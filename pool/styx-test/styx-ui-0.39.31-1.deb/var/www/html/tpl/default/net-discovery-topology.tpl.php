<?php
/**
 * Fragment: Network Discovery Topology tab.
 * Loaded via load_tpl into the disc-topology panel.
 * Expects $tdata['tpl_data']['topology_tab'] with gateways[], segments, etc.
 *
 * @var array<mixed> $tdata
 */

$topo         = $tdata['tpl_data']['topology_tab'] ?? [];
$gateways     = $topo['gateways']           ?? [];
$orphan_segs  = $topo['orphan_segments']    ?? [];
$int_rtrs     = $topo['internal_routers']   ?? [];
$unclass      = $topo['unclassified']       ?? [];
$wan_trees    = $topo['wan_trees']          ?? [];
$central      = $topo['central_router']     ?? null;

// A gateway already shown as a central segment's gateway is not repeated.
$claimed_gw_ips = [];
if (is_array($central)) {
    foreach ($central['segments'] ?? [] as $seg) {
        if (!empty($seg['router_info']['ip'])) {
            $claimed_gw_ips[$seg['router_info']['ip']] = true;
        }
    }
}
$has_central = is_array($central) && (!empty($central['segments']) || !empty($central['ip']));
$render_gateways = $has_central
    ? array_values(array_filter($gateways, static function (array $gw) use ($claimed_gw_ips): bool {
        return !isset($claimed_gw_ips[$gw['ip'] ?? '']);
    }))
    : $gateways;

function renderStatusDot(array $node): void {
    ?><span class="disc-status-dot <?= $node['seen_class'] ?>"
          title="<?= $node['seen_title'] ?>"></span><?php
}

/** Render a VM node with hypervisor vendor badge. */
function renderVmNode(array $node): void {
    ?><span class="disc-tree-node disc-node-host disc-node-host-local"
          data-ip="<?= $node['ip'] ?>">
        <span class="disc-node-icon disc-icon-host"></span>
        <?php renderStatusDot($node); ?><?= $node['ip'] ?>
        <?php if (($node['hostname'] ?? null) !== null): ?>
            <span class="disc-tree-hostname"><?= $node['hostname'] ?></span>
        <?php endif ?>
        <?php if (!empty($node['hypervisor_vendor'])): ?>
            <span class="disc-vm-badge"><?= $node['hypervisor_vendor'] ?></span>
        <?php endif ?>
    </span><?php
}

/** Render a router node with a badge (GW, HV, or source label). */
function renderRouterNode(array $node, string $badge, string $badgeTitle = ''): void {
    $titleAttr = $badgeTitle !== '' ? ' title="' . $badgeTitle . '"' : '';
    ?><span class="disc-tree-node disc-node-router disc-node-router-local"
          data-ip="<?= $node['ip'] ?>">
        <span class="disc-node-icon disc-icon-router"></span>
        <?php renderStatusDot($node); ?><?= $node['ip'] ?>
        <span class="disc-confirmed-badge"<?= $titleAttr ?>><?= $badge ?></span>
        <?php if (!empty($node['asn'])): ?>
            <span class="disc-as-badge">AS<?= $node['asn'] ?></span>
        <?php endif ?>
        <?php if (($node['hostname'] ?? null) !== null): ?>
            <span class="disc-tree-hostname"><?= $node['hostname'] ?></span>
        <?php endif ?>
        <?php if (!empty($node['metric']) && $node['metric'] > 0): ?>
            <span class="disc-tree-hostname">metric <?= $node['metric'] ?></span>
        <?php endif ?>
    </span><?php
}

/** Render a segment <summary> with CIDR, count, optional iface, gateway badge, and AS path. */
function renderSegSummary(string $cidr, int $count, string $iface = '', ?array $gw = null, string $icon = 'disc-icon-local', ?array $asPath = null): void {
    ?><summary class="disc-segment-summary">
        <span class="disc-node-icon <?= $icon ?>"></span>
        <?= $cidr ?>
        <span class="disc-wan-count">(<?= $count ?>)</span>
        <?php if ($iface !== ''): ?>
            <span class="disc-tree-hostname"><?= $iface ?></span>
        <?php endif ?>
        <?php if ($gw !== null && !empty($gw['ip'])): ?>
            <?php $gwKind = (string)($gw['gateway_kind'] ?? ''); ?>
            <span class="disc-gw-badge disc-gw-<?= $gwKind ?>"
                  title="<?= $gwKind === 'default' ? 'Default gateway' : 'Gateway (this router)' ?>">
                gw <?= $gw['ip'] ?><?= $gwKind !== '' ? ' &middot; ' . $gwKind : '' ?>
            </span>
        <?php endif ?>
        <?php if ($asPath !== null && $asPath !== []): ?>
            <span class="disc-as-badge" title="BGP AS path">AS <?= implode(' ', $asPath) ?></span>
        <?php endif ?>
    </summary><?php
}

/** Render a segment's hosts, routers, and nested hypervisors. */
function renderSegmentChildren(array $seg): void {
    $hasRouters     = !empty($seg['routers']);
    $hasHosts       = !empty($seg['hosts']);
    $hasHypervisors = !empty($seg['hypervisors']);
    if (!$hasRouters && !$hasHosts && !$hasHypervisors) return;
    ?>
    <ul class="disc-tree-children">
        <?php // Routers first (infrastructure nodes)
        foreach ($seg['routers'] as $rtr): ?>
        <li class="disc-tree-router">
            <?php renderRouterNode($rtr, $rtr['source'] ?? 'RTR'); ?>
            <?php if (!empty($rtr['segments'])): ?>
            <ul class="disc-tree-children">
                <?php foreach ($rtr['segments'] as $rseg): ?>
                <li class="disc-tree-local">
                    <details class="disc-segment">
                    <?php renderSegSummary($rseg['cidr'], count($rseg['hosts'] ?? []), $rseg['iface'] ?? '', $rseg['router_info'] ?? null, 'disc-icon-local', $rseg['as_path'] ?? null); ?>
                    <?php renderSegmentChildren($rseg); ?>
                    </details>
                </li>
                <?php endforeach ?>
            </ul>
            <?php endif ?>
            <?php if (!empty($rtr['children'])): ?>
            <ul class="disc-tree-children">
                <?php foreach ($rtr['children'] as $child): ?>
                <li class="disc-tree-host">
                    <span class="disc-tree-node disc-node-host disc-node-host-local"
                          data-ip="<?= $child['ip'] ?>">
                        <span class="disc-node-icon disc-icon-host"></span>
                        <?php renderStatusDot($child); ?><?= $child['ip'] ?>
                    </span>
                </li>
                <?php endforeach ?>
            </ul>
            <?php endif ?>
        </li>
        <?php endforeach ?>
        <?php // Hosts second
        foreach ($seg['hosts'] as $h): ?>
        <li class="disc-tree-host">
            <span class="disc-tree-node disc-node-host disc-node-host-local"
                  data-ip="<?= $h['ip'] ?>">
                <span class="disc-node-icon disc-icon-host"></span>
                <?php renderStatusDot($h); ?><?= $h['ip'] ?>
                <?php if (($h['hostname'] ?? null) !== null): ?>
                    <span class="disc-tree-hostname"><?= $h['hostname'] ?></span>
                <?php endif ?>
            </span>
        </li>
        <?php endforeach ?>
        <?php // Hypervisors third
        foreach ($seg['hypervisors'] as $hv): ?>
        <li class="disc-tree-router">
            <?php renderRouterNode($hv, 'HV'); ?>
            <?php if (!empty($hv['vms'])): ?>
            <ul class="disc-tree-children">
                <?php foreach ($hv['vms'] as $vm): ?>
                <li class="disc-tree-host">
                    <?php renderVmNode($vm); ?>
                </li>
                <?php endforeach ?>
            </ul>
            <?php endif ?>
        </li>
        <?php endforeach ?>
    </ul>
    <?php
}
?>
<div class="disc-topo-cols">
<div class="disc-topo-left">
<div class="disc-tree" data-js="disc-topology-tree">
    <!-- DEBUG: gw=<?= count($gateways) ?> rtr=<?= count($int_rtrs) ?> oseg=<?= count($orphan_segs) ?> raw_gw=<?= $topo['_debug_raw_gw'] ?? '?' ?> -->

    <?php if ($has_central): ?>
    <ul class="disc-tree-root disc-tree-section-local">
        <li class="disc-tree-router">
            <?php renderRouterNode($central, $central['source'] ?? 'Styx', 'This router (Styx)'); ?>
            <?php if (!empty($central['segments'])): ?>
            <ul class="disc-tree-children">
                <?php foreach ($central['segments'] as $seg): ?>
                <li class="disc-tree-local">
                    <details class="disc-segment">
                    <?php renderSegSummary($seg['cidr'], count($seg['hosts'] ?? []), $seg['iface'] ?? '', $seg['router_info'] ?? null, 'disc-icon-local', $seg['as_path'] ?? null); ?>
                    <?php renderSegmentChildren($seg); ?>
                    </details>
                </li>
                <?php endforeach ?>
            </ul>
            <?php endif ?>
        </li>
    </ul>
    <?php endif ?>

    <?php foreach ($render_gateways as $gw): ?>
    <?php $badge = $gw['is_default'] ? 'GW' : 'GW'; ?>
    <?php $badgeTitle = $gw['is_default'] ? 'Default gateway' : 'Gateway (metric ' . ($gw['metric'] ?? 0) . ')'; ?>
    <ul class="disc-tree-root disc-tree-section-local">
        <li class="disc-tree-router">
            <?php renderRouterNode($gw, $badge, $badgeTitle); ?>
            <?php if ($gw['has_kids']): ?>
            <ul class="disc-tree-children">
                <?php foreach ($gw['segments'] as $seg): ?>
                <li class="disc-tree-local">
                    <details class="disc-segment">
                    <?php renderSegSummary($seg['cidr'], count($seg['hosts'] ?? []), $seg['iface'] ?? '', $seg['router_info'] ?? null, 'disc-icon-local', $seg['as_path'] ?? null); ?>
                    <?php renderSegmentChildren($seg); ?>
                    </details>
                </li>
                <?php endforeach ?>
            </ul>
            <?php endif ?>
        </li>
    </ul>
    <?php endforeach ?>

    <?php foreach ($int_rtrs as $rtr): ?>
    <ul class="disc-tree-root disc-tree-section-local">
        <li class="disc-tree-router">
            <?php renderRouterNode($rtr, $rtr['source'] ?? 'RTR'); ?>
            <?php if ($rtr['has_kids']): ?>
            <ul class="disc-tree-children">
                <?php foreach ($rtr['segments'] as $seg): ?>
                <li class="disc-tree-local">
                    <details class="disc-segment">
                    <?php renderSegSummary($seg['cidr'], count($seg['hosts'] ?? []), $seg['iface'] ?? '', $seg['router_info'] ?? null, 'disc-icon-local', $seg['as_path'] ?? null); ?>
                    <?php renderSegmentChildren($seg); ?>
                    </details>
                </li>
                <?php endforeach ?>
                <?php foreach ($rtr['children'] as $child): ?>
                <li class="disc-tree-host">
                    <span class="disc-tree-node disc-node-host disc-node-host-local"
                          data-ip="<?= $child['ip'] ?>">
                        <span class="disc-node-icon disc-icon-host"></span>
                        <?php renderStatusDot($child); ?><?= $child['ip'] ?>
                    </span>
                </li>
                <?php endforeach ?>
            </ul>
            <?php endif ?>
        </li>
    </ul>
    <?php endforeach ?>

    <?php foreach ($orphan_segs as $seg): ?>
    <ul class="disc-tree-root disc-tree-section-local">
        <li class="disc-tree-local">
            <details class="disc-segment">
            <?php renderSegSummary($seg['cidr'], count($seg['hosts'] ?? []), $seg['iface'] ?? '', $seg['router_info'] ?? null); ?>
            <?php renderSegmentChildren($seg); ?>
            </details>
        </li>
    </ul>
    <?php endforeach ?>

    <?php if (!empty($unclass)): ?>
    <ul class="disc-tree-root disc-tree-section-local">
        <li class="disc-tree-local">
            <details class="disc-segment" open>
            <summary class="disc-segment-summary">
                <span class="disc-node-icon disc-icon-unknown disc-icon-sm"></span>
                Unclassified
                <span class="disc-wan-count">(<?= count($unclass) ?>)</span>
            </summary>
            <ul class="disc-tree-children">
                <?php foreach ($unclass as $h): ?>
                <li class="disc-tree-host">
                    <span class="disc-tree-node disc-node-host disc-node-host-local"
                          data-ip="<?= $h['ip'] ?>">
                        <span class="disc-node-icon disc-icon-host"></span>
                        <?php renderStatusDot($h); ?><?= $h['ip'] ?>
                        <?php if (($h['hostname'] ?? null) !== null): ?>
                            <span class="disc-tree-hostname"><?= $h['hostname'] ?></span>
                        <?php endif ?>
                        <?php if (($h['source_label'] ?? '') !== ''): ?>
                            <span class="disc-tree-hostname">[<?= $h['source_label'] ?>]</span>
                        <?php endif ?>
                    </span>
                </li>
                <?php endforeach ?>
            </ul>
            </details>
        </li>
    </ul>
    <?php endif ?>

</div><!-- /disc-tree -->
</div><!-- /disc-topo-left -->
<div class="disc-topo-right">

    <?php if (!empty($wan_trees)): ?>
    <details class="disc-wan-section">
        <summary class="disc-wan-summary">
            <span class="disc-node-icon disc-icon-router disc-icon-sm"></span>
            WAN Paths
            <span class="disc-wan-count">(<?= count($wan_trees) ?> roots)</span>
        </summary>
        <div class="disc-wan-tree">
            <?php
            $renderWanNode = null;
            $renderWanNode = function (array $node) use (&$renderWanNode): void {
                $children  = $node['children'] ?? [];
                $targets   = $node['targets']  ?? [];
                $hasKids   = $node['has_kids'] ?? false;
                $isRoot    = $node['is_root'] ?? false;
                $kidsCount = $node['kids_count'] ?? 0;
            ?>
            <li class="disc-tree-router">
                <?php if ($isRoot && $hasKids): ?>
                <details class="disc-segment">
                <summary class="disc-segment-summary">
                    <span class="disc-node-icon disc-icon-router"></span>
                    <?php renderStatusDot($node); ?><?= $node['ip'] ?>
                    <span class="disc-wan-count">(<?= $kidsCount ?>)</span>
                    <?php if ($node['vendor']): ?>
                        <span class="disc-tree-hostname"><?= $node['vendor'] ?></span>
                    <?php endif ?>
                </summary>
                <ul class="disc-tree-children">
                    <?php foreach ($children as $child): ?>
                        <?php $renderWanNode($child); ?>
                    <?php endforeach ?>
                    <?php foreach ($targets as $target): ?>
                    <li class="disc-tree-host">
                        <span class="disc-tree-node disc-node-host" data-ip="<?= $target ?>">
                            <span class="disc-node-icon disc-icon-host"></span>
                            <?= $target ?>
                        </span>
                    </li>
                    <?php endforeach ?>
                </ul>
                </details>
                <?php else: ?>
                <span class="disc-tree-node disc-node-router-wan" data-ip="<?= $node['ip'] ?>">
                    <span class="disc-node-icon disc-icon-router"></span>
                    <?php renderStatusDot($node); ?><?= $node['ip'] ?>
                    <?php if ($node['vendor']): ?>
                        <span class="disc-tree-hostname"><?= $node['vendor'] ?></span>
                    <?php endif ?>
                </span>
                <?php if ($hasKids): ?>
                <ul class="disc-tree-children">
                    <?php foreach ($children as $child): ?>
                        <?php $renderWanNode($child); ?>
                    <?php endforeach ?>
                    <?php foreach ($targets as $target): ?>
                    <li class="disc-tree-host">
                        <span class="disc-tree-node disc-node-host" data-ip="<?= $target ?>">
                            <span class="disc-node-icon disc-icon-host"></span>
                            <?= $target ?>
                        </span>
                    </li>
                    <?php endforeach ?>
                </ul>
                <?php endif ?>
                <?php endif ?>
            </li>
            <?php }; ?>
            <?php foreach ($wan_trees as $root): ?>
            <ul class="disc-tree-root">
                <?php $renderWanNode($root); ?>
            </ul>
            <?php endforeach ?>
        </div>
    </details>
    <?php endif ?>

</div><!-- /disc-topo-right -->
</div><!-- /disc-topo-cols -->
