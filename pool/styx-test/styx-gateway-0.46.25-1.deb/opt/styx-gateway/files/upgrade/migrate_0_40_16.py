"""
Migration script: -> 0.40.16

Strips None-valued keys from discovery host entries in the datastore.
Before this change, every host stored ~12 fields explicitly set to null
(device_type, hostname, ttl, os_guess, hops, cdp_info, lldp_info,
behind_router, proxy_arp_via, router_source, mdns_hostname, mdns_model).
Consumers already use .get() everywhere -- absent key means None -- so
storing the nulls was pure overhead in the persisted JSON file.
"""

from constants.datastore_keys import DS_KEY_DISCOVERY_HOSTS
from core.app_context import AppContext

# Keys that may exist with a None value in hosts persisted before 0.40.16.
# Removing them saves significant space in the JSON datastore.
NULLABLE_KEYS = (
    "device_type",
    "hostname",
    "ttl",
    "os_guess",
    "hops",
    "cdp_info",
    "lldp_info",
    "behind_router",
    "proxy_arp_via",
    "router_source",
    "mdns_hostname",
    "mdns_model",
)


def run(ctx: AppContext) -> bool:
    """Strip None-valued keys from all persisted discovery hosts."""
    logger = ctx.get_logger()
    logger.notice("[MIGRATE 0.40.16] Stripping null fields from discovery hosts...")

    ds = ctx.get_datastore()
    stored = ds.get_data(DS_KEY_DISCOVERY_HOSTS, store="discovery-data")

    if not stored or not isinstance(stored, dict):
        logger.notice("[MIGRATE 0.40.16] No discovery data to migrate.")
        return True

    stripped = 0
    for ip, host in stored.items():
        if not isinstance(host, dict):
            continue
        for key in NULLABLE_KEYS:
            if host.get(key) is None:
                del host[key]
                stripped += 1

    if stripped:
        ok = ds.replace_data(DS_KEY_DISCOVERY_HOSTS, stored, store="discovery-data")
        if not ok:
            logger.error("[MIGRATE 0.40.16] Failed to write cleaned discovery data.")
            return False
        logger.notice(f"[MIGRATE 0.40.16] Removed {stripped} null fields from {len(stored)} hosts.")
    else:
        logger.notice("[MIGRATE 0.40.16] No null fields found -- already clean.")

    return True
