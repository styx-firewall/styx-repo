<?php

/**
 * TemplateService->getTpl()
 * @var array<mixed> $tdata
 */
$page_data = $tdata['page_data'] ?? [];
$cpu_usage = $page_data['cpu_usage'] ?? [];
$memory_usage = $page_data['memory_usage'] ?? [];
$network_usage = $page_data['network_usage'] ?? [];
?>

<?= $tdata['page_head'] ?>
<div class="page-layout">
    <?= $tdata['sidebar'] ?>
    <main class="page-content">
        <h1>Dashboard</h1>
        <h2>Overview</h2>
        <div id="dashboard-grid" class="dashboard-muuri-grid">
            <div class="std-grid-item-type1" data-widget-id="system-overview">
                <h3>System Overview</h3>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        Hostname
                    </div>
                    <div class="std-flex-col" id="sysinfo-hostname">
                        <?= $page_data['hostname'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        Domain
                    </div>
                    <div class="std-flex-col" id="sysinfo-domain">
                        <?= $page_data['domain'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        Styx Version
                    </div>
                    <div class="std-flex-col" id="sysinfo-version">
                        <?= $page_data['version'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        OS
                    </div>
                    <div class="std-flex-col" id="sysinfo-os-name">
                        <?= $page_data['os_name'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        OS Version
                    </div>
                    <div class="std-flex-col" id="sysinfo-os-version">
                        <?= $page_data['os_version'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        Kernel
                    </div>
                    <div class="std-flex-col" id="sysinfo-kernel">
                        <?= $page_data['kernel'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        Architecture
                    </div>
                    <div class="std-flex-col" id="sysinfo-arch">
                        <?= $page_data['arch'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        CPUs
                    </div>
                    <div class="std-flex-col" id="sysinfo-cpus">
                        <?= $page_data['num_cpus'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        System Uptime
                    </div>
                    <div class="std-flex-col" id="sysinfo-uptime">
                        <?= $page_data['uptime'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        Styx Uptime
                    </div>
                    <div class="std-flex-col" id="sysinfo-styx-uptime">
                        <?= $page_data['styx_uptime'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        Status
                    </div>
                    <div class="std-flex-col" id="sysinfo-status">
                        <?= $page_data['fw_status'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        Updates
                    </div>
                    <div class="std-flex-col" id="sysinfo-update">
                        <?= $page_data['update'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        System Language
                    </div>
                    <div class="std-flex-col" id="sysinfo-language">
                        <?= $page_data['language'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        System Timezone
                    </div>
                    <div class="std-flex-col" id="sysinfo-timezone">
                        <?= $page_data['timezone'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        System UUID
                    </div>
                    <div class="std-flex-col uuid-val" id="sysinfo-system-uuid" title="<?= $page_data['system_uuid'] ?? '' ?>">
                        <?= $page_data['system_uuid'] ?? '' ?>
                    </div>
                </div>
                <div class="std-flex-row">
                    <div class="std-flex-col">
                        Machine ID
                    </div>
                    <div class="std-flex-col uuid-val" id="sysinfo-machine-id" title="<?= $page_data['machine_id'] ?? '' ?>">
                        <?= $page_data['machine_id'] ?? '' ?>
                    </div>
                </div>
            </div>
            <div class="std-grid-item-type1" id="watchdog-panel" data-widget-id="watchdog">
                <h3>Watchdog</h3>
                <div id="watchdog-content">
                    <div class="std-flex-row">
                        <div class="std-flex-col" style="text-align:center;padding:20px;">Loading...</div>
                    </div>
                </div>
            </div>
            <div class="std-grid-item-type1" data-widget-id="cpu">
                <h3>CPU Usage</h3>
                <canvas id="cpu-chart" class="chart-canvas"></canvas>
            </div>
            <div class="std-grid-item-type1" data-widget-id="memory">
                <h3>Memory Usage</h3>
                <canvas id="memory-chart" class="chart-canvas"></canvas>
            </div>
            <div class="std-grid-item-type1" data-widget-id="network-tx">
                <h3>Network TX</h3>
                <canvas id="network-tx-chart" class="chart-canvas"></canvas>
            </div>
            <div class="std-grid-item-type1" data-widget-id="network-rx">
                <h3>Network RX</h3>
                <canvas id="network-rx-chart" class="chart-canvas"></canvas>
            </div>
        </div>
    </main>
</div>
