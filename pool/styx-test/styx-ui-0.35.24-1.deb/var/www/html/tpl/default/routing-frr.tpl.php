<?php
/**
 * @var array<mixed> $tdata
 * js: scripts/routing/routing-frr.js
 */
$page_data    = $tdata['page_data'];
$frr_profile  = $page_data['frr_profile'] ?? null;
$frr_max_fds  = $page_data['frr_max_fds'] ?? null;
$frr_no_root  = $page_data['frr_no_root'] ?? null;
$vtysh_enable = $page_data['vtysh_enable'] ?? null;
$features     = $page_data['features'] ?? [];
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>FRR Global Settings</h1>

        <details class="nat-help">
            <summary>Help</summary>
            <div class="nat-help-content">
                <p><strong>FRR Global Settings</strong> control how FRRouting operates system-wide.</p>
                <ul>
                    <li><strong>Profile:</strong> <em>traditional</em> uses per-daemon config files. <em>datacenter</em> merges all daemons into a single integrated config — recommended for most setups.</li>
                    <li><strong>vtysh:</strong> Enable the VTY shell for interactive CLI management (<code>vtysh</code>). Useful for debugging but not required for GUI operation.</li>
                </ul>
            </div>
        </details>

        <?php if (empty($features['frrouting'])): ?>
            <div class="content-box">
                <p>FRRouting is not enabled.</p>
            </div>
        <?php else: ?>
            <div class="content-box">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-heading">FRR Global</h2>
                    </div>
                    <div class="card-body std-form">
                        <div class="form-row" style="align-items:flex-end; margin-bottom:1rem;">
                            <div class="form-col" style="max-width:250px;">
                                <label class="form-label" for="frr-profile">Profile</label>
                                <select class="form-select" id="frr-profile">
                                    <option value="" <?= $frr_profile === null ? 'selected' : '' ?>>Default</option>
                                    <option value="traditional" <?= $frr_profile === 'traditional' ? 'selected' : '' ?>>Traditional</option>
                                    <option value="datacenter" <?= $frr_profile === 'datacenter' ? 'selected' : '' ?>>Datacenter</option>
                                </select>
                            </div>
                            <div class="form-col" style="max-width:160px;">
                                <label class="form-label" for="frr-max-fds">Max FDs</label>
                                <input type="number" class="form-control" id="frr-max-fds"
                                       value="<?= $frr_max_fds ?? '' ?>"
                                       placeholder="default" min="1" step="1">
                            </div>
                            <div class="form-col" style="max-width:160px;">
                                <label class="form-label" for="frr-no-root">FRR No Root</label>
                                <select class="form-select" id="frr-no-root">
                                    <option value="" <?= $frr_no_root === null ? 'selected' : '' ?>>Default</option>
                                    <option value="1" <?= $frr_no_root === true ? 'selected' : '' ?>>Yes</option>
                                    <option value="0" <?= $frr_no_root === false ? 'selected' : '' ?>>No</option>
                                </select>
                            </div>
                            <div class="form-col" style="max-width:160px;">
                                <label class="form-label" for="vtysh-enable">VTYSH Enable</label>
                                <select class="form-select" id="vtysh-enable">
                                    <option value="" <?= $vtysh_enable === null ? 'selected' : '' ?>>Default</option>
                                    <option value="1" <?= $vtysh_enable === true ? 'selected' : '' ?>>Yes</option>
                                    <option value="0" <?= $vtysh_enable === false ? 'selected' : '' ?>>No</option>
                                </select>
                            </div>
                            <div class="form-col" style="max-width:100px;">
                                <button type="button" class="std-btn" id="frr-save-btn">
                                    <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
                                        <path d="M3 8l4 4 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    Save
                                </button>
                            </div>
                        </div>
                        <div id="frr-result"></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </main>
</div>
