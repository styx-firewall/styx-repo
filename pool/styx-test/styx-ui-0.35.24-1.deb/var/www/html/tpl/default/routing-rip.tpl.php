<?php
/**
 * @var array<mixed> $tdata
 * js: scripts/routing/routing-rip.js
 */
$page_data  = $tdata['page_data'];
$rip_config = $page_data['rip_config'] ?? [];
$networks   = $page_data['networks'] ?? [];
$neighbors  = $page_data['neighbors'] ?? [];
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>RIP</h1>

        <details class="nat-help">
            <summary>Help</summary>
            <div class="nat-help-content">
                <p><strong>RIP (Routing Information Protocol)</strong> is a distance-vector protocol suitable for small, flat networks. Easy to configure but limited to 15 hops.</p>
                <ul>
                    <li><strong>Version 2:</strong> Use RIP v2 (supports CIDR, multicast updates). Avoid v1 unless legacy equipment requires it.</li>
                    <li><strong>Networks:</strong> Add the prefixes (address sets) that RIP should advertise and listen on.</li>
                    <li><strong>Timers:</strong> Defaults (30/180/120) work for most setups. Tune only if convergence time is critical.</li>
                </ul>
            </div>
        </details>

        <!-- ── Global RIP config ── -->
        <div class="content-box">
            <h2>RIP Configuration</h2>
            <form id="rip-config-form" class="std-form form-compact" data-js="rip-config-form">
                <div class="form-row">
                    <div class="form-col form-col--tight">
                        <label for="rip_enabled">Enabled</label>
                        <label class="std-switch">
                            <input type="checkbox" id="rip_enabled" name="enabled"
                                <?= !empty($rip_config['enabled']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="rip_version">Version</label>
                        <select id="rip_version" name="version" class="std-select">
                            <option value="2" <?= ($rip_config['version'] ?? 2) == 2 ? 'selected' : '' ?>>RIPv2</option>
                            <option value="1" <?= ($rip_config['version'] ?? 2) == 1 ? 'selected' : '' ?>>RIPv1</option>
                        </select>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="rip_default_metric">Default Metric</label>
                        <input type="number" id="rip_default_metric" name="default_metric" class="std-input"
                            min="1" max="16" placeholder="1"
                            value="<?= $rip_config['default_metric'] ?? '' ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="rip_update_timer">Update Timer (s)</label>
                        <input type="number" id="rip_update_timer" name="update_timer" class="std-input"
                            min="1" max="65535" placeholder="30"
                            value="<?= $rip_config['update_timer'] ?? '' ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="rip_timeout_timer">Timeout Timer (s)</label>
                        <input type="number" id="rip_timeout_timer" name="timeout_timer" class="std-input"
                            min="1" max="65535" placeholder="180"
                            value="<?= $rip_config['timeout_timer'] ?? '' ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="rip_garbage_timer">Garbage Timer (s)</label>
                        <input type="number" id="rip_garbage_timer" name="garbage_timer" class="std-input"
                            min="1" max="65535" placeholder="120"
                            value="<?= $rip_config['garbage_timer'] ?? '' ?>">
                    </div>
                </div>
                <div class="form-row">
                    <button type="button" class="std-btn" data-js="rip-save-config">Save Configuration</button>
                </div>
            </form>
        </div>

        <!-- ── Networks table ── -->
        <div class="content-box">
            <div class="content-box-header">
                <h2>RIP Networks</h2>
                <button type="button" class="std-btn" data-js="rip-add-network-open">+ Add Network</button>
            </div>
            <table class="std-table" id="rip-networks-table">
                <thead>
                    <tr>
                        <th>Network</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="rip-networks-tbody">
                <?php if (empty($networks)): ?>
                    <tr class="std-table-empty"><td colspan="2">No networks configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($networks as $net): ?>
                    <?php $netDisplay = $net['network_set_display'] ?? null; ?>
                    <tr data-network-id="<?= $net['id'] ?>">
                        <td>
                            <?php if ($netDisplay): ?>
                                <span class="set-ref" title="ID: <?= $netDisplay['id'] ?>">
                                    <?php if (!empty($netDisplay['family'])): ?><span class="set-type"><?= $netDisplay['family'] ?></span><?php endif; ?>
                                    <span class="set-name"><?= $netDisplay['name'] ?></span>
                                </span>
                            <?php else: ?>
                                <span class="text-dim">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="rip-delete-network" data-id="<?= $net['id'] ?>">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- ── Add network form (hidden by default) ── -->
        <div class="content-box" id="rip-add-network-form" style="display:none;">
            <h2>Add RIP Network</h2>
            <form class="std-form form-compact" data-js="rip-network-form">
                <div class="form-row">
                    <div class="form-col">
                        <label>Network (address set)</label>
                        <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                             data-max-select="1" data-filter-scope="network">
                            <input type="hidden" id="rip_network_set" name="network_set" value="">
                            <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                data-placeholder="Select network set">
                                <span class="js-set-picker-label">Select network</span>
                            </button>
                            <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                title="Clear selection">&#215;</button>
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <button type="button" class="std-btn" data-js="rip-network-save">Add Network</button>
                    <button type="button" class="std-btn std-btn--secondary" data-js="rip-add-network-cancel">Cancel</button>
                </div>
            </form>
        </div>

        <!-- ── Neighbors (read-only) ── -->
        <div class="content-box">
            <h2>RIP Neighbors</h2>
            <table class="std-table" id="rip-neighbors-table">
                <thead>
                    <tr>
                        <th>Address</th>
                        <th>Interface</th>
                        <th>Last Update</th>
                    </tr>
                </thead>
                <tbody id="rip-neighbors-tbody">
                <?php if (empty($neighbors)): ?>
                    <tr class="std-table-empty"><td colspan="3">No neighbors discovered.</td></tr>
                <?php else: ?>
                    <?php foreach ($neighbors as $n): ?>
                    <tr>
                        <td><?= $n['address'] ?></td>
                        <td><?= $n['interface'] ?? '—' ?></td>
                        <td><?= $n['last_update'] ?? '—' ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

    </main>
</div>
