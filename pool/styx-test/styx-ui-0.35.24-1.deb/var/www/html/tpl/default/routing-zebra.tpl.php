<?php
/** FRR Zebra config @var array<mixed> $tdata js: scripts/routing/routing-zebra.js */
$zc = $tdata['page_data']['zebra_config'] ?? [];
$rm = $tdata['page_data']['route_maps'] ?? [];
$can_save = !empty($tdata['page_data']['can_save']);
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>Zebra</h1>

        <details class="nat-help">
            <summary>Help</summary>
            <div class="nat-help-content">
                <p><strong>Zebra</strong> is the FRR daemon that manages the kernel routing table and provides the RIB (Routing Information Base) for all other FRR protocols.</p>
                <ul>
                    <li><strong>Router ID:</strong> 32-bit identifier used as default for protocols that don't set their own.</li>
                    <li><strong>NHT via Default:</strong> Allow nexthop tracking to resolve via the default route. Enable if routes point to nexthops reachable only through the default gateway.</li>
                </ul>
            </div>
        </details>
        <div class="content-box">
            <h2>Configuration</h2>
            <form class="std-form form-compact" data-js="zebra-config-form">
                <div class="form-row">
                    <div class="form-col">
                        <label>Router ID</label>
                        <?php $rid = $zc['router_id_display'] ?? null; ?>
                        <div class="set-picker-field" data-js="label-picker-field" data-set-type="router_id"
                             data-max-select="1" data-label-title="Select Router ID">
                            <input type="hidden" id="zebra_router_id" value="<?= $zc['router_id'] ?? '' ?>">
                            <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                data-placeholder="Select Router ID">
                                <span class="js-set-picker-label"><?= $rid ? $rid['name'] : 'Select Router ID' ?></span>
                            </button>
                            <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear<?= $rid ? '' : ' sets-hidden' ?>"
                                title="Clear">&#215;</button>
                        </div>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="zebra_ip_nht">IPv4 NHT via Default</label>
                        <label class="std-switch">
                            <input type="checkbox" id="zebra_ip_nht"
                                <?= !empty($zc['ip_nht_resolve_via_default']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="zebra_ipv6_nht">IPv6 NHT via Default</label>
                        <label class="std-switch">
                            <input type="checkbox" id="zebra_ipv6_nht"
                                <?= !empty($zc['ipv6_nht_resolve_via_default']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <?php if ($can_save): ?>
                <button type="button" class="std-btn" data-js="zebra-save-config">Save</button>
                <?php endif; ?>
            </form>
        </div>
    </main>
</div>
