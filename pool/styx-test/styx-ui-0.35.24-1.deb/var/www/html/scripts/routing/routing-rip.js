// routing-rip.js
// RIP configuration and network management

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }

    // ── Save RIP global config ──────────────────────────────────────────────
    const saveConfigBtn = document.querySelector('[data-js="rip-save-config"]');
    if (saveConfigBtn) {
        saveConfigBtn.addEventListener('click', async () => {
            const data = {
                version:        parseInt(document.getElementById('rip_version').value, 10),
                enabled:        document.getElementById('rip_enabled').checked,
                default_metric: parseInt(document.getElementById('rip_default_metric').value, 10) || 1,
                update_timer:   parseInt(document.getElementById('rip_update_timer').value, 10) || 30,
                timeout_timer:  parseInt(document.getElementById('rip_timeout_timer').value, 10) || 180,
                garbage_timer:  parseInt(document.getElementById('rip_garbage_timer').value, 10) || 120,
            };
            try {
                const result = await apiClient.submit('routing_save_rip_config', data);
                showApiResult(result, { title: 'RIP Configuration', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // ── Show/hide add network form ──────────────────────────────────────────
    const addNetworkOpenBtn = document.querySelector('[data-js="rip-add-network-open"]');
    const addNetworkForm    = document.getElementById('rip-add-network-form');
    const addNetworkCancel  = document.querySelector('[data-js="rip-add-network-cancel"]');

    if (addNetworkOpenBtn && addNetworkForm) {
        addNetworkOpenBtn.addEventListener('click', () => {
            addNetworkForm.style.display = '';
            addNetworkOpenBtn.style.display = 'none';
        });
    }
    if (addNetworkCancel && addNetworkForm) {
        addNetworkCancel.addEventListener('click', () => {
            addNetworkForm.style.display = 'none';
            if (addNetworkOpenBtn) addNetworkOpenBtn.style.display = '';
        });
    }

    // ── Add RIP network ─────────────────────────────────────────────────────
    const saveNetworkBtn = document.querySelector('[data-js="rip-network-save"]');
    if (saveNetworkBtn) {
        saveNetworkBtn.addEventListener('click', async () => {
            const networkSet = document.getElementById('rip_network_set').value.trim();

            if (!networkSet) {
                showModal('<p>Select an address set for the network.</p>',
                    { title: 'Validation', closeText: 'Close' });
                return;
            }

            const data = { network_set: networkSet };
            try {
                const result = await apiClient.submit('routing_add_rip_network', data);
                showApiResult(result, { title: 'Add RIP Network', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // ── Delete RIP network ──────────────────────────────────────────────────
    document.querySelectorAll('[data-js="rip-delete-network"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this RIP network?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('routing_delete_rip_network', { id });
                        showApiResult(result, { title: 'Delete RIP Network', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });
});
