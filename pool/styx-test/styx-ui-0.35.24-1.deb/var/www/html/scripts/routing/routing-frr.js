/**
 * routing-frr.js
 * FRR Global Settings — profile selector (traditional / datacenter).
 */
(function (window) {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        var saveBtn = document.getElementById('frr-save-btn');
        var profileSelect = document.getElementById('frr-profile');
        var resultEl = document.getElementById('frr-result');

        if (!saveBtn || !profileSelect || !resultEl) return;

        saveBtn.addEventListener('click', async function () {
            saveBtn.disabled = true;
            resultEl.textContent = 'Saving…';

            var profile = profileSelect.value || null;
            var maxFdsRaw = document.getElementById('frr-max-fds')?.value;
            var maxFds = (maxFdsRaw !== '' && maxFdsRaw !== undefined)
                ? parseInt(maxFdsRaw, 10) : null;
            var frrNoRootRaw = document.getElementById('frr-no-root')?.value;
            var frrNoRoot = frrNoRootRaw === '1' ? true : (frrNoRootRaw === '0' ? false : null);
            var vtyshEnableRaw = document.getElementById('vtysh-enable')?.value;
            var vtyshEnable = vtyshEnableRaw === '1' ? true : (vtyshEnableRaw === '0' ? false : null);

            try {
                var result = await window.apiClient.submit('routing_save_frr_global', {
                    profile: profile,
                    max_fds: maxFds,
                    frr_no_root: frrNoRoot,
                    vtysh_enable: vtyshEnable,
                });
                showApiResult(result, {
                    title: 'FRR Global Settings',
                    closeText: 'Close',
                });
                resultEl.textContent = '';
                resultEl.className = '';
            } catch (err) {
                resultEl.textContent = 'Error: ' + (err.message || 'Request failed');
                resultEl.className = 'hint warn';
            } finally {
                saveBtn.disabled = false;
            }
        });
    });
})(window);
