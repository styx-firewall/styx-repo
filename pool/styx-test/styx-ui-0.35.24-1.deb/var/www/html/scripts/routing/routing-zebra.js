// routing-zebra.js
document.addEventListener('DOMContentLoaded', () => {
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }
    const save = document.querySelector('[data-js="zebra-save-config"]');
    if (save) {
        save.addEventListener('click', async () => {
            try {
                const r = await apiClient.submit('routing_save_zebra_config', {
                    router_id: document.getElementById('zebra_router_id').value.trim() || null,
                    ip_nht_resolve_via_default: document.getElementById('zebra_ip_nht').checked,
                    ipv6_nht_resolve_via_default: document.getElementById('zebra_ipv6_nht').checked,
                });
                showApiResult(r, { title: 'Zebra Config', closeText: 'Close', reloadOnOk: true });
            } catch (e) { showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' }); }
        });
    }
});
