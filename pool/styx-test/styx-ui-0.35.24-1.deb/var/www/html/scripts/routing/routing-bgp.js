// routing-bgp.js
// BGP configuration and neighbor management

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }

    // ── Save BGP global config ──────────────────────────────────────────────
    const saveConfigBtn = document.querySelector('[data-js="bgp-save-config"]');
    if (saveConfigBtn) {
        saveConfigBtn.addEventListener('click', async () => {
            // Collect redistribute entries
            const redistribute = [];
            document.querySelectorAll('.js-redist-proto:checked').forEach(cb => {
                const proto = cb.value;
                const rmEl = document.querySelector('.js-redist-route-map[data-proto="' + proto + '"]');
                const metricEl = document.querySelector('.js-redist-metric[data-proto="' + proto + '"]');
                const entry = { protocol: proto };
                if (rmEl && rmEl.value) {
                    entry.route_map = rmEl.value;
                }
                if (metricEl && metricEl.value.trim()) {
                    entry.metric = parseInt(metricEl.value, 10);
                }
                redistribute.push(entry);
            });

            const data = {
                router_as:            document.getElementById('bgp_router_as').value.trim(),
                router_id:            document.getElementById('bgp_router_id').value.trim(),
                enabled:              document.getElementById('bgp_enabled').checked,
                keepalive:            parseInt(document.getElementById('bgp_keepalive').value, 10) || 60,
                hold_time:            parseInt(document.getElementById('bgp_hold_time').value, 10) || 180,
                default_local_pref:   parseInt(document.getElementById('bgp_default_local_pref').value, 10) || 100,
                log_neighbor_changes: document.getElementById('bgp_log_neighbor_changes').checked,
                always_compare_med:   document.getElementById('bgp_always_compare_med').checked,
                graceful_restart:                   document.getElementById('bgp_graceful_restart').checked,
                ebgp_requires_policy:               document.getElementById('bgp_ebgp_requires_policy').checked,
                disable_ebgp_connected_route_check:  document.getElementById('bgp_disable_ebgp_connected_route_check').checked,
                redistribute: redistribute,
            };
            try {
                const result = await apiClient.submit('routing_save_bgp_config', data);
                showApiResult(result, { title: 'BGP Configuration', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // ── Show/hide add neighbor form ─────────────────────────────────────────
    const addNeighborOpenBtn = document.querySelector('[data-js="bgp-add-neighbor-open"]');
    const addNeighborForm    = document.getElementById('bgp-add-neighbor-form');
    const addNeighborCancel  = document.querySelector('[data-js="bgp-add-neighbor-cancel"]');

    if (addNeighborOpenBtn && addNeighborForm) {
        addNeighborOpenBtn.addEventListener('click', () => {
            addNeighborForm.style.display = '';
            addNeighborOpenBtn.style.display = 'none';
            // Reset to add mode
            document.getElementById('bgp_neighbor_id').value = '';
            ['bgp_neighbor_update_source', 'bgp_neighbor_peer_group',
             'bgp_neighbor_route_map_in', 'bgp_neighbor_route_map_out',
             'bgp_neighbor_bfd_profile'].forEach(id => {
                const el = document.getElementById(id); if (el) el.value = '';
            });
            const title = document.getElementById('bgp-neighbor-form-title');
            if (title) title.textContent = 'Add BGP Neighbor';
        });
    }
    if (addNeighborCancel && addNeighborForm) {
        addNeighborCancel.addEventListener('click', () => {
            addNeighborForm.style.display = 'none';
            if (addNeighborOpenBtn) addNeighborOpenBtn.style.display = '';
            // Reset to add mode
            document.getElementById('bgp_neighbor_id').value = '';
            ['bgp_neighbor_update_source', 'bgp_neighbor_peer_group',
             'bgp_neighbor_route_map_in', 'bgp_neighbor_route_map_out',
             'bgp_neighbor_bfd_profile'].forEach(id => {
                const el = document.getElementById(id); if (el) el.value = '';
            });
            const title = document.getElementById('bgp-neighbor-form-title');
            if (title) title.textContent = 'Add BGP Neighbor';
        });
    }

    // ── Add neighbor ────────────────────────────────────────────────────────
    const saveNeighborBtn = document.querySelector('[data-js="bgp-neighbor-save"]');
    if (saveNeighborBtn) {
        saveNeighborBtn.addEventListener('click', async () => {
            const neighborId  = document.getElementById('bgp_neighbor_id').value.trim();
            const ipSet        = document.getElementById('bgp_neighbor_ip_set').value.trim();
            const remoteAs     = document.getElementById('bgp_neighbor_as').value.trim();
            const desc         = document.getElementById('bgp_neighbor_desc').value.trim();
            const password     = document.getElementById('bgp_neighbor_password').value;
            const multihop     = parseInt(document.getElementById('bgp_neighbor_ebgp_multihop').value, 10) || 0;
            const updateSrc    = document.getElementById('bgp_neighbor_update_source').value.trim();
            const keepalive    = document.getElementById('bgp_neighbor_keepalive').value.trim();
            const holdTime     = document.getElementById('bgp_neighbor_hold_time').value.trim();
            const nextHopSelf  = document.getElementById('bgp_neighbor_next_hop_self').checked;
            const softReconfig = document.getElementById('bgp_neighbor_soft_reconfig').checked;
            const rrClient     = document.getElementById('bgp_neighbor_rr_client').checked;
            const bfd          = document.getElementById('bgp_neighbor_bfd').checked;
            const bfdStrict    = document.getElementById('bgp_neighbor_bfd_strict').checked;
            const bfdStrictHold = parseInt(document.getElementById('bgp_neighbor_bfd_strict_hold_time').value, 10) || null;
            const bfdCpFailure  = document.getElementById('bgp_neighbor_bfd_cp_failure').checked;
            const bfdProfile    = document.getElementById('bgp_neighbor_bfd_profile').value.trim();
            const peerGroup     = document.getElementById('bgp_neighbor_peer_group').value.trim();
            const routeMapIn    = document.getElementById('bgp_neighbor_route_map_in').value.trim();
            const routeMapOut   = document.getElementById('bgp_neighbor_route_map_out').value.trim();

            const addrFamilies = [];
            document.querySelectorAll('.js-address-family:checked').forEach(cb => {
                addrFamilies.push(cb.value);
            });

            if (!neighborId) {
                // Add mode — required fields
                if (!ipSet) {
                    showModal('<p>Select an address set for the neighbor IP.</p>',
                        { title: 'Validation', closeText: 'Close' });
                    return;
                }
                if (!remoteAs) {
                    showModal('<p>Remote AS label is required.</p>',
                        { title: 'Validation', closeText: 'Close' });
                    return;
                }
            }

            const data = {
                neighbor_ip_set:                     ipSet || undefined,
                remote_as:                           remoteAs || undefined,
                description:                         desc,
                password:                            password || null,
                ebgp_multihop:                       multihop,
                update_source:                       updateSrc || null,
                keepalive:                           keepalive ? parseInt(keepalive, 10) : null,
                hold_time:                           holdTime ? parseInt(holdTime, 10) : null,
                next_hop_self:                       nextHopSelf,
                soft_reconfiguration_inbound:        softReconfig,
                route_reflector_client:              rrClient,
                bfd,
                bfd_strict:                          bfdStrict,
                bfd_strict_hold_time:                bfdStrictHold,
                bfd_check_control_plane_failure:     bfdCpFailure,
                bfd_profile:                         bfdProfile || null,
                peer_group:                          peerGroup || null,
                route_map_in:                        routeMapIn || null,
                route_map_out:                       routeMapOut || null,
                address_families:                    addrFamilies,
            };

            if (neighborId) {
                data.id = neighborId;
                // Remove undefined keys for partial update
                Object.keys(data).forEach(k => {
                    if (data[k] === undefined) delete data[k];
                });
            }

            const command = neighborId ? 'routing_update_bgp_neighbor' : 'routing_add_bgp_neighbor';
            const title = neighborId ? 'Update BGP Neighbor' : 'Add BGP Neighbor';

            try {
                const result = await apiClient.submit(command, data);
                showApiResult(result, { title: title, closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // ── Edit neighbor — populate form ───────────────────────────────────────
    document.querySelectorAll('[data-js="bgp-edit-neighbor"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const form   = document.getElementById('bgp-add-neighbor-form');
            const title  = document.getElementById('bgp-neighbor-form-title');
            const openBtn = document.querySelector('[data-js="bgp-add-neighbor-open"]');

            // Set hidden id
            document.getElementById('bgp_neighbor_id').value = btn.dataset.id;

            // Populate text/number fields
            const setVal = (id, val) => {
                const el = document.getElementById(id);
                if (el) el.value = val;
            };
            setVal('bgp_neighbor_desc', btn.dataset.description);
            setVal('bgp_neighbor_ebgp_multihop', btn.dataset.ebgpMultihop);
            setVal('bgp_neighbor_update_source', btn.dataset.updateSource);
            setVal('bgp_neighbor_keepalive', btn.dataset.keepalive);
            setVal('bgp_neighbor_hold_time', btn.dataset.holdTime);
            setVal('bgp_neighbor_bfd_strict_hold_time', btn.dataset.bfdStrictHold);
            setVal('bgp_neighbor_bfd_profile', btn.dataset.bfdProfile);
            setVal('bgp_neighbor_peer_group', btn.dataset.peerGroup);
            setVal('bgp_neighbor_route_map_in', btn.dataset.routeMapIn);
            setVal('bgp_neighbor_route_map_out', btn.dataset.routeMapOut);

            // Set checkboxes
            const setChk = (id, val) => {
                const el = document.getElementById(id);
                if (el) el.checked = (val === '1');
            };
            setChk('bgp_neighbor_next_hop_self', btn.dataset.nextHopSelf);
            setChk('bgp_neighbor_soft_reconfig', btn.dataset.softReconfig);
            setChk('bgp_neighbor_rr_client', btn.dataset.rrClient);
            setChk('bgp_neighbor_bfd', btn.dataset.bfd);
            setChk('bgp_neighbor_bfd_strict', btn.dataset.bfdStrict);
            setChk('bgp_neighbor_bfd_cp_failure', btn.dataset.bfdCpFailure);

            // Set address families
            const afs = (btn.dataset.addressFamilies || '').split(',').filter(Boolean);
            document.querySelectorAll('.js-address-family').forEach(cb => {
                cb.checked = afs.includes(cb.value);
            });

            // Set set-picker hidden inputs for ip_set and remote_as
            setVal('bgp_neighbor_ip_set', btn.dataset.ipSet);
            setVal('bgp_neighbor_as', btn.dataset.remoteAs);
            // Update picker labels from data attributes if possible
            const ipLabel = document.querySelector('#bgp-add-neighbor-form .set-picker-field[data-filter-scope="host"] .js-set-picker-label');
            const asLabel = document.querySelector('#bgp-add-neighbor-form .set-picker-field[data-set-type="as_number"] .js-set-picker-label');
            // Try to find labels from the table row
            const row = btn.closest('tr');
            if (row && ipLabel) {
                const ipCell = row.querySelector('.set-name');
                if (ipCell) ipLabel.textContent = ipCell.textContent;
            }

            // Show form, update title
            if (title) title.textContent = 'Edit BGP Neighbor';
            if (openBtn) openBtn.style.display = 'none';
            form.style.display = '';

            // Clear password (never returned by backend)
            setVal('bgp_neighbor_password', '');
        });
    });

    // ── Delete neighbor ─────────────────────────────────────────────────────
    document.querySelectorAll('[data-js="bgp-delete-neighbor"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this BGP neighbor?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('routing_delete_bgp_neighbor', { id });
                        showApiResult(result, { title: 'Delete Neighbor', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });

    // ── Show/hide add network form ──────────────────────────────────────────
    const addNetworkOpenBtn = document.querySelector('[data-js="bgp-add-network-open"]');
    const addNetworkForm    = document.getElementById('bgp-add-network-form');
    const addNetworkCancel  = document.querySelector('[data-js="bgp-add-network-cancel"]');

    if (addNetworkOpenBtn && addNetworkForm) {
        addNetworkOpenBtn.addEventListener('click', () => {
            addNetworkForm.style.display = '';
            addNetworkOpenBtn.style.display = 'none';
        });
    }
    if (addNetworkCancel && addNetworkForm) {
        addNetworkCancel.addEventListener('click', () => {
            addNetworkForm.style.display = 'none';
            if (addNetworkOpenBtn) addNetworkOpenBtn.style.display = '';
        });
    }

    // ── Add network ─────────────────────────────────────────────────────────
    const saveNetworkBtn = document.querySelector('[data-js="bgp-network-save"]');
    if (saveNetworkBtn) {
        saveNetworkBtn.addEventListener('click', async () => {
            const networkSet = document.getElementById('bgp_network_set').value.trim();

            if (!networkSet) {
                showModal('<p>Select an address set for the network prefix.</p>',
                    { title: 'Validation', closeText: 'Close' });
                return;
            }

            try {
                const result = await apiClient.submit('routing_add_bgp_network',
                    { network_set: networkSet });
                showApiResult(result, { title: 'Add BGP Network', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message },
                    { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // ── Delete network ──────────────────────────────────────────────────────
    document.querySelectorAll('[data-js="bgp-delete-network"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this BGP network?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('routing_delete_bgp_network', { id });
                        showApiResult(result, { title: 'Delete Network', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message },
                            { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });

    // ── Peer Groups: toggle form ────────────────────────────────────────────
    const addPgOpen  = document.querySelector('[data-js="bgp-add-peergroup-open"]');
    const addPgForm  = document.getElementById('bgp-add-peergroup-form');
    const addPgCancel = document.querySelector('[data-js="bgp-add-peergroup-cancel"]');

    if (addPgOpen && addPgForm) {
        addPgOpen.addEventListener('click', () => {
            resetPeerGroupForm();
            addPgForm.style.display = '';
            addPgOpen.style.display = 'none';
        });
    }
    if (addPgCancel && addPgForm) {
        addPgCancel.addEventListener('click', () => {
            addPgForm.style.display = 'none';
            if (addPgOpen) addPgOpen.style.display = '';
        });
    }

    function resetPeerGroupForm() {
        document.getElementById('bgp_peergroup_id').value = '';
        document.getElementById('bgp_pg_name').value = '';
        document.getElementById('bgp_pg_remote_as').value = '';
        document.getElementById('bgp_pg_desc').value = '';
        document.getElementById('bgp_pg_rm_in').selectedIndex = 0;
        document.getElementById('bgp_pg_rm_out').selectedIndex = 0;
        document.getElementById('bgp_pg_next_hop_self').checked = false;
        document.getElementById('bgp_pg_bfd').checked = false;
        const title = document.getElementById('bgp-peergroup-form-title');
        if (title) title.textContent = 'Add Peer Group';
    }

    // ── Peer Groups: edit ───────────────────────────────────────────────────
    document.querySelectorAll('.js-bgp-edit-peergroup').forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('bgp_peergroup_id').value = btn.dataset.id;
            document.getElementById('bgp_pg_name').value = btn.dataset.name;
            document.getElementById('bgp_pg_remote_as').value = btn.dataset.remoteAs;
            document.getElementById('bgp_pg_desc').value = btn.dataset.desc;
            document.getElementById('bgp_pg_rm_in').value = btn.dataset.rmIn;
            document.getElementById('bgp_pg_rm_out').value = btn.dataset.rmOut;
            document.getElementById('bgp_pg_next_hop_self').checked = (btn.dataset.nextHopSelf === '1');
            document.getElementById('bgp_pg_bfd').checked = (btn.dataset.bfd === '1');
            const title = document.getElementById('bgp-peergroup-form-title');
            if (title) title.textContent = 'Edit Peer Group';
            addPgForm.style.display = '';
            if (addPgOpen) addPgOpen.style.display = 'none';
        });
    });

    // ── Peer Groups: save (add or update) ───────────────────────────────────
    const savePgBtn = document.querySelector('[data-js="bgp-peergroup-save"]');
    if (savePgBtn) {
        savePgBtn.addEventListener('click', async () => {
            const id = document.getElementById('bgp_peergroup_id').value.trim();
            const name = document.getElementById('bgp_pg_name').value.trim();
            const remoteAs = document.getElementById('bgp_pg_remote_as').value.trim();
            if (!name) { showModal('<p>Name is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }
            if (!remoteAs) { showModal('<p>Remote AS is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }

            const data = {
                name: name,
                remote_as: remoteAs,
                description: document.getElementById('bgp_pg_desc').value.trim() || null,
                route_map_in: document.getElementById('bgp_pg_rm_in').value || null,
                route_map_out: document.getElementById('bgp_pg_rm_out').value || null,
                next_hop_self: document.getElementById('bgp_pg_next_hop_self').checked,
                bfd: document.getElementById('bgp_pg_bfd').checked,
            };
            const command = id ? 'routing_update_peer_group' : 'routing_add_peer_group';
            if (id) data.id = id;
            const title = id ? 'Update Peer Group' : 'Add Peer Group';

            try {
                const result = await apiClient.submit(command, data);
                showApiResult(result, { title: title, closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // ── Peer Groups: delete ─────────────────────────────────────────────────
    document.querySelectorAll('[data-js="bgp-delete-peergroup"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this peer group?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('routing_delete_peer_group', { id });
                        showApiResult(result, { title: 'Delete Peer Group', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message },
                            { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });
});
