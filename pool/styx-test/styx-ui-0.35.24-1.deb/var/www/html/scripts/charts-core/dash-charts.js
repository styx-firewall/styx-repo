// Switch logic for dash-charts.tpl.php
// Fully DOM-driven: discovers switches and chart blocks via naming convention.
// No hardcoded lists — adding a chart only requires adding its {id, label} entry in PHP.
document.addEventListener('DOMContentLoaded', async function() {
    const v = document.querySelector('meta[name="app-version"]')?.content || '0';
    const chartRefreshers = (await import('/scripts/charts/charts-index.js?v=' + v)).default;
    const STORAGE_KEY = 'dash-charts-switches';

    function loadSwitches() {
        try {
            var saved = localStorage.getItem(STORAGE_KEY);
            return saved ? JSON.parse(saved) : {};
        } catch (e) { return {}; }
    }

    function saveSwitches(state) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    }

    var savedState = loadSwitches();

    // Discover all chart switches from the DOM
    var switches = document.querySelectorAll('.chart-switch-box input[type="checkbox"]');

    switches.forEach(function(sw) {
        // switch-{kebab-id} → chartName (underscore), blockId, canvasId
        var kebabId = sw.id.replace('switch-', '');
        var chartName = kebabId.replace(/-/g, '_');
        var blockId = 'chart-' + kebabId + '-block';
        var canvasId = kebabId + '-chart';
        var block = document.getElementById(blockId);
        if (!block) return;

        sw.checked = !!savedState[sw.id];
        sw.addEventListener('change', function() {
            savedState[sw.id] = this.checked;
            saveSwitches(savedState);
            block.classList.toggle('hidden', !this.checked);
            if (this.checked && block.querySelector('canvas')) {
                // Clear previous timer before registering/refreshing
                if (window.chartConfigs && window.chartConfigs[chartName] && window.chartConfigs[chartName].timer) {
                    clearInterval(window.chartConfigs[chartName].timer);
                    window.chartConfigs[chartName].timer = null;
                }
                if (!window.charts || !window.charts[chartName]) {
                    var canvas = document.getElementById(canvasId);
                    if (canvas && canvas.parentElement) {
                        var gridItem = canvas.closest('.std-grid-item-type1');
                        if (gridItem) {
                            var selects = gridItem.querySelectorAll('select.range-select');
                            selects.forEach(function(sel) {
                                if (sel.id === 'range-selector-' + chartName) sel.remove();
                            });
                        }
                    }
                    if (chartRefreshers[chartName]) {
                        var defaultRange = (chartName === 'network_tx' || chartName === 'network_rx')
                            ? '5m'
                            : '15m';
                        window.registerChart(
                            chartName,
                            null,
                            chartRefreshers[chartName],
                            defaultRange
                        );
                    }
                } else if (window.chartConfigs && window.chartConfigs[chartName]) {
                    if (typeof window.startChartRefresh === 'function') window.startChartRefresh(chartName);
                }
            } else {
                if (window.chartConfigs && window.chartConfigs[chartName] && window.chartConfigs[chartName].timer) {
                    clearInterval(window.chartConfigs[chartName].timer);
                    window.chartConfigs[chartName].timer = null;
                }
            }
        });
        // Trigger chart load for initially-checked switches
        if (sw.checked) {
            sw.dispatchEvent(new Event('change'));
        }
    });
});
