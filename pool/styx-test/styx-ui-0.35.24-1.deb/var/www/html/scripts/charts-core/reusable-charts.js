// Reusable Chart.js helpers for dashboard and other pages
// Fallback CSS for all Chart.js canvases

if (typeof window !== 'undefined') {
    var style = document.createElement('style');
    style.innerHTML = (
        '.chartjs-canvas-responsive { width: 100% !important; min-height: 320px; ' +
        'height: 320px; display: block; }'
    );
    document.head.appendChild(style);
}

function makeSingleChart(canvasId, label, data, color, yOptions, customLabels, opts) {
    var labels = customLabels || ['-6m', '-5m', '-4m', '-3m', '-2m', '-1m', 'Now'];
    const canvas = document.getElementById(canvasId);
    if (!canvas || typeof Chart === 'undefined') return null;
    opts = opts || {};
    if (!opts.responsive) {
        canvas.width = canvas.parentElement.offsetWidth;
        canvas.classList.remove('chartjs-canvas-responsive');
    } else {
        canvas.classList.add('chartjs-canvas-responsive');
    }
    const ctx = canvas.getContext('2d');
    yOptions = yOptions || {};
    // Build options for the Y axis
    var yScale = {
        beginAtZero: yOptions.beginAtZero !== false,
        ticks: {
            color: '#fff',
            font: { size: 12 },
            autoSkip: false
        },
        grid: { color: '#444' }
    };
    if (typeof yOptions.min !== 'undefined') yScale.min = yOptions.min;
    if (typeof yOptions.max !== 'undefined') yScale.max = yOptions.max;
    if (typeof yOptions.stepSize !== 'undefined') yScale.ticks.stepSize = yOptions.stepSize;
    if (yOptions.ticks) Object.assign(yScale.ticks, yOptions.ticks);
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: data,
                borderColor: color,
                backgroundColor: color.replace('1)', '0.2)'),
                fill: true,
                tension: 0.2
            }]
        },
        options: {
            responsive: !!opts.responsive,
            maintainAspectRatio: !!opts.responsive,
            plugins: {
                legend: { labels: { color: '#fff', font: { size: 12 } }, display: false },
                title: { color: '#fff' }
            },
            scales: {
                x: { ticks: { color: '#fff', font: { size: 12 } }, grid: { color: '#444' } },
                y: yScale
            }
        }
    });
}

function makeMultilineChart(canvasId, labels, ifaces, data, colors, opts) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || typeof Chart === 'undefined') return null;
    opts = opts || {};
    if (!opts.responsive) {
        canvas.width = canvas.parentElement.offsetWidth;
        canvas.classList.remove('chartjs-canvas-responsive');
    } else {
        canvas.classList.add('chartjs-canvas-responsive');
    }
    const ctx = canvas.getContext('2d');
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: ifaces.map(function(iface, idx) {
                return {
                    label: iface,
                    data: data[idx],
                    borderColor: colors[idx % colors.length],
                    backgroundColor: colors[idx % colors.length].replace('1)', '0.2)'),
                    fill: false,
                    tension: 0.2
                };
            })
        },
        options: {
            responsive: !!opts.responsive,
            maintainAspectRatio: !!opts.responsive,
            plugins: {
                legend: { labels: { color: '#fff', font: { size: 12 } }, display: true },
                title: { color: '#fff' }
            },
            scales: {
                x: { ticks: { color: '#fff', font: { size: 12 } }, grid: { color: '#444' } },
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#fff',
                        font: { size: 12 },
                        autoSkip: false
                    },
                    grid: { color: '#444' }
                }
            }
        }
    });
}

// Duration of each display bucket in seconds for a given range.
// Produces ~30 output points per range, stable regardless of rolling-window shifts.
function getBucketSecForRange(range) {
    switch(range) {
        case '24h': return 48 * 60;  // 48 min → ~30 pts
        case '12h': return 24 * 60;  // 24 min → 30 pts
        case '6h':  return 12 * 60;  // 12 min → 30 pts
        case '1h':  return 2 * 60;   //  2 min → 30 pts
        case '30m': return 60;        //  1 min → 30 pts
        case '15m': return 30;        // 30 sec → 30 pts
        case '5m':  return 10;        // 10 sec → 30 pts
        default:    return 60;
    }
}

// Bucket metric data into fixed time-windows before rendering.
// Aggregation uses MAX to preserve peaks.
// Handles two formats:
//   Format A (cpu/iowait/memory): data.metrics = [{timestamp, value_key...}]
//   Format B (network tx/rx):    data.labels = [ISO...], data.ifaces = [...], data.metrics = {iface: [numbers]}
function normalizeAndBucketData(data, range) {
    if (!data || typeof data !== 'object') return data;
    var bucketSec = getBucketSecForRange(range);

    function bucketKey(isoTs) {
        var d = new Date(isoTs);
        if (isNaN(d.getTime())) return null;
        return new Date(Math.floor(Math.floor(d.getTime() / 1000) / bucketSec) * bucketSec * 1000).toISOString();
    }

    // Format B: labels + ifaces + metrics object
    if (Array.isArray(data.labels) && Array.isArray(data.ifaces) && data.metrics && !Array.isArray(data.metrics)) {
        var ifaces = data.ifaces;
        var buckets = {};
        data.labels.forEach(function(ts, i) {
            var k = bucketKey(ts);
            if (!k) return;
            if (!buckets[k]) {
                buckets[k] = {};
                ifaces.forEach(function(iface) { buckets[k][iface] = []; });
            }
            ifaces.forEach(function(iface) {
                var arr = data.metrics[iface];
                if (arr && typeof arr[i] === 'number') buckets[k][iface].push(arr[i]);
            });
        });
        var sortedKeys = Object.keys(buckets).sort();
        var newMetrics = {};
        ifaces.forEach(function(iface) { newMetrics[iface] = []; });
        sortedKeys.forEach(function(k) {
            ifaces.forEach(function(iface) {
                var vals = buckets[k][iface];
                newMetrics[iface].push(vals.length > 0 ? Math.max.apply(null, vals) : 0);
            });
        });
        data.labels = sortedKeys;
        data.metrics = newMetrics;
        return data;
    }

    // Format A: metrics is array of objects with `timestamp`
    if (Array.isArray(data.metrics) && data.metrics.length > 0 && data.metrics[0] && data.metrics[0].timestamp) {
        var fields = Object.keys(data.metrics[0]).filter(function(f) { return f !== 'timestamp'; });
        var buckets = {};
        data.metrics.forEach(function(item) {
            if (!item || !item.timestamp) return;
            var k = bucketKey(item.timestamp);
            if (!k) return;
            if (!buckets[k]) {
                buckets[k] = { timestamp: k };
                fields.forEach(function(f) { buckets[k][f + '_vals'] = []; });
            }
            fields.forEach(function(f) {
                var v = Number(item[f]);
                if (!isNaN(v)) buckets[k][f + '_vals'].push(v);
            });
        });
        var sortedKeys = Object.keys(buckets).sort();
        data.metrics = sortedKeys.map(function(k) {
            var out = { timestamp: k };
            fields.forEach(function(f) {
                var vals = buckets[k][f + '_vals'];
                out[f] = vals.length > 0 ? Math.max.apply(null, vals) : 0;
            });
            return out;
        });
        data.labels = sortedKeys;
        return data;
    }

    return data;
}

// Return interval in ms according to the selected range
function getIntervalMs(range) {
    switch(range) {
        case '24h': return 8 * 60 * 1000; // 8 min
        case '12h': return 4 * 60 * 1000; // 4 min
        case '6h': return 2 * 60 * 1000; // 2 min
        case '1h': return 60 * 1000; // 1 min
        case '30m': return 30 * 1000; // 30 sec
        case '15m': return 15 * 1000; // 15 sec
        case '5m': return 5 * 1000; // 5 sec
        default: return 60 * 1000;
    }
}

// Generic fetch to update charts
function fetchAndUpdateChart(metric, range, updateFn, extraParams) {
    var payload = {
        action: 'metrics',
        metric: metric,
        range: range
    };
    if (extraParams) {
        Object.keys(extraParams).forEach(function(k) {
            payload[k] = extraParams[k];
        });
    }
    apiClient.request('metrics', payload)
        .then(function(resp) {
            if (Array.isArray(resp)) {
                var found = resp.find(r => r && r.status === 'success');
                if (found) {
                    updateFn(normalizeAndBucketData(found.result || {}, range));
                }
            } else if (resp && resp.status === 'success') {
                updateFn(normalizeAndBucketData(resp.result || {}, range));
            } else {
                appLog('Error fetching chart data:', resp);
            }
        })
        .catch(function(err) {
            appLog('Chart fetch/render error:', err);
        });
}

// Format time labels to HH:MM or HH:MM:SS.
// Shows seconds when adjacent labels are less than 60 s apart (sub-minute buckets).
function formatShortTimeLabels(labels) {
    var includeSeconds = false;
    if (Array.isArray(labels) && labels.length >= 2) {
        try {
            var gap = Math.abs(new Date(labels[1]).getTime() - new Date(labels[0]).getTime());
            if (!isNaN(gap) && gap < 60000) includeSeconds = true;
        } catch (e) {}
    }
    return labels.map(function(ts) {
        try {
            if (window.dateUtils && typeof window.dateUtils.getUserTz === 'function') {
                var tz = window.dateUtils.getUserTz();
                var locale = (window.dateUtils && typeof window.dateUtils.getUserLocale === 'function') ? window.dateUtils.getUserLocale() : undefined;
                var d = new Date(ts);
                if (!isNaN(d.getTime())) {
                    try {
                        var fmtOpts = { timeZone: tz, hour: '2-digit', minute: '2-digit', hour12: false };
                        if (includeSeconds) fmtOpts.second = '2-digit';
                        return new Intl.DateTimeFormat(locale || undefined, fmtOpts).format(d);
                    } catch (e) {}
                }
            }
        } catch (e) {}
        var m = ts.match(/T(\d{2}:\d{2}:\d{2})/);
        if (m) return includeSeconds ? m[1] : m[1].slice(0, 5);
        return ts;
    });
}

// Dynamic color generator for interfaces
function generateColors(n) {
    var colors = [];
    for (var i = 0; i < n; i++) {
        var hue = Math.round((360 / n) * i);
        colors.push('hsl(' + hue + ', 70%, 55%)');
    }
    return colors;
}

// Downsampling: average the data in blocks of size blockSize
function downsampleAvg(arr, blockSize) {
    if (blockSize <= 1) return arr;
    var result = [];
    for (var i = 0; i < arr.length; i += blockSize) {
        var block = arr.slice(i, i + blockSize);
        var avg = block.reduce((a, b) => a + b, 0) / block.length;
        result.push(avg);
    }
    return result;
}
// Downsampling for labels (pick the first label from each block)
function downsampleLabels(labels, blockSize) {
    if (blockSize <= 1) return labels;
    var result = [];
    for (var i = 0; i < labels.length; i += blockSize) {
        result.push(labels[i]);
    }
    return result;
}
// Time-based bucketing is handled by normalizeAndBucketData before updateFn is called.
// No further position-based downsampling is needed.
function getBlockSizeForRange(range) {
    return 1;
}

// --- Chart registration and refresh logic (reusable) ---
window.charts = window.charts || {};
window.chartConfigs = window.chartConfigs || {};

window.registerChart = function(name, chart, refreshFn, defaultRange, selectorOptions) {
    window.charts[name] = chart;
    window.chartConfigs[name] = {
        refreshFn: refreshFn,
        range: defaultRange || '1h',
        timer: null
    };
    setupRangeSelector(Object.assign({
        name: name,
        onChange: function(range) {
            window.chartConfigs[name].range = range;
            startChartRefresh(name);
        }
    }, selectorOptions || {}));
    startChartRefresh(name);
};

/**
 * Create a reusable range selector.
 * @param {Object} opts
 *   - name: logical name of the chart (required)
 *   - rangeOptions: array of options {label, value} (optional)
 *   - canvasIdMap: mapping from logical name to canvas id (optional)
 *   - onChange: callback when the range changes, receives the new value (optional)
 */
function setupRangeSelector(opts) {
    var name = opts.name;
    var rangeOptions = opts.rangeOptions || [
        { label: '24h', value: '24h' },
        { label: '12h', value: '12h' },
        { label: '6h', value: '6h' },
        { label: '1h', value: '1h' },
        { label: '30m', value: '30m' },
        { label: '15m', value: '15m' },
        { label: '5m', value: '5m' }
    ];
    // Remove previous selector if exists
    var oldSelector = document.getElementById('range-selector-' + name);
    if (oldSelector && oldSelector.parentElement) {
        oldSelector.parentElement.removeChild(oldSelector);
    }
    var selector = document.createElement('select');
    selector.id = 'range-selector-' + name;
    selector.className = 'range-select';
    rangeOptions.forEach(function(opt) {
        var o = document.createElement('option');
        o.value = opt.value;
        o.textContent = opt.label;
        selector.appendChild(o);
    });
    selector.value = (
        (window.chartConfigs && window.chartConfigs[name] && window.chartConfigs[name].range)
        || rangeOptions[0].value
    );
    // Fallback: always use the standard pattern for canvasId
    var canvasId = (name.replace(/_/g, '-') + '-chart');
    var chartCanvas = document.getElementById(canvasId);
    if (chartCanvas && chartCanvas.parentElement) {
        chartCanvas.parentElement.insertBefore(selector, chartCanvas);
    }
    selector.addEventListener('change', function() {
        if (typeof opts.onChange === 'function') {
            opts.onChange(selector.value);
        }
    });
}

// Expose
window.setupRangeSelector = setupRangeSelector;

window.startChartRefresh = function(name) {
    var config = window.chartConfigs[name];
    if (config.timer) clearInterval(config.timer);
    config.refreshFn(config.range);
    config.timer = setInterval(function() { config.refreshFn(config.range); }, getIntervalMs(config.range));
};
