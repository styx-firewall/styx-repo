window.addEventListener('load', function() {
    var chartSetups = [
        function() {
            window.registerChart('cpu', null, function(range) {
                fetchAndUpdateChart('cpu', range, function(data) {
                    var metrics = data.metrics || [];
                    var labels = metrics.map(m => m.timestamp);
                    var values = metrics.map(m => m.cpu_usage);
                    var blockSize = getBlockSizeForRange(range);
                    var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
                    var dsValues = downsampleAvg(values, blockSize);
                    if (!window.charts['cpu']) {
                        window.charts['cpu'] = makeSingleChart('cpu-chart', 'CPU %', dsValues, 'rgba(42,122,226,1)', {min:0, max:100, stepSize:20}, dsLabels);
                    } else {
                        var chart = window.charts['cpu'];
                        chart.data.labels = dsLabels;
                        chart.data.datasets[0].data = dsValues;
                        chart.update();
                    }
                });
            }, '15m');
        },
        function() {
            window.registerChart('memory', null, function(range) {
                fetchAndUpdateChart('memory', range, function(data) {
                    var metrics = data.metrics || [];
                    var labels = metrics.map(m => m.timestamp);
                    var values = metrics.map(m => m.memory_usage);
                    var blockSize = getBlockSizeForRange(range);
                    var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
                    var dsValues = downsampleAvg(values, blockSize);
                    if (!window.charts['memory']) {
                        window.charts['memory'] = makeSingleChart('memory-chart', 'Memory %', dsValues, 'rgba(76,175,80,1)', {min:0, max:100, stepSize:20}, dsLabels);
                    } else {
                        var chart = window.charts['memory'];
                        chart.data.labels = dsLabels;
                        chart.data.datasets[0].data = dsValues;
                        chart.update();
                    }
                });
            }, '15m');
        },
        function() {
            window.registerChart('network_tx', null, function(range) {
                fetchAndUpdateChart('network_tx', range, function(data) {
                    var shortLabels = formatShortTimeLabels(data.labels);
                    var allIfaces = data.ifaces;
                    var txDataRaw = allIfaces.map(function(iface) { return data.metrics[iface]; });
                    var flat = txDataRaw.flat();
                    var max = Math.max.apply(null, flat);
                    var scale = 1, unit = 'B/s';
                    if (max >= 1_000_000) { scale = 1_000_000; unit = 'MB/s'; }
                    else if (max >= 1_000) { scale = 1_000; unit = 'KB/s'; }
                    var txData = txDataRaw.map(arr => arr.map(v => v/scale));
                    var blockSize = getBlockSizeForRange(range);
                    var dsLabels = downsampleLabels(shortLabels, blockSize);
                    var dsTxData = txData.map(arr => downsampleAvg(arr, blockSize));
                    var dynColors = generateColors(allIfaces.length);
                    var chart = window.charts['network_tx'];
                    if (!chart || chart.data.datasets.length !== allIfaces.length) {
                        if (chart) chart.destroy();
                        window.charts['network_tx'] = makeMultilineChart('network-tx-chart', dsLabels, allIfaces, dsTxData, dynColors);
                    } else {
                        chart.data.labels = dsLabels;
                        chart.data.datasets.forEach(function(ds, idx) {
                            ds.data = dsTxData[idx];
                            ds.label = allIfaces[idx];
                            ds.borderColor = dynColors[idx % dynColors.length];
                            ds.backgroundColor = dynColors[idx % dynColors.length].replace('1)', '0.2)');
                        });
                        chart.update();
                    }
                    var titleElem = document.querySelector('h3:has(+ #network-tx-chart), h3:has(+ canvas#network-tx-chart)');
                    if (!titleElem) {
                        titleElem = Array.from(document.querySelectorAll('h3')).find(h => h.textContent.trim().toLowerCase().startsWith('network tx'));
                    }
                    if (titleElem) titleElem.textContent = 'Network TX (' + unit + ')';
                });
            }, '5m');
        },
        function() {
            window.registerChart('network_rx', null, function(range) {
                fetchAndUpdateChart('network_rx', range, function(data) {
                    var shortLabels = formatShortTimeLabels(data.labels);
                    var allIfaces = data.ifaces;
                    var rxDataRaw = allIfaces.map(function(iface) { return data.metrics[iface]; });
                    var flat = rxDataRaw.flat();
                    var max = Math.max.apply(null, flat);
                    var scale = 1, unit = 'B/s';
                    if (max >= 1_000_000) { scale = 1_000_000; unit = 'MB/s'; }
                    else if (max >= 1_000) { scale = 1_000; unit = 'KB/s'; }
                    var rxData = rxDataRaw.map(arr => arr.map(v => v/scale));
                    var blockSize = getBlockSizeForRange(range);
                    var dsLabels = downsampleLabels(shortLabels, blockSize);
                    var dsRxData = rxData.map(arr => downsampleAvg(arr, blockSize));
                    var dynColors = generateColors(allIfaces.length);
                    var chart = window.charts['network_rx'];
                    if (!chart || chart.data.datasets.length !== allIfaces.length) {
                        if (chart) chart.destroy();
                        window.charts['network_rx'] = makeMultilineChart('network-rx-chart', dsLabels, allIfaces, dsRxData, dynColors);
                    } else {
                        chart.data.labels = dsLabels;
                        chart.data.datasets.forEach(function(ds, idx) {
                            ds.data = dsRxData[idx];
                            ds.label = allIfaces[idx];
                            ds.borderColor = dynColors[idx % dynColors.length];
                            ds.backgroundColor = dynColors[idx % dynColors.length].replace('1)', '0.2)');
                        });
                        chart.update();
                    }
                    var titleElem = document.querySelector('h3:has(+ #network-rx-chart), h3:has(+ canvas#network-rx-chart)');
                    if (!titleElem) {
                        titleElem = Array.from(document.querySelectorAll('h3')).find(h => h.textContent.trim().toLowerCase().startsWith('network rx'));
                    }
                    if (titleElem) titleElem.textContent = 'Network RX (' + unit + ')';
                });
            }, '5m');
        }
    ];
    // Format technical watcher names to human-readable labels
    function formatWatchdogName(name) {
        return name.split('_').map(function(word) {
            return word.charAt(0).toUpperCase() + word.slice(1);
        }).join(' ');
    }

    // Watchdog panel — fetch watchers and render status
    function fetchWatchdog() {
        apiClient.request('styx_get_watchers', {})
            .then(function(resp) {
                var container = document.getElementById('watchdog-content');
                if (!container) return;
                if (!resp || resp.status !== 'success') {
                    container.innerHTML = '<div class="std-flex-row"><div class="std-flex-col" style="text-align:center;padding:20px;color:var(--danger-color);">Error loading watchdog data</div></div>';
                    return;
                }
                var watchers = (resp.result && resp.result.watchers) ? resp.result.watchers : [];
                if (watchers.length === 0) {
                    container.innerHTML = '<div class="std-flex-row"><div class="std-flex-col" style="text-align:center;padding:20px;">No watchers configured</div></div>';
                    return;
                }
                var html = '';
                watchers.forEach(function(w) {
                    var ok = (w.status === 'ok');
                    var badgeClass = ok ? 'std-badge--success' : 'std-badge--danger';
                    var label = ok ? 'Active' : 'Inactive';
                    html += '<div class="std-flex-row watchdog-row">';
                    html += '<div class="std-flex-col" style="flex:1;font-weight:500;">' + formatWatchdogName(w.name) + '</div>';
                    html += '<div class="std-flex-col" style="flex:0 0 auto;text-align:right;">';
                    html += '<span class="std-badge ' + badgeClass + '" style="min-width:72px;text-align:center;">' + label + '</span>';
                    html += '</div>';
                    html += '</div>';
                });
                container.innerHTML = html;
            })
            .catch(function(err) {
                var container = document.getElementById('watchdog-content');
                if (container) {
                    container.innerHTML = '<div class="std-flex-row"><div class="std-flex-col" style="text-align:center;padding:20px;color:var(--danger-color);">Error fetching watchdog data</div></div>';
                }
            });
    }

    // Fetch watchdog immediately and then every 30 seconds
    fetchWatchdog();
    setInterval(fetchWatchdog, 30000);

    chartSetups.forEach(function(setup, i) {
        setTimeout(setup, (i+1) * 500);
    });
});

