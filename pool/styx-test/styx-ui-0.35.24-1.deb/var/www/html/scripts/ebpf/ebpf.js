/**
 * eBPF Module Management — Interactive Logic
 *
 * Module list table is rendered by PHP. JS handles:
 * - Row clicks → detail panel with API-driven content
 * - Search/filter, modals, control map CRUD, telemetry polling, events
 */
(function () {
    'use strict';

    // ═══════════════════════════════════════════════════════════════════
    // DOM
    // ═══════════════════════════════════════════════════════════════════
    var searchInput       = document.getElementById('ebpf-search');
    var refreshBtn        = document.getElementById('ebpf-refresh-btn');
    var backBtn           = document.getElementById('ebpf-back-btn');
    var detailPanel       = document.getElementById('ebpf-detail-panel');
    var listView          = document.getElementById('ebpf-list-view');
    var kernelSections    = document.querySelectorAll('.ebpf-collapsible-section');
    var detailHeader      = document.getElementById('ebpf-detail-header');
    var detailActions     = document.getElementById('ebpf-detail-actions');
    var overviewContent   = document.getElementById('ebpf-overview-content');
    var controlMapsContent = document.getElementById('ebpf-control-maps-content');
    var telemetryContent  = document.getElementById('ebpf-telemetry-content');
    var eventsTbody       = document.querySelector('#ebpf-events-table tbody');
    var eventsPauseBtn    = document.getElementById('ebpf-events-pause-btn');
    var eventsClearBtn    = document.getElementById('ebpf-events-clear-btn');
    var eventsAutoScroll  = document.getElementById('ebpf-events-autoscroll');

    // ═══════════════════════════════════════════════════════════════════
    // STATE
    // ═══════════════════════════════════════════════════════════════════
    var activeInstanceId = null;
    var activeModule     = null;
    var activeDetail     = null;
    var activeMeta       = null;
    var telemetryData    = {};
    var controlMapEntries = {};
    var telemetryInterval = null;
    var eventPollInterval = null;
    var eventsPaused = false;
    var autoScroll = true;
    var seenEvents = {};  // dedup: "ts-event-srcip" → true
    var lastTelemetryValues = {}; // field → last value for change detection

    // ═══════════════════════════════════════════════════════════════════
    // UTILITY
    // ═══════════════════════════════════════════════════════════════════

    function el(tag, attrs, children) {
        var e = document.createElement(tag);
        if (attrs) {
            Object.keys(attrs).forEach(function (k) {
                if (k === 'className') e.className = attrs[k];
                else if (k === 'dataset') { for (var d in attrs[k]) e.dataset[d] = attrs[k][d]; }
                else if (k.substr(0, 2) === 'on') e.addEventListener(k.substr(2).toLowerCase(), attrs[k]);
                else e.setAttribute(k, attrs[k]);
            });
        }
        (children || []).forEach(function (c) {
            if (c == null) return;
            e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
        });
        return e;
    }

    function showToast(msg, type) {
        var t = el('div', { id: 'ebpf-toast', className: 'ebpf-toast ebpf-toast--' + (type || 'success') }, [msg]);
        var pc = document.querySelector('.page-content');
        if (pc) pc.appendChild(t);
        setTimeout(function () { t.classList.add('ebpf-toast--fade'); }, 3000);
        setTimeout(function () { if (t.parentNode) t.remove(); }, 3500);
    }

    function formatUnit(value, unit) {
        if (value === null || value === undefined) return '—';
        switch (unit) {
        case 'count': return Number(value).toLocaleString();
        case 'bytes':
            var n = Number(value);
            if (n >= 1e9) return (n / 1e9).toFixed(1) + ' GB';
            if (n >= 1e6) return (n / 1e6).toFixed(1) + ' MB';
            if (n >= 1e3) return (n / 1e3).toFixed(1) + ' KB';
            return n + ' B';
        case 'ns':
            var ns = Number(value), msAgo = Date.now() - (ns / 1e6);
            if (msAgo < 1000) return 'just now';
            if (msAgo < 60000) return Math.round(msAgo / 1000) + 's ago';
            if (msAgo < 3600000) return Math.round(msAgo / 60000) + 'm ago';
            return Math.round(msAgo / 3600000) + 'h ago';
        case 'epoch':
            var sAgo = (Date.now() / 1000) - Number(value);
            if (sAgo <= 0) return 'just now';
            if (sAgo < 60) return Math.round(sAgo) + 's ago';
            if (sAgo < 3600) return Math.round(sAgo / 60) + 'm ago';
            if (sAgo < 86400) return Math.round(sAgo / 3600) + 'h ago';
            return Math.round(sAgo / 86400) + 'd ago';
        case 'ipv4':
            var v = Number(value);
            return ((v >>> 24) & 0xFF) + '.' + ((v >>> 16) & 0xFF) + '.' + ((v >>> 8) & 0xFF) + '.' + (v & 0xFF);
        default: return String(value);
        }
    }

    function formatMapEntry(entry) {
        if (typeof entry === 'string') return entry;
        if (!entry || typeof entry !== 'object') return String(entry);
        var key = formatKey(entry);
        var val = entry.value !== undefined ? entry.value : null;
        if (typeof val === 'object' && val !== null) {
            val = Object.entries(val).map(function (e) { return e[0] + ': ' + e[1]; }).join(', ');
        }
        return val !== null && val !== key ? String(key) + ' → ' + String(val) : String(key);
    }

    function formatKey(entry) {
        var key = (entry && typeof entry === 'object') ? (entry.key !== undefined ? entry.key : entry.value) : entry;
        if (typeof key === 'object' && key !== null) {
            var kk = Object.keys(key);
            key = kk.length === 1 ? key[kk[0]] : JSON.stringify(key);
        }
        return String(key !== undefined && key !== null ? key : '');
    }

    function formatValue(val) {
        if (typeof val === 'object' && val !== null) {
            return Object.entries(val).map(function (e) { return e[0] + ': ' + e[1]; }).join(', ');
        }
        return String(val !== undefined ? val : '');
    }

    function statusBadge(status) {
        var map = { loaded: 'ebpf-status-loaded', suspended: 'ebpf-status-suspended', inactive: 'ebpf-status-inactive',
            available: 'ebpf-status-available', incompatible: 'ebpf-status-incompatible', error: 'ebpf-status-error' };
        var labels = { loaded: '● Loaded', suspended: '◐ Suspended', inactive: '○ Inactive',
            available: '○ Available', incompatible: '✗ Incompatible', error: '⚠ Error' };
        return '<span class="ebpf-status-badge ' + (map[status] || '') + '">' + (labels[status] || status) + '</span>';
    }

    // ═══════════════════════════════════════════════════════════════════
    // MODULE LIST: SEARCH / FILTER
    // ═══════════════════════════════════════════════════════════════════

    function filterRows(term) {
        var t = (term || '').toLowerCase();
        document.querySelectorAll('#ebpf-module-list tbody tr.ebpf-module-row').forEach(function (tr) {
            var txt = (tr.textContent || '').toLowerCase();
            tr.style.display = (t && !txt.includes(t)) ? 'none' : '';
        });
    }

    // ═══════════════════════════════════════════════════════════════════
    // ROW CLICKS → DELEGATED
    // ═══════════════════════════════════════════════════════════════════

    document.getElementById('ebpf-module-list').addEventListener('click', function (e) {
        // Activate/Reactivate button (inactive/suspended instances)
        var actBtn = e.target.closest('.ebpf-activate-btn-js');
        if (actBtn) {
            e.stopPropagation();
            var uuid = actBtn.dataset.uuid;
            if (uuid) {
                apiClient.submit('ebpf_load_module', { module: uuid }).then(function (r) {
                    if (r.status === 'success') { showToast(r.response_msg || 'Activated', 'success'); refreshList(); }
                    else showToast(r.response_msg || 'Activation failed', 'error');
                }).catch(function (err) { showToast('Network error: ' + err.message, 'error'); });
            }
            return;
        }
        // Info button
        var infoBtn = e.target.closest('.ebpf-info-btn');
        if (infoBtn) {
            e.stopPropagation();
            selectModule(infoBtn.dataset.identifier, infoBtn.dataset.isInstance === '1');
            return;
        }
        // Load button (available modules)
        var loadBtn = e.target.closest('.ebpf-load-btn-js');
        if (loadBtn) {
            e.stopPropagation();
            var tr = loadBtn.closest('tr');
            if (tr) openLoadModal(tr);
            return;
        }
        // Row click → select
        var row = e.target.closest('tr.ebpf-module-row');
        if (row) {
            selectModule(row.dataset.instanceId || row.dataset.module, !!row.dataset.instanceId);
        }
    });

    // Autoload toggle — delegated
    document.getElementById('ebpf-module-list').addEventListener('change', function (e) {
        if (e.target.classList.contains('ebpf-autoload-toggle')) {
            toggleAutoload(e.target.dataset.uuid, e.target.checked);
        }
    });

    // Collapsible sections
    document.querySelectorAll('.ebpf-collapse-toggle').forEach(function (t) {
        t.addEventListener('click', function () {
            var body = document.getElementById(this.dataset.target);
            if (body) {
                body.classList.toggle('hidden');
                var a = this.querySelector('.ebpf-collapse-arrow');
                if (a) a.textContent = body.classList.contains('hidden') ? '▼' : '▲';
            }
        });
    });

    // ═══════════════════════════════════════════════════════════════════
    // SELECT MODULE → DETAIL PANEL
    // ═══════════════════════════════════════════════════════════════════

    /** Read module metadata from a table row's dataset */
    function metaFromRow(tr) {
        if (!tr) return null;
        var ds = tr.dataset;
        var params = [];
        try { params = JSON.parse(ds.preAttachParams || '[]'); } catch (e) { /* keep [] */ }
        return {
            name: ds.module || '',
            instance_id: ds.instanceId || null,
            status: ds.status || '',
            attach_target: ds.attachTarget || 'interface',
            version: ds.version || '',
            hook_type: ds.hookType || '',
            interface: ds.interface || '',
            mode: ds.mode || '',
            pre_attach_params: params,
        };
    }

    function selectModule(identifier, isInstance) {
        // Read metadata from the specific row that was clicked (no DOM search)
        var sel = isInstance
            ? 'tr.ebpf-module-row[data-instance-id="' + identifier + '"]'
            : 'tr.ebpf-module-row[data-instance-id=""][data-module="' + identifier + '"]';
        var tr = document.querySelector(sel);
        if (!tr) return;

        var meta = metaFromRow(tr);
        if (!meta) return;
        var isInst = !!tr.dataset.instanceId;
        activeInstanceId = isInst ? meta.instance_id : null;
        activeModule = meta.name;
        activeMeta = meta;
        activeDetail = null;
        telemetryData = {};
        controlMapEntries = {};
        seenEvents = {};

        var lookupId = activeInstanceId || activeModule;

        apiClient.request('ebpf_get_module_info', { module: lookupId }).then(function (resp) {
            if (resp.status === 'success' || resp.status === 'partial') {
                activeDetail = resp.result || resp;
                // Seed control map entries from module-info pre-populated data
                (activeDetail.control_maps || []).forEach(function (cm) {
                    if (cm.entries && cm.entries.length) {
                        controlMapEntries[cm.name] = cm.entries;
                    }
                });
                listView.classList.add('hidden');
                kernelSections.forEach(function (s) { s.classList.add('hidden'); });
                detailPanel.classList.remove('hidden');
                stopAllPolling();
                renderDetailHeader();
                renderOverview();
                renderControlMaps();
                renderTelemetry();
                renderEvents();
                switchTab('ebpf-tab-overview');
            } else {
                showToast(resp.response_msg || 'Failed to load module info', 'error');
            }
        }).catch(function (err) {
            showToast('Network error: ' + err.message, 'error');
        });
    }

    function backToList() {
        stopAllPolling();
        activeInstanceId = null; activeModule = null; activeDetail = null; activeMeta = null;
        detailPanel.classList.add('hidden');
        listView.classList.remove('hidden');
        kernelSections.forEach(function (s) { s.classList.remove('hidden'); });
    }

    function renderDetailHeader() {
        var m = activeMeta, d = activeDetail || {};
        detailHeader.innerHTML = '';
        var h2 = el('h2', { className: 'ebpf-detail-title' });
        h2.innerHTML = (d.name || m.name) + ' <span class="ebpf-version-tag">v' + (d.version || m.version || '') + '</span> '
            + statusBadge(m.status);
        if (activeInstanceId) {
            h2.innerHTML += ' <span class="ebpf-uuid ebpf-uuid--large" title="' + activeInstanceId + '">UUID: '
                + activeInstanceId.slice(0, 8) + '...' + activeInstanceId.slice(-4) + '</span>';
        }
        detailHeader.appendChild(h2);
        if (d.description) detailHeader.appendChild(el('p', { className: 'ebpf-detail-desc' }, [d.description]));

        detailActions.innerHTML = '';
        if (m.status === 'loaded') {
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-unload', onClick: function () { handleUnload(false); } }, ['Unload']));
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-suspend', onClick: function () { handleUnload(true); } }, ['Suspend']));
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-reload', onClick: handleReload }, ['Reload']));
        } else if (m.status === 'suspended') {
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-load', onClick: function () { reactivateInstance(m); } }, ['Reactivate']));
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-unload', onClick: function () { handleUnload(false); } }, ['Unload']));
        } else if (m.status === 'inactive') {
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-load', onClick: function () { reactivateInstance(m); } }, ['Activate']));
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-unload', onClick: function () { handleUnload(false); } }, ['Unload']));
        } else if (m.status === 'available') {
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-load', onClick: function () { openLoadModalFromMeta(m); } }, ['Load']));
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    // TABS
    // ═══════════════════════════════════════════════════════════════════

    function switchTab(tabId) {
        document.querySelectorAll('#ebpf-detail-tabs .std-tab-btn').forEach(function (b) { b.classList.remove('active'); });
        document.querySelectorAll('#ebpf-detail-tab-panels .std-tab-panel').forEach(function (p) { p.classList.remove('active'); });
        var btn = document.querySelector('[data-tab="' + tabId + '"]');
        if (btn) btn.classList.add('active');
        var panel = document.getElementById('tab-' + tabId);
        if (panel) panel.classList.add('active');

        stopAllPolling();
        if (tabId === 'ebpf-tab-control-maps') fetchControlMaps();
        if (tabId === 'ebpf-tab-telemetry') { fetchTelemetry(); startTelemetryPolling(); }
        if (tabId === 'ebpf-tab-events') startEventPolling();
    }

    document.getElementById('ebpf-detail-tabs').addEventListener('click', function (e) {
        var btn = e.target.closest('.std-tab-btn');
        if (!btn || !btn.dataset.tab) return;
        e.preventDefault();
        switchTab(btn.dataset.tab);
    });

    // ═══════════════════════════════════════════════════════════════════
    // OVERVIEW
    // ═══════════════════════════════════════════════════════════════════

    function renderOverview() {
        var d = activeDetail || {}, m = activeMeta || {};
        overviewContent.innerHTML = '';

        var rows = [
            ['Name', d.name || m.name], ['Version', d.version || m.version || '—'],
            ['Instance UUID', activeInstanceId || '—'], ['Author', d.author || '—'],
            ['Hook Type', d.hook_type || m.hook_type || '—'], ['Interface', d.interface || m.interface || '—'],
            ['BPF Function', d.bpf_fn_name || '—'], ['Companion', d.companion || '—'],
            ['Kernel Required', d.requires_kernel ? '≥ ' + d.requires_kernel : '—'],
            ['Priority', String(d.priority !== undefined ? d.priority : '—')],
            ['Tags', (d.tags || m.tags || []).join(', ') || '—'],
            ['Mode', d.mode || m.mode || '—'], ['Status', m.status || d.status || '—'],
            ['Loaded At', m.loaded_at ? new Date(m.loaded_at * 1000).toLocaleString() : '—'],
            ['Control Maps', d.control_maps ? String(d.control_maps.length) : '0'],
            ['Telemetry Maps', d.telemetry_maps ? String(d.telemetry_maps.length) : '0'],
            ['Events', d.events ? String(d.events.length) : '0'],
        ];

        var dl = el('dl', { className: 'ebpf-details-list' });
        rows.forEach(function (p) { dl.appendChild(el('dt', null, [p[0]])); dl.appendChild(el('dd', null, [p[1]])); });
        overviewContent.appendChild(dl);

        // Usage section
        var usage = d.usage || m.usage || '';
        if (usage) {
            var sec = el('div', { className: 'ebpf-usage-section' });
            var toggle = el('div', { className: 'ebpf-usage-toggle', onClick: function () {
                var b = this.nextElementSibling, a = this.querySelector('.ebpf-usage-arrow');
                b.classList.toggle('hidden');
                if (a) a.textContent = b.classList.contains('hidden') ? '▶' : '▼';
            } });
            toggle.innerHTML = '<span class="ebpf-usage-arrow">▶</span> Usage';
            sec.appendChild(toggle);
            var body = el('div', { className: 'ebpf-usage-body hidden' });
            body.innerHTML = formatUsageHtml(usage);
            sec.appendChild(body);
            overviewContent.appendChild(sec);
        }
    }

    function formatUsageHtml(text) {
        var escaped = text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
        var lines = escaped.split('\n'), out = [], inList = false;
        lines.forEach(function (line) {
            if (/^### /.test(line)) { if (inList) { out.push('</ul>'); inList = false; } out.push('<h5>' + line.replace(/^### /, '') + '</h5>'); }
            else if (/^## /.test(line)) { if (inList) { out.push('</ul>'); inList = false; } out.push('<h4>' + line.replace(/^## /, '') + '</h4>'); }
            else if (/^- /.test(line)) { if (!inList) { out.push('<ul>'); inList = true; } out.push('<li>' + line.replace(/^- /, '') + '</li>'); }
            else if (/^\s*$/.test(line)) { if (inList) { out.push('</ul>'); inList = false; } out.push('<br>'); }
            else { if (inList) { out.push('</ul>'); inList = false; } out.push('<p>' + line.replace(/`([^`]+)`/g, '<code>$1</code>') + '</p>'); }
        });
        if (inList) out.push('</ul>');
        return out.join('\n');
    }

    // ═══════════════════════════════════════════════════════════════════
    // CONTROL MAPS
    // ═══════════════════════════════════════════════════════════════════

    function buildOutputTable(cm, entries) {
        var keyLabel = cm.key_label || 'Key';
        var valueLabel = cm.value_label || 'Value';
        var editor = el('div', { className: 'ebpf-control-map-editor' });

        // Info row
        editor.appendChild(el('p', { className: 'ebpf-output-hint' }, ['Output map — read-only. Data is generated by the eBPF program.']));

        var table = el('table', { className: 'ebpf-kv-table ebpf-output-table' });
        table.appendChild(el('thead', null, [el('tr', null, [
            el('th', null, [keyLabel]), el('th', null, [valueLabel])
        ])]));
        var tbody = el('tbody');
        if (entries.length) {
            entries.forEach(function (e) {
                tbody.appendChild(el('tr', null, [
                    el('td', { className: 'ebpf-mono' }, [formatKey(e)]),
                    el('td', { className: 'ebpf-mono' }, [formatValue(e.value)])
                ]));
            });
        } else {
            tbody.appendChild(el('tr', null, [el('td', { colSpan: '2', className: 'ebpf-empty-msg' }, ['No data. Click map-get to load.'])]));
        }
        table.appendChild(tbody);
        editor.appendChild(table);

        // Refresh button
        editor.appendChild(el('button', { className: 'std-btn', onClick: function () {
            if (!activeInstanceId) return;
            apiClient.request('ebpf_get_control_map', { module: activeInstanceId, map: cm.name }).then(function (r) {
                controlMapEntries[cm.name] = (r.status === 'success' || r.status === 'partial') && r.result && r.result.entries ? r.result.entries : [];
                controlMapEntries[cm.name + '_has_more'] = r.result && r.result.has_more;
                renderControlMaps();
            });
        } }, ['↻ Refresh']));

        if (controlMapEntries[cm.name + '_has_more']) {
            editor.appendChild(el('p', { className: 'ebpf-output-hint' }, ['Showing first ' + entries.length + ' entries. More data available.']));
        }

        return editor;
    }

    function fetchControlMaps() {
        if (!activeInstanceId || !activeDetail || !activeDetail.control_maps) return;
        (activeDetail.control_maps || []).forEach(function (cm) {
            // Input maps get defaults from module-info (cm.entries), refreshed after push.
            // Do not fetch from kernel — the kernel may have uninitialized (zero) values.
            if (cm.direction === 'input') return;
            apiClient.request('ebpf_get_control_map', { module: activeInstanceId, map: cm.name }).then(function (r) {
                controlMapEntries[cm.name] = (r.status === 'success' || r.status === 'partial') && r.result && r.result.entries ? r.result.entries : [];
                controlMapEntries[cm.name + '_has_more'] = r.result && r.result.has_more;
                renderControlMaps();
            }).catch(function () { controlMapEntries[cm.name] = []; renderControlMaps(); });
        });
    }

    function renderControlMaps() {
        if (!activeDetail || !activeDetail.control_maps || !activeDetail.control_maps.length) {
            controlMapsContent.innerHTML = '<p class="ebpf-empty-msg">No control maps defined.</p>'; return;
        }
        if (!activeInstanceId) {
            controlMapsContent.innerHTML = '<p class="ebpf-empty-msg">Load the module to push data to control maps.</p>'; return;
        }
        controlMapsContent.innerHTML = '';
        activeDetail.control_maps.forEach(function (cm) {
            var card = el('div', { className: 'ebpf-control-map-card' });
            var headerInfo = (cm.max_entries || '?') + ' entries';
            if (cm.editor) headerInfo = cm.editor + ' · ' + headerInfo;
            if (cm.key_label || cm.value_label) headerInfo += ' · ' + (cm.key_label || 'Key') + ' → ' + (cm.value_label || 'Value');
            card.appendChild(el('div', { className: 'ebpf-control-map-header' }, [
                el('span', { className: 'ebpf-control-map-name' }, [cm.name]),
                el('span', { className: 'ebpf-control-map-type' }, [headerInfo])
            ]));
            var editor = buildMapEditor(cm);
            card.appendChild(editor);
            controlMapsContent.appendChild(card);
        });
    }

    function buildMapEditor(cm) {
        var entries = controlMapEntries[cm.name] || [];
        var editorType = cm.editor || 'keyvalue';
        var ops = cm.supported_ops || [];

        switch (editorType) {
        case 'table': return buildOutputTable(cm, entries);
        case 'single': return buildSingleEditor(cm, entries);
        case 'chip': return buildChipEditor(cm, entries, ops);
        case 'keyvalue': return buildKVEditor(cm, entries);
        default:
            var ed = el('div', { className: 'ebpf-control-map-editor' });
            ed.appendChild(el('p', { className: 'ebpf-empty-msg' }, ['Unknown editor type: "' + editorType + '"']));
            return ed;
        }
    }

    function buildSingleEditor(cm, entries) {
        var ed = el('div', { className: 'ebpf-control-map-editor' });
        var curKey = entries.length ? entries[0].key : '';
        var curVal = entries.length ? entries[0].value : '';
        var keyLabel = cm.key_label || 'Key';
        var valLabel = cm.value_label || 'Value';

        // Key row (read-only)
        var keyRow = el('div', { className: 'ebpf-control-input-row' });
        keyRow.appendChild(el('label', { className: 'ebpf-single-label' }, [keyLabel + ': ']));
        keyRow.appendChild(el('span', { className: 'ebpf-mono' }, [String(curKey !== undefined ? curKey : '')]));
        ed.appendChild(keyRow);

        // Value row (editable)
        var valRow = el('div', { className: 'ebpf-control-input-row' });
        valRow.appendChild(el('label', { className: 'ebpf-single-label' }, [valLabel + ': ']));
        var input = el('input', { type: 'text', className: 'ebpf-input ebpf-control-input', value: String(curVal !== undefined ? curVal : '') });
        valRow.appendChild(input);
        ed.appendChild(valRow);

        if ((cm.supported_ops || []).indexOf('upsert') !== -1 || (cm.supported_ops || []).indexOf('replace_all') !== -1) {
            ed.appendChild(el('button', { className: 'std-btn ebpf-btn-save', onClick: function () {
                var v = input.value.trim();
                pushMap(cm.name, [{ value: v }], 'upsert');
            } }, ['Save']));
        }
        return ed;
    }

    function buildChipEditor(cm, entries, ops) {
        var ed = el('div', { className: 'ebpf-control-map-editor' });
        var chips = el('div', { className: 'ebpf-chip-list' });
        entries.forEach(function (e, i) {
            var chip = el('span', { className: 'ebpf-chip' });
            chip.appendChild(document.createTextNode(formatMapEntry(e)));
            chip.appendChild(el('span', { className: 'ebpf-chip-remove', onClick: function () { removeEntry(cm.name, i); } }, ['×']));
            chips.appendChild(chip);
        });
        if (!entries.length) chips.appendChild(el('span', { className: 'ebpf-empty-msg' }, ['No entries']));
        ed.appendChild(chips);

        var input = el('input', { type: 'text', className: 'ebpf-input ebpf-control-input',
            placeholder: 'e.g. ' + (cm.key_label || 'value') });
        ed.appendChild(el('div', { className: 'ebpf-control-input-row' }, [input]));

        var btnRow = el('div', { className: 'ebpf-control-btn-row' });
        if (ops.indexOf('upsert') !== -1) btnRow.appendChild(el('button', { className: 'std-btn', onClick: function () {
            var v = input.value.trim(); if (!v) return; pushMap(cm.name, [v], 'upsert'); input.value = ''; } }, ['Add']));
        if (ops.indexOf('replace_all') !== -1) btnRow.appendChild(el('button', { className: 'std-btn ebpf-btn-warning', onClick: function () {
            var items = input.value.split(/[\n,]+/).map(function (s) { return s.trim(); }).filter(Boolean);
            if (!items.length) return; pushMap(cm.name, items, 'replace_all'); input.value = ''; } }, ['Replace All']));
        if (ops.indexOf('delete') !== -1) btnRow.appendChild(el('button', { className: 'std-btn ebpf-btn-danger', onClick: function () { pushMap(cm.name, [], 'delete'); } }, ['Clear All']));
        ed.appendChild(btnRow);
        return ed;
    }

    function buildKVEditor(cm, entries) {
        var ed = el('div', { className: 'ebpf-control-map-editor' });
        var kLabel = cm.key_label || 'Key';
        var vLabel = cm.value_label || 'Value';
        var table = el('table', { className: 'ebpf-kv-table' });
        table.appendChild(el('thead', null, [el('tr', null, [
            el('th', null, [kLabel]), el('th', null, [vLabel]), el('th', null, [''])
        ])]));
        var tbody = el('tbody');
        entries.forEach(function (e, i) { tbody.appendChild(buildKVRow(e, i, cm.name)); });
        table.appendChild(tbody);
        ed.appendChild(table);
        ed.appendChild(el('button', { className: 'std-btn', onClick: function () {
            if (!controlMapEntries[cm.name]) controlMapEntries[cm.name] = [];
            controlMapEntries[cm.name].push({ key: '', value: '' }); renderControlMaps(); } }, ['+ Add Row']));
        ed.appendChild(el('button', { className: 'std-btn ebpf-btn-save', onClick: function () {
            var items = (controlMapEntries[cm.name] || []).filter(function (e) { return (e.key || e.value) !== ''; });
            pushMap(cm.name, items, 'replace_all'); } }, ['Save']));
        return ed;
    }

    function buildKVRow(entry, idx, mapName) {
        var rawKey = entry.key;
        var rawVal = entry.value;
        var k = rawKey !== undefined && rawKey !== null ? String(rawKey) : '';
        var v = rawVal !== undefined && rawVal !== null ? String(rawVal) : '';
        return el('tr', null, [
            el('td', null, [el('input', { type: 'text', className: 'ebpf-input ebpf-kv-input', value: k,
                onChange: function (e) { ensureEntry(mapName, idx);
                    controlMapEntries[mapName][idx].key = e.target.value; } })]),
            el('td', null, [el('input', { type: 'text', className: 'ebpf-input ebpf-kv-input', value: v,
                onChange: function (e) { ensureEntry(mapName, idx);
                    controlMapEntries[mapName][idx].value = e.target.value; } })]),
            el('td', null, [el('span', { className: 'ebpf-chip-remove ebpf-kv-delete', onClick: function () { removeEntry(mapName, idx); } }, ['×'])])
        ]);
    }

    function ensureEntry(mapName, idx) {
        if (!controlMapEntries[mapName]) controlMapEntries[mapName] = [];
        if (!controlMapEntries[mapName][idx]) controlMapEntries[mapName][idx] = {};
    }

    function removeEntry(mapName, idx) {
        if (!controlMapEntries[mapName]) return;
        controlMapEntries[mapName].splice(idx, 1); renderControlMaps();
    }

    function pushMap(mapName, items, op) {
        if (!activeInstanceId) { showToast('Module is not loaded', 'error'); return; }
        apiClient.submit('ebpf_control_push', { module: activeInstanceId, map: mapName, items: items, op: op }).then(function (r) {
            if (r.status === 'success') {
                showToast(r.response_msg || 'Push successful', 'success');
                apiClient.request('ebpf_get_control_map', { module: activeInstanceId, map: mapName }).then(function (rr) {
                    controlMapEntries[mapName] = (rr.status === 'success' || rr.status === 'partial') && rr.result && rr.result.entries ? rr.result.entries : [];
                    renderControlMaps();
                });
            } else { showToast(r.response_msg || 'Push failed', 'error'); }
        }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); });
    }

    // ═══════════════════════════════════════════════════════════════════
    // TELEMETRY
    // ═══════════════════════════════════════════════════════════════════

    function fetchTelemetry() {
        if (!activeInstanceId) return;
        apiClient.request('ebpf_get_telemetry', { module: activeInstanceId }).then(function (r) {
            telemetryData = (r.status === 'success' || r.status === 'partial') && r.result && r.result.telemetry ? r.result.telemetry : {};
            renderTelemetry();
        }).catch(function () { telemetryData = {}; renderTelemetry(); });
    }

    function renderTelemetry() {
        if (!activeDetail || !activeDetail.telemetry_maps || !activeDetail.telemetry_maps.length) {
            telemetryContent.innerHTML = '<p class="ebpf-empty-msg">No telemetry maps defined.</p>'; return;
        }
        telemetryContent.innerHTML = '';
        activeDetail.telemetry_maps.forEach(function (tm) {
            var sec = el('div', { className: 'ebpf-telemetry-section' });
            sec.appendChild(el('div', { className: 'ebpf-telemetry-section-title' }, [tm.name + ' (' + tm.semantics + ', ' + (tm.poll_interval_ms || '?') + 'ms)']));
            var tiles = el('div', { className: 'ebpf-telemetry-tiles-row' });
            var key = activeInstanceId + '/' + tm.name;
            var td = telemetryData[key] || telemetryData[tm.name] || {};
            var fields = td.fields || {};
            if (Object.keys(fields).length) {
                Object.keys(fields).forEach(function (fn) {
                    tiles.appendChild(telemetryTile(fn, fields[fn]));
                });
            } else {
                tiles.appendChild(el('p', { className: 'ebpf-empty-msg' }, ['No data yet. Polling...']));
            }
            sec.appendChild(tiles);
            telemetryContent.appendChild(sec);
        });
    }

    function telemetryTile(name, value) {
        var unit = name.includes('bytes') ? 'bytes' : (name.includes('ip') ? 'ipv4' : (name.endsWith('_ns') ? 'ns' : (name.endsWith('_seen') ? 'epoch' : 'count')));
        return el('div', { className: 'ebpf-telemetry-tile' }, [
            el('div', { className: 'ebpf-telemetry-label' }, [name.replace(/_/g, ' ')]),
            el('div', { className: 'ebpf-telemetry-value', dataset: { field: name, unit: unit } }, [formatUnit(value, unit)])
        ]);
    }

    function startTelemetryPolling() {
        stopTelemetryPolling();
        var iv = activeDetail && activeDetail.telemetry_maps && activeDetail.telemetry_maps[0] ? (activeDetail.telemetry_maps[0].poll_interval_ms || 2000) : 2000;
        telemetryInterval = setInterval(function () {
            if (!activeInstanceId) return;
            apiClient.request('ebpf_get_telemetry', { module: activeInstanceId }).then(function (r) {
                if (r.status === 'success' || r.status === 'partial') {
                    telemetryData = r.result && r.result.telemetry ? r.result.telemetry : {};
                    Object.keys(telemetryData).forEach(function (k) {
                        var f = telemetryData[k].fields || {};
                        Object.keys(f).forEach(function (fn) {
                            var el = document.querySelector('.ebpf-telemetry-value[data-field="' + fn + '"]');
                            if (!el) return;
                            var newVal = f[fn];
                            el.textContent = formatUnit(newVal, el.dataset.unit || 'count');
                            // Pulse the tile if value changed from last poll
                            if (lastTelemetryValues[fn] !== undefined && lastTelemetryValues[fn] !== newVal) {
                                var tile = el.closest('.ebpf-telemetry-tile');
                                if (tile) {
                                    tile.classList.add('ebpf-pulse');
                                    setTimeout(function () { tile.classList.remove('ebpf-pulse'); }, 600);
                                }
                            }
                            lastTelemetryValues[fn] = newVal;
                        });
                    });
                }
            }).catch(function () {});
        }, iv);
    }

    function stopTelemetryPolling() { if (telemetryInterval) { clearInterval(telemetryInterval); telemetryInterval = null; } }

    // ═══════════════════════════════════════════════════════════════════
    // EVENTS
    // ═══════════════════════════════════════════════════════════════════

    function renderEvents() { eventsTbody.innerHTML = ''; seenEvents = {}; }

    function appendEventRow(ev) {
        var sevMap = { debug: 'ebpf-sev-debug', info: 'ebpf-sev-info', warn: 'ebpf-sev-warn', crit: 'ebpf-sev-crit' };
        var tr = el('tr', {
            className: 'ebpf-event-row ebpf-event-severity-' + (ev.severity || 'info') + ' ebpf-event-clickable',
            onClick: function () { showEventDetail(ev); }
        });
        tr.appendChild(el('td')); tr.firstChild.innerHTML = '<span class="ebpf-severity-badge ' + (sevMap[ev.severity] || 'ebpf-sev-info') + '">' + (ev.severity || 'info').toUpperCase() + '</span>';
        tr.appendChild(el('td', { className: 'ebpf-event-time' }, [formatUnit(ev.ts_ns || 0, 'ns')]));
        tr.appendChild(el('td', null, [ev.source ? ev.source.split('/').pop() : (ev.module || '—')]));
        tr.appendChild(el('td', { className: 'ebpf-event-summary' }, [ev.summary || ev.event || JSON.stringify(ev.fields || {}).slice(0, 80)]));
        eventsTbody.insertBefore(tr, eventsTbody.firstChild);
        while (eventsTbody.children.length > 200) eventsTbody.removeChild(eventsTbody.lastChild);
        if (autoScroll) { var wrap = document.getElementById('ebpf-events-table-wrap'); if (wrap) wrap.scrollTop = 0; }
    }

    function showEventDetail(ev) {
        var rows = [
            ['Severity', '<span class="ebpf-severity-badge ' + ({debug:'ebpf-sev-debug',info:'ebpf-sev-info',warn:'ebpf-sev-warn',crit:'ebpf-sev-crit'}[ev.severity]||'ebpf-sev-info') + '">' + (ev.severity||'').toUpperCase() + '</span>'],
            ['Time', formatUnit(ev.ts_ns || 0, 'ns')],
            ['Source', ev.source || ev.module || '—'],
            ['Event', ev.event || ev.summary || '—'],
        ];
        if (ev.tags && ev.tags.length) rows.push(['Tags', ev.tags.join(', ')]);
        var html = '<dl class="ebpf-details-list">';
        rows.forEach(function (r) { html += '<dt>' + r[0] + '</dt><dd>' + r[1] + '</dd>'; });
        html += '</dl>';
        if (ev.fields && Object.keys(ev.fields).length) {
            html += '<h4 style="margin-top:1em;color:var(--primary)">Fields</h4>';
            html += '<pre class="ebpf-event-raw">' + JSON.stringify(ev.fields, null, 2).replace(/&/g,'&amp;').replace(/</g,'&lt;') + '</pre>';
        }
        showModal(html, { title: 'Event Detail' });
    }

    function startEventPolling() {
        stopEventPolling();
        eventPollInterval = setInterval(function () {
            if (eventsPaused || !activeInstanceId) return;
            apiClient.request('ebpf_get_telemetry', { module: activeInstanceId }).then(function (r) {
                var tel = (r.status === 'success' || r.status === 'partial') && r.result && r.result.telemetry ? r.result.telemetry : {};
                // Prefer event_log (persisted history) over standalone security_event snapshots
                var hasEventLog = Object.keys(tel).some(function (k) { return tel[k] && tel[k].events; });
                Object.keys(tel).forEach(function (k) {
                    var s = tel[k];
                    if (s && s.events && Array.isArray(s.events)) {
                        s.events.forEach(function (ev) {
                            var fp = [ev.ts, ev.event, ev.fields && ev.fields.src_ip].join('|');
                            if (seenEvents[fp]) return;
                            seenEvents[fp] = true;
                            appendEventRow({
                                severity: ev.severity || 'info',
                                ts_ns: (ev.ts || 0) * 1e9,
                                source: k,
                                summary: (ev.fields && ev.fields.summary) || ev.summary || ev.event || '',
                                event: ev.event,
                                tags: ev.tags,
                                fields: ev.fields || {},
                                module: activeModule
                            });
                        });
                    }
                    if (!hasEventLog && s && s.schema_type === 'security_event' && s.fields) {
                        var fp2 = [(s.fields.ts_ns || s.ts_ns), 'security_event', s.fields.src_ip].join('|');
                        if (seenEvents[fp2]) return;
                        seenEvents[fp2] = true;
                        appendEventRow({
                            severity: s.severity || s.fields.severity || 'warn',
                            ts_ns: s.fields.ts_ns || (s.ts_ns || 0),
                            source: k,
                            summary: s.fields.summary || '',
                            fields: s.fields,
                            module: activeModule
                        });
                    }
                });
            }).catch(function () {});
        }, 3000);
    }

    function stopEventPolling() { if (eventPollInterval) { clearInterval(eventPollInterval); eventPollInterval = null; } }
    function startPolling() { startTelemetryPolling(); startEventPolling(); }
    function stopAllPolling() { stopTelemetryPolling(); stopEventPolling(); }

    // ═══════════════════════════════════════════════════════════════════
    // MODALS
    // ═══════════════════════════════════════════════════════════════════

    /** Build an HTML form field for a single pre_attach_param definition */
    function buildParamField(param) {
        var html = '<div class="ebpf-param-field">';
        var name = 'ebpf-param-' + param.name;
        var def = param.default !== undefined ? param.default : '';

        if (param.type === 'bool') {
            var checked = def ? ' checked' : '';
            var req = param.required ? ' <span class="ebpf-param-required">*</span>' : '';
            html += '<label class="ebpf-checkbox-label">'
                + '<input type="checkbox" name="' + name + '"' + checked + '> '
                + (param.label || param.name) + req
                + '</label>';
            if (param.description) {
                html += '<span class="ebpf-param-desc">' + param.description + '</span>';
            }
        } else {
            var reqMark = param.required ? '<span class="ebpf-param-required">*</span>' : '';
            html += '<label class="ebpf-param-label">' + (param.label || param.name) + reqMark + '</label>';
            if (param.description) {
                html += '<span class="ebpf-param-desc">' + param.description + '</span>';
            }

            if (param.type === 'int') {
                var min = param.min !== undefined ? ' min="' + param.min + '"' : '';
                var max = param.max !== undefined ? ' max="' + param.max + '"' : '';
                html += '<input type="number" class="ebpf-input" name="' + name + '"'
                    + ' value="' + def + '"' + min + max + ' style="width:100%">';
            } else if (param.choices && param.choices.length) {
                html += '<select class="ebpf-input" name="' + name + '" style="width:100%">';
                param.choices.forEach(function (c) {
                    var val = typeof c === 'object' ? c.value : c;
                    var lab = typeof c === 'object' ? (c.label || c.value) : c;
                    var sel = (String(val) === String(def)) ? ' selected' : '';
                    html += '<option value="' + val + '"' + sel + '>' + lab + '</option>';
                });
                html += '</select>';
            } else {
                html += '<input type="text" class="ebpf-input" name="' + name + '"'
                    + ' value="' + def + '" style="width:100%">';
            }
        }

        html += '</div>';
        return html;
    }

    function openLoadModalFromMeta(m) {
        openLoadModal({
            name: m.name, version: m.version,
            attach_target: m.attach_target,
            interface: m.interface, hook_type: m.hook_type,
            pre_attach_params: m.pre_attach_params || []
        });
    }

    function openLoadModal(mod) {
        var tr = (typeof mod.dataset !== 'undefined') ? mod : null;
        var meta = tr ? metaFromRow(tr) : mod;
        if (!meta) return;
        var target = meta.attach_target || 'interface';
        var params = meta.pre_attach_params || [];
        var hasParams = params.length > 0;

        // ── attach_target === 'none' (no interface selector) ──
        if (target === 'none') {
            var bodyNone = '<p>Load <b>' + meta.name + '</b>?</p><p class="ebpf-info-text">No interface required.</p>';
            if (hasParams) {
                bodyNone += '<div class="ebpf-params-section"><span class="ebpf-params-title">Parameters</span>';
                params.forEach(function (p) { bodyNone += buildParamField(p); });
                bodyNone += '</div>';
            }
            showModal(bodyNone, {
                title: 'Load: ' + meta.name, showConfirm: true, confirmText: 'Load',
                onConfirm: function () {
                    var collected = null;
                    if (hasParams) {
                        collected = collectParams(params);
                        if (collected === false) return; // validation failed
                    }
                    doLoad(meta.name, null, collected);
                }
            });
            return;
        }

        // ── Fetch interfaces and show combined form ──
        apiClient.request('get_interfaces_names', {}).then(function (r) {
            var ifaces = (r.status === 'success' || r.status === 'partial') && r.result && r.result.interfaces ? r.result.interfaces : [];
            var required = target === 'interface';
            var label = required ? 'Interface (required):' : 'Interface (optional):';
            var opts = ifaces.map(function (i) {
                var n = i.interface || i.name || i.id || '—', uid = i.id || i.iface_id || '';
                return '<label class="ebpf-checkbox-label"><input type="checkbox" name="ebpf-load-iface" value="' + uid + '"> <b>' + n + '</b> <span class="ebpf-uuid">' + uid.slice(0, 8) + '...</span></label>';
            }).join('') || '<p class="ebpf-empty-msg">No interfaces available</p>';

            var body = '<p>Load <b>' + meta.name + '</b></p>'
                + '<div class="ebpf-load-modal-form">'
                + '<label class="ebpf-load-modal-label">' + label + '</label>'
                + '<div class="ebpf-load-modal-ifaces">' + opts + '</div>';

            if (hasParams) {
                body += '<div class="ebpf-params-section"><span class="ebpf-params-title">Parameters</span>';
                params.forEach(function (p) { body += buildParamField(p); });
                body += '</div>';
            }

            body += '</div>';

            showModal(body, {
                title: 'Load: ' + meta.name, showConfirm: true, confirmText: 'Load',
                onConfirm: function () {
                    var checked = document.querySelectorAll('input[name="ebpf-load-iface"]:checked');
                    var uuids = []; checked.forEach(function (c) { uuids.push(c.value); });
                    if (required && !uuids.length) { showToast('Select at least one interface', 'error'); return; }

                    var collected = null;
                    if (hasParams) {
                        collected = collectParams(params);
                        if (collected === false) return; // validation failed
                    }

                    doLoad(meta.name, uuids.length === 1 ? uuids[0] : (uuids.length > 1 ? uuids : null), collected);
                }
            });
        }).catch(function () { showToast('Failed to fetch interfaces', 'error'); });
    }

    /** Collect param values from the modal DOM. Returns false if validation fails. */
    function collectParams(paramDefs) {
        if (!paramDefs || !paramDefs.length) return {};
        var values = {};
        for (var i = 0; i < paramDefs.length; i++) {
            var p = paramDefs[i];
            var name = 'ebpf-param-' + p.name;
            var el = document.querySelector('[name="' + name + '"]');
            if (!el) continue;
            var val;
            if (p.type === 'bool') {
                val = el.checked;
            } else if (p.type === 'int') {
                val = el.value === '' ? null : parseInt(el.value, 10);
                if (p.required && (val === null || isNaN(val))) {
                    showToast((p.label || p.name) + ' is required', 'error');
                    return false;
                }
                if (val !== null && !isNaN(val)) {
                    if (p.min !== undefined && val < p.min) { showToast((p.label || p.name) + ' must be ≥ ' + p.min, 'error'); return false; }
                    if (p.max !== undefined && val > p.max) { showToast((p.label || p.name) + ' must be ≤ ' + p.max, 'error'); return false; }
                }
            } else {
                val = el.value;
                if (p.required && (val === null || val === '')) {
                    showToast((p.label || p.name) + ' is required', 'error');
                    return false;
                }
            }
            // Only include if changed from default (or no default)
            if (p.default === undefined || val !== p.default) {
                values[p.name] = val;
            }
        }
        return values;
    }

    function doLoad(moduleName, ifaceParam, params) {
        var p = { module: moduleName };
        if (ifaceParam !== null) p.interface = ifaceParam;
        if (params && Object.keys(params).length > 0) p.params = params;
        apiClient.submit('ebpf_load_module', p).then(function (r) {
            if (r.status === 'success') {
                var ids = r.result && r.result.instance_ids ? r.result.instance_ids : [];
                var names = r.result && r.result.interfaces ? r.result.interfaces : [];
                var msg = 'Loaded ' + ids.length + ' instance(s)';
                if (names.length) msg += ' on ' + names.join(', ');
                showToast(msg, 'success'); refreshList();
            } else { showToast(r.response_msg || 'Load failed', 'error'); }
        }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); });
    }

    function handleUnload(preserve) {
        var id = activeInstanceId; if (!id) return;
        var a = preserve ? 'Suspend' : 'Unload';
        showModal('<p>' + a + ' <b>' + activeModule + '</b>?</p>', {
            title: a + ' Module', showConfirm: true, confirmText: a, confirmClass: preserve ? 'ebpf-btn-suspend' : 'ebpf-btn-danger',
            onConfirm: function () {
                var p = { module: id }; if (preserve) p.preserve = true;
                apiClient.submit('ebpf_unload_module', p).then(function (r) {
                    if (r.status === 'success') { showToast(r.response_msg || a + 'ed', 'success'); backToList(); refreshList(); }
                    else showToast(r.response_msg || a + ' failed', 'error');
                }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); });
            }
        });
    }

    function reactivateInstance(m) {
        showModal('<p>Reactivate <b>' + m.name + '</b>?</p>', {
            title: 'Reactivate', showConfirm: true, confirmText: 'Reactivate',
            onConfirm: function () {
                apiClient.submit('ebpf_load_module', { module: m.instance_id }).then(function (r) {
                    if (r.status === 'success') { showToast(r.response_msg || 'Reactivated', 'success'); backToList(); refreshList(); }
                    else showToast(r.response_msg || 'Reactivation failed', 'error');
                }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); });
            }
        });
    }

    function handleReload() {
        var id = activeInstanceId; if (!id) return;
        showModal('<p>Reload <b>' + activeModule + '</b>?</p>', {
            title: 'Reload', showConfirm: true, confirmText: 'Reload',
            onConfirm: function () {
                apiClient.submit('ebpf_reload_module', { module: id }).then(function (r) {
                    if (r.status === 'success') { showToast(r.response_msg || 'Reloaded', 'success'); refreshList(); selectModule(id); }
                    else showToast(r.response_msg || 'Reload failed', 'error');
                }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); });
            }
        });
    }

    // ═══════════════════════════════════════════════════════════════════
    // AUTOLOAD
    // ═══════════════════════════════════════════════════════════════════

    function toggleAutoload(uuid, enabled) {
        // Build autoload list from checked checkboxes in the DOM
        var list = [];
        document.querySelectorAll('.ebpf-autoload-toggle').forEach(function (cb) {
            if (cb.checked && cb.dataset.uuid) list.push(cb.dataset.uuid);
        });
        // Ensure the toggled UUID is included/excluded correctly
        if (enabled && list.indexOf(uuid) === -1) list.push(uuid);
        else if (!enabled) list = list.filter(function (id) { return id !== uuid; });

        apiClient.submit('ebpf_set_autoload', { autoload: list }).then(function (r) {
            if (r.status === 'success') {
                showToast(enabled ? 'Autoload enabled' : 'Autoload disabled', 'success');
            } else {
                showToast(r.response_msg || 'Autoload update failed', 'error');
                refreshList();
            }
        }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); refreshList(); });
    }

    // ═══════════════════════════════════════════════════════════════════
    // REFRESH
    // ═══════════════════════════════════════════════════════════════════

    function refreshList() {
        apiClient.request('ebpf_get_module_list', {}).then(function () {
            // Reload the page to get fresh PHP-rendered data
            window.location.reload();
        }).catch(function () {});
    }

    // ═══════════════════════════════════════════════════════════════════
    // EVENT HANDLERS
    // ═══════════════════════════════════════════════════════════════════

    if (backBtn) backBtn.addEventListener('click', backToList);
    if (searchInput) searchInput.addEventListener('input', function () { filterRows(searchInput.value); });
    var rescanBtn = document.getElementById('ebpf-rescan-btn');
    if (refreshBtn) refreshBtn.addEventListener('click', function () { refreshList(); showToast('Refreshing...', 'info'); });
    if (rescanBtn) rescanBtn.addEventListener('click', function () {
        rescanBtn.disabled = true;
        rescanBtn.textContent = 'Scanning...';
        apiClient.submit('ebpf_module_rescan', {}).then(function (r) {
            if (r.status === 'success') {
                var loaded = (r.result && r.result.newly_loaded) || [];
                var msg = r.response_msg || 'Rescan complete';
                if (loaded.length) msg += ' — loaded ' + loaded.length + ' new';
                showToast(msg, 'success');
                refreshList();
            } else {
                showToast(r.response_msg || 'Rescan failed', 'error');
            }
            rescanBtn.disabled = false;
            rescanBtn.textContent = '🔍 Rescan';
        }).catch(function (e) {
            showToast('Network error: ' + e.message, 'error');
            rescanBtn.disabled = false;
            rescanBtn.textContent = '🔍 Rescan';
        });
    });
    if (eventsPauseBtn) eventsPauseBtn.addEventListener('click', function () { eventsPaused = !eventsPaused; eventsPauseBtn.innerHTML = eventsPaused ? '▶ Resume' : '⏸ Pause'; });
    if (eventsClearBtn) eventsClearBtn.addEventListener('click', function () { eventsTbody.innerHTML = ''; seenEvents = {}; });
    if (eventsAutoScroll) eventsAutoScroll.addEventListener('change', function () { autoScroll = eventsAutoScroll.checked; });

    // ═══════════════════════════════════════════════════════════════════
    // FOREIGN PROGRAMS: Acknowledge All
    // ═══════════════════════════════════════════════════════════════════

    var ackAllBtn = document.getElementById('ebpf-ack-all-btn');
    if (ackAllBtn) {
        ackAllBtn.addEventListener('click', function () {
            ackAllBtn.disabled = true;
            ackAllBtn.textContent = 'Acknowledging...';
            apiClient.submit('ebpf_baseline_ack', {}).then(function (r) {
                if (r.status === 'success') {
                    showToast(r.response_msg || 'Foreign programs acknowledged', 'success');
                    refreshList();
                } else {
                    showToast(r.response_msg || 'Acknowledge failed', 'error');
                    ackAllBtn.disabled = false;
                    ackAllBtn.textContent = 'Acknowledge All';
                }
            }).catch(function (e) {
                showToast('Network error: ' + e.message, 'error');
                ackAllBtn.disabled = false;
                ackAllBtn.textContent = 'Acknowledge All';
            });
        });
    }

    // ═══════════════════════════════════════════════════════════════════
    // FOREIGN PROGRAMS: Detach
    // ═══════════════════════════════════════════════════════════════════

    document.getElementById('ebpf-foreign-table').addEventListener('click', function (e) {
        var detachBtn = e.target.closest('.ebpf-detach-btn');
        if (!detachBtn || detachBtn.disabled) return;

        var programId     = detachBtn.dataset.programId;
        var programName   = detachBtn.dataset.programName;
        var programType   = detachBtn.dataset.programType;
        var isXdp         = detachBtn.dataset.isXdp === '1';
        var hasDispatcher = detachBtn.dataset.hasDispatcher === '1';

        var bodyHtml = '<p>Detach BPF program <b>' + programName + '</b> (id=' + programId + ', type=' + programType + ')?</p>';
        if (isXdp && hasDispatcher) {
            bodyHtml += '<p class="ebpf-warning-text">⚠️ Dispatcher detected — this will remove <b>ALL</b> XDP programs from the interface.</p>';
        } else if (isXdp) {
            bodyHtml += '<p class="ebpf-info-text">This will remove the XDP program from the interface.</p>';
        }

        showModal(bodyHtml, {
            title: 'Detach Foreign Program',
            showConfirm: true,
            confirmText: 'Detach',
            confirmClass: 'ebpf-btn-danger',
            onConfirm: function () {
                detachBtn.disabled = true;
                detachBtn.textContent = 'Detaching...';
                apiClient.submit('ebpf_program_detach', { program_id: parseInt(programId, 10) }).then(function (r) {
                    if (r.status === 'success') {
                        showToast(r.response_msg || 'Program detached', 'success');
                        refreshList();
                    } else {
                        showToast(r.response_msg || 'Detach failed', 'error');
                        detachBtn.disabled = false;
                        detachBtn.textContent = 'Detach';
                    }
                }).catch(function (err) {
                    showToast('Network error: ' + err.message, 'error');
                    detachBtn.disabled = false;
                    detachBtn.textContent = 'Detach';
                });
            }
        });
    });

})();
