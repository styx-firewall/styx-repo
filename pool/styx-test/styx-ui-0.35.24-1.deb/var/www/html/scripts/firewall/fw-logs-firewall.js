// fw-logs-firewall.js
// Handles tab switching and log fetching for all firewall log panels (local, prerouting, postrouting, prepost, forward)
// Stops previous fetch when switching tabs using AbortController
const tabNames = ['local', 'prerouting', 'postrouting', 'prepost', 'forward'];
const logTables = {};
const fetchControllers = {};
const currentQuery = {};
const lastMark = {};
function resetMark(tab) {
    lastMark[tab] = null;
    try { saveState('fw-logs', `mark:${tab}`, null); } catch (e) { /* noop */ }
}
let currentTab = 'local';
let autoRefreshInterval = null;
let autoRefreshPaused = false;

// Columns configuration MUST be provided by the server formatter.
const columnsByTab = window.__fwLogsColumnsByTab;

// Attach render callbacks that require runtime globals (dateUtils).
// Done here rather than in the PHP-generated config because functions
// cannot be serialized to JSON.
if (columnsByTab) {
    Object.values(columnsByTab).forEach(cols => {
        cols.forEach(col => {
            if (col.key === 'timestamp') {
                col.render = val => val && window.dateUtils ? window.dateUtils.formatString(val) : val;
            }
        });
    });
}

function getTableId(tab) {
    return `dynamic-table-${tab}`;
}

function showLogModal(log) {
    let html = '<h2 class="fwlog-modal-title">Log Details</h2>';
    html += ('<table class="fwlog-modal-table">');
    html += '<tbody>';
    // Helper to escape HTML text
    function esc(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function renderVal(v) {
        if (v === null || v === undefined) return '';
        if (typeof v === 'object') {
            // Render nested object as a compact two-column table (vertical list)
            let out = '<div class="fwlog-nested"><table class="fwlog-nested-table"><tbody>';
            Object.keys(v).forEach(k => {
                let val = v[k];
                if (typeof val === 'object') {
                    // nested deeper: stringify small objects
                    try { val = JSON.stringify(val); } catch (e) { val = String(val); }
                }
                out += '<tr><td class="fwlog-nk">' + esc(k) + '</td><td class="fwlog-nv">' + esc(val) + '</td></tr>';
            });
            out += '</tbody></table></div>';
            return out;
        }
        return esc(v);
    }

    let keys = Object.keys(log);
    for (let i = 0; i < keys.length; i += 2) {
        html += '<tr>';
        // First column
        let key1 = keys[i];
        html += `<td class="fwlog-key">${esc(key1)}</td>`;
        html += '<td class="fwlog-value">' + renderVal(log[key1]) + '</td>';
        // Second column (if exists)
        if (keys[i+1]) {
            let key2 = keys[i+1];
            html += `<td class="fwlog-key">${esc(key2)}</td>`;
            html += '<td class="fwlog-value">' + renderVal(log[key2]) + '</td>';
        } else {
            html += `<td colspan='2'></td>`;
        }
        html += '</tr>';
    }
    html += '</tbody></table>';
    if (typeof showModal === 'function') {
        // Prefer CSS classes over inline styles. The classes are defined in default-fw-logs.css
        showModal(html, {
            boxClass: 'fwlog-modal-box',
            contentClass: 'fwlog-modal-content',
            modalClass: 'fwlog-modal-overlay'
        });
    } else {
        alert('Log details:\n' + JSON.stringify(log, null, 2));
    }
}

function renderColumnControls(tab) {
    const container = document.getElementById(`column-controls-${tab}`);
    if (!container) return;
    container.innerHTML = '';
    const columns = columnsByTab[tab];
    columns.forEach((col, idx) => {
        const label = document.createElement('label');
        label.style.marginRight = '12px';
        label.style.cursor = 'pointer';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = col.visible !== false;
        checkbox.onchange = () => {
            columns[idx].visible = checkbox.checked;
            // Show/hide header
            const thead = logTables[tab].table.querySelector('thead');
            if (thead && thead.rows[0].cells[idx]) {
                thead.rows[0].cells[idx].style.display = checkbox.checked ? '' : 'none';
            }
            // Show/hide each row cell
            const tbody = logTables[tab].table.querySelector('tbody');
            Array.from(tbody.rows).forEach(tr => {
                if (tr.cells[idx]) {
                    tr.cells[idx].style.display = checkbox.checked ? '' : 'none';
                }
            });
            saveState('fw-logs', `columns:${tab}`, columns.map(c => c.visible !== false));
        };
        label.appendChild(checkbox);
        label.appendChild(document.createTextNode(' ' + col.label));
        container.appendChild(label);
    });
    // Initialize visibility state on load
    const thead = logTables[tab].table.querySelector('thead');
    const tbody = logTables[tab].table.querySelector('tbody');
    columns.forEach((col, idx) => {
        const visible = col.visible !== false;
        if (thead && thead.rows[0].cells[idx]) {
            thead.rows[0].cells[idx].style.display = visible ? '' : 'none';
        }
        Array.from(tbody.rows).forEach(tr => {
            if (tr.cells[idx]) {
                tr.cells[idx].style.display = visible ? '' : 'none';
            }
        });
    });
}

function fetchLogs(tab) {
    // Show global loading overlay while fetching
    try {
        // Best-effort UI update; non-critical if it fails
        window.showLoader?.(true);
    } catch (e) {
        /* ignore: best-effort UI update, non-critical */
    }
    // Abort previous fetch for this tab
    if (fetchControllers[tab]) {
        fetchControllers[tab].abort();
    }
    const controller = new AbortController();
    fetchControllers[tab] = controller;
    const limit = parseInt(document.getElementById(`log-limit-${tab}`).value) || 20;
    const hookMap = {
        local: ['input', 'output'],
        prerouting: 'prerouting',
        postrouting: 'postrouting',
        prepost: ['prerouting', 'postrouting'],
        forward: 'forward',
    };
    const payload = {
        action: 'fw_logs',
        query: (currentQuery[tab] || '').trim(),
        hook: hookMap[tab],
        limit,
        mark: lastMark[tab]
    };
        apiClient.request('fw_logs', payload, { signal: controller.signal })
            .then(json => {
                // Update mark for this tab if present
                if (typeof json.mark !== 'undefined' && json.mark !== null) {
                    lastMark[tab] = json.mark;
                }
                // Remove highlight from all rows in the current table before adding new logs
                const tbody = document.getElementById(getTableId(tab)).querySelector('tbody');
                if (tbody) {
                    Array.from(tbody.rows).forEach(tr => tr.classList.remove('log-row-new'));
                }
                if (Array.isArray(json.logs)) {
                    logTables[tab].addRows(json.logs, true);
                }
            })
            .catch(err => {
                // apiClient returns normalized error objects; handle Abort
                if (err && err.name === 'AbortError') return; // cancelled
                // If apiClient returned an error object, show its message
                if (err && err.response_msg) {
                    renderLogsTabError(tab, err.response_msg);
                } else {
                    renderLogsTabError(tab, err && err.message ? err.message : String(err));
                }
            })
            .finally(() => {
                try { if (typeof hideLoader === 'function') hideLoader(); } catch (e) { /* noop */ }
            });
}

function getRefreshIntervalMs() {
    const input = document.getElementById('fw-logs-refresh-interval');
    const seconds = input ? parseInt(input.value) : 20;
    return Math.max(2, isNaN(seconds) ? 20 : seconds) * 1000;
}

function startAutoRefresh(tab) {
    if (autoRefreshPaused) return;
    if (autoRefreshInterval) clearInterval(autoRefreshInterval);
    autoRefreshInterval = setInterval(() => {
        fetchLogs(tab);
    }, getRefreshIntervalMs());
}

function pauseAutoRefresh() {
    if (autoRefreshInterval) {
        clearInterval(autoRefreshInterval);
        autoRefreshInterval = null;
    }
    autoRefreshPaused = true;
    const btn = document.getElementById('fw-logs-toggle-autorefresh');
    if (btn) btn.textContent = 'Resume Auto-refresh';
}

function resumeAutoRefresh(tab) {
    autoRefreshPaused = false;
    startAutoRefresh(tab || currentTab);
    const btn = document.getElementById('fw-logs-toggle-autorefresh');
    if (btn) btn.textContent = 'Pause Auto-refresh';
}

function setupTabs() {
    // Restore persisted state before building tabs
    const savedTab = loadState('fw-logs', 'currentTab', null);
    if (savedTab && tabNames.includes(savedTab)) {
        currentTab = savedTab;
    }
    // Auto-refresh starts unpaused on every page load (no localStorage persistence)
    const savedInterval = loadState('fw-logs', 'refreshInterval', null);
    const intervalElInit = document.getElementById('fw-logs-refresh-interval');
    if (savedInterval !== null && intervalElInit) {
        intervalElInit.value = savedInterval;
    }

    tabNames.forEach(tab => {
        // Restore query string (we keep this early so UI shows previous query)
        const savedQuery = loadState('fw-logs', `query:${tab}`, '');
        currentQuery[tab] = savedQuery;

        // Ensure there's a dedicated Details button column (do not rely on
        // row click for showing details). The render returns a DOM node so
        // the LogTable will insert a button per-row.
        // Ensure there's a visible Hook column showing the netfilter hook name
        if (!columnsByTab[tab].some(c => c.key === 'network.hook' || c.key === 'hook' || c.key === 'hook_name')) {
            columnsByTab[tab].push({
                key: 'network.hook',
                label: 'Hook',
                visible: true,
                render: (v, log) => {
                    const val = (v !== undefined && v !== null && v !== '') ? v
                        : (log && log.network && log.network.hook) ? log.network.hook
                        : (log && log.hook) ? log.hook
                        : '';
                    return String(val);
                }
            });
        }
        if (!columnsByTab[tab].some(c => c.key === '__details')) {
            columnsByTab[tab].push({
                key: '__details',
                label: '',
                visible: true,
                render: (v, log) => {
                    const btn = document.createElement('button');
                    btn.textContent = 'Details';
                    btn.className = 'std-btn fwlog-details-btn';
                    btn.addEventListener('click', (ev) => {
                        ev.stopPropagation();
                        showLogModal(log);
                    });
                    return btn;
                }
            });
        }

        // After ensuring dynamic columns (Hook, Details), restore column visibility
        const savedCols = loadState('fw-logs', `columns:${tab}`, null);
        if (savedCols && columnsByTab[tab]) {
            columnsByTab[tab].forEach((col, idx) => {
                if (savedCols[idx] !== undefined) { col.visible = savedCols[idx]; }
            });
        }

        // Init LogTable for each tab. Do not pass `showLogModal` as the
        // global row click handler so clicking a row won't open details.
        logTables[tab] = new LogTable({
            tableId: getTableId(tab),
            columns: columnsByTab[tab],
            onRowClick: undefined,
            rowClass: log => ''
        });
        renderColumnControls(tab);

        // Restore and wire log-limit input
        const savedLimit = loadState('fw-logs', `limit:${tab}`, null);
        const limitInput = document.getElementById(`log-limit-${tab}`);
        if (savedLimit !== null && limitInput) {
            limitInput.value = savedLimit;
        }
        if (limitInput) {
            limitInput.addEventListener('change', () => {
                saveState('fw-logs', `limit:${tab}`, limitInput.value);
            });
        }

        // Wire raw query input
        const queryInput = document.getElementById(`fw-query-${tab}`);
        if (queryInput) {
            queryInput.value = currentQuery[tab] || '';
            queryInput.addEventListener('input', () => {
                currentQuery[tab] = queryInput.value;
                saveState('fw-logs', `query:${tab}`, queryInput.value);
            });
        }

        // Wire Keys helper button
        const keysHelpBtn = document.querySelector(`.js-fw-query-help[data-tab="${tab}"]`);
        const keysDiv = document.getElementById(`fw-query-keys-${tab}`);
        if (keysHelpBtn && keysDiv) {
            keysHelpBtn.addEventListener('click', () => {
                if (!keysDiv.hidden) {
                    keysDiv.hidden = true;
                    return;
                }
                const colKeys = (columnsByTab[tab] || [])
                    .map(c => c.key)
                    .filter(k => k && !k.startsWith('__'));
                const extraKeys = ['network.hook', 'network.in_iface', 'network.out_iface'];
                const allKeys = Array.from(new Set([...colKeys, ...extraKeys]));
                keysDiv.innerHTML = allKeys.map(k =>
                    `<button type="button" class="std-btn fwlog-key-chip" data-key="${k}" data-tab="${tab}">${k}</button>`
                ).join(' ');
                keysDiv.hidden = false;
                keysDiv.querySelectorAll('.fwlog-key-chip').forEach(chip => {
                    chip.addEventListener('click', () => {
                        if (!queryInput) return;
                        const append = (queryInput.value.trim() ? ' AND ' : '') + chip.dataset.key + ' == ""';
                        queryInput.value += append;
                        const pos = queryInput.value.length - 1;
                        queryInput.focus();
                        queryInput.setSelectionRange(pos, pos);
                        currentQuery[tab] = queryInput.value;
                        saveState('fw-logs', `query:${tab}`, queryInput.value);
                    });
                });
            });
        }

        const filterForm = document.getElementById(`log-filters-form-${tab}`);
        if (!filterForm) return;
        filterForm.onsubmit = function(e) {
            e.preventDefault();
            resetMark(tab);
            try { logTables[tab].clearRows(); } catch (e) { /* noop */ }
            fetchLogs(tab);
        };
        // Tab button event — skip if button is not in the DOM (e.g. commented out in template)
        const tabBtn = document.querySelector(`.tab-btn[data-tab="${tab}"]`);
        if (!tabBtn) return;
        tabBtn.addEventListener('click', () => {
            if (currentTab === tab) return;
            // Hide previous panel, show new (toggle both legacy display and std-tab-panel active class)
            const prevPanel = document.getElementById(`fw-logs-${currentTab}-panel`);
            const nextPanel = document.getElementById(`fw-logs-${tab}-panel`);
            if (prevPanel) {
                try { prevPanel.style.display = 'none'; } catch (e) {}
                prevPanel.classList.remove('visible');
                prevPanel.classList.remove('active');
            }
            if (nextPanel) {
                try { nextPanel.style.display = 'block'; } catch (e) {}
                nextPanel.classList.add('visible');
                nextPanel.classList.add('active');
            }
            const prevBtn = document.querySelector(`.tab-btn[data-tab="${currentTab}"]`);
            const nextBtn = document.querySelector(`.tab-btn[data-tab="${tab}"]`);
            if (prevBtn) prevBtn.classList.remove('active');
            if (nextBtn) nextBtn.classList.add('active');
            currentTab = tab;
            saveState('fw-logs', 'currentTab', tab);
            fetchLogs(tab);
            startAutoRefresh(tab);
        });
    });
    // If restored tab differs from default, activate its panel visually
    if (currentTab !== 'local') {
        const defPanel = document.getElementById('fw-logs-local-panel');
        const actPanel = document.getElementById(`fw-logs-${currentTab}-panel`);
        if (defPanel) { defPanel.style.display = 'none'; defPanel.classList.remove('visible', 'active'); }
        if (actPanel) { actPanel.style.display = 'block'; actPanel.classList.add('visible', 'active'); }
        const defBtn = document.querySelector('.tab-btn[data-tab="local"]');
        const actBtn = document.querySelector(`.tab-btn[data-tab="${currentTab}"]`);
        if (defBtn) defBtn.classList.remove('active');
        if (actBtn) actBtn.classList.add('active');
    }
    if (autoRefreshPaused) {
        const toggleBtn2 = document.getElementById('fw-logs-toggle-autorefresh');
        if (toggleBtn2) toggleBtn2.textContent = 'Resume Auto-refresh';
    }

    // Initial fetch for default tab
    fetchLogs(currentTab);
    startAutoRefresh(currentTab);

    // Wire the pause/resume toggle button
    const toggleBtn = document.getElementById('fw-logs-toggle-autorefresh');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            if (autoRefreshPaused) {
                resumeAutoRefresh(currentTab);
            } else {
                pauseAutoRefresh();
            }
        });
    }

    // Restart the auto-refresh interval whenever the user changes the interval input
    const intervalInput = document.getElementById('fw-logs-refresh-interval');
    if (intervalInput) {
        intervalInput.addEventListener('change', () => {
            saveState('fw-logs', 'refreshInterval', intervalInput.value);
            if (!autoRefreshPaused) {
                startAutoRefresh(currentTab);
            }
        });
    }
}

document.addEventListener('DOMContentLoaded', setupTabs);
