/**
 * strongSwan VPN page — single orchestrator script.
 *
 * Handles: tab switching, inline editors for connections / pools / secrets,
 * conditional form visibility, IKE/ESP proposal builder, auto-presets,
 * PSK generation, data collection, CRUD operations, status refresh,
 * and global config form.
 *
 * No sub-modules, no cloning, no fallbacks for config-meaningful fields.
 */
(function () {
    'use strict';

    // ------------------------------------------------------------------
    // Proposal builder helpers (selects now rendered server-side)
    // ------------------------------------------------------------------
    function isAead(enc) {
        return /gcm|chacha20poly1305/.test(enc);
    }

    // ------------------------------------------------------------------
    // Auto-presets
    // ------------------------------------------------------------------
    const PRESETS = {
        'site-to-site': {
            label: 'Site-to-Site',
            values: {
                type: 'tunnel', ike_version: '2', start_action: 'start',
                remote_access: false,
                local_auth: 'pubkey', remote_auth: 'pubkey',
                mobike: false, compress: false, forceudp: false,
                dpd_action: 'clear', close_action: 'start',
                ike_rekey: '14400', child_rekey: '3600', dpd_delay: '30',
                keyingtries: '0',
            },
            ike_proposals: ['aes256gcm16-prfsha256-modp2048'],
            esp_proposals: ['aes256gcm16-modp2048'],
        },
        'remote-access-server': {
            label: 'Remote Access Server',
            values: {
                type: 'tunnel', ike_version: '2', start_action: 'trap',
                remote_access: true,
                role: 'server',
                local_auth: 'pubkey', remote_auth: 'eap-mschapv2',
                mobike: true, compress: false, forceudp: true,
                dpd_action: 'clear', close_action: 'none',
                ike_rekey: '14400', child_rekey: '3600', dpd_delay: '30',
                keyingtries: '0',
            },
            ike_proposals: ['aes128gcm16-prfsha256-modp2048'],
            esp_proposals: ['aes128gcm16-modp2048'],
        },
        'remote-access-client': {
            label: 'Remote Access Client',
            values: {
                type: 'tunnel', ike_version: '2', start_action: 'start',
                remote_access: false,
                local_auth: 'eap-mschapv2', remote_auth: 'pubkey',
                mobike: true, compress: false, forceudp: true,
                dpd_action: 'clear', close_action: 'start',
                ike_rekey: '14400', child_rekey: '3600', dpd_delay: '30',
                vips: '',
                keyingtries: '0',
            },
            ike_proposals: ['aes128gcm16-prfsha256-modp2048'],
            esp_proposals: ['aes128gcm16-modp2048'],
        },
    };

    // ------------------------------------------------------------------
    // Picker helpers
    // ------------------------------------------------------------------

    // Set the value and display state of a picker field programmatically.
    // idOrIds: a UUID string, an array of UUID strings, or a comma-separated UUID string.
    // displayNames: optional display name(s) from backend _display enrichment.
    function setPickerValue(form, fieldName, idOrIds, displayNames) {
        const hiddenInput = form.querySelector('[data-js="set-picker-field"] input[name="' + fieldName + '"]');
        if (!hiddenInput) {
            return;
        }
        const wrapper = hiddenInput.closest('[data-js="set-picker-field"]');
        const labelEl = wrapper.querySelector('.js-set-picker-label');
        const openBtn = wrapper.querySelector('.js-set-picker-open');
        const clearBtn = wrapper.querySelector('.js-set-picker-clear');

        let ids;
        if (Array.isArray(idOrIds)) {
            ids = idOrIds.map(String).filter(Boolean);
        } else {
            ids = String(idOrIds || '').split(',').map(s => s.trim()).filter(Boolean);
        }

        const idStr = ids.join(',');
        hiddenInput.value = idStr;

        if (idStr) {
            let names;
            if (displayNames !== undefined) {
                names = Array.isArray(displayNames) ? displayNames : [displayNames];
            } else {
                names = ids;
            }
            if (labelEl) {
                labelEl.textContent = names.join(', ');
            }
            if (openBtn) {
                openBtn.classList.add('set-picker-trigger--has-value');
            }
            if (clearBtn) {
                clearBtn.classList.remove('sets-hidden');
            }
        } else {
            const placeholder = openBtn?.dataset.placeholder || 'Select…';
            if (labelEl) {
                labelEl.textContent = placeholder;
            }
            if (openBtn) {
                openBtn.classList.remove('set-picker-trigger--has-value');
            }
            if (clearBtn) {
                clearBtn.classList.add('sets-hidden');
            }
        }

        hiddenInput.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // Reset all picker fields inside a form to empty/placeholder state.
    function resetPickerFields(form) {
        form.querySelectorAll('[data-js="set-picker-field"], [data-js="label-picker-field"]').forEach(wrapper => {
            const hiddenInput = wrapper.querySelector('input[type="hidden"]');
            const labelEl = wrapper.querySelector('.js-set-picker-label');
            const openBtn = wrapper.querySelector('.js-set-picker-open');
            const clearBtn = wrapper.querySelector('.js-set-picker-clear');
            if (hiddenInput) {
                hiddenInput.value = '';
            }
            if (labelEl && openBtn) {
                labelEl.textContent = openBtn.dataset.placeholder || 'Select…';
            }
            if (openBtn) {
                openBtn.classList.remove('set-picker-trigger--has-value');
            }
            if (clearBtn) {
                clearBtn.classList.add('sets-hidden');
            }
        });
    }

    // ------------------------------------------------------------------
    // Fetch helpers — no fallback behaviour, throw on failure
    // ------------------------------------------------------------------
    async function sendCommand(command, data) {
        return apiClient.submit(command, data);
    }

    async function sendRequest(action, params) {
        return apiClient.request(action, params);
    }

    // ------------------------------------------------------------------
    // Tab switching
    // ------------------------------------------------------------------
    function initTabs() {
        const tabBar = document.getElementById('swan-tabs');
        if (!tabBar) {
            return;
        }
        tabBar.addEventListener('click', (e) => {
            const btn = e.target.closest('.std-tab-btn');
            if (!btn) {
                return;
            }
            const tab = btn.dataset.tab;
            tabBar.querySelectorAll('.std-tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            document.querySelectorAll('.std-tab-panel').forEach(p => {
                p.classList.toggle('active', p.dataset.tab === tab);
            });
        });
    }

    // ------------------------------------------------------------------
    // Collapsible section toggles (used by Advanced in connection form)
    // ------------------------------------------------------------------
    function initCollapsible() {
        document.querySelectorAll('.section-head--collapsible').forEach(heading => {
            heading.addEventListener('click', () => {
                const body = heading.nextElementSibling;
                if (!body || !body.matches('.swan-advanced-body, .swan-timers-body, .swan-tls-body')) {
                    return;
                }
                const isOpen = body.style.display !== 'none';
                body.style.display = isOpen ? 'none' : '';
                const indicator = heading.querySelector('.collapse-indicator');
                if (indicator) {
                    indicator.innerHTML = isOpen ? '&#9654;' : '&#9660;';
                }
            });
        });
    }

    // ------------------------------------------------------------------
    // Inline editor helpers (generic show / hide / reset)
    // ------------------------------------------------------------------
    function showEditor(containerId, titleText, saveText) {
        const container = document.getElementById(containerId);
        if (!container) {
            return;
        }
        const titleEl = container.querySelector('[data-js="inline-title"]');
        const saveBtn = container.querySelector('[data-js="inline-save"]');
        if (titleEl) {
            titleEl.textContent = titleText;
        }
        if (saveBtn) {
            saveBtn.textContent = saveText;
        }
        container.style.display = 'block';
        container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function hideEditor(containerId) {
        const container = document.getElementById(containerId);
        if (container) {
            container.style.display = 'none';
        }
    }

    function resetForm(form) {
        if (!form) {
            return;
        }
        form.reset();
        // Clear hidden id field
        const idField = form.querySelector('input[name="id"]');
        if (idField) {
            idField.value = '';
        }
        // Reset proposal lists
        form.querySelectorAll('.proposal-list').forEach(list => {
            list.innerHTML = '<em>No proposals yet</em>';
        });
        form.querySelectorAll('input[name="ike_proposals"], input[name="esp_proposals"]').forEach(inp => {
            inp.value = '[]';
        });
        // Reset picker fields
        resetPickerFields(form);
    }

    // ------------------------------------------------------------------
    // Set a form field value (handles selects, checkboxes, text inputs)
    // ------------------------------------------------------------------
    function setFieldValue(form, name, value) {
        const el = form.querySelector('[name="' + name + '"]');
        if (!el) {
            return;
        }
        if (el.type === 'checkbox') {
            el.checked = !!value;
        } else {
            el.value = value;
        }
        el.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // ------------------------------------------------------------------
    // Connection form — show / hide / populate
    // ------------------------------------------------------------------
    let editingConnId = null;

    function showConnectionForm(conn) {
        const form = document.querySelector('[data-js="swan-conn-form"]');
        if (!form) {
            return;
        }
        resetForm(form);
        const isEdit = conn && conn.id;
        editingConnId = isEdit ? conn.id : null;

        if (isEdit) {
            // Populate plain form fields (non-picker)
            const plainFields = [
                'name', 'type', 'ike_version', 'start_action', 'local_id',
                'local_auth', 'local_cert', 'eap_id',
                'remote_id', 'remote_auth', 'remote_cert',
                'role',
                'ike_rekey', 'reauth_time', 'child_rekey', 'dpd_delay', 'dpd_timeout', 'dpd_action',
                'close_action', 'pool',
                'keyingtries', 'unique', 'fragmentation',
            ];
            plainFields.forEach(f => {
                if (conn[f] !== undefined && conn[f] !== null) {
                    setFieldValue(form, f, conn[f]);
                }
            });
            // Checkboxes
            setFieldValue(form, 'remote_access', !!conn.remote_access);
            setFieldValue(form, 'mobike', !!conn.mobike);
            setFieldValue(form, 'compress', !!conn.compress);
            setFieldValue(form, 'forceudp', !!conn.forceudp);
            setFieldValue(form, 'send_certreq', conn.send_certreq !== false);

            // Hidden id
            const idField = form.querySelector('input[name="id"]');
            if (idField) {
                idField.value = conn.id;
            }

            // interface_id uses a server-rendered <select>
            if (conn.interface_id !== undefined) {
                setFieldValue(form, 'interface_id', conn.interface_id);
            }
            // Local address — picker, mutually exclusive with interface_id
            if (conn.local_addrs) {
                setPickerValue(form, 'local_addrs', conn.local_addrs, conn.local_addrs_display?.name);
            }
            // Picker fields — UUIDs
            if (conn.remote_addrs) {
                setPickerValue(form, 'remote_addrs', conn.remote_addrs, conn.remote_addrs_display?.name);
            }
            if (conn.local_ts) {
                setPickerValue(form, 'local_ts', conn.local_ts, conn.local_ts_display?.map(d => d.name));
            }
            if (conn.remote_ts) {
                setPickerValue(form, 'remote_ts', conn.remote_ts, conn.remote_ts_display?.map(d => d.name));
            }
            // XFRM interface ID label pickers (UUID strings, optional)
            if (conn.if_id_in !== undefined && conn.if_id_in !== null) {
                setPickerValue(form, 'if_id_in', conn.if_id_in);
            }
            if (conn.if_id_out !== undefined && conn.if_id_out !== null) {
                setPickerValue(form, 'if_id_out', conn.if_id_out);
            }
            // Virtual IPs (remote-access client)
            if (conn.vips) {
                setPickerValue(form, 'vips', conn.vips, conn.vips_display?.name);
            }

            // Remote CACerts — multi-select; populate from array
            if (conn.remote_cacerts !== undefined && conn.remote_cacerts !== null) {
                const cacertsArr = Array.isArray(conn.remote_cacerts)
                    ? conn.remote_cacerts
                    : [conn.remote_cacerts];
                const cacertSelect = form.querySelector('select[name="remote_cacerts[]"]');
                if (cacertSelect) {
                    Array.from(cacertSelect.options).forEach(opt => {
                        opt.selected = cacertsArr.includes(opt.value);
                    });
                }
            }

            // Proposals
            if (Array.isArray(conn.ike_proposals)) {
                setProposals(form, 'ike', conn.ike_proposals);
            }
            if (Array.isArray(conn.esp_proposals)) {
                setProposals(form, 'esp', conn.esp_proposals);
            }
        }

        // Apply conditional visibility after populating
        applyConnectionConditions(form);
        showEditor('swan-conn-inline', isEdit ? 'Edit Connection' : 'Add Connection', isEdit ? 'Save' : 'Create');
    }

    function hideConnectionForm() {
        editingConnId = null;
        hideEditor('swan-conn-inline');
    }

    // ------------------------------------------------------------------
    // Pool form — show / hide / populate
    // ------------------------------------------------------------------
    let editingPoolId = null;

    function showPoolForm(pool) {
        const form = document.querySelector('[data-js="swan-pool-form"]');
        if (!form) {
            return;
        }
        resetForm(form);
        const isEdit = pool && pool.id;
        editingPoolId = isEdit ? pool.id : null;

        if (isEdit) {
            if (pool.name !== undefined) {
                setFieldValue(form, 'name', pool.name);
            }
            // Picker fields
            if (pool.addrs) {
                setPickerValue(form, 'addrs', pool.addrs, pool.addrs_display?.name);
            }
            if (pool.dns) {
                setPickerValue(form, 'dns', pool.dns, pool.dns_display?.name);
            }
            if (pool.split_include) {
                setPickerValue(form, 'split_include', pool.split_include, pool.split_include_display?.map(d => d.name));
            }
            if (pool.split_exclude) {
                setPickerValue(form, 'split_exclude', pool.split_exclude, pool.split_exclude_display?.map(d => d.name));
            }
        }

        showEditor('swan-pool-inline', isEdit ? 'Edit Address Pool' : 'Add Address Pool', isEdit ? 'Save' : 'Create');
    }

    function hidePoolForm() {
        editingPoolId = null;
        hideEditor('swan-pool-inline');
    }

    // ------------------------------------------------------------------
    // Secret form — show / hide / populate
    // ------------------------------------------------------------------
    let editingSecretId = null;

    function showSecretForm(sec) {
        const form = document.querySelector('[data-js="swan-secret-form"]');
        if (!form) {
            return;
        }
        resetForm(form);
        const isEdit = sec && sec.id;
        editingSecretId = isEdit ? sec.id : null;

        // Value is required on add, optional on edit (write-only policy)
        const valueInput = form.querySelector('[data-js="swan-secret-value"]');
        if (valueInput) {
            if (isEdit) {
                valueInput.removeAttribute('required');
            } else {
                valueInput.setAttribute('required', '');
            }
        }

        if (isEdit) {
            ['label', 'type', 'username', 'local_id', 'remote_id'].forEach(f => {
                if (sec[f] !== undefined) {
                    setFieldValue(form, f, sec[f]);
                }
            });
            // Value is write-only — never populated on edit
        }

        applySecretConditions(form);
        showEditor('swan-secret-inline', isEdit ? 'Edit Secret' : 'Add Secret', isEdit ? 'Save' : 'Add');
    }

    function hideSecretForm() {
        editingSecretId = null;
        hideEditor('swan-secret-inline');
    }

    // ------------------------------------------------------------------
    // Connection form — conditional visibility
    // ------------------------------------------------------------------
    function applyConnectionConditions(form) {
        if (!form) {
            return;
        }

        const ikeVersion = form.querySelector('[name="ike_version"]')?.value;
        const localAuth = form.querySelector('[name="local_auth"]')?.value;
        const remoteAuth = form.querySelector('[name="remote_auth"]')?.value;
        const remoteAccess = form.querySelector('[name="remote_access"]')?.checked;
        const dpdDelay = parseInt(form.querySelector('[name="dpd_delay"]')?.value, 10);

        // Filter auth options by IKE version and by remote-access mode
        filterAuthOptions(form, ikeVersion, remoteAccess);

        // Certificate rows — visible when auth is pubkey or eap-tls
        const certAuths = ['pubkey', 'eap-tls'];
        toggleCond(form, 'local-cert', certAuths.includes(localAuth));
        toggleCond(form, 'remote-cert', certAuths.includes(remoteAuth));

        // IKEv2-only fields
        const isV2 = ikeVersion === '2';
        toggleCond(form, 'reauth-time', isV2);
        toggleCond(form, 'mobike', isV2);

        // Remote TS — hidden in remote-access mode; clear stale value when hiding
        toggleCond(form, 'remote-ts', !remoteAccess);
        if (remoteAccess) {
            setPickerValue(form, 'remote_ts', '');
        }

        // Virtual IPs — shown for remote-access clients
        const role = form.querySelector('[name="role"]')?.value;
        toggleCond(form, 'vips', remoteAccess && role === 'client');

        // Pool — shown only in remote-access mode
        toggleCond(form, 'pool', remoteAccess);

        // Role — only relevant for remote-access (roadwarrior) setups
        toggleCond(form, 'role', remoteAccess);
        const roleEl = form.querySelector('[name="role"]');
        if (roleEl) {
            roleEl.required = !!remoteAccess;
        }

        // DPD action — shown only when dpd_delay > 0
        toggleCond(form, 'dpd-action', dpdDelay > 0);

        // DPD timeout — IKEv1 only
        toggleCond(form, 'dpd-timeout', ikeVersion === '1');

        // EAP identity — shown when local_auth is an EAP method
        const eapAuths = ['eap-mschapv2', 'eap-tls', 'eap-radius'];
        toggleCond(form, 'eap-id', eapAuths.includes(localAuth));

        // local_addrs / interface_id mutual exclusion
        // local_addrs (address-set picker) is the standard method;
        // interface_id (<select>) is a convenience override.
        // Selecting one clears the other.
        const localAddrsInput = form.querySelector('input[name="local_addrs"]');
        const ifaceIdSel = form.querySelector('[name="interface_id"]');
        const localAddrsVal = localAddrsInput?.value || '';
        const ifaceIdVal = ifaceIdSel?.value || '';

        if (localAddrsVal && ifaceIdVal) {
            // Both have values — local_addrs wins, clear interface_id
            ifaceIdSel.value = '';
            ifaceIdSel.dispatchEvent(new Event('change', { bubbles: true }));
        }

        // Interface warning — show if no selectable interfaces (check interface_id select)
        const ifaceWarning = form.querySelector('[data-js="iface-warning-row"]');
        if (ifaceIdSel && ifaceWarning) {
            const hasSelectable = Array.from(ifaceIdSel.options).some(o => o.value && !o.disabled);
            ifaceWarning.style.display = hasSelectable ? 'none' : '';
        }

    }

    function toggleCond(form, condName, show) {
        form.querySelectorAll('[data-cond="' + condName + '"]').forEach(el => {
            el.style.display = show ? '' : 'none';
        });
    }

    function filterAuthOptions(form, ikeVersion, remoteAccess) {
        form.querySelectorAll('select[name="local_auth"], select[name="remote_auth"]').forEach(sel => {
            const current = sel.value;
            let firstVisible = null;
            let currentStillValid = false;

            Array.from(sel.options).forEach(opt => {
                const versions = (opt.dataset.versions || '').split(',');
                const allowedByVersion = versions.includes(ikeVersion);
                const isLocalSelect = sel.name === 'local_auth';
                // In remote-access mode, restrict local_auth to pubkey/psk only
                // (the gateway authenticates itself with a cert or PSK, not EAP).
                // remote_auth is intentionally left unrestricted: remote peers
                // may use any method (EAP, pubkey, psk).
                const allowedByRemoteAccess = !remoteAccess || !isLocalSelect
                    || ['pubkey', 'psk'].includes(opt.value);
                const allowed = allowedByVersion && allowedByRemoteAccess;
                opt.hidden = !allowed;
                opt.disabled = !allowed;
                if (allowed && !firstVisible) {
                    firstVisible = opt.value;
                }
                if (allowed && opt.value === current) {
                    currentStillValid = true;
                }
            });

            if (!currentStillValid && firstVisible) {
                sel.value = firstVisible;
                sel.dispatchEvent(new Event('change', { bubbles: true }));
            }
        });
    }

    function attachConnectionListeners(form) {
        if (!form) {
            return;
        }
        const condFields = ['ike_version', 'local_auth', 'remote_auth', 'remote_access', 'dpd_delay', 'pool', 'role', 'local_addrs', 'interface_id'];
        condFields.forEach(name => {
            const el = form.querySelector('[name="' + name + '"]');
            if (el) {
                el.addEventListener('change', () => applyConnectionConditions(form));
                if (el.type === 'number' || el.type === 'text' || el.type === 'hidden') {
                    el.addEventListener('input', () => applyConnectionConditions(form));
                }
            }
        });

        // Clear auto-preset highlight when user fills in a highlighted field
        form.addEventListener('input', (e) => {
            const col = e.target.closest('.auto-missing');
            if (col && e.target.value) {
                col.classList.remove('auto-missing');
                const note = col.querySelector('.auto-missing-note');
                if (note) {
                    note.remove();
                }
            }
        });
        form.addEventListener('change', (e) => {
            const col = e.target.closest('.auto-missing');
            if (col && e.target.value) {
                col.classList.remove('auto-missing');
                const note = col.querySelector('.auto-missing-note');
                if (note) {
                    note.remove();
                }
            }
        });
    }

    // ------------------------------------------------------------------
    // Secret form — conditional visibility
    // ------------------------------------------------------------------
    function applySecretConditions(form) {
        if (!form) {
            return;
        }
        const secretType = form.querySelector('[name="type"]')?.value;
        // Username row — only for EAP types
        toggleCond(form, 'secret-username', secretType === 'eap-mschapv2');
        // IDs row — shown for IKE (PSK) type
        toggleCond(form, 'secret-ids', secretType === 'ike');
    }

    function attachSecretListeners(form) {
        if (!form) {
            return;
        }
        const typeSelect = form.querySelector('[name="type"]');
        if (typeSelect) {
            typeSelect.addEventListener('change', () => applySecretConditions(form));
        }
    }

    // ------------------------------------------------------------------
    // PSK generator and clipboard
    // ------------------------------------------------------------------
    function generatePSK() {
        const arr = new Uint8Array(32);
        crypto.getRandomValues(arr);
        return Array.from(arr, b => b.toString(16).padStart(2, '0')).join('');
    }

    function attachPSKHandlers(container) {
        const generateBtn = container.querySelector('[data-js="generate-psk"]');
        const copyBtn = container.querySelector('[data-js="copy-secret"]');
        const valueInput = container.querySelector('[data-js="swan-secret-value"]');

        if (generateBtn && valueInput) {
            generateBtn.addEventListener('click', () => {
                valueInput.value = generatePSK();
            });
        }

        if (copyBtn && valueInput) {
            copyBtn.addEventListener('click', async () => {
                try {
                    await navigator.clipboard.writeText(valueInput.value);
                    const orig = copyBtn.textContent;
                    copyBtn.textContent = 'Copied';
                    setTimeout(() => { copyBtn.textContent = orig; }, 1500);
                } catch (err) {
                    showModal('<p>Failed to copy to clipboard: ' + err.message + '</p>');
                }
            });
        }
    }

    // ------------------------------------------------------------------
    // Proposal builder (selects rendered server-side; only JS logic remains)
    // ------------------------------------------------------------------
    function addProposal(builder) {
        const prefix = builder.dataset.prefix;
        const encSel = builder.querySelector('[data-role="encryption"]');
        const intSel = builder.querySelector('[data-role="integrity"]');
        const dhSel = builder.querySelector('[data-role="dh"]');
        const prfSel = builder.querySelector('[data-role="prf"]');

        if (!encSel || !dhSel) {
            return;
        }

        const parts = [encSel.value];
        if (!isAead(encSel.value) && intSel) {
            parts.push(intSel.value);
        }
        if (prfSel) {
            parts.push(prfSel.value);
        }
        parts.push(dhSel.value);

        const proposal = parts.join('-');
        const hiddenInput = builder.querySelector('input[name="' + prefix + '_proposals"]');
        const current = getProposals(hiddenInput);

        if (current.includes(proposal)) {
            return;
        }
        current.push(proposal);
        hiddenInput.value = JSON.stringify(current);
        renderProposalList(builder, prefix, current);
    }

    function removeProposal(builder, index) {
        const prefix = builder.dataset.prefix;
        const hiddenInput = builder.querySelector('input[name="' + prefix + '_proposals"]');
        const current = getProposals(hiddenInput);
        current.splice(index, 1);
        hiddenInput.value = JSON.stringify(current);
        renderProposalList(builder, prefix, current);
    }

    function getProposals(hiddenInput) {
        try {
            return JSON.parse(hiddenInput.value);
        } catch {
            return [];
        }
    }

    function setProposals(form, prefix, list) {
        const builder = form.querySelector('.proposal-builder[data-prefix="' + prefix + '"]');
        if (!builder) {
            return;
        }
        const hiddenInput = builder.querySelector('input[name="' + prefix + '_proposals"]');
        hiddenInput.value = JSON.stringify(list);
        renderProposalList(builder, prefix, list);
    }

    function renderProposalList(builder, prefix, list) {
        const listEl = builder.querySelector('[data-js="' + prefix + '-proposal-list"]');
        if (!listEl) {
            return;
        }
        if (list.length === 0) {
            listEl.innerHTML = '<em>No proposals yet</em>';
            return;
        }
        listEl.innerHTML = list.map((p, i) =>
            '<div class="proposal-entry">' +
                '<span>' + p + '</span>' +
                ' <button type="button" class="btn btn-sm proposal-remove" data-index="' + i + '">&times;</button>' +
            '</div>'
        ).join('');
    }

    // ------------------------------------------------------------------
    // Auto-preset application + field highlighting
    // ------------------------------------------------------------------
    function ensureAutoStyle() {
        if (document.getElementById('vpn-auto-style')) {
            return;
        }
        const s = document.createElement('style');
        s.id = 'vpn-auto-style';
        s.textContent =
            '.auto-missing { outline: 2px solid #e06 !important; box-shadow: 0 0 6px rgba(224,6,102,0.12) !important; }' +
            '.auto-missing-note { display:block; color:#e06; font-size:0.9em; margin-top:4px; }';
        document.head.appendChild(s);
    }

    function clearHighlights(form) {
        if (!form) {
            return;
        }
        form.querySelectorAll('.auto-missing').forEach(el => el.classList.remove('auto-missing'));
        form.querySelectorAll('.auto-missing-note').forEach(n => n.remove());
    }

    function highlightField(el, message) {
        if (!el) {
            return;
        }
        const col = el.closest('.form-col') || el;
        col.classList.add('auto-missing');
        if (!col.querySelector('.auto-missing-note')) {
            const note = document.createElement('div');
            note.className = 'auto-missing-note';
            note.textContent = message || 'Please provide a value for this field.';
            col.appendChild(note);
        }
    }

    function highlightMissingFields(form) {
        ensureAutoStyle();
        clearHighlights(form);
        const missing = [];

        const nameEl = form.querySelector('[name="name"]');
        if (nameEl && !nameEl.value) {
            highlightField(nameEl, 'Provide a connection name for this VPN');
            missing.push(nameEl);
        }

        const iface = form.querySelector('input[name="local_addrs"]');
        if (iface && !iface.value) {
            highlightField(iface, 'Select a local address set for IKE endpoint');
            missing.push(iface);
        }

        const remoteAccess = form.querySelector('[name="remote_access"]')?.checked;
        const pool = form.querySelector('[name="pool"]');
        if (remoteAccess && pool && !pool.value) {
            highlightField(pool, 'Select or create a pool for remote clients');
            missing.push(pool);
        }

        // Role is required for remote-access connections
        const roleEl = form.querySelector('[name="role"]');
        if (remoteAccess && roleEl && !roleEl.value) {
            highlightField(roleEl, 'Select role: client or server');
            missing.push(roleEl);
        }

        // Remote address is required when start_action is start or trap
        // (except in roadwarrior mode where %any is acceptable)
        const startAction = form.querySelector('[name="start_action"]')?.value;
        const needsRemoteAddr = (startAction === 'start' || startAction === 'trap') && !remoteAccess;
        const remoteAddrs = form.querySelector('[name="remote_addrs"]');
        if (needsRemoteAddr && remoteAddrs && !remoteAddrs.value) {
            highlightField(remoteAddrs, 'Remote address is required for start/trap mode (or use Remote Access)');
            missing.push(remoteAddrs);
        }

        // Tunnel connections require traffic selectors, a pool, or XFRM interface IDs
        const connType = form.querySelector('[name="type"]')?.value;
        if (connType === 'tunnel') {
            const localTs = form.querySelector('[name="local_ts"]');
            const remoteTs = form.querySelector('[name="remote_ts"]');
            const hasLocalTs = localTs && localTs.value;
            const hasRemoteTs = remoteTs && remoteTs.value && remoteTs.closest('[data-cond]')?.style.display !== 'none';
            const hasPool = pool && pool.value && pool.closest('[data-cond]')?.style.display !== 'none';
            const ifIdIn = parseInt(form.querySelector('[name="if_id_in"]')?.value, 10) || 0;
            const ifIdOut = parseInt(form.querySelector('[name="if_id_out"]')?.value, 10) || 0;
            const hasXfrm = ifIdIn > 0 || ifIdOut > 0;

            if (!hasLocalTs && !hasRemoteTs && !hasPool && !hasXfrm) {
                if (localTs) {
                    highlightField(localTs, 'Tunnel needs traffic selectors, a pool, or XFRM interface IDs');
                    missing.push(localTs);
                }
                if (remoteTs && remoteTs.closest('[data-cond]')?.style.display !== 'none') {
                    highlightField(remoteTs, 'Tunnel needs traffic selectors, a pool, or XFRM interface IDs');
                    missing.push(remoteTs);
                }
                if (pool && pool.closest('[data-cond]')?.style.display !== 'none') {
                    highlightField(pool, 'Tunnel needs traffic selectors, a pool, or XFRM interface IDs');
                    missing.push(pool);
                }
                const ifIdInEl = form.querySelector('[name="if_id_in"]');
                if (ifIdInEl) {
                    highlightField(ifIdInEl, 'Tunnel needs traffic selectors, a pool, or XFRM interface IDs');
                    missing.push(ifIdInEl);
                }
            }
        }

        const localAuth = form.querySelector('[name="local_auth"]')?.value;
        const remoteAuth = form.querySelector('[name="remote_auth"]')?.value;
        const certAuths = ['pubkey', 'eap-tls'];

        const localCert = form.querySelector('[name="local_cert"]');
        if (certAuths.includes(localAuth) && localCert && !localCert.value) {
            highlightField(localCert, 'Select a local certificate');
            missing.push(localCert);
        }

        const remoteCert = form.querySelector('[name="remote_cert"]');
        if (certAuths.includes(remoteAuth) && remoteCert && !remoteCert.value) {
            highlightField(remoteCert, 'Select a remote certificate to validate peer');
            missing.push(remoteCert);
        }

        if (missing.length > 0) {
            try { missing[0].focus(); } catch (e) { /* noop */ }
        }
        return missing.length === 0;
    }

    function applyPreset(form, preset) {
        resetForm(form);
        Object.entries(preset.values).forEach(([key, val]) => {
            setFieldValue(form, key, val);
        });
        if (preset.ike_proposals) {
            setProposals(form, 'ike', preset.ike_proposals);
        }
        if (preset.esp_proposals) {
            setProposals(form, 'esp', preset.esp_proposals);
        }
        applyConnectionConditions(form);
        highlightMissingFields(form);
        showModal('<p>Applied <strong>' + preset.label + '</strong> preset. Fill in the highlighted fields.</p>');
    }

    // ------------------------------------------------------------------
    // Data collection from forms
    // ------------------------------------------------------------------
    // Fields that must be sent as integers to the backend
    const NUMERIC_FIELDS = ['ike_version', 'ike_rekey', 'reauth_time', 'child_rekey', 'dpd_delay', 'dpd_timeout', 'keyingtries'];
    // Picker fields that map to arrays of UUIDs on the backend
    const ARRAY_PICKER_FIELDS = ['local_ts', 'remote_ts'];
    // Picker fields that map to single UUID strings on the backend
    const SINGLE_PICKER_FIELDS = ['remote_addrs', 'local_addrs', 'if_id_in', 'if_id_out', 'vips'];
    // Multi-select fields that map to arrays of UUIDs (name="field[]")
    const MULTI_SELECT_FIELDS = ['remote_cacerts'];
    // Pool picker fields that map to arrays
    const POOL_ARRAY_PICKER_FIELDS = ['split_include', 'split_exclude'];
    // Pool picker fields that map to single UUIDs
    const POOL_SINGLE_PICKER_FIELDS = ['addrs', 'dns'];

    function getConnectionData(form) {
        const data = {};

        form.querySelectorAll('input, select, textarea').forEach(el => {
            if (!el.name || el.type === 'button' || el.type === 'submit' || el.type === 'hidden') {
                return;
            }
            if (el.type === 'checkbox') {
                data[el.name] = el.checked;
                return;
            }
            // Skip fields in hidden conditional rows
            const condParent = el.closest('[data-cond]');
            if (condParent && condParent.style.display === 'none') {
                return;
            }
            // Skip hidden auth options (filtered by IKE version)
            if (el.tagName === 'SELECT' && el.selectedOptions[0]?.hidden) {
                return;
            }

            // Cast numeric fields to integers for the backend
            if (NUMERIC_FIELDS.includes(el.name)) {
                data[el.name] = parseInt(el.value, 10) || 0;
            } else {
                data[el.name] = el.value;
            }
        });

        // Hidden id field
        const idField = form.querySelector('input[name="id"]');
        if (idField && idField.value) {
            data.id = idField.value;
        }

        // Parse proposal JSON arrays
        const ikeInput = form.querySelector('input[name="ike_proposals"]');
        const espInput = form.querySelector('input[name="esp_proposals"]');
        if (ikeInput) {
            data.ike_proposals = getProposals(ikeInput);
        }
        if (espInput) {
            data.esp_proposals = getProposals(espInput);
        }

        // Picker fields: single UUID strings
        SINGLE_PICKER_FIELDS.forEach(name => {
            const input = form.querySelector('input[name="' + name + '"]');
            if (!input) {
                return;
            }
            data[name] = input.value || '';
        });

        // Picker fields: arrays of UUIDs (split comma-separated hidden input value)
        ARRAY_PICKER_FIELDS.forEach(name => {
            const input = form.querySelector('input[name="' + name + '"]');
            if (!input) {
                return;
            }
            // Skip if the enclosing conditional column is hidden
            const condParent = input.closest('[data-cond]');
            if (condParent && condParent.style.display === 'none') {
                delete data[name];
                return;
            }
            data[name] = input.value ? input.value.split(',').map(s => s.trim()).filter(Boolean) : [];
        });

        // Multi-select fields: collect all selected values as arrays
        MULTI_SELECT_FIELDS.forEach(name => {
            const select = form.querySelector('select[name="' + name + '[]"]');
            if (!select) {
                return;
            }
            const condParent = select.closest('[data-cond]');
            if (condParent && condParent.style.display === 'none') {
                return;
            }
            const vals = Array.from(select.selectedOptions).map(o => o.value).filter(Boolean);
            if (vals.length > 0) {
                data[name] = vals;
            }
        });

        return data;
    }

    function getPoolData(form) {
        const data = {};
        form.querySelectorAll('input, select, textarea').forEach(el => {
            if (!el.name || el.type === 'button' || el.type === 'submit' || el.type === 'hidden') {
                return;
            }
            if (el.type === 'checkbox') {
                data[el.name] = el.checked;
                return;
            }
            data[el.name] = el.value;
        });

        // Picker fields: single UUID
        POOL_SINGLE_PICKER_FIELDS.forEach(name => {
            const input = form.querySelector('input[name="' + name + '"]');
            if (input) {
                data[name] = input.value || '';
            }
        });

        // Picker fields: arrays of UUIDs
        POOL_ARRAY_PICKER_FIELDS.forEach(name => {
            const input = form.querySelector('input[name="' + name + '"]');
            if (input) {
                data[name] = input.value ? input.value.split(',').map(s => s.trim()).filter(Boolean) : [];
            }
        });

        return data;
    }

    function getSecretData(form) {
        const data = {};
        form.querySelectorAll('input, select, textarea').forEach(el => {
            if (!el.name || el.type === 'button' || el.type === 'submit' || el.type === 'hidden') {
                return;
            }
            if (el.type === 'checkbox') {
                data[el.name] = el.checked;
                return;
            }
            // Skip fields in hidden conditional rows
            const condParent = el.closest('[data-cond]');
            if (condParent && condParent.style.display === 'none') {
                return;
            }
            data[el.name] = el.value;
        });
        return data;
    }

    // ------------------------------------------------------------------
    // CRUD operations
    // ------------------------------------------------------------------
    async function saveConnection() {
        const form = document.querySelector('[data-js="swan-conn-form"]');
        if (!form || !form.checkValidity()) {
            form?.reportValidity();
            return;
        }
        if (!highlightMissingFields(form)) {
            return;
        }
        const data = getConnectionData(form);
        const command = editingConnId ? 'swan_edit_connection' : 'swan_add_connection';
        try {
            const result = await sendCommand(command, { connection: data });
            showApiResult(result, { closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    async function deleteConnection(id) {
        if (!confirm('Delete this connection?')) {
            return;
        }
        try {
            const result = await sendCommand('swan_delete_connection', { id });
            showApiResult(result, { closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    async function initiateConnection(id) {
        try {
            const result = await sendCommand('swan_conn_up', { id });
            const data = result.result || {};

            if (data.already_up) {
                showApiResult(
                    { status: 'success', response_msg: 'El túnel ya estaba establecido' },
                    { closeText: 'Cerrar' }
                );
            } else if (data.already_connecting) {
                showApiResult(
                    { status: 'success', response_msg: 'El túnel ya se está estableciendo' },
                    { closeText: 'Cerrar' }
                );
            } else {
                showApiResult(result, { closeText: 'Cerrar', reloadOnOk: true });
            }
        } catch (err) {
            showApiResult(
                { status: 'error', response_msg: err.message },
                { title: 'Error', closeText: 'Cerrar' }
            );
        }
    }

    async function teardownConnection(id) {
        try {
            const result = await sendCommand('swan_conn_down', { id });
            showApiResult(result, { closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    async function savePool() {
        const form = document.querySelector('[data-js="swan-pool-form"]');
        if (!form || !form.checkValidity()) {
            form?.reportValidity();
            return;
        }
        const data = getPoolData(form);
        if (editingPoolId) {
            data.id = editingPoolId;
        }
        const command = editingPoolId ? 'swan_edit_pool' : 'swan_add_pool';
        try {
            const result = await sendCommand(command, { pool: data });
            showApiResult(result, { closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    async function deletePool(id) {
        if (!confirm('Delete this pool?')) {
            return;
        }
        try {
            const result = await sendCommand('swan_delete_pool', { id });
            showApiResult(result, { closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    async function saveSecret() {
        const form = document.querySelector('[data-js="swan-secret-form"]');
        if (!form || !form.checkValidity()) {
            form?.reportValidity();
            return;
        }
        const data = getSecretData(form);
        if (editingSecretId) {
            data.id = editingSecretId;
        }
        const command = editingSecretId ? 'swan_edit_secret' : 'swan_add_secret';
        try {
            const result = await sendCommand(command, { secret: data });
            showApiResult(result, { closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    async function deleteSecret(id) {
        if (!confirm('Delete this secret?')) {
            return;
        }
        try {
            const result = await sendCommand('swan_delete_secret', { id });
            showApiResult(result, { closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    async function saveGlobalConfig(form) {
        const data = {};
        form.querySelectorAll('input, select').forEach(el => {
            if (!el.name || el.type === 'button' || el.type === 'submit') {
                return;
            }
            if (el.type === 'checkbox') {
                data[el.name] = el.checked;
            } else {
                data[el.name] = el.value;
            }
        });

        // Nest tls_* fields under a tls object
        const tlsFlatFields = [
            'tls_version_min', 'tls_version_max',
            'tls_cipher', 'tls_ke_group', 'tls_key_exchange', 'tls_mac',
            'tls_signature', 'tls_suites',
        ];
        const tlsCheckboxFields = ['tls_send_certreq_authorities'];

        const tlsData = {};
        let hasTls = false;

        tlsFlatFields.forEach(f => {
            if (data[f]) {
                // Strip tls_ prefix for the nested key
                const nestedKey = f.replace(/^tls_/, '');
                tlsData[nestedKey] = data[f];
                hasTls = true;
            }
            delete data[f];
        });

        tlsCheckboxFields.forEach(f => {
            if (data[f] !== undefined) {
                const nestedKey = f.replace(/^tls_/, '');
                tlsData[nestedKey] = data[f];
                hasTls = true;
            }
            delete data[f];
        });

        if (hasTls) {
            data.tls = tlsData;
        }

        // Nest x509_enforce_critical under a x509 object
        if (data.x509_enforce_critical !== undefined) {
            data.x509 = { enforce_critical: data.x509_enforce_critical };
        }
        delete data.x509_enforce_critical;

        // Collect interfaces_use multi-select as array of UUIDs
        const ifaceUseSelect = form.querySelector('select[name="interfaces_use[]"]');
        if (ifaceUseSelect) {
            const selected = Array.from(ifaceUseSelect.selectedOptions)
                .map(o => o.value)
                .filter(Boolean);
            data.interfaces_use = selected;
            delete data['interfaces_use[]'];
        }

        try {
            const result = await sendCommand('swan_set_global_config', { config: data });
            showApiResult(result, { closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    async function reloadAll() {
        try {
            const result = await sendCommand('swan_reload_all', {});
            showApiResult(result, { closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    // ------------------------------------------------------------------
    // Status refresh
    // ------------------------------------------------------------------
    function formatBytes(bytes) {
        if (!bytes || bytes === 0) {
            return '0 B';
        }
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
        return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + units[i];
    }

    function buildIkeProposal(sa) {
        const encr = sa['encr-alg'] || '';
        const keysize = sa['encr-keysize'] ? String(sa['encr-keysize']) : '';
        const encrFull = encr ? encr + keysize : '';
        const parts = [encrFull, sa['integ-alg'] || '', sa['prf-alg'] || '', sa['dh-group'] || ''].filter(Boolean);
        return parts.length > 0 ? parts.join('-') : '—';
    }

    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    /** Map IKE state to std-badge variant suffix. */
    function badgeVariant(state) {
        const map = {
            up: 'success', established: 'success', installed: 'success',
            down: 'danger',
            connecting: 'info', created: 'info',
            passive: 'muted',
            rekeyed: 'warning', rekeying: 'warning', warning: 'warning'
        };
        const s = (state || '').toLowerCase();
        return map[s] || '';
    }

    async function refreshStatus() {
        try {
            const result = await sendRequest('swan_get_status');
            if (result.status !== 'success' || !Array.isArray(result.result)) {
                showModal('<p>Failed to refresh status.</p>');
                return;
            }
            const tbody = document.querySelector('#swan-status-table tbody');
            if (!tbody) {
                return;
            }
            const rows = result.result;
            if (rows.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" class="text-center">No active SAs</td></tr>';
                return;
            }
            tbody.innerHTML = rows.map(sa => {
                const state = (sa.state || 'down').toLowerCase();
                const proposal = buildIkeProposal(sa);
                const children = Array.isArray(sa.children) ? sa.children : [];
                const hasChildren = children.length > 0;

                let totalBytesIn = 0;
                let totalBytesOut = 0;
                const childrenHtml = children.map(child => {
                    const cState = (child.state || 'down').toLowerCase();
                    const localTsRaw = child['local-ts'] || '';
                    const remoteTsRaw = child['remote-ts'] || '';
                    const localTs = Array.isArray(localTsRaw) ? localTsRaw.join(', ') : String(localTsRaw);
                    const remoteTs = Array.isArray(remoteTsRaw) ? remoteTsRaw.join(', ') : String(remoteTsRaw);
                    const bytesIn = parseInt(child['bytes-in'], 10) || 0;
                    const bytesOut = parseInt(child['bytes-out'], 10) || 0;
                    totalBytesIn += bytesIn;
                    totalBytesOut += bytesOut;
                    return '<tr class="swan-child-row" data-ike-parent="' + sa.uniqueid + '" style="display:none;">' +
                        '<td></td>' +
                        '<td>' +
                            '<span class="swan-child-name">' + escapeHtml(child.name || '') + '</span>' +
                            '<div class="swan-sub text-muted">reqid ' + escapeHtml(String(child.uniqueid || '')) + '</div>' +
                        '</td>' +
                        '<td><span class="std-badge std-badge--' + badgeVariant(cState) + '">' + cState.charAt(0).toUpperCase() + cState.slice(1) + '</span></td>' +
                        '<td>' +
                            (localTs || remoteTs ? '<div class="swan-sub">' + escapeHtml(localTs) + ' → ' + escapeHtml(remoteTs) + '</div>' : '') +
                            '<div class="swan-sub text-muted">' + escapeHtml(child.mode || '') + ' / ' + escapeHtml(child.protocol || '') + '</div>' +
                        '</td>' +
                        '<td class="text-muted">—</td>' +
                        '<td>' + (child['install-time'] || '') + '</td>' +
                        '<td>' + (child['rekey-time'] || '') + '</td>' +
                        '<td>' +
                            '<span class="swan-traffic-in">↓ ' + formatBytes(bytesIn) + '</span> ' +
                            '<span class="swan-traffic-out">↑ ' + formatBytes(bytesOut) + '</span>' +
                            '<div class="swan-sub text-muted">' + (child['packets-in'] || 0) + ' / ' + (child['packets-out'] || 0) + ' pkt</div>' +
                        '</td>' +
                    '</tr>';
                }).join('');

                return '<tr class="swan-ike-row" data-ike-id="' + sa.uniqueid + '">' +
                    '<td class="swan-expand-col">' +
                        (hasChildren ? '<button class="swan-expand-btn" data-js="swan-expand-ike" title="Show CHILD_SAs">▶</button>' : '') +
                    '</td>' +
                    '<td>' +
                        '<span class="swan-ike-name">' + escapeHtml(sa.name || '') + '</span>' +
                        (sa['remote-id'] ? '<div class="swan-sub">' + escapeHtml(sa['remote-id']) + '</div>' : '') +
                        (sa['local-id'] ? '<div class="swan-sub text-muted">local: ' + escapeHtml(sa['local-id']) + '</div>' : '') +
                    '</td>' +
                    '<td>' +
                        '<span class="std-badge std-badge--' + badgeVariant(state) + '">' + state.charAt(0).toUpperCase() + state.slice(1) + '</span>' +
                        (sa.version ? '<div class="swan-sub text-muted">IKEv' + sa.version + '</div>' : '') +
                    '</td>' +
                    '<td>' +
                        escapeHtml(sa['remote-host'] || '') +
                        (sa['local-host'] ? '<div class="swan-sub text-muted">via ' + escapeHtml(sa['local-host']) + '</div>' : '') +
                    '</td>' +
                    '<td class="swan-mono">' + escapeHtml(proposal) + '</td>' +
                    '<td>' + (sa.established || '') + '</td>' +
                    '<td>' + (sa['rekey-time'] || '') + '</td>' +
                    '<td>' +
                        (hasChildren
                            ? '<span class="swan-traffic-in">↓ ' + formatBytes(totalBytesIn) + '</span> ' +
                              '<span class="swan-traffic-out">↑ ' + formatBytes(totalBytesOut) + '</span>' +
                              '<div class="swan-sub text-muted">' + children.length + ' child SA(s)</div>'
                            : '<span class="text-muted">—</span>') +
                    '</td>' +
                '</tr>' + childrenHtml;
            }).join('');
            window.swanStatus = rows;
        } catch (err) {
            showModal('<p>Status refresh failed: ' + err.message + '</p>');
        }
    }

    async function refreshConnections() {
        const openEditors = ['swan-conn-inline', 'swan-pool-inline', 'swan-secret-inline']
            .filter(id => {
                const el = document.getElementById(id);
                return el && el.style.display !== 'none';
            });
        if (openEditors.length > 0 && !confirm('You have unsaved changes in an open editor. Discard and refresh?')) {
            return;
        }
        try {
            const result = await sendRequest('swan_get_connections');
            if (result.status === 'success') {
                location.reload();
            } else {
                showModal('<p>Failed to refresh connections.</p>');
            }
        } catch (err) {
            showModal('<p>Refresh failed: ' + err.message + '</p>');
        }
    }

    // ------------------------------------------------------------------
    // Event delegation and initialisation
    // ------------------------------------------------------------------
    document.addEventListener('DOMContentLoaded', () => {
        initTabs();
        initCollapsible();

        // Initialise all picker fields on the page
        if (window.setsModal) {
            window.setsModal.initPickerFields(document);
        }
        if (window.labelsMgmt) {
            window.labelsMgmt.initPickerFields(document);
        }

        // Connection form listeners
        const connForm = document.querySelector('[data-js="swan-conn-form"]');
        attachConnectionListeners(connForm);

        // AEAD toggle: hide integrity when AEAD cipher selected (selects rendered server-side)
        if (connForm) {
            connForm.addEventListener('change', (e) => {
                if (e.target.dataset.role === 'encryption') {
                    const builder = e.target.closest('.proposal-builder');
                    if (!builder) {
                        return;
                    }
                    const intCol = builder.querySelector('[data-role="integrity-col"]');
                    if (intCol) {
                        intCol.style.display = isAead(e.target.value) ? 'none' : '';
                    }
                }
            });
        }

        // Secret form listeners
        const secretForm = document.querySelector('[data-js="swan-secret-form"]');
        attachSecretListeners(secretForm);
        const secretContainer = document.getElementById('swan-secret-inline');
        if (secretContainer) {
            attachPSKHandlers(secretContainer);
        }

        // Apply initial conditions
        if (connForm) {
            applyConnectionConditions(connForm);
        }
        if (secretForm) {
            applySecretConditions(secretForm);
        }

        // Status tab: expand/collapse IKE_SA to show CHILD_SAs
        document.addEventListener('click', (e) => {
            const expandBtn = e.target.closest('[data-js="swan-expand-ike"]');
            if (!expandBtn) {
                return;
            }
            const ikeRow = expandBtn.closest('.swan-ike-row');
            if (!ikeRow) {
                return;
            }
            const ikeId = ikeRow.dataset.ikeId;
            const childRows = document.querySelectorAll('.swan-child-row[data-ike-parent="' + ikeId + '"]');
            const isExpanded = expandBtn.textContent.trim() === '▼';
            childRows.forEach(row => {
                row.style.display = isExpanded ? 'none' : '';
            });
            expandBtn.textContent = isExpanded ? '▶' : '▼';
        });

        // Auto-expand roadwarrior connections (2+ CHILD_SAs) on page load
        document.querySelectorAll('.swan-ike-row').forEach(row => {
            const ikeId = row.dataset.ikeId;
            const childRows = document.querySelectorAll('.swan-child-row[data-ike-parent="' + ikeId + '"]');
            if (childRows.length >= 2) {
                const btn = row.querySelector('[data-js="swan-expand-ike"]');
                childRows.forEach(r => { r.style.display = ''; });
                if (btn) {
                    btn.textContent = '▼';
                }
            }
        });

        // Ensure initiate (bring-up) buttons reflect role + remote_access policy:
        // disable the initiate button only when remote_access is true AND role === 'server'.
        function updateInitiateButtonStates() {
            try {
                if (!Array.isArray(window.swanConnections)) {
                    return;
                }
                window.swanConnections.forEach(conn => {
                    const id = String(conn.id);
                    const btn = document.querySelector('#swan-connections-table button.swan-conn-up[data-id="' + id + '"]');
                    if (!btn) return;
                    const shouldDisable = !!(conn.remote_access && String(conn.role) === 'server');
                    btn.disabled = shouldDisable;
                    if (shouldDisable) {
                        btn.title = 'Initiate disabled for remote-access role=server';
                    } else {
                        // restore title if available from server-side data, otherwise default
                        if (!btn.title || btn.title.indexOf('Initiate disabled') === 0) {
                            btn.title = 'Bring Up';
                        }
                    }
                });
            } catch (e) {
                /* noop */
            }
        }

        updateInitiateButtonStates();

        // Global config form submit
        const globalForm = document.getElementById('swan-global-form');
        if (globalForm) {
            globalForm.addEventListener('submit', (e) => {
                e.preventDefault();
                saveGlobalConfig(globalForm);
            });
        }

        // Click delegation
        document.addEventListener('click', (e) => {
            const target = e.target;
            const btn = target.closest('button');
            if (!btn) {
                return;
            }

            // Add / toggle buttons
            if (btn.id === 'btn-add-connection') {
                const container = document.getElementById('swan-conn-inline');
                if (container && container.style.display !== 'none') {
                    hideConnectionForm();
                } else {
                    showConnectionForm(null);
                }
                return;
            }
            if (btn.id === 'btn-add-pool') {
                const container = document.getElementById('swan-pool-inline');
                if (container && container.style.display !== 'none') {
                    hidePoolForm();
                } else {
                    showPoolForm(null);
                }
                return;
            }
            if (btn.id === 'btn-add-secret') {
                const container = document.getElementById('swan-secret-inline');
                if (container && container.style.display !== 'none') {
                    hideSecretForm();
                } else {
                    showSecretForm(null);
                }
                return;
            }

            // Refresh / reload buttons
            if (btn.id === 'btn-refresh-status') {
                refreshStatus();
                return;
            }
            if (btn.id === 'btn-refresh-connections') {
                refreshConnections();
                return;
            }
            if (btn.id === 'btn-reload-all') {
                reloadAll();
                return;
            }

            // Connection table actions (delegated via CSS class)
            const id = btn.dataset.id;

            if (btn.classList.contains('swan-conn-edit')) {
                const conn = window.swanConnections.find(c => String(c.id) === String(id));
                if (conn) {
                    showConnectionForm(conn);
                }
                return;
            }
            if (btn.classList.contains('swan-conn-delete')) {
                deleteConnection(id);
                return;
            }
            if (btn.classList.contains('swan-conn-up')) {
                initiateConnection(id);
                return;
            }
            if (btn.classList.contains('swan-conn-down')) {
                teardownConnection(id);
                return;
            }

            // Pool table actions
            if (btn.classList.contains('swan-pool-edit')) {
                const pool = window.swanPools.find(p => String(p.id) === String(id));
                if (pool) {
                    showPoolForm(pool);
                }
                return;
            }
            if (btn.classList.contains('swan-pool-delete')) {
                deletePool(id);
                return;
            }

            // Secret table actions
            if (btn.classList.contains('swan-secret-edit')) {
                const sec = window.swanSecrets.find(s => String(s.id) === String(id));
                if (sec) {
                    showSecretForm(sec);
                }
                return;
            }
            if (btn.classList.contains('swan-secret-delete')) {
                deleteSecret(id);
                return;
            }

            // Inline editor save / cancel (data-js attributes)
            const jsAction = btn.dataset.js;
            if (jsAction === 'inline-save') {
                const editor = btn.closest('.inline-editor');
                const entity = editor?.dataset.entity;
                if (entity === 'connection') {
                    saveConnection();
                } else if (entity === 'pool') {
                    savePool();
                } else if (entity === 'secret') {
                    saveSecret();
                }
                return;
            }
            if (jsAction === 'inline-cancel') {
                const editor = btn.closest('.inline-editor');
                const entity = editor?.dataset.entity;
                if (entity === 'connection') {
                    hideConnectionForm();
                } else if (entity === 'pool') {
                    hidePoolForm();
                } else if (entity === 'secret') {
                    hideSecretForm();
                }
                return;
            }

            // Proposal builder — add
            if (btn.classList.contains('proposal-add')) {
                const builder = btn.closest('.proposal-builder');
                if (builder) {
                    addProposal(builder);
                }
                return;
            }

            // Proposal builder — remove
            if (btn.classList.contains('proposal-remove')) {
                const builder = btn.closest('.proposal-builder');
                const index = parseInt(btn.dataset.index, 10);
                if (builder && !isNaN(index)) {
                    removeProposal(builder, index);
                }
                return;
            }

            // Auto-preset buttons
            if (jsAction === 'auto-site-to-site') {
                applyPreset(connForm, PRESETS['site-to-site']);
                return;
            }
            if (jsAction === 'auto-remote-access-server') {
                applyPreset(connForm, PRESETS['remote-access-server']);
                return;
            }
            if (jsAction === 'auto-remote-access-client') {
                applyPreset(connForm, PRESETS['remote-access-client']);
                return;
            }
        });
    });
})();
