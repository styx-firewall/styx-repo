# System — Settings, reboot, packages, services, certificates, and sysctl

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Update system setting | `POST /submit.php` | `command: "update_setting"` |
| Update SSH config | `POST /submit.php` | `command: "update_ssh_config"` |
| Reboot system | `POST /submit.php` | `command: "system-reboot"` |
| Restart daemon | `POST /submit.php` | `command: "restart-daemon"` |
| Get system logs | `POST /submit.php` | `command: "get_system_logs"` |
| System service control (start/stop/restart/enable/disable) | `POST /submit.php` | `command: "system-services"` |
| Install package | `POST /submit.php` | `command: "install-package"` |
| Uninstall package | `POST /submit.php` | `command: "uninstall-package"` |
| Search package | `POST /submit.php` | `command: "search-package"` |
| Purge package | `POST /submit.php` | `command: "purge-package"` |
| Update package lists (async) | `POST /submit.php` | `command: "update-package-lists"` |
| Upgrade all packages (async) | `POST /submit.php` | `command: "upgrade-packages"` |
| Upload certificate | `POST /submit.php` | | `command: "upload_certificate"` |
| Delete certificate | `POST /submit.php` | `command: "delete_certificate"` |
| Save sysctl tuning | `POST /submit.php` | `command: "save_sysctl_tunning"` |
| Set interface sysctl | `POST /submit.php` | `command: "set_iface_sysctl"` |
| Enable/disable feature | `POST /submit.php` | `command: "set_enable_feature"` |
| Get system settings | `POST /request.php` | `action: "sys_get_settings"` |
| Get SSH config | `POST /request.php` | `action: "get_ssh_config"` |
| Get services list | `POST /request.php` | `action: "sys_get_services"` |
| Get apps list | `POST /request.php` | `action: "sys_get_apps"` |
| Get upgradable packages | `POST /request.php` | `action: "sys_get_upgradable_packages"` |
| Get certificates | `POST /request.php` | | `action: "sys_get_certs"` |
| Get sysctl keys | `POST /request.php` | `action: "get_sysctl_keys"` |

---

# submit.php — Write operations

---

## `update_setting`

Updates a system-wide configuration setting.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `setting` | `string` | ✅ | Setting key |
| `value` | `mixed` | ✅ | Setting value (type depends on the setting) |

### Request

```json
{
  "command": "update_setting",
  "setting": "hostname",
  "value": "styx-gateway"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Setting updated"
}
```

---

## `update_ssh_config`

Updates SSH server configuration.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `ssh_config` | `object` | ✅ | SSH configuration object |

### Request

```json
{
  "command": "update_ssh_config",
  "ssh_config": {
    "port": 2222,
    "password_authentication": false,
    "permit_root_login": false
  }
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "SSH config updated"
}
```

---

## `system-reboot`

Reboots the entire system.

### Parameters

None.

### Request

```json
{
  "command": "system-reboot"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "System is rebooting"
}
```

---

## `restart-daemon`

Restarts the Styx backend daemon without rebooting the system.

### Parameters

None.

### Request

```json
{
  "command": "restart-daemon"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Daemon restart initiated"
}
```

---

## `get_system_logs`

Retrieves recent system logs.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `limit` | `integer` | ❌ | Maximum number of log entries (default: 50) |
| `level` | `integer` | ❌ | Minimum log level filter |

### Request

```json
{
  "command": "get_system_logs",
  "limit": 100,
  "level": 4
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Logs retrieved",
  "result": [
    {
      "timestamp": "2026-03-26T10:00:00Z",
      "level": 4,
      "message": "Service started"
    },
    {
      "timestamp": "2026-03-26T10:00:05Z",
      "level": 3,
      "message": "Configuration loaded"
    }
  ]
}
```

| Field | Type | Description |
|---|---|---|
| `result[].timestamp` | `string` (ISO8601) | Log entry timestamp |
| `result[].level` | `integer` | Log level (lower = more severe) |
| `result[].message` | `string` | Log message |

---

## `system-services`

Controls system services (start, stop, restart, enable, disable).

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `service_name` | `string` | ✅ | Name of the service |
| `action` | `string` | ✅ | `"start"`, `"stop"`, `"restart"`, `"enable"`, `"disable"` |

### Request

```json
{
  "command": "system-services",
  "service_name": "sshd",
  "action": "restart"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Service sshd restarted successfully"
}
```

---

## Package management

### `install-package`

Installs a system package asynchronously.

| Field | Type | Required | Description |
|---|---|---|---|
| `package_name` | `string` | ✅ | Package name |

```json
{
  "command": "install-package",
  "package_name": "tcpdump"
}
```

**Response** (async — returns a task ID to poll):

```json
{
  "status": "pending",
  "response_msg": "Task received, running in background",
  "result": {
    "task_id": "task-uuid-1234"
  }
}
```

### `uninstall-package`

Uninstalls a package asynchronously.

```json
{
  "command": "uninstall-package",
  "package_name": "tcpdump"
}
```

### `search-package`

Searches for available packages synchronously.

```json
{
  "command": "search-package",
  "package_name": "tcpdump"
}
```

### `purge-package`

Purges a package and its configuration files asynchronously.

```json
{
  "command": "purge-package",
  "package_name": "tcpdump"
}
```

> **⚠️ Note:** Package operations (`install`, `uninstall`, `purge`) return `status: "pending"` with a `task_id`. Poll the task status to get the final result.

---

## System update / upgrade

### `update-package-lists`

Refreshes apt package lists (async task).

### Parameters

None.

### Request

```json
{
  "command": "update-package-lists"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Package list update started",
  "result": {
    "task_id": "a1b2c3d4-..."
  }
}
```

---

### `upgrade-packages`

Upgrades all packages via `apt dist-upgrade -y` (async task).

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `run_update_first` | `boolean` | ❌ | If true, runs `apt update` before upgrading (default: false) |

### Request

```json
{
  "command": "upgrade-packages",
  "run_update_first": true
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Package upgrade started",
  "result": {
    "task_id": "e5f6g7h8-..."
  }
}
```

> **⚠️ Note:** Both `update-package-lists` and `upgrade-packages` are asynchronous. They return a `task_id` to track progress via the refresh mechanism.

---

## Certificate management

### `upload_certificate`

Uploads a certificate (single or cert+key pair).

#### Single certificate

```json
{
  "command": "upload_certificate",
  "name": "server.pem",
  "type": "CERT",
  "file_name": "server.pem",
  "content": "<base64-encoded-pem-content>"
}
```

#### Certificate + key pair

```json
{
  "command": "upload_certificate",
  "pair": true,
  "cert": {
    "name": "server.crt",
    "type": "CERT",
    "file_name": "server.crt",
    "content": "<base64-pem>"
  },
  "key": {
    "name": "server.key",
    "type": "KEY",
    "file_name": "server.key",
    "content": "<base64-pem>"
  }
}
```

#### Response (success)

```json
{
  "status": "success",
  "response_msg": "Upload successful",
  "result": {
    "id": "cert-uuid-1234",
    "name": "server.pem",
    "type": "CERT",
    "file_name": "server.pem",
    "is_ca": false
  }
}
```

### `delete_certificate`

Deletes a certificate by its UUID.

```json
{
  "command": "delete_certificate",
  "id": "cert-uuid-1234"
}
```

---

## Sysctl management

### `save_sysctl_tunning`

Saves system-wide sysctl tunings.

```json
{
  "command": "save_sysctl_tunning",
  "sysctl_keys": [
    { "key": "net.ipv4.ip_forward", "value": 1 },
    { "key": "net.ipv4.tcp_congestion_control", "value": "bbr" }
  ]
}
```

### `set_iface_sysctl`

Sets interface-specific sysctl values.

```json
{
  "command": "set_iface_sysctl",
  "id": "uuid-interface-id",
  "sysctl_keys": [
    { "key": "net.ipv4.conf.eth0.proxy_arp", "value": 0 }
  ]
}
```

---

## Feature management

### `set_enable_feature`

Enables or disables a feature option.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `feature_key` | `string` | ✅ | Feature identifier (e.g. `"routing"`, `"vpn"`, `"sla_monitor"`) |
| `option_key` | `string` | ❌ | Specific sub-option within the feature. Omit to enable/disable the entire feature |
| `enabled` | `boolean` | ✅ | `true` to enable, `false` to disable |

### Request — toggle entire feature

```json
{
  "command": "set_enable_feature",
  "feature_key": "routing",
  "enabled": true
}
```

### Request — toggle sub-option

```json
{
  "command": "set_enable_feature",
  "feature_key": "routing",
  "option_key": "advanced_routing",
  "enabled": true
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Feature 'routing' enabled"
}
```

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Unknown feature key: 'invalid_feature'"
}
```

---

# request.php — Read operations

---

## `sys_get_settings`

Returns system-wide settings.

### Parameters

None.

### Request

```json
{
  "action": "sys_get_settings"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Settings retrieved",
  "result": {
    "hostname": "styx-gateway",
    "timezone": "UTC",
    "language": "en"
  }
}
```

---

## `get_ssh_config`

Returns the current SSH server configuration.

### Parameters

None.

### Request

```json
{
  "action": "get_ssh_config"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "SSH config retrieved",
  "result": {
    "ssh_config": {
      "port": 2222,
      "password_authentication": false,
      "permit_root_login": false
    }
  }
}
```

---

## `sys_get_services`

Returns a list of system services with their status.

### Parameters

None.

### Request

```json
{
  "action": "sys_get_services"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Services retrieved",
  "result": {
    "services": [
      {
        "name": "sshd",
        "status": "running",
        "enabled": true
      }
    ]
  }
}
```

---

## `sys_get_apps`

Returns a list of installed/available applications.

### Parameters

None.

---

## `sys_get_upgradable_packages`

Returns a list of packages available for upgrade.

### Parameters

None.

### Request

```json
{
  "action": "sys_get_upgradable_packages"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Upgradable packages retrieved",
  "result": {
    "packages": [
      {
        "name": "libssl3",
        "archive": "stable-security",
        "version": "3.0.15-2",
        "arch": "amd64",
        "old_version": "3.0.15-1"
      }
    ],
    "count": 5,
    "security_count": 2
  }
}
```

---

## `sys_get_certs`

Returns a list of stored certificates.

### Parameters

None.

### Request

```json
{
  "action": "sys_get_certs"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Certificates retrieved",
  "result": {
    "certificates": [
      {
        "id": "cert-uuid-1",
        "name": "server.crt",
        "type": "CERT_KEY",
        "file_name": "server.crt",
        "has_key": true,
        "matched_key_path": "/etc/ssl/local-private/server.key",
        "is_ca": false,
        "expires_at": "2027-01-01T00:00:00Z"
      }
    ]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.certificates[].id` | `string` (UUID) | Certificate UUID |
| `result.certificates[].name` | `string` | Certificate name |
| `result.certificates[].type` | `string` | `"CERT"`, `"KEY"`, or `"CERT_KEY"` |
| `result.certificates[].file_name` | `string` | Original filename |
| `result.certificates[].has_key` | `boolean` | Whether a matching private key was found |
| `result.certificates[].is_ca` | `boolean` | Whether this is a CA certificate |
| `result.certificates[].expires_at` | `string` (ISO8601) \| `null` | Expiry timestamp |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "sys_get_certs"}' | jq
```

---

## `get_sysctl_keys`

Returns available sysctl keys.

### Parameters

None.

---

## Important notes

1. **Async package operations:** `install-package`, `uninstall-package`, and `purge-package` are asynchronous. They return `status: "pending"` with a `task_id` instead of a final result.

2. **Certificate upload:** Certificate content must be base64-encoded PEM data. The response includes the stored certificate UUID.

---

## References

- Backend handler (system): `api/handlers/system_mgmt.md`
- Backend handler (packages): `api/handlers/system_packages.md`
- Backend handler (services): `api/handlers/system_services.md`
- Backend handler (certificates): `api/handlers/certificates.md`
- Backend handler (sysctl): `api/handlers/sysctl.md`
- Backend handler (features): `api/handlers/styx_features.md`
- PHP implementation (submit): `App\Controllers\Submit\SystemSubmitController`, `App\Controllers\Submit\PackagesSubmitController`
- PHP implementation (request): `App\Controllers\Request\SystemRequestController`
