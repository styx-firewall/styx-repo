<?php

namespace App\Registry;

use App\Core\AppContext;

use App\Controllers\Submit\UserSubmitController;
use App\Controllers\Submit\FirewallSubmitController;
use App\Controllers\Submit\IperfSubmitController;
use App\Controllers\Submit\SystemSubmitController;
use App\Controllers\Submit\EventSubmitController;
use App\Controllers\Submit\NetTunningSubmitController;
use App\Controllers\Submit\PackagesSubmitController;
use App\Controllers\Submit\FeaturesSubmitController;
use App\Controllers\Submit\TCSubmitController;
use App\Controllers\Submit\RoutesSubmitController;
use App\Controllers\Submit\SLASubmitController;
use App\Controllers\Submit\InterfaceSubmitController;
use App\Controllers\Submit\StyxSubmitController;
use App\Controllers\Submit\DhcpServerSubmitController;
use App\Controllers\Submit\EbpfSubmitController;
use App\Controllers\Submit\PacketMarkingSubmitController;
use App\Controllers\Submit\StrongswanSubmitController;
use App\Controllers\Submit\BearerTokenSubmitController;
use App\Controllers\Submit\SetsSubmitController;
use App\Controllers\Submit\NatSubmitController;
use App\Controllers\Submit\RouteRulesSubmitController;
use App\Controllers\Submit\TrafficStatsSubmitController;
use App\Controllers\Submit\RoutingSubmitController;
use App\Controllers\Submit\RoleSubmitController;

/**
 * Submit Registry
 * Maps command names to [ControllerClass, methodName]
 */
class SubmitRegistry
{
    /**
     * Command registry mapping
     * @var array<string, array{0: class-string, 1: string}>
     */
    private static array $commands = [
        // User commands
        'add_user'       => [UserSubmitController::class, 'addUser'],
        'edit_user'      => [UserSubmitController::class, 'editUser'],
        'delete_user'    => [UserSubmitController::class, 'deleteUser'],
        'lock_user'      => [UserSubmitController::class, 'lockUser'],
        'unlock_user'    => [UserSubmitController::class, 'unlockUser'],
        'login'          => [UserSubmitController::class, 'login'],
        'logout'         => [UserSubmitController::class, 'logout'],
        'reset_password' => [UserSubmitController::class, 'resetPassword'],
        'set_role'       => [UserSubmitController::class, 'setRole'],
        'remove_role'    => [UserSubmitController::class, 'removeRole'],

        // Role management
        'create_role'    => [RoleSubmitController::class, 'create'],
        'delete_role'    => [RoleSubmitController::class, 'delete'],
        'update_role'    => [RoleSubmitController::class, 'update'],

        // SLA monitor commands
        'add_monitor'     => [SLASubmitController::class, 'addMonitor'],
        'enable_monitor'  => [SLASubmitController::class, 'enableMonitor'],
        'disable_monitor' => [SLASubmitController::class, 'disableMonitor'],
        'delete_monitor'  => [SLASubmitController::class, 'deleteMonitor'],


        // Firewall commands
        'set_firewall_rule'   => [FirewallSubmitController::class, 'setFirewallRule'],
        'preview_firewall_rule' => [FirewallSubmitController::class, 'previewRule'],
        'update_firewall_rule'=> [FirewallSubmitController::class, 'updateRule'],
        'delete_firewall_rule'=> [FirewallSubmitController::class, 'deleteFirewallRule'],
        'move_rule'           => [FirewallSubmitController::class, 'moveRule'],

        // NAT commands
        'set_nat_rule'          => [NatSubmitController::class, 'setNatRule'],
        'set_static_nat_rule'   => [NatSubmitController::class, 'setStaticNatRule'],
        'delete_nat_rule'       => [NatSubmitController::class, 'deleteNatRule'],
        'delete_static_nat_rule'=> [NatSubmitController::class, 'deleteStaticNatRule'],
        'set_nat_rule_enabled'  => [NatSubmitController::class, 'setNatRuleEnabled'],
        // New sets-style commands (alias to new controller)
        'set_port'            => [SetsSubmitController::class, 'set_port'],
        'set_address'         => [SetsSubmitController::class, 'set_address'],
        'set_interface_set'   => [SetsSubmitController::class, 'set_interface_set'],
        'delete_port'         => [SetsSubmitController::class, 'delete_port'],
        'delete_address'      => [SetsSubmitController::class, 'delete_address'],
        'delete_interface_set'=> [SetsSubmitController::class, 'delete_interface_set'],
        'set_domain'          => [SetsSubmitController::class, 'set_domain'],
        'delete_domain'       => [SetsSubmitController::class, 'delete_domain'],
        // new label command
        'sets-mgmt.set_label' => [SetsSubmitController::class, 'set_label'],
        'sets-mgmt.delete_label' => [SetsSubmitController::class, 'delete_label'],

        // iPerf commands
        'iperf_start_server'      => [IperfSubmitController::class, 'startServer'],
        'iperf_stop_server'       => [IperfSubmitController::class, 'stopServer'],
        'iperf_start_client_test' => [IperfSubmitController::class, 'startClientTest'],

        // System commands
        'restart-daemon'     => [SystemSubmitController::class, 'restartDaemon'],
        'system-reboot'      => [SystemSubmitController::class, 'systemReboot'],
        'update_setting'     => [SystemSubmitController::class, 'updateSetting'],
        'update_ssh_config'  => [SystemSubmitController::class, 'updateSshConfig'],
        'get_system_logs'    => [SystemSubmitController::class, 'getSystemLogs'],
        'delete_certificate' => [SystemSubmitController::class, 'deleteCertificate'],
        // Service control (start/stop/restart/enable/disable)
        'system-services'         => [SystemSubmitController::class, 'systemServices'],
        'upload_certificate'      => [SystemSubmitController::class, 'uploadCertificate'],
        // Package management commands
        'update-package-lists'    => [SystemSubmitController::class, 'updatePackageLists'],
        'upgrade-packages'        => [SystemSubmitController::class, 'upgradePackages'],

        // Event commands
        'toggle_ack' => [EventSubmitController::class, 'toggleAck'],

        // Net tunning commands
        'save_sysctl_tunning' => [NetTunningSubmitController::class, 'saveSysctlTunning'],
        'set_iface_sysctl'    => [NetTunningSubmitController::class, 'saveIfaceSysctl'],

        // Package commands
        'install-package'   => [PackagesSubmitController::class, 'handle'],
        'uninstall-package' => [PackagesSubmitController::class, 'handle'],
        'search-package'    => [PackagesSubmitController::class, 'handle'],
        'purge-package'     => [PackagesSubmitController::class, 'handle'],

        // Features commands
        'set_enable_feature' => [FeaturesSubmitController::class, 'setEnableFeature'],

        // Traffic Control (TC) commands
        'add_tc_rule'      => [TCSubmitController::class, 'addRule'],
        'edit_tc_rule'     => [TCSubmitController::class, 'editRule'],
        'delete_tc_rule'   => [TCSubmitController::class, 'deleteRule'],
        'toggle_tc_rule'   => [TCSubmitController::class, 'toggleRule'],
        'add_tc_qdisc'     => [TCSubmitController::class, 'addQdisc'],
        'edit_tc_qdisc'    => [TCSubmitController::class, 'editQdisc'],
        'delete_tc_qdisc'  => [TCSubmitController::class, 'deleteQdisc'],
        'remove_tc_qdisc'  => [TCSubmitController::class, 'removeQdisc'],
        'add_tc_class'     => [TCSubmitController::class, 'addClass'],
        'delete_tc_class'  => [TCSubmitController::class, 'deleteClass'],

        // Packet marking commands
        'set_pm_rule'      => [PacketMarkingSubmitController::class, 'setRule'],
        'preview_pm_rule'  => [PacketMarkingSubmitController::class, 'previewRule'],
        'delete_pm_rule'   => [PacketMarkingSubmitController::class, 'deleteRule'],
        'toggle_pm_rule'   => [PacketMarkingSubmitController::class, 'toggleRule'],

        // Interface commands
        'set_iface_config'          => [InterfaceSubmitController::class, 'setIfaceConfig'],
        'create_virtual_interface'  => [InterfaceSubmitController::class, 'createVirtualInterface'],
        'delete_virtual_interface'  => [InterfaceSubmitController::class, 'deleteVirtualInterface'],

        // Styx commands
        'styx-backup-restore' => [StyxSubmitController::class, 'restoreBackup'],
        'get_styx_logs'       => [StyxSubmitController::class, 'getStyxLogs'],
        'update_web_settings' => [StyxSubmitController::class, 'updateWebSettings'],
        'save_config'        => [StyxSubmitController::class, 'saveConfig'],
        'restart_styx_ui'    => [StyxSubmitController::class, 'restartStyxUi'],

        // DHCP commands
        'set_dhcp_config'        => [DhcpServerSubmitController::class, 'setDhcpConfig'],
        'set_dhcp_reservations'  => [DhcpServerSubmitController::class, 'setDhcpReservations'],
        'set_dhcp_global_config' => [DhcpServerSubmitController::class, 'setDhcpGlobalConfig'],

        // eBPF commands
        'ebpf_load_module'    => [EbpfSubmitController::class, 'loadModule'],
        'ebpf_unload_module'  => [EbpfSubmitController::class, 'unloadModule'],
        'ebpf_reload_module'  => [EbpfSubmitController::class, 'reloadModule'],
        'ebpf_control_push'   => [EbpfSubmitController::class, 'controlPush'],
        'ebpf_set_autoload'   => [EbpfSubmitController::class, 'setAutoload'],
        'ebpf_set_map_source' => [EbpfSubmitController::class, 'setMapSource'],
        'ebpf_module_rescan'  => [EbpfSubmitController::class, 'moduleRescan'],
        'ebpf_baseline_ack'   => [EbpfSubmitController::class, 'baselineAck'],
        'ebpf_program_detach' => [EbpfSubmitController::class, 'detachProgram'],

        // strongSwan VPN commands
        'swan_add_connection'    => [StrongswanSubmitController::class, 'addConnection'],
        'swan_edit_connection'   => [StrongswanSubmitController::class, 'editConnection'],
        'swan_delete_connection' => [StrongswanSubmitController::class, 'deleteConnection'],
        'swan_conn_up'           => [StrongswanSubmitController::class, 'connUp'],
        'swan_conn_down'         => [StrongswanSubmitController::class, 'connDown'],
        'swan_add_pool'          => [StrongswanSubmitController::class, 'addPool'],
        'swan_edit_pool'         => [StrongswanSubmitController::class, 'editPool'],
        'swan_delete_pool'       => [StrongswanSubmitController::class, 'deletePool'],
        'swan_add_secret'        => [StrongswanSubmitController::class, 'addSecret'],
        'swan_edit_secret'       => [StrongswanSubmitController::class, 'editSecret'],
        'swan_delete_secret'     => [StrongswanSubmitController::class, 'deleteSecret'],
        'swan_set_global_config' => [StrongswanSubmitController::class, 'setGlobalConfig'],
        'swan_reload_all'        => [StrongswanSubmitController::class, 'reloadAll'],

        // Bearer token commands
        'generate_bearer_token' => [BearerTokenSubmitController::class, 'generateToken'],
        'revoke_bearer_token'   => [BearerTokenSubmitController::class, 'revokeToken'],
        'list_bearer_tokens'    => [BearerTokenSubmitController::class, 'listTokens'],

        // User profile commands
        'save_profile' => [UserSubmitController::class, 'saveProfile'],

        // Route rules commands
        'set_routing_rule'      => [RouteRulesSubmitController::class, 'setRule'],
        'preview_routing_rule'  => [RouteRulesSubmitController::class, 'previewRule'],
        'delete_routing_rule'   => [RouteRulesSubmitController::class, 'deleteRule'],
        'toggle_routing_rule'   => [RouteRulesSubmitController::class, 'toggleRule'],
        'update_routing_rule'   => [RouteRulesSubmitController::class, 'updateRule'],

        // Traffic Stats
        'traffic-stats-reset'   => [TrafficStatsSubmitController::class, 'resetStats'],

        // Route commands
        'add_route'          => [RoutesSubmitController::class, 'addRoute'],
        'delete_route_by_id' => [RoutesSubmitController::class, 'deleteRouteById'],
        // Routing (frrouting + igmp_proxy)
        'routing_save_bgp_config'     => [RoutingSubmitController::class, 'saveBgpConfig'],
        'routing_add_bgp_neighbor'    => [RoutingSubmitController::class, 'addBgpNeighbor'],
        'routing_update_bgp_neighbor' => [RoutingSubmitController::class, 'updateBgpNeighbor'],
        'routing_delete_bgp_neighbor' => [RoutingSubmitController::class, 'deleteBgpNeighbor'],
        'routing_add_bgp_network'     => [RoutingSubmitController::class, 'addBgpNetwork'],
        'routing_delete_bgp_network'  => [RoutingSubmitController::class, 'deleteBgpNetwork'],
        // BGP Peer Groups
        'routing_add_peer_group'                  => [RoutingSubmitController::class, 'addPeerGroup'],
        'routing_update_peer_group'               => [RoutingSubmitController::class, 'updatePeerGroup'],
        'routing_delete_peer_group'               => [RoutingSubmitController::class, 'deletePeerGroup'],
        'routing_assign_neighbor_to_peer_group'   => [RoutingSubmitController::class, 'assignNeighborToPeerGroup'],
        'routing_unassign_neighbor_from_peer_group' => [RoutingSubmitController::class, 'unassignNeighborFromPeerGroup'],
        'routing_save_ospf_config'    => [RoutingSubmitController::class, 'saveOspfConfig'],
        'routing_add_ospf_area'       => [RoutingSubmitController::class, 'addOspfArea'],
        'routing_delete_ospf_area'    => [RoutingSubmitController::class, 'deleteOspfArea'],
        'routing_add_ospf_iface'      => [RoutingSubmitController::class, 'addOspfInterface'],
        'routing_delete_ospf_iface'   => [RoutingSubmitController::class, 'deleteOspfInterface'],
        'routing_save_rip_config'     => [RoutingSubmitController::class, 'saveRipConfig'],
        'routing_add_rip_network'     => [RoutingSubmitController::class, 'addRipNetwork'],
        'routing_delete_rip_network'  => [RoutingSubmitController::class, 'deleteRipNetwork'],
        'routing_save_igmp_config'    => [RoutingSubmitController::class, 'saveIgmpProxyConfig'],
        'routing_add_igmp_iface'      => [RoutingSubmitController::class, 'addIgmpInterface'],
        'routing_delete_igmp_iface'   => [RoutingSubmitController::class, 'deleteIgmpInterface'],
        'routing_save_frr_global'    => [RoutingSubmitController::class, 'saveFrrGlobal'],

        // FRR Static Routes
        'routing_save_frr_static_config'    => [RoutingSubmitController::class, 'saveFrrStaticConfig'],
        'routing_add_frr_static_route'      => [RoutingSubmitController::class, 'addFrrStaticRoute'],
        'routing_update_frr_static_route'   => [RoutingSubmitController::class, 'updateFrrStaticRoute'],
        'routing_delete_frr_static_route'   => [RoutingSubmitController::class, 'deleteFrrStaticRoute'],

        // VRRP
        'routing_save_vrrp_config'    => [RoutingSubmitController::class, 'saveVrrpConfig'],
        'routing_add_vrrp_instance'   => [RoutingSubmitController::class, 'addVrrpInstance'],
        'routing_update_vrrp_instance' => [RoutingSubmitController::class, 'updateVrrpInstance'],
        'routing_delete_vrrp_instance' => [RoutingSubmitController::class, 'deleteVrrpInstance'],

        // BFD Profiles
        'routing_add_bfd_profile'     => [RoutingSubmitController::class, 'addBfdProfile'],
        'routing_update_bfd_profile'  => [RoutingSubmitController::class, 'updateBfdProfile'],
        'routing_delete_bfd_profile'  => [RoutingSubmitController::class, 'deleteBfdProfile'],

        // OSPFv3
        'routing_save_ospf6_config'   => [RoutingSubmitController::class, 'saveOspf6Config'],
        'routing_add_ospf6_area'      => [RoutingSubmitController::class, 'addOspf6Area'],
        'routing_delete_ospf6_area'   => [RoutingSubmitController::class, 'deleteOspf6Area'],
        'routing_add_ospf6_iface'     => [RoutingSubmitController::class, 'addOspf6Interface'],
        'routing_delete_ospf6_iface'  => [RoutingSubmitController::class, 'deleteOspf6Interface'],

        // Zebra
        'routing_save_zebra_config'   => [RoutingSubmitController::class, 'saveZebraConfig'],

        // EVPN
        'routing_save_evpn'           => [RoutingSubmitController::class, 'saveEvpn'],
        'routing_add_evpn_vrf'        => [RoutingSubmitController::class, 'addEvpnVrf'],
        'routing_delete_evpn_vrf'     => [RoutingSubmitController::class, 'deleteEvpnVrf'],

        // FRR Policies — Prefix Lists
        'routing_add_prefix_list'      => [RoutingSubmitController::class, 'addPrefixList'],
        'routing_update_prefix_list'   => [RoutingSubmitController::class, 'updatePrefixList'],
        'routing_delete_prefix_list'   => [RoutingSubmitController::class, 'deletePrefixList'],
        // FRR Policies — Route Maps
        'routing_add_route_map'        => [RoutingSubmitController::class, 'addRouteMap'],
        'routing_update_route_map'     => [RoutingSubmitController::class, 'updateRouteMap'],
        'routing_delete_route_map'     => [RoutingSubmitController::class, 'deleteRouteMap'],
        // FRR Policies — AS Path Lists
        'routing_add_as_path_list'     => [RoutingSubmitController::class, 'addAsPathList'],
        'routing_update_as_path_list'  => [RoutingSubmitController::class, 'updateAsPathList'],
        'routing_delete_as_path_list'  => [RoutingSubmitController::class, 'deleteAsPathList'],
        // FRR Policies — Community Lists
        'routing_add_community_list'    => [RoutingSubmitController::class, 'addCommunityList'],
        'routing_update_community_list' => [RoutingSubmitController::class, 'updateCommunityList'],
        'routing_delete_community_list' => [RoutingSubmitController::class, 'deleteCommunityList'],

        // Discovery actions
        'discovery_sweep_now'       => [\App\Controllers\Submit\DiscoverySubmitController::class, 'sweepNow'],
        'discovery_traceroute_all'  => [\App\Controllers\Submit\DiscoverySubmitController::class, 'tracerouteAll'],
        'discovery_pause'           => [\App\Controllers\Submit\DiscoverySubmitController::class, 'pause'],
        'discovery_resume'          => [\App\Controllers\Submit\DiscoverySubmitController::class, 'resume'],
        'discovery_prune_hosts'     => [\App\Controllers\Submit\DiscoverySubmitController::class, 'pruneHosts'],
        'discovery_update_settings' => [\App\Controllers\Submit\DiscoverySubmitController::class, 'updateSettings'],
    ];

    /**
     * Get all registered commands
     * @return array<string, array{0: class-string, 1: string}>
     */
    public static function all(): array
    {
        return self::$commands;
    }

    /**
     * Check if a command exists
     * @param string $command
     * @return bool
     */
    public static function has(string $command): bool
    {
        return isset(self::$commands[$command]);
    }

    /**
     * Get a command handler
     * @param string $command
     * @return array{0: class-string, 1: string}|null
     */
    public static function get(string $command): ?array
    {
        return self::$commands[$command] ?? null;
    }

    /**
     * Execute a command
     * @param AppContext $ctx
     * @param string $command
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     * @throws \InvalidArgumentException if command not found
     */
    public static function execute(AppContext $ctx, string $command, array $data): array
    {
        if (!self::has($command)) {
            throw new \InvalidArgumentException("Unknown command: $command");
        }

        [$controllerClass, $method] = self::$commands[$command];
        $controller = new $controllerClass($ctx);
        return $controller->$method($data);
    }
}
