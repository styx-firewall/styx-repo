<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class FwLogsRequestController extends BaseController
{
    public function __construct(AppContext $ctx)
    {
        parent::__construct($ctx);
    }

    public function handle(array $inputData): array
    {
        $userQuery = isset($inputData['query']) ? trim($inputData['query']) : '';
        $hook = $inputData['hook'] ?? null;
        $mark = $inputData['mark'] ?? null;
        $limit = $inputData['limit'] ?? 50;
        $start = $inputData['start'] ?? null;
        $end = $inputData['end'] ?? null;

        $queryParts = [];
        if ($hook !== null) {
            $queryParts[] = $this->buildHookExpr($hook);
        }
        if ($userQuery !== '') {
            $queryParts[] = '(' . $userQuery . ')';
        }
        $query = $queryParts ? implode(' AND ', $queryParts) : null;

        $data = [];
        if ($query !== null) {
            $data['query'] = $query;
        }
        $this->logService->debug([
            'fw_logs_request' => [
                'query' => $query,
                'mark_in' => $mark,
                'limit' => $limit,
            ]
        ]);
        if ($start !== null && $end !== null) {
            $data['start'] = $start;
            $data['end'] = $end;
        } elseif ($mark !== null) {
            $data['mark'] = $mark;
            $data['limit'] = $limit;
        } else {
            $data['limit'] = $limit;
        }

        $command = [
            'method' => 'firewall-logs.get_firewall_logs',
            'id' => 'logs',
            'data' => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$command], null, ['timeout_read' => 8]));
        if ($resp['status'] === 'error') {
            return array_merge($resp, ['logs' => [], 'mark' => null]);
        }

        $cmd = $resp['commands']['logs'] ?? [];

        if (($cmd['status'] ?? null) === 'success' && isset($cmd['result']['logs'])) {
            $logs = $cmd['result']['logs'];
            foreach ($logs as &$log) {
                $log = $this->parseLogEntry($log);
            }
            $this->logService->debug([
                'fw_logs_response' => [
                    'mark_out' => $cmd['result']['mark'] ?? null,
                    'logs_count' => is_array($logs) ? count($logs) : 0,
                ]
            ]);
            return [
                'status' => 'success',
                'response_msg' => 'Logs retrieved successfully',
                'mark' => $cmd['result']['mark'] ?? null,
                'logs' => $logs,
            ];
        }
        $this->logService->warning(['fw_logs_error' => $cmd]);
        return [
            'status' => 'error',
            'response_msg' => $cmd['response_msg'] ?? 'No data from backend',
            'logs' => [],
            'mark' => null,
        ];
    }

    private function parseLogEntry(array $log): array
    {
        // Flatten the network sub-object for table column access
        if (isset($log['network']) && is_array($log['network'])) {
            $log['iface_in']  = $log['network']['in_iface'] ?? '';
            $log['iface_out'] = $log['network']['out_iface'] ?? '';
            $log['hook_name'] = $log['network']['hook'] ?? '';
        }

        // Prefer the authoritative UTC ISO timestamp from the backend normalizer
        if (!empty($log['timestamp_iso'])) {
            $log['timestamp'] = $log['timestamp_iso'];
        }

        // Extract tcp.flags from the normalized nested tcp object
        if (isset($log['tcp']) && is_array($log['tcp']) && !empty($log['tcp']['flags'])) {
            $log['tcp.flags'] = $log['tcp']['flags'];
        }

        return $log;
    }

    /**
     * Build a hook filter expression for the query.
     * Arrays produce OR-grouped expressions; strings produce a single equality.
     *
     * @param string|array<string> $hook
     */
    private function buildHookExpr(string|array $hook): string
    {
        if (is_array($hook)) {
            $parts = array_map(fn($h) => 'network.hook == "' . $h . '"', $hook);
            return '(' . implode(' OR ', $parts) . ')';
        }
        return 'network.hook == "' . $hook . '"';
    }
}
