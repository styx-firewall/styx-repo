<?php
/**
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 */
namespace App\Controllers\Submit;

use App\Controllers\BaseController;
use App\Core\AppContext;

class RoutingSubmitController extends BaseController
{
    public function __construct(AppContext $ctx)
    {
        parent::__construct($ctx);
    }

    // ── BGP ──────────────────────────────────────────────────────────────────

    /**
     * @param array{
     *     router_as: string,
     *     router_id: string,
     *     enabled: bool,
     *     keepalive: int,
     *     hold_time: int,
     *     default_local_pref: int,
     *     log_neighbor_changes: bool,
     *     always_compare_med: bool,
     *     graceful_restart: bool,
     *     ebgp_requires_policy: bool,
     *     disable_ebgp_connected_route_check: bool,
     *     redistribute?: array<int, array{protocol: string, route_map?: string|null, metric?: int|null}>,
     * } $data
     * @return array<string, mixed>
     */
    public function saveBgpConfig(array $data): array
    {
        if (empty($data['router_as'])) {
            return $this->baseError('router_as is required');
        }
        if (empty($data['router_id'])) {
            return $this->baseError('router_id is required');
        }
        $cmd = [
            'method' => 'frr-service.save_bgp_config',
            'id'     => 'save_bgp_config',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['save_bgp_config'] ?? $this->baseError('No response for save_bgp_config');
    }

    /**
     * @param array{
     *     neighbor_ip_set: string,
     *     remote_as: string,
     *     description?: string,
     *     password?: string|null,
     *     ebgp_multihop?: int,
     *     update_source?: string|null,
     *     keepalive?: int|null,
     *     hold_time?: int|null,
     *     next_hop_self?: bool,
     *     soft_reconfiguration_inbound?: bool,
     *     route_reflector_client?: bool,
     *     bfd?: bool,
     *     bfd_strict?: bool,
     *     bfd_strict_hold_time?: int|null,
     *     bfd_check_control_plane_failure?: bool,
     *     bfd_profile?: string|null,
     *     peer_group?: string|null,
     *     route_map_in?: string|null,
     *     route_map_out?: string|null,
     * } $data
     * @return array<string, mixed>
     */
    public function addBgpNeighbor(array $data): array
    {
        if (empty($data['neighbor_ip_set'])) {
            return $this->baseError('neighbor_ip_set is required');
        }
        if (empty($data['remote_as'])) {
            return $this->baseError('remote_as is required');
        }
        $cmd = [
            'method' => 'frr-service.add_bgp_neighbor',
            'id'     => 'add_bgp_neighbor',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_bgp_neighbor'] ?? $this->baseError('No response for add_bgp_neighbor');
    }

    /**
     * @param array{id: string} $data
     * @return array<string, mixed>
     */
    public function deleteBgpNeighbor(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.delete_bgp_neighbor',
            'id'     => 'delete_bgp_neighbor',
            'data'   => ['id' => $data['id']],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_bgp_neighbor'] ?? $this->baseError('No response for delete_bgp_neighbor');
    }

    /**
     * Update a BGP neighbor. Only `id` is required; all other fields are optional
     * (partial merge on the backend).
     *
     * @param array{
     *     id: string,
     *     neighbor_ip_set?: string,
     *     remote_as?: string,
     *     description?: string,
     *     password?: string|null,
     *     ebgp_multihop?: int,
     *     update_source?: string|null,
     *     keepalive?: int|null,
     *     hold_time?: int|null,
     *     next_hop_self?: bool,
     *     soft_reconfiguration_inbound?: bool,
     *     route_reflector_client?: bool,
     *     bfd?: bool,
     *     bfd_strict?: bool,
     *     bfd_strict_hold_time?: int|null,
     *     bfd_check_control_plane_failure?: bool,
     *     bfd_profile?: string|null,
     *     peer_group?: string|null,
     *     route_map_in?: string|null,
     *     route_map_out?: string|null,
     *     address_families?: string[],
     * } $data
     * @return array<string, mixed>
     */
    public function updateBgpNeighbor(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.update_bgp_neighbor',
            'id'     => 'update_bgp_neighbor',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['update_bgp_neighbor'] ?? $this->baseError('No response for update_bgp_neighbor');
    }

    /**
     * @param array{network_set: string} $data
     * @return array<string, mixed>
     */
    public function addBgpNetwork(array $data): array
    {
        if (empty($data['network_set'])) {
            return $this->baseError('network_set is required');
        }
        $cmd = [
            'method' => 'frr-service.add_bgp_network',
            'id'     => 'add_bgp_network',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_bgp_network'] ?? $this->baseError('No response for add_bgp_network');
    }

    /**
     * @param array{id: string} $data
     * @return array<string, mixed>
     */
    public function deleteBgpNetwork(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.delete_bgp_network',
            'id'     => 'delete_bgp_network',
            'data'   => ['id' => $data['id']],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_bgp_network'] ?? $this->baseError('No response for delete_bgp_network');
    }

    // ── OSPF ─────────────────────────────────────────────────────────────────

    /**
     * @param array{
     *     router_id: string,
     *     reference_bandwidth: int,
     *     enabled: bool,
     *     log_adjacency_changes: bool,
     *     passive_interface_default: bool,
     * } $data
     * @return array<string, mixed>
     */
    public function saveOspfConfig(array $data): array
    {
        if (empty($data['router_id'])) {
            return $this->baseError('router_id is required');
        }
        $cmd = [
            'method' => 'frr-service.save_ospf_config',
            'id'     => 'save_ospf_config',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['save_ospf_config'] ?? $this->baseError('No response for save_ospf_config');
    }

    /**
     * @param array{
     *     area_id: string,
     *     type: 'normal'|'stub'|'nssa',
     *     no_summary?: bool,
     *     network_set: string,
     * } $data
     * @return array<string, mixed>
     */
    public function addOspfArea(array $data): array
    {
        if (empty($data['area_id'])) {
            return $this->baseError('area_id is required');
        }
        if (empty($data['network_set'])) {
            return $this->baseError('network_set is required');
        }
        $allowed_types = ['normal', 'stub', 'nssa'];
        if (!in_array($data['type'] ?? '', $allowed_types, true)) {
            return $this->baseError('type must be normal, stub or nssa');
        }
        $cmd = [
            'method' => 'frr-service.add_ospf_area',
            'id'     => 'add_ospf_area',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_ospf_area'] ?? $this->baseError('No response for add_ospf_area');
    }

    /**
     * @param array{id: string} $data
     * @return array<string, mixed>
     */
    public function deleteOspfArea(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.delete_ospf_area',
            'id'     => 'delete_ospf_area',
            'data'   => ['id' => $data['id']],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_ospf_area'] ?? $this->baseError('No response for delete_ospf_area');
    }

    /**
     * @param array{
     *     iface_set: string,
     *     priority: int,
     *     cost?: int|null,
     *     hello_interval: int,
     *     dead_interval: int,
     *     poll_interval: int,
     *     passive: bool,
     * } $data
     * @return array<string, mixed>
     */
    public function addOspfInterface(array $data): array
    {
        if (empty($data['iface_set'])) {
            return $this->baseError('iface_set is required');
        }
        $cmd = [
            'method' => 'frr-service.add_ospf_iface',
            'id'     => 'add_ospf_iface',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_ospf_iface'] ?? $this->baseError('No response for add_ospf_iface');
    }

    /**
     * @param array{id: string} $data
     * @return array<string, mixed>
     */
    public function deleteOspfInterface(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.delete_ospf_iface',
            'id'     => 'delete_ospf_iface',
            'data'   => ['id' => $data['id']],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_ospf_iface'] ?? $this->baseError('No response for delete_ospf_iface');
    }

    // ── RIP ──────────────────────────────────────────────────────────────────

    /**
     * @param array{
     *     version: 1|2,
     *     enabled: bool,
     *     default_metric: int,
     *     update_timer: int,
     *     timeout_timer: int,
     *     garbage_timer: int,
     * } $data
     * @return array<string, mixed>
     */
    public function saveRipConfig(array $data): array
    {
        $cmd = [
            'method' => 'frr-service.save_rip_config',
            'id'     => 'save_rip_config',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['save_rip_config'] ?? $this->baseError('No response for save_rip_config');
    }

    /**
     * @param array{network_set: string} $data
     * @return array<string, mixed>
     */
    public function addRipNetwork(array $data): array
    {
        if (empty($data['network_set'])) {
            return $this->baseError('network_set is required');
        }
        $cmd = [
            'method' => 'frr-service.add_rip_network',
            'id'     => 'add_rip_network',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_rip_network'] ?? $this->baseError('No response for add_rip_network');
    }

    /**
     * @param array{id: string} $data
     * @return array<string, mixed>
     */
    public function deleteRipNetwork(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.delete_rip_network',
            'id'     => 'delete_rip_network',
            'data'   => ['id' => $data['id']],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_rip_network'] ?? $this->baseError('No response for delete_rip_network');
    }

    // ── IGMP Proxy ───────────────────────────────────────────────────────────

    /**
     * @param array{enabled: bool} $data
     * @return array<string, mixed>
     */
    public function saveIgmpProxyConfig(array $data): array
    {
        $cmd = [
            'method' => 'igmp-service.save_igmp_proxy_config',
            'id'     => 'save_igmp_proxy_config',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['save_igmp_proxy_config'] ?? $this->baseError('No response for save_igmp_proxy_config');
    }

    /**
     * @param array{
     *     iface: string,
     *     role: 'upstream'|'downstream',
     *     whitelist?: string|null,
     * } $data
     * @return array<string, mixed>
     */
    public function addIgmpInterface(array $data): array
    {
        if (empty($data['iface'])) {
            return $this->baseError('iface is required');
        }
        $allowed_roles = ['upstream', 'downstream'];
        if (!in_array($data['role'] ?? '', $allowed_roles, true)) {
            return $this->baseError('role must be upstream or downstream');
        }
        $cmd = [
            'method' => 'igmp-service.add_igmp_iface',
            'id'     => 'add_igmp_iface',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_igmp_iface'] ?? $this->baseError('No response for add_igmp_iface');
    }

    /**
     * @param array{id: string} $data
     * @return array<string, mixed>
     */
    public function deleteIgmpInterface(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'igmp-service.delete_igmp_iface',
            'id'     => 'delete_igmp_iface',
            'data'   => ['id' => $data['id']],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_igmp_iface'] ?? $this->baseError('No response for delete_igmp_iface');
    }

    // ── Policies: Prefix Lists ───────────────────────────────────────────────

    /**
     * @param array{
     *     name: string,
     *     description?: string|null,
     *     entries: array<int, array{seq: int, action: string, prefix_set: string, ge?: int|null, le?: int|null}>,
     * } $data
     * @return array<string, mixed>
     */
    public function addPrefixList(array $data): array
    {
        if (empty($data['name'])) {
            return $this->baseError('name is required');
        }
        if (empty($data['entries']) || !is_array($data['entries'])) {
            return $this->baseError('entries array is required');
        }
        $cmd = [
            'method' => 'frr-service.add_prefix_list',
            'id'     => 'add_prefix_list',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_prefix_list'] ?? $this->baseError('No response for add_prefix_list');
    }

    /**
     * @param array{
     *     id: string,
     *     name?: string,
     *     description?: string|null,
     *     entries?: array<int, array{seq: int, action: string, prefix_set: string, ge?: int|null, le?: int|null}>,
     * } $data
     * @return array<string, mixed>
     */
    public function updatePrefixList(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.update_prefix_list',
            'id'     => 'update_prefix_list',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['update_prefix_list'] ?? $this->baseError('No response for update_prefix_list');
    }

    /**
     * @param array{id: string} $data
     * @return array<string, mixed>
     */
    public function deletePrefixList(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.delete_prefix_list',
            'id'     => 'delete_prefix_list',
            'data'   => ['id' => $data['id']],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_prefix_list'] ?? $this->baseError('No response for delete_prefix_list');
    }

    // ── Policies: Route Maps ─────────────────────────────────────────────────

    /**
     * @param array{
     *     name: string,
     *     description?: string|null,
     *     entries: array<int, array{
     *         seq: int, action: string, description?: string|null,
     *         match?: array{prefix_list?: string|null, as_path_list?: string|null,
     *             community_list?: string|null, community_exact_match?: bool},
     *         set?: array{local_preference?: int|null, metric?: int|null,
     *             community?: string|null, community_additive?: bool,
     *             ip_next_hop_set?: string|null, origin?: string|null,
     *             weight?: int|null, as_path_prepend?: string|null},
     *     }>,
     * } $data
     * @return array<string, mixed>
     */
    public function addRouteMap(array $data): array
    {
        if (empty($data['name'])) {
            return $this->baseError('name is required');
        }
        if (empty($data['entries']) || !is_array($data['entries'])) {
            return $this->baseError('entries array is required');
        }
        $cmd = [
            'method' => 'frr-service.add_route_map',
            'id'     => 'add_route_map',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_route_map'] ?? $this->baseError('No response for add_route_map');
    }

    /**
     * @param array{
     *     id: string,
     *     name?: string,
     *     description?: string|null,
     *     entries?: array<int, array>,
     * } $data
     * @return array<string, mixed>
     */
    public function updateRouteMap(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.update_route_map',
            'id'     => 'update_route_map',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['update_route_map'] ?? $this->baseError('No response for update_route_map');
    }

    /**
     * @param array{id: string} $data
     * @return array<string, mixed>
     */
    public function deleteRouteMap(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.delete_route_map',
            'id'     => 'delete_route_map',
            'data'   => ['id' => $data['id']],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_route_map'] ?? $this->baseError('No response for delete_route_map');
    }

    // ── Policies: AS Path Lists ──────────────────────────────────────────────

    /**
     * @param array{
     *     name: string,
     *     description?: string|null,
     *     entries: array<int, array{seq: int, action: string, regex: string}>,
     * } $data
     * @return array<string, mixed>
     */
    public function addAsPathList(array $data): array
    {
        if (empty($data['name'])) {
            return $this->baseError('name is required');
        }
        if (empty($data['entries']) || !is_array($data['entries'])) {
            return $this->baseError('entries array is required');
        }
        $cmd = [
            'method' => 'frr-service.add_bgp_as_path_list',
            'id'     => 'add_as_path_list',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_as_path_list'] ?? $this->baseError('No response for add_as_path_list');
    }

    /**
     * @param array{
     *     id: string,
     *     name?: string,
     *     description?: string|null,
     *     entries?: array<int, array{seq: int, action: string, regex: string}>,
     * } $data
     * @return array<string, mixed>
     */
    public function updateAsPathList(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.update_bgp_as_path_list',
            'id'     => 'update_as_path_list',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['update_as_path_list'] ?? $this->baseError('No response for update_as_path_list');
    }

    /**
     * @param array{id: string} $data
     * @return array<string, mixed>
     */
    public function deleteAsPathList(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.delete_bgp_as_path_list',
            'id'     => 'delete_as_path_list',
            'data'   => ['id' => $data['id']],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_as_path_list'] ?? $this->baseError('No response for delete_as_path_list');
    }

    // ── Policies: Community Lists ────────────────────────────────────────────

    /**
     * @param array{
     *     name: string,
     *     list_type?: string,
     *     description?: string|null,
     *     entries: array<int, array{seq: int, action: string, community: string}>,
     * } $data
     * @return array<string, mixed>
     */
    public function addCommunityList(array $data): array
    {
        if (empty($data['name'])) {
            return $this->baseError('name is required');
        }
        if (empty($data['entries']) || !is_array($data['entries'])) {
            return $this->baseError('entries array is required');
        }
        $cmd = [
            'method' => 'frr-service.add_bgp_community_list',
            'id'     => 'add_community_list',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_community_list'] ?? $this->baseError('No response for add_community_list');
    }

    /**
     * @param array{
     *     id: string,
     *     name?: string,
     *     list_type?: string,
     *     description?: string|null,
     *     entries?: array<int, array{seq: int, action: string, community: string}>,
     * } $data
     * @return array<string, mixed>
     */
    public function updateCommunityList(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.update_bgp_community_list',
            'id'     => 'update_community_list',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['update_community_list'] ?? $this->baseError('No response for update_community_list');
    }

    /**
     * @param array{id: string} $data
     * @return array<string, mixed>
     */
    public function deleteCommunityList(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('id is required');
        }
        $cmd = [
            'method' => 'frr-service.delete_bgp_community_list',
            'id'     => 'delete_community_list',
            'data'   => ['id' => $data['id']],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_community_list'] ?? $this->baseError('No response for delete_community_list');
    }

    // ── FRR Global ───────────────────────────────────────────────────────────

    /**
     * @param array{profile?: string|null} $data
     * @return array<string, mixed>
     */
    public function saveFrrGlobal(array $data): array
    {
        $cmd = [
            'method' => 'frr-service.save_frr_global',
            'id'     => 'save_frr_global',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['save_frr_global'] ?? $this->baseError('No response for save_frr_global');
    }

    // ── BGP Peer Groups ─────────────────────────────────────────────────────

    /** @param array{name: string, remote_as: string, description?: string|null,
     *     route_map_in?: string|null, route_map_out?: string|null,
     *     update_source_set?: string|null, ebgp_multihop?: int,
     *     next_hop_self?: bool, soft_reconfiguration_inbound?: bool,
     *     route_reflector_client?: bool, bfd?: bool} $data */
    public function addPeerGroup(array $data): array
    {
        if (empty($data['name'])) return $this->baseError('name is required');
        if (empty($data['remote_as'])) return $this->baseError('remote_as is required');
        $cmd = ['method' => 'frr-service.add_bgp_peer_group', 'id' => 'add_peer_group', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_peer_group'] ?? $this->baseError('No response');
    }

    /** @param array{id: string, name?: string, remote_as?: string, description?: string|null,
     *     route_map_in?: string|null, route_map_out?: string|null,
     *     update_source_set?: string|null, ebgp_multihop?: int,
     *     next_hop_self?: bool, soft_reconfiguration_inbound?: bool,
     *     route_reflector_client?: bool, bfd?: bool} $data */
    public function updatePeerGroup(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id is required');
        $cmd = ['method' => 'frr-service.update_bgp_peer_group', 'id' => 'update_peer_group', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['update_peer_group'] ?? $this->baseError('No response');
    }

    /** @param array{id: string} $data */
    public function deletePeerGroup(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id is required');
        $cmd = ['method' => 'frr-service.delete_bgp_peer_group', 'id' => 'delete_peer_group', 'data' => ['id' => $data['id']]];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_peer_group'] ?? $this->baseError('No response');
    }

    /** @param array{id: string, neighbor_id: string} $data */
    public function assignNeighborToPeerGroup(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id (peer group) is required');
        if (empty($data['neighbor_id'])) return $this->baseError('neighbor_id is required');
        $cmd = ['method' => 'frr-service.assign_bgp_neighbor_to_peer_group', 'id' => 'assign_peer_group', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['assign_peer_group'] ?? $this->baseError('No response');
    }

    /** @param array{id: string} $data */
    public function unassignNeighborFromPeerGroup(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id (neighbor) is required');
        $cmd = ['method' => 'frr-service.unassign_bgp_neighbor_from_peer_group', 'id' => 'unassign_peer_group', 'data' => ['id' => $data['id']]];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['unassign_peer_group'] ?? $this->baseError('No response');
    }

    // ── FRR Static Routes ───────────────────────────────────────────────────

    /** @param array{enabled: bool} $data */
    public function saveFrrStaticConfig(array $data): array
    {
        $cmd = ['method' => 'frr-service.save_frr_static_config', 'id' => 'save_frr_static_config', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['save_frr_static_config'] ?? $this->baseError('No response');
    }

    /** @param array{network: string, gateway?: string|null, interface?: string|null,
     *     distance?: int, metric?: int, tag?: int|null, weight?: int|null,
     *     table?: int|null, vrf?: string|null, nexthop_vrf?: string|null,
     *     onlink?: bool, type?: string, description?: string|null} $data */
    public function addFrrStaticRoute(array $data): array
    {
        if (empty($data['network'])) return $this->baseError('network is required');
        $cmd = ['method' => 'frr-service.add_frr_static_route', 'id' => 'add_frr_static_route', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_frr_static_route'] ?? $this->baseError('No response');
    }

    /** @param array{id: string, network?: string, gateway?: string|null, interface?: string|null,
     *     distance?: int, metric?: int, tag?: int|null, weight?: int|null,
     *     table?: int|null, vrf?: string|null, nexthop_vrf?: string|null,
     *     onlink?: bool, type?: string, description?: string|null} $data */
    public function updateFrrStaticRoute(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id is required');
        $cmd = ['method' => 'frr-service.update_frr_static_route', 'id' => 'update_frr_static_route', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['update_frr_static_route'] ?? $this->baseError('No response');
    }

    /** @param array{id: string} $data */
    public function deleteFrrStaticRoute(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id is required');
        $cmd = ['method' => 'frr-service.delete_frr_static_route', 'id' => 'delete_frr_static_route', 'data' => ['id' => $data['id']]];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_frr_static_route'] ?? $this->baseError('No response');
    }

    // ── VRRP ────────────────────────────────────────────────────────────────

    /** @param array{enabled: bool, priority?: int, advertisement_interval?: int,
     *     preempt?: bool, shutdown?: bool, checksum_with_ipv4_pseudoheader?: bool} $data */
    public function saveVrrpConfig(array $data): array
    {
        $cmd = ['method' => 'frr-service.save_vrrp_config', 'id' => 'save_vrrp_config', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['save_vrrp_config'] ?? $this->baseError('No response');
    }

    /** @param array{interface: string, vrid: int, priority?: int,
     *     advertisement_interval?: int, preempt?: bool, shutdown?: bool,
     *     checksum_with_ipv4_pseudoheader?: bool,
     *     ip_addresses?: string[], ipv6_addresses?: string[]} $data */
    public function addVrrpInstance(array $data): array
    {
        if (empty($data['interface'])) return $this->baseError('interface is required');
        if (empty($data['vrid'])) return $this->baseError('vrid is required');
        $cmd = ['method' => 'frr-service.add_vrrp_instance', 'id' => 'add_vrrp_instance', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_vrrp_instance'] ?? $this->baseError('No response');
    }

    /** @param array{id: string, interface?: string, vrid?: int, priority?: int,
     *     advertisement_interval?: int, preempt?: bool, shutdown?: bool,
     *     checksum_with_ipv4_pseudoheader?: bool,
     *     ip_addresses?: string[], ipv6_addresses?: string[]} $data */
    public function updateVrrpInstance(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id is required');
        $cmd = ['method' => 'frr-service.update_vrrp_instance', 'id' => 'update_vrrp_instance', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['update_vrrp_instance'] ?? $this->baseError('No response');
    }

    /** @param array{id: string} $data */
    public function deleteVrrpInstance(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id is required');
        $cmd = ['method' => 'frr-service.delete_vrrp_instance', 'id' => 'delete_vrrp_instance', 'data' => ['id' => $data['id']]];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_vrrp_instance'] ?? $this->baseError('No response');
    }

    // ── BFD Profiles ────────────────────────────────────────────────────────

    /** @param array{name: string, detect_multiplier?: int, receive_interval?: int,
     *     transmit_interval?: int, echo_mode?: bool, echo_receive_interval?: int|string,
     *     echo_transmit_interval?: int, passive_mode?: bool, minimum_ttl?: int,
     *     log_session_changes?: bool} $data */
    public function addBfdProfile(array $data): array
    {
        if (empty($data['name'])) return $this->baseError('name is required');
        $cmd = ['method' => 'frr-service.add_bfd_profile', 'id' => 'add_bfd_profile', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_bfd_profile'] ?? $this->baseError('No response');
    }

    /** @param array{id: string, name?: string, detect_multiplier?: int, receive_interval?: int,
     *     transmit_interval?: int, echo_mode?: bool, echo_receive_interval?: int|string,
     *     echo_transmit_interval?: int, passive_mode?: bool, minimum_ttl?: int,
     *     log_session_changes?: bool} $data */
    public function updateBfdProfile(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id is required');
        $cmd = ['method' => 'frr-service.update_bfd_profile', 'id' => 'update_bfd_profile', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['update_bfd_profile'] ?? $this->baseError('No response');
    }

    /** @param array{id: string} $data */
    public function deleteBfdProfile(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id is required');
        $cmd = ['method' => 'frr-service.delete_bfd_profile', 'id' => 'delete_bfd_profile', 'data' => ['id' => $data['id']]];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_bfd_profile'] ?? $this->baseError('No response');
    }

    // ── OSPFv3 ──────────────────────────────────────────────────────────────

    /** @param array{router_id: string, reference_bandwidth: int, enabled: bool,
     *     log_adjacency_changes: bool} $data */
    public function saveOspf6Config(array $data): array
    {
        if (empty($data['router_id'])) return $this->baseError('router_id is required');
        $cmd = ['method' => 'frr-service.save_ospf6_config', 'id' => 'save_ospf6_config', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['save_ospf6_config'] ?? $this->baseError('No response');
    }

    /** @param array{area_id: string, type: string, no_summary?: bool, network_set: string} $data */
    public function addOspf6Area(array $data): array
    {
        if (empty($data['area_id'])) return $this->baseError('area_id is required');
        if (empty($data['network_set'])) return $this->baseError('network_set is required');
        if (!in_array($data['type'] ?? '', ['normal', 'nssa'], true)) return $this->baseError('type must be normal or nssa');
        $cmd = ['method' => 'frr-service.add_ospf6_area', 'id' => 'add_ospf6_area', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_ospf6_area'] ?? $this->baseError('No response');
    }

    /** @param array{id: string} $data */
    public function deleteOspf6Area(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id is required');
        $cmd = ['method' => 'frr-service.delete_ospf6_area', 'id' => 'delete_ospf6_area', 'data' => ['id' => $data['id']]];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_ospf6_area'] ?? $this->baseError('No response');
    }

    /** @param array{iface: string, area_set: string, priority?: int, cost?: int|null,
     *     hello_interval?: int, dead_interval?: int, passive?: bool} $data */
    public function addOspf6Interface(array $data): array
    {
        if (empty($data['iface'])) return $this->baseError('iface is required');
        if (empty($data['area_set'])) return $this->baseError('area_set is required');
        $cmd = ['method' => 'frr-service.add_ospf6_iface', 'id' => 'add_ospf6_iface', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_ospf6_iface'] ?? $this->baseError('No response');
    }

    /** @param array{id: string} $data */
    public function deleteOspf6Interface(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id is required');
        $cmd = ['method' => 'frr-service.delete_ospf6_iface', 'id' => 'delete_ospf6_iface', 'data' => ['id' => $data['id']]];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_ospf6_iface'] ?? $this->baseError('No response');
    }

    // ── Zebra ───────────────────────────────────────────────────────────────

    /** @param array{router_id?: string|null, ip_nht_resolve_via_default?: bool,
     *     ipv6_nht_resolve_via_default?: bool} $data */
    public function saveZebraConfig(array $data): array
    {
        $cmd = ['method' => 'frr-service.save_zebra_config', 'id' => 'save_zebra_config', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['save_zebra_config'] ?? $this->baseError('No response');
    }

    // ── EVPN ────────────────────────────────────────────────────────────────

    /** @param array{enabled: bool, advertise_all_vni?: bool, advertise_svi_ip?: bool} $data */
    public function saveEvpn(array $data): array
    {
        $cmd = ['method' => 'frr-service.save_evpn', 'id' => 'save_evpn', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['save_evpn'] ?? $this->baseError('No response');
    }

    /** @param array{vrf_name: string, l3vni: int, advertise_ipv4_unicast?: bool,
     *     advertise_ipv6_unicast?: bool} $data */
    public function addEvpnVrf(array $data): array
    {
        if (empty($data['vrf_name'])) return $this->baseError('vrf_name is required');
        if (empty($data['l3vni'])) return $this->baseError('l3vni is required');
        $cmd = ['method' => 'frr-service.add_evpn_vrf', 'id' => 'add_evpn_vrf', 'data' => $data];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_evpn_vrf'] ?? $this->baseError('No response');
    }

    /** @param array{id: string} $data */
    public function deleteEvpnVrf(array $data): array
    {
        if (empty($data['id'])) return $this->baseError('id is required');
        $cmd = ['method' => 'frr-service.delete_evpn_vrf', 'id' => 'delete_evpn_vrf', 'data' => ['id' => $data['id']]];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_evpn_vrf'] ?? $this->baseError('No response');
    }
}
