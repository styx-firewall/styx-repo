<?php
// dr: 2025-12-01
namespace App\Controllers\Submit;
use App\Controllers\BaseController;
use App\Services\DateFormatter;

class SystemSubmitController extends BaseController
{

    public function restartDaemon($data = [])
    {
        $commands = [
            [
                'method' => 'gateway-daemon.restart-daemon',
                'id' => 'restart_daemon',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['restart_daemon'] ?? $this->baseError('No response for restart_daemon');
    }

    public function systemReboot($data = [])
    {
        $commands = [
            [
                'method' => 'system-mgmt.system-reboot',
                'id' => 'system_reboot',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['system_reboot'] ?? $this->baseError('No response for system_reboot');
    }

    public function updateSetting($data = [])
    {
        $key = $data['key'] ?? null;
        $value = $data['value'] ?? null;
        if (!$key || $value === null) {
            return $this->baseError('Missing key or value');
        }
        $allowed = ['hostname', 'domain', 'timezone', 'language'];
        if (!in_array($key, $allowed, true)) {
            return ['status' => 'error', 'response_msg' => 'Setting not allowed'];
        }
        if ($key === 'hostname') {
            $command = 'set-hostname';
        } elseif ($key === 'domain') {
            $command = 'set-domain';
        } elseif ($key === 'timezone') {
            $command = 'set-timezone';
        } elseif ($key === 'language') {
            $command = 'set-language';
        } else {
            return $this->baseError('Invalid setting key');
        }

        $commands = [
            [
                'method' => 'system-mgmt.' . ($command),
                'id' => 'update_setting',
                'data' => [$key => $value]
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['update_setting'] ?? $this->baseError('No response for update_setting');
    }

    public function getSystemLogs($payload)
    {
        $data = [];
        if (isset($payload['level']) && !empty($payload['level'])) {
            $data['level'] = $payload['level'];
        }
        if (isset($payload['limit'])) {
            $data['limit'] = (int)$payload['limit'];
        } else {
            $data['limit'] = 50;
        }
        if (isset($payload['last_id'])) {
            $data['last_id'] = (int)$payload['last_id'];
        }

        $commands = [
            [
                'method' => 'log-watcher.get_system_logs',
                'id' => 'get_system_logs',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['get_system_logs'] ?? null;
        if (!$cmd) {
            return $this->baseError('No response for get_system_logs');
        }
        if (($cmd['status'] ?? null) === 'success' && isset($cmd['result'])) {
            $result = $cmd['result'];
            // Pre-format timestamps server-side using the user's timezone and locale.
            $logs = $result['system_logs'] ?? [];
            if (is_array($logs)) {
                foreach ($logs as $k => $log) {
                    $ts = $log['timestamp_iso'] ?? $log['date'] ?? null;
                    if ($ts !== null) {
                        $logs[$k]['date_fmt'] = DateFormatter::fromBackend($this->ctx, (string)$ts);
                    }
                }
                $result['system_logs'] = $logs;
            }
            return ['status' => 'success', 'result' => $result];
        }
        return $cmd;
    }

    public function updateSshConfig($data = [])
    {
        $enabled = isset($data['enabled']) ? (bool)$data['enabled'] : null;
        $port = isset($data['port']) ? (int)$data['port'] : null;
        $listen = $data['listen_addresses'] ?? [];

        if ($enabled === null || $port === null) {
            return $this->baseError('Missing parameters');
        }
        if ($port < 1 || $port > 65535) {
            return $this->baseError('Invalid port');
        }

        $commands = [
            [
                'method' => 'system-mgmt.set_ssh_config',
                'id' => 'set_ssh_config',
                'data' => [
                    'enabled' => $enabled,
                    'port' => $port,
                    'listen_addresses' => $listen
                ]
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['set_ssh_config'] ?? null;
        if (!$cmd) {
            return $this->baseError('No response for set_ssh_config');
        }
        if (($cmd['status'] ?? null) === 'success') {
            return ['status' => 'success', 'response_msg' => $cmd['response_msg'] ?? 'SSH config updated'];
        }
        return $cmd;
    }

    public function deleteCertificate($data = [])
    {
        $id = $data['id'] ?? null;
        if (empty($id)) {
            return $this->baseError('Missing certificate id');
        }

        $commands = [
            [
                'method' => 'certs-mgmt.delete_certificate',
                'id' => 'delete_certificate',
                'data' => ['id' => $id]
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['delete_certificate'] ?? null;
        if (!$cmd) {
            return $this->baseError('No response for delete_certificate');
        }
        $status = $cmd['status'] ?? 'error';
        $msg = $cmd['response_msg'] ?? ($status === 'success' ? 'Certificate deleted' : 'Delete failed');
        $out = ['status' => $status, 'response_msg' => $msg];
        if ($status === 'success' && isset($cmd['result'])) {
            $out['result'] = $cmd['result'];
        }
        return $out;
    }

    public function uploadCertificate($data = [])
    {
        $type = $data['type'] ?? null;
        $certB64 = $data['cert_b64'] ?? null;
        $keyB64 = $data['key_b64'] ?? null;
        $name = $data['name'] ?? null;
        $fileName = $data['file_name'] ?? null;
        $keyFileName = $data['key_file_name'] ?? null;

        if (!$type || !$certB64) {
            return $this->baseError('Missing type or certificate data');
        }
        if (empty($fileName)) {
            return $this->baseError('Missing original certificate file name');
        }
        if ($type === 'pair') {
            if (!$keyB64) {
                return $this->baseError('Missing key data for pair upload');
            }
            if (empty($keyFileName)) {
                return $this->baseError('Missing original key file name for pair upload');
            }
        }

        $cmdData = ['type' => $type, 'cert_b64' => $certB64];
        if ($type === 'pair') {
            $cmdData['key_b64'] = $keyB64;
        }
        if (!empty($fileName)) {
            $cmdData['file_name'] = $fileName;
        }
        if (!empty($keyFileName)) {
            $cmdData['key_file_name'] = $keyFileName;
        }
        if (!empty($name)) {
            $cmdData['name'] = $name;
        }

        $commands = [
            [
                'method' => 'certs-mgmt.upload_certificate',
                'id' => 'upload_certificate',
                'data' => $cmdData
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['upload_certificate'] ?? null;
        if (!$cmd) {
            return $this->baseError('No response for upload_certificate');
        }
        $status = $cmd['status'] ?? 'error';
        $msg = $cmd['response_msg'] ?? ($status === 'success' ? 'Uploaded' : 'Upload failed');
        return ['status' => $status, 'response_msg' => $msg];
    }

    /**
     * Trigger async package list update (apt update).
     */
    public function updatePackageLists($data = [])
    {
        $commands = [
            [
                'method' => 'system-mgmt.update-package-lists',
                'id' => 'update_package_lists',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['update_package_lists'] ?? null;
        if (!$cmd) {
            return $this->baseError('No response for update_package_lists');
        }
        $status = $cmd['status'] ?? 'error';
        $msg = $cmd['response_msg'] ?? ($status === 'success' ? 'Package list update started' : 'Update failed');
        $out = ['status' => $status, 'response_msg' => $msg];
        if ($status === 'success' && isset($cmd['result'])) {
            $out['result'] = $cmd['result'];
        }
        return $out;
    }

    /**
     * Trigger async package upgrade (apt dist-upgrade).
     */
    public function upgradePackages($data = [])
    {
        $runUpdateFirst = !empty($data['run_update_first']);
        $commands = [
            [
                'method' => 'system-mgmt.upgrade-packages',
                'id' => 'upgrade_packages',
                'data' => ['run_update_first' => $runUpdateFirst],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['upgrade_packages'] ?? null;
        if (!$cmd) {
            return $this->baseError('No response for upgrade_packages');
        }
        $status = $cmd['status'] ?? 'error';
        $msg = $cmd['response_msg'] ?? ($status === 'success' ? 'Package upgrade started' : 'Upgrade failed');
        $out = ['status' => $status, 'response_msg' => $msg];
        if ($status === 'success' && isset($cmd['result'])) {
            $out['result'] = $cmd['result'];
        }
        return $out;
    }

    public function systemServices($data = [])
    {
        $service = $data['service'] ?? null;
        $action = $data['action'] ?? null;
        if (empty($service) || empty($action)) {
            return ['status' => 'error', 'response_msg' => 'Missing service or action'];
        }
        $allowed = ['start', 'stop', 'restart', 'enable', 'disable'];
        if (!in_array($action, $allowed, true)) {
            return ['status' => 'error', 'response_msg' => 'Invalid action'];
        }

        if ($action === 'restart') {
            $commands = [
                [
                    'method' => 'system-services.reload-or-restart',
                    'id' => 'service_action',
                    'data' => ['service_name' => $service],
                ]
            ];
        } else {
            $cmdName = $action . '-service';
            $commands = [
                [
                    'method' => 'system-services.' . ($cmdName),
                    'id' => 'service_action',
                    'data' => ['service_name' => $service],
                ]
            ];
        }
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['service_action'] ?? $this->baseError('No response for service_action');
    }
}
