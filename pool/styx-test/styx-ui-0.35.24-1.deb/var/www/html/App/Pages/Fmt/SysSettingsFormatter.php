<?php
/**
 * Formatter for system settings page.
 * Moves small presentation helpers out of the template.
 */
namespace App\Pages\Fmt;

class SysSettingsFormatter
{
    /**
     * Prepare display strings and ensure keys exist for the template.
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $settings = $fmt_data ?? [];
        $sys = $settings['system_info'] ?? [];
        $ssh = $settings['ssh'] ?? [];

        $ssh_enabled_text = (!empty($ssh['enabled']))
            ? 'Enabled, port ' . ($ssh['port'] ?? '22')
            : 'Disabled';

        $ssh_listen_text = '';
        if (!empty($ssh['listen_addresses']) && is_array($ssh['listen_addresses'])) {
            $ssh_listen_text = implode(', ', $ssh['listen_addresses']);
        }

        $fmt_data['system_info'] = $sys;
        $fmt_data['ssh'] = $ssh;
        $fmt_data['ssh_enabled_text'] = $ssh_enabled_text;
        $fmt_data['ssh_listen_text'] = $ssh_listen_text;

        return $fmt_data;
    }
}
