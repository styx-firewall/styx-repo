<?php
namespace App\Pages\Fmt;

class DashboardFormatter
{
    /**
     * Ensure presentation-ready keys for dashboard pages.
     * @param array $fmt_data
     * @return array
     */
    public static function format(array $fmt_data): array
    {
        $fmt_data['hostname']     = $fmt_data['hostname'] ?? 'Unknown';
        $fmt_data['domain']       = $fmt_data['domain'] ?? 'Unknown';
        $fmt_data['version']      = $fmt_data['version'] ?? '';
        $fmt_data['fw_status']    = $fmt_data['fw_status'] ?? 'Unknown';
        $fmt_data['update']       = $fmt_data['update'] ?? 'Unknown';
        $fmt_data['uptime']       = $fmt_data['uptime'] ?? '';
        $fmt_data['styx_uptime']  = $fmt_data['styx_uptime'] ?? '';
        $fmt_data['num_cpus']     = $fmt_data['num_cpus'] ?? 0;
        $fmt_data['arch']         = $fmt_data['arch'] ?? '';
        $fmt_data['kernel']       = $fmt_data['kernel'] ?? '';
        $fmt_data['os_name']      = $fmt_data['os_name'] ?? '';
        $fmt_data['os_version']   = $fmt_data['os_version'] ?? '';
        $fmt_data['language']     = $fmt_data['language'] ?? '';
        $fmt_data['timezone']     = $fmt_data['timezone'] ?? '';
        $fmt_data['system_uuid']  = self::truncateMiddle($fmt_data['system_uuid'] ?? '', 23);
        $fmt_data['machine_id']   = self::truncateMiddle($fmt_data['machine_id'] ?? '', 23);

        // Chart arrays
        $fmt_data['cpu_usage'] = $fmt_data['cpu_usage'] ?? [];
        $fmt_data['memory_usage'] = $fmt_data['memory_usage'] ?? [];
        $fmt_data['network_usage'] = $fmt_data['network_usage'] ?? [];
        // dash-charts page: list of {id, label} for rendering switches + canvas blocks
        // Single source of truth — add a new chart here and it appears in the UI automatically
        $fmt_data['charts'] = $fmt_data['charts'] ?? [
            ['id' => 'cpu',                         'label' => 'CPU Usage'],
            ['id' => 'iowait',                      'label' => 'I/O Wait'],
            ['id' => 'memory',                      'label' => 'Memory Usage'],
            ['id' => 'network-tx',                  'label' => 'Network TX'],
            ['id' => 'network-rx',                  'label' => 'Network RX'],
            ['id' => 'tcp-mem',                     'label' => 'TCP Memory'],
            ['id' => 'udp-mem',                     'label' => 'UDP Memory'],
            ['id' => 'tcp-inuse',                   'label' => 'TCP Inuse'],
            ['id' => 'udp-inuse',                   'label' => 'UDP Inuse'],
            ['id' => 'raw-inuse',                   'label' => 'RAW Inuse'],
            ['id' => 'fragments',                   'label' => 'Fragments'],
            ['id' => 'tcp-orphan',                  'label' => 'TCP Orphan'],
            ['id' => 'tcp-time-wait',               'label' => 'TCP TIME_WAIT'],
            ['id' => 'tcp-connections-established',  'label' => 'TCP ESTABLISHED'],
            ['id' => 'tcp-connections-close-wait',   'label' => 'TCP CLOSE_WAIT'],
            ['id' => 'tcp-connections-listen',       'label' => 'TCP LISTEN'],
            ['id' => 'tcp-connections-total',        'label' => 'TCP Total'],
            ['id' => 'udp-connections-total',        'label' => 'UDP Total'],
            ['id' => 'conntrack-count',              'label' => 'ConnTrack Count'],
            ['id' => 'conntrack-pressure',           'label' => 'ConnTrack Pressure'],
            ['id' => 'softnet-processed',            'label' => 'Softnet Processed'],
            ['id' => 'softnet-dropped',              'label' => 'Softnet Dropped'],
            ['id' => 'softnet-drop-pct',             'label' => 'Softnet Drop %'],
            ['id' => 'softnet-squeeze',              'label' => 'Softnet Squeeze'],
            ['id' => 'softnet-squeeze-pct',          'label' => 'Softnet Squeeze %'],
        ];

        return $fmt_data;
    }

    /**
     * Truncate a string from the middle, keeping start and end.
     */
    private static function truncateMiddle(string $val, int $max): string
    {
        if (strlen($val) <= $max) {
            return $val;
        }
        $half = (int) floor(($max - 1) / 2);
        return substr($val, 0, $half) . '…' . substr($val, -$half);
    }
}
