<?php
/**
 * Formatter for the logs settings page (logs-settings section).
 *
 * Presentation logic only: normalizes the raw log settings object from the
 * gateway into template-ready values under $fmt_data['settings_ui']. Echo-only
 * templates consume the precomputed keys instead of validating or defaulting
 * themselves.
 */
namespace App\Pages\Fmt;

use App\Constants\LogLevel;

class LogsSettingsFormatter
{
    /**
     * @param array<string,mixed> $fmt_data expects 'settings', 'bounds',
     *                            'settings_error', 'can_write'
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $settings = $fmt_data['settings'] ?? [];
        $bounds = $fmt_data['bounds'] ?? [];
        $settings_error = $fmt_data['settings_error'] ?? false;

        // The gateway always returns the full normalized settings object. A
        // missing or incomplete object is treated as an error: no frontend
        // defaults are substituted here, otherwise a backend default change
        // would silently drift from the values shown in the UI.
        $sys = is_array($settings) ? ($settings['system_logs'] ?? null) : null;
        $sty = is_array($settings) ? ($settings['styx_logs'] ?? null) : null;
        $valid = is_array($sys) && is_int($sys['buffer_size'] ?? null)
            && is_array($sty) && is_int($sty['buffer_size'] ?? null)
            && is_int($sty['min_level'] ?? null);

        if (!$valid && $settings_error === false) {
            $settings_error = 'Log settings are missing or incomplete';
        }

        // Buffer range: taken from the gateway bounds so the UI never drifts from
        // the backend; fall back to a conservative default when they are absent.
        $buffer_min = is_int($bounds['buffer_min'] ?? null) ? $bounds['buffer_min'] : 1;
        $buffer_max = is_int($bounds['buffer_max'] ?? null) ? $bounds['buffer_max'] : 8000;

        // Level select options (name + numeric syslog value), current one selected.
        $min_level = $valid ? (int)$sty['min_level'] : null;
        $level_options = [];
        foreach (LogLevel::getConstants() as $name => $value) {
            $level_options[] = [
                'name'     => $name,
                'value'    => (int)$value,
                'selected' => ((int)$value === $min_level),
            ];
        }

        $fmt_data['settings_ui'] = [
            'error'              => $settings_error,
            'disabled_attr'      => (!empty($fmt_data['can_write']) && $settings_error === false) ? '' : 'disabled',
            'system_buffer_size' => $valid ? $sys['buffer_size'] : '',
            'styx_buffer_size'   => $valid ? $sty['buffer_size'] : '',
            'styx_min_level'     => $min_level,
            'buffer_min'         => $buffer_min,
            'buffer_max'         => $buffer_max,
            'level_options'      => $level_options,
        ];

        return $fmt_data;
    }
}
