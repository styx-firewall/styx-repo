<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

/**
 * On-demand system readings (backend module system-detail.*).
 *
 * Nothing here is cached and the cost of the commands is very uneven: a /proc
 * read is instant, get_cpu_usage samples for 0.1 s, get_iowait_usage for 1 s,
 * get_processes walks every process and get_smart_disks_info runs smartctl
 * (up to 10 s per disk). The gateway blocks a batch on its slowest command, so
 * the caller names exactly the metrics it wants and leaves the slow ones for a
 * request of their own.
 *
 * The action exists because `refresh` builds its commands from page/section by
 * design and refuses to forward arbitrary ones; this module had no read path
 * at all.
 */
class SystemDetailController extends BaseController
{
    /**
     * Accepted metric key => gateway command. Every command answers under the
     * key it is named after, so a key doubles as the response field.
     */
    private const METRICS = [
        'loadavg'     => 'system-detail.get_load_avg',
        'meminfo'     => 'system-detail.get_memory_info',
        'disksinfo'   => 'system-detail.get_disks_info',
        'cpu_usage'   => 'system-detail.get_cpu_usage',
        'iowait'      => 'system-detail.get_iowait_usage',
        'processes'   => 'system-detail.get_processes',
        'smart_disks' => 'system-detail.get_smart_disks_info',
    ];

    /**
     * Read the requested metrics in a single gateway round trip.
     *
     * @param array $data body with `metrics`: list of metric keys
     * @return array{result: array<string, mixed>}|array
     */
    public function handle(array $data): array
    {
        $metrics = $data['metrics'] ?? null;
        if (!is_array($metrics) || $metrics === []) {
            return $this->baseError('`metrics` must be a non-empty list');
        }

        $unknown = array_values(array_diff(array_unique($metrics), array_keys(self::METRICS)));
        if ($unknown !== []) {
            return $this->baseError('Unknown metric: ' . implode(', ', $unknown));
        }

        $commands = [];
        foreach (array_unique($metrics) as $metric) {
            $commands[] = [
                'method' => self::METRICS[$metric],
                'id'     => $metric,
                'data'   => (object)[],
            ];
        }

        // No read timeout is requested on purpose: the transport drops it
        // today (GatewayService never passes it to connect()), so the socket
        // keeps its 10 s default and get_smart_disks_info can time out on a
        // host with several disks. Passing a hint that is silently ignored
        // would read as a guarantee; see the note in the system-info plan.
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $result = [];
        foreach ($resp['commands'] as $id => $cmd) {
            if (($cmd['status'] ?? null) !== 'success') {
                continue;
            }
            $payload = $cmd['result'] ?? [];
            $result[$id] = $payload[$id] ?? $payload;
        }

        return [
            'status'   => 'success',
            'result'   => $result,
            'warnings' => $resp['warnings'] ?? [],
        ];
    }
}
