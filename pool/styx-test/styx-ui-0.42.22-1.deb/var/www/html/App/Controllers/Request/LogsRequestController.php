<?php
/**
 * Controller for handling log settings requests.
 */
namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class LogsRequestController extends BaseController
{
    /**
     * Get the log buffering settings (system_logs / styx_logs) plus the accepted
     * range for the buffer size, as returned by the gateway.
     *
     * @return array
     */
    public function getLogSettings()
    {
        $commands[] = [
            'method' => 'log-settings.get_log_settings',
            'id'     => 'log_settings',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $result = $resp['commands']['log_settings']['result'] ?? [];
        return [
            'status'   => $resp['status'],
            'result'   => [
                'settings' => $result['settings'] ?? [],
                'bounds'   => $result['bounds'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }
}
