const POLL_FAST=5000;const POLL_PROCESSES=15000;const PROCESSES_FIRST_DELAY=1500;const SCAN_TIMEOUT=60000;const HEALTH_BADGE={ok:'std-badge--success',warning:'std-badge--warning',fail:'std-badge--danger',unknown:'std-badge--muted',};function $id(id){return document.getElementById(id);}
function setText(id,value){const node=$id(id);if(node)node.textContent=value;}
function esc(value){return String(value===null||value===undefined?'':value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
function isNum(value){return typeof value==='number'&&isFinite(value);}
function fmtPct(value){return isNum(value)?value.toFixed(1)+'%':'—';}
function fmtMb(value){return isNum(value)?value+' MB':'—';}
function fmtLoad(value){return isNum(value)?value.toFixed(2):'—';}
function clampPct(value){return Math.max(0,Math.min(100,Number(value)||0));}
function levelOf(value){if(value>=90)return'crit';if(value>=75)return'warn';return'ok';}
function levelOfInverted(value){if(value<=10)return'crit';if(value<=25)return'warn';return'ok';}
function roundPct(value){return Math.round(clampPct(value)*10)/10;}
function setMeter(id,value){const fill=$id(id);if(!fill)return;const v=roundPct(value);fill.style.setProperty('--std-progress-value',v);if(fill.parentElement)fill.parentElement.setAttribute('data-level',levelOf(v));}
function blocksHtml(value,extraClass,level){const v=roundPct(value);const lvl=level===undefined?levelOf(v):level;return'<div class="std-progress std-progress--blocks'+(extraClass?' '+extraClass:'')+'"'+
(lvl?' data-level="'+lvl+'"':'')+' title="'+v.toFixed(1)+'%">'+'<div class="std-progress-fill" style="--std-progress-value:'+v+'"></div></div>';}
function pctOf(part,total){if(!isNum(part)||!isNum(total)||total<=0)return 0;return clampPct(part/total*100);}
function meterRowHtml(label,value,text,level){return'<div class="sysinfo-meter-row">'+'<span class="sysinfo-meter-row-label">'+esc(label)+'</span>'+
blocksHtml(value,'std-progress--grow',level)+'<span class="sysinfo-meter-row-value">'+esc(text)+'</span>'+'</div>';}
function detail(metrics,opts){return apiClient.request('sys_detail',{metrics:metrics},opts||{});}
function loop(fn,interval,firstDelay){async function tick(){try{await fn();}catch(e){}
setTimeout(tick,interval);}
setTimeout(tick,firstDelay||0);}
function renderLoad(load){setText('sysinfo-load-1',fmtLoad(load['1min']));setText('sysinfo-load-5',fmtLoad(load['5min']));setText('sysinfo-load-15',fmtLoad(load['15min']));setText('sysinfo-load-usage',fmtPct(load.usage));}
function renderMemory(mem){setText('sysinfo-mem-value',fmtPct(mem.percent));setMeter('sysinfo-mem-bar',mem.percent);setText('sysinfo-mem-sub',fmtMb(mem.used)+' used of '+fmtMb(mem.total));const box=$id('sysinfo-mem-rows');if(!box)return;const rows=[];if(isNum(mem.cache_used))rows.push(['Cached',mem.cache_used,null]);if(isNum(mem.available)){rows.push(['Available',mem.available,levelOfInverted(pctOf(mem.available,mem.total))]);}
if(isNum(mem.free))rows.push(['Free',mem.free,null]);box.innerHTML=rows.map(function(row){return meterRowHtml(row[0],pctOf(row[1],mem.total),fmtMb(row[1]),row[2]);}).join('');}
function renderDisks(rows){const body=$id('sysinfo-disks-rows');if(!body)return;if(!Array.isArray(rows)||rows.length===0){body.innerHTML='<tr><td colspan="6">No mounted filesystems reported.</td></tr>';return;}
body.innerHTML=rows.map(function(d){return'<tr>'+'<td>'+esc(d.mountpoint)+'</td>'+'<td>'+esc(d.device)+'</td>'+'<td>'+esc(d.fstype)+'</td>'+'<td style="text-align:right;">'+fmtMb(d.used)+'</td>'+'<td style="text-align:right;">'+fmtMb(d.free)+'</td>'+'<td>'+blocksHtml(d.percent,'std-progress--sm')+'</td>'+'</tr>';}).join('');}
function renderCpu(cpu){setText('sysinfo-cpu-value',fmtPct(cpu.usage));setText('sysinfo-cpu-sub',isNum(cpu.cores)?cpu.cores+' cores':'—');setMeter('sysinfo-cpu-bar',cpu.usage);const box=$id('sysinfo-cpu-cores');if(!box)return;if(!Array.isArray(cpu.per_core)||cpu.per_core.length===0){box.innerHTML='';return;}
box.innerHTML=cpu.per_core.map(function(core){const v=clampPct(core.usage);return meterRowHtml('cpu'+core.core,v,v.toFixed(0)+'%');}).join('');}
const SORT_STORAGE_KEY='system-info-proc-sort';const PROC_COLUMNS={pid:'num',program:'text',command:'text',user:'text',threads:'num',memory:'num',cpu:'num',};const DEFAULT_SORT={key:'cpu',dir:'desc'};let procSort=loadProcSort();let lastProcesses=null;function loadProcSort(){try{const saved=JSON.parse(localStorage.getItem(SORT_STORAGE_KEY)||'null');if(saved&&PROC_COLUMNS[saved.key]&&(saved.dir==='asc'||saved.dir==='desc')){return{key:saved.key,dir:saved.dir};}}catch(e){}
return{key:DEFAULT_SORT.key,dir:DEFAULT_SORT.dir};}
function saveProcSort(){try{localStorage.setItem(SORT_STORAGE_KEY,JSON.stringify(procSort));}catch(e){}}
function compareProcesses(a,b){const sign=procSort.dir==='asc'?1:-1;const key=procSort.key;let order;if(PROC_COLUMNS[key]==='num'){order=(Number(a[key])||0)-(Number(b[key])||0);}else{order=String(a[key]===undefined?'':a[key]).localeCompare(String(b[key]===undefined?'':b[key]));}
return order*sign;}
function procTable(){const body=$id('sysinfo-proc-rows');return body?body.closest('table'):null;}
function markSortedColumn(){const table=procTable();if(!table)return;table.querySelectorAll('th[data-sort]').forEach(function(th){if(th.getAttribute('data-sort')===procSort.key){th.setAttribute('data-dir',procSort.dir);}else{th.removeAttribute('data-dir');}});}
function initProcessSorting(){const table=procTable();if(!table)return;table.querySelectorAll('th[data-sort]').forEach(function(th){th.addEventListener('click',function(){const key=th.getAttribute('data-sort');if(key===procSort.key){procSort.dir=procSort.dir==='asc'?'desc':'asc';}else{procSort.key=key;procSort.dir=PROC_COLUMNS[key]==='num'?'desc':'asc';}
saveProcSort();markSortedColumn();if(lastProcesses)renderProcesses(lastProcesses);});});markSortedColumn();}
function renderProcesses(rows){const body=$id('sysinfo-proc-rows');if(!body)return;if(!Array.isArray(rows))return;lastProcesses=rows;setText('sysinfo-proc-sub',rows.length+' processes');const sorted=rows.slice().sort(compareProcesses);if(sorted.length===0){body.innerHTML='<tr><td colspan="7">No processes reported.</td></tr>';return;}
body.innerHTML=sorted.map(function(p){return'<tr>'+'<td>'+esc(p.pid)+'</td>'+'<td>'+esc(p.program)+'</td>'+'<td title="'+esc(p.command)+'">'+esc(p.command)+'</td>'+'<td>'+esc(p.user)+'</td>'+'<td style="text-align:right;">'+esc(p.threads)+'</td>'+'<td style="text-align:right;">'+fmtMb(p.memory)+'</td>'+'<td style="text-align:right;">'+fmtPct(p.cpu)+'</td>'+'</tr>';}).join('');}
function renderIowait(iowait){setText('sysinfo-iowait-value',fmtPct(iowait.usage));setMeter('sysinfo-iowait-bar',iowait.usage);}
function renderSmart(disks){const body=$id('sysinfo-smart-rows');if(!body)return;if(!Array.isArray(disks)||disks.length===0){body.innerHTML='<tr><td colspan="5">No disks reported by smartctl.</td></tr>';return;}
body.innerHTML=disks.map(function(d){const health=HEALTH_BADGE[d.health]?d.health:'unknown';const temp=isNum(d.temperature)?d.temperature+' °C':'—';return'<tr>'+'<td>'+esc(d.device)+'</td>'+'<td title="'+esc(d.model)+'">'+esc(d.model)+'</td>'+'<td><span class="std-badge '+HEALTH_BADGE[health]+' std-badge--dot">'+
esc(health)+'</span></td>'+'<td>'+esc(d.status)+'</td>'+'<td style="text-align:right;">'+temp+'</td>'+'</tr>';}).join('');}
async function pollFast(){const res=await detail(['loadavg','meminfo','disksinfo','cpu_usage','iowait']);if(res.status!=='success'||!res.result)return;if(res.result.loadavg)renderLoad(res.result.loadavg);if(res.result.meminfo)renderMemory(res.result.meminfo);if(res.result.disksinfo)renderDisks(res.result.disksinfo);if(res.result.cpu_usage)renderCpu(res.result.cpu_usage);if(res.result.iowait)renderIowait(res.result.iowait);}
async function pollProcesses(){const res=await detail(['processes']);if(res.status!=='success'||!res.result)return;renderProcesses(res.result.processes);}
async function scanSmart(){const button=$id('sysinfo-smart-scan');const note=$id('sysinfo-smart-note');if(button)button.disabled=true;if(note)note.textContent='Scanning… smartctl runs once per disk.';const res=await detail(['smart_disks'],{timeout:SCAN_TIMEOUT});if(res.status!=='success'||!res.result||!Array.isArray(res.result.smart_disks)){if(note)note.textContent=res.response_msg||'Scan failed.';}else{renderSmart(res.result.smart_disks);if(note)note.textContent='Scanned at '+new Date().toLocaleTimeString()+'.';}
if(button)button.disabled=false;}
async function initChart(){const canvas=$id('cpu-chart');if(!canvas||typeof window.registerChart!=='function')return;window.chartDefaults={responsive:true};const version=document.querySelector('meta[name="app-version"]')?.content||'0';const refreshers=(await import('/scripts/charts/charts-index.js?v='+version)).default;if(refreshers&&refreshers.cpu){window.registerChart('cpu',null,refreshers.cpu,'15m');}}
document.addEventListener('DOMContentLoaded',function(){const scanButton=$id('sysinfo-smart-scan');if(scanButton)scanButton.addEventListener('click',scanSmart);initProcessSorting();loop(pollFast,POLL_FAST);loop(pollProcesses,POLL_PROCESSES,PROCESSES_FIRST_DELAY);initChart();scanSmart();});