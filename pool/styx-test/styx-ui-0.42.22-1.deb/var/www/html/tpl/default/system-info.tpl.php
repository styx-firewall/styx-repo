<?php

/**
 * TemplateService->getTpl()
 * @var array<mixed> $tdata
 *
 * System info panel. Six cards, grouped by what the readings are about rather
 * than one per backend command: CPU carries load average and I/O wait (both are
 * CPU states), and Storage carries the filesystems and the disks.
 *
 * Every card is hydrated by scripts/charts-core/system-info.js, except the
 * identity card: its rows reuse the exact `#sysinfo-*` ids that
 * scripts/refresh/systemOverview.js already fills from the cached
 * system-overview snapshot the page refresh loop delivers, so that card needs
 * no JavaScript of its own.
 */
$page_data = $tdata['page_data'] ?? [];
?>

<?= $tdata['page_head'] ?>
<div class="page-layout">
    <?= $tdata['sidebar'] ?>
    <main class="page-content">
        <h1>Dashboard</h1>
        <h2>System Info</h2>
        <div class="sysinfo-panel">
            <div class="sysinfo-grid">

                <section class="sysinfo-card sysinfo-span-2">
                    <header class="sysinfo-card-header">
                        <span class="sysinfo-card-title">System</span>
                    </header>
                    <div class="sysinfo-card-body">
                        <div class="std-flex-row">
                            <div class="std-flex-col">Hostname</div>
                            <div class="std-flex-col" id="sysinfo-hostname">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">Domain</div>
                            <div class="std-flex-col" id="sysinfo-domain">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">Styx GW Version</div>
                            <div class="std-flex-col" id="sysinfo-version">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">OS</div>
                            <div class="std-flex-col" id="sysinfo-os-name">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">Kernel</div>
                            <div class="std-flex-col" id="sysinfo-kernel">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">CPUs</div>
                            <div class="std-flex-col" id="sysinfo-cpus">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">System Uptime</div>
                            <div class="std-flex-col" id="sysinfo-uptime">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">Styx Uptime</div>
                            <div class="std-flex-col" id="sysinfo-styx-uptime">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">Status</div>
                            <div class="std-flex-col" id="sysinfo-status">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">Updates</div>
                            <div class="std-flex-col" id="sysinfo-update">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">System Language</div>
                            <div class="std-flex-col" id="sysinfo-language">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">System Timezone</div>
                            <div class="std-flex-col" id="sysinfo-timezone">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">System UUID</div>
                            <div class="std-flex-col uuid-val" id="sysinfo-system-uuid" title="">—</div>
                        </div>
                        <div class="std-flex-row">
                            <div class="std-flex-col">Machine ID</div>
                            <div class="std-flex-col uuid-val" id="sysinfo-machine-id" title="">—</div>
                        </div>
                    </div>
                </section>

                <section class="sysinfo-card sysinfo-span-2">
                    <header class="sysinfo-card-header">
                        <span class="sysinfo-card-title">CPU</span>
                        <span class="sysinfo-card-sub" id="sysinfo-cpu-sub">—</span>
                    </header>
                    <div class="sysinfo-card-body">
                        <div class="sysinfo-card-value" id="sysinfo-cpu-value">—</div>
                        <div class="std-progress std-progress--blocks" data-level="ok" style="margin: 0.5rem 0 1rem;">
                            <div class="std-progress-fill" id="sysinfo-cpu-bar" style="--std-progress-value:0"></div>
                        </div>
                        <div class="sysinfo-meter-list" id="sysinfo-cpu-cores"></div>

                        <div class="sysinfo-subhead" style="margin-top:1rem;">Load Average</div>
                        <div class="sysinfo-stats">
                            <div class="sysinfo-stat">
                                <span class="sysinfo-stat-label">1 min</span>
                                <span class="sysinfo-stat-value" id="sysinfo-load-1">—</span>
                            </div>
                            <div class="sysinfo-stat">
                                <span class="sysinfo-stat-label">5 min</span>
                                <span class="sysinfo-stat-value" id="sysinfo-load-5">—</span>
                            </div>
                            <div class="sysinfo-stat">
                                <span class="sysinfo-stat-label">15 min</span>
                                <span class="sysinfo-stat-value" id="sysinfo-load-15">—</span>
                            </div>
                            <div class="sysinfo-stat">
                                <span class="sysinfo-stat-label">Usage</span>
                                <span class="sysinfo-stat-value" id="sysinfo-load-usage">—</span>
                            </div>
                        </div>

                        <div class="sysinfo-subhead" style="margin-top:1rem;">I/O Wait</div>
                        <div class="sysinfo-stat">
                            <span class="sysinfo-stat-label">Wait</span>
                            <span class="sysinfo-stat-value" id="sysinfo-iowait-value">—</span>
                        </div>
                        <div class="std-progress std-progress--blocks" data-level="ok" style="margin-top:0.5rem;">
                            <div class="std-progress-fill" id="sysinfo-iowait-bar" style="--std-progress-value:0"></div>
                        </div>
                    </div>
                </section>

                <section class="sysinfo-card sysinfo-span-2">
                    <header class="sysinfo-card-header">
                        <span class="sysinfo-card-title">Memory</span>
                    </header>
                    <div class="sysinfo-card-body">
                        <div class="sysinfo-card-value" id="sysinfo-mem-value">—</div>
                        <div class="std-progress std-progress--blocks" data-level="ok" style="margin: 0.5rem 0;">
                            <div class="std-progress-fill" id="sysinfo-mem-bar" style="--std-progress-value:0"></div>
                        </div>
                        <div class="sysinfo-card-sub" id="sysinfo-mem-sub">—</div>
                        <div class="sysinfo-meter-list sysinfo-meter-list--wide" id="sysinfo-mem-rows"
                             style="margin-top:0.75rem;"></div>
                    </div>
                </section>

                <section class="sysinfo-card sysinfo-span-3">
                    <header class="sysinfo-card-header">
                        <span class="sysinfo-card-title">CPU Usage</span>
                    </header>
                    <div class="sysinfo-card-body">
                        <canvas id="cpu-chart"></canvas>
                    </div>
                </section>

                <section class="sysinfo-card sysinfo-span-3 sysinfo-span-full-4">
                    <header class="sysinfo-card-header">
                        <span class="sysinfo-card-title">Storage</span>
                    </header>
                    <div class="sysinfo-card-body">
                        <div class="sysinfo-subhead">Filesystems</div>
                        <div class="sysinfo-table-wrap">
                            <table class="std-table">
                                <thead>
                                    <tr>
                                        <th>Mount</th>
                                        <th>Device</th>
                                        <th>Type</th>
                                        <th style="text-align:right;">Used</th>
                                        <th style="text-align:right;">Free</th>
                                        <th>Usage</th>
                                    </tr>
                                </thead>
                                <tbody id="sysinfo-disks-rows">
                                    <tr><td colspan="6">—</td></tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="sysinfo-subhead" style="margin-top:1rem;">Disks</div>
                        <div class="std-flex-row" style="gap:8px;">
                            <button type="button" class="std-btn" id="sysinfo-smart-scan">Scan disks</button>
                            <span class="sysinfo-card-sub" id="sysinfo-smart-note">
                                Scanned on load; the button repeats it. smartctl runs on every
                                disk and can take up to 10 s each.
                            </span>
                        </div>
                        <div class="sysinfo-table-wrap">
                            <table class="std-table">
                                <thead>
                                    <tr>
                                        <th>Device</th>
                                        <th>Model</th>
                                        <th>Health</th>
                                        <th>SMART</th>
                                        <th style="text-align:right;">Temp</th>
                                    </tr>
                                </thead>
                                <tbody id="sysinfo-smart-rows">
                                    <tr><td colspan="5">Not scanned yet.</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

                <section class="sysinfo-card sysinfo-span-full">
                    <header class="sysinfo-card-header">
                        <span class="sysinfo-card-title">Processes</span>
                        <span class="sysinfo-card-sub" id="sysinfo-proc-sub">—</span>
                    </header>
                    <div class="sysinfo-card-body">
                        <div class="sysinfo-table-wrap sysinfo-table-wrap--scroll">
                            <table class="std-table">
                                <thead>
                                    <tr>
                                        <th class="sysinfo-col-pid" data-sort="pid">PID</th>
                                        <th class="sysinfo-col-program" data-sort="program">Program</th>
                                        <th data-sort="command">Command</th>
                                        <th class="sysinfo-col-user" data-sort="user">User</th>
                                        <th class="sysinfo-col-num" data-sort="threads" style="text-align:right;">Threads</th>
                                        <th class="sysinfo-col-num" data-sort="memory" style="text-align:right;">MEM</th>
                                        <th class="sysinfo-col-num" data-sort="cpu" style="text-align:right;">CPU</th>
                                    </tr>
                                </thead>
                                <tbody id="sysinfo-proc-rows">
                                    <tr><td colspan="7">—</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

            </div>
        </div>
    </main>
</div>
