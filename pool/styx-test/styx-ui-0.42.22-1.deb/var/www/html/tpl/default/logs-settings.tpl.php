<?php

/**
 * TemplateService->getTpl()
 *
 * Included: logs-settings.js
 *
 * @var array<mixed> $tdata
 */
// Presentation data prepared by LogsSettingsFormatter (echo-only template).
$ui = $tdata['page_data']['settings_ui'] ?? [];
// logs:write capability gates the controls.
$can_write = !empty($tdata['page_data']['can_write']);
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Logs Settings</h1>

        <?php if (!empty($ui['error'])): ?>
            <div class="std-error-box">
                <strong>Error:</strong> could not load the log settings. Nothing was changed; the controls are
                disabled until the page is reloaded.
                <?php if (is_string($ui['error'])): ?>
                    <span class="fw-text-muted">(<?= htmlspecialchars($ui['error']) ?>)</span>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <p class="fw-settings-desc">
            The buffer size is how many entries the gateway keeps
            (and therefore the most any request can return); it also sets how much history is preloaded at startup.
        </p>

        <div class="fw-settings-cols">
            <section class="card card--compact">
                <header class="card-header">
                    <h2 class="card-heading">System logs</h2>
                </header>
                <div class="card-body">
                    <div class="setting-row">
                        <div>
                            <strong>Buffer size</strong>
                            <div class="fw-setting-hint">
                                Number of journald entries kept in memory for the System Logs view.
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <input type="number"
                                class="logs-setting-number"
                                data-path="system_logs.buffer_size"
                                value="<?= $ui['system_buffer_size'] ?>"
                                min="<?= $ui['buffer_min'] ?>" max="<?= $ui['buffer_max'] ?>" step="1"
                                <?= $ui['disabled_attr'] ?>>
                        </div>
                    </div>
                </div>
            </section>

            <section class="card card--compact">
                <header class="card-header">
                    <h2 class="card-heading">Styx logs</h2>
                </header>
                <div class="card-body">
                    <div class="setting-row">
                        <div>
                            <strong>Buffer size</strong>
                            <div class="fw-setting-hint">
                                Number of gateway log entries kept in memory for the Styx Logs view.
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <input type="number"
                                class="logs-setting-number"
                                data-path="styx_logs.buffer_size"
                                value="<?= $ui['styx_buffer_size'] ?>"
                                min="<?= $ui['buffer_min'] ?>" max="<?= $ui['buffer_max'] ?>" step="1"
                                <?= $ui['disabled_attr'] ?>>
                        </div>
                    </div>
                    <div class="setting-row">
                        <div>
                            <strong>Minimum level</strong>
                            <div class="fw-setting-hint">
                                Only messages at this severity or more severe are kept in the Styx Logs view.
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <select class="std-select logs-setting-level"
                                data-path="styx_logs.min_level"
                                <?= $ui['disabled_attr'] ?>>
                                <?php foreach ($ui['level_options'] as $opt): ?>
                                    <option value="<?= $opt['value'] ?>"<?= $opt['selected'] ? ' selected' : '' ?>>
                                        <?= $opt['name'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <p class="fw-settings-note">
            Changes take effect immediately for the running buffers. The startup preload uses the new size on the
            next restart.
        </p>

        <?php if (!$can_write): ?>
            <p class="fw-settings-note">
                You do not have permission to modify the log settings.
            </p>
        <?php endif; ?>
    </main>
</div>
