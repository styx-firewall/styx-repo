# ebpf_modules/net_block/net_block_companion.py

import ctypes

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import serialize_ipv4, serialize_cidr, serialize_uint32
from _helpers import format_ipv4, format_cidr, format_uint32
from _helpers import ktime_to_epoch, u32_to_ip

# Companion API

_SERIALIZERS = {
    "blocklist": serialize_ipv4,
    "cidr_rules": serialize_cidr,
    "cfg_map": serialize_uint32,
}
_FORMATTERS = {
    "blocklist": format_ipv4,
    "cidr_rules": format_cidr,
    "cfg_map": format_uint32,
}


def serialize_entry(items, map_name, op):
    try:
        handler = _SERIALIZERS[map_name]
    except KeyError:
        raise ValueError(f"Map '{map_name}' does not support push")
    return [handler(item) for item in items]


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# C struct mirrors (keep in sync with net_block.c)


class StatsT(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("hits", ctypes.c_uint64),
        ("drops", ctypes.c_uint64),
        ("bytes_seen", ctypes.c_uint64),
        ("last_seen_ns", ctypes.c_uint64),
        ("ring_drops", ctypes.c_uint64),
    ]


class EventT(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("ts_ns", ctypes.c_uint64),
        ("src_ip", ctypes.c_uint32),
        ("dst_ip", ctypes.c_uint32),
        ("dport", ctypes.c_uint16),
        ("proto", ctypes.c_uint8),
        ("action", ctypes.c_uint8),
    ]


# Telemetry / Event deserializers


@register_deserializer("net_block", "stats")
class StatsDeserializer(FeedbackDeserializer):
    # `stats` is a PERCPU map, so the collector combines one value per CPU. The
    # counters add up; `last_seen` is a timestamp, so it is the newest one that
    # counts and it is published as it is (a delta of two epochs is meaningless).
    absolute_fields = ("last_seen",)

    def from_map(self, raw, spec, key=None) -> dict:
        s = StatsT.from_buffer_copy(bytes(raw))
        return {
            "hits": s.hits,
            "drops": s.drops,
            "bytes_seen": s.bytes_seen,
            "last_seen": ktime_to_epoch(s.last_seen_ns),
            "ring_drops": s.ring_drops,
        }

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")


@register_deserializer("net_block", "blocked_events")
class BlockedEventDeserializer(FeedbackDeserializer):
    def from_map(self, raw, spec, key=None) -> dict:
        raise NotImplementedError("blocked_events is an event buffer, not a telemetry map")

    def from_event(self, data: bytes, size: int, spec) -> dict:
        e = EventT.from_buffer_copy(data[:size])
        return {
            "ts_ns": e.ts_ns,
            # u32_to_ip, not IPv4Address(e.src_ip): the fields hold the addresses
            # as they sit in the packet (network order), so the int a c_uint32
            # gives back is that sequence backwards.
            "src_ip": u32_to_ip(e.src_ip),
            "dst_ip": u32_to_ip(e.dst_ip),
            "dport": e.dport,
            "proto": e.proto,
            "action": e.action,
        }
