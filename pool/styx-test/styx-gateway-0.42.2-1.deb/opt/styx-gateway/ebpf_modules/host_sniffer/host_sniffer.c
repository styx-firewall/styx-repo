// SPDX-License-Identifier: GPL-2.0
// host_sniffer.c — passive host discovery via socket filter
//
// Extracts source MAC + source IP from every IPv4 packet and stores
// the mapping in a BPF hash.  Designed for both BCC (DEV) and
// libbpf CO-RE (PROD) compilation.

#ifndef BCC_COMPILE
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>

#ifndef ETH_P_IP
#define ETH_P_IP 0x0800
#endif
#endif

// ── Data ─────────────────────────────────────────────────────────────────

struct host_entry {
    __u64 mac;
    __u32 ip;
} __attribute__((packed));

// telemetry_map: name="hosts" — MAC → IP mapping
struct {
    __uint(type,        BPF_MAP_TYPE_HASH);
    __uint(max_entries, 4096);
    __type(key,         __u64);            // MAC address packed into u64
    __type(value,       __u32);            // IPv4 address
} hosts SEC(".maps");

// ── MAC helper ───────────────────────────────────────────────────────────

static __always_inline __u64 mac_to_u64(const unsigned char *mac) {
    return ((__u64)mac[0])       | ((__u64)mac[1] << 8)  |
           ((__u64)mac[2] << 16) | ((__u64)mac[3] << 24) |
           ((__u64)mac[4] << 32) | ((__u64)mac[5] << 40);
}

// ── Program ──────────────────────────────────────────────────────────────

SEC("socket_filter")
int sniff_hosts(struct __sk_buff *skb) {
    unsigned char mac[6];
    unsigned short eth_proto;
    unsigned char ip[4];

    // Read source MAC at offset 6 (destination is 0-5, source is 6-11)
    if (bpf_skb_load_bytes(skb, 6, mac, 6) < 0)
        return 0;

    // Read EtherType at offset 12
    if (bpf_skb_load_bytes(skb, 12, &eth_proto, 2) < 0)
        return 0;

    // Only process IPv4
    if (__builtin_bswap16(eth_proto) != ETH_P_IP)
        return 0;

    // Read source IP at offset 26 (14B eth header + 12B into IP header)
    if (bpf_skb_load_bytes(skb, 26, ip, 4) < 0)
        return 0;

    __u64 macval = mac_to_u64(mac);
    __u32 ipval  = ((__u32)ip[0])       | ((__u32)ip[1] << 8) |
                   ((__u32)ip[2] << 16) | ((__u32)ip[3] << 24);

    bpf_map_update_elem(&hosts, &macval, &ipval, BPF_ANY);
    return 0;
}

char _license[] SEC("license") = "GPL";
