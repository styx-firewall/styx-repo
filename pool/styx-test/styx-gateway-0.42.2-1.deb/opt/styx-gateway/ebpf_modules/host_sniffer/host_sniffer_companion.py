# modules/host_sniffer/host_sniffer_companion.py
#
# Companion for host_sniffer.  Registers a deserializer for the hosts
# telemetry map (MAC → IP).

import ctypes
import ipaddress

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer


class HostEntryT(ctypes.Structure):
    """Mirror of struct host_entry in host_sniffer.c."""

    _pack_ = 1
    _fields_ = [
        ("mac", ctypes.c_uint64),
        ("ip", ctypes.c_uint32),
    ]


@register_deserializer("host_sniffer", "hosts")
class HostsDeserializer(FeedbackDeserializer):
    def from_map(self, raw, spec, key=None) -> dict:
        # raw is a single struct host_entry value (ctypes or bytes)
        if hasattr(raw, "mac"):
            s = raw
        else:
            s = HostEntryT.from_buffer_copy(bytes(raw))

        mac_bytes = [(s.mac >> (8 * i)) & 0xFF for i in range(6)]
        mac_str = ":".join(f"{b:02x}" for b in mac_bytes)
        ip_str = str(ipaddress.IPv4Address(s.ip))

        return {"mac": mac_str, "ip": ip_str}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("hosts is a telemetry map, not an event buffer")
