# test_custom_serializer/test_custom_serializer_companion.py -- TEST-ONLY fixture.
#
# Demonstrates a third-party companion with custom formatting.
# The pattern is the same for every module: import helpers, map names to handlers.

from _helpers import bytes_to_int


def serialize_entry(items, map_name, op):
    if map_name == "dns_blocklist":
        return [_serialize_dns(item) for item in items]
    raise ValueError(f"Map '{map_name}' does not support push")


def format_map_entry(key, value, map_name):
    if map_name == "dns_blocklist":
        return _format_dns(key, value)
    return None, None


# ── dns_name helpers ──────────────────────────────────────────────────────────

_DNS_KEY_SIZE = 64


def _serialize_dns(item):
    import ctypes

    name = item if isinstance(item, str) else item.get("name", item)
    key = (ctypes.c_char * _DNS_KEY_SIZE)()
    key.value = name.encode()[: _DNS_KEY_SIZE - 1]
    if isinstance(item, dict):
        return (key, ctypes.c_uint8(item.get("action", 1)))
    return (key, ctypes.c_uint8(1))


def _format_dns(key, value):
    if isinstance(key, bytes):
        name = key.split(b"\x00")[0].decode("utf-8", errors="replace")
    else:
        name = key.name.decode("utf-8", errors="replace") if hasattr(key, "name") else str(key)
    val = bytes_to_int(value) if value is not None else None
    return (name, val)
