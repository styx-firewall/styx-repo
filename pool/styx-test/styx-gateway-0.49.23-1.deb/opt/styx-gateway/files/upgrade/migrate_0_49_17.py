"""
Migration script: -> 0.49.17

Deploys the PHP-FPM configuration of the web UI on installations that already
exist: the daemon config, the php.ini and the pool. Fresh installations get the
same three files from the first-boot templates (configure/system_templates.py),
so this migration only covers the boxes that are already running.

Until now the pool stayed at the distribution defaults, which for a UI that
proxies every request to the gateway socket means no ceiling for a worker stuck
waiting on the gateway, no idle-timeout status to size the pool with, and a
worker count meant for a generic application. The php.ini also dropped PHP into
answers, stopped nothing on the session side, and left sessions reaped before
their cookie expired.

php-fpm is reloaded afterwards. SIGUSR2 reloads the pools and re-executes the
fpm binary, so the new php.ini is re-read as well, and no session is dropped.
"""

import os
import shutil

from core.app_context import AppContext
from services.system_services import SystemServices

TAG = "[MIGRATE 0.49.17]"

SRC_DIR = "/opt/styx-gateway/files/cfg-tpl"

TEMPLATES = {
    # template                (destination,                            mode)
    "php-fpm.conf": ("/etc/php/8.4/fpm/php-fpm.conf", 0o644),
    "php.ini": ("/etc/php/8.4/fpm/php.ini", 0o644),
    "php-www.conf": ("/etc/php/8.4/fpm/pool.d/www.conf", 0o644),
}


def run(ctx: AppContext) -> bool:
    """Copy the three PHP-FPM templates into /etc and reload php8.4-fpm."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    ok = True

    for filename, (dest, mode) in TEMPLATES.items():
        src = os.path.join(SRC_DIR, filename)
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            os.chmod(dest, mode)
            logger.notice(f"{TAG} Deployed {filename} -> {dest} (mode {oct(mode)})")
        except Exception as e:
            logger.error(f"{TAG} Failed to deploy {filename} -> {dest}: {e}")
            ok = False

    result = SystemServices.reload_or_restart(ctx, "php8.4-fpm", non_blocking=True)
    if result.ok:
        logger.notice(f"{TAG} php8.4-fpm reload requested.")
    else:
        logger.warning(f"{TAG} php8.4-fpm reload failed: {result.msg}")
        ok = False

    if ok:
        logger.notice(f"{TAG} Migration completed successfully.")
    else:
        logger.notice(f"{TAG} Migration completed with errors (check logs).")
    return ok
