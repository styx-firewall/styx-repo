"""
Migration script: -> 0.49.21

Re-imposes the rsyslog base config (/etc/rsyslog.conf) on installations that
already exist, to pick up the imjournal fix.

imjournal was loading without a state file, so every rsyslog start (that is,
every system boot) read the journal from its beginning and forwarded all of it
to the configured destination. On a box whose journal goes back weeks that is
hundreds of thousands of syslog packets in one burst when the network comes up;
the firewall logs every outgoing packet, so the same burst lands in the firewall
log as hundreds of MB and stalls the firewall-log watcher until it catches up.

Fresh installations get the corrected file from the product template when the
rsyslogd feature reconciles it, so this migration only covers running boxes.

It only touches the file when the rsyslogd feature is enabled: that feature owns
/etc/rsyslog.conf, and on a box that does not use it the file belongs to the
distribution and must stay untouched. The file is written by the same code the
feature uses (ensure_base_config), so the migration does exactly what a feature
reconcile would do, no more.

Carried over from 0.49.20, whose script failed on every box: it asked
StyxFeatures for the enabled features, and that reads the memory store, which
does not exist yet when migrations run.
"""

from constants.datastore_keys import DS_KEY_FEATURES_STATE
from core.app_context import AppContext

TAG = "[MIGRATE 0.49.21]"


def _rsyslogd_enabled(ctx: AppContext) -> bool:
    """Whether the rsyslogd feature is switched on, read from the datastore.

    Not through StyxFeatures: its constructor reads the enabled set from the
    memory store, which bootstrap() has not built yet when migrations run (they
    run from main(), before run()). Reading the key directly is what is available
    at this point.
    """
    state = ctx.get_datastore().get_data(DS_KEY_FEATURES_STATE) or {}
    selected = state.get("selected") if isinstance(state, dict) else None
    return bool(isinstance(selected, dict) and selected.get("rsyslogd"))


def run(ctx: AppContext) -> bool:
    """Re-impose the rsyslog base config and reload rsyslog when it changed."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    try:
        enabled = _rsyslogd_enabled(ctx)
    except Exception as e:
        logger.error(f"{TAG} Could not read the enabled features: {e}")
        return False

    if not enabled:
        logger.info(f"{TAG} rsyslogd feature not enabled; leaving /etc/rsyslog.conf alone.")
        return True

    from services.rsyslog.rsyslog_apply import ensure_base_config, reload_rsyslog, rsyslog_present

    if not rsyslog_present():
        logger.info(f"{TAG} rsyslog not installed; nothing to do.")
        return True

    base = ensure_base_config(ctx)
    if not base.ok:
        logger.error(f"{TAG} Could not write /etc/rsyslog.conf: {base.msg}")
        return False

    if base.data and base.data.get("changed"):
        reload_result = reload_rsyslog(ctx)
        if not reload_result.ok:
            logger.warning(f"{TAG} rsyslog reload failed: {reload_result.msg}")
            return False
        logger.notice(f"{TAG} /etc/rsyslog.conf updated and rsyslog reloaded.")
    else:
        logger.info(f"{TAG} /etc/rsyslog.conf already up to date.")

    logger.notice(f"{TAG} Migration completed successfully.")
    return True
