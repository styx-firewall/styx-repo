<?php

namespace App\Controllers\Submit;

use App\Controllers\BaseController;
use App\Helpers\ContentFilterResp;

/**
 * DNS filter write path.
 *
 * Registered commands (SubmitRegistry):
 *   dns-filter.set_settings -> setSettings()
 *
 * Responses are canonicalized through App\Helpers\ContentFilterResp: messages
 * always come from result.msg (the top-level response_msg legacy bridge is
 * ignored). RBAC is enforced by the backend (content_filter:write).
 *
 * No `posture` here: the policy is the catalogue's (categories.set_posture),
 * because this filter cuts first and a divergent web filter would only be heard
 * on the flows this one did not see. `DATA_KEYS` is what keeps a posture out of
 * the call: this endpoint changes what this mechanism does with the policy, not
 * what the policy is.
 *
 * Saving **applies**, and only while the filter is on: the gateway regenerates
 * the nft rules, repoints the running engine at the shared policy and updates
 * the live decider. When the filter is off the settings are still stored, but
 * the response says so (`apply` is null and the message says they take effect
 * when it is enabled) - the UI must surface that rather than report a plain
 * success.
 *
 * An error can therefore mean the settings were stored but could not be put in
 * force; result.msg says which, and the UI must surface it.
 */
class DnsFilterSubmitController extends BaseController
{
    /** Top-level keys accepted by the partial settings payload. */
    private const DATA_KEYS = [
        'sinkhole_address',
        'sinkhole_address6',
        'fail_mode',
        'chains',
    ];

    /**
     * Save a (partial) set of this filter's settings. Omitted keys keep their
     * current value; `chains` is replaced wholesale, so the frontend always
     * sends the complete list.
     *
     * @param array<string,mixed> $data request body (command/metadata are ignored)
     * @return array<string,mixed>
     */
    public function setSettings(array $data = []): array
    {
        $unknown = $this->unknownFields($data, self::DATA_KEYS);
        if (!empty($unknown)) {
            return ContentFilterResp::error('unknown field(s): ' . implode(', ', $unknown));
        }
        $payload  = array_intersect_key($data, array_flip(self::DATA_KEYS));
        $commands = [
            [
                'method' => 'dns-filter.set_settings',
                'id'     => 'set_settings',
                'data'   => $payload,
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return ContentFilterResp::single($resp, 'set_settings');
    }
}
