<?php
/**
 * ContentFilterPostureFormatter - shared presentation helpers for the content
 * filter panes.
 *
 * The catalogue, the web filter and the DNS filter all render the same three
 * things: a category by name, the policy as one of three actions, and the
 * runtime counters. Building them once here is what keeps the three panes
 * saying the same words about the same policy.
 *
 * That policy is **one**, and it is decided in the catalogue
 * (categories.set_posture). The DNS filter cuts first, so a filter that kept a
 * different one would only be heard on the flows the other did not see: a hole
 * in the policy, not a second policy. Neither filter's own pane edits it.
 *
 * Templates are echo-only: every derived text, badge class and selected token is
 * computed in this class.
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class ContentFilterPostureFormatter
{
    /** The actions a policy can hold, in menu order. */
    public const ACTIONS = ['monitor', 'allow', 'block'];

    /** Action -> the word the operator reads. */
    private const ACTION_LABELS = [
        'monitor' => 'Monitor',
        'allow'   => 'Allow',
        'block'   => 'Block',
    ];

    /**
     * The status keys that are NOT counters.
     *
     * The status carries the running counters nesting one level down, and next
     * to them a few things that are not numbers at all: the two decision lists
     * (already shown as badges) and the resolved targets (already shown in the
     * target cards). Flattening those into label/value pairs would print
     * "Blocked_categories / 0 = adult", which reads like a measurement and is
     * not one.
     */
    private const NOT_COUNTERS = ['blocked_categories', 'qos_categories', 'resolved'];

    /**
     * Classifier name -> the word the operator reads.
     *
     * The backend sends the observer's own `name` in its status, and this is
     * where it becomes a heading: `http-observer` says what the code calls it,
     * "HTTP (Host header)" says what it reads.
     */
    private const OBSERVER_LABELS = [
        'http-observer' => 'HTTP (Host header)',
        'sni-observer'  => 'TLS (SNI)',
    ];

    /**
     * The three actions as <option> rows for one category, the current one
     * selected.
     *
     * A category with no entry in the policy is `monitor`: that is what the
     * backend does with an absent key, and showing it as anything else would
     * misrepresent what the filter is doing.
     *
     * @return array<int,array<string,string>>
     */
    public static function actions(string $current): array
    {
        $out = [];
        foreach (self::ACTIONS as $value) {
            $out[] = [
                'value_attr' => Filter::escHtml($value),
                'label_html' => Filter::escHtml(self::ACTION_LABELS[$value] ?? $value),
                'selected'   => $value === $current ? 'selected' : '',
            ];
        }
        return $out;
    }

    /**
     * Category id -> human label, for showing a policy or a status by name.
     *
     * Raw on purpose: this is the lookup the callers below index into, not a
     * field that reaches a template.
     *
     * @param array<int,array<string,mixed>> $categories
     * @return array<string,string>
     */
    public static function labels(array $categories): array
    {
        $out = [];
        foreach ($categories as $category) {
            if (!is_array($category)) {
                continue;
            }
            $id = (string)($category['id'] ?? '');
            if ($id !== '') {
                $out[$id] = (string)($category['label'] ?? $id);
            }
        }
        return $out;
    }

    /**
     * Resolve a list of category ids to display rows, keeping unknown ids
     * visible: a policy naming a category this build no longer ships is a fact
     * the operator needs to see, not one to hide.
     *
     * @param array<int,string>    $ids
     * @param array<string,string> $labels
     * @return array<int,array<string,string>>
     */
    public static function named(array $ids, array $labels): array
    {
        $out = [];
        foreach ($ids as $id) {
            $key = (string)$id;
            $out[] = [
                'id_attr'    => Filter::escHtml($key),
                'label_html' => Filter::escHtml($labels[$key] ?? $key),
            ];
        }
        return $out;
    }

    /**
     * The runtime counters, grouped by the piece they came from.
     *
     * Grouped, and not one flat list, because the pieces answer different
     * questions: "applied" in the core and "flows_written" in the labeler are not
     * comparable, and a flat list makes the reader hold all of them at once.
     *
     * What becomes a counter, and what does not:
     *
     * - **A number** is one. A **boolean** is a state and a **string** is a name:
     *   neither is a measurement, and "running: 1" reads like one. Both are said
     *   elsewhere on the pane -- the state in the pane's own line, the name in the
     *   group's title.
     * - **A keyed array** is flattened into its group with a compound label
     *   ("prefix / buffered_flows"). Dropping a level in silence is how a counter
     *   stops being visible at all, which is the one failure this pane cannot
     *   afford: it exists to be read when something looks wrong.
     * - **A list of scalars** is one row with the values joined: the interfaces
     *   being captured, the ports a classifier reads. A list is a set of things
     *   the piece is working on, not a measurement of it.
     * - **A list of keyed arrays** is a group per item, titled with the item's own
     *   name, because each classifier has its own numbers and the counters alone
     *   do not say whose they are.
     *
     * @param array<string,mixed> $status
     * @return array<int,array<string,mixed>> [['title_html' => string, 'rows' =>
     *                                         [['label_html' => string, 'value_html' => string]]]]
     */
    public static function counterGroups(array $status): array
    {
        $out = [];
        foreach ($status as $key => $value) {
            $key = (string)$key;
            if (in_array($key, self::NOT_COUNTERS, true) || !is_array($value)) {
                continue;
            }
            if (array_is_list($value)) {
                $position = 0;
                foreach ($value as $item) {
                    if (!is_array($item) || array_is_list($item)) {
                        continue;
                    }
                    $rows = self::counterRows($item);
                    if ($rows === []) {
                        continue;
                    }
                    $position++;
                    $out[] = [
                        'title_html' => self::groupTitle($item, $key, $position),
                        'rows'       => $rows,
                    ];
                }
                continue;
            }
            $rows = self::counterRows($value);
            if ($rows !== []) {
                $out[] = ['title_html' => Filter::escHtml(ucfirst($key)), 'rows' => $rows];
            }
        }
        return $out;
    }

    /**
     * How many counter rows the groups hold: what the folded summary counts.
     *
     * @param array<int,array<string,mixed>> $groups
     */
    public static function counterCount(array $groups): int
    {
        $total = 0;
        foreach ($groups as $group) {
            $total += count($group['rows'] ?? []);
        }
        return $total;
    }

    /**
     * One group's rows, from the status the piece itself reported.
     *
     * @param array<string,mixed> $data
     * @param string              $prefix the path already walked, for nested keys
     * @return array<int,array<string,string>>
     */
    private static function counterRows(array $data, string $prefix = ''): array
    {
        $rows = [];
        foreach ($data as $name => $value) {
            $label = $prefix === '' ? (string)$name : $prefix . ' / ' . (string)$name;
            if (is_array($value)) {
                if (array_is_list($value)) {
                    $joined = self::joinedScalars($value);
                    if ($joined !== '') {
                        $rows[] = self::row($label, $joined);
                    }
                    continue;
                }
                foreach (self::counterRows($value, $label) as $row) {
                    $rows[] = $row;
                }
                continue;
            }
            if (!is_int($value) && !is_float($value)) {
                continue;
            }
            $rows[] = self::row($label, (string)$value);
        }
        return $rows;
    }

    /**
     * A list's scalars, joined for one row, or '' when there is nothing to join.
     *
     * A list holding a structure is not a value -- that shape is a group, and it
     * is handled as one.
     *
     * @param array<int,mixed> $values
     */
    private static function joinedScalars(array $values): string
    {
        $out = [];
        foreach ($values as $value) {
            if ($value === null || is_bool($value) || is_array($value)) {
                return '';
            }
            $out[] = (string)$value;
        }
        return implode(', ', $out);
    }

    /**
     * The title of a group that came from a list: the item's own name when it
     * carries one, so an observer's numbers are attributed by the observer.
     *
     * @param array<string,mixed> $item
     */
    private static function groupTitle(array $item, string $key, int $position): string
    {
        $name = is_scalar($item['name'] ?? null) ? (string)$item['name'] : '';
        if ($name !== '') {
            return Filter::escHtml(self::OBSERVER_LABELS[$name] ?? ucfirst(str_replace('-', ' ', $name)));
        }
        return Filter::escHtml(ucfirst($key) . ' ' . $position);
    }

    /**
     * One counter row. Escaped here, because templates only echo.
     */
    private static function row(string $label, string $value): array
    {
        return [
            'label_html' => Filter::escHtml($label),
            'value_html' => Filter::escHtml($value),
        ];
    }
}
