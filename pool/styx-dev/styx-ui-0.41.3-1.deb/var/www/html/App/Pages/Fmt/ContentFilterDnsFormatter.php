<?php
/**
 * ContentFilterDnsFormatter - presentation helpers for the DNS filter pane.
 *
 * This pane carries two things the web filter's does not, and both are design
 * decisions that have to survive the trip to the screen:
 *
 *   - **Nothing configured is the clean cut, not a gap.** With both targets
 *     empty a blocked name is answered NXDOMAIN: the client never opens a
 *     connection, so there is nothing to serve, nothing to allow and no address
 *     of the appliance exposed to the user network. The pane says that where the
 *     operator would otherwise read an empty box as "unfinished".
 *   - **The appliance serves no page, and that is deliberate.** A page here would
 *     be a service the users can reach, on an address of the appliance - the
 *     management plane with a door into the user network. There is no setting for
 *     it, so showing a blocked user something means pointing the address at a
 *     server of the operator's own, and the pane says so next to the fields.
 *
 * There is **no policy editor here**: what is blocked is decided once, in the
 * catalogue, because this filter cuts first. What this pane holds is what only
 * this mechanism decides - where a blocked answer is sent, and what happens when
 * it is not there.
 *
 * Each family is one card carrying its own field and what that field became, so
 * the configured value and the resolved one are never read across the width of a
 * table: "I set a name and it did not resolve" and "I set nothing" are different
 * answers and only the operator can tell which they meant.
 *
 * Templates are echo-only: every derived text, badge class, attribute and
 * selected token is computed here.
 *
 * @see App\Pages\PageContentFilter
 * @see api/handlers/dns_filter.md
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class ContentFilterDnsFormatter
{
    /** Which failure is acceptable in this network (design doc, decision 24). */
    private const FAIL_MODES = [
        'bypass' => 'Bypass - if the filter is down, DNS keeps flowing unfiltered',
        'strict' => 'Strict - if the filter is down, DNS is cut',
    ];

    /** Where the resolver is, which decides which chain the rule must live in (decision 25). */
    private const CHAINS = [
        'forward' => 'forward - clients resolve through an external resolver',
        'output'  => 'output - this appliance is the resolver for its clients',
    ];

    /**
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    public static function format(array $data, bool $canEdit, bool $featureOn): array
    {
        $settings   = is_array($data['settings'] ?? null) ? $data['settings'] : [];
        $status     = is_array($data['status'] ?? null) ? $data['status'] : [];
        $categories = is_array($data['categories'] ?? null) ? $data['categories'] : [];

        $labels   = ContentFilterPostureFormatter::labels($categories);
        $address  = (string)($settings['sinkhole_address'] ?? '');
        $address6 = (string)($settings['sinkhole_address6'] ?? '');
        $resolved = is_array($status['resolved'] ?? null) ? $status['resolved'] : [];

        $failMode = (string)($settings['fail_mode'] ?? 'bypass');
        $chains   = is_array($settings['chains'] ?? null) ? $settings['chains'] : [];
        $counterGroups = ContentFilterPostureFormatter::counterGroups($status);
        $queueNum = $status['queue_num'] ?? null;

        // `feature_on` is what the operator switched on; `running` is the filter's own
        // answer about its pieces, and the two can disagree -- a filter that is enabled but
        // whose reader could not bind answers no query while the pane says "Running". A
        // server that does not report `running` yet makes no claim, so it warns about
        // nothing either.
        $enabledNotRunning = array_key_exists('running', $status) && empty($status['running']);

        return [
            // Escaped here: the template echoes what it is given, it never
            // escapes and never casts.
            'error_html'        => self::message($data['error'] ?? null),
            'status_error_html' => self::message($data['status_error'] ?? null),
            'feature_on'    => $featureOn,
            // Enabled but not up: the badge and the warning need the same answer.
            'enabled_not_running' => $enabledNotRunning,
            'can_edit'      => $canEdit,
            'disabled_attr' => $canEdit ? '' : 'disabled',
            'targets'       => [
                self::target(
                    'IPv4',
                    'cf-address',
                    'IPv4 address or name',
                    $address,
                    (string)($resolved['sinkhole_ip'] ?? '')
                ),
                self::target(
                    'IPv6',
                    'cf-address6',
                    'IPv6 address or name',
                    $address6,
                    (string)($resolved['sinkhole_ip6'] ?? '')
                ),
            ],
            // The promise, made visible where the empty boxes are.
            'cut_mode'         => $address === '' && $address6 === '',
            // The appliance serves no page of its own, and there is no setting to
            // turn one on: the note says it where the operator would look for it.
            'fail_modes'       => self::options(self::FAIL_MODES, $failMode),
            'fail_mode_aria_attr' => Filter::escHtml('Which failure is acceptable in this network'),
            'chain_rows'       => self::chainRows($chains),
            'queue_num'        => is_scalar($queueNum) ? (int)$queueNum : null,
            'blocked'          => ContentFilterPostureFormatter::named((array)($status['blocked_categories'] ?? []), $labels),
            'counter_groups'   => $counterGroups,
            // For the folded summary, so the template does not count.
            'counters_count'   => ContentFilterPostureFormatter::counterCount($counterGroups),
        ];
    }

    /**
     * A load error as escaped text, or '' when there is none: the template asks
     * whether there is an error, it does not render the raw message.
     */
    private static function message($msg): string
    {
        return is_string($msg) && $msg !== '' ? Filter::escHtml($msg) : '';
    }

    /**
     * One configured target and what it became.
     *
     * The resolved address is shown **next to** the configured value, never
     * instead of it: "I set a name and it did not resolve" and "I set nothing"
     * are different answers, and only the operator can tell which they meant.
     *
     * `resolved_html` is complete inner markup, not a value: the em dash that
     * stands for "nothing resolved" is a decision about the screen, not data.
     *
     * @return array<string,string>
     */
    private static function target(string $family, string $inputId, string $inputLabel, string $configured, string $resolved): array
    {
        $out = [
            'family_html'       => Filter::escHtml($family),
            'input_id_attr'     => Filter::escHtml($inputId),
            'input_label_attr'  => Filter::escHtml($inputLabel),
            'value_attr'        => Filter::escHtml($configured),
            'placeholder_attr'  => Filter::escHtml('(none - answer NXDOMAIN)'),
            'state_class'       => 'std-badge--info',
        ];

        if ($configured === '') {
            $out['resolved_html'] = self::noValue();
            $out['state_html']    = Filter::escHtml('Not set');
            $out['detail_html']   = Filter::escHtml('Blocked names of this family are answered NXDOMAIN (the clean cut).');
            return $out;
        }

        if ($resolved === '') {
            $out['resolved_html'] = self::noValue();
            $out['state_html']    = Filter::escHtml('Did not resolve');
            $out['state_class']   = 'std-badge--danger';
            $out['detail_html']   = Filter::escHtml('Blocked names of this family are cut instead of being sent '
                . 'somewhere unconfirmed.');
            return $out;
        }

        $isLiteral = $configured === $resolved;
        $out['resolved_html'] = $isLiteral ? self::noValue() : '<code>' . Filter::escHtml($resolved) . '</code>';
        $out['state_html']    = Filter::escHtml($isLiteral ? 'Literal address' : 'Name resolved when armed');
        $out['state_class']   = 'std-badge--success';
        // The "the name may change under you" caveat is not repeated here: it is
        // in the folded note, once, for both families.
        $out['detail_html']   = Filter::escHtml($isLiteral
            ? 'A blocked name of this family is rewritten to this address.'
            : 'A blocked name of this family is rewritten to the address above.');
        return $out;
    }

    /** The mark that stands for "nothing here", as the operator sees it. */
    private static function noValue(): string
    {
        return '<span class="text-muted">&mdash;</span>';
    }

    /**
     * @param array<string,string> $options
     * @return array<int,array<string,string>>
     */
    private static function options(array $options, string $current): array
    {
        $out = [];
        foreach ($options as $value => $label) {
            $out[] = [
                'value_attr' => Filter::escHtml($value),
                'label_html' => Filter::escHtml($label),
                'selected'   => $value === $current ? 'selected' : '',
            ];
        }
        return $out;
    }

    /**
     * @param array<int,string> $chains
     * @return array<int,array<string,string>>
     */
    private static function chainRows(array $chains): array
    {
        $out = [];
        foreach (self::CHAINS as $value => $label) {
            $out[] = [
                'value_attr' => Filter::escHtml($value),
                'label_html' => Filter::escHtml($label),
                'checked'    => in_array($value, $chains, true) ? 'checked' : '',
            ];
        }
        return $out;
    }
}
