<?php
/**
 * eBPF Module Management
 *
 * Uses ebpf.<command> protocol via EbpfRequestController.
 * Formatter pre-computes all HTML for the template.
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Controllers\Request\EbpfRequestController;
use App\Pages\Fmt\EbpfFormatter;
use App\Services\AuthService;
use App\Services\Filter;
use App\Helpers\RoleHelper;

class PageEbpf
{
    /**
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $section = 'ebpf';

        // Permission check
        $auth = $ctx->get(AuthService::class);
        $userCaps = $auth instanceof AuthService ? $auth->getCapabilities() : [];
        $canWrite = RoleHelper::hasCapability($userCaps, 'ebpf:write');

        // Fetch module list from backend
        $ebpfCtrl = new EbpfRequestController($ctx);
        $listResp = $ebpfCtrl->getModuleList();

        // getModuleList returns 'success' or 'error' (fallback) - never 'partial'.
        if ($listResp['status'] === 'success') {
            $fmt = EbpfFormatter::formatModuleList($listResp['result']);
        } else {
            $errorMsg = (string)($listResp['response_msg'] ?? '');
            if ($errorMsg === '') $errorMsg = 'eBPF service unavailable';

            $fmt = [
                'api_ok'            => false,
                'error_html'        => Filter::escHtml($errorMsg),
                'instances_rows'    => [],
                'available_rows'    => [],
                'internal_rows'     => [],
                'internal_count'    => 0,
                'has_internal'      => false,
                'foreign_rows'      => [],
                'foreign_count'     => 0,
                'has_foreign'       => false,
                'has_new_foreign'   => false,
                'stale_rows'        => [],
                'stale_count'       => 0,
                'has_stale'         => false,
                'unmanaged_rows'    => [],
                'unmanaged_count'   => 0,
                'has_unmanaged'     => false,
                'conflict_rows'     => [],
                'conflict_count'    => 0,
                'has_conflicts'     => false,
                'coexisting_rows'   => [],
                'coexisting_count'  => 0,
                'has_coexisting'    => false,
            ];
        }

        $fmt['can_write'] = $canWrite;

        // JS scripts
        $page['web_main']['footer_script'][] = ['src' => '/scripts/ebpf/ebpf.js'];

        // CSS
        $page['web_main']['cssfile'][] = 'default-ebpf';

        // Build page array
        $page['page'] = $section;
        $page['page_data'] = $fmt;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        // Inject fragments
        // Each fragment receives the full formatted data as tpl_data
        if ($fmt['api_ok'] ?? false) {
            $page['load_tpl'][] = ['file' => 'ebpf-list',   'place' => 'ebpf_list',   'tpl_data' => $fmt];
            $page['load_tpl'][] = ['file' => 'ebpf-kernel', 'place' => 'ebpf_kernel', 'tpl_data' => $fmt];
        }
        $page['load_tpl'][] = ['file' => 'ebpf-detail', 'place' => 'ebpf_detail'];

        return $page;
    }
}
