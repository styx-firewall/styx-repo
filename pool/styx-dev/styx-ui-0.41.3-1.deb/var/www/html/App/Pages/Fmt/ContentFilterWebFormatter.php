<?php
/**
 * ContentFilterWebFormatter - presentation helpers for the web filter pane.
 *
 * There is **no policy editor here**: what is blocked is decided once, in the
 * catalogue. This pane holds what only this mechanism decides - how a blocked
 * flow is cut, and which categories derive a DSCP - plus what it is doing right
 * now, which is rendered first because a filter that is off explains the rest of
 * the pane better than the pane explains it.
 *
 * The DSCP policy is one compact labelled field per category, laid out in as
 * many columns as fit: a long taxonomy stops being a page of scrolling, and a
 * value of a few characters keeps a field of a few characters.
 *
 * Input (from PageContentFilter):
 *   - settings     {block_mode, dscp}  (transport msg already stripped)
 *   - status       {blocked_categories, qos_categories, ...counters}
 *   - categories   the taxonomy
 *   - groups       group order and names
 *   - error        string|null  load error of the settings
 *   - status_error string|null  load error of the status
 *
 * Templates are echo-only: every derived text, badge class, attribute and
 * selected token is computed here.
 *
 * @see App\Pages\PageContentFilter
 * @see api/handlers/web_filter.md
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class ContentFilterWebFormatter
{
    /**
     * How a blocked flow is stopped, as the operator chooses it.
     *
     * The distinction is the one the design documents: `drop` is silent and the
     * client waits for its own timeout; `reject` sends a TCP reset and the client
     * finds out at once. Neither is "the safe one" - it is what the network wants.
     */
    private const BLOCK_MODES = [
        'reject' => 'Reject (TCP reset - the client is told at once)',
        'drop'   => 'Drop (silent - the client waits for its own timeout)',
    ];

    private const UNGROUPED_LABEL = 'Ungrouped';

    /**
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    public static function format(array $data, bool $canEdit, bool $featureOn): array
    {
        $settings   = is_array($data['settings'] ?? null) ? $data['settings'] : [];
        $status     = is_array($data['status'] ?? null) ? $data['status'] : [];
        $categories = is_array($data['categories'] ?? null) ? $data['categories'] : [];
        $groups     = is_array($data['groups'] ?? null) ? $data['groups'] : [];

        $dscp      = is_array($settings['dscp'] ?? null) ? $settings['dscp'] : [];
        $labels    = ContentFilterPostureFormatter::labels($categories);
        $blockMode = (string)($settings['block_mode'] ?? 'reject');

        $modes = [];
        foreach (self::BLOCK_MODES as $value => $label) {
            $modes[] = [
                'value_attr' => Filter::escHtml($value),
                'label_html' => Filter::escHtml($label),
                'selected'   => $value === $blockMode ? 'selected' : '',
            ];
        }

        $rows   = self::policyRows($categories, $groups, $dscp, $canEdit);
        $marked = 0;
        foreach ($rows as $i => $row) {
            // Each field needs its own id so its category name can label it with
            // `for`: the pair reads as one control, not as a cell and a hint.
            $rows[$i]['input_id_attr'] = Filter::escHtml('cf-dscp-' . $i);
            if ($row['value_attr'] !== '') {
                $marked++;
            }
        }

        $counterGroups = ContentFilterPostureFormatter::counterGroups($status);

        // `feature_on` is what the operator switched on; `running` is the filter's own
        // answer about its pieces, and the two can disagree -- a filter that is enabled but
        // whose pieces could not be armed inspects nothing while the pane says "Running".
        // A server that does not report `running` yet makes no claim, so it warns about
        // nothing either.
        $enabledNotRunning = array_key_exists('running', $status) && empty($status['running']);

        return [
            // Escaped here: the template echoes what it is given, it never
            // escapes and never casts.
            'error_html'        => self::message($data['error'] ?? null),
            'status_error_html' => self::message($data['status_error'] ?? null),
            'feature_on'     => $featureOn,
            // Enabled but not up: the badge and the warning need the same answer.
            'enabled_not_running' => $enabledNotRunning,
            'can_edit'       => $canEdit,
            'disabled_attr'  => $canEdit ? '' : 'disabled',
            'block_mode'     => Filter::escHtml($blockMode),
            'block_modes'    => $modes,
            'block_mode_aria_attr' => Filter::escHtml('How a blocked flow is stopped'),
            // Flat, not cut into rows: how many fit per line is a question about
            // the screen, and only the stylesheet can answer it.
            'policy_rows'    => $rows,
            'has_policy'     => !empty($rows),
            'marked_count'   => $marked,
            // What the filter is DOING, next to what the form says it should do.
            // Two lists, so a policy that is not being applied is visible instead
            // of implied.
            'blocked'        => ContentFilterPostureFormatter::named((array)($status['blocked_categories'] ?? []), $labels),
            'qos'            => ContentFilterPostureFormatter::named((array)($status['qos_categories'] ?? []), $labels),
            'counter_groups' => $counterGroups,
            // For the folded summary, so the template does not count.
            'counters_count' => ContentFilterPostureFormatter::counterCount($counterGroups),
        ];
    }

    /**
     * A load error as escaped text, or '' when there is none: the template asks
     * whether there is an error, it does not render the raw message.
     */
    private static function message($msg): string
    {
        return is_string($msg) && $msg !== '' ? Filter::escHtml($msg) : '';
    }

    /**
     * The taxonomy in group order, flattened to one row per category.
     *
     * A category whose group the catalogue does not list is kept: it would
     * otherwise be the one category the operator cannot mark, with nothing on
     * screen saying why.
     *
     * @param array<int,array<string,mixed>> $categories
     * @param array<int,array<string,mixed>> $groups
     * @param array<string,mixed>            $dscp
     * @return array<int,array<string,string>>
     */
    private static function policyRows(array $categories, array $groups, array $dscp, bool $canEdit): array
    {
        $rows   = [];
        $placed = [];
        foreach ($groups as $group) {
            if (!is_array($group)) {
                continue;
            }
            $groupId = (string)($group['id'] ?? '');
            foreach ($categories as $category) {
                if (!is_array($category) || (string)($category['group'] ?? '') !== $groupId) {
                    continue;
                }
                $id = (string)($category['id'] ?? '');
                if ($id === '') {
                    continue;
                }
                $rows[]     = self::policyRow($category, (string)($group['label'] ?? $groupId), $dscp, $canEdit);
                $placed[$id] = true;
            }
        }

        // Groups the catalogue does not list (or no group list at all).
        $unlisted = [];
        foreach ($categories as $category) {
            if (!is_array($category)) {
                continue;
            }
            $id = (string)($category['id'] ?? '');
            if ($id === '' || isset($placed[$id])) {
                continue;
            }
            $groupId = (string)($category['group'] ?? '');
            $unlisted[$groupId][] = self::policyRow(
                $category,
                $groupId === '' ? self::UNGROUPED_LABEL : $groupId,
                $dscp,
                $canEdit
            );
        }
        foreach ($unlisted as $groupRows) {
            foreach ($groupRows as $row) {
                $rows[] = $row;
            }
        }

        return $rows;
    }

    /**
     * @param array<string,mixed> $category
     * @param array<string,mixed> $dscp
     * @return array<string,string>
     */
    private static function policyRow(array $category, string $groupLabel, array $dscp, bool $canEdit): array
    {
        $id    = (string)($category['id'] ?? '');
        $label = (string)($category['label'] ?? $id);
        $value = $dscp[$id] ?? '';

        return [
            'id_attr'       => Filter::escHtml($id),
            'label_html'    => Filter::escHtml($label),
            'group_attr'    => Filter::escHtml($groupLabel),
            'value_attr'    => Filter::escHtml(is_scalar($value) ? (string)$value : ''),
            'disabled_attr' => $canEdit ? '' : 'disabled',
        ];
    }
}
