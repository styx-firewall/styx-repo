<?php
/**
 * Event codes emitted by the gateway.
 *
 * MIRROR of /opt/styx-gateway/constants/event_types.py. The events are produced
 * by the backend, so that file is the source of truth: register or renumber an
 * event there first, then mirror it here. Name and number must match exactly.
 *
 * Nothing in this repo consumes these constants: the events UI renders the
 * event_name / level_name the backend sends in the payload, so this file is a
 * reference, not an interpretation layer. Keep it in sync rather than growing
 * it with codes the gateway does not have, and check it against the .py before
 * relying on it.
 */

namespace App\Constants;

class EventType
{
    // 1-100: Sistema
    const EVENT_SYSTEM_BOOT = 1;
    const EVENT_SYSTEM_SHUTDOWN = 2;
    const EVENT_SHUTDOWN = 3; // In Use
    const EVENT_RESTART = 4; // In Use
    const EVENT_SYSTEM_UPDATE = 5;
    const EVENT_SYSTEM_ERROR = 6;
    const EVENT_POWER_FAILURE = 7;
    const EVENT_POWER_RESTORED = 8;
    const EVENT_TEMP_THRESHOLD_EXCEEDED = 9;
    const EVENT_FAN_FAILURE = 10;
    const EVENT_HARDWARE_FAILURE = 11;
    const EVENT_STORAGE_FULL = 12;
    const EVENT_TIME_SYNC = 13;
    const EVENT_CONFIG_IMPORT = 14;
    const EVENT_CONFIG_EXPORT = 15;
    const EVENT_BACKUP_CREATED = 16;
    const EVENT_BACKUP_RESTORED = 17;
    const EVENT_FIRMWARE_UPGRADE_STARTED = 18;
    const EVENT_FIRMWARE_UPGRADE_COMPLETED = 19;
    const EVENT_FIRMWARE_UPGRADE_FAILED = 20;
    const EVENT_STORAGE_WARNING = 21;
    const EVENT_STORAGE_CRITICAL = 22;
    const EVENT_STORAGE_RECOVERED = 23;
    // ...reserva hasta 100...

    // 101-200: Usuarios
    const EVENT_USER_CREATED = 101;
    const EVENT_USER_DELETED = 102;
    const EVENT_USER_MODIFIED = 103;
    const EVENT_USER_LOGIN_BLOCKED = 104;
    const EVENT_USER_PASSWORD_CHANGED = 105;
    const EVENT_USER_GROUP_CHANGED = 106;
    const EVENT_USER_ROLE_CHANGED = 107;
    const EVENT_USER_SESSION_EXPIRED = 108;
    const EVENT_USER_PROFILE_UPDATED = 109;
    const EVENT_USER_2FA_ENABLED = 110;
    const EVENT_ADMIN_PRIVILEGE_GRANTED = 111;
    const EVENT_ADMIN_PRIVILEGE_REVOKED = 112;
    const EVENT_API_KEY_CREATED = 113;
    const EVENT_API_KEY_REVOKED = 114;
    const EVENT_API_KEY_REVOKED_DETECTED = 115;
    const EVENT_API_KEY_USED = 116;
    const EVENT_LOGIN_SUCCESS = 117;
    const EVENT_LOGIN_FAILURE = 118;
    const EVENT_LOGOUT = 119;
    const EVENT_USER_NOT_FOUND = 120;
    const EVENT_USER_CREATE_ERROR = 121;
    // ...reserva hasta 200...

    // 201-300: IDS/IPS
    const EVENT_IDS_ALERT = 201;
    const EVENT_IDS_BLOCKED_IP = 202;
    const EVENT_IDS_SIGNATURE_UPDATE = 203;
    const EVENT_IDS_BYPASS_ACTIVATED = 204;
    const EVENT_IDS_BYPASS_DEACTIVATED = 205;
    const EVENT_IDS_SCAN_DETECTED = 206;
    const EVENT_IDS_ANOMALY_DETECTED = 207;
    const EVENT_IDS_POLICY_CHANGED = 208;
    const EVENT_IDS_ENGINE_RESTARTED = 209;
    const EVENT_IDS_ENGINE_ERROR = 210;
    // ...reserva hasta 300...

    // 301-400: Descubrimiento de red
    const EVENT_DEVICE_DISCOVERED = 301;
    const EVENT_DEVICE_LOST = 302;
    const EVENT_DEVICE_NAME_CHANGED = 303;
    const EVENT_DEVICE_IP_CHANGED = 304;
    const EVENT_DEVICE_TYPE_CHANGED = 305;
    const EVENT_DEVICE_VENDOR_CHANGED = 306;
    const EVENT_DEVICE_OS_CHANGED = 307;
    const EVENT_DEVICE_PORTS_CHANGED = 308;
    const EVENT_DEVICE_MAC_CHANGED = 309;
    const EVENT_DEVICE_STATUS_CHANGED = 310;
    const EVENT_DISCOVERY_SEED_COMPLETE = 311;
    const EVENT_DISCOVERY_BATCH = 312;
    // ...reserva hasta 400...

    // 401-500: Servicios (VPN, DHCP, otros)
    const EVENT_VPN_CONNECTED = 401;
    const EVENT_VPN_DISCONNECTED = 402;
    const EVENT_VPN_CONFIG_CHANGED = 403;
    const EVENT_VPN_AUTH_FAILURE = 404;
    const EVENT_VPN_TUNNEL_DOWN = 405;
    const EVENT_VPN_TUNNEL_REESTABLISHED = 406;
    const EVENT_VPN_CLIENT_CONNECT = 407;
    const EVENT_VPN_CLIENT_DISCONNECT = 408;
    const EVENT_VPN_CLIENT_NEGOTIATION_FAILED = 409;
    const EVENT_DHCP_LEASE_GRANTED = 410;
    const EVENT_DHCP_LEASE_EXPIRED = 411;
    const EVENT_DHCP_CONFIG_CHANGED = 412;
    const EVENT_DHCP_SERVER_CHANGED = 412; // Renamed: consolidated DHCP datastore structure
    const EVENT_DHCP_POOL_EXHAUSTED = 413;
    const EVENT_DHCP_CONFLICT = 414;
    const EVENT_SERVICE_STARTED = 415;
    const EVENT_SERVICE_STOPPED = 416;
    const EVENT_SERVICE_RESTARTED = 417;
    // ...reserva hasta 500...

    // 501-600: Routing
    const EVENT_ROUTE_ADDED = 501;
    const EVENT_ROUTE_REMOVED = 502;
    const EVENT_ROUTE_CHANGED = 503;
    const EVENT_ROUTING_TABLE_FLUSHED = 504;
    const EVENT_ROUTING_PROTOCOL_CHANGED = 505;
    // ...reserva hasta 600...

    // 601-700: Network/Interfaces
    const EVENT_INTERFACE_UP = 601;
    const EVENT_INTERFACE_DOWN = 602;
    const EVENT_INTERFACE_CONFIG_CHANGE = 603;
    const EVENT_INTERFACE_MAC_CHANGED = 604;
    const EVENT_INTERFACE_SPEED_CHANGED = 605;
    const EVENT_INTERFACE_DUPLEX_CHANGED = 606;
    const EVENT_INTERFACE_MTU_CHANGED = 607;
    const EVENT_INTERFACE_ERROR = 608;
    const EVENT_INTERFACE_ALIAS_ADDED = 609;
    const EVENT_INTERFACE_ALIAS_REMOVED = 610;
    const EVENT_BANDWIDTH_LIMIT_EXCEEDED = 611;
    const EVENT_QOS_POLICY_APPLIED = 612;
    const EVENT_QOS_POLICY_REMOVED = 613;
    const EVENT_GUEST_NETWORK_ENABLED = 614;
    const EVENT_GUEST_NETWORK_DISABLED = 615;
    const EVENT_PARENTAL_CONTROL_ENABLED = 616;
    const EVENT_PARENTAL_CONTROL_DISABLED = 617;
    const EVENT_DNS_FAILURE = 618;
    const EVENT_ARP_CONFLICT = 619;
    // ...reserva hasta 700...

    // 701-800: Firewall/NAT
    const EVENT_FIREWALL_ALERT = 701;
    const EVENT_FIREWALL_RULE_ADDED = 702; // In Use
    const EVENT_FIREWALL_RULE_REMOVED = 703; // In Use
    const EVENT_FIREWALL_RULE_MODIFIED = 704; // In Use
    const EVENT_NAT_RULE_ADDED = 705; // In Use
    const EVENT_NAT_RULE_REMOVED = 706; // In Use
    const EVENT_NAT_RULE_MODIFIED = 707;
    const EVENT_PORT_SCAN_DETECTED = 708;
    const EVENT_DOS_ATTACK_DETECTED = 709;
    const EVENT_FIREWALL_POLICY_CHANGED = 710;
    const EVENT_FIREWALL_LOG_ROTATED = 711;
    const EVENT_FIREWALL_LOG_CLEARED = 712;
    const EVENT_FIREWALL_CHAIN_CREATED = 713;
    const EVENT_FIREWALL_CHAIN_DELETED = 714;
    const EVENT_FIREWALL_CHAIN_MODIFIED = 715;
    const EVENT_FIREWALL_ZONE_CHANGED = 716;
    const EVENT_FIREWALL_ZONE_ADDED = 717;
    const EVENT_FIREWALL_ZONE_REMOVED = 718;
    const EVENT_FIREWALL_DEFAULT_POLICY_CHANGED = 719;
    const EVENT_FIREWALL_RELOAD = 720; // In Use
    const EVENT_FIREWALL_RESTORE = 721;
    const EVENT_FIREWALL_BACKUP_CREATED = 722;
    const EVENT_FIREWALL_BACKUP_RESTORED = 723;
    const EVENT_FIREWALL_ERROR = 724; // In Use
    const EVENT_NAT_ERROR = 725; // In Use
    const EVENT_CERTIFICATE_EXPIRED = 726;
    const EVENT_CERTIFICATE_RENEWED = 727;
    const EVENT_FIREWALL_RULES_FLUSHED = 728; // In Use
    // ...reserva hasta 800...

    // 801-900: Task Manager
    const EVENT_TASK_CREATED = 801;
    const EVENT_TASK_STARTED = 802;
    const EVENT_TASK_COMPLETED = 803;
    const EVENT_TASK_FAILED = 804;
    const EVENT_TASK_CANCELLED = 805;
    const EVENT_TASK_TIMEOUT = 806;
    const EVENT_TASK_PROGRESS = 807;
    // ...reserva hasta 900...

    # 900-100: SLA/Ping Monitor Events
    const EVENT_SLA_PING_FAILURE = 900; // In Use
    const EVENT_SLA_PING_RECOVERED = 901; // In Use
    const EVENT_SLA_LATENCY_EXCEEDED = 902; // In Use
    const EVENT_SLA_LATENCY_RESTORED = 903; // In Use
    const EVENT_SLA_JITTER_EXCEEDED = 904; // In Use
    const EVENT_SLA_JITTER_RESTORED = 905; // In Use

    // 1001-1100: Netlink Events
    const EVENT_NETLINK_ADDR_ADDED = 1001;
    const EVENT_NETLINK_ADDR_REMOVED = 1002;
    const EVENT_NETLINK_EVENTS_LOST = 1003; // kernel dropped notifications: state may have diverged

    // 1101-1200: Features
    const EVENT_FEATURE_ENABLED = 1101;
    const EVENT_FEATURE_DISABLED = 1102;
    const EVENT_FEATURE_FAILED = 1103;

    // 1201-1210: Watchdog / Monitoring
    const EVENT_WATCHDOG_ANOMALY = 1201;
    const EVENT_WATCHDOG_ERROR = 1203;

    // 1301-1310: eBPF / Kernel Programs
    const EVENT_EBPF_FOREIGN_PROGRAM_DETECTED = 1301; // In Use
    const EVENT_EBPF_PROGRAM_ATTACHED = 1302;
    const EVENT_EBPF_PROGRAM_DETACHED = 1303;
    const EVENT_EBPF_STALE_COMPONENT = 1304;
    const EVENT_EBPF_UNMANAGED_PROGRAM = 1305;

    // 1401-1410: Boot / Startup
    const EVENT_BOOT_ERRORS_DETECTED = 1401; // one per boot when ERROR logs were seen

}
