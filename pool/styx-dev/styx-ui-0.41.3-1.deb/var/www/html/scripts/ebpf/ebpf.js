/**
 * eBPF Module Management-Interactive Logic
 *
 * Module list table is rendered by PHP. JS handles:
 * - Row clicks > detail panel with API-driven content
 * - Search/filter, modals, control map CRUD, telemetry polling, events
 */
(function () {
    'use strict';

    //
    // DOM
    //
    var searchInput       = document.getElementById('ebpf-search');
    var refreshBtn        = document.getElementById('ebpf-refresh-btn');
    var backBtn           = document.getElementById('ebpf-back-btn');
    var detailPanel       = document.getElementById('ebpf-detail-panel');
    var listView          = document.getElementById('ebpf-list-view');
    var moduleList        = document.getElementById('ebpf-module-list');
    var kernelSections    = document.querySelectorAll('.ebpf-collapsible-section');
    var detailHeader      = document.getElementById('ebpf-detail-header');
    var detailActions     = document.getElementById('ebpf-detail-actions');
    var overviewContent   = document.getElementById('ebpf-overview-content');
    var controlMapsContent = document.getElementById('ebpf-control-maps-content');
    var telemetryContent  = document.getElementById('ebpf-telemetry-content');
    var eventsTbody       = document.querySelector('#ebpf-events-table tbody');
    var eventsPauseBtn    = document.getElementById('ebpf-events-pause-btn');
    var eventsClearBtn    = document.getElementById('ebpf-events-clear-btn');
    var eventsAutoScroll  = document.getElementById('ebpf-events-autoscroll');

    //
    // STATE
    //
    var activeInstanceId = null;
    var activeModule     = null;
    var activeDetail     = null;
    var activeMeta       = null;
    var telemetryData    = {};
    var telemetryMapsMeta = {}; // from telemetry-get: mapName > {type, poll_interval_ms, semantics}
    var controlMapEntries = {};
    var telemetryInterval = null;
    var eventPollInterval = null;
    var eventsPaused = false;
    var autoScroll = true;
    var seenEvents = {};  // dedup: "ts-event-srcip" > true
    var lastTelemetryValues = {}; // field > last value for change detection

    //
    // UTILITY
    //

    function el(tag, attrs, children) {
        var e = document.createElement(tag);
        if (attrs) {
            Object.keys(attrs).forEach(function (k) {
                if (k === 'className') e.className = attrs[k];
                else if (k === 'dataset') { for (var d in attrs[k]) e.dataset[d] = attrs[k][d]; }
                else if (k.substr(0, 2) === 'on') e.addEventListener(k.substr(2).toLowerCase(), attrs[k]);
                else e.setAttribute(k, attrs[k]);
            });
        }
        (children || []).forEach(function (c) {
            if (c == null) return;
            e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
        });
        return e;
    }

    /**
     * Clone a <template> block and fill its .js-* placeholders with plain text.
     * The markup is parsed once by the browser at page load and the values go in
     * as text nodes, so data never reaches an HTML parser. Returns null when the
     * template is not in the page (caller should not open an empty modal).
     */
    function fillTemplate(tplId, values) {
        var tpl = document.getElementById(tplId);
        if (!tpl) return null;
        var frag = tpl.content.cloneNode(true);
        Object.keys(values || {}).forEach(function (sel) {
            var node = frag.querySelector(sel);
            if (node) node.textContent = values[sel] == null ? '' : values[sel];
        });
        return frag;
    }

    function showToast(msg, type) {
        var t = el('div', { id: 'ebpf-toast', className: 'ebpf-toast ebpf-toast--' + (type || 'success') }, [msg]);
        var pc = document.querySelector('.page-content');
        if (pc) pc.appendChild(t);
        setTimeout(function () { t.classList.add('ebpf-toast--fade'); }, 3000);
        setTimeout(function () { if (t.parentNode) t.remove(); }, 3500);
    }

    function formatUnit(value, unit) {
        if (value === null || value === undefined) return '-';
        switch (unit) {
        case 'count': return Number(value).toLocaleString();
        case 'bytes':
            var n = Number(value);
            if (n >= 1e9) return (n / 1e9).toFixed(1) + ' GB';
            if (n >= 1e6) return (n / 1e6).toFixed(1) + ' MB';
            if (n >= 1e3) return (n / 1e3).toFixed(1) + ' KB';
            return n + ' B';
        case 'ns':
            var ns = Number(value), msAgo = Date.now() - (ns / 1e6);
            if (msAgo < 1000) return 'just now';
            if (msAgo < 60000) return Math.round(msAgo / 1000) + 's ago';
            if (msAgo < 3600000) return Math.round(msAgo / 60000) + 'm ago';
            return Math.round(msAgo / 3600000) + 'h ago';
        case 'epoch':
            var sAgo = (Date.now() / 1000) - Number(value);
            if (sAgo <= 0) return 'just now';
            if (sAgo < 60) return Math.round(sAgo) + 's ago';
            if (sAgo < 3600) return Math.round(sAgo / 60) + 'm ago';
            if (sAgo < 86400) return Math.round(sAgo / 3600) + 'h ago';
            return Math.round(sAgo / 86400) + 'd ago';
        case 'ipv4': return String(value);
        default: return String(value);
        }
    }

    function formatMapEntry(entry) {
        if (typeof entry === 'string') return entry;
        if (!entry || typeof entry !== 'object') return String(entry);
        var key = formatKey(entry);
        var val = entry.value !== undefined ? entry.value : null;
        if (typeof val === 'object' && val !== null) {
            val = Object.entries(val).map(function (e) { return e[0] + ': ' + e[1]; }).join(', ');
        }
        return val !== null && val !== key ? String(key) + ' > ' + String(val) : String(key);
    }

    function formatKey(entry) {
        var key = (entry && typeof entry === 'object') ? (entry.key !== undefined ? entry.key : entry.value) : entry;
        if (typeof key === 'object' && key !== null) {
            var kk = Object.keys(key);
            key = kk.length === 1 ? key[kk[0]] : JSON.stringify(key);
        }
        return String(key !== undefined && key !== null ? key : '');
    }

    function formatValue(val) {
        if (typeof val === 'object' && val !== null) {
            return Object.entries(val).map(function (e) { return e[0] + ': ' + e[1]; }).join(', ');
        }
        return String(val !== undefined ? val : '');
    }

    /** Status pill as a node, so an unknown status is shown as text, not markup. */
    function statusBadge(status) {
        var map = { loaded: 'ebpf-status-loaded', suspended: 'ebpf-status-suspended', inactive: 'ebpf-status-inactive',
            available: 'ebpf-status-available', incompatible: 'ebpf-status-incompatible', error: 'ebpf-status-error' };
        var labels = { loaded: '● Loaded', suspended: '◐ Suspended', inactive: '○ Inactive',
            available: '○ Available', incompatible: '✗ Incompatible', error: '⚠ Error' };
        return el('span', { className: 'ebpf-status-badge ' + (map[status] || '') }, [labels[status] || status]);
    }

    var SEV_BADGE = { debug: 'ebpf-sev-debug', info: 'ebpf-sev-info', warn: 'ebpf-sev-warn', crit: 'ebpf-sev-crit' };

    /** Severity pill as a node: the event row and the event modal share it. */
    function severityBadge(sev) {
        return el('span', { className: 'ebpf-severity-badge ' + (SEV_BADGE[sev] || 'ebpf-sev-info') },
            [(sev || '').toUpperCase()]);
    }

    //
    // MODULE LIST: SEARCH / FILTER
    //

    function filterRows(term) {
        var t = (term || '').toLowerCase();
        document.querySelectorAll('#ebpf-module-list tbody tr.ebpf-module-row').forEach(function (tr) {
            var txt = (tr.textContent || '').toLowerCase();
            tr.style.display = (t && !txt.includes(t)) ? 'none' : '';
        });
    }

    //
    // ROW CLICKS > DELEGATED
    //

    // The table only renders when the API answered (ebpf-list fragment), so the
    // lookups are guarded: an unguarded one would abort the IIFE and take every
    // handler registered below it with it.
    if (moduleList) moduleList.addEventListener('click', function (e) {
        // Activate/Reactivate button (inactive/suspended instances)
        var actBtn = e.target.closest('.ebpf-activate-btn-js');
        if (actBtn) {
            e.stopPropagation();
            var uuid = actBtn.dataset.uuid;
            if (uuid) {
                apiClient.submit('ebpf_activate_module', { module: uuid }).then(function (r) {
                    if (r.status === 'success') { showToast(r.response_msg || 'Activated', 'success'); refreshList(); }
                    else showToast(r.response_msg || 'Activation failed', 'error');
                }).catch(function (err) { showToast('Network error: ' + err.message, 'error'); });
            }
            return;
        }
        // Info button
        var infoBtn = e.target.closest('.ebpf-info-btn');
        if (infoBtn) {
            e.stopPropagation();
            selectModule(infoBtn.dataset.identifier, infoBtn.dataset.isInstance === '1');
            return;
        }
        // Load button (available modules)
        var loadBtn = e.target.closest('.ebpf-load-btn-js');
        if (loadBtn) {
            e.stopPropagation();
            var tr = loadBtn.closest('tr');
            if (tr) openLoadModal(tr);
            return;
        }
        // Autoload toggle-let the change event handle it, don't select the row
        if (e.target.closest('.ebpf-autoload-toggle')) {
            return;
        }
        // Row click > select
        var row = e.target.closest('tr.ebpf-module-row');
        if (row) {
            selectModule(row.dataset.instanceId || row.dataset.module, !!row.dataset.instanceId);
        }
    });

    // Autoload toggle-delegated
    if (moduleList) moduleList.addEventListener('change', function (e) {
        if (e.target.classList.contains('ebpf-autoload-toggle')) {
            toggleAutoload(e.target.dataset.uuid, e.target.checked);
        }
    });

    // Collapsible sections
    document.querySelectorAll('.ebpf-collapse-toggle').forEach(function (t) {
        t.addEventListener('click', function () {
            var body = document.getElementById(this.dataset.target);
            if (body) {
                body.classList.toggle('hidden');
                var a = this.querySelector('.ebpf-collapse-arrow');
                if (a) a.textContent = body.classList.contains('hidden') ? '▼' : '▲';
            }
        });
    });

    //
    // SELECT MODULE > DETAIL PANEL
    //

    /** Read module metadata from a table row's dataset */
    function metaFromRow(tr) {
        if (!tr) return null;
        var ds = tr.dataset;
        var params = [];
        try { params = JSON.parse(ds.preAttachParams || '[]'); } catch (e) { /* keep [] */ }
        return {
            name: ds.module || '',
            instance_id: ds.instanceId || null,
            status: ds.status || '',
            attach_target: ds.attachTarget || 'interface',
            version: ds.version || '',
            hook_type: ds.hookType || '',
            interface: ds.interface || '',
            mode: ds.mode || '',
            pre_attach_params: params,
        };
    }

    function selectModule(identifier, isInstance) {
        stopAllPolling(); // kill any polling from previous module immediately
        // Read metadata from the specific row that was clicked (no DOM search)
        var sel = isInstance
            ? 'tr.ebpf-module-row[data-instance-id="' + identifier + '"]'
            : 'tr.ebpf-module-row[data-instance-id=""][data-module="' + identifier + '"]';
        var tr = document.querySelector(sel);
        if (!tr) return;

        var meta = metaFromRow(tr);
        if (!meta) return;
        var isInst = !!tr.dataset.instanceId;
        activeInstanceId = isInst ? meta.instance_id : null;
        activeModule = meta.name;
        activeMeta = meta;
        activeDetail = null;
        telemetryData = {};
        telemetryMapsMeta = {};
        controlMapEntries = {};
        seenEvents = {};

        var lookupId = activeInstanceId || activeModule;

        apiClient.request('ebpf_get_module_info', { module: lookupId }).then(function (resp) {
            if (resp.status === 'success' || resp.status === 'partial') {
                activeDetail = resp.result || resp;
                // Seed control map entries from module-info pre-populated data
                (activeDetail.control_maps || []).forEach(function (cm) {
                    if (cm.entries && cm.entries.length) {
                        controlMapEntries[cm.name] = cm.entries;
                    }
                });
                listView.classList.add('hidden');
                kernelSections.forEach(function (s) { s.classList.add('hidden'); });
                detailPanel.classList.remove('hidden');
                stopAllPolling();
                renderDetailHeader();
                renderOverview();
                renderControlMaps();
                renderTelemetry();
                renderEvents();
                switchTab('ebpf-tab-overview');
            } else {
                stopAllPolling();
                showToast(resp.response_msg || 'Failed to load module info', 'error');
            }
        }).catch(function (err) {
            stopAllPolling();
            showToast('Network error: ' + err.message, 'error');
        });
    }

    function backToList() {
        stopAllPolling();
        activeInstanceId = null; activeModule = null; activeDetail = null; activeMeta = null;
        detailPanel.classList.add('hidden');
        listView.classList.remove('hidden');
        kernelSections.forEach(function (s) { s.classList.remove('hidden'); });
    }

    function renderDetailHeader() {
        var m = activeMeta, d = activeDetail || {};
        detailHeader.innerHTML = '';
        var h2 = el('h2', { className: 'ebpf-detail-title' }, [
            (d.name || m.name) + ' ',
            el('span', { className: 'ebpf-version-tag' }, ['v' + (d.version || m.version || '')]),
            ' ',
            statusBadge(m.status)
        ]);
        if (activeInstanceId) {
            h2.appendChild(document.createTextNode(' '));
            h2.appendChild(el('span', {
                className: 'ebpf-uuid ebpf-uuid--large',
                title: activeInstanceId
            }, ['UUID: ' + activeInstanceId.slice(0, 8) + '...' + activeInstanceId.slice(-4)]));
        }
        detailHeader.appendChild(h2);
        if (d.description) detailHeader.appendChild(el('p', { className: 'ebpf-detail-desc' }, [d.description]));

        detailActions.innerHTML = '';
        if (m.status === 'loaded') {
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-unload', onClick: function () { handleUnload(false); } }, ['Unload']));
            // Deactivate is reversible, so it gets the amber style rather than
            // the danger one (there is no ebpf-btn-suspend rule in the CSS).
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-warning', onClick: function () { handleUnload(true); } }, ['Deactivate']));
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-reload', onClick: handleReload }, ['Reload']));
        } else if (m.status === 'suspended') {
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-load', onClick: function () { reactivateInstance(m); } }, ['Activate']));
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-unload', onClick: function () { handleUnload(false); } }, ['Unload']));
        } else if (m.status === 'inactive') {
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-load', onClick: function () { reactivateInstance(m); } }, ['Activate']));
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-unload', onClick: function () { handleUnload(false); } }, ['Unload']));
        } else if (m.status === 'available') {
            detailActions.appendChild(el('button', { className: 'std-btn ebpf-btn-load', onClick: function () { openLoadModalFromMeta(m); } }, ['Load']));
        }
    }

    //
    // TABS
    //

    function switchTab(tabId) {
        document.querySelectorAll('#ebpf-detail-tabs .std-tab-btn').forEach(function (b) { b.classList.remove('active'); });
        document.querySelectorAll('#ebpf-detail-tab-panels .std-tab-panel').forEach(function (p) { p.classList.remove('active'); });
        var btn = document.querySelector('[data-tab="' + tabId + '"]');
        if (btn) btn.classList.add('active');
        var panel = document.getElementById('tab-' + tabId);
        if (panel) panel.classList.add('active');

        stopAllPolling();
        if (tabId === 'ebpf-tab-control-maps') fetchControlMaps();
        if (tabId === 'ebpf-tab-telemetry') { fetchTelemetry(); startTelemetryPolling(); }
        if (tabId === 'ebpf-tab-events') startEventPolling();
    }

    document.getElementById('ebpf-detail-tabs').addEventListener('click', function (e) {
        var btn = e.target.closest('.std-tab-btn');
        if (!btn || !btn.dataset.tab) return;
        e.preventDefault();
        switchTab(btn.dataset.tab);
    });

    //
    // OVERVIEW
    //

    function renderOverview() {
        var d = activeDetail || {}, m = activeMeta || {};
        overviewContent.innerHTML = '';

        var rows = [
            ['Name', d.name || m.name], ['Version', d.version || m.version || '-'],
            ['Instance UUID', activeInstanceId || '-'], ['Author', d.author || '-'],
            ['Hook Type', d.hook_type || m.hook_type || '-'], ['Interface', d.interface || m.interface || '-'],
            ['BPF Function', d.bpf_fn_name || '-'], ['Companion', d.companion || '-'],
            ['Kernel Required', d.requires_kernel ? '≥ ' + d.requires_kernel : '-'],
            ['Priority', String(d.priority !== undefined ? d.priority : '-')],
            ['Tags', (d.tags || m.tags || []).join(', ') || '-'],
            ['Mode', d.mode || m.mode || '-'], ['Status', m.status || d.status || '-'],
            ['Loaded At', m.loaded_at ? new Date(m.loaded_at * 1000).toLocaleString() : '-'],
            ['Control Maps', d.control_maps ? String(d.control_maps.length) : '0'],
            ['Telemetry Maps', d.telemetry_maps ? String(d.telemetry_maps.length) : '0'],
            ['Events', d.events ? String(d.events.length) : '0'],
        ];

        var dl = el('dl', { className: 'ebpf-details-list' });
        rows.forEach(function (p) { dl.appendChild(el('dt', null, [p[0]])); dl.appendChild(el('dd', null, [p[1]])); });
        overviewContent.appendChild(dl);

        // Usage section
        var usage = d.usage || m.usage || '';
        if (usage) {
            var sec = el('div', { className: 'ebpf-usage-section' });
            var toggle = el('div', { className: 'ebpf-usage-toggle', onClick: function () {
                var b = this.nextElementSibling, a = this.querySelector('.ebpf-usage-arrow');
                b.classList.toggle('hidden');
                if (a) a.textContent = b.classList.contains('hidden') ? '▶' : '▼';
            } });
            toggle.innerHTML = '<span class="ebpf-usage-arrow">▶</span> Usage';
            sec.appendChild(toggle);
            var body = el('div', { className: 'ebpf-usage-body hidden' });
            body.innerHTML = formatUsageHtml(usage);
            sec.appendChild(body);
            overviewContent.appendChild(sec);
        }
    }

    function formatUsageHtml(text) {
        var escaped = text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
        var lines = escaped.split('\n'), out = [], inList = false;
        lines.forEach(function (line) {
            if (/^### /.test(line)) { if (inList) { out.push('</ul>'); inList = false; } out.push('<h5>' + line.replace(/^### /, '') + '</h5>'); }
            else if (/^## /.test(line)) { if (inList) { out.push('</ul>'); inList = false; } out.push('<h4>' + line.replace(/^## /, '') + '</h4>'); }
            else if (/^- /.test(line)) { if (!inList) { out.push('<ul>'); inList = true; } out.push('<li>' + line.replace(/^- /, '') + '</li>'); }
            else if (/^\s*$/.test(line)) { if (inList) { out.push('</ul>'); inList = false; } out.push('<br>'); }
            else { if (inList) { out.push('</ul>'); inList = false; } out.push('<p>' + line.replace(/`([^`]+)`/g, '<code>$1</code>') + '</p>'); }
        });
        if (inList) out.push('</ul>');
        return out.join('\n');
    }

    //
    // CONTROL MAPS
    //

    function buildOutputTable(cm, entries) {
        var keyLabel = cm.key_label || 'Key';
        var valueLabel = cm.value_label || 'Value';
        var editor = el('div', { className: 'ebpf-control-map-editor' });

        // Info row
        editor.appendChild(el('p', { className: 'ebpf-output-hint' }, ['Output map-read-only. Data is generated by the eBPF program.']));

        var table = el('table', { className: 'ebpf-kv-table ebpf-output-table' });
        table.appendChild(el('thead', null, [el('tr', null, [
            el('th', null, [keyLabel]), el('th', null, [valueLabel])
        ])]));
        var tbody = el('tbody');
        if (entries.length) {
            entries.forEach(function (e) {
                tbody.appendChild(el('tr', null, [
                    el('td', { className: 'ebpf-mono' }, [formatKey(e)]),
                    el('td', { className: 'ebpf-mono' }, [formatValue(e.value)])
                ]));
            });
        } else {
            tbody.appendChild(el('tr', null, [el('td', { colSpan: '2', className: 'ebpf-empty-msg' }, ['No data. Click map-get to load.'])]));
        }
        table.appendChild(tbody);
        editor.appendChild(table);

        // Refresh button
        editor.appendChild(el('button', { className: 'std-btn', onClick: function () {
            if (!activeInstanceId) return;
            apiClient.request('ebpf_get_control_map', { module: activeInstanceId, map: cm.name }).then(function (r) {
                controlMapEntries[cm.name] = (r.status === 'success' || r.status === 'partial') && r.result && r.result.entries ? r.result.entries : [];
                controlMapEntries[cm.name + '_has_more'] = r.result && r.result.has_more;
                renderControlMaps();
            });
        } }, ['↻ Refresh']));

        if (controlMapEntries[cm.name + '_has_more']) {
            editor.appendChild(el('p', { className: 'ebpf-output-hint' }, ['Showing first ' + entries.length + ' entries. More data available.']));
        }

        return editor;
    }

    function fetchControlMaps() {
        if (!activeInstanceId || !activeDetail || !activeDetail.control_maps) return;
        (activeDetail.control_maps || []).forEach(function (cm) {
            // Input maps get defaults from module-info (cm.entries), refreshed after push.
            // Do not fetch from kernel-the kernel may have uninitialized (zero) values.
            if (cm.direction === 'input') return;
            apiClient.request('ebpf_get_control_map', { module: activeInstanceId, map: cm.name }).then(function (r) {
                controlMapEntries[cm.name] = (r.status === 'success' || r.status === 'partial') && r.result && r.result.entries ? r.result.entries : [];
                controlMapEntries[cm.name + '_has_more'] = r.result && r.result.has_more;
                renderControlMaps();
            }).catch(function () { controlMapEntries[cm.name] = []; renderControlMaps(); });
        });
    }

    function renderControlMaps() {
        if (!activeDetail || !activeDetail.control_maps || !activeDetail.control_maps.length) {
            controlMapsContent.innerHTML = '<p class="ebpf-empty-msg">No control maps defined.</p>'; return;
        }
        if (!activeInstanceId) {
            controlMapsContent.innerHTML = '<p class="ebpf-empty-msg">Load the module to push data to control maps.</p>'; return;
        }
        controlMapsContent.innerHTML = '';
        activeDetail.control_maps.forEach(function (cm) {
            var card = el('div', { className: 'ebpf-control-map-card' });
            var headerInfo = (cm.max_entries || '?') + ' entries';
            if (cm.editor) headerInfo = cm.editor + ' · ' + headerInfo;
            if (cm.key_label || cm.value_label) headerInfo += ' · ' + (cm.key_label || 'Key') + ' > ' + (cm.value_label || 'Value');
            card.appendChild(el('div', { className: 'ebpf-control-map-header' }, [
                el('span', { className: 'ebpf-control-map-name' }, [cm.name]),
                el('span', { className: 'ebpf-control-map-type' }, [headerInfo])
            ]));
            var editor = buildMapEditor(cm);
            card.appendChild(editor);
            controlMapsContent.appendChild(card);
        });
    }

    function buildMapEditor(cm) {
        var entries = controlMapEntries[cm.name] || [];
        var editorType = cm.editor || 'keyvalue';
        var ops = cm.supported_ops || [];

        switch (editorType) {
        case 'table': return buildOutputTable(cm, entries);
        case 'single': return buildSingleEditor(cm, entries);
        case 'chip': return buildChipEditor(cm, entries, ops);
        case 'keyvalue': return buildKVEditor(cm, entries);
        default:
            var ed = el('div', { className: 'ebpf-control-map-editor' });
            ed.appendChild(el('p', { className: 'ebpf-empty-msg' }, ['Unknown editor type: "' + editorType + '"']));
            return ed;
        }
    }

    function buildSingleEditor(cm, entries) {
        var ed = el('div', { className: 'ebpf-control-map-editor' });
        var curKey = entries.length ? entries[0].key : '';
        var curVal = entries.length ? entries[0].value : '';
        var keyLabel = cm.key_label || 'Key';
        var valLabel = cm.value_label || 'Value';

        // Key row (read-only)
        var keyRow = el('div', { className: 'ebpf-control-input-row' });
        keyRow.appendChild(el('label', { className: 'ebpf-single-label' }, [keyLabel + ': ']));
        keyRow.appendChild(el('span', { className: 'ebpf-mono' }, [String(curKey !== undefined ? curKey : '')]));
        ed.appendChild(keyRow);

        // Value row (editable)
        var valRow = el('div', { className: 'ebpf-control-input-row' });
        valRow.appendChild(el('label', { className: 'ebpf-single-label' }, [valLabel + ': ']));
        var input = el('input', { type: 'text', className: 'ebpf-input ebpf-control-input', value: String(curVal !== undefined ? curVal : '') });
        valRow.appendChild(input);
        ed.appendChild(valRow);

        if ((cm.supported_ops || []).indexOf('upsert') !== -1 || (cm.supported_ops || []).indexOf('replace_all') !== -1) {
            ed.appendChild(el('button', { className: 'std-btn ebpf-btn-save', onClick: function () {
                var v = input.value.trim();
                pushMap(cm.name, [{ value: v }], 'upsert');
            } }, ['Save']));
        }
        return ed;
    }

    function buildChipEditor(cm, entries, ops) {
        var ed = el('div', { className: 'ebpf-control-map-editor' });
        var chips = el('div', { className: 'ebpf-chip-list' });
        entries.forEach(function (e, i) {
            var chip = el('span', { className: 'ebpf-chip' });
            chip.appendChild(document.createTextNode(formatMapEntry(e)));
            chip.appendChild(el('span', { className: 'ebpf-chip-remove', onClick: function () { removeEntry(cm.name, i); } }, ['×']));
            chips.appendChild(chip);
        });
        if (!entries.length) chips.appendChild(el('span', { className: 'ebpf-empty-msg' }, ['No entries']));
        ed.appendChild(chips);

        var input = el('input', { type: 'text', className: 'ebpf-input ebpf-control-input',
            placeholder: 'e.g. ' + (cm.key_label || 'value') });
        ed.appendChild(el('div', { className: 'ebpf-control-input-row' }, [input]));

        var btnRow = el('div', { className: 'ebpf-control-btn-row' });
        if (ops.indexOf('upsert') !== -1) btnRow.appendChild(el('button', { className: 'std-btn', onClick: function () {
            var v = input.value.trim(); if (!v) return; pushMap(cm.name, [v], 'upsert'); input.value = ''; } }, ['Add']));
        if (ops.indexOf('replace_all') !== -1) btnRow.appendChild(el('button', { className: 'std-btn ebpf-btn-warning', onClick: function () {
            var items = input.value.split(/[\n,]+/).map(function (s) { return s.trim(); }).filter(Boolean);
            if (!items.length) return; pushMap(cm.name, items, 'replace_all'); input.value = ''; } }, ['Replace All']));
        if (ops.indexOf('delete') !== -1) btnRow.appendChild(el('button', { className: 'std-btn ebpf-btn-danger', onClick: function () { pushMap(cm.name, [], 'delete'); } }, ['Clear All']));
        ed.appendChild(btnRow);
        return ed;
    }

    function buildKVEditor(cm, entries) {
        var ed = el('div', { className: 'ebpf-control-map-editor' });
        var kLabel = cm.key_label || 'Key';
        var vLabel = cm.value_label || 'Value';
        var table = el('table', { className: 'ebpf-kv-table' });
        table.appendChild(el('thead', null, [el('tr', null, [
            el('th', null, [kLabel]), el('th', null, [vLabel]), el('th', null, [''])
        ])]));
        var tbody = el('tbody');
        entries.forEach(function (e, i) { tbody.appendChild(buildKVRow(e, i, cm.name)); });
        table.appendChild(tbody);
        ed.appendChild(table);
        ed.appendChild(el('button', { className: 'std-btn', onClick: function () {
            if (!controlMapEntries[cm.name]) controlMapEntries[cm.name] = [];
            controlMapEntries[cm.name].push({ key: '', value: '' }); renderControlMaps(); } }, ['+ Add Row']));
        ed.appendChild(el('button', { className: 'std-btn ebpf-btn-save', onClick: function () {
            var items = (controlMapEntries[cm.name] || []).filter(function (e) { return (e.key || e.value) !== ''; });
            pushMap(cm.name, items, 'replace_all'); } }, ['Save']));
        return ed;
    }

    function buildKVRow(entry, idx, mapName) {
        var rawKey = entry.key;
        var rawVal = entry.value;
        var k = rawKey !== undefined && rawKey !== null ? String(rawKey) : '';
        var v = rawVal !== undefined && rawVal !== null ? String(rawVal) : '';
        return el('tr', null, [
            el('td', null, [el('input', { type: 'text', className: 'ebpf-input ebpf-kv-input', value: k,
                onChange: function (e) { ensureEntry(mapName, idx);
                    controlMapEntries[mapName][idx].key = e.target.value; } })]),
            el('td', null, [el('input', { type: 'text', className: 'ebpf-input ebpf-kv-input', value: v,
                onChange: function (e) { ensureEntry(mapName, idx);
                    controlMapEntries[mapName][idx].value = e.target.value; } })]),
            el('td', null, [el('span', { className: 'ebpf-chip-remove ebpf-kv-delete', onClick: function () { removeEntry(mapName, idx); } }, ['×'])])
        ]);
    }

    function ensureEntry(mapName, idx) {
        if (!controlMapEntries[mapName]) controlMapEntries[mapName] = [];
        if (!controlMapEntries[mapName][idx]) controlMapEntries[mapName][idx] = {};
    }

    function removeEntry(mapName, idx) {
        if (!controlMapEntries[mapName]) return;
        controlMapEntries[mapName].splice(idx, 1); renderControlMaps();
    }

    function pushMap(mapName, items, op) {
        if (!activeInstanceId) { showToast('Module is not loaded', 'error'); return; }
        apiClient.submit('ebpf_control_push', { module: activeInstanceId, map: mapName, items: items, op: op }).then(function (r) {
            if (r.status === 'success') {
                showToast(r.response_msg || 'Push successful', 'success');
                apiClient.request('ebpf_get_control_map', { module: activeInstanceId, map: mapName }).then(function (rr) {
                    controlMapEntries[mapName] = (rr.status === 'success' || rr.status === 'partial') && rr.result && rr.result.entries ? rr.result.entries : [];
                    renderControlMaps();
                });
            } else { showToast(r.response_msg || 'Push failed', 'error'); }
        }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); });
    }

    //
    // TELEMETRY
    //

    function fetchTelemetry() {
        if (!activeInstanceId) return;
        apiClient.request('ebpf_get_telemetry', { module: activeInstanceId }).then(function (r) {
            telemetryData = (r.status === 'success' || r.status === 'partial') && r.result && r.result.telemetry ? r.result.telemetry : {};
            telemetryMapsMeta = (r.status === 'success' || r.status === 'partial') && r.result && r.result.telemetry_maps ? r.result.telemetry_maps : {};
            renderTelemetry();
        }).catch(function () { telemetryData = {}; renderTelemetry(); });
    }

    function renderTelemetry() {
        if (!activeDetail || !activeDetail.telemetry_maps || !activeDetail.telemetry_maps.length) {
            telemetryContent.innerHTML = '<p class="ebpf-empty-msg">No telemetry maps defined.</p>'; return;
        }
        telemetryContent.innerHTML = '';
        activeDetail.telemetry_maps.forEach(function (tm) {
            var mapMeta = telemetryMapsMeta[tm.name] || {};
            var mapType = mapMeta.type || 'array'; // default array > KPI tiles (backward compat)

            var sec = el('div', { className: 'ebpf-telemetry-section' });
            sec.appendChild(el('div', { className: 'ebpf-telemetry-section-title' }, [
                tm.name + ' (' + (mapMeta.semantics || tm.semantics || '') + ', ' + (mapMeta.poll_interval_ms || tm.poll_interval_ms || '?') + 'ms, ' + mapType + ')'
            ]));

            if (mapType === 'hash') {
                sec.appendChild(renderTelemetryTable(tm.name));
            } else {
                // Array type: single-source KPI tiles
                var tiles = el('div', { className: 'ebpf-telemetry-tiles-row' });
                var key = activeInstanceId + '/' + tm.name;
                var td = telemetryData[key] || telemetryData[tm.name] || {};
                var fields = td.fields || {};
                if (Object.keys(fields).length) {
                    Object.keys(fields).forEach(function (fn) {
                        tiles.appendChild(telemetryTile(fn, fields[fn]));
                    });
                } else {
                    tiles.appendChild(el('p', { className: 'ebpf-empty-msg' }, ['No data yet. Polling...']));
                }
                sec.appendChild(tiles);
            }
            telemetryContent.appendChild(sec);
        });
    }

    function telemetryTile(name, value) {
        var unit = name.includes('bytes') ? 'bytes' : (name.includes('ip') ? 'ipv4' : (name.endsWith('_ns') ? 'ns' : (name.endsWith('_seen') ? 'epoch' : 'count')));
        return el('div', { className: 'ebpf-telemetry-tile' }, [
            el('div', { className: 'ebpf-telemetry-label' }, [name.replace(/_/g, ' ')]),
            el('div', { className: 'ebpf-telemetry-value', dataset: { field: name, unit: unit } }, [formatUnit(value, unit)])
        ]);
    }

    // Hash-type telemetry: table with one row per source key 

    function renderTelemetryTable(mapName) {
        var prefix = mapName + '/';
        var rows = [];
        Object.keys(telemetryData).sort().forEach(function (k) {
            if (k.indexOf(prefix) === 0) {
                rows.push({ key: k.substring(prefix.length), data: telemetryData[k] });
            }
        });

        if (!rows.length) {
            return el('p', { className: 'ebpf-empty-msg' }, ['No data yet. Polling...']);
        }

        // Collect union of all field names across rows
        var fieldNames = [];
        var seen = {};
        rows.forEach(function (r) {
            Object.keys(r.data.fields || {}).forEach(function (fn) {
                if (!seen[fn]) { seen[fn] = true; fieldNames.push(fn); }
            });
        });

        var wrap = el('div', { className: 'ebpf-telemetry-table-wrap' });
        var table = el('table', { className: 'ebpf-telemetry-table' });

        var thead = el('thead');
        var headerRow = el('tr');
        headerRow.appendChild(el('th', null, ['Key']));
        fieldNames.forEach(function (fn) {
            headerRow.appendChild(el('th', null, [fn.replace(/_/g, ' ')]));
        });
        thead.appendChild(headerRow);
        table.appendChild(thead);

        var tbody = el('tbody');
        rows.forEach(function (row) {
            var tr = el('tr');
            tr.appendChild(el('td', { className: 'ebpf-telemetry-key' }, [row.key]));
            var fields = row.data.fields || {};
            fieldNames.forEach(function (fn) {
                var val = fields[fn];
                var unit = inferUnit(fn);
                tr.appendChild(el('td', { dataset: { map: mapName, key: row.key, field: fn, unit: unit } }, [formatUnit(val, unit)]));
            });
            tbody.appendChild(tr);
        });
        table.appendChild(tbody);
        wrap.appendChild(table);
        return wrap;
    }

    function inferUnit(name) {
        if (name.includes('bytes')) return 'bytes';
        if (name.endsWith('_ns')) return 'ns';
        if (name.endsWith('_seen')) return 'epoch';
        if (name.includes('ip') || name.includes('addr')) return 'ipv4';
        if (name.includes('mac')) return 'mac';
        return 'count';
    }

    function startTelemetryPolling() {
        stopTelemetryPolling();
        var capturedId = activeInstanceId;
        var iv = activeDetail && activeDetail.telemetry_maps && activeDetail.telemetry_maps[0] ? (activeDetail.telemetry_maps[0].poll_interval_ms || 2000) : 2000;
        telemetryInterval = setInterval(function () {
            if (!activeInstanceId) return;
            if (activeInstanceId !== capturedId) { stopTelemetryPolling(); return; }
            if (detailPanel.classList.contains('hidden')) { stopTelemetryPolling(); return; }
            apiClient.request('ebpf_get_telemetry', { module: activeInstanceId }).then(function (r) {
                if (r.status === 'success' || r.status === 'partial') {
                    telemetryData = r.result && r.result.telemetry ? r.result.telemetry : {};
                    telemetryMapsMeta = r.result && r.result.telemetry_maps ? r.result.telemetry_maps : {};

                    // Update array-type KPI tiles 
                    Object.keys(telemetryData).forEach(function (k) {
                        var f = telemetryData[k].fields || {};
                        Object.keys(f).forEach(function (fn) {
                            var el = document.querySelector('.ebpf-telemetry-value[data-field="' + fn + '"]');
                            if (!el) return;
                            var newVal = f[fn];
                            el.textContent = formatUnit(newVal, el.dataset.unit || 'count');
                            // Pulse the tile if value changed from last poll
                            if (lastTelemetryValues[fn] !== undefined && lastTelemetryValues[fn] !== newVal) {
                                var tile = el.closest('.ebpf-telemetry-tile');
                                if (tile) {
                                    tile.classList.add('ebpf-pulse');
                                    setTimeout(function () { tile.classList.remove('ebpf-pulse'); }, 600);
                                }
                            }
                            lastTelemetryValues[fn] = newVal;
                        });
                    });

                    // Update hash-type table cells 
                    document.querySelectorAll('.ebpf-telemetry-table td[data-map]').forEach(function (td) {
                        var entryKey = td.dataset.map + '/' + td.dataset.key;
                        var entry = telemetryData[entryKey];
                        if (entry && entry.fields && entry.fields[td.dataset.field] !== undefined) {
                            var newVal = entry.fields[td.dataset.field];
                            td.textContent = formatUnit(newVal, td.dataset.unit || 'count');
                        }
                    });
                }
            }).catch(function () {});
        }, iv);
    }

    function stopTelemetryPolling() { if (telemetryInterval) { clearInterval(telemetryInterval); telemetryInterval = null; } }

    //
    // EVENTS
    //

    function renderEvents() { eventsTbody.innerHTML = ''; seenEvents = {}; }

    function appendEventRow(ev) {
        var tr = el('tr', {
            className: 'ebpf-event-row ebpf-event-severity-' + (ev.severity || 'info') + ' ebpf-event-clickable',
            onClick: function () { showEventDetail(ev); }
        });
        tr.appendChild(el('td', null, [severityBadge(ev.severity || 'info')]));
        tr.appendChild(el('td', { className: 'ebpf-event-time' }, [formatUnit(ev.ts_ns || 0, 'ns')]));
        tr.appendChild(el('td', null, [ev.source ? ev.source.split('/').pop() : (ev.module || '-')]));
        tr.appendChild(el('td', { className: 'ebpf-event-summary' }, [ev.summary || ev.event || JSON.stringify(ev.fields || {}).slice(0, 80)]));
        eventsTbody.insertBefore(tr, eventsTbody.firstChild);
        while (eventsTbody.children.length > 200) eventsTbody.removeChild(eventsTbody.lastChild);
        if (autoScroll) { var wrap = document.getElementById('ebpf-events-table-wrap'); if (wrap) wrap.scrollTop = 0; }
    }

    function showEventDetail(ev) {
        // Built as nodes: every value here comes from the module's event stream,
        // so none of it may be reparsed as HTML.
        var rows = [
            ['Severity', severityBadge(ev.severity)],
            ['Time', formatUnit(ev.ts_ns || 0, 'ns')],
            ['Source', ev.source || ev.module || '-'],
            ['Event', ev.event || ev.summary || '-'],
        ];
        if (ev.tags && ev.tags.length) rows.push(['Tags', ev.tags.join(', ')]);

        var body = el('dl', { className: 'ebpf-details-list' });
        rows.forEach(function (r) {
            body.appendChild(el('dt', null, [r[0]]));
            body.appendChild(el('dd', null, [r[1]]));
        });
        if (ev.fields && Object.keys(ev.fields).length) {
            body.appendChild(el('h4', { style: 'margin-top:1em;color:var(--primary)' }, ['Fields']));
            body.appendChild(el('pre', { className: 'ebpf-event-raw' }, [JSON.stringify(ev.fields, null, 2)]));
        }
        showModal(body, { title: 'Event Detail' });
    }

    function startEventPolling() {
        stopEventPolling();
        var capturedId = activeInstanceId;
        eventPollInterval = setInterval(function () {
            if (eventsPaused || !activeInstanceId) return;
            if (activeInstanceId !== capturedId) { stopEventPolling(); return; }
            if (detailPanel.classList.contains('hidden')) { stopEventPolling(); return; }
            apiClient.request('ebpf_get_telemetry', { module: activeInstanceId }).then(function (r) {
                var tel = (r.status === 'success' || r.status === 'partial') && r.result && r.result.telemetry ? r.result.telemetry : {};
                // Prefer event_log (persisted history) over standalone security_event snapshots
                var hasEventLog = Object.keys(tel).some(function (k) { return tel[k] && tel[k].events; });
                Object.keys(tel).forEach(function (k) {
                    var s = tel[k];
                    if (s && s.events && Array.isArray(s.events)) {
                        s.events.forEach(function (ev) {
                            var fp = [ev.ts, ev.event, ev.fields && ev.fields.src_ip].join('|');
                            if (seenEvents[fp]) return;
                            seenEvents[fp] = true;
                            appendEventRow({
                                severity: ev.severity || 'info',
                                ts_ns: (ev.ts || 0) * 1e9,
                                source: k,
                                summary: (ev.fields && ev.fields.summary) || ev.summary || ev.event || '',
                                event: ev.event,
                                tags: ev.tags,
                                fields: ev.fields || {},
                                module: activeModule
                            });
                        });
                    }
                    if (!hasEventLog && s && s.schema_type === 'security_event' && s.fields) {
                        var fp2 = [(s.fields.ts_ns || s.ts_ns), 'security_event', s.fields.src_ip].join('|');
                        if (seenEvents[fp2]) return;
                        seenEvents[fp2] = true;
                        appendEventRow({
                            severity: s.severity || s.fields.severity || 'warn',
                            ts_ns: s.fields.ts_ns || (s.ts_ns || 0),
                            source: k,
                            summary: s.fields.summary || '',
                            fields: s.fields,
                            module: activeModule
                        });
                    }
                });
            }).catch(function () {});
        }, 3000);
    }

    function stopEventPolling() { if (eventPollInterval) { clearInterval(eventPollInterval); eventPollInterval = null; } }
    function startPolling() { startTelemetryPolling(); startEventPolling(); }
    function stopAllPolling() { stopTelemetryPolling(); stopEventPolling(); }

    //
    // MODALS
    //

    /** Build the form field for a single pre_attach_param definition (nodes, not HTML). */
    function buildParamField(param) {
        var field = el('div', { className: 'ebpf-param-field' });
        var name = 'ebpf-param-' + param.name;
        var def = param.default !== undefined ? param.default : '';

        if (param.type === 'bool') {
            var box = el('input', { type: 'checkbox', name: name });
            if (def) box.checked = true;
            var boolLabel = [box, ' ', param.label || param.name];
            if (param.required) boolLabel.push(' ', el('span', { className: 'ebpf-param-required' }, ['*']));
            field.appendChild(el('label', { className: 'ebpf-checkbox-label' }, boolLabel));
            if (param.description) {
                field.appendChild(el('span', { className: 'ebpf-param-desc' }, [param.description]));
            }
            return field;
        }

        var label = [param.label || param.name];
        if (param.required) label.push(el('span', { className: 'ebpf-param-required' }, ['*']));
        field.appendChild(el('label', { className: 'ebpf-param-label' }, label));
        if (param.description) {
            field.appendChild(el('span', { className: 'ebpf-param-desc' }, [param.description]));
        }

        if (param.type === 'int') {
            var num = el('input', {
                type: 'number', className: 'ebpf-input', name: name, value: def, style: 'width:100%'
            });
            if (param.min !== undefined) num.setAttribute('min', param.min);
            if (param.max !== undefined) num.setAttribute('max', param.max);
            field.appendChild(num);
        } else if (param.choices && param.choices.length) {
            var select = el('select', { className: 'ebpf-input', name: name, style: 'width:100%' });
            param.choices.forEach(function (c) {
                var val = typeof c === 'object' ? c.value : c;
                var lab = typeof c === 'object' ? (c.label || c.value) : c;
                var opt = el('option', { value: val }, [lab]);
                if (String(val) === String(def)) opt.selected = true;
                select.appendChild(opt);
            });
            field.appendChild(select);
        } else {
            field.appendChild(el('input', {
                type: 'text', className: 'ebpf-input', name: name, value: def, style: 'width:100%'
            }));
        }

        return field;
    }

    function openLoadModalFromMeta(m) {
        openLoadModal({
            name: m.name, version: m.version,
            attach_target: m.attach_target,
            interface: m.interface, hook_type: m.hook_type,
            pre_attach_params: m.pre_attach_params || []
        });
    }

    function openLoadModal(mod) {
        var tr = (typeof mod.dataset !== 'undefined') ? mod : null;
        var meta = tr ? metaFromRow(tr) : mod;
        if (!meta) return;
        var target = meta.attach_target || 'interface';
        var params = meta.pre_attach_params || [];
        var hasParams = params.length > 0;

        // Bodies are built as nodes: names and params come from the module
        // descriptor, so none of it may be reparsed as HTML.
        var moduleName = meta.name == null ? '' : String(meta.name);

        // attach_target === 'none' (no interface selector)
        if (target === 'none') {
            var bodyNone = document.createDocumentFragment();
            bodyNone.appendChild(el('p', null, ['Load ', el('b', null, [moduleName]), '?']));
            bodyNone.appendChild(el('p', { className: 'ebpf-info-text' }, ['No interface required.']));
            if (hasParams) {
                var sectionNone = el('div', { className: 'ebpf-params-section' },
                    [el('span', { className: 'ebpf-params-title' }, ['Parameters'])]);
                params.forEach(function (p) { sectionNone.appendChild(buildParamField(p)); });
                bodyNone.appendChild(sectionNone);
            }
            showModal(bodyNone, {
                title: 'Load: ' + meta.name, showConfirm: true, confirmText: 'Load',
                onConfirm: function () {
                    var collected = null;
                    if (hasParams) {
                        collected = collectParams(params);
                        if (collected === false) return; // validation failed
                    }
                    doLoad(meta.name, null, collected);
                }
            });
            return;
        }

        // Fetch interfaces and show combined form 
        apiClient.request('get_interfaces_names', {}).then(function (r) {
            var ifaces = (r.status === 'success' || r.status === 'partial') && r.result && r.result.interfaces ? r.result.interfaces : [];
            var required = target === 'interface';
            var label = required ? 'Interface (required):' : 'Interface (optional):';
            var ifaceList = el('div', { className: 'ebpf-load-modal-ifaces' });
            if (ifaces.length) {
                ifaces.forEach(function (i) {
                    var n = i.interface || i.name || i.id || '-';
                    var uid = String(i.id || i.iface_id || '');
                    ifaceList.appendChild(el('label', { className: 'ebpf-checkbox-label' }, [
                        el('input', { type: 'checkbox', name: 'ebpf-load-iface', value: uid }),
                        ' ',
                        el('b', null, [String(n)]),
                        ' ',
                        el('span', { className: 'ebpf-uuid' }, [uid.slice(0, 8) + '...'])
                    ]));
                });
            } else {
                ifaceList.appendChild(el('p', { className: 'ebpf-empty-msg' }, ['No interfaces available']));
            }

            var body = document.createDocumentFragment();
            body.appendChild(el('p', null, ['Load ', el('b', null, [moduleName])]));
            var form = el('div', { className: 'ebpf-load-modal-form' }, [
                el('label', { className: 'ebpf-load-modal-label' }, [label]),
                ifaceList
            ]);
            if (hasParams) {
                var section = el('div', { className: 'ebpf-params-section' },
                    [el('span', { className: 'ebpf-params-title' }, ['Parameters'])]);
                params.forEach(function (p) { section.appendChild(buildParamField(p)); });
                form.appendChild(section);
            }
            body.appendChild(form);

            showModal(body, {
                title: 'Load: ' + meta.name, showConfirm: true, confirmText: 'Load',
                onConfirm: function () {
                    var checked = document.querySelectorAll('input[name="ebpf-load-iface"]:checked');
                    var uuids = []; checked.forEach(function (c) { uuids.push(c.value); });
                    if (required && !uuids.length) { showToast('Select at least one interface', 'error'); return; }

                    var collected = null;
                    if (hasParams) {
                        collected = collectParams(params);
                        if (collected === false) return; // validation failed
                    }

                    doLoad(meta.name, uuids.length === 1 ? uuids[0] : (uuids.length > 1 ? uuids : null), collected);
                }
            });
        }).catch(function () { showToast('Failed to fetch interfaces', 'error'); });
    }

    /** Collect param values from the modal DOM. Returns false if validation fails. */
    function collectParams(paramDefs) {
        if (!paramDefs || !paramDefs.length) return {};
        var values = {};
        for (var i = 0; i < paramDefs.length; i++) {
            var p = paramDefs[i];
            var name = 'ebpf-param-' + p.name;
            // getElementsByName, not querySelector: a param name is descriptor
            // data and must never be parsed as a CSS selector.
            var input = document.getElementsByName(name)[0];
            if (!input) continue;
            var val;
            if (p.type === 'bool') {
                val = input.checked;
            } else if (p.type === 'int') {
                val = input.value === '' ? null : parseInt(input.value, 10);
                if (p.required && (val === null || isNaN(val))) {
                    showToast((p.label || p.name) + ' is required', 'error');
                    return false;
                }
                if (val !== null && !isNaN(val)) {
                    if (p.min !== undefined && val < p.min) { showToast((p.label || p.name) + ' must be ≥ ' + p.min, 'error'); return false; }
                    if (p.max !== undefined && val > p.max) { showToast((p.label || p.name) + ' must be ≤ ' + p.max, 'error'); return false; }
                }
            } else {
                val = input.value;
                if (p.required && (val === null || val === '')) {
                    showToast((p.label || p.name) + ' is required', 'error');
                    return false;
                }
            }
            // Only include if changed from default (or no default)
            if (p.default === undefined || val !== p.default) {
                values[p.name] = val;
            }
        }
        return values;
    }

    function doLoad(moduleName, ifaceParam, params) {
        var p = { module: moduleName };
        if (ifaceParam !== null) p.interface = ifaceParam;
        if (params && Object.keys(params).length > 0) p.params = params;
        apiClient.submit('ebpf_load_module', p).then(function (r) {
            if (r.status === 'success') {
                var ids = r.result && r.result.instance_ids ? r.result.instance_ids : [];
                var names = r.result && r.result.interfaces ? r.result.interfaces : [];
                var msg = 'Loaded ' + ids.length + ' instance(s)';
                if (names.length) msg += ' on ' + names.join(', ');
                showToast(msg, 'success'); refreshList();
            } else { showToast(r.response_msg || 'Load failed', 'error'); }
        }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); });
    }

    function handleUnload(preserve) {
        var id = activeInstanceId; if (!id) return;
        var a = preserve ? 'Deactivate' : 'Unload';
        var cmd = preserve ? 'ebpf_deactivate_module' : 'ebpf_unload_module';
        var body = fillTemplate('ebpf-module-action-tpl', { '.js-verb': a, '.js-module-name': activeModule });
        if (!body) return;
        showModal(body, {
            title: a + ' Module', showConfirm: true, confirmText: a, confirmClass: preserve ? 'ebpf-btn-warning' : 'ebpf-btn-danger',
            onConfirm: function () {
                var p = { module: id };
                apiClient.submit(cmd, p).then(function (r) {
                    if (r.status === 'success') { showToast(r.response_msg || a + 'ed', 'success'); backToList(); refreshList(); }
                    else showToast(r.response_msg || a + ' failed', 'error');
                }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); });
            }
        });
    }

    function reactivateInstance(m) {
        var body = fillTemplate('ebpf-module-action-tpl', { '.js-verb': 'Activate', '.js-module-name': m.name });
        if (!body) return;
        showModal(body, {
            title: 'Activate', showConfirm: true, confirmText: 'Activate',
            onConfirm: function () {
                apiClient.submit('ebpf_activate_module', { module: m.instance_id }).then(function (r) {
                    if (r.status === 'success') { showToast(r.response_msg || 'Reactivated', 'success'); backToList(); refreshList(); }
                    else showToast(r.response_msg || 'Reactivation failed', 'error');
                }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); });
            }
        });
    }

    function handleReload() {
        var id = activeInstanceId; if (!id) return;
        var body = fillTemplate('ebpf-module-action-tpl', { '.js-verb': 'Reload', '.js-module-name': activeModule });
        if (!body) return;
        showModal(body, {
            title: 'Reload', showConfirm: true, confirmText: 'Reload',
            onConfirm: function () {
                apiClient.submit('ebpf_reload_module', { module: id }).then(function (r) {
                    if (r.status === 'success') { showToast(r.response_msg || 'Reloaded', 'success'); refreshList(); selectModule(id); }
                    else showToast(r.response_msg || 'Reload failed', 'error');
                }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); });
            }
        });
    }

    //
    // AUTOLOAD
    //

    function toggleAutoload(uuid, enabled) {
        // Build autoload list from checked checkboxes in the DOM
        var list = [];
        document.querySelectorAll('.ebpf-autoload-toggle').forEach(function (cb) {
            if (cb.checked && cb.dataset.uuid) list.push(cb.dataset.uuid);
        });
        // Ensure the toggled UUID is included/excluded correctly
        if (enabled && list.indexOf(uuid) === -1) list.push(uuid);
        else if (!enabled) list = list.filter(function (id) { return id !== uuid; });

        apiClient.submit('ebpf_set_autoload', { autoload: list }).then(function (r) {
            if (r.status === 'success') {
                showToast(enabled ? 'Autoload enabled' : 'Autoload disabled', 'success');
            } else {
                showToast(r.response_msg || 'Autoload update failed', 'error');
                refreshList();
            }
        }).catch(function (e) { showToast('Network error: ' + e.message, 'error'); refreshList(); });
    }

    //
    // REFRESH
    //

    function refreshList() {
        apiClient.request('ebpf_get_module_list', {}).then(function () {
            // Reload the page to get fresh PHP-rendered data
            window.location.reload();
        }).catch(function () {});
    }

    //
    // EVENT HANDLERS
    //

    if (backBtn) backBtn.addEventListener('click', backToList);
    if (searchInput) searchInput.addEventListener('input', function () { filterRows(searchInput.value); });
    var rescanBtn = document.getElementById('ebpf-rescan-btn');
    if (refreshBtn) refreshBtn.addEventListener('click', function () { refreshList(); showToast('Refreshing...', 'info'); });
    if (rescanBtn) rescanBtn.addEventListener('click', function () {
        rescanBtn.disabled = true;
        rescanBtn.textContent = 'Scanning...';
        apiClient.submit('ebpf_module_rescan', {}).then(function (r) {
            if (r.status === 'success') {
                var loaded = (r.result && r.result.newly_loaded) || [];
                var msg = r.response_msg || 'Rescan complete';
                if (loaded.length) msg += '-loaded ' + loaded.length + ' new';
                showToast(msg, 'success');
                refreshList();
            } else {
                showToast(r.response_msg || 'Rescan failed', 'error');
            }
            rescanBtn.disabled = false;
            rescanBtn.textContent = '🔍 Rescan';
        }).catch(function (e) {
            showToast('Network error: ' + e.message, 'error');
            rescanBtn.disabled = false;
            rescanBtn.textContent = '🔍 Rescan';
        });
    });
    if (eventsPauseBtn) eventsPauseBtn.addEventListener('click', function () { eventsPaused = !eventsPaused; eventsPauseBtn.innerHTML = eventsPaused ? '▶ Resume' : '⏸ Pause'; });
    if (eventsClearBtn) eventsClearBtn.addEventListener('click', function () { eventsTbody.innerHTML = ''; seenEvents = {}; });
    if (eventsAutoScroll) eventsAutoScroll.addEventListener('change', function () { autoScroll = eventsAutoScroll.checked; });

    //
    // FOREIGN PROGRAMS: Acknowledge All
    //

    var ackAllBtn = document.getElementById('ebpf-ack-all-btn');
    if (ackAllBtn) {
        ackAllBtn.addEventListener('click', function () {
            ackAllBtn.disabled = true;
            ackAllBtn.textContent = 'Acknowledging...';
            apiClient.submit('ebpf_baseline_ack', {}).then(function (r) {
                if (r.status === 'success') {
                    showToast(r.response_msg || 'Foreign programs acknowledged', 'success');
                    refreshList();
                } else {
                    showToast(r.response_msg || 'Acknowledge failed', 'error');
                    ackAllBtn.disabled = false;
                    ackAllBtn.textContent = 'Acknowledge All';
                }
            }).catch(function (e) {
                showToast('Network error: ' + e.message, 'error');
                ackAllBtn.disabled = false;
                ackAllBtn.textContent = 'Acknowledge All';
            });
        });
    }

    //
    // FOREIGN PROGRAMS: Detach
    //

    // The whole section is absent when there are no foreign programs, so the
    // table is optional - an unguarded lookup here would abort the IIFE and
    // take the handlers registered below it (stale detach) with it.
    var foreignTable = document.getElementById('ebpf-foreign-table');
    if (foreignTable) foreignTable.addEventListener('click', function (e) {
        var detachBtn = e.target.closest('.ebpf-detach-btn');
        if (!detachBtn || detachBtn.disabled) return;

        var programId     = detachBtn.dataset.programId;
        var programName   = detachBtn.dataset.programName;
        var programType   = detachBtn.dataset.programType;
        var isXdp         = detachBtn.dataset.isXdp === '1';
        var hasDispatcher = detachBtn.dataset.hasDispatcher === '1';

        var body = fillTemplate('ebpf-foreign-detach-tpl', {
            '.js-program-name': programName,
            '.js-program-id': programId,
            '.js-program-type': programType
        });
        if (!body) return;
        if (isXdp) {
            var msg = body.querySelector(hasDispatcher ? '.js-msg-dispatcher' : '.js-msg-xdp');
            if (msg) msg.classList.remove('hidden');
        }

        showModal(body, {
            title: 'Detach Foreign Program',
            showConfirm: true,
            confirmText: 'Detach',
            confirmClass: 'ebpf-btn-danger',
            onConfirm: function () {
                detachBtn.disabled = true;
                detachBtn.textContent = 'Detaching...';
                apiClient.submit('ebpf_program_detach', { program_id: parseInt(programId, 10) }).then(function (r) {
                    if (r.status === 'success') {
                        showToast(r.response_msg || 'Program detached', 'success');
                        refreshList();
                    } else {
                        showToast(r.response_msg || 'Detach failed', 'error');
                        detachBtn.disabled = false;
                        detachBtn.textContent = 'Detach';
                    }
                }).catch(function (err) {
                    showToast('Network error: ' + err.message, 'error');
                    detachBtn.disabled = false;
                    detachBtn.textContent = 'Detach';
                });
            }
        });
    });

    //
    // STALE COMPONENTS: Detach
    //
    // A stale component is a leftover generation of one of our own modules. The
    // gateway removes it by program id, so unlike a foreign XDP program this
    // never takes the dispatcher (and the healthy programs in it) down with it.
    //

    var staleTable = document.getElementById('ebpf-stale-table');
    if (staleTable) {
        staleTable.addEventListener('click', function (e) {
            var btn = e.target.closest('.ebpf-stale-detach-btn');
            if (!btn || btn.disabled) return;

            var programId = btn.dataset.programId;
            var programName = btn.dataset.programName;
            var iface = btn.dataset.iface;

            var body = fillTemplate('ebpf-stale-detach-tpl', {
                '.js-program-name': programName,
                '.js-program-id': programId,
                '.js-iface': iface
            });
            if (!body) return;

            showModal(body, {
                title: 'Remove Stale Component',
                showConfirm: true,
                confirmText: 'Detach',
                confirmClass: 'ebpf-btn-danger',
                onConfirm: function () {
                    btn.disabled = true;
                    btn.textContent = 'Detaching...';
                    apiClient.submit('ebpf_program_detach', { program_id: parseInt(programId, 10) }).then(function (r) {
                        if (r.status === 'success') {
                            showToast(r.response_msg || 'Stale component detached', 'success');
                            refreshList();
                        } else {
                            showToast(r.response_msg || 'Detach failed', 'error');
                            btn.disabled = false;
                            btn.textContent = 'Detach';
                        }
                    }).catch(function (err) {
                        showToast('Network error: ' + err.message, 'error');
                        btn.disabled = false;
                        btn.textContent = 'Detach';
                    });
                }
            });
        });
    }

})();
