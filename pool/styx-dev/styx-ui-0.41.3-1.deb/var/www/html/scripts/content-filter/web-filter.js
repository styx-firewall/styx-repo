// web-filter.js
// Content filter: what the web filter does with the shared policy.
//
//   save -> apiClient.submit('web-filter.set_settings', payload)
//
// Which categories are blocked is not decided here: that is the catalogue's
// (categories.set_posture), because the DNS filter cuts first and a divergent
// web filter would only be heard on the flows DNS did not see. What this pane
// saves is how a blocked flow is cut and which categories derive a DSCP.
//
// Saving APPLIES: the gateway regenerates the nft rules and repoints the running
// engine before answering, so an error can mean the settings were stored but
// could not be put in force. result.msg says which, and showApiResult() reads
// exactly that - the page is only reloaded on success, so a failure leaves the
// form the operator just filled in on screen.
//
// Flags come from the DOM: the page is rendered by the backend, so the render
// already knows whether this user may write.

document.addEventListener('DOMContentLoaded', () => {
    const root = document.querySelector('.cf-page');
    if (!root || root.dataset.canEdit !== '1') return;
    bindSave(root);
});

/**
 * Build this filter's settings from the form.
 *
 * No `posture`: what is blocked is the catalogue's decision, and the backend
 * refuses a posture sent here rather than accepting a change that will not
 * happen. `dscp` is replaced wholesale, so the complete map is sent - a category
 * with no entry means "no marking", and leaving one out would silently reset it.
 */
function buildWebPolicy(root) {
    const dscp = {};

    document.querySelectorAll('.cf-dscp').forEach((input) => {
        const category = input.getAttribute('data-category') || '';
        const value = input.value.trim();
        if (category === '' || value === '') return;
        dscp[category] = value;
    });

    const modeEl = document.getElementById('cf-block-mode');
    return {
        dscp,
        // The select is always rendered next to the Save button; data-block-mode
        // is what the backend says is in force, used only if it is not there.
        block_mode: modeEl ? modeEl.value : (root.dataset.blockMode || 'reject'),
    };
}

function bindSave(root) {
    const btn = document.querySelector('[data-js="cf-save-web"]');
    if (!btn) return;

    btn.addEventListener('click', async () => {
        try {
            const result = await apiClient.submit('web-filter.set_settings', buildWebPolicy(root));
            showApiResult(result, { title: 'Web Filter', closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult(
                { status: 'error', result: { msg: err.message } },
                { title: 'Web Filter', closeText: 'Close' }
            );
        }
    });
}
