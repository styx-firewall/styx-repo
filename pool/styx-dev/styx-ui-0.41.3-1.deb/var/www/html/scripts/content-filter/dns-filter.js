// dns-filter.js
// Content filter: what the DNS filter does with the shared policy.
//
//   save -> apiClient.submit('dns-filter.set_settings', payload)
//
// Which categories are blocked is not decided here: that is the catalogue's
// (categories.set_posture), because this filter cuts first and a divergent web
// filter would only be heard on the flows this one did not see. What this pane
// saves is where a blocked name is sent and what happens when the filter is not
// there.
//
// Saving APPLIES while the filter is on (rules regenerated, engine repointed,
// live decider updated in place) and is only STORED while it is off - the
// backend says so in result.msg and returns apply: null, which is why the page
// reloads on success either way and lets the notice speak for itself.
//
// Nothing is sent for a field left empty: empty IS the setting (the clean cut,
// NXDOMAIN), not "unset", so it has to be sent explicitly rather than omitted.
//
// Flags come from the DOM: the page is rendered by the backend, so the render
// already knows whether this user may write.

document.addEventListener('DOMContentLoaded', () => {
    const root = document.querySelector('.cf-page');
    if (!root || root.dataset.canEdit !== '1') return;
    bindSave();
});

function dnsValue(id) {
    const el = document.getElementById(id);
    return el ? el.value.trim() : '';
}

function buildDnsPolicy() {
    const chains = [];
    document.querySelectorAll('.cf-chain').forEach((box) => {
        if (box.checked) chains.push(box.value);
    });

    const failEl = document.getElementById('cf-fail-mode');

    return {
        sinkhole_address: dnsValue('cf-address'),
        sinkhole_address6: dnsValue('cf-address6'),
        fail_mode: failEl ? failEl.value : 'bypass',
        chains,
    };
}

function bindSave() {
    const btn = document.querySelector('[data-js="cf-save-dns"]');
    if (!btn) return;

    btn.addEventListener('click', async () => {
        try {
            const result = await apiClient.submit('dns-filter.set_settings', buildDnsPolicy());
            showApiResult(result, { title: 'DNS Filter', closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult(
                { status: 'error', result: { msg: err.message } },
                { title: 'DNS Filter', closeText: 'Close' }
            );
        }
    });
}
