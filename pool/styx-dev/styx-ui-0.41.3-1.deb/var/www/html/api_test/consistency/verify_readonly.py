#!/usr/bin/env python3
"""Read-only smoke checks against /request.php.

Runs a data-driven list of read actions and asserts status=='success' plus the
expected keys. Does not modify state. Replaces the old payloads/request/*.json
tests (selective: keeps the endpoints that are actually exercised).

Usage:
    python api_test/consistency/verify_readonly.py --target NAME
"""

import os
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, get, require_ok
from api_test.apicore.verify_common import build_parser, build_client, finish

# Each entry: (label, action, data, required_keys, expect)
#   required_keys: dotted paths that must be present and truthy
#   expect:        list of (dotted_path, expected_value) equality checks
CHECKS = [
    # Metrics
    ("metrics.cpu", "metrics", {"metric": "cpu", "range": "5m"}, (), []),
    ("metrics.memory", "metrics", {"metric": "memory", "range": "5m"}, (), []),
    ("metrics.network", "metrics", {"metric": "network", "range": "5m"}, (), []),
    ("metrics.network_tx", "metrics", {"metric": "network_tx", "range": "5m"}, (), []),
    ("metrics.network_rx", "metrics", {"metric": "network_rx", "range": "5m"}, (), []),
    # Refresh orchestration
    ("refresh.dashboard", "refresh", {"page": "dashboard", "firstRefresh": True}, (), [("action", "refreshed")]),
    ("refresh.logs", "refresh", {"page": "logs", "section": "logs-system"}, ("commands",), [("action", "refreshed")]),
    # Network / interfaces
    ("network.get_interfaces_names", "get_interfaces_names", {}, ("result.interfaces",), []),
    ("network.get_interfaces_names_ds", "get_interfaces_names_ds", {}, ("result.ifaces_list",), []),
    # Sets (read side)
    ("sets.get_ports", "get_ports", {}, ("result.ports",), []),
    ("sets.get_address", "get_address", {}, ("result.address",), []),
    ("sets.get_interfaces_sets", "get_interfaces_sets", {}, ("result.interfaces",), []),
    ("sets.get_domains", "get_domains", {}, ("result.domain",), []),
    ("sets.get_labels", "get_labels", {}, ("result.labels",), []),
    # Packet marking page data (backend returns only result.rules today)
    ("pm.get_pm_rules", "get_pm_rules", {}, ("result.rules",), []),
    # strongSwan
    ("swan.get_status", "swan_get_status", {}, (), []),
    ("swan.get_connections", "swan_get_connections", {}, (), []),
    # Styx. Valid backup types: startup-config, running-config, profiles, events,
    # discovery-data, dns-data.
    (
        "styx.backup_download",
        "styx-backup-download",
        {"data": {"type": "startup-config"}},
        ("result.filename", "result.backup_content"),
        [],
    ),
    # System
    ("system.get_ssh_config", "get_ssh_config", {}, (), []),
    # Liveness ping (`simple` = no tasks/events; `uptime` adds the uptime object).
    # The backend only echoes client_timestamp, it does not validate it, so a
    # constant stands in for the RTT reference the UI would send.
    (
        "system.ping",
        "ping",
        {"client_timestamp": 1.0, "simple": True, "uptime": True},
        ("result.client_timestamp", "result.version", "result.uptime.system"),
        [],
    ),
    # Users
    ("user.get_user_info", "get_user_info", {"username": "admin"}, (), []),
    ("user.get_bearer_tokens", "get_bearer_tokens", {}, ("result",), []),
    # Firewall logs
    ("firewall.fw_logs", "fw_logs", {"limit": 5}, (), []),
    # Telemetry (generic TelemetryBus access). `scopes` and `points` may be
    # empty on an idle gateway -- an empty bus is healthy, not a failure, so
    # only presence is asserted. The `n`/range refusals are error responses and
    # have no representation in this success-only list.
    ("telemetry.sources", "telemetry_sources", {}, ("result.scopes",), []),
    (
        "telemetry.stats",
        "telemetry_stats",
        {},
        ("result.total_points", "result.total_buckets", "result.total_evictions"),
        [],
    ),
    ("telemetry.query", "telemetry_query", {"n": 5}, ("result.query", "result.points"), []),
    ("telemetry.instances", "telemetry_instances", {}, ("result.scopes",), []),
    ("telemetry.instances.scoped", "telemetry_instances", {"scope": "ebpf"}, ("result.scopes",), []),
    # Wire-key dispatch contract. RequestRegistry hands the whole body to the
    # controller, which reads its keys out of it by name, so these pin the key
    # names the client sends. A payload that stops sending a key, or a
    # controller that starts reading a different one, fails here rather than
    # quietly falling through to a default. Assertions stay at status==success:
    # the box may legitimately have nothing to return (no leases, no events).
    ("sets.getFullSets", "getFullSets", {}, (), []),
    ("dhcp.get_dhcp_leases", "dhcp-server.get_dhcp_leases", {}, (), []),
    ("ethtool.get_catalog", "ethtool-config.get_catalog", {}, (), []),
    (
        "ethtool.get_catalog.family",
        "ethtool-config.get_catalog",
        {"family": "features"},
        (),
        [],
    ),
    ("styx.get_events", "styx_get_events", {}, (), []),
    ("traffic_stats.get", "traffic-stats-get", {}, (), []),
    (
        "traffic_stats.get.summary",
        "traffic-stats-get",
        {"params": {"summary_only": True}},
        (),
        [],
    ),
    (
        "network.get_valid_parents",
        "get_valid_parents",
        {"iface_subtype": "vlan"},
        (),
        [],
    ),
    # `tableFilters` is the client-side key (the controller maps it to the
    # gateway's `table_filters`). `chain: local` is the shorthand for
    # input+output; both shapes are the documented ones.
    (
        "firewall.get_rules_forward",
        "fw_get_rules_forward",
        {"tableFilters": {"table": "filter", "chain": "forward"}},
        (),
        [],
    ),
    (
        "firewall.get_rules_local",
        "fw_get_rules_local",
        {"tableFilters": {"table": "filter", "chain": "local"}},
        (),
        [],
    ),
    # `tableFilters` is optional: omitted (or empty) means no positional
    # filter, so these two are the same request and both return every rule.
    # Pinned here because the endpoint names suggest a chain they do not apply.
    ("firewall.get_rules_forward.unfiltered", "fw_get_rules_forward", {}, (), []),
    ("firewall.get_rules_local.unfiltered", "fw_get_rules_local", {}, (), []),
    (
        "firewall.get_rules_forward.empty",
        "fw_get_rules_forward",
        {"tableFilters": {}},
        (),
        [],
    ),
]


def run(client, continue_on_fail):
    failures = 0
    for label, action, data, keys, expect in CHECKS:
        try:
            resp = client.request(action, data)
            require_ok(resp, *keys)
            for path, expected in expect:
                actual = get(resp, path)
                if actual != expected:
                    raise AssertionError(f"{path} = {actual!r}, expected {expected!r}")
            print(f"  OK   {label}")
        except (ApiError, AssertionError) as e:
            print(f"  FAIL {label}: {e}")
            failures += 1
            if not continue_on_fail:
                break
    return failures


def main():
    p = build_parser("Read-only smoke checks against /request.php")
    p.add_argument("--continue-on-fail", action="store_true", help="Keep going after a check fails")
    args = p.parse_args()
    client = build_client(args)
    failures = run(client, args.continue_on_fail)

    finish(failures)


if __name__ == "__main__":
    main()
