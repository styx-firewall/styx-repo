#!/usr/bin/env python3
"""Lifecycle verification for the eBPF modules, with the leftover invariant.

Flow: discover the interface -> snapshot the module list -> load a passive module
-> check it comes up attached -> unload it -> assert that nothing of ours was
left behind in the kernel.

The last step is the reason this exists. The interesting failure is not that load
or unload returns success, it is that a module can be reported as loaded while
its program is not on the interface, or that unloading leaves a program nobody
owns holding its maps. Both are invisible unless someone looks at the kernel, and
the module list already reports both over HTTP, so no shell on the target is
needed:

  * `unmanaged_programs` and `stale_components` must be exactly as they were
    before the load (a leftover of ours shows up in one of the two);
  * `missing_components` must not name the instance we just loaded, which is what
    would mean a module that loaded and did not attach;
  * `styx_program_count` must come back to its baseline.

It also goes through submit.php and the registries, so it covers the frontend
path: a command can work at the gateway and still be unreachable from the UI
until it is registered.

What this does NOT cover: a detach done from outside the gateway (an `ip link set
xdp off` by hand, a driver reset), which is the other way a program of ours ends
up unowned. That needs a shell on the target and stays a manual check.

Caveats before pointing it at a box:
  * it mutates real kernel state, so run it on a lab;
  * attaching an XDP costs receive throughput on a virtio interface (measured
    around a third), so do not run it on a box that is passing traffic;
  * the module is passive on purpose: ddos_protect drops traffic while loaded.

Usage:
    python api_test/integration/verify_ebpf.py --target NAME [--interface if0]
"""

import os
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish

DEFAULT_INTERFACE = "if0"
MODULE = "ping_monitor"  # passive: an active module would drop traffic while loaded


def _snapshot(resp):
    """The four numbers the invariant is stated in."""
    result = resp["result"]
    return {
        "unmanaged": len(result.get("unmanaged_programs") or []),
        "stale": len(result.get("stale_components") or []),
        "missing": len(result.get("missing_components") or []),
        "styx_programs": result.get("styx_program_count", 0),
    }


def run(client, iface_name):
    tracker = ResourceTracker()

    def step(label, fn):
        fn()
        print(f"  OK   {label}")

    def module_list():
        return require_ok(client.request("ebpf_get_module_list"), "result.instances")

    try:
        # The load command takes an interface UUID, not a name.
        resp = require_ok(client.request("get_interfaces_names_ds"), "result.ifaces_list")
        iface_uuid = None
        for item in resp["result"]["ifaces_list"]:
            if item.get("interface") == iface_name and item.get("id"):
                iface_uuid = item["id"]
                break
        if iface_uuid is None:
            raise AssertionError(f"interface {iface_name} not found in get_interfaces_names_ds")
        print(f"  OK   {iface_name} = {iface_uuid}")

        before = _snapshot(module_list())
        print(f"  OK   baseline: {before}")
        if before["unmanaged"] or before["stale"]:
            # A dirty box says nothing about this test, and failing later with a
            # number that did not move is more confusing than saying it here.
            raise AssertionError(
                f"the box is not clean to start with ({before['unmanaged']} unmanaged, "
                f"{before['stale']} stale); clean those first, see api_test/consistency"
            )

        loaded = require_ok(
            client.submit("ebpf_load_module", {"module": MODULE, "interface": iface_uuid}),
            "result.instance_ids",
        )
        instance_ids = loaded["result"]["instance_ids"]
        if not instance_ids:
            raise AssertionError(f"load succeeded but returned no instance id: {loaded}")
        instance_id = instance_ids[0]
        # Undo by instance UUID: that is what unload takes, and it has to be armed
        # before the checks below so a failure still leaves the box clean.
        tracker.remember("ebpf_unload_module", {"module": instance_id})
        print(f"  OK   loaded {MODULE} as {instance_id}")

        after_load = module_list()
        listed = [i for i in after_load["result"]["instances"] if i.get("instance_id") == instance_id]
        if not listed:
            raise AssertionError(f"the instance is not in the module list: {instance_id}")
        if listed[0].get("status") != "loaded":
            raise AssertionError(f"the instance is listed as {listed[0].get('status')!r}, not 'loaded'")
        print("  OK   the instance is listed as loaded")

        missing_ids = {m.get("instance_id") for m in after_load["result"].get("missing_components") or []}
        if instance_id in missing_ids:
            raise AssertionError(
                "the module loaded and its program is not on the interface: this is the "
                "condition missing_components reports, and it means the box filters nothing"
            )
        print("  OK   the instance's program is attached")

        step("unload", lambda: require_ok(client.submit("ebpf_unload_module", {"module": instance_id})))
        tracker.forget("ebpf_unload_module", {"module": instance_id})

        after = _snapshot(module_list())
        print(f"  OK   after unload: {after}")
        for key in ("unmanaged", "stale", "missing", "styx_programs"):
            if after[key] != before[key]:
                raise AssertionError(
                    f"unload left something behind: {key} went from {before[key]} to {after[key]}. "
                    f"A program of ours with no owner shows up in unmanaged_programs or "
                    f"stale_components, and it keeps its maps until something releases it."
                )
        print("  OK   nothing of ours was left behind")

    finally:
        tracker.cleanup(client)


def main():
    parser = build_parser("Verify eBPF module load/unload and that unload leaves no leftover")
    parser.add_argument(
        "--interface",
        default=DEFAULT_INTERFACE,
        help=f"interface to load on (default: {DEFAULT_INTERFACE})",
    )
    args = parser.parse_args()
    client = build_client(args)
    try:
        run(client, args.interface)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
