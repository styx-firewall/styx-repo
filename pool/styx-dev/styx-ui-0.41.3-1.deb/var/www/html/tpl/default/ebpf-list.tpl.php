<?php
/**
 * eBPF fragment: module list (instances + available) and toolbar.
 *
 * @var array $tdata - $tdata['tpl_data'] contains the full formatted page data
 */
$pd = $tdata['tpl_data'] ?? [];
?>

<!-- TOOLBAR -->
<div class="ebpf-toolbar">
    <input type="text" id="ebpf-search" class="ebpf-input ebpf-search-inline"
           placeholder="Search modules by name, tags, hook type...">
    <button id="ebpf-refresh-btn" class="std-btn" type="button">&#8635; Refresh</button>
    <button id="ebpf-rescan-btn" class="std-btn" type="button">🔍 Rescan</button>
    <?= $pd['counts_html'] ?? '' ?>
</div>

<!-- LIST VIEW -->
<div id="ebpf-list-view">
    <div class="ebpf-section">
        <div class="ebpf-section-header">
            <span class="ebpf-section-title">Managed by Styx</span>
        </div>
        <table id="ebpf-module-list" class="ebpf-module-table">
            <thead>
                <tr>
                    <th>Module</th><th>Status</th><th>Type</th><th>Hook</th>
                    <th>Interface</th><th>Autoload</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pd['instances_rows'] ?? [] as $row): ?>
                <tr class="ebpf-module-row"
                    data-module="<?= $row['name_attr'] ?>"
                    data-instance-id="<?= $row['instance_id_attr'] ?>"
                    data-status="<?= $row['status_attr'] ?>"
                    data-attach-target="<?= $row['attach_target_attr'] ?>"
                    data-version="<?= $row['version_attr'] ?>"
                    data-hook-type="<?= $row['hook_type_attr'] ?>"
                    data-interface="<?= $row['interface_attr'] ?>"
                    data-mode="<?= $row['mode_attr'] ?>"
                    data-pre-attach-params="<?= $row['pre_attach_params_json'] ?>">
                    <td>
                        <b><?= $row['name_attr'] ?></b>
                        <span class="ebpf-version-tag">v<?= $row['version_attr'] ?></span>
                        <?= $row['uuid_html'] ?>
                    </td>
                    <td><?= $row['status_html'] ?></td>
                    <td><?= $row['type_html'] ?></td>
                    <td><span class="ebpf-info-tag"><?= $row['hook_type_attr'] ?></span></td>
                    <td><?= $row['interface_attr'] ?></td>
                    <td>
                        <?php if ($row['has_autoload']): ?>
                        <input type="checkbox" class="ebpf-autoload-toggle"
                               data-uuid="<?= $row['instance_id_attr'] ?>"
                               <?= $row['autoload_attr'] ?>>
                        <?php else: ?>-<?php endif; ?>
                    </td>
                    <td>
                        <?php if ($row['activatable']): ?>
                        <button class="std-btn ebpf-btn-action ebpf-activate-btn-js"
                                data-uuid="<?= $row['instance_id_attr'] ?>">Activate</button>
                        <?php endif; ?>
                        <button class="std-btn ebpf-info-btn"
                                data-identifier="<?= $row['identifier_attr'] ?>"
                                data-is-instance="<?= $row['is_instance_attr'] ?>">Info</button>
                    </td>
                </tr>
                <?php endforeach; ?>

                <?php if (!empty($pd['available_rows'])): ?>
                <tr class="ebpf-section-separator"><td colspan="7">Available to load</td></tr>
                <?php endif; ?>

                <?php foreach ($pd['available_rows'] ?? [] as $row): ?>
                <tr class="ebpf-module-row"
                    data-module="<?= $row['name_attr'] ?>"
                    data-instance-id=""
                    data-status="<?= $row['status_attr'] ?>"
                    data-attach-target="<?= $row['attach_target_attr'] ?>"
                    data-version="<?= $row['version_attr'] ?>"
                    data-hook-type="<?= $row['hook_type_attr'] ?>"
                    data-mode="<?= $row['mode_attr'] ?>"
                    data-pre-attach-params="<?= $row['pre_attach_params_json'] ?>">
                    <td>
                        <b><?= $row['name_attr'] ?></b>
                        <span class="ebpf-version-tag">v<?= $row['version_attr'] ?></span>
                    </td>
                    <td><?= $row['status_html'] ?></td>
                    <td><?= $row['type_html'] ?></td>
                    <td><span class="ebpf-info-tag"><?= $row['hook_type_attr'] ?></span></td>
                    <td>-</td><td>-</td>
                    <td>
                        <button class="std-btn ebpf-info-btn"
                                data-identifier="<?= $row['identifier_attr'] ?>"
                                data-is-instance="0">Info</button>
                        <?php if ($row['loadable']): ?>
                        <button class="std-btn ebpf-btn-action ebpf-load-btn-js"
                                data-module="<?= $row['name_attr'] ?>">Load</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
