<?php
/**
 * Content Filter page shell: the DNS filter.
 *
 * Echo-only; every derived value comes from the formatter ($pd).
 * js: scripts/content-filter/dns-filter.js
 * css: default-content-filter.css
 *
 * There is **no policy editor here**: what is blocked is decided once, in the
 * catalogue, because the DNS filter cuts first and a divergent web filter would
 * only be heard on the flows DNS did not see. What this pane holds is what only
 * this mechanism can do: rewrite an answer, and decide what happens when it is
 * not there.
 *
 * Two things this pane must not let the operator misread, both of them design
 * decisions rather than omissions:
 *   - with no target configured, the answer is NXDOMAIN: the clean cut. An empty
 *     box is the default, not an unfinished one.
 *   - the appliance serves no block page of its own and there is no setting for
 *     one: showing a blocked user something means pointing the address at a
 *     server of the operator's.
 */
$pd = $tdata['page_data'] ?? [];
$da = $pd['disabled_attr'] ?? 'disabled';
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content cf-page" data-can-edit="<?= !empty($pd['can_edit']) ? '1' : '0' ?>">
        <h1>DNS Filter</h1>
        <?php if (!empty($pd['error_html'])): ?>
            <div class="std-error-box"><strong>Error:</strong> <?= $pd['error_html'] ?></div>
        <?php else: ?>

        <?php if (empty($pd['feature_on'])): ?>
            <div class="std-error-box std-warning-box">The DNS filter is <strong>off</strong>. Settings saved here are
                stored and will take effect when it is enabled, but DNS is not being inspected right now.</div>
        <?php elseif (!empty($pd['enabled_not_running'])): ?>
            <div class="std-error-box std-warning-box">The DNS filter is <strong>enabled but not running</strong>: its
                reader is not up, so no query is being answered right now. The gateway log says what the last attempt
                ran into.</div>
        <?php endif; ?>

        <div class="section-full">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-heading">In force</h2>
                    <?php if (!empty($pd['queue_num'])): ?>
                    <span class="std-badge std-badge--chain">queue <?= $pd['queue_num'] ?></span>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if (!empty($pd['status_error_html'])): ?>
                        <div class="std-error-box"><strong>Error:</strong> <?= $pd['status_error_html'] ?></div>
                    <?php else: ?>
                        <h3>Blocked</h3>
                        <div class="cf-badges">
                            <?php if (empty($pd['blocked'])): ?>
                                <span class="text-muted">No category is set to block.</span>
                            <?php else: ?>
                                <?php foreach ($pd['blocked'] as $item): ?>
                                <span class="std-badge std-badge--danger"><?= $item['label_html'] ?></span>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>

                        <details class="cf-fold">
                            <summary class="cf-fold-summary">Counters
                                <span class="cf-fold-hint">(<?= $pd['counters_count'] ?>)</span></summary>
                            <?php if (empty($pd['counter_groups'])): ?>
                            <span class="text-muted">The filter is not running, so there is nothing to count.</span>
                            <?php else: ?>
                            <div class="cf-counter-groups">
                                <?php foreach ($pd['counter_groups'] as $group): ?>
                                <div class="cf-counter-group">
                                    <h4 class="cf-group-title"><?= $group['title_html'] ?></h4>
                                    <div class="cf-badges">
                                        <?php foreach ($group['rows'] as $row): ?>
                                        <span class="std-badge std-badge--muted"><?= $row['label_html'] ?>:
                                            <?= $row['value_html'] ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                            <p class="text-muted">Blocked with the rewritten records at zero is worth a look: the name
                                is being blocked and the client is getting nothing rather than being sent somewhere -
                                either the answer carried no address at all, or that family has no target configured.</p>
                        </details>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="section-full">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-heading">What happens to a blocked name</h2>
                </div>
                <div class="card-body">
                    <?php if (!empty($pd['cut_mode'])): ?>
                        <div class="std-info-box">
                            <strong>Clean cut.</strong> With nothing configured, a blocked name is answered
                            <strong>NXDOMAIN</strong>: the client's resolver stops there and the browser never opens a
                            connection. Nothing is served, there is nothing to hang on, and no address of this
                            appliance is exposed to the user network. <strong>This is the default and it is a
                            policy, not a gap.</strong>
                        </div>
                    <?php endif; ?>

                    <div class="cf-blocks">
                        <?php foreach (($pd['targets'] ?? []) as $target): ?>
                        <div class="cf-block">
                            <div class="cf-block-head">
                                <h4 class="cf-block-title"><?= $target['family_html'] ?></h4>
                                <span class="std-badge <?= $target['state_class'] ?>"><?= $target['state_html'] ?></span>
                            </div>
                            <div class="cf-block-row">
                                <input class="std-input" type="text" id="<?= $target['input_id_attr'] ?>"
                                    value="<?= $target['value_attr'] ?>" placeholder="<?= $target['placeholder_attr'] ?>"
                                    aria-label="<?= $target['input_label_attr'] ?>" <?= $da ?>>
                            </div>
                            <p class="cf-resolved"><span class="cf-resolved-label">Resolved:</span>
                                <?= $target['resolved_html'] ?></p>
                            <p class="cf-block-note"><?= $target['detail_html'] ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <details class="cf-fold cf-fold--note">
                        <summary class="cf-fold-summary">How the address is used</summary>
                        <p class="text-muted">Either field takes an <strong>IP address or a hostname</strong>. A hostname
                            is resolved when the settings are saved, never on the packet path - a lookup per response
                            would be exactly the latency this design exists to avoid. The price, said out loud: if the
                            name's addresses change, the filter keeps using the ones it resolved until the settings are
                            saved again.</p>
                        <p class="text-muted">What lives at that address and what it does with the connection is
                            <strong>outside this filter's scope</strong>: its job ends at the answer naming the address
                            the operator configured. If the address belongs to another machine, there is nothing to
                            configure or open here.</p>
                    </details>
                </div>
            </div>
        </div>

        <div class="section-full">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-heading">When the filter is not there</h2>
                </div>
                <div class="card-body">
                    <p class="text-muted">This says which failure is acceptable in <strong>this</strong> network, not how
                        hard the filter tries. <strong>Strict</strong> is not the hardened choice: it is right where a
                        window without filtering is itself the compliance violation, and wrong everywhere else.</p>
                    <div class="std-form std-form--compact">
                        <div class="form-row">
                            <div class="form-col">
                                <select class="std-select" id="cf-fail-mode"
                                    aria-label="<?= $pd['fail_mode_aria_attr'] ?>" <?= $da ?>>
                                    <?php foreach (($pd['fail_modes'] ?? []) as $mode): ?>
                                    <option value="<?= $mode['value_attr'] ?>" <?= $mode['selected'] ?>><?= $mode['label_html'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <h3>Chains</h3>
                    <p class="text-muted">Which one applies depends on where the resolver is, and that is the operator's
                        topology to know.</p>
                    <div class="std-form std-form--compact">
                        <?php foreach (($pd['chain_rows'] ?? []) as $chain): ?>
                        <div class="form-row">
                            <div class="form-col">
                                <label>
                                    <input type="checkbox" class="cf-chain" value="<?= $chain['value_attr'] ?>"
                                        <?= $chain['checked'] ?> <?= $da ?>>
                                    <?= $chain['label_html'] ?>
                                </label>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="form-row">
                        <div class="form-col cf-actions">
                            <button class="std-btn" type="button" data-js="cf-save-dns" <?= $da ?>>Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php endif; ?>
    </main>
</div>
