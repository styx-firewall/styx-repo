# tc_l3fwd/tc_l3fwd_companion.py
#
# Companion for tc_l3fwd. The module has no control maps: the FIB is the kernel's own
# (FRR installs the routes there) and there is nothing for userspace to push. The only
# map is the telemetry counter array, which the deserializer below aggregates.

import ctypes

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import aggregate_percpu

# C struct mirror (keep in sync with tc_l3fwd.c)


class StatsT(ctypes.Structure):
    """`struct stats_t`: ten __u64 counters, 80 bytes."""

    _pack_ = 1
    _fields_ = [
        ("packets_processed", ctypes.c_uint64),
        ("packets_forwarded", ctypes.c_uint64),
        ("packets_redirected", ctypes.c_uint64),
        ("packets_passed", ctypes.c_uint64),
        ("packets_dropped", ctypes.c_uint64),
        ("packets_ttl", ctypes.c_uint64),
        ("errors", ctypes.c_uint64),
        ("packets_gso", ctypes.c_uint64),
        ("packets_frag_needed", ctypes.c_uint64),
        ("packets_no_neigh", ctypes.c_uint64),
    ]


# Telemetry deserializer


@register_deserializer("tc_l3fwd", "stats")
class StatsDeserializer(FeedbackDeserializer):
    """Aggregate the per-CPU counters into one dict."""

    _FIELDS = [
        "packets_processed",
        "packets_forwarded",
        "packets_redirected",
        "packets_passed",
        "packets_dropped",
        "packets_ttl",
        "errors",
        "packets_gso",
        "packets_frag_needed",
        "packets_no_neigh",
    ]
    _FMTS = ["<Q"] * 10

    def from_map(self, raw, spec, key=None) -> dict:
        totals = aggregate_percpu(raw, self._FIELDS, self._FMTS)
        return {field: totals[field] for field in self._FIELDS}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")
