/* SPDX-License-Identifier: AGPL-3.0-or-later */
/*
 * Soft:        IPv4 layer-3 forwarder at the TC hook (tcx/ingress) using the live
 *              kernel FIB.
 *
 *              The XDP port of the same logic (xdp_l3fwd_devmap) forwards before the
 *              driver hands the packet to the stack, but on virtio_net an XDP program
 *              disables GRO/GSO and the host then segments every frame; the measured
 *              cost in this lab is a collapse of the throughput. A TC program runs
 *              after the driver and GRO, so the offloads stay, and bpf_redirect()
 *              steers the skb to the egress interface without going through the
 *              routing stack or netfilter.
 *
 *              The FIB is the kernel's own (FRR installs the BGP routes there), the
 *              lookup is bpf_fib_lookup(), and a lookup that does not resolve (no
 *              neighbour yet, destination local, forwarding disabled) is returned to
 *              the stack with TC_ACT_OK: the stack resolves the neighbour and sends
 *              the first packet, and the following ones take this path. The TTL check
 *              runs only on a packet the lookup says to forward, so a packet addressed
 *              to the node itself (eBGP keepalives travel with TTL 1) reaches the
 *              stack unharmed.
 *
 *              The length given to the helper depends on the skb: a GSO super-packet
 *              carries the total block in its IPv4 header, so it is passed with
 *              tot_len = 0 (the helper then accepts it through is_skb_forwardable()
 *              and the egress segments it); a plain skb passes its own tot_len and a
 *              real MTU miss goes back to the stack, which fragments it.
 *
 *              IPv4 only, untagged ingress. No NAT: this is a forwarder, not a
 *              gateway; masquerade/conntrack stay in the kernel path of the gateway.
 *
 *              References (design, not copied):
 *                - samples/bpf/xdp_fwd_kern.c (TTL and MAC rewrite)
 *                - netdev "Forwarding from TC classifier" (bpf_fib_lookup +
 *                  bpf_redirect from a TC classifier, TC_ACT_OK on NO_NEIGH)
 *                - Cilium bpf/lib/fib.h (fib_redirect_v4, GPL-2.0-only OR BSD-2-Clause)
 *
 * Authors:     Styx
 * Copyright (C) 2026 Styx
 */
#define KBUILD_MODNAME "tc_l3_fwd"

#include <linux/bpf.h>
#include <linux/if_ether.h>
#include <linux/ip.h>
#include <linux/pkt_cls.h>
#include <linux/types.h>
#include <bpf/bpf_endian.h>
#include <bpf/bpf_helpers.h>

/* <sys/socket.h> is what pulls glibc into the build of the XDP sibling; the only thing
 * this program needs from it is AF_INET, and the kernel UAPI uses the same value. */
#ifndef AF_INET
#define AF_INET 2
#endif

struct stats_t {
	__u64 packets_processed;
	__u64 packets_forwarded;
	__u64 packets_redirected;
	__u64 packets_passed;
	__u64 packets_dropped;
	__u64 packets_ttl;
	__u64 errors;
	__u64 packets_gso;
	__u64 packets_frag_needed;
	__u64 packets_no_neigh;
};

struct {
	__uint(type, BPF_MAP_TYPE_PERCPU_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, struct stats_t);
} stats SEC(".maps");

static __always_inline void stats_inc(__u32 field)
{
	__u32 zero = 0;
	struct stats_t *s = bpf_map_lookup_elem(&stats, &zero);

	if (!s)
		return;
	switch (field) {
	case 0: __sync_fetch_and_add(&s->packets_processed, 1); break;
	case 1: __sync_fetch_and_add(&s->packets_forwarded, 1); break;
	case 2: __sync_fetch_and_add(&s->packets_redirected, 1); break;
	case 3: __sync_fetch_and_add(&s->packets_passed, 1); break;
	case 4: __sync_fetch_and_add(&s->packets_dropped, 1); break;
	case 5: __sync_fetch_and_add(&s->packets_ttl, 1); break;
	case 6: __sync_fetch_and_add(&s->errors, 1); break;
	case 7: __sync_fetch_and_add(&s->packets_gso, 1); break;
	case 8: __sync_fetch_and_add(&s->packets_frag_needed, 1); break;
	case 9: __sync_fetch_and_add(&s->packets_no_neigh, 1); break;
	}
}

/* include/net/ip.h's ip_decrease_ttl, with the one's complement carry applied: the
 * XDP sibling only adds the constant, which is wrong for the 0xffff edge case. */
static __always_inline void ip_decrease_ttl(struct iphdr *iph)
{
	__u32 check = (__u32)iph->check;

	check += (__u32)bpf_htons(0x0100);
	iph->check = (__sum16)(check + (check >= 0xFFFF));
	iph->ttl--;
}

SEC("tcx/ingress")
int tc_l3_fwd(struct __sk_buff *skb)
{
	void *data, *data_end;
	struct ethhdr *eth;
	struct iphdr *iph;
	struct bpf_fib_lookup fib = {};
	int rc;

	stats_inc(0);

	if (bpf_skb_pull_data(skb, sizeof(struct ethhdr) + sizeof(struct iphdr)) < 0) {
		stats_inc(6);
		return TC_ACT_OK;
	}

	data = (void *)(long)skb->data;
	data_end = (void *)(long)skb->data_end;

	eth = data;
	if ((void *)(eth + 1) > data_end) {
		stats_inc(6);
		return TC_ACT_OK;
	}
	if (eth->h_proto != bpf_htons(ETH_P_IP)) {
		stats_inc(3);
		return TC_ACT_OK;
	}

	iph = (void *)(eth + 1);
	if ((void *)(iph + 1) > data_end || iph->version != 4 || iph->ihl < 5) {
		stats_inc(6);
		return TC_ACT_OK;
	}

	fib.family = AF_INET;
	fib.tos = iph->tos;
	fib.l4_protocol = iph->protocol;
	fib.ipv4_src = iph->saddr;
	fib.ipv4_dst = iph->daddr;
	fib.ifindex = skb->ingress_ifindex;

	/* GRO coalesces and TCP builds TSO skbs: on those, the IPv4 header carries the
	 * length of the whole block (up to 64 KB), not the on-wire segment. The helper
	 * only checks the MTU when the caller supplies tot_len, and then it compares that
	 * number against the route MTU; a super-packet would come back FRAG_NEEDED and
	 * be handed to the stack on every packet (measured in the lab: 34k forwarded of
	 * 483k). With tot_len = 0 the helper falls back to is_skb_forwardable(), which
	 * accepts a GSO skb regardless of its length because the egress segments it. */
	if (skb->gso_size) {
		stats_inc(7);
		fib.tot_len = 0;
	} else {
		fib.tot_len = bpf_ntohs(iph->tot_len);
	}

	rc = bpf_fib_lookup(skb, &fib, sizeof(fib), BPF_FIB_LOOKUP_DIRECT);
	if (rc != BPF_FIB_LKUP_RET_SUCCESS) {
		/* NO_NEIGH (no entry, or the first packet after it expires) and a real MTU
		 * miss on a non-GSO skb (the stack fragments) go to the stack. The helper
		 * does not fill dmac/smac on those results, and copying them would send the
		 * frame to a neighbour that is not resolved. */
		if (rc == BPF_FIB_LKUP_RET_NO_NEIGH)
			stats_inc(9);
		else if (rc == BPF_FIB_LKUP_RET_FRAG_NEEDED)
			stats_inc(8);
		stats_inc(3);
		return TC_ACT_OK;
	}

	/* Only packets this node forwards are TTL-checked. A local destination (the
	 * router's own addresses, eBGP keepalives among them) comes back NOT_FWDED from
	 * the lookup and goes to the stack untouched: eBGP sends with TTL 1, and dropping
	 * it here starves the session until the hold timer expires (measured in the lab:
	 * the sessions fell 180 s after the load). */
	if (iph->ttl <= 1) {
		stats_inc(4);
		stats_inc(5);
		return TC_ACT_SHOT;
	}

	ip_decrease_ttl(iph);
	__builtin_memcpy(eth->h_dest, fib.dmac, ETH_ALEN);
	__builtin_memcpy(eth->h_source, fib.smac, ETH_ALEN);

	stats_inc(1);
	stats_inc(2);
	return bpf_redirect(fib.ifindex, 0);
}

char _license[] SEC("license") = "GPL";
