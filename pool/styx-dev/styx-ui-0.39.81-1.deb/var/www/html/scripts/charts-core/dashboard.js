window.addEventListener('load', function() {
    var chartSetups = [
        function() {
            window.registerChart('cpu', null, function(range) {
                fetchAndUpdateChart('cpu', range, function(data) {
                    var metrics = data.metrics || [];
                    var labels = metrics.map(m => m.timestamp);
                    var values = metrics.map(m => m.cpu_usage);
                    var blockSize = getBlockSizeForRange(range);
                    var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
                    var dsValues = downsampleAvg(values, blockSize);
                    if (!window.charts['cpu']) {
                        window.charts['cpu'] = makeSingleChart('cpu-chart', 'CPU %', dsValues, 'rgba(42,122,226,1)', {min:0, max:100, stepSize:20}, dsLabels);
                    } else {
                        var chart = window.charts['cpu'];
                        chart.data.labels = dsLabels;
                        chart.data.datasets[0].data = dsValues;
                        chart.update();
                    }
                });
            }, '15m');
        },
        function() {
            window.registerChart('memory', null, function(range) {
                fetchAndUpdateChart('memory', range, function(data) {
                    var metrics = data.metrics || [];
                    var labels = metrics.map(m => m.timestamp);
                    var values = metrics.map(m => m.memory_usage);
                    var blockSize = getBlockSizeForRange(range);
                    var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
                    var dsValues = downsampleAvg(values, blockSize);
                    if (!window.charts['memory']) {
                        window.charts['memory'] = makeSingleChart('memory-chart', 'Memory %', dsValues, 'rgba(76,175,80,1)', {min:0, max:100, stepSize:20}, dsLabels);
                    } else {
                        var chart = window.charts['memory'];
                        chart.data.labels = dsLabels;
                        chart.data.datasets[0].data = dsValues;
                        chart.update();
                    }
                });
            }, '15m');
        },
        function() {
            window.registerChart('network_tx', null, function(range) {
                fetchAndUpdateChart('network_tx', range, function(data) {
                    var shortLabels = formatShortTimeLabels(data.labels);
                    var allIfaces = data.ifaces;
                    var txDataRaw = allIfaces.map(function(iface) { return data.metrics[iface]; });
                    var flat = txDataRaw.flat();
                    var max = Math.max.apply(null, flat);
                    var scale = 1, unit = 'B/s';
                    if (max >= 1_000_000) { scale = 1_000_000; unit = 'MB/s'; }
                    else if (max >= 1_000) { scale = 1_000; unit = 'KB/s'; }
                    var txData = txDataRaw.map(arr => arr.map(v => v/scale));
                    var blockSize = getBlockSizeForRange(range);
                    var dsLabels = downsampleLabels(shortLabels, blockSize);
                    var dsTxData = txData.map(arr => downsampleAvg(arr, blockSize));
                    var dynColors = generateColors(allIfaces.length);
                    var chart = window.charts['network_tx'];
                    if (!chart || chart.data.datasets.length !== allIfaces.length) {
                        if (chart) chart.destroy();
                        window.charts['network_tx'] = makeMultilineChart('network-tx-chart', dsLabels, allIfaces, dsTxData, dynColors);
                    } else {
                        chart.data.labels = dsLabels;
                        chart.data.datasets.forEach(function(ds, idx) {
                            ds.data = dsTxData[idx];
                            ds.label = allIfaces[idx];
                            ds.borderColor = dynColors[idx % dynColors.length];
                            ds.backgroundColor = dynColors[idx % dynColors.length].replace('1)', '0.2)');
                        });
                        chart.update();
                    }
                    var titleElem = document.querySelector('h3:has(+ #network-tx-chart), h3:has(+ canvas#network-tx-chart)');
                    if (!titleElem) {
                        titleElem = Array.from(document.querySelectorAll('h3')).find(h => h.textContent.trim().toLowerCase().startsWith('network tx'));
                    }
                    if (titleElem) titleElem.textContent = 'Network TX (' + unit + ')';
                });
            }, '5m');
        },
        function() {
            window.registerChart('network_rx', null, function(range) {
                fetchAndUpdateChart('network_rx', range, function(data) {
                    var shortLabels = formatShortTimeLabels(data.labels);
                    var allIfaces = data.ifaces;
                    var rxDataRaw = allIfaces.map(function(iface) { return data.metrics[iface]; });
                    var flat = rxDataRaw.flat();
                    var max = Math.max.apply(null, flat);
                    var scale = 1, unit = 'B/s';
                    if (max >= 1_000_000) { scale = 1_000_000; unit = 'MB/s'; }
                    else if (max >= 1_000) { scale = 1_000; unit = 'KB/s'; }
                    var rxData = rxDataRaw.map(arr => arr.map(v => v/scale));
                    var blockSize = getBlockSizeForRange(range);
                    var dsLabels = downsampleLabels(shortLabels, blockSize);
                    var dsRxData = rxData.map(arr => downsampleAvg(arr, blockSize));
                    var dynColors = generateColors(allIfaces.length);
                    var chart = window.charts['network_rx'];
                    if (!chart || chart.data.datasets.length !== allIfaces.length) {
                        if (chart) chart.destroy();
                        window.charts['network_rx'] = makeMultilineChart('network-rx-chart', dsLabels, allIfaces, dsRxData, dynColors);
                    } else {
                        chart.data.labels = dsLabels;
                        chart.data.datasets.forEach(function(ds, idx) {
                            ds.data = dsRxData[idx];
                            ds.label = allIfaces[idx];
                            ds.borderColor = dynColors[idx % dynColors.length];
                            ds.backgroundColor = dynColors[idx % dynColors.length].replace('1)', '0.2)');
                        });
                        chart.update();
                    }
                    var titleElem = document.querySelector('h3:has(+ #network-rx-chart), h3:has(+ canvas#network-rx-chart)');
                    if (!titleElem) {
                        titleElem = Array.from(document.querySelectorAll('h3')).find(h => h.textContent.trim().toLowerCase().startsWith('network rx'));
                    }
                    if (titleElem) titleElem.textContent = 'Network RX (' + unit + ')';
                });
            }, '5m');
        }
    ];
    // Format technical watcher names to human-readable labels
    function formatWatchdogName(name) {
        return name.split('_').map(function(word) {
            return word.charAt(0).toUpperCase() + word.slice(1);
        }).join(' ');
    }

    // Extract a human-readable observed value from an entity's state dict
    function observedValue(entity) {
        var state = entity.state || {};
        if (typeof state !== 'object') return String(state);
        var val = state.status;
        if (val === undefined || val === null) {
            // Fallback: first scalar field (e.g. watcher_alive: true)
            var keys = Object.keys(state);
            for (var i = 0; i < keys.length; i++) {
                var v = state[keys[i]];
                if (typeof v !== 'object' && v !== null) { val = v; break; }
            }
        }
        if (val === undefined || val === null) return '';
        if (typeof val === 'boolean') val = val ? 'alive' : 'down';
        return String(val);
    }

    // Color the observed-state badge by known status values
    function observedBadgeClass(val) {
        var good = ['ok', 'up', 'running', 'alive', 'connected', 'enabled'];
        var warn = ['warning', 'warn', 'degraded'];
        var bad = ['critical', 'error', 'down', 'stopped', 'disabled', 'not_initialized', 'dead'];
        if (good.indexOf(val) !== -1) return 'std-badge--success';
        if (warn.indexOf(val) !== -1) return 'std-badge--warning';
        if (bad.indexOf(val) !== -1) return 'std-badge--danger';
        return 'std-badge--muted';
    }

    // Watchers with more entities than this collapse to a single summary row.
    var WATCHDOG_COLLAPSE_THRESHOLD = 5;
    // Persist watcher open-state across the 30s re-renders.
    var watchdogOpen = {};

    function escapeHtml(s) {
        return String(s).replace(/[&<>"']/g, function(c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    // One entity row: name + ok/fail badge + observed-state badge.
    function buildEntityRow(entityName, entity) {
        var ok = (entity.status === 'ok');
        var badgeClass = ok ? 'std-badge--success' : 'std-badge--danger';
        var label = ok ? 'OK' : 'FAIL';

        // Second marker: the observed state reported by the check
        var observedHtml = '';
        var observed = observedValue(entity);
        if (observed) {
            observedHtml = '<span class="std-badge ' + observedBadgeClass(observed) + '" style="min-width:52px;text-align:center;">' + observed + '</span>';
        }

        var html = '<div class="std-flex-row watchdog-row">';
        html += '<div class="std-flex-col" style="flex:1;">' + formatWatchdogName(entityName);
        html += '</div>';
        html += '<div class="std-flex-col" style="flex:0 0 auto;flex-direction:row;align-items:center;gap:.4rem;justify-content:flex-end;">';
        html += '<span class="std-badge ' + badgeClass + '" style="min-width:52px;text-align:center;">' + label + '</span>';
        html += observedHtml;
        html += '</div>';
        html += '</div>';
        return html;
    }

    // Watchdog panel-fetch watchers and render entity-level status
    function fetchWatchdog() {
        apiClient.request('styx_get_watchers', {})
            .then(function(resp) {
                var container = document.getElementById('watchdog-content');
                if (!container) return;
                if (!resp || resp.status !== 'success') {
                    container.innerHTML = '<div class="std-flex-row"><div class="std-flex-col" style="text-align:center;padding:20px;color:var(--danger-color);">Error loading watchdog data</div></div>';
                    return;
                }
                var watchers = (resp.result && resp.result.watchers) ? resp.result.watchers : [];
                if (watchers.length === 0) {
                    container.innerHTML = '<div class="std-flex-row"><div class="std-flex-col" style="text-align:center;padding:20px;">No watchers configured</div></div>';
                    return;
                }
                var html = '';
                watchers.forEach(function(w) {
                    var entities = w.entities || {};
                    var entityKeys = Object.keys(entities);

                    if (entityKeys.length === 0) return;

                    var rowsHtml = '';
                    entityKeys.forEach(function(entityName) {
                        rowsHtml += buildEntityRow(entityName, entities[entityName]);
                    });

                    // Many-entity watchers (e.g. disk_usage with one entity per
                    // partition) collapse to a summary row; a failing entity
                    // keeps it expanded so the problem is always visible.
                    if (entityKeys.length > WATCHDOG_COLLAPSE_THRESHOLD) {
                        var failCount = entityKeys.filter(function(k) { return entities[k].status !== 'ok'; }).length;
                        var open = (failCount > 0 || watchdogOpen[w.name]) ? ' open' : '';
                        var summary =
                            '<summary class="watchdog-summary" title="Click to expand/collapse">' +
                            '<span class="watchdog-summary-name">' + escapeHtml(formatWatchdogName(w.name)) + '</span>' +
                            '<span class="watchdog-count">' + entityKeys.length + ' entities' + (failCount ? ' · ' + failCount + ' failing' : '') + '</span>' +
                            '<span class="std-badge ' + (w.status === 'ok' ? 'std-badge--success' : 'std-badge--danger') + '" style="min-width:52px;text-align:center;">' + (w.status === 'ok' ? 'OK' : 'FAIL') + '</span>' +
                            '</summary>';
                        html += '<details class="watchdog-watcher"' + open + ' data-watcher="' + escapeHtml(w.name) + '">' +
                                summary +
                                '<div class="watchdog-entities">' + rowsHtml + '</div>' +
                                '</details>';
                    } else {
                        html += rowsHtml;
                    }
                });
                container.innerHTML = html;
            })
            .catch(function(err) {
                var container = document.getElementById('watchdog-content');
                if (container) {
                    container.innerHTML = '<div class="std-flex-row"><div class="std-flex-col" style="text-align:center;padding:20px;color:var(--danger-color);">Error fetching watchdog data</div></div>';
                }
            });
    }

    // Persist open/close state across re-renders. 'toggle' does not bubble,
    // so listen in capture on the container (which survives the innerHTML swap).
    document.getElementById('watchdog-content').addEventListener('toggle', function(ev) {
        var target = ev.target;
        if (!(target instanceof Element)) return;
        if (target.classList.contains('watchdog-watcher')) {
            watchdogOpen[target.dataset.watcher] = target.open;
        }
    }, true);

    // Fetch watchdog immediately and then every 30 seconds
    fetchWatchdog();
    setInterval(fetchWatchdog, 30000);

    chartSetups.forEach(function(setup, i) {
        setTimeout(setup, (i+1) * 500);
    });
});

