/**
 * Handles log filtering and refresh for both system and styx logs
 */

let isLoading = false;

const CONFIG = {
    system: {
        form: '#system-logs-form', tbody: '#system-logs-table tbody',
        level: '#system-log-level', limit: '#system-log-limit',
        cmd: 'get_system_logs', dataPath: 'system_logs', cols: 5,
        hasId: true, hasService: true, useLastId: true
    },
    styx: {
        form: '#styx-logs-form', tbody: '#styx-logs-tbody',
        level: '#log-level', limit: '#log-limit',
        cmd: 'get_styx_logs',         dataPath: 'styx_logs', cols: 3,
        hasId: false, hasService: false, useLastId: true
    }
};

const PRIORITY_MAP = {
    '0': 'EMERG',
    '1': 'ALERT',
    '2': 'CRIT',
    '3': 'ERR',
    '4': 'WARN',
    '5': 'NOTICE',
    '6': 'INFO',
    '7': 'DEBUG'
};

const LEVEL_TO_NUM = {
    'EMERG': '0',
    'ALERT': '1',
    'CRIT': '2',
    'ERR': '3',
    'ERROR': '3',
    'WARN': '4',
    'WARNING': '4',
    'NOTICE': '5',
    'INFO': '6',
    'DEBUG': '7'
};

function init(type) {
    const cfg = CONFIG[type];
    if (!cfg) return;

    const form = document.querySelector(cfg.form);
    if (form) form.addEventListener('submit', (e) => handleSubmit(e, cfg, type));

    // Restore saved filter values
    const levelEl = document.querySelector(cfg.level);
    const limitEl = document.querySelector(cfg.limit);
    const savedLevel = loadState(`logs-parser:${type}`, 'level', null);
    const savedLimit = loadState(`logs-parser:${type}`, 'limit', null);
    if (savedLevel !== null && levelEl) { levelEl.value = savedLevel; }
    if (savedLimit !== null && limitEl) { limitEl.value = savedLimit; }

    loadLogs(cfg);
    setInterval(() => !isLoading && loadLogs(cfg), 5000);
}

async function handleSubmit(e, cfg, type) {
    e.preventDefault();
    if (type) {
        const levelEl = document.querySelector(cfg.level);
        const limitEl = document.querySelector(cfg.limit);
        if (levelEl) { saveState(`logs-parser:${type}`, 'level', levelEl.value); }
        if (limitEl) { saveState(`logs-parser:${type}`, 'limit', limitEl.value); }
    }
    if (cfg.useLastId) {
        window[`${cfg.cmd}_lastId`] = 0;
        window[`${cfg.cmd}_logs`] = [];
        const tbody = document.querySelector(cfg.tbody);
        if (tbody) tbody.innerHTML = '';
    }
    await loadLogs(cfg);
}

async function loadLogs(cfg) {
    if (isLoading) return;
    isLoading = true;

    if (cfg.useLastId && !window[`${cfg.cmd}_logs`]) window[`${cfg.cmd}_logs`] = [];

    const btn = document.querySelector('button[type="submit"]');
    if (btn) { btn.disabled = true; btn.textContent = 'Loading...'; }

    try {
        let level = document.querySelector(cfg.level)?.value || '';
        if (LEVEL_TO_NUM[level]) level = LEVEL_TO_NUM[level];

        const limit = parseInt(document.querySelector(cfg.limit)?.value) || 50;
        const dataToSend = { level, limit };
        if (cfg.useLastId) dataToSend.last_id = window[`${cfg.cmd}_lastId`] || 0;

        const result = await apiClient.submit(cfg.cmd, dataToSend);

        if (result.status === 'success' || result.status === 'ok') {
            let logs = cfg.dataPath ? (result.result?.[cfg.dataPath] || []) : (result.result || []);

            if (cfg.useLastId) {
                if (logs.length === 0 && window[`${cfg.cmd}_logs`].length === 0) {
                    displayError('No logs found', cfg);
                } else if (logs.length > 0) {
                    logs.sort((a, b) => (b.id || 0) - (a.id || 0));
                    const existingIds = new Set(window[`${cfg.cmd}_logs`].map(l => l.id));
                    logs.forEach(log => !existingIds.has(log.id) && window[`${cfg.cmd}_logs`].unshift(log));
                    if (window[`${cfg.cmd}_logs`].length > limit) {
                        window[`${cfg.cmd}_logs`] = window[`${cfg.cmd}_logs`].slice(0, limit);
                    }
                    displayLogs(window[`${cfg.cmd}_logs`], cfg);
                } else {
                    displayLogs(window[`${cfg.cmd}_logs`], cfg);
                }
                if (result.result?.last_id) window[`${cfg.cmd}_lastId`] = result.result.last_id;
            } else {
                logs.length > 0 ? displayLogs(logs, cfg) : displayError('No logs found', cfg);
            }
        } else {
            displayError(`Error: ${result.response_msg || 'Unknown error'}`, cfg);
        }
    } catch (error) {
        displayError(`Network error: ${error.message}`, cfg);
    } finally {
        isLoading = false;
        if (btn) { btn.disabled = false; btn.textContent = 'Filter / Refresh'; }
    }
}

function displayLogs(logs, cfg) {
    const tbody = document.querySelector(cfg.tbody);
    if (!tbody) return;

    tbody.innerHTML = '';
    if (!logs?.length) {
        tbody.innerHTML = '' +
            '<tr>' +
                '<td colspan="' + String(cfg.cols) + '"' +
                    ' style="text-align: center; color: #666;">' +
                    'No logs found' +
                '</td>' +
            '</tr>';
        return;
    }

    [...logs]
        .sort((a, b) => (b.id || 0) - (a.id || 0))
        .forEach(log => {
            const tr = document.createElement('tr');
            const date = log.date_fmt || log.timestamp_iso || log.date || '';
            const level = getLevel(log);
            const levelClass = getLevelClass(level);

            if (cfg.hasId && cfg.hasService) {
                const serviceText = esc(log.SYSLOG_IDENTIFIER || log.UNIT || '');
                const msgText = esc(log.MESSAGE || '');
                tr.innerHTML = '' +
                    '<td>' + (log.id || '') + '</td>' +
                    '<td style="white-space:nowrap; font-family: monospace;">' + date + '</td>' +
                    '<td><span class="log-level ' + levelClass + '">' + esc(level) + '</span></td>' +
                    '<td class="log-service" title="' + serviceText + '">' + serviceText + '</td>' +
                    '<td class="log-message">' + msgText + '</td>';
            } else {
                const msgText = esc(log.message || '');
                tr.innerHTML = '' +
                    '<td style="white-space:nowrap; font-family: monospace; font-size: 1em;">' + date + '</td>' +
                    '<td><span class="log-level ' + levelClass + '">' + esc(level) + '</span></td>' +
                    '<td class="log-message">' + msgText + '</td>';
            }
            tbody.appendChild(tr);
        });
}

function getLevel(log) {
    const p = log.PRIORITY ?? log.level;
    if (p !== undefined && p !== null && PRIORITY_MAP[p]) return PRIORITY_MAP[p];
    if (p !== undefined && p !== null) return String(p);
    return 'INFO';
}

function getLevelClass(level) {
    if (!level) return '';
    const l = level.toUpperCase();
    if (l === 'EMERG' || l === 'EMERGENCY') return 'level-emergency';
    if (l === 'ALERT') return 'level-alert';
    if (l === 'CRIT' || l === 'CRITICAL') return 'level-critical';
    if (l === 'ERR' || l === 'ERROR') return 'level-error';
    if (l === 'WARN' || l === 'WARNING') return 'level-warning';
    if (l === 'NOTICE') return 'level-notice';
    if (l === 'INFO') return 'level-info';
    if (l === 'DEBUG') return 'level-debug';
    return '';
}

function displayError(msg, cfg) {
    const tbody = document.querySelector(cfg.tbody);
    if (tbody) {
        tbody.innerHTML = `
            <tr>
                <td colspan="${cfg.cols}" style="text-align: center; color: red;">${esc(msg)}</td>
            </tr>`;
    }
}

function esc(text) {
    if (text == null) return '';
    const div = document.createElement('div');
    div.textContent = String(text);
    return div.innerHTML;
}

function pad(n) { return String(n).padStart(2, '0'); }

// Auto-initialize
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('#system-logs-form')) init('system');
    if (document.querySelector('#styx-logs-form')) init('styx');
});
