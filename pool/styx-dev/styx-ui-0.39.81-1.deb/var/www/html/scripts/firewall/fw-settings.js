/*
 * Firewall Settings: rule toggles (conntrack bypass / drop invalid), ct-state
 * logging (ct_state_log), log cache sizes (fw_logs_max / ct_logs_max) and the
 * conntrack log flow filters (ct_logs_filter_{loopback,multicast,broadcast}).
 *
 * Each leaf control (checkbox or number) carries a dotted settings path in
 * data-path and submits only its own delta: the path is expanded to the merge
 * payload, e.g. "conntrack_bypass.forward" -> { conntrack_bypass: { forward: v } }
 * or a single-segment path -> { key: v }. The backend merges the payload over
 * the current settings, so an unrelated setting can never be overwritten and
 * future settings not rendered here are preserved.
 *
 * While a request is in flight every control is disabled, which serializes the
 * changes and prevents out-of-order overwrites from rapid clicks.
 */
document.addEventListener('DOMContentLoaded', function() {
    const toggles = document.querySelectorAll('.fw-setting-toggle');
    const numbers = document.querySelectorAll('.fw-setting-number');
    const ctlChecks = document.querySelectorAll('.fw-setting-ctl');

    if (toggles.length === 0 && numbers.length === 0 && ctlChecks.length === 0) {
        return;
    }

    let saving = false;

    function setSaving(active) {
        saving = active;
        toggles.forEach(function(toggle) {
            toggle.disabled = active;
        });
        numbers.forEach(function(input) {
            input.disabled = active;
        });
        ctlChecks.forEach(function(check) {
            check.disabled = active;
        });
    }

    // Expands a dotted settings path into a merge payload:
    //   'ct_logs_filter_loopback'  -> { ct_logs_filter_loopback: value }
    //   'conntrack_bypass.forward' -> { conntrack_bypass: { forward: value } }
    function payloadFromPath(path, value) {
        const payload = {};
        const keys = path.split('.');
        let node = payload;
        keys.forEach(function(key, i) {
            node = node[key] = (i === keys.length - 1) ? value : {};
        });
        return payload;
    }

    // apiClient.submit never rejects (network failures resolve as
    // {status:'error'}), so errors are handled in the else branch.
    function submitDelta(payload, onSuccess, onFailure) {
        setSaving(true);
        apiClient.submit('set_firewall_settings', payload)
            .then(function(data) {
                if (data.status === 'success') {
                    if (onSuccess) onSuccess();
                    showApiResult(data, { closeText: 'Close' });
                } else {
                    if (onFailure) onFailure();
                    showApiResult(data, { title: 'Error', closeText: 'Close' });
                }
            })
            .finally(function() {
                setSaving(false);
            });
    }

    toggles.forEach(function(toggle) {
        toggle.addEventListener('change', function() {
            // Guard: controls are disabled while saving, so this is belt-and-suspenders.
            if (saving) {
                toggle.checked = !toggle.checked;
                return;
            }
            const prev = toggle.checked;
            const path = toggle.dataset.path;
            if (!path) {
                // Toggle without a settings path: malformed, revert and ignore.
                toggle.checked = !prev;
                return;
            }
            submitDelta(payloadFromPath(path, prev), null, function() {
                toggle.checked = !prev;
            });
        });
    });

    numbers.forEach(function(input) {
        // Last value successfully committed to the gateway.
        input.dataset.committed = input.value;

        input.addEventListener('change', function() {
            if (saving) {
                input.value = input.dataset.committed;
                return;
            }
            const committed = input.dataset.committed;
            const value = Number(input.value);
            if (!Number.isInteger(value) || value < 1 || value > 100000) {
                input.value = committed;
                showError('The log cache size must be an integer between 1 and 100000.', 'Invalid value');
                return;
            }
            const payload = payloadFromPath(input.dataset.path, value);
            submitDelta(payload, function() {
                input.dataset.committed = String(value);
            }, function() {
                input.value = committed;
            });
        });
    });

    // Ct-state log checkboxes: per chain, two independent states (established,
    // related). The backend replaces the whole chain list, so each change
    // submits the combined list of every checkbox in the same chain.
    ctlChecks.forEach(function(check) {
        check.addEventListener('change', function() {
            // Guard: controls are disabled while saving, belt-and-suspenders.
            if (saving) {
                check.checked = !check.checked;
                return;
            }
            const prev = check.checked;
            const chain = check.dataset.ctlChain;
            const states = [];
            ['established', 'related'].forEach(function(state) {
                const el = document.querySelector(
                    '.fw-setting-ctl[data-ctl-chain="' + chain + '"][data-ctl-state="' + state + '"]'
                );
                if (el && el.checked) {
                    states.push(state);
                }
            });
            const payload = {};
            payload['ct_state_log'] = {};
            payload['ct_state_log'][chain] = states;
            submitDelta(payload, null, function() {
                check.checked = !prev;
            });
        });
    });
});
