// fw-logs-ct.js
// Handles fetching and display of conntrack flow logs (ct-logs.get_ct_logs)
// Uses LogTable for rendering with a detail modal showing orig + reply side by side.

let ctLogTable = null;
let ctFetchController = null;
let ctCurrentQuery = '';
let ctLastMark = null;
let ctAutoRefreshInterval = null;
let ctAutoRefreshPaused = false;

// Columns config provided by the server formatter
const ctColumns = window.__ctLogsColumns || [];

/**
 * Resolve the display value for a host cell: custom_name ?? hostname ?? ip
 * @param {Object} log - The log entry
 * @param {string} prefix - Key prefix (e.g. 'src_', 'dest_', 'reply_src_')
 * @returns {string}
 */
function resolveHostDisplay(log, prefix) {
    const customName = log[prefix + 'custom_name'] || '';
    const hostname = log[prefix + 'hostname'] || '';
    const ip = log[prefix + 'ip'] || '';
    return customName || hostname || ip;
}

/**
 * Refine host cells once they are in the DOM. Each cell shows a resolved
 * name/domain in place of the IP, keeping the FULL value in the DOM (so
 * selecting/copying the cell yields the whole domain). When the value is wider
 * than the cell, the overflowing line is scrolled to its end so the TAIL is
 * visible and the beginning is clipped (no ellipsis). Tooltip: full value plus
 * the underlying IP when truncated, IP alone otherwise.
 * @param {HTMLElement|null} root - container to scan for host cells
 */
function finalizeHostCells(root) {
    if (!root) return;
    root.querySelectorAll('.fwlog-host-cell').forEach(span => {
        const host = span.getAttribute('data-host');
        const ip = span.getAttribute('data-ip');
        const overflow = span.scrollWidth > span.clientWidth;
        if (overflow) {
            span.scrollLeft = span.scrollWidth - span.clientWidth;
            let t = host || ip || '';
            if (host && ip && ip !== host) {
                t += '\nIP: ' + ip;
            }
            span.title = t;
        } else {
            span.scrollLeft = 0;
            span.title = ip || '';
        }
    });
}

// Attach render callbacks that require runtime globals
ctColumns.forEach(col => {
    if (col.key === 'timestamp') {
        col.render = val => val && window.dateUtils ? window.dateUtils.formatString(val) : val;
    }
    if (col.key === 'flow.duration') {
        col.render = val => {
            if (val === null || val === undefined) return '';
            const secs = parseFloat(val);
            if (isNaN(secs)) return String(val);
            if (secs < 1) return (secs * 1000).toFixed(0) + ' ms';
            if (secs < 60) return secs.toFixed(1) + ' s';
            const m = Math.floor(secs / 60);
            const s = Math.floor(secs % 60);
            return m + 'm ' + s + 's';
        };
    }
    if (col.key === 'orig_bytes' || col.key === 'reply_bytes') {
        col.render = val => {
            if (val === null || val === undefined) return '';
            const n = parseInt(val, 10);
            if (isNaN(n)) return String(val);
            if (n >= 1e9) return (n / 1e9).toFixed(1) + ' GB';
            if (n >= 1e6) return (n / 1e6).toFixed(1) + ' MB';
            if (n >= 1e3) return (n / 1e3).toFixed(1) + ' KB';
            return n + ' B';
        };
    }
    if (col.key === 'src_ip' || col.key === 'dest_ip' ||
        col.key === 'reply_src_ip' || col.key === 'reply_dest_ip') {
        const prefix = col.key.replace('_ip', '_'); // 'src_ip' -> 'src_', 'reply_src_ip' -> 'reply_src_'
        const origRender = col.render;
        col.render = (raw, log) => {
            const display = resolveHostDisplay(log, prefix);
            if (display === raw) {
                return origRender ? origRender(raw, log) : raw;
            }
            const span = document.createElement('span');
            span.textContent = display;
            span.className = 'fwlog-host-cell';
            span.title = raw;
            span.dataset.host = display;
            span.dataset.ip = raw;
            return span;
        };
    }
});

// Ensure the Details button column exists
if (!ctColumns.some(c => c.key === '__details')) {
    ctColumns.push({
        key: '__details',
        label: '',
        visible: true,
        render: (v, log) => {
            const btn = document.createElement('button');
            btn.textContent = 'Details';
            btn.className = 'std-btn fwlog-details-btn';
            btn.addEventListener('click', (ev) => {
                ev.stopPropagation();
                showCtLogModal(log);
            });
            return btn;
        }
    });
}

function resetMark() {
    ctLastMark = null;
    try { removeState('ct-logs', 'mark'); } catch (e) { /* noop */ }
}

function renderColumnControls() {
    const container = document.getElementById('column-controls-ct');
    if (!container) return;
    container.innerHTML = '';
    ctColumns.forEach((col, idx) => {
        const label = document.createElement('label');
        label.style.marginRight = '12px';
        label.style.cursor = 'pointer';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = col.visible !== false;
        checkbox.onchange = () => {
            ctColumns[idx].visible = checkbox.checked;
            const thead = ctLogTable.table.querySelector('thead');
            if (thead && thead.rows[0].cells[idx]) {
                thead.rows[0].cells[idx].style.display = checkbox.checked ? '' : 'none';
            }
            const tbody = ctLogTable.table.querySelector('tbody');
            Array.from(tbody.rows).forEach(tr => {
                if (tr.cells[idx]) {
                    tr.cells[idx].style.display = checkbox.checked ? '' : 'none';
                }
            });
            saveState('ct-logs', 'columns', ctColumns.map(c => c.visible !== false));
            finalizeHostCells(tbody);
        };
        label.appendChild(checkbox);
        label.appendChild(document.createTextNode(' ' + col.label));
        container.appendChild(label);
    });
    // Apply saved visibility state
    const thead = ctLogTable.table.querySelector('thead');
    const tbody = ctLogTable.table.querySelector('tbody');
    ctColumns.forEach((col, idx) => {
        const visible = col.visible !== false;
        if (thead && thead.rows[0].cells[idx]) {
            thead.rows[0].cells[idx].style.display = visible ? '' : 'none';
        }
        Array.from(tbody.rows).forEach(tr => {
            if (tr.cells[idx]) {
                tr.cells[idx].style.display = visible ? '' : 'none';
            }
        });
    });
    finalizeHostCells(tbody);
}

function showCtLogModal(log) {
    const tpl = document.getElementById('ct-flow-modal-tpl');
    if (!tpl) {
        alert('Flow details:\n' + JSON.stringify(log, null, 2));
        return;
    }

    const clone = tpl.content.cloneNode(true);

    // Resolve a dotted path like "orig.src_ip" against the log object
    function getField(path) {
        const parts = path.split('.');
        let v = log;
        for (const p of parts) {
            if (v === null || v === undefined) return undefined;
            v = v[p];
        }
        return v;
    }

    function esc(s) {
        return String(s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }

    // Fill data-field slots
    clone.querySelectorAll('[data-field]').forEach(el => {
        const path = el.getAttribute('data-field');
        const val = getField(path);
        if (val === null || val === undefined) {
            el.innerHTML = '<span class="ct-nil">—</span>';
        } else if (typeof val === 'object') {
            el.textContent = JSON.stringify(val);
        } else if (path === 'flow.duration' && typeof val === 'number') {
            el.textContent = val.toFixed(2) + ' s';
        } else {
            el.textContent = esc(String(val));
        }
    });

    // Show/hide conditional sections
    const icmpSection = clone.querySelector('[data-section="icmp"]');
    if (icmpSection) icmpSection.hidden = !log.icmp;
    const oobSection = clone.querySelector('[data-section="oob"]');
    if (oobSection) oobSection.hidden = !log.oob;

    // Wrap in a container for showModal
    const container = document.createElement('div');
    container.appendChild(clone);

    if (typeof showModal === 'function') {
        showModal(container.innerHTML, {
            boxClass: 'ctlog-modal-box',
            contentClass: 'fwlog-modal-content',
            modalClass: 'fwlog-modal-overlay'
        });
    } else {
        alert('Flow details:\n' + JSON.stringify(log, null, 2));
    }
}

function fetchCtLogs() {
    try {
        window.showLoader?.(true);
    } catch (e) { /* ignore */ }

    if (ctFetchController) {
        ctFetchController.abort();
    }
    const controller = new AbortController();
    ctFetchController = controller;

    const limit = parseInt(document.getElementById('ct-logs-limit').value) || 20;
    const payload = {
        action: 'get_ct_logs',
        query: String(ctCurrentQuery || '').trim(),
        limit,
        mark: ctLastMark
    };

    apiClient.request('get_ct_logs', payload, { signal: controller.signal })
        .then(json => {
            if (typeof json.mark !== 'undefined' && json.mark !== null) {
                ctLastMark = json.mark;
            }
            const tbody = document.getElementById('dynamic-table-ct').querySelector('tbody');
            if (tbody) {
                Array.from(tbody.rows).forEach(tr => tr.classList.remove('log-row-new'));
            }
            if (Array.isArray(json.logs)) {
                ctLogTable.addRows(json.logs, true);
                finalizeHostCells(tbody);
            }
        })
        .catch(err => {
            if (err && err.name === 'AbortError') return;
            if (err && err.response_msg) {
                renderCtError(err.response_msg);
            } else {
                renderCtError(err && err.message ? err.message : String(err));
            }
        })
        .finally(() => {
            try { if (typeof hideLoader === 'function') hideLoader(); } catch (e) { /* noop */ }
        });
}

function renderCtError(msg) {
    const tbody = document.querySelector('#dynamic-table-ct tbody');
    if (tbody) {
        tbody.innerHTML = '<tr><td colspan="' + ctColumns.length + '" style="text-align:center;color:red;">' +
            msg.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') +
            '</td></tr>';
    }
}

function getRefreshIntervalMs() {
    const input = document.getElementById('ct-logs-refresh-interval');
    const seconds = input ? parseInt(input.value) : 20;
    return Math.max(2, isNaN(seconds) ? 20 : seconds) * 1000;
}

function startAutoRefresh() {
    if (ctAutoRefreshPaused) return;
    if (ctAutoRefreshInterval) clearInterval(ctAutoRefreshInterval);
    ctAutoRefreshInterval = setInterval(() => {
        fetchCtLogs();
    }, getRefreshIntervalMs());
}

function pauseAutoRefresh() {
    if (ctAutoRefreshInterval) {
        clearInterval(ctAutoRefreshInterval);
        ctAutoRefreshInterval = null;
    }
    ctAutoRefreshPaused = true;
    const btn = document.getElementById('ct-logs-toggle-autorefresh');
    if (btn) btn.textContent = 'Resume Auto-refresh';
}

function resumeAutoRefresh() {
    ctAutoRefreshPaused = false;
    startAutoRefresh();
    const btn = document.getElementById('ct-logs-toggle-autorefresh');
    if (btn) btn.textContent = 'Pause Auto-refresh';
}

// All known queryable keys for CT logs
const CT_QUERY_KEYS = [
    'ct.id', 'ct.mark',
    'orig.src.ip', 'orig.dst.ip', 'orig.src.port', 'orig.dst.port',
    'orig.bytes', 'orig.packets',
    'reply.src.ip', 'reply.dst.ip', 'reply.src.port', 'reply.dst.port',
    'reply.bytes', 'reply.packets',
    'flow.start', 'flow.end', 'flow.duration',
    'icmp.type', 'icmp.code',
    'src.ip', 'dst.ip', 'src.port', 'dst.port',
    'protocol', 'protocol_num', 'event_type', 'timestamp',
];

function setupCtLogs() {
    // Restore persisted state
    const savedQuery = loadState('ct-logs', 'query', '');
    ctCurrentQuery = savedQuery;

    const savedInterval = loadState('ct-logs', 'refreshInterval', null);
    const intervalEl = document.getElementById('ct-logs-refresh-interval');
    if (savedInterval !== null && intervalEl) {
        intervalEl.value = savedInterval;
    }

    // Always start from the current tail on open: do NOT resume from a
    // previously saved `mark` cursor. A stale persisted cursor made the first
    // fetch an append-only feed since that offset (get_logs_since) instead of
    // the latest logs, hiding older rows (e.g. ICMP) until Clear reset it.
    ctLastMark = null;
    try { removeState('ct-logs', 'mark'); } catch (e) { /* noop */ }

    // Restore column visibility
    const savedCols = loadState('ct-logs', 'columns', null);
    if (savedCols && ctColumns) {
        ctColumns.forEach((col, idx) => {
            if (savedCols[idx] !== undefined) { col.visible = savedCols[idx]; }
        });
    }

    // Init LogTable
    ctLogTable = new LogTable({
        tableId: 'dynamic-table-ct',
        columns: ctColumns,
        onRowClick: undefined,
        rowClass: log => ''
    });
    renderColumnControls();

    // Restore limit
    const savedLimit = loadState('ct-logs', 'limit', null);
    const limitInput = document.getElementById('ct-logs-limit');
    if (savedLimit !== null && limitInput) {
        limitInput.value = savedLimit;
    }
    if (limitInput) {
        limitInput.addEventListener('change', () => {
            saveState('ct-logs', 'limit', limitInput.value);
        });
    }

    // Wire query input
    const queryInput = document.getElementById('ct-logs-query');
    if (queryInput) {
        queryInput.value = ctCurrentQuery || '';
        queryInput.addEventListener('input', () => {
            ctCurrentQuery = queryInput.value;
            saveState('ct-logs', 'query', queryInput.value);
        });
    }

    // Wire Clear button: reset the query input, forget the saved query and
    // refetch all logs (as if Apply was pressed with an empty query).
    const clearBtn = document.querySelector('.fw-query-clear');
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            if (queryInput) queryInput.value = '';
            ctCurrentQuery = '';
            removeState('ct-logs', 'query');
            resetMark();
            try { ctLogTable.clearRows(); } catch (e) { /* noop */ }
            fetchCtLogs();
        });
    }

    // Wire Keys helper button
    const keysHelpBtn = document.querySelector('.js-ct-query-help');
    const keysDiv = document.getElementById('ct-query-keys');
    if (keysHelpBtn && keysDiv) {
        keysHelpBtn.addEventListener('click', () => {
            if (!keysDiv.hidden) {
                keysDiv.hidden = true;
                return;
            }
            keysDiv.innerHTML = CT_QUERY_KEYS.map(k =>
                '<button type="button" class="std-btn fwlog-key-chip" data-key="' + k + '">' + k + '</button>'
            ).join(' ');
            keysDiv.hidden = false;
            keysDiv.querySelectorAll('.fwlog-key-chip').forEach(chip => {
                chip.addEventListener('click', () => {
                    if (!queryInput) return;
                    const append = (queryInput.value.trim() ? ' AND ' : '') + chip.dataset.key + ' == ""';
                    queryInput.value += append;
                    const pos = queryInput.value.length - 1;
                    queryInput.focus();
                    queryInput.setSelectionRange(pos, pos);
                    ctCurrentQuery = queryInput.value;
                    saveState('ct-logs', 'query', queryInput.value);
                });
            });
        });
    }

    // Wire filters form submit
    const filterForm = document.getElementById('ct-logs-filters-form');
    if (filterForm) {
        filterForm.onsubmit = function(e) {
            e.preventDefault();
            resetMark();
            try { ctLogTable.clearRows(); } catch (e) { /* noop */ }
            fetchCtLogs();
        };
    }

    // Wire auto-refresh toggle
    const toggleBtn = document.getElementById('ct-logs-toggle-autorefresh');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            if (ctAutoRefreshPaused) {
                resumeAutoRefresh();
            } else {
                pauseAutoRefresh();
            }
        });
    }

    // Wire refresh interval change
    const intervalInput = document.getElementById('ct-logs-refresh-interval');
    if (intervalInput) {
        intervalInput.addEventListener('change', () => {
            saveState('ct-logs', 'refreshInterval', intervalInput.value);
            if (!ctAutoRefreshPaused) {
                startAutoRefresh();
            }
        });
    }

    // Initial fetch
    fetchCtLogs();
    startAutoRefresh();
}

document.addEventListener('DOMContentLoaded', setupCtLogs);
