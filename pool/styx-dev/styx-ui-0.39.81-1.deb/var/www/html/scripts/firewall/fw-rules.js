/**
 * Firewall rules presentation with IPv4/IPv6 tabs
 */

// Tables created on this page, so the "Filters" toggle can re-render them.
const _fwRuleTables = [];

/**
 * Whether the "Filters" toggle is active (system rules hidden). The checkbox
 * is seeded by the server from `bypass_filter` and synced with localStorage by
 * initSystemRulesFilter() before the tables are built.
 */
function isSystemRulesFilterActive() {
    const checkbox = document.querySelector('input.fw-filter-system-rules');
    return !!(checkbox && checkbox.checked);
}

/**
 * Initialize tabbed firewall rules table (forward)
 * @param {Object} config - { thead, data, controlsId, tableIdPrefix, rowLinkFn, endpoint, columnsConfig }
 */
function initForwardRulesTabs(config) {
    const { thead, data, controlsId, tableIdPrefix, rowLinkFn, endpoint, columnsConfig } = config;
    const hideSystemRules = isSystemRulesFilterActive();

    // Filter rules by family
    const ipv4Rules = data.filter(r => r.family === 'ip');
    const ipv6Rules = data.filter(r => r.family === 'ip6');

    // Create IPv4 table
    _fwRuleTables.push(createDraggableTable({
        thead: thead,
        data: ipv4Rules,
        controlsId: controlsId + '-ipv4',
        tableId: tableIdPrefix + '-ipv4',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix,
        hideSystemRules: hideSystemRules
    }));

    // Create IPv6 table
    _fwRuleTables.push(createDraggableTable({
        thead: thead,
        data: ipv6Rules,
        controlsId: controlsId + '-ipv6',
        tableId: tableIdPrefix + '-ipv6',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix,
        hideSystemRules: hideSystemRules
    }));

    // Initialize tab buttons for this context
    initTabButtons();

    // Always show IPv4 by default (tab selection is not persisted)
    showTab('ipv4', tableIdPrefix);
}

/**
 * Initialize tabbed firewall rules table (local: input/output)
 * @param {Object} config - { thead, inputData, outputData, controlsIdPrefix, tableIdPrefix, rowLinkFn, endpoint, columnsConfig }
 */
function initLocalRulesTabs(config) {
    const { thead, inputData, outputData, controlsIdPrefix, tableIdPrefix, rowLinkFn, endpoint, columnsConfig } = config;
    const hideSystemRules = isSystemRulesFilterActive();

    // Filter input rules by family
    const inputIpv4 = inputData.filter(r => r.family === 'ip');
    const inputIpv6 = inputData.filter(r => r.family === 'ip6');

    // Filter output rules by family
    const outputIpv4 = outputData.filter(r => r.family === 'ip');
    const outputIpv6 = outputData.filter(r => r.family === 'ip6');

    // Create IPv4 INPUT table
    _fwRuleTables.push(createDraggableTable({
        thead: thead,
        data: inputIpv4,
        controlsId: controlsIdPrefix + '-input-ipv4',
        tableId: tableIdPrefix + '-input-ipv4',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix + '-local',
        hideSystemRules: hideSystemRules
    }));

    // Create IPv6 INPUT table
    _fwRuleTables.push(createDraggableTable({
        thead: thead,
        data: inputIpv6,
        controlsId: controlsIdPrefix + '-input-ipv6',
        tableId: tableIdPrefix + '-input-ipv6',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix + '-local',
        hideSystemRules: hideSystemRules
    }));

    // Create IPv4 OUTPUT table
    _fwRuleTables.push(createDraggableTable({
        thead: thead,
        data: outputIpv4,
        controlsId: controlsIdPrefix + '-output-ipv4',
        tableId: tableIdPrefix + '-output-ipv4',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix + '-local',
        hideSystemRules: hideSystemRules
    }));

    // Create IPv6 OUTPUT table
    _fwRuleTables.push(createDraggableTable({
        thead: thead,
        data: outputIpv6,
        controlsId: controlsIdPrefix + '-output-ipv6',
        tableId: tableIdPrefix + '-output-ipv6',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix + '-local',
        hideSystemRules: hideSystemRules
    }));

    // Initialize tab buttons for this context
    initTabButtons();

    // Always show IPv4 by default for both input and output (tab selection is
    // not persisted)
    showTab('ipv4', 'fw-local');
}

/**
 * Show a specific tab and hide others
 * @param {string} family - 'ipv4' or 'ipv6'
 * @param {string} context - table context identifier
 */
function showTab(family, context) {
    // Hide all tabs for this context
    const allTabs = document.querySelectorAll(`[data-tab-context="${context}"]`);
    allTabs.forEach(tab => tab.style.display = 'none');

    // Show all selected tabs (can be multiple for the same family)
    const selectedTabs = document.querySelectorAll(`[data-tab-context="${context}"][data-tab-family="${family}"]`);
    selectedTabs.forEach(tab => tab.style.display = 'block');

    // Update tab buttons
    const allButtons = document.querySelectorAll(`[data-tab-btn-context="${context}"]`);
    allButtons.forEach(btn => btn.classList.remove('active'));

    const activeButton = document.querySelector(`[data-tab-btn-context="${context}"][data-tab-btn-family="${family}"]`);
    if (activeButton) {
        activeButton.classList.add('active');
    }
}

/**
 * Initialize tab button click handlers. The selected tab is intentionally not
 * persisted (the pages always open on IPv4); only the "Filters" toggle state
 * is saved to localStorage.
 */
function initTabButtons() {
    document.querySelectorAll('[data-tab-btn-context]').forEach(btn => {
        btn.addEventListener('click', function() {
            const context = this.getAttribute('data-tab-btn-context');
            const family = this.getAttribute('data-tab-btn-family');
            showTab(family, context);
        });
    });
}

/**
 * Initialize the "Filters" toggle that shows/hides the system rules
 * (conntrack-bypass, antilockout, drop-invalid, ipsec-peer, loopback-accept;
 * the end-of-chain rule is always kept visible).
 *
 * The server always sends every rule, so the toggle is purely client-side: it
 * re-renders the tables via `setHideSystemRules` and persists the preference
 * to localStorage (like the tab selection above). Runs early (end of body) so
 * the checkbox is set before the tables are built on DOMContentLoaded.
 */
function initSystemRulesFilter() {
    const checkbox = document.querySelector('input.fw-filter-system-rules');
    if (!checkbox) return;

    const initial = checkbox.checked ? 1 : 0; // seeded by the server (bypass_filter)
    const saved = loadState('fw-rules', 'bypassFilter', initial);

    // Restore the saved preference; localStorage wins over the server seed.
    checkbox.checked = saved === 1;

    checkbox.addEventListener('change', () => {
        const val = checkbox.checked ? 1 : 0;
        saveState('fw-rules', 'bypassFilter', val);
        _fwRuleTables.forEach(t => t && t.setHideSystemRules(val === 1));
    });
}

initSystemRulesFilter();

