// routing-bgp.js
// BGP configuration and neighbor management

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }

    // Read an optional BGP number field: empty/absent -> null (not emitted),
    // otherwise the parsed integer. Used for maximum_paths*, update_delay*.
    function readNullableInt(id) {
        const el = document.getElementById(id);
        if (!el) return null;
        const v = el.value.trim();
        if (v === '') return null;
        const n = parseInt(v, 10);
        return isNaN(n) ? null : n;
    }

    // Pre-validate the optional advanced settings, mirroring the gateway's
    // error strings so the user sees them before a round-trip.
    function validateBgpAdvanced(o) {
        if (o.maxPaths !== null && (o.maxPaths < 1 || o.maxPaths > 64)) {
            return "Invalid 'maximum_paths': must be between 1 and 64";
        }
        if (o.maxPathsIbgp !== null && (o.maxPathsIbgp < 1 || o.maxPathsIbgp > 64)) {
            return "Invalid 'maximum_paths_ibgp': must be between 1 and 64";
        }
        if (o.updateDelay !== null && (o.updateDelay < 0 || o.updateDelay > 3600)) {
            return "Invalid 'update_delay': must be between 0 and 3600";
        }
        if (o.updateDelayWait !== null && (o.updateDelayWait < 1 || o.updateDelayWait > 3600)) {
            return "Invalid 'update_delay_establish_wait': must be between 1 and 3600";
        }
        if (o.updateDelayWait !== null && o.updateDelay === null) {
            return "'update_delay' is required when 'update_delay_establish_wait' is set";
        }
        if (o.updateDelayWait !== null && o.updateDelay < o.updateDelayWait) {
            return "'update_delay' must be greater than or equal to 'update_delay_establish_wait'";
        }
        return null;
    }

    // Save BGP global config
    const saveConfigBtn = document.querySelector('[data-js="bgp-save-config"]');
    if (saveConfigBtn) {
        saveConfigBtn.addEventListener('click', async () => {
            // Collect redistribute entries
            const redistribute = [];
            document.querySelectorAll('.js-redist-proto:checked').forEach(cb => {
                const proto = cb.value;
                const rmEl = document.querySelector('.js-redist-route-map[data-proto="' + proto + '"]');
                const metricEl = document.querySelector('.js-redist-metric[data-proto="' + proto + '"]');
                const entry = { protocol: proto };
                if (rmEl && rmEl.value) {
                    entry.route_map = rmEl.value;
                }
                if (metricEl && metricEl.value.trim()) {
                    entry.metric = parseInt(metricEl.value, 10);
                }
                redistribute.push(entry);
            });

            // Optional advanced settings (Multipath/ECMP + Convergence).
            // Empty number inputs -> null (field not emitted -> FRR default).
            const maxPaths        = readNullableInt('bgp_maximum_paths');
            const maxPathsIbgp    = readNullableInt('bgp_maximum_paths_ibgp');
            const updateDelay     = readNullableInt('bgp_update_delay');
            const updateDelayWait = readNullableInt('bgp_update_delay_establish_wait');
            const nicEl           = document.getElementById('bgp_network_import_check');
            let networkImportCheck = null;
            if (nicEl) {
                if (nicEl.value === '1') networkImportCheck = true;
                else if (nicEl.value === '0') networkImportCheck = false;
            }

            const advancedErr = validateBgpAdvanced({ maxPaths, maxPathsIbgp, updateDelay, updateDelayWait });
            if (advancedErr) {
                showModal('<p>' + advancedErr + '</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }

            const data = {
                router_as:            document.getElementById('bgp_router_as').value.trim(),
                router_id:            document.getElementById('bgp_router_id').value.trim(),
                // Optional route-reflector cluster-id label, empty -> null (FRR uses router-id)
                cluster_id:           document.getElementById('bgp_cluster_id').value.trim() || null,
                enabled:              document.getElementById('bgp_enabled').checked,
                keepalive:            parseInt(document.getElementById('bgp_keepalive').value, 10) || 60,
                hold_time:            parseInt(document.getElementById('bgp_hold_time').value, 10) || 180,
                default_local_pref:   parseInt(document.getElementById('bgp_default_local_pref').value, 10) || 100,
                log_neighbor_changes: document.getElementById('bgp_log_neighbor_changes').checked,
                always_compare_med:   document.getElementById('bgp_always_compare_med').checked,
                graceful_restart:                   document.getElementById('bgp_graceful_restart').checked,
                ebgp_requires_policy:               document.getElementById('bgp_ebgp_requires_policy').checked,
                disable_ebgp_connected_route_check:  document.getElementById('bgp_disable_ebgp_connected_route_check').checked,
                deterministic_med:                  document.getElementById('bgp_deterministic_med').checked,
                show_hostname:                      document.getElementById('bgp_show_hostname').checked,
                maximum_paths:                    maxPaths,
                maximum_paths_ibgp:               maxPathsIbgp,
                multipath_relax:                  document.getElementById('bgp_multipath_relax').checked,
                update_delay:                     updateDelay,
                update_delay_establish_wait:      updateDelayWait,
                network_import_check:             networkImportCheck,
                redistribute: redistribute,
            };
            try {
                const result = await apiClient.submit('routing_save_bgp_config', data);
                showApiResult(result, { title: 'BGP Configuration', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Force BGP outbound resync: clear bgp <peer> soft out to every Established peer
    const resyncBtn = document.querySelector('[data-js="bgp-resync"]');
    if (resyncBtn) {
        resyncBtn.addEventListener('click', async () => {
            let result;
            try {
                result = await apiClient.submit('routing_bgp_resync', {});
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                return;
            }
            const ok = result && (result.status === 'success' || result.status === 'ok');
            const report = result && result.result && typeof result.result === 'object' ? result.result : null;
            if (!ok || !report) {
                showApiResult(result, { title: 'BGP Resync', closeText: 'Close' });
                return;
            }
            let msg;
            if (report.failed > 0) {
                msg = '⚠️ Failed on ' + report.failed + ' peer(s)';
            } else if (report.cleared > 0) {
                msg = '✅ Forced re-announcement to ' + report.cleared + ' peer(s)';
            } else if (report.skipped === 1) {
                msg = 'ℹ️ No established peer to resync';
            } else {
                msg = 'BGP resync executed';
            }
            showModal('<p>' + msg + '</p>', { title: 'BGP Resync', closeText: 'Close' });
        });
    }

    // Show/hide add neighbor form
    const addNeighborOpenBtn = document.querySelector('[data-js="bgp-add-neighbor-open"]');
    const addNeighborForm    = document.getElementById('bgp-add-neighbor-form');
    const addNeighborCancel  = document.querySelector('[data-js="bgp-add-neighbor-cancel"]');

    if (addNeighborOpenBtn && addNeighborForm) {
        addNeighborOpenBtn.addEventListener('click', () => {
            addNeighborForm.style.display = '';
            addNeighborOpenBtn.style.display = 'none';
            // Reset to add mode
            document.getElementById('bgp_neighbor_id').value = '';
            ['bgp_neighbor_update_source', 'bgp_neighbor_peer_group',
             'bgp_neighbor_route_map_in', 'bgp_neighbor_route_map_out',
             'bgp_neighbor_prefix_list_in', 'bgp_neighbor_prefix_list_out',
             'bgp_neighbor_bfd_profile'].forEach(id => {
                const el = document.getElementById(id); if (el) el.value = '';
            });
            resetNeighborPickers();
            const title = document.getElementById('bgp-neighbor-form-title');
            if (title) title.textContent = 'Add BGP Neighbor';
        });
    }
    if (addNeighborCancel && addNeighborForm) {
        addNeighborCancel.addEventListener('click', () => {
            addNeighborForm.style.display = 'none';
            if (addNeighborOpenBtn) addNeighborOpenBtn.style.display = '';
            // Reset to add mode
            document.getElementById('bgp_neighbor_id').value = '';
            ['bgp_neighbor_update_source', 'bgp_neighbor_peer_group',
             'bgp_neighbor_route_map_in', 'bgp_neighbor_route_map_out',
             'bgp_neighbor_prefix_list_in', 'bgp_neighbor_prefix_list_out',
             'bgp_neighbor_bfd_profile'].forEach(id => {
                const el = document.getElementById(id); if (el) el.value = '';
            });
            resetNeighborPickers();
            const title = document.getElementById('bgp-neighbor-form-title');
            if (title) title.textContent = 'Add BGP Neighbor';
        });
    }

    // Reset the set-picker labels + clear buttons in the neighbor form to their
    // placeholders (mirror resetSetPicker in routing-vrrp.js).
    function resetNeighborPickers() {
        document.querySelectorAll('#bgp-add-neighbor-form .set-picker-field').forEach(field => {
            const label = field.querySelector('.js-set-picker-label');
            const clearBtn = field.querySelector('.js-set-picker-clear');
            const trigger = field.querySelector('.js-set-picker-open');
            if (label && trigger) label.textContent = trigger.dataset.placeholder || '';
            if (clearBtn) clearBtn.classList.add('sets-hidden');
        });
    }

    // Add neighbor
    const saveNeighborBtn = document.querySelector('[data-js="bgp-neighbor-save"]');
    if (saveNeighborBtn) {
        saveNeighborBtn.addEventListener('click', async () => {
            const neighborId  = document.getElementById('bgp_neighbor_id').value.trim();
            const ipSet        = document.getElementById('bgp_neighbor_ip_set').value.trim();
            const remoteAs     = document.getElementById('bgp_neighbor_as').value.trim();
            const desc         = document.getElementById('bgp_neighbor_desc').value.trim();
            const password     = document.getElementById('bgp_neighbor_password').value;
            const multihop     = parseInt(document.getElementById('bgp_neighbor_ebgp_multihop').value, 10) || 0;
            const updateSrc    = document.getElementById('bgp_neighbor_update_source').value.trim();
            const keepalive    = document.getElementById('bgp_neighbor_keepalive').value.trim();
            const holdTime     = document.getElementById('bgp_neighbor_hold_time').value.trim();
            const nextHopSelf  = document.getElementById('bgp_neighbor_next_hop_self').checked;
            const softReconfig = document.getElementById('bgp_neighbor_soft_reconfig').checked;
            const rrClient     = document.getElementById('bgp_neighbor_rr_client').checked;
            const bfd          = document.getElementById('bgp_neighbor_bfd').checked;
            const bfdCpFailure  = document.getElementById('bgp_neighbor_bfd_cp_failure').checked;
            const bfdProfile    = document.getElementById('bgp_neighbor_bfd_profile').value.trim();
            const peerGroup     = document.getElementById('bgp_neighbor_peer_group').value.trim();
            const routeMapIn    = document.getElementById('bgp_neighbor_route_map_in').value.trim();
            const routeMapOut   = document.getElementById('bgp_neighbor_route_map_out').value.trim();
            const prefixListIn  = document.getElementById('bgp_neighbor_prefix_list_in').value.trim();
            const prefixListOut = document.getElementById('bgp_neighbor_prefix_list_out').value.trim();

            const addrFamilies = [];
            document.querySelectorAll('.js-address-family:checked').forEach(cb => {
                addrFamilies.push(cb.value);
            });

            if (!neighborId) {
                // Add mode-required fields
                if (!ipSet) {
                    showModal('<p>Select an address set for the neighbor IP.</p>',
                        { title: 'Validation', closeText: 'Close' });
                    return;
                }
                if (!remoteAs) {
                    showModal('<p>Remote AS label is required.</p>',
                        { title: 'Validation', closeText: 'Close' });
                    return;
                }
            }

            const data = {
                neighbor_ip_set:                     ipSet || undefined,
                remote_as:                           remoteAs || undefined,
                description:                         desc,
                password:                            password || null,
                ebgp_multihop:                       multihop,
                update_source:                       updateSrc || null,
                keepalive:                           keepalive ? parseInt(keepalive, 10) : null,
                hold_time:                           holdTime ? parseInt(holdTime, 10) : null,
                next_hop_self:                       nextHopSelf,
                soft_reconfiguration_inbound:        softReconfig,
                route_reflector_client:              rrClient,
                bfd,
                bfd_check_control_plane_failure:     bfdCpFailure,
                bfd_profile:                         bfdProfile || null,
                peer_group:                          peerGroup || null,
                route_map_in:                        routeMapIn || null,
                route_map_out:                       routeMapOut || null,
                prefix_list_in:                      prefixListIn || null,
                prefix_list_out:                     prefixListOut || null,
                address_families:                    addrFamilies,
            };

            if (neighborId) {
                data.id = neighborId;
                // Remove undefined keys for partial update
                Object.keys(data).forEach(k => {
                    if (data[k] === undefined) delete data[k];
                });
            }

            const command = neighborId ? 'routing_update_bgp_neighbor' : 'routing_add_bgp_neighbor';
            const title = neighborId ? 'Update BGP Neighbor' : 'Add BGP Neighbor';

            try {
                const result = await apiClient.submit(command, data);
                showApiResult(result, { title: title, closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Edit neighbor-populate form
    document.querySelectorAll('[data-js="bgp-edit-neighbor"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const form   = document.getElementById('bgp-add-neighbor-form');
            const title  = document.getElementById('bgp-neighbor-form-title');
            const openBtn = document.querySelector('[data-js="bgp-add-neighbor-open"]');

            // Set hidden id
            document.getElementById('bgp_neighbor_id').value = btn.dataset.id;

            // Populate text/number fields
            const setVal = (id, val) => {
                const el = document.getElementById(id);
                if (el) el.value = val;
            };
            setVal('bgp_neighbor_desc', btn.dataset.description);
            setVal('bgp_neighbor_ebgp_multihop', btn.dataset.ebgpMultihop);
            setVal('bgp_neighbor_update_source', btn.dataset.updateSource);
            setVal('bgp_neighbor_keepalive', btn.dataset.keepalive);
            setVal('bgp_neighbor_hold_time', btn.dataset.holdTime);
            setVal('bgp_neighbor_bfd_profile', btn.dataset.bfdProfile);
            setVal('bgp_neighbor_peer_group', btn.dataset.peerGroup);
            setVal('bgp_neighbor_route_map_in', btn.dataset.routeMapIn);
            setVal('bgp_neighbor_route_map_out', btn.dataset.routeMapOut);
            setVal('bgp_neighbor_prefix_list_in', btn.dataset.prefixListIn);
            setVal('bgp_neighbor_prefix_list_out', btn.dataset.prefixListOut);

            // Set checkboxes
            const setChk = (id, val) => {
                const el = document.getElementById(id);
                if (el) el.checked = (val === '1');
            };
            setChk('bgp_neighbor_next_hop_self', btn.dataset.nextHopSelf);
            setChk('bgp_neighbor_soft_reconfig', btn.dataset.softReconfig);
            setChk('bgp_neighbor_rr_client', btn.dataset.rrClient);
            setChk('bgp_neighbor_bfd', btn.dataset.bfd);
            setChk('bgp_neighbor_bfd_cp_failure', btn.dataset.bfdCpFailure);

            // Set address families
            const afs = (btn.dataset.addressFamilies || '').split(',').filter(Boolean);
            document.querySelectorAll('.js-address-family').forEach(cb => {
                cb.checked = afs.includes(cb.value);
            });

            // Set set-picker hidden inputs for ip_set and remote_as
            setVal('bgp_neighbor_ip_set', btn.dataset.ipSet);
            setVal('bgp_neighbor_as', btn.dataset.remoteAs);
            // Update picker labels + clear buttons from the table row so the
            // selection is reflected when editing (mirror populateSetPicker).
            const ipLabel = document.querySelector('#bgp-add-neighbor-form .set-picker-field[data-set-type="address"] .js-set-picker-label');
            const asLabel = document.querySelector('#bgp-add-neighbor-form .set-picker-field[data-set-type="as_number"] .js-set-picker-label');
            const row = btn.closest('tr');
            if (row) {
                const ipName = row.querySelector('td:nth-child(1) .set-ref .set-name');
                const asName = row.querySelector('td:nth-child(2) .set-ref .set-name');
                if (ipLabel && ipName) ipLabel.textContent = ipName.textContent;
                if (asLabel && asName) asLabel.textContent = asName.textContent;
            }
            const ipClear = form.querySelector('.set-picker-field[data-set-type="address"] .js-set-picker-clear');
            const asClear = form.querySelector('.set-picker-field[data-set-type="as_number"] .js-set-picker-clear');
            if (ipClear) ipClear.classList.toggle('sets-hidden', !btn.dataset.ipSet);
            if (asClear) asClear.classList.toggle('sets-hidden', !btn.dataset.remoteAs);

            // Show form, update title
            if (title) title.textContent = 'Edit BGP Neighbor';
            if (openBtn) openBtn.style.display = 'none';
            form.style.display = '';

            // Clear password (never returned by backend)
            setVal('bgp_neighbor_password', '');
        });
    });

    // Delete neighbor
    document.querySelectorAll('[data-js="bgp-delete-neighbor"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this BGP neighbor?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('routing_delete_bgp_neighbor', { id });
                        showApiResult(result, { title: 'Delete Neighbor', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });

    // Neighbor details: show the live FRR status (full real peer object)
    document.querySelectorAll('[data-js="bgp-neighbor-details"]').forEach(btn => {
        btn.addEventListener('click', () => {
            let status;
            try {
                status = JSON.parse(btn.dataset.detail || 'null');
            } catch (e) {
                status = null;
            }
            if (!status || typeof status !== 'object' || Array.isArray(status)) {
                showModal('<p>No runtime status available for this neighbor.</p>',
                    { title: 'BGP Neighbor Details', closeText: 'Close' });
                return;
            }
            const esc = (s) => String(s).replace(/[&<>"']/g,
                (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
            const rows = Object.entries(status)
                .map(([k, v]) => {
                    const val = (v === null || v === undefined) ? '-' :
                        (typeof v === 'object' ? JSON.stringify(v) : v);
                    return '<tr><td><strong>' + esc(k) + '</strong></td><td>' + esc(val) + '</td></tr>';
                })
                .join('');
            showModal('<table class="std-table"><tbody>' + rows + '</tbody></table>',
                { title: 'BGP Neighbor Details', closeText: 'Close' });
        });
    });

    // Show/hide add network form
    const addNetworkOpenBtn = document.querySelector('[data-js="bgp-add-network-open"]');
    const addNetworkForm    = document.getElementById('bgp-add-network-form');
    const addNetworkCancel  = document.querySelector('[data-js="bgp-add-network-cancel"]');

    if (addNetworkOpenBtn && addNetworkForm) {
        addNetworkOpenBtn.addEventListener('click', () => {
            addNetworkForm.style.display = '';
            addNetworkOpenBtn.style.display = 'none';
        });
    }
    if (addNetworkCancel && addNetworkForm) {
        addNetworkCancel.addEventListener('click', () => {
            addNetworkForm.style.display = 'none';
            if (addNetworkOpenBtn) addNetworkOpenBtn.style.display = '';
        });
    }

    // Add network
    const saveNetworkBtn = document.querySelector('[data-js="bgp-network-save"]');
    if (saveNetworkBtn) {
        saveNetworkBtn.addEventListener('click', async () => {
            const networkSet = document.getElementById('bgp_network_set').value.trim();

            if (!networkSet) {
                showModal('<p>Select an address set for the network prefix.</p>',
                    { title: 'Validation', closeText: 'Close' });
                return;
            }

            try {
                const result = await apiClient.submit('routing_add_bgp_network',
                    { network_set: networkSet });
                showApiResult(result, { title: 'Add BGP Network', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message },
                    { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Delete network
    document.querySelectorAll('[data-js="bgp-delete-network"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this BGP network?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('routing_delete_bgp_network', { id });
                        showApiResult(result, { title: 'Delete Network', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message },
                            { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });

    // Peer Groups: toggle form
    const addPgOpen  = document.querySelector('[data-js="bgp-add-peergroup-open"]');
    const addPgForm  = document.getElementById('bgp-add-peergroup-form');
    const addPgCancel = document.querySelector('[data-js="bgp-add-peergroup-cancel"]');

    if (addPgOpen && addPgForm) {
        addPgOpen.addEventListener('click', () => {
            resetPeerGroupForm();
            addPgForm.style.display = '';
            addPgOpen.style.display = 'none';
        });
    }
    if (addPgCancel && addPgForm) {
        addPgCancel.addEventListener('click', () => {
            addPgForm.style.display = 'none';
            if (addPgOpen) addPgOpen.style.display = '';
        });
    }

    function resetPeerGroupForm() {
        document.getElementById('bgp_peergroup_id').value = '';
        document.getElementById('bgp_pg_name').value = '';
        document.getElementById('bgp_pg_remote_as').value = '';
        document.getElementById('bgp_pg_desc').value = '';
        document.getElementById('bgp_pg_rm_in').selectedIndex = 0;
        document.getElementById('bgp_pg_rm_out').selectedIndex = 0;
        document.getElementById('bgp_pg_pl_in').selectedIndex = 0;
        document.getElementById('bgp_pg_pl_out').selectedIndex = 0;
        document.getElementById('bgp_pg_next_hop_self').checked = false;
        document.getElementById('bgp_pg_bfd').checked = false;
        const title = document.getElementById('bgp-peergroup-form-title');
        if (title) title.textContent = 'Add Peer Group';
    }

    // Peer Groups: edit
    document.querySelectorAll('.js-bgp-edit-peergroup').forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('bgp_peergroup_id').value = btn.dataset.id;
            document.getElementById('bgp_pg_name').value = btn.dataset.name;
            document.getElementById('bgp_pg_remote_as').value = btn.dataset.remoteAs;
            document.getElementById('bgp_pg_desc').value = btn.dataset.desc;
            document.getElementById('bgp_pg_rm_in').value = btn.dataset.rmIn;
            document.getElementById('bgp_pg_rm_out').value = btn.dataset.rmOut;
            document.getElementById('bgp_pg_pl_in').value = btn.dataset.plIn;
            document.getElementById('bgp_pg_pl_out').value = btn.dataset.plOut;
            document.getElementById('bgp_pg_next_hop_self').checked = (btn.dataset.nextHopSelf === '1');
            document.getElementById('bgp_pg_bfd').checked = (btn.dataset.bfd === '1');
            const title = document.getElementById('bgp-peergroup-form-title');
            if (title) title.textContent = 'Edit Peer Group';
            addPgForm.style.display = '';
            if (addPgOpen) addPgOpen.style.display = 'none';
        });
    });

    // Peer Groups: save (add or update)
    const savePgBtn = document.querySelector('[data-js="bgp-peergroup-save"]');
    if (savePgBtn) {
        savePgBtn.addEventListener('click', async () => {
            const id = document.getElementById('bgp_peergroup_id').value.trim();
            const name = document.getElementById('bgp_pg_name').value.trim();
            const remoteAs = document.getElementById('bgp_pg_remote_as').value.trim();
            if (!name) { showModal('<p>Name is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }
            if (!remoteAs) { showModal('<p>Remote AS is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }

            const data = {
                name: name,
                remote_as: remoteAs,
                description: document.getElementById('bgp_pg_desc').value.trim() || null,
                route_map_in: document.getElementById('bgp_pg_rm_in').value || null,
                route_map_out: document.getElementById('bgp_pg_rm_out').value || null,
                prefix_list_in: document.getElementById('bgp_pg_pl_in').value || null,
                prefix_list_out: document.getElementById('bgp_pg_pl_out').value || null,
                next_hop_self: document.getElementById('bgp_pg_next_hop_self').checked,
                bfd: document.getElementById('bgp_pg_bfd').checked,
            };
            const command = id ? 'routing_update_peer_group' : 'routing_add_peer_group';
            if (id) data.id = id;
            const title = id ? 'Update Peer Group' : 'Add Peer Group';

            try {
                const result = await apiClient.submit(command, data);
                showApiResult(result, { title: title, closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Peer Groups: delete
    document.querySelectorAll('[data-js="bgp-delete-peergroup"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this peer group?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('routing_delete_peer_group', { id });
                        showApiResult(result, { title: 'Delete Peer Group', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message },
                            { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });
});
