// routing-policies.js
// FRR Policies-toggle forms + add/edit submit + delete
// Full list data is embedded via window.__policiesData (routing-policies.tpl.php).
// Editing a list opens the form with ALL its entries as editable blocks.
// The backend update replaces the FULL entries list, so the form always
// serializes every block and sends the complete list.

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }

    const cmdMap = {
        prefix_list:    { add: 'routing_add_prefix_list',    upd: 'routing_update_prefix_list',    del: 'routing_delete_prefix_list' },
        route_map:      { add: 'routing_add_route_map',      upd: 'routing_update_route_map',      del: 'routing_delete_route_map' },
        as_path_list:   { add: 'routing_add_as_path_list',   upd: 'routing_update_as_path_list',   del: 'routing_delete_as_path_list' },
        community_list: { add: 'routing_add_community_list', upd: 'routing_update_community_list', del: 'routing_delete_community_list' },
    };

    // Embedded full data (list id -> list object with name/description/entries)
    function getListData(policy, id) {
        const all = window.__policiesData || {};
        const arr = all[policy] || [];
        return arr.find(l => String(l.id) === String(id)) || null;
    }

    // ---- Entry blocks (cloned from <template>, pickers re-initialized per block) ----

    function entriesContainer(form) {
        return form.querySelector('.js-entries-container');
    }

    function getBlockTemplate(form) {
        if (!form._blockTemplate) {
            form._blockTemplate = form.querySelector('.js-entry-block-template');
        }
        return form._blockTemplate;
    }

    function initBlockPickers(block) {
        if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
            window.setsModal.initPickerFields(block);
        }
        if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
            window.labelsMgmt.initPickerFields(block);
        }
    }

    function resetPickerField(field) {
        const hidden = field.querySelector('input[type="hidden"]');
        if (hidden) hidden.value = '';
        const openBtn = field.querySelector('.js-set-picker-open');
        const label = field.querySelector('.js-set-picker-label');
        if (label) {
            label.textContent = (openBtn && openBtn.dataset.placeholder) || 'None';
        }
        if (openBtn) openBtn.classList.remove('set-picker-trigger--has-value');
        const clearBtn = field.querySelector('.js-set-picker-clear');
        if (clearBtn) clearBtn.classList.add('sets-hidden');
    }

    function setPickerValue(block, sel, uuid, displayName) {
        const hidden = block.querySelector(sel);
        if (!hidden || uuid === undefined) return;
        hidden.value = uuid;
        const field = hidden.closest('.set-picker-field');
        if (!field) return;
        const label = field.querySelector('.js-set-picker-label');
        const openBtn = field.querySelector('.js-set-picker-open');
        const clearBtn = field.querySelector('.js-set-picker-clear');
        if (label) {
            label.textContent = displayName || 'None';
        }
        if (openBtn) {
            if (uuid) { openBtn.classList.add('set-picker-trigger--has-value'); }
            else { openBtn.classList.remove('set-picker-trigger--has-value'); }
        }
        if (clearBtn) {
            if (uuid) { clearBtn.classList.remove('sets-hidden'); }
            else { clearBtn.classList.add('sets-hidden'); }
        }
    }

    function resetBlock(block) {
        block.querySelectorAll('input[type="text"], input[type="number"]').forEach(el => {
            if (el.classList.contains('js-entry-seq')) el.value = '10';
            else el.value = '';
        });
        block.querySelectorAll('select').forEach(el => el.selectedIndex = 0);
        block.querySelectorAll('input[type="checkbox"]').forEach(el => el.checked = false);
        block.querySelectorAll('.set-picker-field').forEach(resetPickerField);
    }

    function populateBlock(block, policy, entry) {
        setVal(block, '.js-entry-seq', entry.seq ?? 10);
        setSel(block, '.js-entry-action', entry.action ?? 'permit');

        if (policy === 'prefix_list') {
            setVal(block, '.js-entry-prefix-set', entry.prefix_set || '');
            setPickerValue(block, '.js-entry-prefix-set', entry.prefix_set, (entry.prefix_set_display || {}).name || '');
            setVal(block, '.js-entry-ge', entry.ge ?? '');
            setVal(block, '.js-entry-le', entry.le ?? '');
        }

        if (policy === 'route_map') {
            const m = entry.match || {};
            const s = entry.set || {};
            setVal(block, '.js-entry-desc', entry.description || '');
            setSel(block, '.js-match-prefix-list', m.prefix_list || '');
            setSel(block, '.js-match-as-path-list', m.as_path_list || '');
            setSel(block, '.js-match-community-list', m.community_list || '');
            setChk(block, '.js-match-community-exact', m.community_exact_match);
            setVal(block, '.js-set-local-pref', s.local_preference ?? '');
            setVal(block, '.js-set-metric', s.metric ?? '');
            setVal(block, '.js-set-community', s.community || '');
            setPickerValue(block, '.js-set-community', s.community, (s.community_display || {}).name || '');
            setChk(block, '.js-set-community-additive', s.community_additive);
            setVal(block, '.js-set-ip-next-hop', s.ip_next_hop_set || '');
            setPickerValue(block, '.js-set-ip-next-hop', s.ip_next_hop_set, (s.ip_next_hop_set_display || {}).name || '');
            setSel(block, '.js-set-origin', s.origin || '');
            setVal(block, '.js-set-weight', s.weight ?? '');
            setVal(block, '.js-set-as-prepend', s.as_path_prepend || '');
            setPickerValue(block, '.js-set-as-prepend', s.as_path_prepend, (s.as_path_prepend_display || {}).name || '');
        }

        if (policy === 'as_path_list') {
            setVal(block, '.js-entry-regex', entry.regex || '');
            setPickerValue(block, '.js-entry-regex', entry.regex, (entry.regex_display || {}).name || '');
        }

        if (policy === 'community_list') {
            setVal(block, '.js-entry-community', entry.community || '');
            setPickerValue(block, '.js-entry-community', entry.community, (entry.community_display || {}).name || '');
        }
    }

    function addEntryBlock(form, policy, entry) {
        const tpl = getBlockTemplate(form);
        if (!tpl) return;
        const frag = tpl.content.cloneNode(true);
        const block = frag.querySelector('.js-entry-block');
        if (!block) return;
        if (entry) { populateBlock(block, policy, entry); }
        else { resetBlock(block); }
        entriesContainer(form).appendChild(block);
        initBlockPickers(block);
    }

    function clearEntries(form) {
        entriesContainer(form).innerHTML = '';
    }

    function renumberBlocks(form) {
        entriesContainer(form).querySelectorAll('.js-entry-block').forEach((block, i) => {
            const idx = block.querySelector('.js-entry-block-idx');
            if (idx) idx.textContent = String(i + 1);
        });
    }

    // ---- Open/close form (create mode) ----

    function resetFormToAdd(formContainer) {
        const form = formContainer.querySelector('[data-js="policy-add-form"]');
        if (!form) return;
        const idEl = form.querySelector('.js-policy-id');
        if (idEl) idEl.value = '';
        setVal(form, '.js-policy-name', '');
        setVal(form, '.js-policy-desc', '');
        const listTypeEl = form.querySelector('.js-list-type');
        if (listTypeEl) listTypeEl.selectedIndex = 0;
        clearEntries(form);
        addEntryBlock(form, form.dataset.policy, null);
        renumberBlocks(form);
        const titleEl = formContainer.querySelector('[id$="-form-title"]');
        const submitBtn = formContainer.querySelector('.js-policy-submit');
        if (titleEl) titleEl.textContent = 'Add ' + policyName(form.dataset.policy);
        if (submitBtn) submitBtn.textContent = 'Create';
    }

    document.querySelectorAll('[data-js="policies-toggle-form"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = document.getElementById(btn.dataset.target);
            if (!target) return;
            if (target.style.display === 'none') {
                // Opening via "+ Add" button (create new list)
                resetFormToAdd(target);
                target.style.display = 'block';
                btn.style.display = 'none';
            } else {
                // Closing via Cancel or toggling off
                resetFormToAdd(target);
                target.style.display = 'none';
                const addBtn = document.querySelector(
                    '[data-js="policies-toggle-form"][data-target="' + btn.dataset.target + '"]'
                );
                if (addBtn) addBtn.style.display = '';
            }
        });
    });

    // ---- Edit (whole list: all entries) ----

    document.querySelectorAll('[data-js="policy-edit"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const policy = btn.dataset.policy;
            const listId = btn.dataset.id;
            const target = document.getElementById(btn.dataset.target);
            if (!target) return;

            const form = target.querySelector('[data-js="policy-add-form"]');
            const list = getListData(policy, listId);
            if (!list) {
                showModal('<p>List data not found. Reload the page and try again.</p>', { title: 'Error', closeText: 'Close' });
                return;
            }

            const idEl = form.querySelector('.js-policy-id');
            if (idEl) idEl.value = list.id;

            setVal(form, '.js-policy-name', list.name || '');
            setVal(form, '.js-policy-desc', list.description || '');
            const listTypeEl = form.querySelector('.js-list-type');
            if (listTypeEl && list.list_type) setSel(form, '.js-list-type', list.list_type);

            clearEntries(form);
            const entries = (Array.isArray(list.entries) && list.entries.length) ? list.entries : [null];
            entries.forEach(e => addEntryBlock(form, policy, e));
            renumberBlocks(form);

            const titleEl = document.getElementById(btn.dataset.title);
            const submitBtn = document.getElementById(btn.dataset.submitBtn);
            if (titleEl) titleEl.textContent = 'Edit ' + policyName(policy);
            if (submitBtn) submitBtn.textContent = 'Save';

            target.style.display = 'block';
            const addBtn = document.querySelector('[data-js="policies-toggle-form"][data-target="' + btn.dataset.target + '"]');
            if (addBtn) addBtn.style.display = 'none';
        });
    });

    // ---- + Entry / Remove entry inside the form ----

    document.querySelectorAll('[data-js="policy-add-form"]').forEach(form => {
        const addEntryBtn = form.querySelector('[data-js="policy-entry-row-add"]');
        if (addEntryBtn) {
            addEntryBtn.addEventListener('click', () => {
                addEntryBlock(form, form.dataset.policy, null);
                renumberBlocks(form);
            });
        }

        entriesContainer(form).addEventListener('click', ev => {
            const rm = ev.target.closest('.js-entry-remove');
            if (!rm) return;
            const blocks = entriesContainer(form).querySelectorAll('.js-entry-block');
            if (blocks.length <= 1) {
                showModal('<p>A list must have at least one entry.</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }
            rm.closest('.js-entry-block').remove();
            renumberBlocks(form);
        });
    });

    // ---- Submit (create list | update whole list) ----

    document.querySelectorAll('[data-js="policy-add-form"]').forEach(form => {
        const submitBtn = form.querySelector('.js-policy-submit');
        if (!submitBtn) return;

        submitBtn.addEventListener('click', async () => {
            const policy = form.dataset.policy;
            const cmds = cmdMap[policy];
            if (!cmds) return;

            const idEl = form.querySelector('.js-policy-id');
            const id = idEl ? idEl.value.trim() : '';
            const isCreate = !id;

            const nameEl = form.querySelector('.js-policy-name');
            if (!nameEl || !nameEl.value.trim()) {
                showModal('<p>Name is required.</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }

            // Serialize every entry block (full list)
            const entries = [];
            const blocks = entriesContainer(form).querySelectorAll('.js-entry-block');
            for (const block of blocks) {
                const entry = buildEntryFromBlock(block, policy);
                if (entry === null) return; // validation message already shown
                entries.push(entry);
            }

            const data = { name: nameEl.value.trim() };
            const descEl = form.querySelector('.js-policy-desc');
            data.description = (descEl && descEl.value.trim()) ? descEl.value.trim() : null;
            if (!isCreate) data.id = id;
            const listTypeEl = form.querySelector('.js-list-type');
            if (listTypeEl) data.list_type = listTypeEl.value;
            data.entries = entries;

            const command = isCreate ? cmds.add : cmds.upd;
            const title = (isCreate ? 'Add ' : 'Update ') + policyName(policy);

            try {
                const result = await apiClient.submit(command, data);
                showApiResult(result, { title: title, closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message },
                    { title: 'Error', closeText: 'Close' });
            }
        });
    });

    // ---- Delete whole list ----

    document.querySelectorAll('[data-js="policies-delete"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const policy = btn.dataset.policy;
            const id = btn.dataset.id;
            const cmds = cmdMap[policy];
            if (!cmds) return;

            showModal('Delete this ' + policyName(policy).toLowerCase() + '?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit(cmds.del, { id });
                        showApiResult(result, {
                            title: 'Delete ' + policyName(policy),
                            closeText: 'Close',
                            reloadOnOk: true,
                        });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message },
                            { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });
});

// Helpers

function policyName(policy) {
    const names = {
        prefix_list: 'Prefix List', route_map: 'Route Map',
        as_path_list: 'AS Path List', community_list: 'Community List',
    };
    return names[policy] || policy;
}

// Build the wire-format entry from one block. Returns null (after showing
// a validation modal) when a required field is missing.
function buildEntryFromBlock(block, policy) {
    const entry = {};
    const seqEl = block.querySelector('.js-entry-seq');
    if (seqEl) entry.seq = parseInt(seqEl.value, 10) || 10;
    const actionEl = block.querySelector('.js-entry-action');
    if (actionEl) entry.action = actionEl.value;

    if (policy === 'prefix_list') {
        const pfSet = block.querySelector('.js-entry-prefix-set');
        if (!pfSet || !pfSet.value.trim()) {
            showModal('<p>A network address set is required in every entry.</p>',
                { title: 'Validation', closeText: 'Close' });
            return null;
        }
        entry.prefix_set = pfSet.value.trim();
        entry.ge = numOrNull(block, '.js-entry-ge');
        entry.le = numOrNull(block, '.js-entry-le');
    }

    if (policy === 'route_map') {
        const entryDesc = block.querySelector('.js-entry-desc');
        if (entryDesc && entryDesc.value.trim()) entry.description = entryDesc.value.trim();

        entry.match = {
            prefix_list:           selValOrNull(block, '.js-match-prefix-list'),
            as_path_list:          selValOrNull(block, '.js-match-as-path-list'),
            community_list:        selValOrNull(block, '.js-match-community-list'),
            community_exact_match: chkVal(block, '.js-match-community-exact'),
        };

        entry.set = {
            local_preference:    numOrNull(block, '.js-set-local-pref'),
            metric:              numOrNull(block, '.js-set-metric'),
            community:           txtOrNull(block, '.js-set-community'),
            community_additive:  chkVal(block, '.js-set-community-additive'),
            ip_next_hop_set:     txtOrNull(block, '.js-set-ip-next-hop'),
            origin:              selValOrNull(block, '.js-set-origin'),
            weight:              numOrNull(block, '.js-set-weight'),
            as_path_prepend:     txtOrNull(block, '.js-set-as-prepend'),
        };
    }

    if (policy === 'as_path_list') {
        const regex = block.querySelector('.js-entry-regex');
        if (!regex || !regex.value.trim()) {
            showModal('<p>Regex is required in every entry.</p>', { title: 'Validation', closeText: 'Close' });
            return null;
        }
        entry.regex = regex.value.trim();
    }

    if (policy === 'community_list') {
        const comm = block.querySelector('.js-entry-community');
        if (!comm || !comm.value.trim()) {
            showModal('<p>Community value is required in every entry.</p>', { title: 'Validation', closeText: 'Close' });
            return null;
        }
        entry.community = comm.value.trim();
    }

    return entry;
}

function setVal(root, sel, val) {
    const el = root.querySelector(sel);
    if (el && val !== undefined) el.value = val;
}
function setSel(root, sel, val) {
    const el = root.querySelector(sel);
    if (el && val !== undefined) el.value = val;
}
function setChk(root, sel, val) {
    const el = root.querySelector(sel);
    if (el) el.checked = (val === '1' || val === true);
}
function numOrNull(root, sel) {
    const el = root.querySelector(sel);
    if (el && el.value.trim()) return parseInt(el.value, 10);
    return null;
}
function txtOrNull(root, sel) {
    const el = root.querySelector(sel);
    if (el && el.value.trim()) return el.value.trim();
    return null;
}
function selValOrNull(root, sel) {
    const el = root.querySelector(sel);
    if (el && el.value) return el.value;
    return null;
}
function chkVal(root, sel) {
    const el = root.querySelector(sel);
    return el ? el.checked : false;
}
