function truncateMiddle(val, max) {
    if (!val || val.length <= max) return val || '';
    const half = Math.floor((max - 1) / 2);
    return val.slice(0, half) + '...' + val.slice(-half);
}

export function getSystemOverview(cmd) {
    if (cmd.status === 'success' && cmd.method === 'system-overview.get_system_info' && cmd.result) {
        appLog('System Overview:', cmd);
        if (cmd.result.hostname !== undefined) {
            const el = document.getElementById('sysinfo-hostname');
            if (el) el.textContent = cmd.result.hostname;
        }
        if (cmd.result.hostname_domain !== undefined) {
            const el = document.getElementById('sysinfo-domain');
            if (el) el.textContent = cmd.result.hostname_domain;
        }
        if (cmd.result.language !== undefined) {
            const el = document.getElementById('sysinfo-language');
            if (el) el.textContent = cmd.result.language;
        }
        if (cmd.result.timezone !== undefined) {
            const el = document.getElementById('sysinfo-timezone');
            if (el) el.textContent = cmd.result.timezone;
        }
        if (cmd.result.system_status !== undefined) {
            const el = document.getElementById('sysinfo-status');
            if (el) el.textContent = cmd.result.system_status;
        }
        if (cmd.result.app_version !== undefined) {
            const el = document.getElementById('sysinfo-version');
            if (el) el.textContent = cmd.result.app_version;
        }
        if (cmd.result.update_status !== undefined) {
            const el = document.getElementById('sysinfo-update');
            if (el) {
                el.textContent = cmd.result.update_status;
                el.closest('.std-flex-row')?.classList.toggle('sysinfo-update-alert', /security/i.test(cmd.result.update_status));
            }
        }
        if (cmd.result.system_uptime !== undefined) {
            const el = document.getElementById('sysinfo-uptime');
            if (el) {
                let uptime = cmd.result.system_uptime;
                let days = Math.floor(uptime / 86400);
                let hours = Math.floor((uptime % 86400) / 3600);
                let minutes = Math.floor((uptime % 3600) / 60);
                let seconds = Math.floor(uptime % 60);
                let formatted = days + "d " + hours + "h " + minutes + "m " + seconds + "s";
                el.textContent = formatted;
            }
        }
        if (cmd.result.styx_uptime !== undefined) {
            const el = document.getElementById('sysinfo-styx-uptime');
            if (el) {
                let uptime = cmd.result.styx_uptime;
                let days = Math.floor(uptime / 86400);
                let hours = Math.floor((uptime % 86400) / 3600);
                let minutes = Math.floor((uptime % 3600) / 60);
                let seconds = Math.floor(uptime % 60);
                let formatted = days + "d " + hours + "h " + minutes + "m " + seconds + "s";
                el.textContent = formatted;
            }
        }
        if (cmd.result.cpus !== undefined) {
            const el = document.getElementById('sysinfo-cpus');
            if (el) el.textContent = cmd.result.cpus + ' cores (' + (cmd.result.arch || '') + ')';
        }
        if (cmd.result.smart_disks !== undefined) {
            const el = document.getElementById('sysinfo-disks');
            if (el) {
                const disks = Array.isArray(cmd.result.smart_disks) ? cmd.result.smart_disks : [];
                el.innerHTML = disks.map(function (d) {
                    const dev = (d.device || '').replace(/^\/dev\//, '');
                    const status = d.status || 'unknown';
                    const cls = status === 'passed' ? 'ok' : (status === 'failed' ? 'failed' : 'unknown');
                    const temp = (typeof d.temperature === 'number') ? ' ' + d.temperature + '°C' : '';
                    const title = d.model ? ' title="' + d.model + '"' : '';
                    return '<span class="disk-state disk-' + cls + '"' + title + '>' + dev + ' ' + status + temp + '</span>';
                }).join('');
            }
        }
        if (cmd.result.kernel !== undefined) {
            const el = document.getElementById('sysinfo-kernel');
            if (el) el.textContent = cmd.result.kernel;
        }
        if (cmd.result.os_name !== undefined) {
            const el = document.getElementById('sysinfo-os-name');
            if (el) el.textContent = (cmd.result.os_name + ' ' + (cmd.result.os_version || '')).trim();
        }
        if (cmd.result.system_uuid !== undefined) {
            const el = document.getElementById('sysinfo-system-uuid');
            if (el) { el.textContent = truncateMiddle(cmd.result.system_uuid, 23); el.title = cmd.result.system_uuid; }
        }
        if (cmd.result.machine_id !== undefined) {
            const el = document.getElementById('sysinfo-machine-id');
            if (el) { el.textContent = truncateMiddle(cmd.result.machine_id, 23); el.title = cmd.result.machine_id; }
        }
    }
}

// Click-to-copy for UUID / Machine ID fields (copies full value from title)
document.addEventListener('click', function (e) {
    const el = e.target.closest('.uuid-val');
    if (!el) return;
    const val = el.title.trim();
    if (!val || val === 'Copied!') return;
    navigator.clipboard.writeText(val).then(() => {
        el.title = 'Copied!';
        setTimeout(() => { el.title = val; }, 1200);
    }).catch(() => { /* clipboard denied, ignore */ });
});
