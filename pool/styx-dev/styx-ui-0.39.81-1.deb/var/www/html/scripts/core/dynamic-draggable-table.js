function createDraggableTable({
    thead,
    data,
    controlsId,
    tableId,
    rowLink,
    endpoint = '/request.php',
    idField = 'id',
    handlerField = 'handler',
    onMoveResponse,
    cellHtml = false,
    stripedRows = false,
    columnsConfig = null, // Optional: visible columns configuration
    stateKey = null, // Optional: localStorage key for persisting column visibility
    hideSystemRules = false // Optional: hide system rule rows (except end-of-chain)
}) {
    // Tracked so the "Filters" toggle can re-render with a new value.
    let _hideSystemRules = hideSystemRules;
    // Merge server columnsConfig with saved localStorage state (saved state wins)
    const savedColState = stateKey ? loadState('fw-table-cols', stateKey, null) : null;
    let columns = Object.keys(thead).map(key => {
        let visible = true;
        if (columnsConfig && columnsConfig[key] !== undefined) { visible = columnsConfig[key]; }
        if (savedColState && savedColState[key] !== undefined) { visible = savedColState[key]; }
        return { key, label: thead[key], visible };
    });

    function _saveColState() {
        if (!stateKey) return;
        const state = {};
        columns.forEach(col => { state[col.key] = col.visible; });
        saveState('fw-table-cols', stateKey, state);
    }

    // Helper: find row index by handler
    function findRowIdxByHandler(handler) {
        return data.findIndex(r => r.handler === handler);
    }

    // Helper: send move request
    function sendMoveRequest(id, ref_id, position, cb) {
        const payload = { id };
        if (ref_id != null) {
            payload.ref_id = ref_id;
            payload.position = position;
        }
        apiClient.submit('move_rule', payload)
        .then(resp => {
            appLog('Move response:', resp);
            if (typeof onMoveResponse === 'function') onMoveResponse(resp);
            cb(resp);
        })
        .catch(e => alert('Error moving element: ' + e));
    }

    function renderControls() {
        const controls = document.getElementById(controlsId);
        controls.innerHTML = '';
        const dragContainer = document.createElement('div');
        dragContainer.classList.add('std-drag-container');

        columns.forEach((col, idx) => {
            const wrapper = document.createElement('div');
            wrapper.classList.add('std-drag-wrapper');
            wrapper.draggable = true;
            wrapper.dataset.idx = idx;

            wrapper.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('text/plain', idx);
                wrapper.classList.add('dragging');
            });
            wrapper.addEventListener('dragend', (e) => {
                wrapper.classList.remove('dragging');
            });
            wrapper.addEventListener('dragover', (e) => {
                e.preventDefault();
                wrapper.classList.add('drag-over');
            });
            wrapper.addEventListener('dragleave', (e) => {
                wrapper.classList.remove('drag-over');
            });
            wrapper.addEventListener('drop', (e) => {
                e.preventDefault();
                wrapper.classList.remove('drag-over');
                const fromIdx = parseInt(e.dataTransfer.getData('text/plain'));
                const toIdx = parseInt(wrapper.dataset.idx);
                if (fromIdx !== toIdx) {
                    const moved = columns.splice(fromIdx, 1)[0];
                    columns.splice(toIdx, 0, moved);
                    renderControls();
                    renderTable();
                }
            });

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.checked = col.visible;
            checkbox.onchange = () => {
                col.visible = checkbox.checked;
                _saveColState();
                renderTable();
            };
            wrapper.appendChild(checkbox);

            const label = document.createElement('label');
            label.textContent = col.label;
            label.classList.add('std-drag-label');
            wrapper.appendChild(label);

            dragContainer.appendChild(wrapper);
        });
        controls.appendChild(dragContainer);
    }

    function renderTable() {
        const table = document.getElementById(tableId);
        table.innerHTML = '';
        const theadEl = document.createElement('thead');
        const trHead = document.createElement('tr');
        const visibleCols = columns.map((col, idx) => ({...col, absIdx: idx}));

        visibleCols.forEach((col, visIdx) => {
            const th = document.createElement('th');
            th.textContent = col.label;
            th.draggable = true;
            th.classList.add('std-drag-grab');
            th.dataset.visIdx = visIdx;
            th.style.display = col.visible ? '' : 'none';

            th.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('vis-idx', visIdx);
                th.classList.add('dragging');
            });
            th.addEventListener('dragend', (e) => {
                th.classList.remove('dragging');
            });
            th.addEventListener('dragover', (e) => {
                e.preventDefault();
                th.classList.add('th-drag-over');
            });
            th.addEventListener('dragleave', (e) => {
                th.classList.remove('th-drag-over');
            });
            th.addEventListener('drop', (e) => {
                e.preventDefault();
                th.classList.remove('th-drag-over');
                const fromVisIdx = parseInt(e.dataTransfer.getData('vis-idx'));
                const toVisIdx = visIdx;
                if (fromVisIdx === toVisIdx) return;
                const fromAbsIdx = visibleCols[fromVisIdx].absIdx;
                const toAbsIdx = visibleCols[toVisIdx].absIdx;
                const moved = columns.splice(fromAbsIdx, 1)[0];
                columns.splice(toAbsIdx, 0, moved);
                renderControls();
                renderTable();
            });

            trHead.appendChild(th);
        });
        theadEl.appendChild(trHead);
        table.appendChild(theadEl);

        const tbodyEl = document.createElement('tbody');
        // Track the count of rendered (visible) rows so zebra striping stays
        // correct when system rules are hidden by the "Filters" toggle.
        let visibleIdx = 0;
        data.forEach((row, rowIdx) => {
            const tr = document.createElement('tr');
            // System rules (antilockout, drop-invalid, conntrack-bypass,
            // loopback-accept, end-of-chain) preserve the firewall's security
            // posture and cannot be moved, make them non-draggable. When the
            // "Filters" toggle is active they are also hidden (display:none).
            // The end-of-chain rule is deliberately excluded from hiding: it is
            // the chain's default-drop marker and was always visible under the
            // old server-side filter.
            const isSystemRow = !!(row.system_rule && !row.end_of_chain);
            const hidden = _hideSystemRules && isSystemRow;
            tr.draggable = !row.system_rule;
            tr.dataset.handler = row[handlerField];
            tr.dataset.rowIdx = rowIdx;
            if (stripedRows) {
                tr.classList.add(visibleIdx % 2 === 0 ? 'std-table-row-even' : 'std-table-row-odd');
            }
            if (hidden) {
                tr.style.display = 'none';
            } else {
                visibleIdx++;
            }

            visibleCols.forEach(col => {
                const td = document.createElement('td');
                let value = row[col.key];
                if (cellHtml && (typeof value === 'string' && (value.includes('<br>') || value.includes('<span')))) {
                    td.innerHTML = value;
                } else if (Array.isArray(value)) {
                    td.innerHTML = value.map(v => escapeHtml(v)).join('<br>');
                } else {
                    td.textContent = value;
                }
                td.style.display = col.visible ? '' : 'none';
                tr.appendChild(td);
            });

            tr.addEventListener('dragstart', function(e) {
                e.dataTransfer.setData('drag-row-idx', rowIdx);
                tr.classList.add('dragging');
            });
            tr.addEventListener('dragend', function(e) {
                tr.classList.remove('dragging');
            });
            tr.addEventListener('dragover', function(e) {
                e.preventDefault();
                // Visual feedback: upper/lower half
                const rect = tr.getBoundingClientRect();
                const offset = e.clientY - rect.top;
                if (offset < rect.height / 2) {
                    tr.classList.add('insert-before');
                    tr.classList.remove('insert-after');
                } else {
                    tr.classList.remove('insert-before');
                    tr.classList.add('insert-after');
                }
            });
            tr.addEventListener('dragleave', function(e) {
                tr.classList.remove('insert-before');
                tr.classList.remove('insert-after');
            });
            tr.addEventListener('drop', function(e) {
                e.preventDefault();
                tr.classList.remove('insert-before');
                tr.classList.remove('insert-after');
                const fromIdx = parseInt(e.dataTransfer.getData('drag-row-idx'));
                const toIdx = rowIdx;
                if (fromIdx === toIdx) return;
                const rect = tr.getBoundingClientRect();
                const offset = e.clientY - rect.top;
                let position, insertIdx;
                if (offset < rect.height / 2) {
                    position = 'before';
                    insertIdx = toIdx;
                } else {
                    position = 'after';
                    insertIdx = toIdx + 1;
                }
                const movedRow = data[fromIdx];
                const refRow = data[toIdx];

                // Backend contract (move_firewall_rule): a rule cannot be moved
                // relative to a system rule (before or after). The only exception
                // is the end-of-chain rule, which is a valid anchor for "before"
                // (moves the rule to the bottom of the chain); "after" it remains
                // rejected. Block these in the UI so invalid moves are never sent.
                if (movedRow.system_rule) {
                    showApiResult({
                        status: 'error', response_msg: 'System rules cannot be moved.' }, { title: 'Error', closeText: 'Close'
                        });
                    return;
                }
                if (refRow.system_rule && !refRow.end_of_chain) {
                    showApiResult({
                        status: 'error', response_msg: 'Cannot move a rule relative to a system rule.' }, { title: 'Error', closeText: 'Close'

                        });
                    return;
                }
                if (refRow.end_of_chain && position === 'after') {
                    showApiResult({
                        status: 'error', response_msg: 'Cannot move a rule after the end-of-chain rule.' }, { title: 'Error', closeText: 'Close'
                        });
                    return;
                }

                sendMoveRequest(movedRow[idField] || movedRow[handlerField], refRow[idField], position, function(resp) {
                    if (resp && resp.status === 'success') {
                        data.splice(fromIdx, 1);
                        if (fromIdx < insertIdx) insertIdx--;
                        data.splice(insertIdx, 0, movedRow);
                        renderTable();
                    } else {
                        showApiResult(resp || { status: 'error', response_msg: 'Could not move the element.' }, { title: 'Error', closeText: 'Close' });
                    }
                });
            });

            if (typeof rowLink === 'function') {
                tr.addEventListener('click', function(e) {
                    if (e.target.tagName === 'TD' && !e.defaultPrevented) {
                        const url = rowLink(row);
                        if (url) window.location.href = url;
                    }
                });
                tr.addEventListener('mouseover', function() {
                    tr.style.cursor = 'pointer';
                });
                tr.addEventListener('mouseout', function() {
                    tr.style.cursor = '';
                });
            }
            tbodyEl.appendChild(tr);
        });
        table.appendChild(tbodyEl);
    }

    renderControls();
    renderTable();

    // Controller so callers can re-render with a new system-rules visibility
    // (used by the firewall "Filters" toggle) without rebuilding the table.
    return {
        setHideSystemRules(hide) {
            _hideSystemRules = !!hide;
            renderTable();
        }
    };
}

// Helper to escape HTML
function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, function(m) {
        return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'})[m];
    });
}

// Alias for compatibility
const createDynamicRulesTable = createDraggableTable;