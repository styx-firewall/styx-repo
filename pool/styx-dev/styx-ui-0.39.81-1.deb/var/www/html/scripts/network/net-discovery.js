/**
 * Network Discovery page JS
 * Handles tabs, actions (sweep, traceroute, pause/resume), host filtering
 * and host detail modals. Data is rendered server-side; page reload for refresh.
 *
 * Depends on: api-client.js (global `apiClient`), common.js (showModal/hideModal)
 */
(function () {
    'use strict';

    /* Helpers                                                              */

    function escHtml(str) {
        if (typeof str !== 'string') return String(str ?? '');
        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function qjs(attr) { return document.querySelector('[data-js="' + attr + '"]'); }

    /* Tabs                                                                 */

    function initTabs() {
        document.querySelectorAll('.std-tab-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                document.querySelectorAll('.std-tab-btn').forEach(function (b) {
                    b.classList.remove('active');
                });
                this.classList.add('active');
                var tab = this.getAttribute('data-tab');
                document.querySelectorAll('.std-tab-panel').forEach(function (panel) {
                    panel.style.display = (panel.getAttribute('data-tab') === tab) ? 'block' : 'none';
                });
            });
        });
    }

    /* Host filter                                                          */

    function applyHostFilter() {
        var input = document.getElementById('disc-host-filter');
        var filter = input ? input.value.toLowerCase() : '';
        document.querySelectorAll('.disc-hosts-table .disc-host-row').forEach(function (row) {
            var text = row.textContent.toLowerCase();
            row.style.display = (!filter || text.indexOf(filter) !== -1) ? '' : 'none';
        });
    }

    function initHostFilter() {
        var input = document.getElementById('disc-host-filter');
        if (!input) return;
        input.addEventListener('input', applyHostFilter);
    }

    /* Click on tree/table node > show host modal                          */

    var SOURCE_LABELS = {
        'arp_reply':        'ARP Reply',
        'arp_table_kernel': 'ARP Table (kernel)',
        'arp_sweep':        'ARP Sweep',
        'ipv6_neighbor':    'IPv6 Neighbor',
        'cdp':              'CDP',
        'lldp':             'LLDP',
        'traceroute_hop':   'Traceroute Hop',
        'dhcp_lease':       'DHCP Lease',
        'conntrack':        'Conntrack',
        'mdns':             'mDNS',
        'unknown':          'Unknown',
    };

    function initNodeClick() {
        document.addEventListener('click', function (e) {
            var node = e.target.closest('[data-ip]');
            if (!node) return;
            var ip = node.getAttribute('data-ip');
            if (!ip) return;
            showHostModal(ip);
        });
    }

    function showHostModal(ip) {
        apiClient.request('discovery_get_host', { ip: ip }).then(function (resp) {
            var host = (resp.result || {}).host;
            if (!host) {
                showModal(
                    '<p class="disc-modal-subtitle">This IP is a transit hop or external host'
                    + '-not in the local discovery database.</p>',
                    { title: 'Host: ' + escHtml(ip) }
                );
                return;
            }

            var title = 'Host: ' + escHtml(ip);
            var subtitle = [];
            if (host.vendor) subtitle.push(escHtml(host.vendor));
            if (host.os_guess) subtitle.push(escHtml(host.os_guess));
            if (host.hostname) subtitle.push(escHtml(host.hostname));

            var html = '';
            if (subtitle.length > 0) {
                html += '<p class="disc-modal-subtitle">' + subtitle.join(' · ') + '</p>';
            }

            // Badges
            var badges = [];
            if (host.l2_confirmed) badges.push('<span class="disc-badge disc-badge-l2">L2</span>');
            if (host.source) badges.push('<span class="disc-badge disc-badge-src">'
                + escHtml(SOURCE_LABELS[host.source] || host.source) + '</span>');
            if (host.hypervisor_vendor) badges.push('<span class="disc-badge disc-badge-vm">'
                + escHtml(host.hypervisor_vendor) + '</span>');
            if (host.mdns_model) badges.push('<span class="disc-badge disc-badge-mdns-model">'
                + escHtml(host.mdns_model) + '</span>');
            // Roles as individual badges
            (host.roles || []).forEach(function (role) {
                badges.push('<span class="std-badge std-badge--std">' + escHtml(role) + '</span>');
            });
            if (badges.length > 0) {
                html += '<p class="disc-modal-badges">' + badges.join(' ') + '</p>';
            }

            // Core table
            var rows = [
                ['IP',           escHtml(host.ip)],
                ['MAC',          host.mac && host.mac !== '00:00:00:00:00:00' ? escHtml(host.mac) : '-'],
                ['Interface',    host.iface || '-'],
                ['TTL',          host.ttl != null ? host.ttl : '-'],
                ['Hops',         host.hops != null ? host.hops : '-'],
                ['mDNS Hostname', host.mdns_hostname ? escHtml(host.mdns_hostname) : '-'],
                ['First Seen',   window.dateUtils ? window.dateUtils.formatString(host.first_seen) : (host.first_seen || '-')],
                ['Last Seen',    window.dateUtils ? window.dateUtils.formatString(host.last_seen) : (host.last_seen || '-')],
            ];
            html += '<table class="std-table disc-modal-table">';
            rows.forEach(function (r) {
                html += '<tr><th>' + r[0] + '</th><td>' + r[1] + '</td></tr>';
            });
            html += '</table>';

            // Services (mDNS + future port scan)
            var services = host.services || [];
            if (services.length > 0) {
                html += '<h4 class="disc-modal-h4">Services (' + services.length + ')</h4>';
                html += '<table class="std-table disc-modal-table">';
                html += '<thead><tr><th>Port</th><th>Proto</th><th>Type</th><th>Source</th><th>Target</th></tr></thead>';
                html += '<tbody>';
                services.forEach(function (svc) {
                    var typeDisplay = svc.type || (svc.mdns_type ? escHtml(svc.mdns_type) : '-');
                    var targetDisplay = svc.mdns_target ? escHtml(svc.mdns_target) : '-';
                    html += '<tr>' +
                        '<td>' + escHtml(String(svc.port)) + '</td>' +
                        '<td>' + escHtml(svc.proto || '') + '</td>' +
                        '<td>' + escHtml(typeDisplay) + '</td>' +
                        '<td>' + escHtml(svc.source || '') + '</td>' +
                        '<td>' + targetDisplay + '</td>' +
                        '</tr>';
                });
                html += '</tbody></table>';
            }

            // Traceroute
            var tr = host.traceroute || [];
            if (tr.length > 0) {
                html += '<h4 class="disc-modal-h4">Traceroute (' + tr.length + ' hops)</h4>';
                html += '<ol class="disc-modal-hoplist">';
                tr.forEach(function (hop) {
                    html += '<li><code>' + escHtml(hop) + '</code></li>';
                });
                html += '</ol>';
            }

            // CDP / LLDP
            var cdp = host.cdp_info;
            var lldp = host.lldp_info;
            if (cdp || lldp) {
                html += '<h4 class="disc-modal-h4">Discovery Protocols</h4>';
                if (cdp) {
                    html += '<table class="std-table disc-modal-table"><caption>CDP</caption>';
                    Object.keys(cdp).forEach(function (k) {
                        html += '<tr><th>' + escHtml(k) + '</th><td>' + escHtml(String(cdp[k] ?? '-')) + '</td></tr>';
                    });
                    html += '</table>';
                }
                if (lldp) {
                    html += '<table class="std-table disc-modal-table"><caption>LLDP</caption>';
                    Object.keys(lldp).forEach(function (k) {
                        html += '<tr><th>' + escHtml(k) + '</th><td>' + escHtml(String(lldp[k] ?? '-')) + '</td></tr>';
                    });
                    html += '</table>';
                }
            }

            showModal(html, { title: title });
        }).catch(function () {
            showModal(
                '<p class="disc-modal-subtitle">Could not load host details. Please try again.</p>',
                { title: 'Host: ' + escHtml(ip) }
            );
        });
    }

    /* Actions                                                              */

    function apiErrorMsg(resp) {
        var code = resp.error_code ? '[' + resp.error_code + '] ' : '';
        var msg = (resp.result && (resp.result.response_msg || resp.result.msg)) || 'unknown error';
        return code + msg;
    }

    function execAction(btnEl, action, payload, label, reloadOnSuccess) {
        btnEl.disabled = true;
        apiClient.submit(action, payload).then(function (resp) {
            btnEl.disabled = false;
            if (resp.status === 'success') {
                var msg = (resp.result && resp.result.msg) || label + ' done';
                var opts = reloadOnSuccess ? { onClose: function () { window.location.reload(); } } : {};
                showModal('<p>' + escHtml(msg) + '</p>', opts);
            } else {
                showModal('<p>' + label + ' failed: ' + escHtml(apiErrorMsg(resp)) + '</p>');
            }
        }).catch(function () {
            btnEl.disabled = false;
            showModal('<p>Network error. ' + label + ' request failed.</p>');
        });
    }

    function initActions() {
        var btnSweep      = qjs('disc-btn-sweep');
        var btnTraceroute = qjs('disc-btn-traceroute');
        var btnPing       = qjs('disc-btn-ping');
        var btnPrune      = qjs('disc-btn-prune');

        if (btnPing) {
            btnPing.addEventListener('click', function () {
                execAction(btnPing, 'discovery_ping_now', {}, 'Ping', true);
            });
        }

        if (btnSweep) {
            btnSweep.addEventListener('click', function () {
                execAction(btnSweep, 'discovery_sweep_now', {}, 'Sweep', true);
            });
        }

        if (btnTraceroute) {
            btnTraceroute.addEventListener('click', function () {
                execAction(btnTraceroute, 'discovery_traceroute_all', {}, 'Traceroute', true);
            });
        }

        if (btnPrune) {
            btnPrune.addEventListener('click', function () {
                var daysInput = document.getElementById('disc-prune-days');
                var days = daysInput ? parseInt(daysInput.value, 10) : 7;
                if (isNaN(days) || days < 1) days = 7;
                if (days > 365) days = 365;
                if (!confirm('Prune hosts not seen in ' + days + ' day' + (days > 1 ? 's' : '') + '? This cannot be undone.')) return;
                execAction(btnPrune, 'discovery_prune_hosts', { minutes: days * 24 * 60 }, 'Prune', true);
            });
        }

        // Per-host Ping buttons in the hosts tab. Delegated on the panel so
        // stopPropagation also keeps the row-click (host details) from firing.
        var hostsPanel = document.querySelector('.std-tab-panel[data-tab="disc-hosts"]');
        if (hostsPanel) {
            hostsPanel.addEventListener('click', function (e) {
                var btn = e.target.closest('.disc-btn-ping-host');
                if (!btn) return;
                e.stopPropagation();
                var row = btn.closest('.disc-host-row');
                var ip = row ? row.getAttribute('data-ip') : null;
                if (!ip) return;
                execAction(btn, 'discovery_ping_now', { ip: ip }, 'Ping', true);
            });
        }
    }

    /* Settings                                                             */

    function initSettings() {
        var form = document.querySelector('[data-js="disc-settings-form"]');
        if (!form) return;

        var feedback = document.querySelector('[data-js="disc-settings-feedback"]');

        form.addEventListener('submit', function (e) {
            e.preventDefault();

            var payload = {};

            // Max WAN hops
            var hopsInput = document.getElementById('disc-max-wan-hops');
            if (hopsInput) {
                var hops = parseInt(hopsInput.value, 10);
                if (!isNaN(hops) && hops > 0) {
                    payload.max_wan_hops = hops;
                }
            }

            // Feature toggles
            var toggles = form.querySelectorAll('[data-js="disc-feature-toggle"]');
            var features = {};
            toggles.forEach(function (cb) {
                features[cb.getAttribute('data-feature')] = cb.checked;
            });
            if (Object.keys(features).length > 0) {
                payload.features = features;
            }

            if (Object.keys(payload).length === 0) {
                if (feedback) {
                    feedback.textContent = 'Nothing to save.';
                    feedback.className = 'disc-settings-feedback disc-settings-feedback-err';
                }
                return;
            }

            var btn = form.querySelector('[data-js="disc-settings-save"]');
            if (btn) btn.disabled = true;
            if (feedback) {
                feedback.textContent = 'Saving...';
                feedback.className = 'disc-settings-feedback';
            }

            apiClient.submit('discovery_update_settings', payload).then(function (resp) {
                if (btn) btn.disabled = false;
                if (resp.status === 'success') {
                    var result = resp.result || {};
                    var applied = result.applied || {};
                    var deferred = result.deferred || {};
                    var msgParts = [];
                    var appliedKeys = Object.keys(applied);
                    var deferredKeys = Object.keys(deferred);

                    if (appliedKeys.length > 0) {
                        msgParts.push('Applied: ' + appliedKeys.join(', '));
                    }
                    if (deferredKeys.length > 0) {
                        msgParts.push('Deferred (restart required): ' + deferredKeys.map(function (k) {
                            return k + (deferred[k] ? ' (' + deferred[k] + ')' : '');
                        }).join(', '));
                    }
                    var msg = msgParts.length > 0 ? msgParts.join('. ') : 'Settings saved.';
                    if (feedback) {
                        feedback.textContent = msg;
                        feedback.className = 'disc-settings-feedback disc-settings-feedback-ok';
                    }
                } else {
                    var err = (resp.result && (resp.result.response_msg || resp.result.msg))
                        || resp.response_msg
                        || 'Failed to save settings';
                    if (feedback) {
                        feedback.textContent = 'Error: ' + err;
                        feedback.className = 'disc-settings-feedback disc-settings-feedback-err';
                    }
                }
            }).catch(function () {
                if (btn) btn.disabled = false;
                if (feedback) {
                    feedback.textContent = 'Network error.';
                    feedback.className = 'disc-settings-feedback disc-settings-feedback-err';
                }
            });
        });
    }

    /* Init                                                                 */

    document.addEventListener('DOMContentLoaded', function () {
        initTabs();
        initHostFilter();
        initNodeClick();
        initActions();
        initSettings();
    });

})();
