document.addEventListener('DOMContentLoaded', function() {
	const createSelect = document.getElementById('create-interface-select');
	if (createSelect) {
		createSelect.addEventListener('change', function() {
				if (this.value) {
					// New create URL: create=1&type=virtual&subtype=<type>
					window.location.href =
						'?page=network&section=net-iface-mgmt&create=1&type=virtual&subtype=' + encodeURIComponent(this.value);
				}
		});
	}

	const phyTbody = document.querySelector('#physical-interfaces-table tbody');
		if (phyTbody) {
			phyTbody.addEventListener('click', function(e) {
				let tr = e.target.closest('tr');
				if (!tr || tr.classList.contains('ni-unmanaged')) return;
				if (tr && tr.hasAttribute('data-iface-id')) {
					const ifaceId = tr.getAttribute('data-iface-id');
					let url = '?page=network&section=net-iface-mgmt&modify=' + encodeURIComponent(ifaceId);
					const ifaceType = tr.getAttribute('data-iface-type') || '';
					const ifaceSubtype = tr.getAttribute('data-iface-subtype') || '';
					if (ifaceType) url += '&type=' + encodeURIComponent(ifaceType);
					if (ifaceSubtype) url += '&subtype=' + encodeURIComponent(ifaceSubtype);
					window.location.href = url;
				}
			});
		}

	const virtTbody = document.querySelector('#virtual-interfaces-table tbody');
		if (virtTbody) {
			virtTbody.addEventListener('click', function(e) {
				// Ignore clicks that originate from the delete button so they don't trigger modify navigation
				if (e.target && e.target.closest && e.target.closest('.js-delete-virtual')) {
					return;
				}
				let tr = e.target.closest('tr');
				if (!tr || tr.classList.contains('ni-unmanaged')) return;
				if (tr && tr.hasAttribute('data-iface-id')) {
					const ifaceId = tr.getAttribute('data-iface-id');
					let url = '?page=network&section=net-iface-mgmt&modify=' + encodeURIComponent(ifaceId);
					const ifaceType = tr.getAttribute('data-iface-type') || '';
					const ifaceSubtype = tr.getAttribute('data-iface-subtype') || '';
					if (ifaceType) url += '&type=' + encodeURIComponent(ifaceType);
					if (ifaceSubtype) url += '&subtype=' + encodeURIComponent(ifaceSubtype);
					window.location.href = url;
				}
			});
		}

	// Delegate delete button for virtual interfaces
	document.body.addEventListener('click', function (ev) {
		const btn = ev.target.closest('.js-delete-virtual');
		if (!btn) return;
		ev.preventDefault();
		ev.stopPropagation();

		const ifaceId = btn.getAttribute('data-id');
		if (!ifaceId) return;

		const tr = btn.closest('tr');
		const ifaceName = tr ? tr.getAttribute('data-iface') : ifaceId;

		if (!confirm('Delete virtual interface "' + ifaceName + '"? Its DHCP configuration (if any) will also be removed. This action cannot be undone.')) {
			return;
		}

		if (typeof apiClient === 'undefined' || !apiClient.submit) {
			alert('API client not available');
			return;
		}

		btn.disabled = true;
		const originalText = btn.textContent;
		btn.textContent = 'Deleting...';

		// Remove DHCP config first (idempotent): the gateway blocks interface
		// deletion while the interface still has DHCP refs.
		apiClient.submit('delete_dhcp_config', { interface_id: ifaceId })
			.then(function (cleanup) {
				if (!(cleanup && cleanup.status === 'success')) {
					showApiResult(cleanup || { status: 'error', response_msg: 'Failed to clean up DHCP config' }, { title: 'Error', closeText: 'Close' });
					btn.disabled = false;
					btn.textContent = originalText;
					return null;
				}
				return apiClient.submit('delete_virtual_interface', { id: ifaceId });
			})
			.then(function (data) {
				if (!data) return; // DHCP cleanup failed; error already shown
				if (data.status === 'success') {
					if (tr) tr.remove();
				} else {
					showApiResult(data, { title: 'Error', closeText: 'Close' });
					btn.disabled = false;
					btn.textContent = originalText;
				}
			})
			.catch(function () {
				showApiResult({ status: 'error', response_msg: 'Network error while deleting interface' }, { title: 'Error', closeText: 'Close' });
				btn.disabled = false;
				btn.textContent = originalText;
			});
	});
});
