// ha.js
// High Availability (conntrackd) configuration

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }

    const transportEl = document.getElementById('ha_transport');
    const TRANSPORTS = ['multicast', 'udp', 'tcp'];

    function toggleTransportFields() {
        const t = transportEl ? transportEl.value : 'multicast';
        TRANSPORTS.forEach((key) => {
            const el = document.getElementById('ha-' + key + '-fields');
            if (el) {
                el.style.display = key === t ? '' : 'none';
            }
        });
    }
    if (transportEl) {
        transportEl.addEventListener('change', toggleTransportFields);
    }
    toggleTransportFields();

    // Build the save payload from the form, preserving values the user did
    // not touch (window.haConfig holds the full current configuration).
    // Address/port values are Styx object references (set UUIDs), never literals.
    // Each transport is a list of dedicated links; links[0] is edited from the
    // form and redundant links beyond [0] (future) are preserved.
    function buildConfig() {
        const base = window.haConfig || {};
        const cfg = JSON.parse(JSON.stringify(base));
        cfg.sync = cfg.sync || {};
        cfg.general = cfg.general || {};

        const transport = transportEl ? transportEl.value : 'multicast';
        cfg.sync.mode = val('ha_mode', 'FTFW');
        cfg.sync.transport = transport;

        const ifaceEl = document.getElementById('ha_interface');
        cfg.sync.interface = ifaceEl && ifaceEl.value ? ifaceEl.value : null;
        cfg.sync.startup_resync = checked('ha_startup_resync');
        cfg.sync.expectation_sync = checked('ha_expectation_sync');

        // The backend always stores each transport as a list of dedicated
        // links (links[0] active). Fresh feature -- no legacy shapes.
        const links = cfg.sync[transport];
        const link = links[0] || {};
        if (transport === 'multicast') {
            link.address_set = val('ha_mcast_addr_set', '') || null;
            link.group_set = val('ha_mcast_group_set', '') || null;
        } else {
            link.peer_address_set = val('ha_' + transport + '_addr_set', '') || null;
            link.port_set = val('ha_' + transport + '_port_set', '') || null;
        }
        link.checksum = link.checksum !== undefined ? link.checksum : true;
        links[0] = link;
        cfg.sync[transport] = links;

        // Event filtering: addresses are address-set references.
        cfg.general.filter = cfg.general.filter || {};
        cfg.general.filter.from = val('ha_filter_from', 'Userspace');
        cfg.general.filter.protocol_action = val('ha_filter_proto_action', 'accept');
        cfg.general.filter.protocols = Array.from(
            document.querySelectorAll('.ha-proto:checked')
        ).map((cb) => cb.value);
        cfg.general.filter.address_action = val('ha_filter_addr_action', 'ignore');
        cfg.general.filter.address_sets = val('ha_filter_address_sets', '')
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean);

        return cfg;
    }

    function val(id, fallback) {
        const el = document.getElementById(id);
        return el ? el.value : fallback;
    }

    function checked(id) {
        const el = document.getElementById(id);
        return !!(el && el.checked);
    }

    // Save configuration
    const saveBtn = document.querySelector('[data-js="ha-save-config"]');
    if (saveBtn) {
        saveBtn.addEventListener('click', async () => {
            try {
                const result = await apiClient.submit('ha_save_conntrackd_config', buildConfig());
                showApiResult(result, { title: 'conntrackd Configuration', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Reset configuration
    const resetBtn = document.querySelector('[data-js="ha-reset-config"]');
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            showModal('Reset the conntrackd configuration to defaults?', {
                title: 'Confirm Reset',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Reset',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('ha_reset_conntrackd_config', {});
                        showApiResult(result, { title: 'Reset conntrackd', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    }
});
