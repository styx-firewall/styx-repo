<?php
/**
 * HA fragment: page actions.
 *
 * Save / Reset apply to the whole conntrackd configuration (sync transport
 * and event filtering) and are submitted together via ha.js buildConfig().
 *
 * @var array<mixed> $tdata - $tdata['tpl_data'] contains the full formatted HA data
 */
?>
<div class="content-box ha-actions">
    <div class="std-form form-compact">
        <div class="form-row">
            <button type="button" class="std-btn" data-js="ha-save-config">Save Configuration</button>
            <button type="button" class="std-btn std-btn--secondary" data-js="ha-reset-config">Reset Defaults</button>
        </div>
    </div>
</div>
