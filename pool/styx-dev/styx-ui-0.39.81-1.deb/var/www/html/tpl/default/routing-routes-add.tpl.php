<?php
/**
 * Fragment: Add route form for net-routes
 * Expects $tdata['tpl_data']['ifaces_names']
 * Script: routes.js
 */
$ifaces_names = $tdata['tpl_data']['ifaces_names'] ?? [];
?>
<form id="add-route-form"
    class="std-form js-add-route-form add-route-form"
    method="post"
    action="?page=network&section=net-routes">
    <div class="add-route-fields">
        <div class="std-flex-col">
            <label class="form-label">Type</label>
            <select name="route_type" id="route-type-select" required class="input-select">
                <option value="ipv4">IPv4</option>
                <option value="ipv6">IPv6</option>
            </select>
        </div>
        <div class="std-flex-col">
            <label class="form-label">Destination</label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-filter-scope="network,host" data-max-select="1" data-required>
                <input type="hidden" name="dst" id="destination-input" value="">
                <button type="button" class="std-btn set-picker-trigger js-set-picker-open"
                    data-placeholder="Select destination set&hellip;">
                    <span class="js-set-picker-label">Select destination set&hellip;</span>
                </button>
                <button type="button" class="std-btn set-picker-clear js-set-picker-clear sets-hidden"
                    title="Clear selection">&#215;</button>
            </div>
        </div>
        <div class="std-flex-col">
            <label class="form-label">Gateway</label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-filter-scope="host" data-max-select="1" data-required>
                <input type="hidden" name="gateway" id="gateway-input" value="">
                <button type="button" class="std-btn set-picker-trigger js-set-picker-open"
                    data-placeholder="Select gateway set&hellip;">
                    <span class="js-set-picker-label">Select gateway set&hellip;</span>
                </button>
                <button type="button" class="std-btn set-picker-clear js-set-picker-clear sets-hidden"
                    title="Clear selection">&#215;</button>
            </div>
        </div>
        <div class="std-flex-col">
            <label class="form-label">Iface</label>
            <select name="iface" required class="input-select">
                <option value="">Select...</option>
                <?php foreach ($ifaces_names as $iface): ?>
                    <option value="<?= $iface['id'] ?>"><?= $iface['interface'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="std-flex-col">
            <label class="form-label">Metric</label>
            <input type="number" name="metric" value="0" min="0" class="input-number">
        </div>
        <div class="std-flex-col">
            <label class="form-label">MTU</label>
            <input type="number" name="mtu" id="mtu-input" min="0" placeholder="1500" class="input-number">
        </div>
        <div class="advanced-toggle">
            <button type="button" id="toggle-advanced-btn" class="btn-advanced-toggle">Show advanced options</button>
        </div>
        <div id="advanced-options" class="advanced-options im-hide">
            <div class="advanced-fields">
                <div class="std-flex-col">
                    <label class="form-label">Preferred Source (prefsrc)</label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-filter-scope="host">
                        <input type="hidden" name="prefsrc" id="prefsrc-input" value="">
                        <button type="button" class="std-btn set-picker-trigger js-set-picker-open"
                            data-placeholder="Select source address&hellip;">
                            <span class="js-set-picker-label">Select source address&hellip;</span>
                        </button>
                        <button type="button" class="std-btn set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                </div>
                <div class="std-flex-col">
                    <label class="form-label">Multipath</label>
                    <div class="checkbox-field">
                        <label class="checkbox-inline">
                            <input type="checkbox" id="path-mode-checkbox" name="path_mode" value="multipath"> Multipath
                        </label>
                    </div>
                </div>
                <div class="std-flex-col">
                    <label class="form-label">Route Type</label>
                    <select name="route_real_type" id="route-real-type-select" class="input-select">
                        <option value="">Select...</option>
                        <option value="unicast">Unicast</option>
                        <option value="blackhole">Blackhole</option>
                        <option value="prohibit">Prohibit</option>
                        <option value="unreachable">Unreachable</option>
                    </select>
                </div>
                <div class="std-flex-col">
                    <label class="form-label">Flags</label>
                    <div class="flags-fields">
                        <label>
                            <input type="checkbox" name="flags[]" value="onlink">Onlink
                        </label>
                    </div>
                </div>
                <div class="std-flex-col">
                    <label class="form-label">Table</label>
                    <div class="set-picker-field" data-js="label-picker-field" data-set-type="routing_tables"
                         data-max-select="1" data-label-title="Select routing table">
                        <input type="hidden" name="table" id="table-input" value="">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                            data-placeholder="Select routing table">
                            <span class="js-set-picker-label">Select routing table</span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                </div>
            </div>
            <div id="multipath-nexthops" class="multipath-nexthops im-hide">
                <label class="form-label">Nexthops (Multipath)</label>
                <div id="nexthop-list"></div>
                <button type="button" id="add-nexthop-btn" class="btn-add-nexthop">Add Nexthop</button>
            </div>
        </div>
        <button type="submit" class="std-btn">Add Route</button>
    </div>
</form>
