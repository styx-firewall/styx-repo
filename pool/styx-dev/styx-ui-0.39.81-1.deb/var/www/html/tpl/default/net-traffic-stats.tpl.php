<?php

/**
 * TemplateService->getTpl()
 * JS: /scripts/network/net-traffic-stats.js
 *
 * @var array<mixed> $tdata
 */

$traffic_sets_in = $tdata['page_data']['traffic_sets_in'] ?? [];
$traffic_sets_out = $tdata['page_data']['traffic_sets_out'] ?? [];
$traffic_sets_fwd = $tdata['page_data']['traffic_sets_fwd'] ?? [];
$traffic_summary = $tdata['page_data']['traffic_summary'] ?? [];
$traffic_summary_all = $tdata['page_data']['traffic_summary_all'] ?? [];
$traffic_total_bytes = $tdata['page_data']['traffic_total_bytes'] ?? '0 B';
$traffic_total_packets = $tdata['page_data']['traffic_total_packets'] ?? 0;
$traffic_total_flows = $tdata['page_data']['traffic_total_flows'] ?? 0;
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Traffic Statistics</h1>

        <!-- Global totals badge (always visible) -->
        <div class="ts-summary-bar">
            <span class="ts-summary-item">
                <strong>Total:</strong> <?= $traffic_total_bytes ?>
            </span>
            <span class="ts-summary-item">
                <strong>Packets:</strong> <?= number_format($traffic_total_packets) ?>
            </span>
            <span class="ts-summary-item">
                <strong>Flows:</strong> <?= number_format($traffic_total_flows) ?>
            </span>
            <span class="ts-summary-item ts-refresh-controls">
                <button id="ts-refresh-btn" class="std-btn" title="Refresh now">Refresh</button>
                <button id="ts-reset-btn" class="std-btn ts-btn-reset" title="Reset all counters">Reset</button>
                <label class="ts-auto-label">
                    <input type="checkbox" id="ts-auto-refresh" checked />
                    Auto
                </label>
            </span>
        </div>

        <!-- Tabs: Overview | Detailed -->
        <div class="std-tabs">
            <button type="button" class="std-tab-btn active" data-tab="ts-overview">Overview</button>
            <button type="button" class="std-tab-btn" data-tab="ts-detailed">Detailed</button>
        </div>

        <!-- OVERVIEW TAB -->
        <div class="std-tab-panel active" data-tab="ts-overview">
            <!-- Top 10 IPs (full width) -->
            <div class="content-box ts-section">
                <h3>Top 10 IPs by Traffic</h3>
                <div class="ts-chart-full"><canvas id="ts-chart-top-ips" class="ts-chart-canvas"></canvas></div>
            </div>

            <!-- Row: Interface + Protocol -->
            <div class="ts-chart-row">
                <div class="content-box ts-section ts-chart-col">
                    <h3>Traffic by Interface</h3>
                    <div class="ts-chart-row-inner">
                        <div class="ts-chart-half">
                            <h4>Packets</h4>
                            <div class="ts-chart-wrap"><canvas id="ts-chart-iface-packets" class="ts-chart-canvas"></canvas></div>
                        </div>
                        <div class="ts-chart-half">
                            <h4>Bytes</h4>
                            <div class="ts-chart-wrap"><canvas id="ts-chart-iface-bytes" class="ts-chart-canvas"></canvas></div>
                        </div>
                    </div>
                </div>
                <div class="content-box ts-section ts-chart-col">
                    <h3>Protocol Distribution</h3>
                    <div class="ts-chart-wrap"><canvas id="ts-chart-protocol" class="ts-chart-canvas"></canvas></div>
                </div>
            </div>

            <!-- Row: Direction -->
            <div class="content-box ts-section">
                <h3>Traffic Direction (All Interfaces)</h3>
                <div class="ts-chart-row">
                    <div class="ts-chart-col">
                        <h4>Packets by Direction</h4>
                        <div class="ts-chart-wrap"><canvas id="ts-chart-dir-packets" class="ts-chart-canvas"></canvas></div>
                    </div>
                    <div class="ts-chart-col">
                        <h4>Bytes by Direction</h4>
                        <div class="ts-chart-wrap"><canvas id="ts-chart-dir-bytes" class="ts-chart-canvas"></canvas></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- DETAILED TAB -->
        <div class="std-tab-panel" data-tab="ts-detailed">
            <!-- Per-interface summary table -->
            <?php if (!empty($traffic_summary)): ?>
            <div class="content-box ts-section">
                <h3>Per-Interface Summary</h3>
                    <table class="std-table ts-summary-table">
                        <thead>
                            <tr>
                                <th>Interface</th>
                                <th>Packets</th>
                                <th>Bytes</th>
                                <th>Flows</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($traffic_summary as $iface => $agg): ?>
                            <tr>
                                <td><strong><?= (string)$iface ?></strong></td>
                                <td><?= number_format((int)($agg['packets'] ?? 0)) ?></td>
                                <td><?= (string)($agg['bytes_formatted'] ?? '0 B') ?></td>
                                <td><?= number_format((int)($agg['flows'] ?? 0)) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
            </div>
            <?php endif; ?>

            <!-- Inbound traffic -->
            <div class="content-box ts-section">
                <h3>Inbound Traffic</h3>
                    <table class="std-table ts-detail-table" id="ts-table-in">
                        <thead>
                            <tr>
                                <th>Interface</th>
                                <th>Src IP</th>
                                <th>Src Name</th>
                                <th>Protocol</th>
                                <th>Packets</th>
                                <th>Bytes</th>
                                <th>Expires</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($traffic_sets_in)): ?>
                                <?php foreach ($traffic_sets_in as $entry): ?>
                                <tr>
                                    <td><?= $entry['iface'] ?></td>
                                    <td><?= $entry['ip'] ?></td>
                                    <td title="<?= htmlspecialchars($entry['ip'] ?? '', ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($entry['name'] ?? '-', ENT_QUOTES, 'UTF-8') ?></td>
                                    <td><?= $entry['proto'] ?></td>
                                    <td><?= number_format($entry['packets']) ?></td>
                                    <td><?= $entry['bytes_formatted'] ?></td>
                                    <td><?= $entry['expires'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="7" class="ts-empty">No inbound traffic data</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
            </div>

            <!-- Outbound traffic -->
            <div class="content-box ts-section">
                <h3>Outbound Traffic</h3>
                    <table class="std-table ts-detail-table" id="ts-table-out">
                        <thead>
                            <tr>
                                <th>Interface</th>
                                <th>Dst IP</th>
                                <th>Dst Name</th>
                                <th>Protocol</th>
                                <th>Packets</th>
                                <th>Bytes</th>
                                <th>Expires</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($traffic_sets_out)): ?>
                                <?php foreach ($traffic_sets_out as $entry): ?>
                                <tr>
                                    <td><?= $entry['iface'] ?></td>
                                    <td><?= $entry['ip'] ?></td>
                                    <td title="<?= htmlspecialchars($entry['ip'] ?? '', ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($entry['name'] ?? '-', ENT_QUOTES, 'UTF-8') ?></td>
                                    <td><?= $entry['proto'] ?></td>
                                    <td><?= number_format($entry['packets']) ?></td>
                                    <td><?= $entry['bytes_formatted'] ?></td>
                                    <td><?= $entry['expires'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="7" class="ts-empty">No outbound traffic data</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
            </div>

            <!-- Forwarded traffic -->
            <div class="content-box ts-section">
                <h3>Forwarded Traffic</h3>
                    <table class="std-table ts-detail-table" id="ts-table-fwd">
                        <thead>
                            <tr>
                                <th>Interface</th>
                                <th>Src IP</th>
                                <th>Src Name</th>
                                <th>Dst IP</th>
                                <th>Dst Name</th>
                                <th>Protocol</th>
                                <th>Packets</th>
                                <th>Bytes</th>
                                <th>Expires</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($traffic_sets_fwd)): ?>
                                <?php foreach ($traffic_sets_fwd as $entry): ?>
                                <tr>
                                    <td><?= $entry['iface'] ?></td>
                                    <td><?= $entry['src_ip'] !== '' ? $entry['src_ip'] : '-' ?></td>
                                    <td title="<?= htmlspecialchars($entry['src_ip'] ?? '', ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($entry['src_name'] ?? '-', ENT_QUOTES, 'UTF-8') ?></td>
                                    <td><?= $entry['dst_ip'] !== '' ? $entry['dst_ip'] : '-' ?></td>
                                    <td title="<?= htmlspecialchars($entry['dst_ip'] ?? '', ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($entry['dst_name'] ?? '-', ENT_QUOTES, 'UTF-8') ?></td>
                                    <td><?= $entry['proto'] ?></td>
                                    <td><?= number_format($entry['packets']) ?></td>
                                    <td><?= $entry['bytes_formatted'] ?></td>
                                    <td><?= $entry['expires'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="9" class="ts-empty">No forwarded traffic data</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
            </div>
        </div>

        <!-- Initial data injection for JS -->
        <script>
        window.__tsInitialData = {
            sets_in: <?= json_encode($traffic_sets_in) ?>,
            sets_out: <?= json_encode($traffic_sets_out) ?>,
            sets_fwd: <?= json_encode($traffic_sets_fwd) ?>,
            summary: <?= json_encode($traffic_summary) ?>,
            summary_all: <?= json_encode($traffic_summary_all) ?>
        };
        </script>
    </main>
</div>
