<?php
/**
 * Fragment: Routes view (tables + filters)
 * Expects routing tables/scopes/types and routes arrays in $tdata['tpl_data']
 */
$routing_tables = $tdata['tpl_data']['routing_tables'] ?? [];
$routing_scopes = $tdata['tpl_data']['routing_scopes'] ?? [];
$routing_types = $tdata['tpl_data']['routing_types'] ?? [];
$routes_ipv4 = $tdata['tpl_data']['routes_ipv4'] ?? [];
$routes_ipv6 = $tdata['tpl_data']['routes_ipv6'] ?? [];
$can_write = $tdata['tpl_data']['can_write'] ?? false;
$can_delete = $tdata['tpl_data']['can_delete'] ?? false;

?>
<!-- Filters -->
<div class="routes-filters">
    <div>
        <label for="filter-table-select">Table:</label>
        <select id="filter-table-select" class="input-select">
            <option value="">All</option>
            <?php foreach ($routing_tables as $table): ?>
                <option value="<?= $table['value'] ?>"><?= $table['label'] ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="filter-scope-select">Scope:</label>
        <select id="filter-scope-select" class="input-select">
            <option value="">All</option>
            <?php foreach ($routing_scopes as $scope): ?>
                <option value="<?= $scope ?>"><?= $scope ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="filter-type-select">Type:</label>
        <select id="filter-type-select" class="input-select">
            <option value="">All</option>
            <?php foreach ($routing_types as $type): ?>
                <option value="<?= $type ?>"><?= $type ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

<!-- IPv4 table -->
<table class="std-table" id="ipv4-routes-table">
    <thead>
        <tr>
            <th class="routes-warning-col"></th>
            <th>Destination</th>
            <th>Gateway</th>
            <th>Device</th>
            <th>Table</th>
            <th>Protocol</th>
            <th>Scope</th>
            <th>Prefsrc</th>
            <th>Type</th>
            <th>Flags</th>
            <th>Metric</th>
            <th>MTU</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($routes_ipv4 as $route): ?>
        <tr>
            <td class="routes-warning-col">
                <?php if (!empty($route['warning_text'])): ?>
                    <span class="ni-missing-label" title="<?= $route['warning_text'] ?>">
                        <svg
                            class="ni-missing-icon"
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 20 20"
                            width="16"
                            height="16"
                        >
                            <polygon points="10,2 19,18 1,18" fill="#FFD600" stroke="#d00" stroke-width="1.5" />
                            <rect x="9" y="7" width="2" height="6" rx="1" fill="#d00" />
                            <circle cx="10" cy="15.5" r="1" fill="#d00" />
                        </svg>
                    </span>
                <?php endif; ?>
            </td>
            <td>
                <span title="<?= $route['dst_tooltip'] ?? '' ?>"><?= $route['dst_display'] ?? '' ?></span>
                <?php if (!empty($route['is_disabled'])): ?>
                    <span class="route-disabled-badge" title="This route is disabled">Disabled</span>
                <?php endif; ?>
                <?php if (!empty($route['nexthops_list'])): ?>
                    <div class="nexthop-list-info">
                        <?php foreach ($route['nexthops_list'] as $nhs): ?>
                            <div class="nexthop-list-item"><?= $nhs ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </td>
            <td><span title="<?= $route['gateway_tooltip'] ?? '' ?>"><?= $route['gateway'] ?? '' ?></span></td>
            <td><?= $route['dev'] ?? '' ?></td>
            <td><?= $route['table'] ?? '' ?></td>
            <td><?= $route['protocol'] ?? '' ?></td>
            <td><?= $route['scope'] ?? '' ?></td>
            <td><?= $route['prefsrc'] ?? '' ?></td>
            <td><?= $route['type'] ?? '' ?></td>
            <td><?= $route['flags_text'] ?? '' ?></td>
            <td><?= $route['metric'] ?? '' ?></td>
            <td><?= $route['mtu'] ?? '' ?></td>
            <td>
                <?php if (!empty($route['has_id'])): ?>
                    <?php if (!empty($can_write)): ?>
                        <button class="std-btn <?= $route['action_class'] ?>" data-route-id="<?= $route['id'] ?>"><?= $route['action_label'] ?></button>
                    <?php endif; ?>
                    <?php if (!empty($can_delete)): ?>
                        <button class="std-btn delete-route-btn" data-route-id="<?= $route['id'] ?>">Delete</button>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<!-- IPv6 table -->
<table class="std-table" id="ipv6-routes-table">
    <thead>
        <tr>
            <th class="routes-warning-col"></th>
            <th>Destination</th>
            <th>Gateway</th>
            <th>Device</th>
            <th>Table</th>
            <th>Protocol</th>
            <th>Scope</th>
            <th>Prefsrc</th>
            <th>Type</th>
            <th>Flags</th>
            <th>Metric</th>
            <th>MTU</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($routes_ipv6 as $route): ?>
        <tr>
            <td class="routes-warning-col">
                <?php if (!empty($route['warning_text'])): ?>
                    <span class="ni-missing-label" title="<?= $route['warning_text'] ?>">
                        <svg
                            class="ni-missing-icon"
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 20 20"
                            width="16"
                            height="16"
                        >
                            <polygon points="10,2 19,18 1,18" fill="#FFD600" stroke="#d00" stroke-width="1.5" />
                            <rect x="9" y="7" width="2" height="6" rx="1" fill="#d00" />
                            <circle cx="10" cy="15.5" r="1" fill="#d00" />
                        </svg>
                    </span>
                <?php endif; ?>
            </td>
            <td>
                <span title="<?= $route['dst_tooltip'] ?? '' ?>"><?= $route['dst_display'] ?? '' ?></span>
                <?php if (!empty($route['is_disabled'])): ?>
                    <span class="route-disabled-badge" title="This route is disabled">Disabled</span>
                <?php endif; ?>
            </td>
            <td><span title="<?= $route['gateway_tooltip'] ?? '' ?>"><?= $route['gateway'] ?? '' ?></span></td>
            <td><?= $route['dev'] ?? '' ?></td>
            <td><?= $route['table'] ?? '' ?></td>
            <td><?= $route['protocol'] ?? '' ?></td>
            <td><?= $route['scope'] ?? '' ?></td>
            <td><?= $route['prefsrc'] ?? '' ?></td>
            <td><?= $route['type'] ?? '' ?></td>
            <td><?= $route['flags_text'] ?? '' ?></td>
            <td><?= $route['metric'] ?? '' ?></td>
            <td><?= $route['mtu'] ?? '' ?></td>
            <td>
                <?php if (!empty($route['has_id'])): ?>
                    <?php if (!empty($can_write)): ?>
                        <button class="std-btn <?= $route['action_class'] ?>" data-route-id="<?= $route['id'] ?>" data-ipv6="1"><?= $route['action_label'] ?></button>
                    <?php endif; ?>
                    <?php if (!empty($can_delete)): ?>
                        <button class="std-btn delete-route-btn" data-route-id="<?= $route['id'] ?>" data-ipv6="1">Delete</button>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
