<?php
/**
 * @var array<mixed> $tdata
 * js: scripts/routing/routing-rip.js
 */
$page_data   = $tdata['page_data'];
$rip_config  = $page_data['rip_config'] ?? [];
$networks    = $page_data['networks'] ?? [];
$bfd_profiles = $page_data['bfd_profiles'] ?? [];
$prefix_lists = $page_data['prefix_lists'] ?? [];
$route_maps   = $page_data['route_maps'] ?? [];
$rip_ifaces   = $page_data['rip_ifaces'] ?? [];
$rip_redistribute = $page_data['rip_redistribute'] ?? [];
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>RIP</h1>

        <details class="nat-help">
            <summary>Help</summary>
            <div class="nat-help-content">
                <p><strong>RIP (Routing Information Protocol)</strong> is a distance-vector protocol suitable for small, flat networks. Easy to configure but limited to 15 hops.</p>
                <ul>
                    <li><strong>Version 2:</strong> Use RIP v2 (supports CIDR, multicast updates). Avoid v1 unless legacy equipment requires it.</li>
                    <li><strong>Networks:</strong> Add the prefixes (address sets) that RIP should advertise and listen on.</li>
                    <li><strong>Timers:</strong> Defaults (30/180/120) work for most setups. Tune only if convergence time is critical.</li>
                </ul>
            </div>
        </details>

        <!-- Global RIP config -->
        <div class="content-box">
            <h2>RIP Configuration</h2>
            <form id="rip-config-form" class="std-form form-compact" data-js="rip-config-form">
                <div class="form-row">
                    <div class="form-col form-col--tight">
                        <label for="rip_enabled">Enabled</label>
                        <label class="std-switch">
                            <input type="checkbox" id="rip_enabled" name="enabled"
                                <?= $rip_config['enabled_checked'] ?? '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="rip_version">Version</label>
                        <select id="rip_version" name="version" class="std-select">
                            <option value="2" <?= $rip_config['version_selected_2'] ?? '' ?>>RIPv2</option>
                            <option value="1" <?= $rip_config['version_selected_1'] ?? '' ?>>RIPv1</option>
                        </select>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="rip_default_metric">Default Metric</label>
                        <input type="number" id="rip_default_metric" name="default_metric" class="std-input"
                            min="1" max="16" placeholder="1"
                            value="<?= $rip_config['default_metric'] ?? '' ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="rip_update_timer">Update Timer (s)</label>
                        <input type="number" id="rip_update_timer" name="update_timer" class="std-input"
                            min="1" max="65535" placeholder="30"
                            value="<?= $rip_config['update_timer'] ?? '' ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="rip_timeout_timer">Timeout Timer (s)</label>
                        <input type="number" id="rip_timeout_timer" name="timeout_timer" class="std-input"
                            min="1" max="65535" placeholder="180"
                            value="<?= $rip_config['timeout_timer'] ?? '' ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="rip_garbage_timer">Garbage Timer (s)</label>
                        <input type="number" id="rip_garbage_timer" name="garbage_timer" class="std-input"
                            min="1" max="65535" placeholder="120"
                            value="<?= $rip_config['garbage_timer'] ?? '' ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-col">
                        <label for="rip_bfd_default_profile">BFD Default Profile</label>
                        <select id="rip_bfd_default_profile" class="std-input">
                            <option value="">- None -</option>
                            <?php foreach ($bfd_profiles as $bfp): ?>
                            <option value="<?= $bfp['id'] ?>"
                                <?= $bfp['selected'] ?? '' ?>>
                                <?= $bfp['name'] ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-col">
                        <label>Passive Interfaces</label>
                        <select id="rip_passive_interfaces" class="std-input" multiple size="4">
                            <?php foreach ($rip_ifaces as $iface): ?>
                            <option value="<?= $iface['id'] ?>"
                                <?= $iface['selected'] ?? '' ?>>
                                <?= $iface['name'] ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <!-- Redistribute -->
                <details class="form-section-collapse">
                    <summary>Redistribute into RIP</summary>
                    <fieldset class="form-fieldset">
                    <?php foreach ($rip_redistribute as $rr): ?>
                        <div class="form-row">
                            <div class="form-col form-col--tight">
                                <label class="std-checkbox-label">
                                    <input type="checkbox" class="js-rip-redist-proto" value="<?= $rr['proto'] ?>"
                                        <?= $rr['checked'] ?>>
                                    <?= $rr['label'] ?>
                                </label>
                            </div>
                            <div class="form-col">
                                <select class="std-input js-rip-redist-route-map" data-proto="<?= $rr['proto'] ?>"
                                    style="width:auto; min-width:160px;">
                                    <option value="">- No route map -</option>
                                    <?php foreach ($rr['route_maps'] as $rm): ?>
                                    <option value="<?= $rm['id'] ?>"
                                        <?= $rm['selected'] ?>>
                                        <?= $rm['name'] ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-col form-col--tight">
                                <input type="number" class="std-input js-rip-redist-metric" data-proto="<?= $rr['proto'] ?>"
                                    placeholder="Metric (1-16)" min="1" max="16"
                                    value="<?= $rr['metric'] ?>"
                                    style="width:110px;">
                            </div>
                        </div>
                    <?php endforeach; ?>
                    </fieldset>
                </details>
                <div class="form-row">
                    <button type="button" class="std-btn" data-js="rip-save-config">Save Configuration</button>
                </div>
            </form>
        </div>

        <!-- Networks table -->
        <div class="content-box">
            <div class="content-box-header">
                <h2>RIP Networks</h2>
                <button type="button" class="std-btn" data-js="rip-add-network-open">+ Add Network</button>
            </div>
            <table class="std-table" id="rip-networks-table">
                <thead>
                    <tr>
                        <th>Network</th>
                        <th>BFD</th>
                        <th>BFD Profile</th>
                        <th>Prefix In</th>
                        <th>Prefix Out</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="rip-networks-tbody">
                <?php if (empty($networks)): ?>
                    <tr class="std-table-empty"><td colspan="6">No networks configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($networks as $net): ?>
                    <tr data-network-id="<?= $net['id'] ?>">
                        <td><?= $net['network_html'] ?></td>
                        <td><?= $net['bfd_label'] ?? 'No' ?></td>
                        <td><?= $net['bfd_profile_label'] ?? '-' ?></td>
                        <td><?= $net['prefix_list_in_label'] ?? '-' ?></td>
                        <td><?= $net['prefix_list_out_label'] ?? '-' ?></td>
                        <td>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="rip-delete-network" data-id="<?= $net['id'] ?>">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Add network form (hidden by default) -->
        <div class="content-box" id="rip-add-network-form" style="display:none;">
            <h2>Add RIP Network</h2>
            <form class="std-form form-compact" data-js="rip-network-form">
                <div class="form-row">
                    <div class="form-col">
                        <label>Network (address set)</label>
                        <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                             data-max-select="1" data-filter-scope="network">
                            <input type="hidden" id="rip_network_set" name="network_set" value="">
                            <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                data-placeholder="Select network set">
                                <span class="js-set-picker-label">Select network</span>
                            </button>
                            <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                title="Clear selection">&#215;</button>
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-col form-col--tight">
                        <label for="rip_network_bfd">BFD</label>
                        <label class="std-switch">
                            <input type="checkbox" id="rip_network_bfd">
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col">
                        <label for="rip_network_bfd_profile">BFD Profile</label>
                        <select id="rip_network_bfd_profile" class="std-input">
                            <option value="">- None -</option>
                            <?php foreach ($bfd_profiles as $bfp): ?>
                            <option value="<?= $bfp['id'] ?>"><?= $bfp['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-col">
                        <label for="rip_network_pl_in">Prefix List In</label>
                        <select id="rip_network_pl_in" class="std-input">
                            <option value="">- None -</option>
                            <?php foreach ($prefix_lists as $pl): ?>
                            <option value="<?= $pl['id'] ?>"><?= $pl['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-col">
                        <label for="rip_network_pl_out">Prefix List Out</label>
                        <select id="rip_network_pl_out" class="std-input">
                            <option value="">- None -</option>
                            <?php foreach ($prefix_lists as $pl): ?>
                            <option value="<?= $pl['id'] ?>"><?= $pl['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <button type="button" class="std-btn" data-js="rip-network-save">Save Network</button>
                    <button type="button" class="std-btn std-btn--secondary" data-js="rip-add-network-cancel">Cancel</button>
                </div>
            </form>
        </div>

    </main>
</div>
