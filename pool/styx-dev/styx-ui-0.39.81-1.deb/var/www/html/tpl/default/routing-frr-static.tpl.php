<?php
/**
 * FRR Static Routes
 * @var array<mixed> $tdata
 * js: scripts/routing/routing-frr-static.js
 */
$page_data = $tdata['page_data'];
$config    = $page_data['frr_static_config'] ?? [];
$routes    = $page_data['frr_static_routes'] ?? [];
$ifaces    = $page_data['frr_static_ifaces'] ?? [];
$can_add   = !empty($page_data['can_add']);
$can_save  = !empty($page_data['can_save']);
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>FRR Static Routes</h1>

        <details class="nat-help">
            <summary>Help</summary>
            <div class="nat-help-content">
                <p><strong>FRR Static Routes</strong> are managed by the staticd daemon and injected into the FRR RIB. Unlike kernel routes, they can be redistributed into BGP/OSPF/RIP.</p>
                <ul>
                    <li><strong>Network:</strong> Destination prefix (address set).</li>
                    <li><strong>Gateway or Interface:</strong> Next-hop IP (host scope address set) or outgoing interface. Use one or both.</li>
                    <li><strong>Distance:</strong> Administrative distance (1-255). Lower = preferred.</li>
                    <li><strong>Type:</strong> unicast (normal), blackhole (drop silently), reject (drop with ICMP unreachable).</li>
                </ul>
            </div>
        </details>

        <div class="content-box">
            <h2>Configuration</h2>
            <form class="std-form form-compact" data-js="frr-static-config-form">
                <div class="form-row">
                    <div class="form-col form-col--tight">
                        <label for="frr_static_enabled">Enabled</label>
                        <label class="std-switch">
                            <input type="checkbox" id="frr_static_enabled"
                                <?= !empty($config['enabled']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <?php if ($can_save): ?>
                <div class="form-row">
                    <button type="button" class="std-btn" data-js="frr-static-save-config">Save</button>
                </div>
                <?php endif; ?>
            </form>
        </div>

        <div class="content-box">
            <div class="content-box-header">
                <h2>Routes</h2>
                <?php if ($can_add): ?>
                <button type="button" class="std-btn" data-js="frr-static-toggle-form"
                    data-target="frr-static-add-form">+ Add Route</button>
                <?php endif; ?>
            </div>

            <div class="content-box" id="frr-static-add-form" style="display:none;">
                <h3 id="frr-static-form-title">Add Static Route</h3>
                <form class="std-form form-compact" data-js="frr-static-route-form">
                    <input type="hidden" id="frr_static_id" value="">
                    <div class="form-row">
                        <div class="form-col">
                            <label>Network (address set)</label>
                            <div class="set-picker-field" data-js="set-picker-field"
                                 data-set-type="address" data-max-select="1">
                                <input type="hidden" id="frr_static_network" value="">
                                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select network">
                                    <span class="js-set-picker-label">Select network</span>
                                </button>
                                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear">&#215;</button>
                            </div>
                        </div>
                        <div class="form-col">
                            <label>Gateway (address set, optional)</label>
                            <div class="set-picker-field" data-js="set-picker-field"
                                 data-set-type="address" data-max-select="1" data-filter-scope="host">
                                <input type="hidden" id="frr_static_gateway" value="">
                                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Optional gateway">
                                    <span class="js-set-picker-label">Optional gateway</span>
                                </button>
                                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear">&#215;</button>
                            </div>
                        </div>
                        <div class="form-col">
                            <label for="frr_static_interface">Interface (optional)</label>
                            <select id="frr_static_interface" class="std-input">
                                <option value="">Optional interface</option>
                                <?php foreach ($ifaces as $iface): ?>
                                <option value="<?= $iface['id'] ?>"><?= $iface['interface'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col form-col--tight">
                            <label for="frr_static_distance">Distance (1-255)</label>
                            <input type="number" id="frr_static_distance" class="std-input" min="1" max="255" placeholder="1">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="frr_static_metric">Metric</label>
                            <input type="number" id="frr_static_metric" class="std-input" min="0" max="4294967295" placeholder="0">
                        </div>
                        <div class="form-col form-col--tight js-frr-static-unicast-only">
                            <label>Route Tag</label>
                            <div class="set-picker-field" data-js="label-picker-field"
                                 data-set-type="route_tag" data-max-select="1">
                                <input type="hidden" id="frr_static_tag" value="">
                                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select tag">
                                    <span class="js-set-picker-label">None</span>
                                </button>
                                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear">&#215;</button>
                            </div>
                        </div>
                        <div class="form-col form-col--tight js-frr-static-unicast-only">
                            <label for="frr_static_weight">Weight</label>
                            <input type="number" id="frr_static_weight" class="std-input" min="1" max="65535" placeholder="none">
                        </div>
                        <div class="form-col form-col--tight">
                            <label>Table</label>
                            <div class="set-picker-field" data-js="label-picker-field"
                                 data-set-type="routing_tables" data-max-select="1">
                                <input type="hidden" id="frr_static_table" value="">
                                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select table">
                                    <span class="js-set-picker-label">None</span>
                                </button>
                                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear">&#215;</button>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="frr_static_vrf">VRF</label>
                            <input type="text" id="frr_static_vrf" class="std-input" placeholder="none">
                        </div>
                        <div class="form-col js-frr-static-unicast-only">
                            <label for="frr_static_nh_vrf">Nexthop VRF</label>
                            <input type="text" id="frr_static_nh_vrf" class="std-input" placeholder="none">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="frr_static_type">Type</label>
                            <select id="frr_static_type" class="std-input">
                                <option value="unicast">unicast</option>
                                <option value="blackhole">blackhole</option>
                                <option value="reject">reject</option>
                            </select>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="frr_static_onlink">On-link</label>
                            <label class="std-switch">
                                <input type="checkbox" id="frr_static_onlink">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <div class="form-col">
                            <label for="frr_static_desc">Description</label>
                            <input type="text" id="frr_static_desc" class="std-input" placeholder="Optional">
                        </div>
                    </div>
                    <div class="form-row">
                        <button type="button" class="std-btn" data-js="frr-static-route-save">Save</button>
                        <button type="button" class="std-btn std-btn--secondary"
                            data-js="frr-static-toggle-form"
                            data-target="frr-static-add-form">Cancel</button>
                    </div>
                </form>
            </div>

            <table class="std-table">
                <thead>
                    <tr><th>Network</th><th>Gateway</th><th>Interface</th><th>Distance</th><th>Metric</th><th>Tag</th><th>Table</th><th>Type</th><th>Actions</th></tr>
                </thead>
                <tbody>
                <?php if (empty($routes)): ?>
                    <tr class="std-table-empty"><td colspan="9">No static routes configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($routes as $r): ?>
                    <tr data-route-id="<?= $r['id'] ?>">
                        <td><?= $r['network_label'] ?></td>
                        <td><?= $r['gateway_label'] ?></td>
                        <td><?= $r['interface_label'] ?></td>
                        <td><?= $r['distance'] ?></td>
                        <td><?= $r['metric'] ?></td>
                        <td><?= $r['route_tag_label'] ?></td>
                        <td><?= $r['table_label'] ?></td>
                        <td><span class="std-badge"><?= $r['type'] ?? 'unicast' ?></span></td>
                        <td>
                            <?php if (!empty($r['can_delete'])): ?>
                            <button type="button" class="std-btn std-btn--sm js-frr-static-edit"
                                data-id="<?= $r['id'] ?>"
                                data-network="<?= $r['network'] ?>"
                                data-network-display="<?= $r['network_display']['name'] ?? '' ?>"
                                data-gateway="<?= $r['gateway'] ?? '' ?>"
                                data-gateway-display="<?= $r['gateway_display']['name'] ?? '' ?>"
                                data-interface="<?= $r['interface'] ?? '' ?>"
                                data-distance="<?= $r['distance'] ?? '' ?>"
                                data-metric="<?= $r['metric'] ?? '' ?>"
                                data-route-tag="<?= $r['route_tag'] ?? '' ?>"
                                data-route-tag-display="<?= $r['route_tag_display']['name'] ?? $r['route_tag_display']['value'] ?? '' ?>"
                                data-weight="<?= $r['weight'] ?? '' ?>"
                                data-table="<?= $r['table'] ?? '' ?>"
                                data-table-display="<?= $r['table_display']['name'] ?? $r['table_display']['value'] ?? '' ?>"
                                data-vrf="<?= $r['vrf'] ?? '' ?>"
                                data-nh-vrf="<?= $r['nexthop_vrf'] ?? '' ?>"
                                data-type="<?= $r['type'] ?? 'unicast' ?>"
                                data-onlink="<?= $r['onlink_flag'] ?>"
                                data-desc="<?= $r['description'] ?? '' ?>"
                            >Edit</button>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="frr-static-delete" data-id="<?= $r['id'] ?>">Delete</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
