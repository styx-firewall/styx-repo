<?php
/**
 * Unified Firewall Logs (Local & Forward) with Tabs
 * @var array<mixed> $tdata
 * fw-logs-firewall.js
 */
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Firewall Logs</h1>
        <div class="fw-logs-toolbar">
            <button id="fw-logs-toggle-autorefresh" class="std-btn btn-pad">Pause Auto-refresh</button>
            <label class="fw-logs-interval-label">
                Refresh interval (s):
                <input
                    type="number"
                    id="fw-logs-refresh-interval"
                    min="2"
                    step="1"
                    value="20"
                    class="fw-logs-interval-input"
                    size="4"
                >
            </label>
        </div>
        <div class="tab-container">
            <div class="std-tabs" id="fw-logs-tabs">
                <!-- Hook 13 -->                 
                <button class="std-tab-btn tab-btn active" data-tab="local">Local</button>                
                <!-- Hook 2 -->
                <button class="std-tab-btn tab-btn" data-tab="forward">Forward</button>                                
                <!-- Hook 0
                <button class="std-tab-btn tab-btn" data-tab="prerouting">PreRouting</button>
                -->
                <!-- Hook 4 
                <button class="std-tab-btn tab-btn" data-tab="postrouting">PostRouting</button>
                -->
                <!-- Hook 40 
                <button class="std-tab-btn tab-btn" data-tab="prepost">Pre/PostRouting</button>
                -->

            </div>
        </div>
        <div class="content-box">
            <div id="fw-logs-local-panel" class="tab-panel std-tab-panel active">
                <!-- Local logs UI will be rendered here -->
                <form id="log-filters-form-local" class="log-filters-form">
                    <label>
                        Limit:
                        <input
                            type="number"
                            id="log-limit-local"
                            min="10"
                            max="1000"
                            step="10"
                            value="20"
                            class="log-limit"
                        >
                    </label>
                    <input type="text" id="fw-query-local" class="fw-query-input" placeholder='e.g. src_ip == "10.0.0.1" AND protocol == "tcp"' autocomplete="off">
                    <button type="button" class="std-btn btn-pad js-fw-query-help" data-tab="local">Keys &#9660;</button>
                    <button type="submit" class="std-btn btn-pad">Apply</button>
                    <button type="button" class="std-btn btn-pad fw-query-clear" data-tab="local">Clear</button>
                </form>
                <div id="fw-query-keys-local" class="fw-query-keys" hidden></div>
                <div id="column-controls-local"></div>
                <table class="std-table" id="dynamic-table-local"></table>
            </div>
            <div id="fw-logs-prerouting-panel" class="tab-panel std-tab-panel">
                <!-- PreRouting logs UI -->
                <form id="log-filters-form-prerouting" class="log-filters-form">
                    <label>
                        Limit:
                        <input
                            type="number"
                            id="log-limit-prerouting"
                            min="10"
                            max="1000"
                            step="10"
                            value="20"
                            class="log-limit"
                        >
                    </label>
                    <input type="text" id="fw-query-prerouting" class="fw-query-input" placeholder='e.g. src_ip == "10.0.0.1" AND protocol == "tcp"' autocomplete="off">
                    <button type="button" class="std-btn btn-pad js-fw-query-help" data-tab="prerouting">Keys &#9660;</button>
                    <button type="submit" class="std-btn btn-pad">Apply</button>
                    <button type="button" class="std-btn btn-pad fw-query-clear" data-tab="prerouting">Clear</button>
                </form>
                <div id="fw-query-keys-prerouting" class="fw-query-keys" hidden></div>
                <div id="column-controls-prerouting"></div>
                <table class="std-table" id="dynamic-table-prerouting"></table>
            </div>
            <div id="fw-logs-postrouting-panel" class="tab-panel std-tab-panel">
                <!-- PostRouting logs UI -->
                <form id="log-filters-form-postrouting" class="log-filters-form">
                    <label>
                        Limit:
                        <input
                            type="number"
                            id="log-limit-postrouting"
                            min="10"
                            max="1000"
                            step="10"
                            value="20"
                            class="log-limit"
                        >
                    </label>
                    <input type="text" id="fw-query-postrouting" class="fw-query-input" placeholder='e.g. src_ip == "10.0.0.1" AND protocol == "tcp"' autocomplete="off">
                    <button type="button" class="std-btn btn-pad js-fw-query-help" data-tab="postrouting">Keys &#9660;</button>
                    <button type="submit" class="std-btn btn-pad">Apply</button>
                    <button type="button" class="std-btn btn-pad fw-query-clear" data-tab="postrouting">Clear</button>
                </form>
                <div id="fw-query-keys-postrouting" class="fw-query-keys" hidden></div>
                <div id="column-controls-postrouting"></div>
                <table class="std-table" id="dynamic-table-postrouting"></table>
            </div>
            <div id="fw-logs-prepost-panel" class="tab-panel std-tab-panel">
                <!-- Pre/PostRouting logs UI -->
                <form id="log-filters-form-prepost" class="log-filters-form">
                    <label>
                        Limit:
                        <input
                            type="number"
                            id="log-limit-prepost"
                            min="10"
                            max="1000"
                            step="10"
                            value="20"
                            class="log-limit"
                        >
                    </label>
                    <input type="text" id="fw-query-prepost" class="fw-query-input" placeholder='e.g. src_ip == "10.0.0.1" AND protocol == "tcp"' autocomplete="off">
                    <button type="button" class="std-btn btn-pad js-fw-query-help" data-tab="prepost">Keys &#9660;</button>
                    <button type="submit" class="std-btn btn-pad">Apply</button>
                    <button type="button" class="std-btn btn-pad fw-query-clear" data-tab="prepost">Clear</button>
                </form>
                <div id="fw-query-keys-prepost" class="fw-query-keys" hidden></div>
                <div id="column-controls-prepost"></div>
                <table class="std-table" id="dynamic-table-prepost"></table>
            </div>
            <div id="fw-logs-forward-panel" class="tab-panel std-tab-panel">
                <!-- Forward logs UI will be rendered here -->
                <form id="log-filters-form-forward" class="log-filters-form">
                    <label>
                        Limit:
                        <input
                            type="number"
                            id="log-limit-forward"
                            min="10"
                            max="1000"
                            step="10"
                            value="20"
                            class="log-limit"
                        >
                    </label>
                    <input type="text" id="fw-query-forward" class="fw-query-input" placeholder='e.g. src_ip == "10.0.0.1" AND protocol == "tcp"' autocomplete="off">
                    <button type="button" class="std-btn btn-pad js-fw-query-help" data-tab="forward">Keys &#9660;</button>
                    <button type="submit" class="std-btn btn-pad">Apply</button>
                    <button type="button" class="std-btn btn-pad fw-query-clear" data-tab="forward">Clear</button>
                </form>
                <div id="fw-query-keys-forward" class="fw-query-keys" hidden></div>
                <div id="column-controls-forward"></div>
                <table class="std-table" id="dynamic-table-forward"></table>
            </div>
        </div>
    </main>
</div>
<!-- Log detail modal template -->
<template id="fwlog-modal-tpl">
    <h2 class="fwlog-modal-title">Log Details</h2>
    <table class="fwlog-modal-table">
        <tbody></tbody>
    </table>
</template>

<script>
// Server-provided columns configuration (if formatter supplied it)
window.__fwLogsColumnsByTab = <?php
echo $tdata['page_data']['fw_logs_columns_by_tab_json'];
?>;
</script>
