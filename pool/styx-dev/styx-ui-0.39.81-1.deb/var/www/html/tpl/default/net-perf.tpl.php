<?php
/**
 * Net Performance Template
 * net-perf.js
 * default-iperf.css
 * @var array<mixed> $tdata
 */
$page_data = $tdata['page_data'] ?? [];
$server = $page_data['server'] ?? [
    'running' => false,
    'pid' => null,
    'port' => null,
    'started_at' => null
];
$is_running = $server['running'] ?? false;
// Prefer an explicit response_msg if provided by the request controller
$response_msg = $page_data['response_msg'] ?? ($page_data['error']['response_msg'] ?? null);
$response_is_error = isset($page_data['error']);
?>
<?php if (!empty($response_msg)): ?>
    <div class="page-alert <?= $response_is_error ? 'alert-error' : 'alert-info' ?>" id="iperf-response-msg">
        <?= $response_msg ?>
    </div>
<?php endif; ?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Network Performance (iPerf3)</h1>

        <!-- Server Section -->
        <section class="content-box">
            <h2>iPerf3 Server</h2>
            <div id="server-status" class="iperf-status-panel">
                <div class="status-indicator">
                    <span
                        id="server-status-text"
                        data-status="<?= $is_running ? 'running' : 'stopped' ?>"
                    >
                        <?= $is_running ? 'Running' : 'Stopped' ?>
                    </span>
                    <?php if ($is_running): ?>
                        <span>PID: <?= $server['pid'] ?></span>
                        <span>Port: <?= $server['port'] ?></span>
                        <span>Started: <?= $server['started_at'] ?></span>
                    <?php endif; ?>
                </div>
                <div class="server-controls">
                    <button
                        type="button"
                        id="btn-start-server"
                        class="std-btn"
                        data-js="start-server"
                        <?= $is_running ? 'disabled' : '' ?>
                    >Start Server</button>
                    <button
                        type="button"
                        id="btn-stop-server"
                        class="std-btn"
                        data-js="stop-server"
                        <?= !$is_running ? 'disabled' : '' ?>
                    >Stop Server</button>
                </div>
            </div>

            <details id="server-config-panel">
                <summary>Server Configuration</summary>
                <div class="content-form iperf-form-wrap">
                <form id="iperf-server-form" class="std-form" data-js="server-form">
                    <!-- Hidden dummy fields to reduce browser autofill for username/password -->
                    <input type="text" name="fakeusernameremembered_server" id="fake-user-server" class="hidden" autocomplete="username" />
                    <input type="password" name="fakepasswordremembered_server" id="fake-pass-server" class="hidden" autocomplete="current-password" />
                    <div class="form-grid">
                    <label>
                        Port:
                        <span class="js-info-icon" data-info-modal="help-iperf-server-port"></span>
                        <input
                            type="number"
                            name="port"
                            value="5201"
                            min="1"
                            max="65535"
                            data-field="port"
                        />
                    </label>
                    <label>
                        Bind Address:
                        <span class="js-info-icon" data-info-modal="help-iperf-server-bind"></span>
                        <input
                            type="text"
                            name="bind_address"
                            value="0.0.0.0"
                            placeholder="0.0.0.0"
                            data-field="bind_address"
                        />
                    </label>
                    <label>
                        One-off (exit after one test):
                        <span class="js-info-icon" data-info-modal="help-iperf-server-oneoff"></span>
                        <input
                            type="checkbox"
                            name="one_off"
                            data-field="one_off"
                        />
                    </label>
                    <label>
                        UDP mode:
                        <span class="js-info-icon" data-info-modal="help-iperf-server-udp"></span>
                        <input
                            type="checkbox"
                            name="udp"
                            data-field="udp"
                        />
                    </label>
                    <details>
                        <summary>Advanced Server Options</summary>
                        <label>
                            Window size:
                            <span class="js-info-icon" data-info-modal="help-iperf-server-window"></span>
                            <input
                                type="text"
                                name="window"
                                placeholder="256K"
                                data-field="window"
                            />
                        </label>
                        <label>
                            TOS/DSCP:
                            <span class="js-info-icon" data-info-modal="help-iperf-server-tos"></span>
                            <input
                                type="number"
                                name="tos"
                                min="0"
                                max="255"
                                data-field="tos"
                            />
                        </label>
                        <label>
                            Force flush:
                            <span class="js-info-icon" data-info-modal="help-iperf-server-forceflush"></span>
                            <input
                                type="checkbox"
                                name="forceflush"
                                data-field="forceflush"
                            />
                        </label>
                        <label>
                            Username:
                            <span class="js-info-icon" data-info-modal="help-iperf-server-username"></span>
                            <input
                                type="text"
                                name="username"
                                data-field="username"
                                autocomplete="off"
                                autocorrect="off"
                                autocapitalize="off"
                                spellcheck="false"
                                readonly
                                onfocus="this.removeAttribute('readonly');"
                            />
                        </label>
                        <label>
                            Password:
                            <span class="js-info-icon" data-info-modal="help-iperf-server-password"></span>
                            <input
                                type="password"
                                name="password"
                                data-field="password"
                                autocomplete="off"
                                autocorrect="off"
                                autocapitalize="off"
                                spellcheck="false"
                                readonly
                                onfocus="this.removeAttribute('readonly');"
                            />
                        </label>
                    </details>
                    </div>
                </form>
                </div>
            </details>
        </section>

        <!-- Client Section -->
        <section class="content-box">
            <h2>iPerf3 Client</h2>
            <div class="content-form iperf-form-wrap">
            <form id="iperf-client-form" class="std-form" data-js="client-form">
                <!-- Hidden dummy fields to reduce browser autofill for username/password -->
                <input type="text" name="fakeusernameremembered_client" id="fake-user-client" class="hidden" autocomplete="username" />
                <input type="password" name="fakepasswordremembered_client" id="fake-pass-client" class="hidden" autocomplete="current-password" />
                <div class="form-grid">
                <label>
                    Server IP: <span class="required">*</span>
                    <span class="js-info-icon" data-info-modal="help-iperf-client-server-ip"></span>
                    <input
                        type="text"
                        name="server_ip"
                        placeholder="192.168.1.1"
                        required
                        data-field="server_ip"
                    />
                </label>
                <label>
                    Port:
                    <span class="js-info-icon" data-info-modal="help-iperf-client-port"></span>
                    <input
                        type="number"
                        name="port"
                        value="5201"
                        min="1"
                        max="65535"
                        data-field="port"
                    />
                </label>
                <label>
                    Duration (seconds):
                    <span class="js-info-icon" data-info-modal="help-iperf-client-duration"></span>
                    <input
                        type="number"
                        name="duration"
                        value="10"
                        min="1"
                        max="3600"
                        data-field="duration"
                    />
                </label>
                <label>
                    Parallel streams:
                    <span class="js-info-icon" data-info-modal="help-iperf-client-parallel"></span>
                    <input
                        type="number"
                        name="parallel"
                        value="1"
                        min="1"
                        max="32"
                        data-field="parallel"
                    />
                </label>
                <label>
                    Bandwidth limit:
                    <span class="js-info-icon" data-info-modal="help-iperf-client-bandwidth"></span>
                    <input
                        type="text"
                        name="bandwidth"
                        placeholder="0 (unlimited) or 100M"
                        data-field="bandwidth"
                    />
                </label>
                <label>
                    UDP mode:
                    <span class="js-info-icon" data-info-modal="help-iperf-client-udp"></span>
                    <input
                        type="checkbox"
                        name="udp"
                        data-field="udp"
                    />
                </label>
                <label>
                    Reverse (server sends):
                    <span class="js-info-icon" data-info-modal="help-iperf-client-reverse"></span>
                    <input
                        type="checkbox"
                        name="reverse"
                        data-field="reverse"
                    />
                </label>
                <label>
                    Interval (seconds):
                    <span class="js-info-icon" data-info-modal="help-iperf-client-interval"></span>
                    <input
                        type="number"
                        name="interval"
                        value="1"
                        min="1"
                        max="10"
                        data-field="interval"
                    />
                </label>

                <details>
                    <summary>Advanced Client Options</summary>
                    <label>
                        Window size:
                        <input
                            type="text"
                            name="window"
                            placeholder="256K"
                            data-field="window"
                        />
                    </label>
                    <label>
                        TOS/DSCP:
                        <input
                            type="number"
                            name="tos"
                            min="0"
                            max="255"
                            data-field="tos"
                        />
                    </label>
                    <label>
                        Omit (seconds):
                        <input
                            type="number"
                            name="omit"
                            min="0"
                            max="60"
                            data-field="omit"
                        />
                    </label>
                    <label>
                        Force flush:
                        <input
                            type="checkbox"
                            name="forceflush"
                            data-field="forceflush"
                        />
                    </label>
                    <label>
                        Get server output:
                        <input
                            type="checkbox"
                            name="get_server_output"
                            data-field="get_server_output"
                        />
                    </label>
                    <label>
                        Verbose:
                        <input
                            type="checkbox"
                            name="verbose"
                            data-field="verbose"
                        />
                    </label>
                    <label>
                        Username:
                        <input
                            type="text"
                            name="username"
                            data-field="username"
                            autocomplete="off"
                            autocorrect="off"
                            autocapitalize="off"
                            spellcheck="false"
                            readonly
                            onfocus="this.removeAttribute('readonly');"
                        />
                    </label>
                    <label>
                        Password:
                        <input
                            type="password"
                            name="password"
                            data-field="password"
                            autocomplete="off"
                            autocorrect="off"
                            autocapitalize="off"
                            spellcheck="false"
                            readonly
                            onfocus="this.removeAttribute('readonly');"
                        />
                    </label>
                </details>

                <button type="submit" class="std-btn" data-js="start-test">Start Test</button>
                </div>
            </form>
            </div>
        </section>

        <!-- Help blocks for iPerf forms -->
        <div id="help-iperf-server-port" class="hidden"><p><strong>Port</strong>: TCP port where the iPerf3 server listens (1-65535).</p></div>
        <div id="help-iperf-server-bind" class="hidden"><p><strong>Bind Address</strong>: IP address the server binds to (0.0.0.0 for all).</p></div>
        <div id="help-iperf-server-oneoff" class="hidden"><p><strong>One-off</strong>: If enabled, server exits after a single test.</p></div>
        <div id="help-iperf-server-udp" class="hidden"><p><strong>UDP mode</strong>: Use UDP instead of TCP for tests.</p></div>
        <div id="help-iperf-server-window" class="hidden"><p><strong>Window size</strong>: TCP window buffer size (e.g. 256K).</p></div>
        <div id="help-iperf-server-tos" class="hidden"><p><strong>TOS/DSCP</strong>: Type of Service / DSCP value for packets (0-255).</p></div>
        <div id="help-iperf-server-forceflush" class="hidden"><p><strong>Force flush</strong>: Force socket flush after each report.</p></div>
        <div id="help-iperf-server-username" class="hidden"><p><strong>Username</strong>: Optional username for authenticated tests (readonly until focused).</p></div>
        <div id="help-iperf-server-password" class="hidden"><p><strong>Password</strong>: Optional password for authenticated tests (readonly until focused).</p></div>

        <div id="help-iperf-client-server-ip" class="hidden"><p><strong>Server IP</strong>: Target iPerf3 server IP address to test against.</p></div>
        <div id="help-iperf-client-port" class="hidden"><p><strong>Port</strong>: TCP/UDP port used by the server (default 5201).</p></div>
        <div id="help-iperf-client-duration" class="hidden"><p><strong>Duration</strong>: Test duration in seconds.</p></div>
        <div id="help-iperf-client-parallel" class="hidden"><p><strong>Parallel streams</strong>: Number of concurrent streams.</p></div>
        <div id="help-iperf-client-bandwidth" class="hidden"><p><strong>Bandwidth limit</strong>: e.g. 100M for 100 Mbps or 0 for unlimited.</p></div>
        <div id="help-iperf-client-udp" class="hidden"><p><strong>UDP mode</strong>: Send UDP traffic instead of TCP.</p></div>
        <div id="help-iperf-client-reverse" class="hidden"><p><strong>Reverse</strong>: Run the test in reverse (server sends to client).</p></div>
        <div id="help-iperf-client-interval" class="hidden"><p><strong>Interval</strong>: Reporting interval in seconds.</p></div>

        <!-- Active Tasks -->
        <section class="content-box">
            <h2>Active Tasks</h2>
            <div id="tasks-list" data-js="tasks-list">
                <p>No active tasks</p>
            </div>
        </section>

        <!-- Test Results -->
        <section class="content-box">
            <h2>Test Results</h2>
            <div id="iperf-results" data-js="results-container"></div>
            <div id="iperf-graphs" class="iperf-graphs" data-js="graphs-container"></div>
        </section>
    </main>
</div>

