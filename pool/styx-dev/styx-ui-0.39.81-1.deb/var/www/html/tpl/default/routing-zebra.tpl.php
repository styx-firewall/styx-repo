<?php
/** FRR Zebra config @var array<mixed> $tdata js: scripts/routing/routing-zebra.js */
$page_data = $tdata['page_data'] ?? [];
$zc = $page_data['zebra_config'] ?? [];
$can_save = !empty($page_data['can_save']);
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>Zebra</h1>

        <details class="nat-help">
            <summary>Help</summary>
            <div class="nat-help-content">
                <p><strong>Zebra</strong> is the FRR daemon that manages the kernel routing table and provides the RIB (Routing Information Base) for all other FRR protocols.</p>
                <ul>
                    <li><strong>Router ID:</strong> 32-bit identifier used as default for protocols that don't set their own.</li>
                    <li><strong>NHT via Default:</strong> Allow nexthop tracking to resolve via the default route. Enable if routes point to nexthops reachable only through the default gateway.</li>
                </ul>
            </div>
        </details>
        <div class="content-box">
            <h2>Configuration</h2>
            <form class="std-form form-compact" data-js="zebra-config-form">
                <div class="form-row">
                    <div class="form-col">
                        <label>Router ID</label>
                        <div class="set-picker-field" data-js="label-picker-field" data-set-type="router_id"
                             data-max-select="1" data-label-title="Select Router ID">
                            <input type="hidden" id="zebra_router_id" value="<?= $zc['router_id'] ?? '' ?>">
                            <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                data-placeholder="Select Router ID">
                                <span class="js-set-picker-label"><?= $zc['router_id_label'] ?></span>
                            </button>
                            <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear<?= $zc['router_id_clear_hidden'] ?>"
                                title="Clear">&#215;</button>
                        </div>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="zebra_ip_nht">IPv4 NHT via Default</label>
                        <label class="std-switch">
                            <input type="checkbox" id="zebra_ip_nht"
                                <?= !empty($zc['ip_nht_resolve_via_default']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="zebra_ipv6_nht">IPv6 NHT via Default</label>
                        <label class="std-switch">
                            <input type="checkbox" id="zebra_ipv6_nht"
                                <?= !empty($zc['ipv6_nht_resolve_via_default']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-col form-col--tight">
                        <label for="zebra_nhg_keep">Nexthop Group Keep (s)</label>
                        <input type="number" id="zebra_nhg_keep" class="std-input" min="1" max="3600"
                            value="<?= $zc['nexthop_group_keep'] ?? 180 ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="zebra_rm_delay">Route Map Delay Timer (s)</label>
                        <input type="number" id="zebra_rm_delay" class="std-input" min="0" max="600"
                            value="<?= $zc['route_map_delay_timer'] ?? 0 ?>">
                    </div>
                </div>
                <?php if ($can_save): ?>
                <button type="button" class="std-btn" data-js="zebra-save-config">Save</button>
                <?php endif; ?>
            </form>
        </div>

        <div class="content-box">
            <h2>Protocol Route Maps</h2>
            <p class="std-hint">Assign route-maps to protocol routes processed by the Zebra RIB.</p>
            <form class="std-form form-compact" data-js="zebra-protocol-rm-form">
                <?php foreach ($page_data['zebra_protocol_rm'] ?? [] as $prm): ?>
                    <div class="form-row">
                        <div class="form-col form-col--tight">
                            <label class="std-checkbox-label">
                                <input type="checkbox" class="js-zebra-proto-rm" value="<?= $prm['proto'] ?>"
                                    <?= $prm['checked'] ?>>
                                <?= $prm['label'] ?>
                            </label>
                        </div>
                        <div class="form-col">
                            <select class="std-input js-zebra-proto-rm-map" data-proto="<?= $prm['proto'] ?>"
                                style="width:auto; min-width:180px;">
                                <option value="">- No route map -</option>
                                <?php foreach ($prm['route_maps'] as $rmap): ?>
                                <option value="<?= $rmap['id'] ?>"
                                    <?= $rmap['selected'] ?>>
                                    <?= $rmap['name'] ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php if ($can_save): ?>
                <button type="button" class="std-btn" data-js="zebra-save-config">Save</button>
                <?php endif; ?>
            </form>
        </div>
    </main>
</div>
