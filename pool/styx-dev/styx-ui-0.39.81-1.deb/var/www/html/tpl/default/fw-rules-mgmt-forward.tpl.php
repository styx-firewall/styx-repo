<?php
/**
 * TemplateService->getTpl()
 * @var array<mixed> $tdata
 * Included
 * firewall-mgmt-rules.js
 * Presentation data prepared by FwRulesMgmtForwardFormatter (echo-only template).
 */

$ui = $tdata['page_data']['rule_ui'] ?? [];
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
    <h1><?= $ui['title'] ?></h1>
    <h2>Forward rule management</h2>
        <div class="content-box">
            <?php if (!empty($ui['error'])): ?>
                <div class="error-message fw-error-message">
                    <strong>Error:</strong> <?= $ui['error'] ?>
                </div>
                </div></main></div> <!-- END/FINISH THE TEMPLATE -->
                <?php return; endif; ?>
            <form id="firewall-rule-forward-form" class="std-form fw-maxwidth" method="post"
                action="?page=firewall&section=rules_mgmt_forward"
                <?= $ui['is_system_rule'] ? 'data-system-rule="1"' : '' ?>
                <?= $ui['end_of_chain'] ? 'data-end-of-chain="1"' : '' ?>
                data-redirect-section="fw-rules-forward">
                <input type="hidden" name="command" value="<?= $ui['command'] ?>">
                <input type="hidden" name="table" value="filter" data-field="table">
                <input type="hidden" name="chain" value="forward" data-field="chain">
                <?php if (!empty($ui['rule_id'])): ?>
                    <input type="hidden" name="id" value="<?= $ui['rule_id'] ?>">
                <?php endif; ?>
                <h3 class="form-section-title">Identification</h3>
                <div class="std-flex-row">
                    <label>Rule name
                        <span class="js-info-icon" data-info-modal="help-rule-name"></span>
                        <input type="text" name="name" id="rule-name" data-field="name" required maxlength="64"
                            placeholder="E.g.: Rule name"
                            value="<?= $ui['name'] ?>">
                    </label>
                    <label>Comment
                        <span class="js-info-icon" data-info-modal="help-comment"></span>
                        <input type="text" name="comment" id="rule-comment" data-field="comment" maxlength="128"
                            placeholder="Optional comment"
                            value="<?= $ui['comment'] ?>">
                    </label>
                </div>
                <h3 class="form-section-title">Context</h3>
                <div class="std-flex-row">
                    <label>Family
                        <span class="js-info-icon" data-info-modal="help-family"></span>
                        <select name="family" id="rule-family" data-field="family" required>
                            <?php foreach ($ui['family_options'] as $opt): ?>
                                <option value="<?= $opt['value'] ?>" <?= $opt['selected'] ? 'selected' : '' ?>>
                                    <?= $opt['label'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label>Input interface set
                        <span class="js-info-icon" data-info-modal="help-input-ifaces"></span>
                        <div class="set-picker-field" data-js="set-picker-field"
                            data-set-type="interfaces" data-max-select="20">
                            <input type="hidden" data-field="src_ifaces" data-picker-array="true"
                                value="<?= $ui['src_ifaces']['ids'] ?>">
                            <button type="button"
                                class="set-picker-trigger js-set-picker-open<?= $ui['src_ifaces']['hasVal'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="Any (select interface sets...)">
                                <span class="js-set-picker-label">
                                    <?= $ui['src_ifaces']['hasVal'] ? $ui['src_ifaces']['names'] : 'Any (select interface sets...)' ?>
                                </span>
                            </button>
                            <button type="button"
                                class="set-picker-clear js-set-picker-clear<?= $ui['src_ifaces']['hasVal'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                    <label>Output interface set
                        <span class="js-info-icon" data-info-modal="help-output-ifaces"></span>
                        <div class="set-picker-field" data-js="set-picker-field"
                            data-set-type="interfaces" data-max-select="20">
                            <input type="hidden" data-field="dst_ifaces" data-picker-array="true"
                                value="<?= $ui['dst_ifaces']['ids'] ?>">
                            <button type="button"
                                class="set-picker-trigger js-set-picker-open<?= $ui['dst_ifaces']['hasVal'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="Any (select interface sets...)">
                                <span class="js-set-picker-label">
                                    <?= $ui['dst_ifaces']['hasVal'] ? $ui['dst_ifaces']['names'] : 'Any (select interface sets...)' ?>
                                </span>
                            </button>
                            <button type="button"
                                class="set-picker-clear js-set-picker-clear<?= $ui['dst_ifaces']['hasVal'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                </div>
                <h3 class="form-section-title">Traffic matching - Layer 3</h3>
                <div class="std-flex-row">
                    <label>Source IP(s)
                        <span class="js-info-icon" data-info-modal="help-src-ips"></span>
                        <div class="set-picker-field" data-js="set-picker-field"
                            data-set-type="address" data-max-select="20">
                            <input type="hidden" data-field="src_ips" data-picker-array="true"
                                value="<?= $ui['src_ips']['ids'] ?>">
                            <button type="button"
                                class="set-picker-trigger js-set-picker-open<?= $ui['src_ips']['hasVal'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="Any (select address sets...)">
                                <span class="js-set-picker-label">
                                    <?= $ui['src_ips']['hasVal'] ? $ui['src_ips']['names'] : 'Any (select address sets...)' ?>
                                </span>
                            </button>
                            <button type="button"
                                class="set-picker-clear js-set-picker-clear<?= $ui['src_ips']['hasVal'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                    <label>Destination IP(s)
                        <span class="js-info-icon" data-info-modal="help-dst-ips"></span>
                        <div class="set-picker-field" data-js="set-picker-field"
                            data-set-type="address" data-max-select="20">
                            <input type="hidden" data-field="dst_ips" data-picker-array="true"
                                value="<?= $ui['dst_ips']['ids'] ?>">
                            <button type="button"
                                class="set-picker-trigger js-set-picker-open<?= $ui['dst_ips']['hasVal'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="Any (select address sets...)">
                                <span class="js-set-picker-label">
                                    <?= $ui['dst_ips']['hasVal'] ? $ui['dst_ips']['names'] : 'Any (select address sets...)' ?>
                                </span>
                            </button>
                            <button type="button"
                                class="set-picker-clear js-set-picker-clear<?= $ui['dst_ips']['hasVal'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                    <label>Packet mark (fwmark)
                        <span class="js-info-icon" data-info-modal="help-fwmark"></span>
                        <div class="set-picker-field" data-js="label-picker-field"
                            data-set-type="packet_marking"
                            data-max-select="1" data-label-title="Select packet mark">
                            <input type="hidden" data-field="fwmark"
                                value="<?= $ui['fwmark_id'] ?>">
                            <button type="button"
                                class="std-btn-picker set-picker-trigger js-set-picker-open<?= $ui['fwmark_id'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="None (select mark...)">
                                <span class="js-set-picker-label"><?= $ui['fwmark_id'] ?: 'None (select mark...)' ?></span>
                            </button>
                            <button type="button"
                                class="std-btn-picker set-picker-clear js-set-picker-clear<?= $ui['fwmark_id'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                </div>
                <h3 class="form-section-title">Traffic matching - Layer 4</h3>
                <div class="std-flex-row">
                    <label>Protocol
                        <span class="js-info-icon" data-info-modal="help-protocol"></span>
                        <select name="protocol" id="rule-protocol" class="std-select" data-field="protocol">
                            <?php foreach ($ui['protocol_options'] as $opt): ?>
                                <option value="<?= $opt['value'] ?>" <?= $opt['selected'] ? 'selected' : '' ?>>
                                    <?= $opt['label'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label id="src-ports-field">Source port(s)
                        <span class="js-info-icon" data-info-modal="help-src-ports"></span>
                        <div class="set-picker-field" data-js="set-picker-field"
                            data-set-type="ports" data-max-select="20">
                            <input type="hidden" data-field="src_ports" data-picker-array="true"
                                value="<?= $ui['src_ports']['ids'] ?>">
                            <button type="button"
                                class="set-picker-trigger js-set-picker-open<?= $ui['src_ports']['hasVal'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="Any (select port sets...)">
                                <span class="js-set-picker-label">
                                    <?= $ui['src_ports']['hasVal'] ? $ui['src_ports']['names'] : 'Any (select port sets...)' ?>
                                </span>
                            </button>
                            <button type="button"
                                class="set-picker-clear js-set-picker-clear<?= $ui['src_ports']['hasVal'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                    <label id="dst-ports-field">Destination port(s)
                        <span class="js-info-icon" data-info-modal="help-dst-ports"></span>
                        <div class="set-picker-field" data-js="set-picker-field"
                            data-set-type="ports" data-max-select="20">
                            <input type="hidden" data-field="dst_ports" data-picker-array="true"
                                value="<?= $ui['dst_ports']['ids'] ?>">
                            <button type="button"
                                class="set-picker-trigger js-set-picker-open<?= $ui['dst_ports']['hasVal'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="Any (select port sets...)">
                                <span class="js-set-picker-label">
                                    <?= $ui['dst_ports']['hasVal'] ? $ui['dst_ports']['names'] : 'Any (select port sets...)' ?>
                                </span>
                            </button>
                            <button type="button"
                                class="set-picker-clear js-set-picker-clear<?= $ui['dst_ports']['hasVal'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                </div>
                <h3 class="form-section-title">Action</h3>
                <div class="std-flex-row">
                    <label>Action
                        <span class="js-info-icon" data-info-modal="help-action"></span>
                        <select name="action" id="rule-action" class="std-select" data-field="action" required>
                            <?php foreach ($ui['action_options'] as $opt): ?>
                                <option value="<?= $opt['value'] ?>" <?= $opt['selected'] ? 'selected' : '' ?>>
                                    <?= $opt['label'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label>Rate limit
                        <span class="js-info-icon" data-info-modal="help-rate-limit"></span>
                        <input type="text" name="log_limit" id="rule-log-limit" data-field="log_limit"
                            placeholder="E.g.: 10/minute"
                            value="<?= $ui['log_limit'] ?>">
                    </label>
                </div>
                <!-- Time restriction -->
                <div class="std-flex-row">
                    <div class="std-collapse-box">
                        <div class="std-collapse-header">Time restriction (optional)</div>
                        <div class="std-collapse-content">
                            <fieldset class="fieldset-no-border">
                                <label>Start time
                                    <span class="js-info-icon" data-info-modal="help-time-restriction"></span>
                                    <input type="time" name="time[start]"
                                        value="<?= $ui['time_start'] ?>">
                                </label>
                                <label>End time
                                    <input type="time" name="time[stop]"
                                        value="<?= $ui['time_stop'] ?>">
                                </label>
                                <label>Days of the week
                                    <select name="time[days][]" multiple size="4">
                                        <?php foreach ($ui['days_options'] as $opt): ?>
                                            <option value="<?= $opt['value'] ?>" <?= $opt['selected'] ? 'selected' : '' ?>>
                                                <?= $opt['label'] ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <small>Ctrl+Click to select multiple</small>
                                </label>
                            </fieldset>
                        </div>
                    </div>
                </div>
                <div class="std-flex-row">
                    <label class="std-switch">
                        <input type="checkbox" name="enabled" value="1"
                            <?= $ui['enabled_checked'] ? 'checked' : '' ?>>
                        <span class="std-switch-slider" data-on="Enabled" data-off="Disabled"></span>
                    </label>
                    <label class="std-switch">
                        <input type="checkbox" name="log" id="rule-log" value="1"
                            <?= $ui['log_checked'] ? 'checked' : '' ?>>
                        <span class="std-switch-slider" data-on="LOG" data-off="LOG"></span>
                    </label>
                    <label class="std-switch">
                        <input type="checkbox" name="nat" value="1"
                            <?= $ui['nat_checked'] ? 'checked' : '' ?> data-field="nat">
                        <span class="std-switch-slider" data-on="NAT" data-off="NAT"></span>
                    </label>
                </div>
                <div class="std-flex-row" id="icmp-type-row">
                    <label>ICMP type
                        <span class="js-info-icon" data-info-modal="help-icmp-type"></span>
                        <input type="text" list="icmp-types" name="icmp_type" id="rule-icmp-type"
                            placeholder="e.g. 0,1,4,5 (comma separated) or pick below..."
                            value="<?= $ui['icmp_csv'] ?>">
                        <datalist id="icmp-types">
                            <option value="8">8 - Echo Request</option>
                            <option value="0">0 - Echo Reply</option>
                            <option value="3">3 - Destination Unreachable</option>
                            <option value="11">11 - Time Exceeded</option>
                            <option value="5">5 - Redirect</option>
                            <option value="12">12 - Parameter Problem</option>
                            <option value="13">13 - Timestamp</option>
                            <option value="14">14 - Timestamp Reply</option>
                            <option value="17">17 - Address Mask Request</option>
                            <option value="18">18 - Address Mask Reply</option>
                        </datalist>
                        <div class="icmp-common-types">
                            <?php foreach ($ui['icmp_common'] as $cb): ?>
                                <label class="inline-flex-center">
                                    <input type="checkbox" name="icmp_common[]" value="<?= $cb['value'] ?>"
                                        <?= $cb['checked'] ? 'checked' : '' ?>>
                                    <?= $cb['value'] ?> - <?= $cb['label'] ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <small>Type numbers separated by commas, or pick common types (0-255).</small>
                    </label>
                </div>
                <div class="std-flex-row tcp-flags-row" id="tcp-flags-row">
                    <fieldset class="fieldset-no-border">
                        <legend>Flags TCP <span class="js-info-icon" data-info-modal="help-tcp-flags"></span></legend>
                        <div class="flex-row-gap-1em">
                            <?php foreach ($ui['tcp_flags'] as $flag): ?>
                                <label class="inline-flex-center">
                                    <input type="checkbox"
                                        name="tcp_flags[]"
                                        value="<?= $flag['value'] ?>"
                                        <?= $flag['checked'] ? 'checked' : '' ?>>
                                    <?= $flag['label'] ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>
                </div>
                <div class="std-flex-row">
                    <!-- Firewall rule preview -->
                    <div class="fw-preview">
                        <strong class="fw-preview-title">nft rule preview</strong>
                        <code class="fw-preview-code"></code>
                    </div>
                </div>
                <div class="std-flex-row">
                    <button type="submit" class="std-btn" name="command" value="<?= $ui['command'] ?>">
                        <?= $ui['submit_label'] ?>
                    </button>
                    <?php if ($ui['show_delete']): ?>
                        <button
                            type="submit"
                            class="std-btn std-btn-danger margin-left-1em"
                            name="command"
                            value="delete_firewall_rule"
                            onclick="return confirm('Are you sure you want to delete this rule?');"
                        >
                            Delete rule
                        </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </main>
</div>

<!-- Help content for Forward Rule fields (referenced by data-info-modal) -->
<div id="help-rule-name" class="fw-help">
    <p><strong>Rule name</strong>: A short descriptive name for this rule to show in lists.</p>
</div>
<div id="help-family" class="fw-help">
    <p><strong>Family</strong>: Choose IPv4 or IPv6 to limit matching to the IP family.</p>
</div>
<div id="help-input-ifaces" class="fw-help">
    <p><strong>Input interface set</strong>: Select one or more interface sets that this rule applies to.</p>
</div>
<div id="help-output-ifaces" class="fw-help">
    <p><strong>Output interface set</strong>: Select one or more output interface sets for this rule.</p>
</div>
<div id="help-src-ips" class="fw-help">
    <p><strong>Source IP(s)</strong>: Addresses or address-sets to match as packet sources.</p>
</div>
<div id="help-dst-ips" class="fw-help">
    <p><strong>Destination IP(s)</strong>: Addresses or address-sets to match as packet destinations.</p>
</div>
<div id="help-protocol" class="fw-help">
    <p><strong>Protocol</strong>: Protocol to match (TCP/UDP/ICMP/ESP/AH) or leave empty for any. ESP (50) and AH (51) are IPsec protocols and have no ports.</p>
</div>
<div id="help-src-ports" class="fw-help">
    <p><strong>Source port(s)</strong>: Port names or ranges to match on the source side.</p>
</div>
<div id="help-dst-ports" class="fw-help">
    <p><strong>Destination port(s)</strong>: Port names or ranges to match on the destination side.</p>
</div>
<div id="help-action" class="fw-help">
    <p><strong>Action</strong>: Accept, Drop or Reject the matching traffic.</p>
</div>
<div id="help-rate-limit" class="fw-help">
    <p><strong>Rate limit</strong>: Optional logging/rate limit expression (for example: 10/minute).</p>
</div>
<div id="help-comment" class="fw-help">
    <p><strong>Comment</strong>: Optional free-text note for operator reference.</p>
</div>
<div id="help-time-restriction" class="fw-help">
    <p><strong>Time restriction</strong>: Optional schedule to limit when the rule is active.</p>
</div>
<div id="help-icmp-type" class="fw-help">
    <p><strong>ICMP type</strong>: Numeric ICMP type to match (0-255) or leave empty for all types.</p>
</div>
<div id="help-tcp-flags" class="fw-help">
    <p><strong>TCP Flags</strong>: Match packets by TCP flags (SYN, ACK, FIN, etc.).</p>
</div>
<div id="help-fwmark" class="fw-help">
    <p><strong>Packet mark (fwmark)</strong>: Match packets that have been marked with a specific firewall mark value.
    Select a packet marking label to filter traffic by its mark.</p>
</div>
