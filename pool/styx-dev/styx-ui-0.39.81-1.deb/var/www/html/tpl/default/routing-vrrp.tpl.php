<?php
/**
 * VRRPv3 - Virtual Router Redundancy Protocol
 * @var array<mixed> $tdata
 * js: scripts/routing/routing-vrrp.js
 */
$page_data  = $tdata['page_data'];
$config     = $page_data['vrrp_config'] ?? [];
$defaults   = $page_data['vrrp_global_defaults'] ?? [];
$instances  = $page_data['vrrp_instances'] ?? [];
$ifaces     = $page_data['vrrp_ifaces'] ?? [];
$can_add    = !empty($page_data['can_add']);
$can_save   = !empty($page_data['can_save']);
$vrrp_defaults_json = $page_data['vrrp_defaults_json'] ?? '[]';
?>
<script>
window.__vrrpDefaults = <?= $vrrp_defaults_json ?>;
</script>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>VRRPv3</h1>

        <details class="nat-help">
            <summary>Help</summary>
            <div class="nat-help-content">
                <p><strong>VRRPv3 (Virtual Router Redundancy Protocol)</strong> provides gateway high availability by sharing a virtual IP across multiple routers. One router is elected master based on priority.</p>
                <ul>
                    <li><strong>VRID:</strong> Virtual Router ID (1-255). Must match across all routers in the same group.</li>
                    <li><strong>Priority:</strong> Higher wins the master election (1-254).</li>
                    <li><strong>VIPs:</strong> IPv4 and/or IPv6 virtual addresses that clients use as their default gateway.</li>
                    <li><strong>Preempt:</strong> When enabled, a router with higher priority takes over immediately.</li>
                    <li><strong>Requires:</strong> macvlan interfaces in bridge mode on the parent interface (configured outside FRR).</li>
                </ul>
            </div>
        </details>

        <div class="content-box">
            <h2>Global Configuration</h2>
            <form class="std-form form-compact" data-js="vrrp-config-form">
                <div class="form-row">
                    <div class="form-col form-col--tight">
                        <label for="vrrp_enabled">Enabled</label>
                        <label class="std-switch">
                            <input type="checkbox" id="vrrp_enabled"
                                <?= $config['enabled_checked'] ?? '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="vrrp_def_priority">Default Priority (1-254)</label>
                        <input type="number" id="vrrp_def_priority" class="std-input" min="1" max="254"
                            value="<?= $defaults['priority'] ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="vrrp_def_adv_interval">Default Adv Interval (ms)</label>
                        <input type="number" id="vrrp_def_adv_interval" class="std-input" min="10" max="40950" step="10"
                            value="<?= $defaults['advertisement_interval'] ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="vrrp_def_preempt">Default Preempt</label>
                        <label class="std-switch">
                            <input type="checkbox" id="vrrp_def_preempt"
                                <?= $defaults['preempt_checked'] ?? '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="vrrp_def_shutdown">Default Shutdown</label>
                        <label class="std-switch">
                            <input type="checkbox" id="vrrp_def_shutdown"
                                <?= $defaults['shutdown_checked'] ?? '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="vrrp_def_checksum">Default IPv4 Checksum</label>
                        <label class="std-switch">
                            <input type="checkbox" id="vrrp_def_checksum"
                                <?= $defaults['checksum_checked'] ?? '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <?php if ($can_save): ?>
                <div class="form-row">
                    <button type="button" class="std-btn" data-js="vrrp-save-config">Save</button>
                </div>
                <?php endif; ?>
            </form>
        </div>

        <div class="content-box">
            <div class="content-box-header">
                <h2>VRRP Instances</h2>
                <?php if ($can_add): ?>
                <button type="button" class="std-btn" data-js="vrrp-toggle-form"
                    data-target="vrrp-add-form">+ Add Instance</button>
                <?php endif; ?>
            </div>

            <div class="content-box" id="vrrp-add-form" style="display:none;">
                <h3 id="vrrp-form-title">Add VRRP Instance</h3>
                <form class="std-form form-compact" data-js="vrrp-instance-form">
                    <input type="hidden" id="vrrp_id" value="">
                    <div class="form-row">
                        <div class="form-col">
                            <label for="vrrp_interface">Interface</label>
                            <select id="vrrp_interface" class="std-input">
                                <option value="">Select interface</option>
                                <?php foreach ($ifaces as $iface): ?>
                                <option value="<?= $iface['id'] ?>"><?= $iface['interface'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="vrrp_vrid">VRID (1-255)</label>
                            <input type="number" id="vrrp_vrid" class="std-input" min="1" max="255" required>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="vrrp_priority">Priority (1-254)</label>
                            <input type="number" id="vrrp_priority" class="std-input" min="1" max="254" placeholder="100">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="vrrp_adv_interval">Adv Interval (ms)</label>
                            <input type="number" id="vrrp_adv_interval" class="std-input" min="10" max="40950" step="10" placeholder="1000">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col form-col--tight">
                            <label for="vrrp_preempt">Preempt</label>
                            <label class="std-switch">
                                <input type="checkbox" id="vrrp_preempt" checked>
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="vrrp_shutdown">Shutdown</label>
                            <label class="std-switch">
                                <input type="checkbox" id="vrrp_shutdown">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="vrrp_checksum">IPv4 Checksum</label>
                            <label class="std-switch">
                                <input type="checkbox" id="vrrp_checksum" checked>
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <div class="form-col">
                            <label>IPv4 Virtual Addresses</label>
                            <div class="set-picker-field" data-js="set-picker-field"
                                 data-set-type="address" data-max-select="1"
                                 data-filter-scope="host,set_host">
                                <input type="hidden" id="vrrp_ip_addresses_set" value="">
                                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select address set">
                                    <span class="js-set-picker-label">Select address set</span>
                                </button>
                                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear">&#215;</button>
                            </div>
                        </div>
                        <div class="form-col">
                            <label>IPv6 Virtual Addresses</label>
                            <div class="set-picker-field" data-js="set-picker-field"
                                 data-set-type="address" data-max-select="1"
                                 data-filter-scope="host,set_host">
                                <input type="hidden" id="vrrp_ipv6_addresses_set" value="">
                                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select address set">
                                    <span class="js-set-picker-label">Select address set</span>
                                </button>
                                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear">&#215;</button>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <button type="button" class="std-btn" data-js="vrrp-instance-save">Save</button>
                        <button type="button" class="std-btn std-btn--secondary"
                            data-js="vrrp-toggle-form"
                            data-target="vrrp-add-form">Cancel</button>
                    </div>
                </form>
            </div>

            <table class="std-table">
                <thead>
                    <tr><th>Interface</th><th>VRID</th><th>Priority</th><th>Adv Interval</th><th>Status</th><th>VIPs</th><th>Actions</th></tr>
                </thead>
                <tbody>
                <?php if (empty($instances)): ?>
                    <tr class="std-table-empty"><td colspan="7">No VRRP instances configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($instances as $inst): ?>
                    <tr data-instance-id="<?= $inst['id'] ?>">
                        <td><?= $inst['interface_label'] ?? '' ?></td>
                        <td><?= $inst['vrid'] ?></td>
                        <td><?= $inst['priority'] ?? 100 ?></td>
                        <td><?= $inst['advertisement_interval'] ?? 1000 ?> ms</td>
                        <td><?= $inst['status_badge_html'] ?? '' ?></td>
                        <td style="max-width:200px;word-break:break-all;"><?= $inst['vips_html'] ?? '-' ?></td>
                        <td>
                            <button type="button" class="std-btn std-btn--sm" data-js="vrrp-details"
                                data-detail='<?= $inst['detail_json'] ?? '' ?>'>Details</button>
                            <?php if (!empty($inst['can_delete'])): ?>
                            <button type="button" class="std-btn std-btn--sm js-vrrp-edit"
                                data-id="<?= $inst['id'] ?>"
                                data-interface="<?= $inst['interface'] ?>"
                                data-vrid="<?= $inst['vrid'] ?>"
                                data-priority="<?= $inst['priority'] ?? '' ?>"
                                data-adv-interval="<?= $inst['advertisement_interval'] ?? '' ?>"
                                data-preempt="<?= $inst['preempt_flag'] ?? '0' ?>"
                                data-shutdown="<?= $inst['shutdown_flag'] ?? '0' ?>"
                                data-checksum="<?= $inst['checksum_flag'] ?? '0' ?>"
                                data-ip-addresses-set="<?= $inst['ip_addresses_set'] ?? '' ?>"
                                data-ip-addresses-set-display="<?= $inst['ip_addresses_set_display']['name'] ?? '' ?>"
                                data-ipv6-addresses-set="<?= $inst['ipv6_addresses_set'] ?? '' ?>"
                                data-ipv6-addresses-set-display="<?= $inst['ipv6_addresses_set_display']['name'] ?? '' ?>"
                            >Edit</button>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="vrrp-delete" data-id="<?= $inst['id'] ?>">Delete</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
