<?php
/**
 * HA fragment: event filtering (general.filter).
 *
 * @var array<mixed> $tdata - $tdata['tpl_data'] contains the full formatted HA data
 */
$pd = $tdata['tpl_data'] ?? [];
$config = $pd['config'] ?? [];
$filter = $config['general']['filter'] ?? [];
$protocols = $filter['protocols'] ?? [];
$proto_list = ['TCP', 'SCTP', 'DCCP', 'UDP', 'ICMP', 'IPv6-ICMP'];
$address_sets_map = $pd['address_sets_map'] ?? [];

// Set-picker selection labels (server-side pre-render).
$filter_sets = $filter['address_sets'] ?? [];
$filter_value = implode(',', $filter_sets);
$filter_labels = [];
foreach ($filter_sets as $sid) {
    $filter_labels[] = $address_sets_map[$sid] ?? $sid;
}
$filter_label = implode("\n", $filter_labels);
?>
<div class="content-box">
    <h2>Event Filtering</h2>
    <form class="std-form form-compact" data-js="ha-filter-form">
        <div class="form-row">
            <div class="form-col">
                <label for="ha_filter_from">Filter from</label>
                <select id="ha_filter_from" class="std-input">
                    <?php foreach (['Userspace', 'Kernelspace'] as $f): ?>
                    <option value="<?= $f ?>" <?= ($filter['from'] ?? 'Userspace') === $f ? 'selected' : '' ?>><?= $f ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-col">
                <label for="ha_filter_proto_action">Protocol</label>
                <select id="ha_filter_proto_action" class="std-input">
                    <?php foreach (['accept', 'ignore'] as $a): ?>
                    <option value="<?= $a ?>" <?= ($filter['protocol_action'] ?? 'accept') === $a ? 'selected' : '' ?>><?= ucfirst($a) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <?php foreach ($proto_list as $p): ?>
            <label class="std-checkbox">
                <input type="checkbox" class="ha-proto" value="<?= $p ?>" <?= in_array($p, $protocols, true) ? 'checked' : '' ?>>
                <span><?= $p ?></span>
            </label>
            <?php endforeach; ?>
        </div>
        <div class="form-row">
            <div class="form-col">
                <label for="ha_filter_addr_action">Addresses</label>
                <select id="ha_filter_addr_action" class="std-input">
                    <?php foreach (['accept', 'ignore'] as $a): ?>
                    <option value="<?= $a ?>" <?= ($filter['address_action'] ?? 'ignore') === $a ? 'selected' : '' ?>><?= ucfirst($a) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-col">
                <label>Address sets</label>
                <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-max-select="10"
                    data-filter-family="ip" data-filter-scope="host,network,set_host,set_networks">
                    <input type="hidden" id="ha_filter_address_sets" value="<?= htmlspecialchars($filter_value) ?>">
                    <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                        data-placeholder="Select address sets...">
                        <span class="js-set-picker-label"><?= htmlspecialchars($filter_label ?: 'Select address sets...') ?></span>
                    </button>
                    <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
            </div>
        </div>
    </form>
</div>
