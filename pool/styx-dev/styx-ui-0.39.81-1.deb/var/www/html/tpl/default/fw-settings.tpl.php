<?php

/**
 * TemplateService->getTpl()
 *
 * Included: fw-settings.js
 *
 * @var array<mixed> $tdata
 */
// Presentation data prepared by FwSettingsFormatter (echo-only template).
$ui = $tdata['page_data']['settings_ui'] ?? [];
// Same firewall:write capability used to create/edit rules
$can_edit = !empty($tdata['page_data']['can_create']);
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Firewall Settings</h1>

        <?php if (!empty($ui['error'])): ?>
            <div class="std-error-box">
                <strong>Error:</strong> could not load the firewall settings. Nothing was changed; the toggles are
                disabled until the page is reloaded.
                <?php if (is_string($ui['error'])): ?>
                    <span class="fw-text-muted">(<?= htmlspecialchars($ui['error']) ?>)</span>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <p class="fw-settings-desc">
            Control which system firewall rules are created. Disabling a rule stops it from being applied to
            nftables for both IPv4 and IPv6 of the selected chain; the change takes effect immediately.
        </p>

        <div class="fw-settings-cols">
            <section class="card card--compact">
                <header class="card-header">
                    <h2 class="card-heading">Conntrack bypass</h2>
                </header>
                <div class="card-body">
                    <div class="setting-row">
                        <div>
                            <strong>Conntrack bypass — Forward</strong>
                            <div class="fw-setting-hint">
                                Accept <code>ct state established,related</code> on the forward chain. Disable when
                                asymmetric routing / load balancing makes return traffic not match an existing connection.
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <label class="std-switch">
                                <input type="checkbox"
                                    class="fw-setting-toggle"
                                    data-path="conntrack_bypass.forward"
                                    <?= $ui['cb_forward'] ? 'checked' : '' ?>
                                    <?= $ui['disabled_attr'] ?>>
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                    <div class="setting-row">
                        <div>
                            <strong>Conntrack bypass — Input</strong>
                            <div class="fw-setting-hint">
                                Accept <code>ct state established,related</code> on the input chain.
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <label class="std-switch">
                                <input type="checkbox"
                                    class="fw-setting-toggle"
                                    data-path="conntrack_bypass.input"
                                    <?= $ui['cb_input'] ? 'checked' : '' ?>
                                    <?= $ui['disabled_attr'] ?>>
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                </div>
            </section>

            <section class="card card--compact">
                <header class="card-header">
                    <h2 class="card-heading">Log cache</h2>
                </header>
                <div class="card-body">
                    <div class="setting-row">
                        <div>
                            <strong>Firewall logs cache</strong>
                            <div class="fw-setting-hint">
                                Maximum number of firewall log entries kept in memory (default 4000).
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <input type="number"
                                class="fw-setting-number"
                                data-path="fw_logs_max"
                                value="<?= $ui['fw_logs_max'] ?>"
                                min="1" max="100000" step="1"
                                <?= $ui['disabled_attr'] ?>>
                        </div>
                    </div>
                    <div class="setting-row">
                        <div>
                            <strong>Conntrack logs cache</strong>
                            <div class="fw-setting-hint">
                                Maximum number of conntrack flow log entries kept in memory (default 2000).
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <input type="number"
                                class="fw-setting-number"
                                data-path="ct_logs_max"
                                value="<?= $ui['ct_logs_max'] ?>"
                                min="1" max="100000" step="1"
                                <?= $ui['disabled_attr'] ?>>
                        </div>
                    </div>
                </div>
            </section>

            <section class="card card--compact">
                <header class="card-header">
                    <h2 class="card-heading">Conntrack flow logs</h2>
                </header>
                <div class="card-body">
                    <p class="fw-settings-desc">
                        The conntrack (CT) flow log lists connections; much of what the gateway sees on its own
                        interfaces is loopback, multicast and broadcast chatter rather than real forwarded traffic.
                        Each switch below hides one category from the log: while a switch is ON, every flow touching
                        one of that category's addresses is left out of the CT log view. All three switches are ON by
                        default; switch one OFF to start seeing that category again.
                    </p>
                    <div class="setting-row">
                        <div>
                            <strong>Hide loopback traffic</strong>
                            <div class="fw-setting-hint">
                                Flows between loopback addresses (<code>127.0.0.0/8</code>, <code>::1</code>) — the gateway
                                talking to itself (management UI, local services).
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <label class="std-switch">
                                <input type="checkbox"
                                    class="fw-setting-toggle"
                                    data-path="ct_logs_filter_loopback"
                                    <?= $ui['ct_logs_filter_loopback'] ? 'checked' : '' ?>
                                    <?= $ui['disabled_attr'] ?>>
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                    <div class="setting-row">
                        <div>
                            <strong>Hide multicast traffic</strong>
                            <div class="fw-setting-hint">
                                Flows touching a multicast address (<code>224.0.0.0/4</code>, <code>ff00::/8</code>), e.g.
                                mDNS / SSDP service discovery.
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <label class="std-switch">
                                <input type="checkbox"
                                    class="fw-setting-toggle"
                                    data-path="ct_logs_filter_multicast"
                                    <?= $ui['ct_logs_filter_multicast'] ? 'checked' : '' ?>
                                    <?= $ui['disabled_attr'] ?>>
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                    <div class="setting-row">
                        <div>
                            <strong>Hide broadcast traffic</strong>
                            <div class="fw-setting-hint">
                                Flows to the limited broadcast (<code>255.255.255.255</code>), e.g. DHCP. Directed LAN
                                broadcasts (e.g. <code>192.168.x.255</code>) are not hidden: they need the network mask
                                to be recognised, and nothing is guessed.
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <label class="std-switch">
                                <input type="checkbox"
                                    class="fw-setting-toggle"
                                    data-path="ct_logs_filter_broadcast"
                                    <?= $ui['ct_logs_filter_broadcast'] ? 'checked' : '' ?>
                                    <?= $ui['disabled_attr'] ?>>
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                </div>
            </section>

            <section class="card card--compact">
                <header class="card-header">
                    <h2 class="card-heading">Drop invalid</h2>
                </header>
                <div class="card-body">
                    <div class="setting-row">
                        <div>
                            <strong>Drop invalid — Forward</strong>
                            <div class="fw-setting-hint">
                                Drop <code>ct state invalid</code> on the forward chain. Disable when asymmetric routing
                                makes otherwise valid traffic appear invalid.
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <label class="std-switch">
                                <input type="checkbox"
                                    class="fw-setting-toggle"
                                    data-path="drop_invalid.forward"
                                    <?= $ui['di_forward'] ? 'checked' : '' ?>
                                    <?= $ui['disabled_attr'] ?>>
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                    <div class="setting-row">
                        <div>
                            <strong>Drop invalid — Input</strong>
                            <div class="fw-setting-hint">
                                Drop <code>ct state invalid</code> on the input chain.
                            </div>
                        </div>
                        <div class="setting-toggle">
                            <label class="std-switch">
                                <input type="checkbox"
                                    class="fw-setting-toggle"
                                    data-path="drop_invalid.input"
                                    <?= $ui['di_input'] ? 'checked' : '' ?>
                                    <?= $ui['disabled_attr'] ?>>
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                </div>
            </section>


            <section class="card card--compact">
                <header class="card-header">
                    <h2 class="card-heading">Log established/related</h2>
                </header>
                <div class="card-body">
                    <p class="fw-settings-desc">
                        Log per-packet <code>ct state established</code> / <code>ct state related</code> traffic to the
                        firewall log (NFLOG group 1) for the selected chains and states. Off by default: each enabled
                        state logs every matching packet of every connection, which grows the firewall log substantially.
                    </p>
                    <?php foreach (['input' => 'Input', 'forward' => 'Forward', 'output' => 'Output'] as $ctl_chain => $ctl_label): ?>
                        <div class="setting-row">
                            <div>
                                <strong>Established — <?= $ctl_label ?></strong>
                                <div class="fw-setting-hint">
                                    Log <code>ct state established</code> on the <?= strtolower($ctl_label) ?> chain.
                                </div>
                            </div>
                            <div class="setting-toggle">
                                <label class="std-switch">
                                    <input type="checkbox"
                                        class="fw-setting-ctl"
                                        data-ctl-chain="<?= $ctl_chain ?>"
                                        data-ctl-state="established"
                                        <?= $ui['ctl_checked']['established'][$ctl_chain] ? 'checked' : '' ?>
                                        <?= $ui['disabled_attr'] ?>>
                                    <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                                </label>
                            </div>
                        </div>
                        <div class="setting-row">
                            <div>
                                <strong>Related — <?= $ctl_label ?></strong>
                                <div class="fw-setting-hint">
                                    Log <code>ct state related</code> on the <?= strtolower($ctl_label) ?> chain.
                                </div>
                            </div>
                            <div class="setting-toggle">
                                <label class="std-switch">
                                    <input type="checkbox"
                                        class="fw-setting-ctl"
                                        data-ctl-chain="<?= $ctl_chain ?>"
                                        data-ctl-state="related"
                                        <?= $ui['ctl_checked']['related'][$ctl_chain] ? 'checked' : '' ?>
                                        <?= $ui['disabled_attr'] ?>>
                                    <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                                </label>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>

        <?php if (!$can_edit): ?>
            <p class="fw-settings-note">
                You do not have permission to modify the firewall settings.
            </p>
        <?php endif; ?>
    </main>
</div>
