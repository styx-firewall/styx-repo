<?php
/**
 * HA page shell.
 *
 * Self-contained sections are loaded via PageHa::get() and rendered into
 * named places:
 *   ha_status - daemon status
 *   ha_sync   - conntrackd configuration form
 *   ha_filter - event filtering
 *
 * @var array<mixed> $tdata
 * js: scripts/ha/ha.js
 */
$config = $tdata['page_data']['config'] ?? [];
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>High Availability</h1>
        <p>Connection tracking cluster synchronization (conntrackd) for firewall failover.</p>
        <script>window.haConfig = <?= json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>

        <div class="ha-sections">
            <?= $tdata['ha_status'] ?? '' ?>
            <?= $tdata['ha_sync'] ?? '' ?>
            <?= $tdata['ha_filter'] ?? '' ?>
            <?= $tdata['ha_actions'] ?? '' ?>
        </div>
    </main>
</div>
