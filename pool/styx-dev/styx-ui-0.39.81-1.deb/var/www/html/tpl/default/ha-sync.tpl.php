<?php
/**
 * HA fragment: conntrackd sync configuration form.
 *
 * @var array<mixed> $tdata - $tdata['tpl_data'] contains the full formatted HA data
 */
$pd = $tdata['tpl_data'] ?? [];
$sync = $pd['sync'] ?? [];
$transport = $pd['transport'] ?? 'multicast';
$ifaces = $pd['ifaces'] ?? [];
$address_sets_map = $pd['address_sets_map'] ?? [];
$port_sets_map = $pd['port_sets_map'] ?? [];

// Each transport is a list of dedicated links; links[0] is the active one.
$mcast_link = $sync['multicast'][0] ?? [];
$udp_link = $sync['udp'][0] ?? [];
$tcp_link = $sync['tcp'][0] ?? [];

// Set-picker selection labels (server-side pre-render), per transport.
$mcast_addr = $mcast_link['address_set'] ?? null;
$mcast_addr_label = $mcast_addr ? ($address_sets_map[$mcast_addr] ?? $mcast_addr) : '';
$mcast_group = $mcast_link['group_set'] ?? null;
$mcast_group_label = $mcast_group ? ($port_sets_map[$mcast_group] ?? $mcast_group) : '';

$udp_addr = $udp_link['peer_address_set'] ?? null;
$udp_addr_label = $udp_addr ? ($address_sets_map[$udp_addr] ?? $udp_addr) : '';
$udp_port = $udp_link['port_set'] ?? null;
$udp_port_label = $udp_port ? ($port_sets_map[$udp_port] ?? $udp_port) : '';

$tcp_addr = $tcp_link['peer_address_set'] ?? null;
$tcp_addr_label = $tcp_addr ? ($address_sets_map[$tcp_addr] ?? $tcp_addr) : '';
$tcp_port = $tcp_link['port_set'] ?? null;
$tcp_port_label = $tcp_port ? ($port_sets_map[$tcp_port] ?? $tcp_port) : '';
?>
<div class="content-box">
    <h2>conntrackd Configuration</h2>
    <form id="ha-config-form" class="std-form form-compact" data-js="ha-config-form">
        <div class="form-row">
            <div class="form-col">
                <label for="ha_mode">Sync mode</label>
                <select id="ha_mode" class="std-input">
                    <?php foreach (['FTFW', 'ALARM', 'NOTRACK'] as $m): ?>
                    <option value="<?= $m ?>" <?= ($sync['mode'] ?? 'FTFW') === $m ? 'selected' : '' ?>><?= $m ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-col">
                <label for="ha_transport">Transport</label>
                <select id="ha_transport" class="std-input">
                    <?php foreach (['multicast', 'udp', 'tcp'] as $t): ?>
                    <option value="<?= $t ?>" <?= $transport === $t ? 'selected' : '' ?>><?= ucfirst($t) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-col">
                <label for="ha_interface">Dedicated interface</label>
                <select id="ha_interface" class="std-input">
                    <option value="">Select an interface...</option>
                    <?php foreach ($ifaces as $iface): ?>
                    <option value="<?= htmlspecialchars((string)($iface['id'] ?? '')) ?>"
                        <?= ($sync['interface'] ?? '') === ($iface['id'] ?? '') ? 'selected' : '' ?>>
                        <?= htmlspecialchars($iface['label'] ?? '') ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-col">
                <label for="ha_startup_resync">Startup resync</label>
                <label class="std-switch">
                    <input type="checkbox" id="ha_startup_resync" <?= !empty($sync['startup_resync']) ? 'checked' : '' ?>>
                    <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                </label>
            </div>
            <div class="form-col">
                <label for="ha_expectation_sync">Expectation sync</label>
                <label class="std-switch">
                    <input type="checkbox" id="ha_expectation_sync" <?= !empty($sync['expectation_sync']) ? 'checked' : '' ?>>
                    <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                </label>
            </div>
        </div>

        <!-- Multicast transport -->
        <div id="ha-multicast-fields" <?= $transport !== 'multicast' ? 'style="display:none;"' : '' ?>>
            <div class="form-row">
                <div class="form-col">
                    <label>Multicast address set</label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-max-select="1"
                        data-filter-family="ip" data-filter-scope="host">
                        <input type="hidden" id="ha_mcast_addr_set" value="<?= htmlspecialchars((string)$mcast_addr) ?>">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                            data-placeholder="Select address set...">
                            <span class="js-set-picker-label"><?= htmlspecialchars($mcast_addr_label ?: 'Select address set...') ?></span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                </div>
                <div class="form-col">
                    <label>Group (port set)</label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="ports" data-max-select="1"
                        data-filter-type="single" data-filter-scope="single">
                        <input type="hidden" id="ha_mcast_group_set" value="<?= htmlspecialchars((string)$mcast_group) ?>">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                            data-placeholder="Select port set...">
                            <span class="js-set-picker-label"><?= htmlspecialchars($mcast_group_label ?: 'Select port set...') ?></span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- UDP transport -->
        <div id="ha-udp-fields" <?= $transport !== 'udp' ? 'style="display:none;"' : '' ?>>
            <div class="form-row">
                <div class="form-col">
                    <label>Peer address set</label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-max-select="1"
                        data-filter-family="ip" data-filter-scope="host">
                        <input type="hidden" id="ha_udp_addr_set" value="<?= htmlspecialchars((string)$udp_addr) ?>">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                            data-placeholder="Select address set...">
                            <span class="js-set-picker-label"><?= htmlspecialchars($udp_addr_label ?: 'Select address set...') ?></span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                </div>
                <div class="form-col">
                    <label>Port set</label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="ports" data-max-select="1"
                        data-filter-type="single" data-filter-scope="single">
                        <input type="hidden" id="ha_udp_port_set" value="<?= htmlspecialchars((string)$udp_port) ?>">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                            data-placeholder="Select port set...">
                            <span class="js-set-picker-label"><?= htmlspecialchars($udp_port_label ?: 'Select port set...') ?></span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                </div>
            </div>
            <p class="text-muted">The local address is derived from the dedicated interface.</p>
        </div>

        <!-- TCP transport -->
        <div id="ha-tcp-fields" <?= $transport !== 'tcp' ? 'style="display:none;"' : '' ?>>
            <div class="form-row">
                <div class="form-col">
                    <label>Peer address set</label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-max-select="1"
                        data-filter-family="ip" data-filter-scope="host">
                        <input type="hidden" id="ha_tcp_addr_set" value="<?= htmlspecialchars((string)$tcp_addr) ?>">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                            data-placeholder="Select address set...">
                            <span class="js-set-picker-label"><?= htmlspecialchars($tcp_addr_label ?: 'Select address set...') ?></span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                </div>
                <div class="form-col">
                    <label>Port set</label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="ports" data-max-select="1"
                        data-filter-type="single" data-filter-scope="single">
                        <input type="hidden" id="ha_tcp_port_set" value="<?= htmlspecialchars((string)$tcp_port) ?>">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                            data-placeholder="Select port set...">
                            <span class="js-set-picker-label"><?= htmlspecialchars($tcp_port_label ?: 'Select port set...') ?></span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                </div>
            </div>
            <p class="text-muted">The local address is derived from the dedicated interface.</p>
        </div>
    </form>
</div>
