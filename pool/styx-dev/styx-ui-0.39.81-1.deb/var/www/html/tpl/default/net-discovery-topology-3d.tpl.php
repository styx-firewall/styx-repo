<?php
/**
 * Fragment: Network Discovery 3D Topology tab.
 * Loaded via load_tpl into the disc-topology-3d panel.
 * Uses 3d-force-graph (vasturiano) with real topology data.
 * Seen/unseen (seen) reflects traffic in the last 5 minutes.
 *
 * @var array<mixed> $tdata
 */

$topo_json = json_encode($tdata['tpl_data']['topology_tab'] ?? []);
?>
<div class="content-box">
    <p class="disc-3d-hint">Click and drag to orbit. Scroll to zoom. Hover nodes for details.</p>
    <div id="disc-3d-container"></div>
</div>

<script src="https://unpkg.com/3d-force-graph@1"></script>
<script>
(function() {
    var container = document.getElementById('disc-3d-container');
    if (!container) return;

    var graph = null;
    var initialized = false;
    var rotateInterval = null;

    // Tunable parameters
    var CFG = {
        chargeStrength: -5,   // node repulsion (more negative = more spread)
        linkStrength:   0.3,   // link spring tension (1 = default). Lower = longer visible links for particles
        sizeGateway: 10,      // gateway / router sphere radius (px)
        sizeSegment: 2,      // subnet segment sphere radius
        sizeHv:      2,      // hypervisor sphere radius
        sizeGroup:   2,       // virtual group parent (orphans, unclassified)
        sizeHost:     0.3,      // individual host / VM sphere radius
        particleWidth: 0.8,     // directional particle trail width (px)
        linkWidth: 0.8,         // link line thickness (px)
    };

    // Colour palette
    var C = {
        seen:   '#81c784',
        unseen: '#888',
        offline: '#ef5350',  // explicit offline status (online === false)
        gw:      '#ffd600',   // main router (Styx) and upstream gateways
        gwDefault: '#e0e0e0', // upstream default gateway of a segment (light gray, distinct from cyan segments)
        gwStyx:    '#5c6bc0', // this router's interface gateway (indigo)
        segment: '#4fc3f7',
        wan:     '#a136df',
        hv:      '#ce93d8',
        link:    'rgba(255,255,255,0.25)',
        particle:'#4fc3f7',
    };

    // Blend two #rrggbb colors: t=0 -> c1, t=1 -> c2. Used to keep a hint of
    // a special node's identity while showing an offline (red) state.
    function mixColors(c1, c2, t) {
        function hexRgb(c) {
            var n = parseInt(c.slice(1), 16);
            return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
        }
        function rgbHex(rgb) {
            return '#' + rgb.map(function(v) {
                return ('0' + Math.round(v).toString(16)).slice(-2);
            }).join('');
        }
        var a = hexRgb(c1), b = hexRgb(c2);
        return rgbHex([
            a[0] + (b[0] - a[0]) * t,
            a[1] + (b[1] - a[1]) * t,
            a[2] + (b[2] - a[2]) * t,
        ]);
    }
    // Offline colouring: hosts turn pure red; special nodes (routers/segments/
    // wan/hv) keep their identity via a red-dominant blend of their own color.
    // Unknown status (online null) never turns red -- it falls back to unseen.
    function offlineColor(base, group, online) {
        if (online !== false) return base;
        return group === 'host' ? C.offline : mixColors(base, C.offline, 0.65);
    }

    // Seen/unseen + group lookup maps
    var seenMap = {};
    var groupMap = {};
    function buildGraphData(topo) {
        var nodes = [];
        var links = [];
        var nodeMap = {}; // id -> true

        function addNode(id, label, group, seen, online) {
            if (nodeMap[id]) return null;
            nodeMap[id] = true;
            seenMap[id] = !!seen;
            groupMap[id] = group;
            var base = group === 'gateway' ? C.gw
                     : group === 'segment' ? C.segment
                     : group === 'wan'     ? C.wan
                     : group === 'hv'      ? C.hv
                     : group === 'group'   ? '#9e9e9e'
                     : (online === true || seen) ? C.seen
                     : C.unseen;
            var color = offlineColor(base, group, online);
            nodes.push({ id: id, label: label, group: group, seen: seen, online: online, color: color });
            return nodes[nodes.length - 1];
        }

        function addLink(src, tgt) {
            links.push({ source: src, target: tgt });
        }

        function rtrLabel(r) {
            return (r.hostname || r.ip) + (r.asn ? ' AS' + r.asn : '');
        }

        // Gateways: only ones not already shown as a central segment's gateway
        // are added as nodes (the default is represented on its own segment).
        var gateways = topo.gateways || [];
        var central = topo.central_router;
        var claimedGw = {};
        if (central) {
            (central.segments || []).forEach(function(seg) {
                if (seg.router_info && seg.router_info.ip) claimedGw[seg.router_info.ip] = true;
            });
        }
        var defaultGwId = null;
        gateways.forEach(function(gw) {
            if (claimedGw[gw.ip]) return;
            var gid = 'gw:' + gw.ip;
            addNode(gid, gw.hostname || gw.ip || 'Gateway', 'gateway', !!gw.seen, gw.online);
            if (gw.is_default) defaultGwId = gid;
        });
        // If no explicit default, use the first gateway as the WAN anchor.
        var wanAnchorId = defaultGwId || (gateways.length > 0 ? 'gw:' + gateways[0].ip : null);

        // Segments nested under their gateway or internal router
        function addSegmentLinks(seg, parentId) {
            var segId = 'seg:' + seg.cidr;
            var segLabel = seg.cidr + (seg.as_path && seg.as_path.length ? ' [' + seg.as_path.join(' ') + ']' : '');
            // BGP multi-path: show every observed next-hop (e.g. both spines).
            if (seg.paths && seg.paths.length > 1) {
                var nhs = [];
                var seenNh = {};
                seg.paths.forEach(function(p) {
                    if (p.nexthop && !seenNh[p.nexthop]) { seenNh[p.nexthop] = 1; nhs.push(p.nexthop); }
                });
                if (nhs.length > 1) segLabel += ' ↑ ' + nhs.join(' ');
            }
            addNode(segId, segLabel, 'segment', null, null);
            addLink(parentId, segId);
            // The segment's gateway: the upstream default router or this
            // router's interface IP. Rendered as a node beside the segment.
            var gwId = null;
            if (seg.router_info && seg.router_info.ip) {
                var gwKind = (seg.router_info.gateway_kind || '').toLowerCase();
                gwId = 'gw:' + seg.router_info.ip;
                var gwNode = addNode(
                    gwId,
                    seg.router_info.ip + (gwKind ? ' (' + gwKind + ')' : ''),
                    'gateway',
                    null,
                    seg.router_info.online
                );
                if (gwNode) {
                    // segment gateways use their own colors, distinct from the
                    // segment (cyan) and the main router (amber)
                    gwNode.color = gwKind === 'styx'    ? C.gwStyx
                                 : gwKind === 'default' ? C.gwDefault
                                 : C.gw;
                    // keep the offline (red) indication on top of the
                    // group-specific color without losing its identity
                    gwNode.color = offlineColor(gwNode.color, gwNode.group, gwNode.online);
                }
                addLink(segId, gwId);
            }
            // Routers inside segment (infrastructure nodes, rendered first).
            // When the segment has a gateway the routers hang BEHIND it
            // (deeper), matching the 2D hierarchy; without one they hang
            // directly from the segment (e.g. BGP-learned segments).
            var routerParent = gwId || segId;
            (seg.routers || []).forEach(function(rtr) {
                var rid = 'rtr:' + rtr.ip;
                addNode(rid, rtrLabel(rtr), 'gateway', !!rtr.seen, rtr.online);
                addLink(routerParent, rid);
                (rtr.segments || []).forEach(function(rseg) { addSegmentLinks(rseg, rid); });
                (rtr.children || []).forEach(function(c) {
                    addNode(c.ip, c.hostname || c.ip, 'host', !!c.seen, c.online);
                    addLink(rid, c.ip);
                });
            });
            (seg.hosts || []).forEach(function(h) {
                addNode(h.ip, h.hostname || h.ip, 'host', !!h.seen, h.online);
                addLink(segId, h.ip);
            });
            (seg.hypervisors || []).forEach(function(hv) {
                var hvid = 'hv:' + hv.ip;
                addNode(hvid, hv.hostname || hv.ip, 'hv', !!hv.seen, hv.online);
                addLink(segId, hvid);
                (hv.vms || []).forEach(function(vm) {
                    addNode(vm.ip, vm.hostname || vm.ip, 'host', !!vm.seen, vm.online);
                    addLink(hvid, vm.ip);
                });
            });
        }

        gateways.forEach(function(gw) {
            var gid = 'gw:' + gw.ip;
            (gw.segments || []).forEach(function(seg) { addSegmentLinks(seg, gid); });
        });

        // Central router: the machine itself is the primary root. Its
        // directly-connected segments hang from it.
        if (central && central.ip) {
            var cid = 'rtr:' + central.ip;
            addNode(cid, central.hostname || central.ip, 'gateway', !!central.seen, central.online);
            (central.segments || []).forEach(function(seg) { addSegmentLinks(seg, cid); });
        }
        // Anchor WAN trees to the upstream default gateway node when it was
        // rendered as a segment's gateway, else to the central router.
        var defaultGwNodeId = null;
        if (central) {
            (central.segments || []).forEach(function(seg) {
                if (seg.router_info && seg.router_info.is_default && seg.router_info.ip) {
                    defaultGwNodeId = 'gw:' + seg.router_info.ip;
                }
            });
        }
        wanAnchorId = defaultGwNodeId || (central && central.ip ? 'rtr:' + central.ip : wanAnchorId);

        // Internal routers with their segments and children
        (topo.internal_routers || []).forEach(function(rtr) {
            var rid = 'rtr:' + rtr.ip;
            addNode(rid, rtrLabel(rtr), 'gateway', !!rtr.seen, rtr.online);
            (rtr.segments || []).forEach(function(seg) { addSegmentLinks(seg, rid); });
            (rtr.children || []).forEach(function(c) {
                addNode(c.ip, c.hostname || c.ip, 'host', !!c.seen, c.online);
                addLink(rid, c.ip);
            });
        });

        // Orphan segments - use the same helper for consistency.
        (topo.orphan_segments || []).forEach(function(seg) {
            var segId = 'seg:' + seg.cidr;
            addNode(segId, seg.cidr, 'segment', null, null);
            (seg.hosts || []).forEach(function(h) {
                addNode(h.ip, h.hostname || h.ip, 'host', !!h.seen, h.online);
                addLink(segId, h.ip);
            });
            (seg.hypervisors || []).forEach(function(hv) {
                var hvid = 'hv:' + hv.ip;
                addNode(hvid, hv.hostname || hv.ip, 'hv', !!hv.seen, hv.online);
                addLink(segId, hvid);
                (hv.vms || []).forEach(function(vm) {
                    addNode(vm.ip, vm.hostname || vm.ip, 'host', !!vm.seen, vm.online);
                    addLink(hvid, vm.ip);
                });
            });
        });

        // Unclassified -> group under a virtual parent
        var unclassed = topo.unclassified || [];
        if (unclassed.length > 0) {
            addNode('_unclassified', 'Unclassified', 'group', null, null);
            unclassed.forEach(function(h) {
                addNode(h.ip, h.hostname || h.ip, 'host', !!h.seen, h.online);
                addLink('_unclassified', h.ip);
            });
        }

        // WAN trees (recursive) anchor to the default gateway if available.
        function walkWan(node, parentId) {
            var wid = 'wan:' + node.ip;
            addNode(wid, node.hostname || node.ip, 'wan', !!node.seen, null);
            if (parentId) addLink(parentId, wid);
            (node.children || []).forEach(function(c) { walkWan(c, wid); });
        }
        (topo.wan_trees || []).forEach(function(root) {
            walkWan(root, wanAnchorId);
        });

        return { nodes: nodes, links: links };
    }

    // Load topology from PHP
    var topo = <?= $topo_json ?>;
    var topoValid = topo && typeof topo === 'object';
    var graphData = topoValid ? buildGraphData(topo) : { nodes: [], links: [] };

    /** Set explicit container size using viewport. */
    function sizeContainer() {
        var pageContent = document.querySelector('.page-content');
        if (!pageContent) return;
        var pcRect = pageContent.getBoundingClientRect();
        var hint = container.previousElementSibling;
        var hintBottom = hint ? hint.getBoundingClientRect().bottom : pcRect.top + 20;
        var availHeight = window.innerHeight - hintBottom - 16;
        var w = pcRect.width - 40;
        container.style.height = Math.max(availHeight, 300) + 'px';
        container.style.width = Math.max(w, 100) + 'px';
    }

    function initGraph() {
        if (initialized) return;
        sizeContainer();
        var w = container.clientWidth;
        var h = container.clientHeight;
        if (w === 0 || h === 0) return;
        if (graphData.nodes.length === 0) {
            container.innerHTML =
                '<p style="color:#888;text-align:center;padding:40px;">No topology data available.</p>';
            initialized = true;
            return;
        }
        initialized = true;

        graph = ForceGraph3D({
            controlType: 'orbit',
            rendererConfig: { antialias: true, alpha: true },
        })(container)
            .graphData(graphData)
            .nodeId('id')
            .enableNodeDrag(false)
            .nodeLabel(function(n) {
                var status;
                if (n.online === true) {
                    status = ' Online';
                } else if (n.online === false) {
                    status = ' Offline';
                } else {
                    status = n.seen === true ? ' Seen' : n.seen === false ? ' Unseen' : '';
                }
                return n.label + ' (' + n.group + ')' + status;
            })
            .nodeColor(function(n) { return n.color; })
            .nodeVal(function(n) {
                return n.group === 'gateway' ? CFG.sizeGateway
                    : n.group === 'segment' ? CFG.sizeSegment
                    : n.group === 'hv' ? CFG.sizeHv
                    : n.group === 'group' ? CFG.sizeGroup
                    : CFG.sizeHost;
            })
            .nodeResolution(48)
            .linkWidth(CFG.linkWidth)
            .linkColor(function() { return C.link; })
            .backgroundColor('#111')
            .linkDirectionalParticles(function(l) {
                // Use maps (reliable regardless of link resolution state)
                var srcId = typeof l.source === 'object' ? l.source.id : l.source;
                var tgtId = typeof l.target === 'object' ? l.target.id : l.target;
                var srcIsLeaf = groupMap[srcId] === 'host' || groupMap[srcId] === 'hv';
                var tgtIsLeaf = groupMap[tgtId] === 'host' || groupMap[tgtId] === 'hv';
                return ((srcIsLeaf && seenMap[srcId]) || (tgtIsLeaf && seenMap[tgtId])) ? 4 : 0;
            })
            .linkDirectionalParticleWidth(CFG.particleWidth)
            .linkDirectionalParticleColor(function(l) {
                var srcId = typeof l.source === 'object' ? l.source.id : l.source;
                var tgtId = typeof l.target === 'object' ? l.target.id : l.target;
                var srcIsLeaf = groupMap[srcId] === 'host' || groupMap[srcId] === 'hv';
                var tgtIsLeaf = groupMap[tgtId] === 'host' || groupMap[tgtId] === 'hv';
                return ((srcIsLeaf && seenMap[srcId]) || (tgtIsLeaf && seenMap[tgtId])) ? '#80f0ff' : 'rgba(0,0,0,0)';
            })
            .linkDirectionalParticleSpeed(0.01)
            .d3AlphaDecay(0.02)
            .warmupTicks(80)
            .cooldownTicks(0)
            .width(w)
            .height(h);

        if (graph.d3Force('charge')) graph.d3Force('charge').strength(CFG.chargeStrength);
        if (graph.d3Force('link'))   graph.d3Force('link').strength(CFG.linkStrength);

        var angle = 0;
        rotateInterval = setInterval(function() {
            graph.cameraPosition({
                x: 400 * Math.sin(angle),
                y: 150,
                z: 400 * Math.cos(angle),
            });
            angle += 0.002;
        }, 50);

        container.addEventListener('mousedown', function() {
            if (rotateInterval) clearInterval(rotateInterval);
        });
        container.addEventListener('touchstart', function() {
            if (rotateInterval) clearInterval(rotateInterval);
        });
    }

    // Size + init on tab activation
    var tabBtn = document.querySelector('.std-tab-btn[data-tab="disc-topology-3d"]');
    if (tabBtn) {
        tabBtn.addEventListener('click', function() {
            sizeContainer();
            initGraph();
            if (graph) {
                setTimeout(function() {
                    sizeContainer();
                    graph.width(container.clientWidth);
                    graph.height(container.clientHeight);
                }, 50);
            }
        });
    }

    // Also try on load in case it's already the active tab
    sizeContainer();
    initGraph();
    if (!initialized) {
        var retries = 0;
        var retryTimer = setInterval(function() {
            sizeContainer();
            initGraph();
            retries++;
            if (initialized || retries > 100) clearInterval(retryTimer);
        }, 200);
    }

    // Window resize
    window.addEventListener('resize', function() {
        if (!graph) return;
        sizeContainer();
        graph.width(container.clientWidth);
        graph.height(container.clientHeight);
    });
})();
</script>
