<?php

/**
 * FormatHelper
 *
 * Utility methods for formatting values for display in templates.
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */

namespace App\Helpers;

class FormatHelper
{
    /**
     * Format bytes to human-readable string.
     *
     * @param int $bytes
     * @return string
     */
    public static function formatBytes(int $bytes): string
    {
        if ($bytes === 0) {
            return '0 B';
        }
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = floor(log($bytes, 1024));
        $i = min((int)$i, count($units) - 1);
        $val = $bytes / pow(1024, $i);
        return number_format($val, $i > 0 ? 1 : 0) . ' ' . $units[$i];
    }
}
