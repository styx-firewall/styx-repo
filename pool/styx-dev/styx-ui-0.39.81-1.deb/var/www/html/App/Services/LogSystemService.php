<?php

/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */

namespace App\Services;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\DateTimeService;
use App\Constants\LogLevel;

class LogSystemService
{
    private int $recursionCount = 0;
    private int $maxDbMsg = 254;

    private string $timezone = 'UTC';
    private Config $ncfg;
    // Log to file
    private bool $log_to_file = true;
    // Log to syslog
    private bool $log_to_syslog = false;
    private string $log_file = '/var/log/styx-ui.log';
    // Debug enabled flag (driven by config 'app.debug')
    private bool $debug_enabled = false;


    public function __construct(AppContext $ctx)
    {
        if ($ctx !== null) {
            $this->ncfg = $ctx->get(Config::class);
            try {
                $this->debug_enabled = (bool)$this->ncfg->get('client.debug', false);
            } catch (\Throwable $_) {
                $this->debug_enabled = false;
            }
        }
    }

    /**
     *
     * @param int $log_level
     * @param mixed $msg
     * @return void
     */
    public function logged(int $log_level, mixed $msg): void
    {
        // Read debug flag lazily so per-user profile loaded after construction is respected.
        $isDebug = isset($this->ncfg)
            ? (bool)$this->ncfg->get('client.debug', false)
            : $this->debug_enabled;

        // Suppress debug-level messages unless debug mode is enabled
        if ($log_level === LogLevel::DEBUG && !$isDebug) {
            return;
        }

        // Format the message with ISO 8601 date and milliseconds in UTC
        $dt = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $millis = (int)($dt->format('u') / 1000);
        $date = $dt->format('Y-m-d\TH:i:s') . '.' . str_pad($millis, 3, '0', STR_PAD_LEFT) . 'Z';
        $level = LogLevel::getName($log_level) ?? (string)$log_level;
        $formatted = "[$date] [$level] [UI] " . (is_scalar($msg) ? $msg : json_encode($msg));

        // Log to file
        if ($this->log_to_file && is_string($this->log_file)) {
            $logfile = $this->log_file;
            if (is_writable($logfile)) {
                @file_put_contents($logfile, $formatted . PHP_EOL, FILE_APPEND | LOCK_EX);
            }
        }

        // Log to syslog
        if ($this->log_to_syslog) {
            openlog('styx', LOG_PID | LOG_PERROR, LOG_LOCAL0);
            syslog($log_level, $formatted);
            closelog();
        }
    }

    /**
     *
     * @param mixed $msg
     *
     * @return void
     */
    public function debug(mixed $msg): void
    {
        $this->logged(LogLevel::DEBUG, $msg);
    }

    /**
     *
     * @param mixed $msg
     *
     * @return void
     */
    public function info(mixed $msg): void
    {
        $this->logged(LogLevel::INFO, $msg);
    }

    /**
     *
     * @param mixed $msg
     *
     * @return void
     */
    public function notice(mixed $msg): void
    {
        $this->logged(LogLevel::NOTICE, $msg);
    }

    /**
     *
     * @param mixed $msg
     * @return void
     */
    public function warning(mixed $msg): void
    {
        $this->logged(LogLevel::WARNING, $msg);
    }

    /**
     *
     * @param mixed $msg
     *
     * @return void
     */
    public function error(mixed $msg): void
    {
        $this->logged(LogLevel::ERROR, $msg);
    }

    /**
     *
     * @param mixed $msg
     *
     * @return void
     */
    public function alert(mixed $msg): void
    {
        $this->logged(LogLevel::ALERT, $msg);
    }

    /**
     *
     * @param mixed $msg
     *
     * @return void
     */
    public function critical(mixed $msg): void
    {
        $this->logged(LogLevel::CRITICAL, $msg);
    }

    /**
     *
     * @param mixed $msg
     *
     * @return void
     */
    public function emergency(mixed $msg): void
    {
        $this->logged(LogLevel::EMERGENCY, $msg);
    }
}
