<?php

/**
 * Gateway related services
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 *
 */

/*
    Backend response format:
    array of commands with:
        "status": "success" or "error"
        "command": the name of the received command
        "response_msg": human-readable message for the user
        "result": object with the specific data returned by that command
                  (can be an empty object {} or null if no data)
    Note: `GatewayService` wraps the backend replies as:
        ['status' => 'success', 'commands' => [ <command responses> ]]
    Each element of `commands` is typically indexed by the original command `id`
    and controllers access the useful payload via the command's `result` field.
*/

/*
    Return response format:
    [
        'status' => 'success' | 'error',
        'commands' => array of command responses,
        'response_msg' => string, optional error message if status is 'error',
        'errors' => array of errors, optional
    ]

*/
namespace App\Services;

use App\Core\AppContext;
use App\Core\Config;

use App\Services\LogSystemService;
use App\Gateway\GwRequest;

class GatewayService
{
    private AppContext $ctx;
    private string $server_ip;
    private int $server_port;
    private LogSystemService $logService;

    public function __construct(AppContext $ctx)
    {
        $this->ctx = $ctx;
        $cfg = $ctx->get(Config::class);
        $this->server_ip = (string)$cfg->get('gateway.host');
        $this->server_port = (int)$cfg->get('gateway.port');
        $this->logService = $ctx->get(LogSystemService::class);
    }

    /**
     * Helper method to send a list of commands via the gateway, with token in payload.
     *
     * @param array<int, array<string, mixed>> $commands
     * @param string|null $token
     * @return array<string, mixed>
     */
    public function sendCommandGW(array $commands, ?string $token = null, array $timeouts = []): array
    {
        foreach ($commands as $i => $cmd) {
            if (empty($cmd['id'])) {
                throw new \InvalidArgumentException(
                    "GatewayService: command at index $i is missing required 'id' field (method: " . ($cmd['method'] ?? '?') . ')'
                );
            }
        }

        $payload = [
            'commands' => $commands,
            'token' => $token,
        ];

        try {
            $gwRequest = new GwRequest($this->ctx, $this->server_ip, $this->server_port);

            if (!isset($payload['metadata']) || !is_array($payload['metadata'])) {
                $payload['metadata'] = [];
            }

            $gwRequest->connect();
            $responses = $gwRequest->request($payload);
            // If the request itself reported a connection failure, propagate it directly
            if (is_array($responses) && ($responses['status'] ?? null) === 'error' && ($responses['error_code'] ?? null) === 'GATEWAY_UNREACHABLE') {
                return $responses;
            }
        } catch (\Throwable $e) {
            $context = json_encode([
                'exception' => (string)$e,
                'send_data' => $payload,
            ]);
            $this->logService->error(
                'GatewayService Exception: ' .
                $e->getMessage() . ' | Context: ' . $context
            );
            return ['status' => 'error', 'commands' => [], 'response_msg' => 'Exception: ' . $e->getMessage(), 'error_code' => 'GATEWAY_UNREACHABLE'];
        }

        if (!is_array($responses)) {
            $responses = [];
        } elseif (array_keys($responses) !== range(0, count($responses) - 1)) {
            // If it's an associative array, convert it to a single-element array
            $responses = [$responses];
        }

        return [
            'status' => 'success',
            'commands' => $responses,
        ];
    }
}
