<?php
/**
 * Formats raw discovery gateway data for the net-discovery template.
 */
namespace App\Pages\Fmt;

use App\Core\AppContext;
use App\Services\DateFormatter;
use App\Services\Filter;

class NetDiscoveryFormatter
{
    /** @var array<string, string> Human-readable labels for discovery source keys. */
    private const SOURCE_LABELS = [
        'arp_reply'        => 'ARP Reply',
        'arp_table_kernel' => 'ARP Table (kernel)',
        'arp_sweep'        => 'ARP Sweep',
        'ipv6_neighbor'    => 'IPv6 Neighbor',
        'cdp'              => 'CDP',
        'lldp'             => 'LLDP',
        'traceroute_hop'   => 'Traceroute Hop',
        'dhcp_lease'       => 'DHCP Lease',
        'conntrack'        => 'Conntrack',
        'mdns'             => 'mDNS',
        'unknown'          => 'Unknown',
    ];

    /** Threshold in seconds: hosts whose last_seen is within this window are considered online. */
    private const SEEN_THRESHOLD_SECONDS = 600; // 10 minutes

    /**
     * @param AppContext $ctx
     * @param array<string, mixed> $fmt_data
     * @param array<string, mixed> $result  Raw result from DiscoveryRequestController::getOverviewData()
     * @return array<string, mixed>
     */
    public static function format(AppContext $ctx, array $fmt_data, array $result): array
    {
        $fmt_data['service_status'] = self::formatStatus($result['service_status'] ?? []);
        $fmt_data['stats']          = self::formatStats($result['stats'] ?? []);
        $fmt_data['graph']          = self::formatGraph($ctx, $result['graph'] ?? []);
        $fmt_data['source_labels']  = self::SOURCE_LABELS;

        // Build seenMap + onlineMap from graph-host data (all nodes go through
        // normalizeHostSummary, which now carries the online fields).
        $graph = $fmt_data['graph'];
        $seenMap = [];
        $onlineMap = [];
        $collectSeen = static function (array $list) use (&$seenMap, &$onlineMap): void {
            foreach ($list as $item) {
                $seenMap[$item['ip']] = (bool)($item['seen'] ?? false);
                $onlineMap[$item['ip']] = $item['online'] ?? null;
            }
        };
        foreach ($graph['gateways'] ?? [] as $gw) {
            foreach ($gw['segments'] ?? [] as $seg) {
                $collectSeen($seg['hosts'] ?? []);
                foreach ($seg['hypervisors'] ?? [] as $hv) {
                    $collectSeen($hv['vms'] ?? []);
                }
            }
        }
        // Central router: the machine's directly-connected segments.
        $centralSeen = $graph['central_router'] ?? null;
        if (is_array($centralSeen)) {
            foreach ($centralSeen['segments'] ?? [] as $seg) {
                $collectSeen($seg['hosts'] ?? []);
                foreach ($seg['hypervisors'] ?? [] as $hv) {
                    $collectSeen($hv['vms'] ?? []);
                }
            }
        }
        foreach ($graph['internal_routers'] ?? [] as $rtr) {
            foreach ($rtr['segments'] ?? [] as $seg) {
                $collectSeen($seg['hosts'] ?? []);
            }
        }
        foreach ($graph['orphan_segments'] ?? [] as $seg) {
            $collectSeen($seg['hosts'] ?? []);
        }
        $collectSeen($graph['unclassified'] ?? []);

        $fmt_data['hosts_tab']      = self::prepareHostsTabData($graph);
        $fmt_data['topology_tab']   = self::prepareTopologyTabData($graph, $seenMap, $onlineMap);

        return $fmt_data;
    }

    /**
     * Pre-compute topology tab data: extract topology fields, enrich WAN
     * trees with render flags, assign hypervisors to the correct parent,
     * and decorate every host-like node with its seen + online status.
     *
     * @param array<string, mixed>     $graph      Formatted graph from formatGraph()
     * @param array<string, bool>       $seenMap    IP → seen lookup
     * @param array<string, bool|null>  $onlineMap  IP → online lookup (null = unknown)
     * @return array<string, mixed>
     */
    private static function prepareTopologyTabData(array $graph, array $seenMap, array $onlineMap): array
    {
        $gateways         = $graph['gateways']          ?? [];
        $isRouter         = $graph['is_router']         ?? false;
        $intRtrs          = $graph['internal_routers']  ?? [];
        $orphanSegs       = $graph['orphan_segments']   ?? [];
        $wanTrees         = $graph['wan_trees']         ?? [];
        $unclass          = $graph['unclassified']      ?? [];
        $centralRouter    = $graph['central_router']    ?? null;

        // Decorate everything with seen + online status.
        $gateways         = self::decorateGateways($gateways, $seenMap);
        $orphanSegs       = self::decorateSegments($orphanSegs, $seenMap, $onlineMap);
        $wanTrees         = self::enrichWanTrees($wanTrees, $seenMap);
        $intRtrs          = self::decorateInternalRouters($intRtrs, $seenMap, $onlineMap);
        $unclass          = self::decorateHostList($unclass, $seenMap);
        $centralRouter    = self::decorateCentralRouter($centralRouter, $seenMap, $onlineMap);

        // Decorate nested segments inside gateways and internal routers.
        foreach ($gateways as $gIdx => $gw) {
            $gateways[$gIdx]['segments'] = self::decorateSegments($gw['segments'] ?? [], $seenMap, $onlineMap);
            $gateways[$gIdx]['has_kids'] = !empty($gateways[$gIdx]['segments']);
        }
        foreach ($intRtrs as $rIdx => $rtr) {
            $intRtrs[$rIdx]['segments'] = self::decorateSegments($rtr['segments'] ?? [], $seenMap, $onlineMap);
            $intRtrs[$rIdx]['has_kids'] = !empty($rtr['children']) || !empty($intRtrs[$rIdx]['segments']);
        }

        return [
            'gateways'           => $gateways,
            'is_router'          => $isRouter,
            'central_router'     => $centralRouter,
            'orphan_segments'    => $orphanSegs,
            'internal_routers'   => $intRtrs,
            'unclassified'       => $unclass,
            'wan_trees'          => $wanTrees,
            'has_gateways'       => !empty($gateways),
            'has_internal_rtrs'  => !empty($intRtrs),
            'has_orphan_segs'    => !empty($orphanSegs),
            'has_wan'            => !empty($wanTrees),
            'has_unclass'        => !empty($unclass),
            '_debug_raw_gw'      => $graph['_debug_raw_gw'] ?? -1,
        ];
    }

    /**
     * Decorate every host node inside segments (hosts + orphan_vms) with seen.
     *
     * @param array<int, array<string, mixed>> $segments
     * @param array<string, bool> $seenMap
     * @param array<string, bool|null> $onlineMap IP → online lookup (null = unknown)
     * @return array<int, array<string, mixed>>
     */
    private static function decorateSegments(array $segments, array $seenMap, array $onlineMap): array
    {
        foreach ($segments as $idx => $seg) {
            $segments[$idx]['hosts']       = self::decorateHostList($seg['hosts'] ?? [], $seenMap);
            $segments[$idx]['orphan_vms']  = self::decorateHostList($seg['orphan_vms'] ?? [], $seenMap);
            if (isset($seg['hypervisors'])) {
                $segments[$idx]['hypervisors'] = self::decorateHypervisors($seg['hypervisors'], $seenMap);
            }
            if (isset($seg['routers'])) {
                $segments[$idx]['routers'] = self::decorateInternalRouters($seg['routers'], $seenMap, $onlineMap);
            }
        }
        return $segments;
    }

    /**
     * Decorate hypervisors and their nested VMs with seen.
     *
     * @param array<int, array<string, mixed>> $hypervisors
     * @param array<string, bool> $seenMap
     * @return array<int, array<string, mixed>>
     */
    private static function decorateHypervisors(array $hypervisors, array $seenMap): array
    {
        foreach ($hypervisors as $idx => $hv) {
            $hvSeen = false;
            if (array_key_exists($hv['ip'], $seenMap)) {
                $hvSeen = (bool)$seenMap[$hv['ip']];
                $hypervisors[$idx]['seen'] = $hvSeen;
            }
            $hypervisors[$idx]['seen_class'] = $hvSeen ? 'disc-dot-seen' : 'disc-dot-unseen';
            $hypervisors[$idx]['seen_title'] = $hvSeen ? 'Seen' : 'Unseen';
            $hypervisors[$idx]['vms'] = self::decorateHostList($hv['vms'] ?? [], $seenMap);
        }
        return $hypervisors;
    }

    /**
     * Decorate gateway entries with seen status.
     *
     * @param array<int, array<string, mixed>> $gateways
     * @param array<string, bool> $seenMap
     * @return array<int, array<string, mixed>>
     */
    private static function decorateGateways(array $gateways, array $seenMap): array
    {
        foreach ($gateways as $idx => $gw) {
            $seen = false;
            if (array_key_exists($gw['ip'], $seenMap)) {
                $seen = (bool)$seenMap[$gw['ip']];
                $gateways[$idx]['seen'] = $seen;
            }
            $gateways[$idx]['seen_class'] = $seen ? 'disc-dot-seen' : 'disc-dot-unseen';
            $gateways[$idx]['seen_title'] = $seen ? 'Seen' : 'Unseen';
        }
        return $gateways;
    }

    /**
     * Add seen to every element in a flat list of host-like arrays.
     *
     * @param array<int, array<string, mixed>> $list
     * @param array<string, bool> $seenMap
     * @return array<int, array<string, mixed>>
     */
    private static function decorateHostList(array $list, array $seenMap): array
    {
        foreach ($list as $idx => $item) {
            $seen = false;
            if (array_key_exists($item['ip'], $seenMap)) {
                $seen = (bool)$seenMap[$item['ip']];
                $list[$idx]['seen'] = $seen;
            }
            $list[$idx]['seen_class'] = $seen ? 'disc-dot-seen' : 'disc-dot-unseen';
            $list[$idx]['seen_title'] = $seen ? 'Seen' : 'Unseen';
        }
        return $list;
    }

    /**
     * Decorate internal routers with seen and convert their children
     * from plain IP strings to arrays with ip + seen + online.
     *
     * @param array<int, array<string, mixed>> $routers
     * @param array<string, bool> $seenMap
     * @param array<string, bool|null> $onlineMap IP → online lookup (null = unknown)
     * @return array<int, array<string, mixed>>
     */
    private static function decorateInternalRouters(array $routers, array $seenMap, array $onlineMap): array
    {
        foreach ($routers as $idx => $r) {
            $rSeen = false;
            if (array_key_exists($r['ip'], $seenMap)) {
                $rSeen = (bool)$seenMap[$r['ip']];
                $routers[$idx]['seen'] = $rSeen;
            }
            $routers[$idx]['seen_class'] = $rSeen ? 'disc-dot-seen' : 'disc-dot-unseen';
            $routers[$idx]['seen_title'] = $rSeen ? 'Seen' : 'Unseen';
            // The router's own online is already carried by normalizeRouter
            // (from the backend graph); $onlineMap is only used for children.
            $routers[$idx]['children']  = array_map(
                static function (string $ip) use ($seenMap, $onlineMap): array {
                    $child = ['ip' => $ip];
                    $seen = false;
                    if (array_key_exists($ip, $seenMap)) {
                        $seen = (bool)$seenMap[$ip];
                        $child['seen'] = $seen;
                    }
                    $child['online'] = $onlineMap[$ip] ?? null;
                    $child['seen_class'] = $seen ? 'disc-dot-seen' : 'disc-dot-unseen';
                    $child['seen_title'] = $seen ? 'Seen' : 'Unseen';
                    return $child;
                },
                $r['children'] ?? []
            );
        }
        return $routers;
    }

    /**
     * Decorate the central router node (the machine itself) with seen status
     * and decorate its directly-connected segments.
     *
     * @param array<string, mixed>|null $central
     * @param array<string, bool> $seenMap
     * @param array<string, bool|null> $onlineMap IP → online lookup (null = unknown)
     * @return array<string, mixed>|null
     */
    private static function decorateCentralRouter(?array $central, array $seenMap, array $onlineMap): ?array
    {
        if (!is_array($central)) {
            return null;
        }
        $seen = false;
        if (array_key_exists($central['ip'] ?? '', $seenMap)) {
            $seen = (bool)$seenMap[$central['ip']];
        }
        $central['seen'] = $seen;
        $central['seen_class'] = $seen ? 'disc-dot-seen' : 'disc-dot-unseen';
        $central['seen_title'] = $seen ? 'Seen' : 'Unseen';
        // The central router's online is already carried by formatGraph.
        $central['segments'] = self::decorateSegments($central['segments'] ?? [], $seenMap, $onlineMap);
        $central['has_kids'] = !empty($central['segments']);
        return $central;
    }

    /**
     * Recursively enrich WAN tree nodes with pre-computed render flags and seen status.
     *
     * @param array<int, array<string, mixed>> $nodes
     * @param array<string, bool> $seenMap
     * @param int $depth
     * @return array<int, array<string, mixed>>
     */
    private static function enrichWanTrees(array $nodes, array $seenMap = [], int $depth = 0): array
    {
        $result = [];
        foreach ($nodes as $node) {
            $children = $node['children'] ?? [];
            $targets  = $node['targets']  ?? [];
            $enrichedChildren = self::enrichWanTrees($children, $seenMap, $depth + 1);
            $enriched = [
                'ip'           => $node['ip']           ?? '',
                'hops_from_gw' => $node['hops_from_gw'] ?? 0,
                'vendor'       => $node['vendor']       ?? '',
                'source'       => $node['source']       ?? '',
                'source_label' => $node['source_label'] ?? '',
                'targets'      => $targets,
                'children'     => $enrichedChildren,
                'has_kids'     => !empty($children) || !empty($targets),
                'is_root'      => $depth === 0,
                'kids_count'   => count($children) + count($targets),
            ];
            if (array_key_exists($node['ip'], $seenMap)) {
                $seen = (bool)$seenMap[$node['ip']];
                $enriched['seen'] = $seen;
            } else {
                $seen = false;
            }
            $enriched['seen_class'] = $seen ? 'disc-dot-seen' : 'disc-dot-unseen';
            $enriched['seen_title'] = $seen ? 'Seen' : 'Unseen';
            $result[] = $enriched;
        }
        return $result;
    }

    /**
     * Check whether a raw timestamp string is within the seen threshold.
     *
     * @param string $rawTimestamp  Raw timestamp from backend (e.g. "2024-01-01T12:00:00Z")
     * @return bool
     */
    private static function isTimestampSeen(string $rawTimestamp): bool
    {
        if ($rawTimestamp === '') {
            return false;
        }
        $ts = strtotime($rawTimestamp);
        if ($ts === false) {
            return false;
        }
        return (time() - $ts) <= self::SEEN_THRESHOLD_SECONDS;
    }

    /**
     * Normalize a backend online/offline value to a strict bool, or null when
     * unknown. Keeps the strict === true/false checks in the 3D topology JS
     * robust against int/string representations (0/1, "0"/"1") from the backend.
     *
     * @param mixed $v
     * @return bool|null
     */
    private static function normalizeOnline($v): ?bool
    {
        if ($v === null || $v === '') {
            return null;
        }
        return (bool)$v;
    }

    /**
     * Pre-compute hosts tab data from the graph structure.
     * Hosts inside segments come fully populated from the backend with roles/services.
     *
     * @param array<string, mixed> $graph  Formatted graph from formatGraph()
     * @return array<string, mixed>
     */
    private static function prepareHostsTabData(array $graph): array
    {
        $segData = [];

        // Collect segments at any nesting depth. A segment can contain routers
        // (infrastructure) that own their own nested segments, e.g. a spine
        // inside a transit /31 owns the BGP-learned or routed subnets hanging
        // from it. Hosts inside those nested segments (like the p2p transit
        // interfaces bucketed under a /24 aggregate) would otherwise be
        // invisible in the hosts view.
        $allSegs = [];
        $seenSegs = [];
        $collectSegments = null;
        $collectSegments = static function (array $seg) use (&$collectSegments, &$allSegs, &$seenSegs): void {
            $cidr = (string)($seg['cidr'] ?? '');
            if ($cidr !== '') {
                if (isset($seenSegs[$cidr])) {
                    return;
                }
                $seenSegs[$cidr] = true;
            }
            $allSegs[] = $seg;
            foreach ($seg['routers'] ?? [] as $rtr) {
                if (!is_array($rtr)) {
                    continue;
                }
                foreach ($rtr['segments'] ?? [] as $rseg) {
                    if (is_array($rseg)) {
                        $collectSegments($rseg);
                    }
                }
            }
        };

        foreach ($graph['gateways'] ?? [] as $gw) {
            foreach ($gw['segments'] ?? [] as $seg) {
                if (is_array($seg)) {
                    $collectSegments($seg);
                }
            }
        }
        // Central router: the machine's directly-connected segments.
        $centralHosts = $graph['central_router'] ?? null;
        if (is_array($centralHosts)) {
            foreach ($centralHosts['segments'] ?? [] as $seg) {
                if (is_array($seg)) {
                    $collectSegments($seg);
                }
            }
        }
        foreach ($graph['internal_routers'] ?? [] as $rtr) {
            foreach ($rtr['segments'] ?? [] as $seg) {
                if (is_array($seg)) {
                    $collectSegments($seg);
                }
            }
        }
        foreach ($graph['orphan_segments'] ?? [] as $seg) {
            if (is_array($seg)) {
                $collectSegments($seg);
            }
        }

        foreach ($allSegs as $seg) {
            $segHosts = [];

            // Add routers from seg.routers as host-like rows
            foreach ($seg['routers'] ?? [] as $rtr) {
                $segHosts[] = self::routerToHostRow($rtr);
            }

            foreach ($seg['hosts'] ?? [] as $h) {
                $segHosts[] = $h;
            }

            $segData[] = [
                'cidr'  => $seg['cidr'] ?? '',
                'iface' => $seg['iface'] ?? '',
                'hosts' => $segHosts,
            ];
        }

        return [
            'segments'   => $segData,
        ];
    }

    /**
     * Convert a segment router entry to a host-row-compatible array for the hosts tab.
     *
     * @param array<string, mixed> $rtr
     * @return array<string, mixed>
     */
    private static function routerToHostRow(array $rtr): array
    {
        $mac = $rtr['mac'] ?? '';
        $vendor = $rtr['vendor'] ?? '';
        $source = $rtr['source'] ?? 'inferred';
        return [
            'ip'                => $rtr['ip'] ?? '',
            'mac'               => $mac,
            'iface'             => '',
            'source'            => $source,
            'first_seen'        => '-',
            'last_seen'         => '-',
            'vendor'            => $vendor,
            'hostname'          => $rtr['hostname'] ?? null,
            'ttl'               => null,
            'os_guess'          => null,
            'hops'              => null,
            'l2_confirmed'      => false,
            'traceroute'        => [],
            'seen'              => false,
            'seen_class'        => 'disc-dot-unseen',
            'seen_title'        => 'Unseen',
            'source_label'      => 'Router (' . $source . ')',
            'mac_display'       => $mac !== '' ? $mac : '-',
            'vendor_display'    => $vendor !== '' ? $vendor : '-',
            'os_display'        => '-',
            'l2_confirmed_html' => '',
        ];
    }

    /**
     * @param array<string, mixed> $raw
     * @return array<string, mixed>
     */
    private static function formatStatus(array $raw): array
    {
        return [
            'running'      => (bool)($raw['running'] ?? false),
            'paused'       => (bool)($raw['paused'] ?? false),
            'packet_count' => (int)($raw['packet_count'] ?? 0),
        ];
    }

    /**
     * @param array<string, mixed> $raw
     * @return array<string, mixed>
     */
    private static function formatStats(array $raw): array
    {
        return [
            'total'                => (int)($raw['total'] ?? 0),
            'with_mac'             => (int)($raw['with_mac'] ?? 0),
            'with_hostname'        => (int)($raw['with_hostname'] ?? 0),
            'router_count'         => (int)($raw['router_count'] ?? 0),
            'packet_count'         => (int)($raw['packet_count'] ?? 0),
            'discovered_last_hour' => (int)($raw['discovered_last_hour'] ?? 0),
            'discovered_last_24h'  => (int)($raw['discovered_last_24h'] ?? 0),
            'discovered_last_week' => (int)($raw['discovered_last_week'] ?? 0),
            'seen'                 => (int)($raw['seen'] ?? 0),
            'unseen'               => (int)($raw['unseen'] ?? 0),
            'online'               => (int)($raw['online'] ?? 0),
            'offline'              => (int)($raw['offline'] ?? 0),
            'by_source'            => $raw['by_source'] ?? [],
            'top_vendors'          => self::escapeVendorList($raw['top_vendors'] ?? []),
        ];
    }

    /**
     * Normalize the pre-structured topology graph from get_topology_graph.
     *
     * @param array<string, mixed> $raw  graph object from the backend
     * @return array<string, mixed>
     */
    private static function formatGraph(AppContext $ctx, array $raw): array
    {
        $gateways = [];
        foreach ($raw['gateways'] ?? [] as $g) {
            if (!is_array($g)) {
                continue;
            }
            $gateways[] = [
                'ip'         => (string)($g['ip'] ?? ''),
                'mac'        => (string)($g['mac'] ?? ''),
                'vendor'     => (string)($g['vendor'] ?? ''),
                'hostname'   => isset($g['hostname']) ? (string)$g['hostname'] : null,
                'iface'      => isset($g['iface'])    ? (string)$g['iface']    : null,
                'is_default' => (bool)($g['is_default'] ?? false),
                'metric'     => (int)($g['metric'] ?? 0),
                'online'     => self::normalizeOnline($g['online'] ?? null),
                'online_checked_at' => $g['online_checked_at'] ?? null,
                'online_via' => $g['online_via'] ?? null,
                'segments'   => self::normalizeSegments($ctx, $g['segments'] ?? []),
            ];
        }

        $internal_routers = [];
        foreach ($raw['internal_routers'] ?? [] as $r) {
            if (!is_array($r)) {
                continue;
            }
            $children = [];
            foreach ($r['children'] ?? [] as $c) {
                if (is_string($c)) {
                    $children[] = $c;
                }
            }
            $internal_routers[] = [
                'ip'       => (string)($r['ip'] ?? ''),
                'mac'      => (string)($r['mac'] ?? ''),
                'vendor'   => (string)($r['vendor'] ?? ''),
                'hostname' => isset($r['hostname']) ? (string)$r['hostname'] : null,
                'source'   => (string)($r['source'] ?? 'inferred'),
                'asn'      => isset($r['asn']) ? (string)$r['asn'] : null,
                'online'   => self::normalizeOnline($r['online'] ?? null),
                'online_checked_at' => $r['online_checked_at'] ?? null,
                'online_via' => $r['online_via'] ?? null,
                'children' => $children,
                'segments' => self::normalizeSegments($ctx, $r['segments'] ?? []),
            ];
        }

        $wan_trees = [];
        foreach ($raw['wan_trees'] ?? [] as $node) {
            if (is_array($node)) {
                $wan_trees[] = self::normalizeWanNode($node);
            }
        }

        $unclassified = [];
        foreach ($raw['unclassified'] ?? [] as $h) {
            if (is_array($h)) {
                $unclassified[] = self::normalizeHostSummary($ctx, $h);
            }
        }

        $orphan_segs = self::normalizeSegments($ctx, $raw['orphan_segments'] ?? []);

        $central_router = null;
        if (isset($raw['central_router']) && is_array($raw['central_router'])) {
            $cr = $raw['central_router'];
            $central_router = [
                'ip'       => (string)($cr['ip'] ?? ''),
                'mac'      => (string)($cr['mac'] ?? ''),
                'vendor'   => (string)($cr['vendor'] ?? ''),
                'hostname' => isset($cr['hostname']) ? (string)$cr['hostname'] : null,
                'source'   => (string)($cr['source'] ?? 'styx'),
                'online'   => self::normalizeOnline($cr['online'] ?? null),
                'online_checked_at' => $cr['online_checked_at'] ?? null,
                'online_via' => $cr['online_via'] ?? null,
                'segments' => self::normalizeSegments($ctx, $cr['segments'] ?? []),
            ];
        }

        return [
            'gateways'           => $gateways,
            'is_router'          => (bool)($raw['is_router'] ?? false),
            'central_router'     => $central_router,
            'internal_routers'   => $internal_routers,
            'orphan_segments'    => $orphan_segs,
            'unclassified'       => $unclassified,
            'wan_trees'          => $wan_trees,
            '_debug_raw_gw'      => count($raw['gateways'] ?? []),
        ];
    }

    /**
     * Normalize an array of segment entries.
     *
     * @param array<int, array<string, mixed>> $rawSegments
     * @return array<int, array<string, mixed>>
     */
    private static function normalizeSegments(AppContext $ctx, array $rawSegments): array
    {
        $segments = [];
        foreach ($rawSegments as $seg) {
            if (!is_array($seg)) {
                continue;
            }
            $hosts = [];
            foreach ($seg['hosts'] ?? [] as $h) {
                if (is_array($h)) {
                    $hosts[] = self::normalizeHostSummary($ctx, $h);
                }
            }
            $routerInfo = null;
            if (isset($seg['router_info']) && is_array($seg['router_info'])) {
                $ri = $seg['router_info'];
                $routerInfo = [
                    'ip'           => (string)($ri['ip'] ?? ''),
                    'mac'          => (string)($ri['mac'] ?? ''),
                    'hostname'     => isset($ri['hostname']) ? (string)$ri['hostname'] : null,
                    'vendor'       => (string)($ri['vendor'] ?? ''),
                    'is_default'   => (bool)($ri['is_default'] ?? false),
                    'metric'       => (int)($ri['metric'] ?? 0),
                    'source'       => (string)($ri['source'] ?? ''),
                    'gateway_kind' => (string)($ri['gateway_kind'] ?? ''),
                    'online'       => self::normalizeOnline($ri['online'] ?? null),
                    'online_checked_at' => $ri['online_checked_at'] ?? null,
                    'online_via'   => $ri['online_via'] ?? null,
                ];
            }
            $routers = [];
            foreach ($seg['routers'] ?? [] as $r) {
                if (is_array($r)) {
                    $routers[] = self::normalizeRouter($ctx, $r);
                }
            }
            $segments[] = [
                'cidr'        => (string)($seg['cidr'] ?? ''),
                'iface'       => (string)($seg['iface'] ?? ''),
                'src'         => isset($seg['src']) ? (string)$seg['src'] : null,
                'type'        => (string)($seg['type'] ?? 'local'),
                'as_path'     => $seg['as_path'] ?? [],
                'origin'      => (string)($seg['origin'] ?? ''),
                'paths'       => $seg['paths'] ?? [],
                'router_info' => $routerInfo,
                'routers'     => $routers,
                'hosts'       => $hosts,
                'hypervisors' => self::normalizeHypervisors($ctx, $seg['hypervisors'] ?? []),
            ];
        }
        return $segments;
    }

    /**
     * Normalize a router entry inside a segment.
     *
     * @param array<string, mixed> $r
     * @return array<string, mixed>
     */
    private static function normalizeRouter(AppContext $ctx, array $r): array
    {
        $children = [];
        foreach ($r['children'] ?? [] as $c) {
            if (is_string($c)) {
                $children[] = $c;
            }
        }
        return [
            'ip'       => (string)($r['ip'] ?? ''),
            'mac'      => (string)($r['mac'] ?? ''),
            'vendor'   => (string)($r['vendor'] ?? ''),
            'hostname' => isset($r['hostname']) ? (string)$r['hostname'] : null,
            'source'   => (string)($r['source'] ?? 'inferred'),
            'asn'      => isset($r['asn']) ? (string)$r['asn'] : null,
            'online'   => self::normalizeOnline($r['online'] ?? null),
            'online_checked_at' => $r['online_checked_at'] ?? null,
            'online_via' => $r['online_via'] ?? null,
            'children' => $children,
            'segments' => self::normalizeSegments($ctx, $r['segments'] ?? []),
        ];
    }

    /**
     * Normalize an array of hypervisor entries.
     *
     * @param array<int, array<string, mixed>> $rawHypervisors
     * @return array<int, array<string, mixed>>
     */
    private static function normalizeHypervisors(AppContext $ctx, array $rawHypervisors): array
    {
        $hypervisors = [];
        foreach ($rawHypervisors as $hv) {
            if (!is_array($hv)) {
                continue;
            }
            $vms = [];
            foreach ($hv['vms'] ?? [] as $vm) {
                if (is_array($vm)) {
                    $vms[] = self::normalizeVmSummary($ctx, $vm);
                }
            }
            $hypervisors[] = [
                'ip'       => (string)($hv['ip'] ?? ''),
                'mac'      => (string)($hv['mac'] ?? ''),
                'vendor'   => (string)($hv['vendor'] ?? ''),
                'hostname' => isset($hv['hostname']) ? (string)$hv['hostname'] : null,
                'source'   => (string)($hv['source'] ?? ''),
                'vms'      => $vms,
            ];
        }
        return $hypervisors;
    }

    /**
     * @param array<string, mixed> $h
     * @return array<string, mixed>
     */
    private static function normalizeHostSummary(AppContext $ctx, array $h): array
    {
        $srcKey = (string)($h['source'] ?? '');
        $srcLabel = '';
        if ($srcKey !== '') {
            $label = self::SOURCE_LABELS[$srcKey] ?? $srcKey;
            $srcLabel = Filter::escHtml($label);
        }
        $rawLastSeen = (string)($h['last_seen'] ?? '');
        $seen = self::isTimestampSeen($rawLastSeen);
        $vendor = (string)($h['vendor'] ?? '');
        $mac = (string)($h['mac'] ?? '');
        $osGuess = $h['os_guess'] ?? null;
        $l2Confirmed = (bool)($h['l2_confirmed'] ?? false);
        $hostname = isset($h['hostname']) ? (string)$h['hostname'] : null;
        $mdnsName = $h['mdns_hostname'] ?? null;

        // Pre-render display fields.
        $mdnsTitle = $mdnsName !== null ? ' title="' . Filter::escHtml($mdnsName) . '"' : '';
        if ($hostname !== null) {
            $hostnameHtml = Filter::escHtml($hostname);
        } elseif ($mdnsName !== null) {
            $hostnameHtml = '<em class="disc-mdns-name">' . Filter::escHtml($mdnsName) . '</em>';
        } else {
            $hostnameHtml = '<em class="disc-pending">-</em>';
        }
        $rolesList = $h['roles'] ?? [];
        $rolesHtml = '';
        foreach ($rolesList as $role) {
            $rolesHtml .= '<span class="std-badge std-badge--std">' . Filter::escHtml($role) . '</span> ';
        }

        return [
            'ip'                => (string)($h['ip'] ?? ''),
            'mac'               => $mac,
            'vendor'            => $vendor,
            'hostname'          => $hostname,
            'source'            => $srcKey,
            'source_label'      => $srcLabel,
            'l2_confirmed'      => $l2Confirmed,
            'first_seen'        => (string)($h['first_seen'] ?? ''),
            'last_seen'         => $rawLastSeen,
            'online'            => self::normalizeOnline($h['online'] ?? null),
            'online_checked_at' => $h['online_checked_at'] ?? null,
            'online_via'        => $h['online_via'] ?? null,
            'ttl'               => $h['ttl'] ?? null,
            'os_guess'          => $osGuess,
            'hops'              => $h['hops'] ?? null,
            'mdns_hostname'     => $mdnsName,
            'mdns_model'        => $h['mdns_model'] ?? null,
            'roles'             => $rolesList,
            'services'          => $h['services'] ?? [],
            'seen'              => $seen,
            'seen_class'        => $seen ? 'disc-dot-seen' : 'disc-dot-unseen',
            'seen_title'        => $seen ? 'Seen' : 'Unseen',
            'mac_display'       => $mac !== '' ? $mac : '-',
            'vendor_display'    => $vendor !== '' ? $vendor : '-',
            'os_display'        => $osGuess !== null ? $osGuess : '-',
            'l2_confirmed_html' => $l2Confirmed ? '<span class="disc-l2-yes" title="L2 confirmed">&#10003;</span>' : '',
            'iface'             => (string)($h['iface'] ?? ''),
            'hostname_html'     => $hostnameHtml,
            'mdns_title'        => $mdnsTitle,
            'roles_html'        => $rolesHtml,
            'last_seen_display' => $rawLastSeen !== '' ? DateFormatter::fromBackend($ctx, $rawLastSeen) : ' - ',
        ];
    }

    /**
     * Like normalizeHostSummary but with the extra hypervisor_vendor field.
     *
     * @param array<string, mixed> $h
     * @return array<string, mixed>
     */
    private static function normalizeVmSummary(AppContext $ctx, array $h): array
    {
        $out = self::normalizeHostSummary($ctx, $h);
        $out['hypervisor_vendor'] = isset($h['hypervisor_vendor'])
            ? (string)$h['hypervisor_vendor'] : '';
        return $out;
    }

    /**
     * Recursively normalize a WAN tree node.
     *
     * @param array<string, mixed> $node
     * @return array<string, mixed>
     */
    private static function normalizeWanNode(array $node): array
    {
        $children = [];
        foreach ($node['children'] ?? [] as $child) {
            if (is_array($child)) {
                $children[] = self::normalizeWanNode($child);
            }
        }
        $targets = [];
        foreach ($node['targets'] ?? [] as $t) {
            if (is_string($t) && $t !== '') {
                $targets[] = $t;
            }
        }
        return [
            'ip'           => (string)($node['ip'] ?? ''),
            'hops_from_gw' => (int)($node['hops_from_gw'] ?? 0),
            'vendor'       => (string)($node['vendor'] ?? ''),
            'source'       => (string)($node['source'] ?? ''),
            'targets'      => $targets,
            'children'     => $children,
        ];
    }

    /**
     * Split VM list into those matching a CIDR and those that don't.
     *
     * @param string $cidr
     * @param array<int, array<string, mixed>> $vms
     * @return array{0: array<int, array<string, mixed>>, 1: array<int, array<string, mixed>>}
     */
    /** @var array<string, array{label: string, desc: string, runtime: bool}> Feature metadata for settings UI. */
    private const FEATURE_META = [
        'ip_ttl'       => [
            'label'   => 'IP/TTL Sniffing',
            'desc'    => 'OS fingerprinting and router-behind detection',
            'runtime' => true,
        ],
        'cdp'          => [
            'label'   => 'CDP Parsing',
            'desc'    => 'Cisco Discovery Protocol frame parsing',
            'runtime' => true,
        ],
        'lldp'         => [
            'label'   => 'LLDP Parsing',
            'desc'    => 'LLDP frame parsing',
            'runtime' => true,
        ],
        'arp_sweep'    => [
            'label'   => 'ARP Sweep at Start',
            'desc'    => 'ARP broadcast sweep on startup/on-demand',
            'runtime' => false,
        ],
        'traceroute'   => [
            'label'   => 'Traceroute at Start',
            'desc'    => 'ICMP traceroute on startup/on-demand',
            'runtime' => false,
        ],
        'conntrack'    => [
            'label'   => 'Conntrack Polling',
            'desc'    => 'nf_conntrack polling (router mode only)',
            'runtime' => true,
        ],
        'dhcp_leases'  => [
            'label'   => 'DHCP Lease Parsing',
            'desc'    => 'DHCP lease parsing (router mode)',
            'runtime' => true,
        ],
        'dns_resolve'  => [
            'label'   => 'DNS Resolution',
            'desc'    => 'Background DNS hostname resolution loop',
            'runtime' => true,
        ],
        'topology'     => [
            'label'   => 'Topology Inference',
            'desc'    => 'Background topology inference loop',
            'runtime' => true,
        ],
        'upnp_igd'     => [
            'label'   => 'UPnP IGD Probe',
            'desc'    => 'SSDP discovery + WAN IP + port mappings',
            'runtime' => true,
        ],
        'mdns'         => [
            'label'   => 'mDNS Snooping',
            'desc'    => 'Multicast DNS/Bonjour passive discovery',
            'runtime' => true,
        ],
        'bgp'          => [
            'label'   => 'BGP Topology',
            'desc'    => 'BGP peers + learned prefixes via FRR vtysh (router mode)',
            'runtime' => true,
        ],
        'ping'         => [
            'label'   => 'Active Ping Polling',
            'desc'    => 'ICMP reachability polling for online/offline (needs CAP_NET_RAW)',
            'runtime' => true,
        ],
        'bfd'          => [
            'label'   => 'BGP/BFD Evidence',
            'desc'    => 'Online/offline from BGP-Established + BFD sessions (router mode)',
            'runtime' => true,
        ],
    ];

    /**
     * Format raw discovery settings for the settings tab template.
     *
     * @param array<string, mixed> $raw  Raw result from discovery.get_settings backend call.
     * @return array<string, mixed>
     */
    public static function formatSettings(array $raw): array
    {
        $settings = $raw['settings'] ?? $raw;
        $enabledFeatures = $settings['features'] ?? [];

        $features = [];
        foreach (self::FEATURE_META as $key => $meta) {
            $features[$key] = [
                'label'   => $meta['label'],
                'desc'    => $meta['desc'],
                'runtime' => $meta['runtime'],
                'enabled' => in_array($key, $enabledFeatures, true),
            ];
        }

        return [
            'running'      => (bool)($settings['running'] ?? false),
            'paused'       => (bool)($settings['paused'] ?? false),
            'max_wan_hops' => (int)($settings['max_wan_hops'] ?? 0),
            'sweep_delay'  => (float)($settings['sweep_delay'] ?? 0),
            'features'     => $features,
        ];
    }

    /**
     * Escape vendor strings in a vendor list array.
     *
     * @param array<int, array<string, mixed>> $vendors
     * @return array<int, array<string, mixed>>
     */
    private static function escapeVendorList(array $vendors): array
    {
        return array_map(function (array $v): array {
            if (isset($v['vendor'])) {
                $v['vendor'] = Filter::escHtml((string) $v['vendor']);
            }
            return $v;
        }, $vendors);
    }
}
