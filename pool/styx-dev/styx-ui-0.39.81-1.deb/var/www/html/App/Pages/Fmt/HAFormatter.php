<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class HAFormatter
{
    /**
     * Normalize conntrackd status/config data for the ha template.
     *
     * @param array<string,mixed> $data  Backend `conntrackd.get_conntrackd_status`
     *                                   result merged with the interface list.
     * @return array<string,mixed>
     */
    public static function format(array $data): array
    {
        $config = $data['config'] ?? [];
        $sync = $config['sync'] ?? [];
        $transport = $sync['transport'] ?? 'multicast';
        $data['config'] = $config;
        $data['sync'] = $sync;
        $data['transport'] = $transport;

        // Interface picker options: flatten the fallback chain into a label.
        $ifaces = $data['ifaces'] ?? [];
        foreach ($ifaces as &$ifc) {
            $ifc['label'] = (string)($ifc['interface'] ?? $ifc['name'] ?? $ifc['id'] ?? '');
        }
        unset($ifc);
        $data['ifaces'] = $ifaces;

        // Set picker labels: id => name maps for address and port sets.
        $data['address_sets_map'] = self::setNameMap($data['address_sets'] ?? []);
        $data['port_sets_map'] = self::setNameMap($data['port_sets'] ?? []);

        // Status booleans.
        $service = $data['service'] ?? [];
        $data['installed']      = !empty($service['installed']);
        $data['service_active'] = !empty($service['active']);
        $data['service_enabled'] = !empty($service['enabled']);
        $data['firewall_hint']  = $data['firewall_hint'] ?? [];

        return $data;
    }

    /**
     * Build an id => name map from a list of set dicts.
     *
     * @param array<string,mixed> $sets
     * @return array<string,string>
     */
    private static function setNameMap(array $sets): array
    {
        $map = [];
        foreach ($sets as $set) {
            if (!empty($set['id']) && !empty($set['name'])) {
                $map[(string)$set['id']] = (string)$set['name'];
            }
        }
        return $map;
    }
}
