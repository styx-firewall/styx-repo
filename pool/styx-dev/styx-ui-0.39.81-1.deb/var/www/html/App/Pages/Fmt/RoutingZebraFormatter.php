<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class RoutingZebraFormatter
{
    /** @var string[] Protocols rendered in a fixed order for route-map assignment. */
    private const PROTOCOL_RM_LIST = [
        'any', 'babel', 'bgp', 'eigrp', 'isis', 'nhrp',
        'ospf', 'ospf6', 'rip', 'ripng', 'static', 'table',
    ];

    /** @param array<string,mixed> $data @param string[] $userCaps */
    public static function format(array $data, array $userCaps = []): array
    {
        $data['can_save'] = RoleHelper::hasCapability($userCaps, 'routing:write');

        $zc = $data['zebra_config'] ?? [];
        $zc['router_id_label']        = self::pickerLabel($zc['router_id_display'] ?? null, 'Select Router ID');
        $zc['router_id_clear_hidden'] = self::pickerClearHidden($zc['router_id_display'] ?? null);
        $data['zebra_config'] = $zc;

        $data['protocol_rm_list'] = self::PROTOCOL_RM_LIST;

        // Protocol route-map rows: merge per-protocol state with the route-map options.
        $protoRms = $zc['protocol_route_maps'] ?? [];
        $routeMaps = $data['route_maps'] ?? [];
        $rows = [];
        foreach (self::PROTOCOL_RM_LIST as $proto) {
            $existing = null;
            foreach ($protoRms as $pr) {
                if (($pr['protocol'] ?? '') === $proto) {
                    $existing = $pr;
                    break;
                }
            }
            $rmOptions = [];
            foreach ($routeMaps as $rmap) {
                $rmOptions[] = [
                    'id'       => $rmap['id'] ?? '',
                    'name'     => $rmap['name'] ?? '',
                    'selected' => ($existing && ($existing['route_map'] ?? null) === ($rmap['id'] ?? null)) ? 'selected' : '',
                ];
            }
            $rows[] = [
                'proto'      => $proto,
                'label'      => ucfirst($proto),
                'checked'    => $existing ? 'checked' : '',
                'route_maps' => $rmOptions,
            ];
        }
        $data['zebra_protocol_rm'] = $rows;

        return $data;
    }

    /** @param mixed $d */
    private static function pickerLabel($d, string $placeholder): string
    {
        return !empty($d) && is_array($d) && !empty($d['name'])
            ? (string)$d['name']
            : $placeholder;
    }

    /** @param mixed $d */
    private static function pickerClearHidden($d): string
    {
        return !empty($d) ? '' : ' sets-hidden';
    }
}
