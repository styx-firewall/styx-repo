<?php
/**
 * Pre-computes sidebar section visibility based on user capabilities and features.
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class SidebarFormatter
{
    /**
     * Map of sidebar sections to required capability and optional feature check.
     */
    private const SECTIONS = [
        'network'         => ['cap' => 'network:read'],
        'routing'         => ['cap' => 'routing:read',  'feature' => ['frrouting', 'igmp_proxy']],
        'firewall'        => ['cap' => 'firewall:read'],
        'packet_marking'  => ['cap' => 'packet_marking:read', 'feature' => ['packet_marking']],
        'ebpf'            => ['cap' => 'ebpf:read',     'feature' => ['ebpf_core', 'ebpf_bcc']],
        'objects'         => ['cap' => 'objects:read'],
        'traffic_shaping' => ['cap' => 'traffic_shaping:read', 'feature' => ['tc']],
        'services'        => ['cap' => 'services:read', 'feature' => ['kea_dhcp4']],
        'ha'              => ['cap' => 'ha:read', 'feature' => ['conntrackd']],
        'system'          => ['cap' => 'system:read'],
        'vpn'             => ['cap' => 'vpn:read',      'feature' => ['vpn']],
        'idsips'          => ['cap' => 'idsips:read',    'feature' => ['ids_ips']],
        'styx'            => ['cap' => 'styx:read'],
        'users'           => ['cap' => 'users:read'],
        'user_roles'      => ['cap' => 'users:admin'],
        'role_definitions' => ['cap' => 'users:admin'],
        'security'        => ['cap' => 'security:read'],
        'logs'            => ['cap' => 'logs:read'],
        'bearer_tokens'   => ['cap' => 'users:read',    'feature' => ['bearer_tokens']],
    ];

    /**
     * Compute visibility flags for all sidebar sections.
     *
     * @param string[] $userCaps
     * @param array<string,mixed> $features
     * @return array<string,bool>
     */
    public static function compute(array $userCaps, array $features): array
    {
        $visible = [];
        foreach (self::SECTIONS as $key => $config) {
            $hasCap = RoleHelper::hasCapability($userCaps, $config['cap']);
            if (!$hasCap) {
                $visible[$key] = false;
                continue;
            }
            if (!empty($config['feature'])) {
                $hasFeature = false;
                foreach ($config['feature'] as $f) {
                    if (!empty($features[$f])) {
                        $hasFeature = true;
                        break;
                    }
                }
                if (!$hasFeature) {
                    $visible[$key] = false;
                    continue;
                }
            }
            $visible[$key] = true;
        }
        return $visible;
    }
}
