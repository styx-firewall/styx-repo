<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

class RoutingFormatter
{
    /**
     * Prepare routing page data for template consumption.
     *
     * Thin dispatcher to the per-feature formatters; keeps the page controller
     * call site unchanged.
     *
     * @param string $section
     * @param array<string,mixed> $fmt_data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(string $section, array $fmt_data, array $userCaps = []): array
    {
        switch ($section) {
            case 'routing-bgp':
                return RoutingBgpFormatter::format($fmt_data, $userCaps);
            case 'routing-ospf':
                return RoutingOspfFormatter::format($fmt_data, $userCaps);
            case 'routing-overview':
                return RoutingOverviewFormatter::format($fmt_data);
            case 'routing-igmp-proxy':
                return RoutingIgmpProxyFormatter::format($fmt_data);
            case 'routing-bfd':
                return RoutingBfdFormatter::format($fmt_data);
            case 'routing-rip':
                return RoutingRipFormatter::format($fmt_data, $userCaps);
            case 'routing-frr':
                return RoutingFrrFormatter::format($fmt_data);
            case 'routing-policies':
                return RoutingPoliciesFormatter::format($fmt_data, $userCaps);
            case 'routing-frr-static':
                return RoutingFrrStaticFormatter::format($fmt_data, $userCaps);
            case 'routing-vrrp':
                return RoutingVrrpFormatter::format($fmt_data, $userCaps);
            case 'routing-zebra':
                return RoutingZebraFormatter::format($fmt_data, $userCaps);
            case 'routing-evpn':
                return RoutingEvpnFormatter::format($fmt_data, $userCaps);
        }

        return $fmt_data;
    }
}
