<?php
namespace App\Pages\Fmt;

use App\Helpers\FormatHelper;

class NetTrafficStatsFormatter
{
    /**
     * Normalize traffic stats data for template rendering.
     *
     * @param array $fmt_data
     * @param array $response Gateway response with sets, summary, summary_all
     * @return array
     */
    public static function format(array $fmt_data, array $response): array
    {
        $data = $response['result'] ?? [];

        // Raw sets grouped by direction
        $sets = $data['sets'] ?? [];

        // Pre-categorise sets for the template
        $fmt_data['traffic_sets_in'] = self::normalizeSetEntries($sets['ipv4_traffic_in'] ?? []) +
                                        self::normalizeSetEntries($sets['ipv6_traffic_in'] ?? []);
        $fmt_data['traffic_sets_out'] = self::normalizeSetEntries($sets['ipv4_traffic_out'] ?? []) +
                                         self::normalizeSetEntries($sets['ipv6_traffic_out'] ?? []);
        $fmt_data['traffic_sets_fwd'] = self::normalizeSetEntries($sets['ipv4_traffic_fwd'] ?? []) +
                                         self::normalizeSetEntries($sets['ipv6_traffic_fwd'] ?? []);

        // Per-interface summary (with pre-formatted bytes)
        $fmt_data['traffic_summary'] = self::normalizeSummary($data['summary'] ?? []);

        // Global totals
        $summary_all = $data['summary_all'] ?? [];
        $fmt_data['traffic_summary_all'] = $summary_all;

        // Pretty-print byte totals for display
        $fmt_data['traffic_total_bytes'] = FormatHelper::formatBytes((int)($summary_all['bytes'] ?? 0));
        $fmt_data['traffic_total_packets'] = $summary_all['packets'] ?? 0;
        $fmt_data['traffic_total_flows'] = $summary_all['flows'] ?? 0;

        return $fmt_data;
    }

    /**
     * Normalise set entries into a flat indexed array.
     *
     * @param array $entries
     * @return array
     */
    private static function normalizeSetEntries(array $entries): array
    {
        $out = [];
        foreach ($entries as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $ip = $entry['ip'] ?? ($entry['src_ip'] ?? ($entry['dst_ip'] ?? '-'));
            // Names must follow the same source as the primary ip: in/out
            // entries carry ip+hostname/custom_name, forwarded entries carry
            // src_ip/dst_ip each with its own name pair. Never mix them.
            if (isset($entry['ip'])) {
                $hostname = $entry['hostname'] ?? '';
                $custom_name = $entry['custom_name'] ?? '';
            } elseif (isset($entry['src_ip'])) {
                $hostname = $entry['src_hostname'] ?? '';
                $custom_name = $entry['src_custom_name'] ?? '';
            } else {
                $hostname = $entry['dst_hostname'] ?? '';
                $custom_name = $entry['dst_custom_name'] ?? '';
            }
            $src_name = $entry['src_custom_name'] ?? ($entry['src_hostname'] ?? '');
            $dst_name = $entry['dst_custom_name'] ?? ($entry['dst_hostname'] ?? '');

            $normalized = [
                'iface' => $entry['iface'] ?? '-',
                'ip' => $ip,
                'hostname' => $hostname,
                'custom_name' => $custom_name,
                'name' => $custom_name !== '' ? $custom_name : ($hostname !== '' ? $hostname : '-'),
                'src_ip' => $entry['src_ip'] ?? '',
                'src_hostname' => $entry['src_hostname'] ?? '',
                'src_custom_name' => $entry['src_custom_name'] ?? '',
                'src_name' => $src_name !== '' ? $src_name : '-',
                'dst_ip' => $entry['dst_ip'] ?? '',
                'dst_hostname' => $entry['dst_hostname'] ?? '',
                'dst_custom_name' => $entry['dst_custom_name'] ?? '',
                'dst_name' => $dst_name !== '' ? $dst_name : '-',
                'proto' => $entry['proto'] ?? '-',
                'packets' => (int)($entry['packets'] ?? 0),
                'bytes' => (int)($entry['bytes'] ?? 0),
                'bytes_formatted' => FormatHelper::formatBytes((int)($entry['bytes'] ?? 0)),
                'expires' => $entry['expires'] ?? '-',
            ];
            $out[] = $normalized;
        }
        return $out;
    }

    /**
     * Normalize per-interface summary entries with pre-formatted bytes.
     *
     * @param array $summary Raw summary data keyed by interface name.
     * @return array Normalized summary with bytes_formatted added.
     */
    private static function normalizeSummary(array $summary): array
    {
        $normalized = [];
        foreach ($summary as $iface => $agg) {
            $normalized[$iface] = [
                'packets' => (int)($agg['packets'] ?? 0),
                'bytes' => (int)($agg['bytes'] ?? 0),
                'bytes_formatted' => FormatHelper::formatBytes((int)($agg['bytes'] ?? 0)),
                'flows' => (int)($agg['flows'] ?? 0),
            ];
        }
        return $normalized;
    }
}
