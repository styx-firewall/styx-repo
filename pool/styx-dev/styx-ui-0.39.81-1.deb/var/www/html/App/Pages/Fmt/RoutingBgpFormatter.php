<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;
use App\Services\Filter;

class RoutingBgpFormatter
{
    /** @var string[] Redistribute protocols rendered in a fixed order. */
    private const REDISTRIBUTE_PROTOS = ['connected', 'static', 'ospf', 'rip', 'kernel'];

    /**
     * @param array<string,mixed> $data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(array $data, array $userCaps = []): array
    {
        $canWrite  = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_save']   = $canWrite;
        $data['can_add']    = $canWrite;

        // Global BGP config: normalize defaults + pre-compute display state.
        $bgp = $data['bgp_config'] ?? [];
        $bgp['keepalive'] = isset($bgp['keepalive']) ? (int)$bgp['keepalive'] : 60;
        $bgp['hold_time'] = isset($bgp['hold_time']) ? (int)$bgp['hold_time'] : 180;
        $bgp['default_local_pref'] = isset($bgp['default_local_pref']) ? (int)$bgp['default_local_pref'] : 100;
        $bgp['enabled'] = !empty($bgp['enabled']);
        $bgp['log_neighbor_changes'] = !empty($bgp['log_neighbor_changes']);
        $bgp['always_compare_med'] = !empty($bgp['always_compare_med']);
        $bgp['graceful_restart'] = !empty($bgp['graceful_restart']);
        // preserve any existing display entries (router_as_display, router_id_display)
        $bgp['redistribute'] = $bgp['redistribute'] ?? [];

        // Network Import Check select: null/true/false -> selected option.
        $nic = $bgp['network_import_check'] ?? null;
        $bgp['nic_selected_default'] = $nic === null ? 'selected' : '';
        $bgp['nic_selected_on']       = $nic === true  ? 'selected' : '';
        $bgp['nic_selected_off']      = $nic === false ? 'selected' : '';

        // Label-picker display labels + clear-button visibility.
        $bgp['router_as_label']        = self::pickerLabel($bgp['router_as_display'] ?? null, 'Select AS number');
        $bgp['router_as_clear_hidden'] = self::pickerClearHidden($bgp['router_as_display'] ?? null);
        $bgp['router_id_label']        = self::pickerLabel($bgp['router_id_display'] ?? null, 'Select Router ID');
        $bgp['router_id_clear_hidden'] = self::pickerClearHidden($bgp['router_id_display'] ?? null);
        $bgp['cluster_id_label']       = self::pickerLabel($bgp['cluster_id_display'] ?? null, 'Select Cluster ID');
        $bgp['cluster_id_clear_hidden'] = self::pickerClearHidden($bgp['cluster_id_display'] ?? null);

        $data['bgp_config'] = $bgp;

        // Redistribute rows: merge per-protocol state with the route-map options.
        $data['bgp_redistribute'] = self::buildRedistributeRows(
            $bgp['redistribute'],
            $data['route_maps'] ?? []
        );

        // Neighbors
        $neighbors = $data['neighbors'] ?? [];
        foreach ($neighbors as &$n) {
            // Display-only classification of the real FRR status values
            // (state FSM + peerState condition). No value is fabricated.
            $n['state_bg_class']      = self::bgpStateBgClass($n['peer_status']['state'] ?? null);
            $n['peer_state_bg_class'] = self::bgpPeerStateBgClass($n['peer_status']['peerState'] ?? null);
            // ensure description exists
            $n['description'] = $n['description'] ?? '';
            $n['can_delete']  = $canDelete;

            $n['neighbor_ip_html']    = self::setRefHtml($n['neighbor_ip_set_display'] ?? null, true, false, ' - ');
            $n['remote_as_html']      = self::setRefHtml($n['remote_as_display'] ?? null, false, true, '-');
            $n['address_families_html'] = self::addressFamiliesHtml($n['address_families'] ?? []);
            $n['route_map_in_label']    = self::displayName($n['route_map_in_display'] ?? null);
            $n['route_map_out_label']   = self::displayName($n['route_map_out_display'] ?? null);
            $n['prefix_list_in_label']  = self::displayName($n['prefix_list_in_display'] ?? null);
            $n['prefix_list_out_label'] = self::displayName($n['prefix_list_out_display'] ?? null);
            $n['state_html']            = self::stateHtml($n['peer_status'] ?? null, $n['state_bg_class'], $n['peer_state_bg_class']);
            $n['uptime_label']          = self::peerValue($n['peer_status'] ?? null, 'peerUptime');
            $n['prefixes_label']        = self::peerValue($n['peer_status'] ?? null, 'pfxRcd')
                . ' / ' . self::peerValue($n['peer_status'] ?? null, 'pfxSnt');
            // Escaped for use inside a single-quoted data-detail attribute.
            $n['peer_status_json']      = Filter::escHtml((string) json_encode($n['peer_status'] ?? null));
            $n['next_hop_self_flag']    = !empty($n['next_hop_self']) ? '1' : '0';
            $n['soft_reconfig_flag']    = !empty($n['soft_reconfiguration_inbound']) ? '1' : '0';
            $n['rr_client_flag']        = !empty($n['route_reflector_client']) ? '1' : '0';
            $n['bfd_flag']              = !empty($n['bfd']) ? '1' : '0';
            $n['bfd_cp_failure_flag']   = !empty($n['bfd_check_control_plane_failure']) ? '1' : '0';
            $n['address_families_csv']  = implode(',', $n['address_families'] ?? ['ipv4_unicast']);
        }
        unset($n);
        $data['neighbors'] = $neighbors;

        // Networks
        $networks = $data['networks'] ?? [];
        foreach ($networks as &$nw) {
            $nw['can_delete']  = $canDelete;
            $nw['network_html'] = self::setRefHtml($nw['network_set_display'] ?? null, true, true, '-');
            $nw['family_label'] = (string)($nw['network_set_display']['family'] ?? '-');
        }
        unset($nw);
        $data['networks'] = $networks;

        // Peer groups
        $peerGroups = $data['peer_groups'] ?? [];
        foreach ($peerGroups as &$pg) {
            $pg['can_delete'] = $canDelete;
            $pg['remote_as_html']      = self::nameHtml($pg['remote_as_display'] ?? null);
            $pg['route_map_in_label']  = self::displayName($pg['route_map_in_display'] ?? null);
            $pg['route_map_out_label'] = self::displayName($pg['route_map_out_display'] ?? null);
            $pg['prefix_list_in_label'] = self::displayName($pg['prefix_list_in_display'] ?? null);
            $pg['prefix_list_out_label'] = self::displayName($pg['prefix_list_out_display'] ?? null);
            $pg['next_hop_self_flag']  = !empty($pg['next_hop_self']) ? '1' : '0';
            $pg['bfd_flag']            = !empty($pg['bfd']) ? '1' : '0';
        }
        unset($pg);
        $data['peer_groups'] = $peerGroups;

        return $data;
    }

    /**
     * Build the redistribute rows for the config form.
     *
     * @param array<int,array<string,mixed>> $redist
     * @param array<int,array<string,mixed>> $routeMaps
     * @return array<int,array<string,mixed>>
     */
    private static function buildRedistributeRows(array $redist, array $routeMaps): array
    {
        $rows = [];
        foreach (self::REDISTRIBUTE_PROTOS as $proto) {
            $existing = null;
            foreach ($redist as $r) {
                if (($r['protocol'] ?? '') === $proto) {
                    $existing = $r;
                    break;
                }
            }
            $rmOptions = [];
            foreach ($routeMaps as $rm) {
                $rmOptions[] = [
                    'id'       => $rm['id'] ?? '',
                    'name'     => $rm['name'] ?? '',
                    'selected' => ($existing && ($existing['route_map'] ?? null) === ($rm['id'] ?? null)) ? 'selected' : '',
                ];
            }
            $rows[] = [
                'proto'      => $proto,
                'label'      => ucfirst($proto),
                'checked'    => $existing ? 'checked' : '',
                'metric'     => $existing['metric'] ?? '',
                'route_maps' => $rmOptions,
            ];
        }
        return $rows;
    }

    //
    // Display helpers
    //

    /** @param mixed $d */
    private static function pickerLabel($d, string $placeholder): string
    {
        return !empty($d) && is_array($d) && !empty($d['name'])
            ? (string)$d['name']
            : $placeholder;
    }

    /** @param mixed $d */
    private static function pickerClearHidden($d): string
    {
        return !empty($d) ? '' : ' sets-hidden';
    }

    /** @param mixed $d */
    private static function displayName($d): string
    {
        return !empty($d) && is_array($d) && isset($d['name'])
            ? (string)$d['name']
            : '-';
    }

    /** @param mixed $d */
    private static function nameHtml($d): string
    {
        return !empty($d) && is_array($d)
            ? '<span class="set-ref">' . Filter::escHtml((string)($d['name'] ?? '')) . '</span>'
            : '<span class="text-dim">-</span>';
    }

    /**
     * Build a set-ref span from a *_set_display array.
     *
     * @param mixed $d
     * @param bool $withFamily render the family chip
     * @param bool $withValue  render the value chip
     * @param string $emptyText fallback when no display data
     */
    private static function setRefHtml($d, bool $withFamily, bool $withValue, string $emptyText = '-'): string
    {
        if (empty($d) || !is_array($d)) {
            return '<span class="text-dim">' . $emptyText . '</span>';
        }
        $title = Filter::escHtml(!empty($d['value']) ? (string)$d['value'] : (string)($d['name'] ?? ''));
        $html = '<span class="set-ref" title="' . $title . '">';
        if ($withFamily && !empty($d['family'])) {
            $html .= '<span class="set-type">' . Filter::escHtml((string)$d['family']) . '</span>';
        }
        $html .= '<span class="set-name">' . Filter::escHtml((string)($d['name'] ?? '')) . '</span>';
        if ($withValue && !empty($d['value'])) {
            $html .= '<span class="set-type">' . Filter::escHtml((string)$d['value']) . '</span>';
        }
        $html .= '</span>';
        return $html;
    }

    /** @param array<mixed> $afs */
    private static function addressFamiliesHtml(array $afs): string
    {
        if (empty($afs)) {
            return '<span class="text-dim">-</span>';
        }
        $html = '';
        foreach ($afs as $af) {
            $html .= '<span class="std-badge">' . Filter::escHtml((string)$af) . '</span>';
        }
        return $html;
    }

    /**
     * @param array<string,mixed>|null $ps
     */
    private static function stateHtml($ps, string $stateBg, string $peerStateBg): string
    {
        if (empty($ps)) {
            return '<span class="text-dim">-</span>';
        }
        return '<span class="std-badge std-badge--' . $stateBg . '">'
            . Filter::escHtml((string)($ps['state'] ?? '-')) . '</span>'
            . '<span class="std-badge std-badge--' . $peerStateBg . '">'
            . Filter::escHtml((string)($ps['peerState'] ?? '-')) . '</span>';
    }

    /** @param array<string,mixed>|null $ps */
    private static function peerValue($ps, string $key): string
    {
        return (is_array($ps) && isset($ps[$key])) ? (string)$ps[$key] : '-';
    }

    /**
     * Background badge variant for the BGP FSM state.
     *
     * Display-only classification of the real FRR state value. Unknown values
     * map to 'warning' (amber) so a state we don't know is never shown green.
     */
    private static function bgpStateBgClass(?string $state): string
    {
        switch ($state) {
            case 'Established':
                return 'enabled';
            case 'Connect':
            case 'Active':
            case 'OpenSent':
            case 'OpenConfirm':
                return 'warning';
            case 'Idle':
            case 'Stopped':
                return 'danger';
            default:
                return 'warning';
        }
    }

    /**
     * Background badge variant for the FRR peerState condition.
     *
     * Display-only classification of the real peerState value. Unknown values
     * map to 'warning' so a condition we don't know is never shown green.
     */
    private static function bgpPeerStateBgClass(?string $peerState): string
    {
        switch ($peerState) {
            case 'OK':
                return 'enabled';
            case 'Passive':
            case 'NSF Wait':
                return 'warning';
            case 'Policy':
            case 'Shutdown':
            case 'Prefix Overflow':
                return 'danger';
            default:
                return 'warning';
        }
    }
}
