<?php
namespace App\Pages\Fmt;

class NetTunningFormatter
{
    /**
     * Prepare presentation-ready keys for net-tunning page.
     * Preserves existing semantics from previous PageNetwork logic.
     *
     * @param array $fmt_data
     * @param array $response
     * @return array
     */
    public static function format(array $fmt_data, array $response): array
    {
        $fmt_data['predefined'] = self::prepareItems($response['predefined'] ?? []);
        $fmt_data['custom'] = self::prepareItems($response['custom'] ?? []);

        return $fmt_data;
    }

    /**
     * Normalize presentation fields for sysctl items: computes `differs`
     * (current value differs from a non-trivial default) and the highlight
     * class consumed by the template.
     *
     * @param array $items
     * @return array
     */
    private static function prepareItems(array $items): array
    {
        foreach ($items as $k => $item) {
            if (!is_array($item)) {
                continue;
            }
            $default = $item['default'] ?? '-';
            $value = $item['value'] ?? '';
            $has_default = ($default !== '-' && $default !== '');
            $item['differs'] = $has_default && ($value !== $default);
            $item['hl_class'] = $item['differs'] ? ' sysctl-differs' : '';
            $items[$k] = $item;
        }

        return $items;
    }
}
