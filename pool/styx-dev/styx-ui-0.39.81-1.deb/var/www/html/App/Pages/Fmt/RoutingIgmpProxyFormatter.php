<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class RoutingIgmpProxyFormatter
{
    /**
     * Splits interfaces into upstream / downstream arrays.
     *
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    public static function format(array $data): array
    {
        // Normalize IGMP proxy global config
        $igmp = $data['igmp_config'] ?? [];
        $igmp['enabled'] = !empty($igmp['enabled']);
        $data['igmp_config'] = $igmp;

        $interfaces = $data['interfaces'] ?? [];
        foreach ($interfaces as &$i) {
            $i['iface_label']    = self::ifaceLabel($i);
            $i['whitelist_html'] = self::whitelistHtml($i['whitelist_display'] ?? null);
        }
        unset($i);

        $data['upstream']   = array_values(
            array_filter($interfaces, fn($i) => ($i['role'] ?? '') === 'upstream')
        );
        $data['downstream'] = array_values(
            array_filter($interfaces, fn($i) => ($i['role'] ?? '') === 'downstream')
        );

        // Interface picker options: flatten the fallback chain into a label.
        $igmpIfaces = $data['igmp_ifaces'] ?? [];
        foreach ($igmpIfaces as &$ifc) {
            $ifc['label'] = (string)($ifc['interface'] ?? $ifc['name'] ?? $ifc['id'] ?? '');
        }
        unset($ifc);
        $data['igmp_ifaces'] = $igmpIfaces;

        return $data;
    }

    /** @param array<string,mixed> $iface */
    private static function ifaceLabel(array $iface): string
    {
        $d = $iface['iface_display'] ?? null;
        if (is_array($d)) {
            $v = $d['name'] ?? $d['interface'] ?? null;
            if ($v !== null && $v !== '') {
                return (string)$v;
            }
        }
        return (string)($iface['iface'] ?? '-');
    }

    /** @param mixed $d */
    private static function whitelistHtml($d): string
    {
        if (empty($d) || !is_array($d)) {
            return '<span class="text-dim">-</span>';
        }
        $title = Filter::escHtml(!empty($d['value']) ? (string)$d['value'] : (string)($d['name'] ?? ''));
        return '<span class="set-ref" title="' . $title . '"><span class="set-name">'
            . Filter::escHtml((string)($d['name'] ?? '')) . '</span></span>';
    }
}
