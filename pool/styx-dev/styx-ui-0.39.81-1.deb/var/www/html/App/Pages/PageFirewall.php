<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Controllers\Request\FirewallRequestController;
use App\Controllers\Request\NatRequestController;
use App\Pages\Fmt\FwRulesLocalFormatter;
use App\Pages\Fmt\FwLogsLocalFormatter;
use App\Pages\Fmt\FwLogsFirewallFormatter;
use App\Pages\Fmt\FwLogsCtFormatter;
use App\Pages\Fmt\FwRulesForwardFormatter;
use App\Pages\Fmt\FwRulesMgmtForwardFormatter;
use App\Pages\Fmt\FwRulesMgmtLocalFormatter;
use App\Pages\Fmt\FwSettingsFormatter;
use App\Pages\Fmt\NatFormatter;
use App\Services\AuthService;
use App\Helpers\RoleHelper;


class PageFirewall
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'fw-rules-forward',
            'fw-rules-local',
            'fw-rules-mgmt-local',
            'fw-rules-mgmt-forward',
            'fw-logs-firewall',
            'fw-logs-ct',
            'fw-mgmt-sets',
            'fw-nat',
            'fw-settings',
        ];
        $section = Filter::getString('section');
        $modify = (bool) Filter::getInt('modify');
        $create = (bool) Filter::getInt('create');
        $bypass_filter_raw = Filter::getInt('bypass_filter');
        // Only seeds the initial state of the client-side "Filters" toggle.
        // System rules are always fetched now; the browser hides/shows them.
        $bypass_filter = $bypass_filter_raw !== null ? (bool) $bypass_filter_raw : true;

        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'fw-rules-forward';
        }

        $fmt_data = [];

        // Add necessary scripts based on the section
        if ($section === 'fw-nat') {
            $page['web_main']['scriptlink'][] = '/scripts/core/api-client.js';
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/firewall/fw-nat.js'];
        } elseif ($section === 'fw-settings') {
            $page['web_main']['scriptlink'][] = '/scripts/core/api-client.js';
            $page['web_main']['footer_script'][] = ['src' => '/scripts/firewall/fw-settings.js'];
        } elseif ($section === 'fw-rules-mgmt-forward' || $section === 'fw-rules-mgmt-local') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/firewall/firewall-mgmt-rules.js'];
        } elseif ($section === 'fw-logs-firewall') {
            $page['web_main']['scriptlink'][] = '/scripts/core/state-storage.js';
            $page['web_main']['footer_script'][] = ['src' => '/scripts/firewall/fw-logs-firewall.js'];
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/logs/logTable.js'];
        } elseif ($section === 'fw-logs-ct') {
            $page['web_main']['scriptlink'][] = '/scripts/core/state-storage.js';
            $page['web_main']['footer_script'][] = ['src' => '/scripts/firewall/fw-logs-ct.js'];
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/logs/logTable.js'];
        } elseif ($section === 'fw-rules-local' || $section === 'fw-rules-forward') {
            $page['web_main']['scriptlink'][] = '/scripts/core/state-storage.js';
            $page['web_main']['scriptlink'][] = '/scripts/core/dynamic-table.js';
            $page['web_main']['scriptlink'][] = '/scripts/core/dynamic-draggable-table.js';
            $page['web_main']['footer_script'][] = ['src' => '/scripts/firewall/fw-rules.js'];
        }

        // Request and Format data for presentation in the template
        if ($section === 'fw-logs-firewall') {
            // Prepare presentation keys for unified firewall logs (tabs)
            $fmt_data = FwLogsFirewallFormatter::format($fmt_data);
        } elseif ($section === 'fw-logs-ct') {
            // Prepare presentation keys for conntrack flow logs
            $fmt_data = FwLogsCtFormatter::format($fmt_data);
        } elseif ($section === 'fw-rules-forward') {
            $fwController = new FirewallRequestController($ctx);
            // Always send all rules (including system rules); the client-side
            // "Filters" toggle hides system rows without a page reload.
            $response = $fwController->getFirewallRules(
                ['table' => ['filter'], 'chain' => ['forward']]
            );
            $fmt_data['rules'] = ($response['status'] ?? '') === 'success' ? $response['result'] : [];
            // Format rules for presentation (moved from template)
            if (is_array($fmt_data)) {
                $fmt_data = FwRulesForwardFormatter::format($fmt_data);
            }
        } elseif ($section === 'fw-rules-local') {
            $fwController = new FirewallRequestController($ctx);
            // Always send all rules (including system rules); the client-side
            // "Filters" toggle hides system rows without a page reload.
            $response = $fwController->getFirewallRules(
                ['table' => ['filter'], 'chain' => ['local']]
            );
            $fmt_data['rules'] = ($response['status'] ?? '') === 'success' ? $response['result'] : [];
            // Prepare presentation-ready table data for the template
            if (is_array($fmt_data)) {
                $fmt_data = FwRulesLocalFormatter::format($fmt_data);
            }
        } elseif (
            $create &&
            ($section === 'fw-rules-mgmt-forward' || $section === 'fw-rules-mgmt-local')
        ) {
            $fwController = new FirewallRequestController($ctx);
            $response = $fwController->getCreateRuleFormData();

            $fmt_data['rule'] = [];
            $fmt_data['addresses'] = [];
            $fmt_data['ports'] = [];
            $fmt_data['ifaces_sets'] = [];

            if (isset($response['status']) && $response['status'] === 'success') {
                $result = $response['result'];
                $fmt_data['addresses'] = $result['addresses'] ?? [];
                $fmt_data['ports'] = $result['ports'] ?? [];
                $fmt_data['ifaces_sets'] = $result['ifaces_sets'] ?? [];
            }
        } elseif (
            $modify &&
            ($section === 'fw-rules-mgmt-forward' || $section === 'fw-rules-mgmt-local')
        ) {
            $rule_id = Filter::getString('id');
            $fwController = new FirewallRequestController($ctx);
            $response = $fwController->getEditRuleFormData($rule_id);

            $fmt_data['rule'] = [];
            $fmt_data['addresses'] = [];
            $fmt_data['ports'] = [];
            $fmt_data['ifaces_sets'] = [];

            if (isset($response['status']) && $response['status'] === 'error') {
                $fmt_data['error'] = $response['response_msg'] ?? 'Unknown error';
            } elseif (isset($response['status']) && $response['status'] === 'success') {
                $result = $response['result'];
                $fmt_data['rule'] = $result['rule'] ?? [];
                $fmt_data['addresses'] = $result['addresses'] ?? [];
                $fmt_data['ports'] = $result['ports'] ?? [];
                $fmt_data['ifaces_sets'] = $result['ifaces_sets'] ?? [];
            }
        } elseif ($section === 'fw-nat') {
            $natController = new NatRequestController($ctx);
            $natResp = $natController->getNatPageData();
            if (($natResp['status'] ?? '') === 'success') {
                $fmt_data['rules']       = $natResp['result']['nftables'];
                $fmt_data['addresses']   = $natResp['result']['addresses'];
                $fmt_data['ports']       = $natResp['result']['ports'];
                $fmt_data['ifaces_sets'] = $natResp['result']['ifaces_sets'];
            } else {
                $fmt_data['rules']       = [];
                $fmt_data['addresses']   = [];
                $fmt_data['ports']       = [];
                $fmt_data['ifaces_sets'] = [];
            }
            $fmt_data = NatFormatter::format($fmt_data);
        } elseif ($section === 'fw-settings') {
            $fwController = new FirewallRequestController($ctx);
            $response = $fwController->getFirewallSettings();
            $settings_ok = ($response['status'] ?? '') === 'success';
            $fmt_data['settings'] = $settings_ok ? ($response['result']['settings'] ?? []) : [];
            // Signal a failed load so the template renders the toggles disabled
            // instead of an optimistic "all enabled" state.
            $fmt_data['settings_error'] = $settings_ok ? false : ($response['response_msg'] ?? true);
        } else {
            $fmt_data['rules'] = [];
        }

        $fmt_data['create'] = $create ? true : false;
        $fmt_data['modify'] = $modify ? true : false;

        // Business logic: resolve set IDs to picker metadata for the rule forms.
        if ($section === 'fw-rules-mgmt-forward' || $section === 'fw-rules-mgmt-local') {
            $fmt_data['rule'] = self::resolveRulePickerMeta(
                $fmt_data['rule'] ?? [],
                $fmt_data['addresses'] ?? [],
                $fmt_data['ports'] ?? [],
                $fmt_data['ifaces_sets'] ?? []
            );
        }

        // Presentation logic: prepare template-ready form data (echo-only templates).
        if ($section === 'fw-rules-mgmt-forward') {
            $fmt_data = FwRulesMgmtForwardFormatter::format($fmt_data);
        } elseif ($section === 'fw-rules-mgmt-local') {
            $fmt_data = FwRulesMgmtLocalFormatter::format($fmt_data);
        }

        $fmt_data['bypass_filter'] = $bypass_filter;
        $fmt_data['section'] = $section;

        $auth = $ctx->get(AuthService::class);
        $fmt_data['can_create'] = RoleHelper::hasCapability(
            $auth->getCapabilities(), 'firewall:write'
        );

        // Presentation logic: prepare template-ready form data (echo-only templates).
        // fw-settings needs can_create for the disabled-attr decision, so it runs
        // here rather than in the section dispatch above.
        if ($section === 'fw-settings') {
            $fmt_data = FwSettingsFormatter::format($fmt_data);
        }

        $page['page'] = $section;
        $page['page_data'] = $fmt_data;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }

    /**
     * Resolve set IDs referenced by a rule into picker metadata (ids, names, hasVal).
     *
     * Business logic for the rule forms: templates consume the precomputed
     * *_meta keys instead of re-resolving IDs themselves. Local rules expose a
     * single "iface" field backed by src_ifaces or dst_ifaces.
     *
     * @param array<string,mixed> $rule
     * @param array<int,array<string,mixed>> $addresses
     * @param array<int,array<string,mixed>> $ports
     * @param array<int,array<string,mixed>> $ifaces_sets
     * @return array<string,mixed>
     */
    private static function resolveRulePickerMeta(
        array $rule,
        array $addresses,
        array $ports,
        array $ifaces_sets
    ): array {
        $pick = static function (array $ids, array $sets): array {
            $names = [];
            foreach ($ids as $id) {
                foreach ($sets as $s) {
                    if (($s['id'] ?? '') === $id) {
                        $names[] = $s['name'] ?? $id;
                        break;
                    }
                }
            }
            return [
                'ids'    => implode(',', $ids),
                'names'  => implode(', ', $names),
                'hasVal' => !empty($ids),
            ];
        };

        // Local rules use a single "iface" field; map it from src_ifaces or dst_ifaces.
        if (isset($rule['src_ifaces'])) {
            $rule['iface'] = $rule['src_ifaces'];
        } elseif (isset($rule['dst_ifaces'])) {
            $rule['iface'] = $rule['dst_ifaces'];
        }
        $ifaceIds = isset($rule['iface'])
            ? (is_array($rule['iface']) ? $rule['iface'] : [$rule['iface']])
            : [];

        $rule['iface_meta']      = $pick($ifaceIds, $ifaces_sets);
        $rule['src_ifaces_meta'] = $pick((array)($rule['src_ifaces'] ?? []), $ifaces_sets);
        $rule['dst_ifaces_meta'] = $pick((array)($rule['dst_ifaces'] ?? []), $ifaces_sets);
        $rule['src_ips_meta']    = $pick((array)($rule['src_ips'] ?? []), $addresses);
        $rule['dst_ips_meta']    = $pick((array)($rule['dst_ips'] ?? []), $addresses);
        $rule['src_ports_meta']  = $pick((array)($rule['src_ports'] ?? []), $ports);
        $rule['dst_ports_meta']  = $pick((array)($rule['dst_ports'] ?? []), $ports);

        return $rule;
    }
}
