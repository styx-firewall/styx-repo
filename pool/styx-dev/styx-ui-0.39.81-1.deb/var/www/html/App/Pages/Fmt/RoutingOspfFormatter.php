<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;
use App\Services\Filter;

class RoutingOspfFormatter
{
    /**
     * @param array<string,mixed> $data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(array $data, array $userCaps = []): array
    {
        $canWrite  = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_save'] = $canWrite;
        $data['can_add'] = $canWrite;

        // OSPFv2 global config
        $ospf = $data['ospf_config'] ?? [];
        $ospf['reference_bandwidth'] = isset($ospf['reference_bandwidth']) ? (int)$ospf['reference_bandwidth'] : 100;
        $ospf['enabled'] = !empty($ospf['enabled']);
        $ospf['log_adjacency_changes'] = !empty($ospf['log_adjacency_changes']);
        $ospf['passive_interface_default'] = !empty($ospf['passive_interface_default']);
        $ospf['router_id_label'] = self::pickerLabel($ospf['router_id_display'] ?? null, 'Select Router ID');
        $ospf['router_id_clear_hidden'] = self::pickerClearHidden($ospf['router_id_display'] ?? null);
        $data['ospf_config'] = $ospf;

        // OSPFv2 areas
        $areas = $data['areas'] ?? [];
        foreach ($areas as &$area) {
            $area['can_delete'] = $canDelete;
            $area['area_id_html'] = self::idSetRefHtml($area['area_id_display'] ?? null, (string)($area['area_id'] ?? ''));
            $area['network_html'] = self::networkHtml($area['network_set_display'] ?? null);
            $area['type_label']   = (string)($area['type'] ?? 'normal');
        }
        unset($area);
        $data['areas'] = $areas;

        // OSPFv2 interface overrides
        $interfaces = $data['interfaces'] ?? [];
        foreach ($interfaces as &$iface) {
            $iface['can_delete'] = $canDelete;
            $iface['cost_display'] = isset($iface['cost']) && $iface['cost'] !== null
                ? (int)$iface['cost']
                : '-';
            $iface['passive_label'] = !empty($iface['passive']) ? 'Yes' : 'No';
            $iface['hello_interval'] = isset($iface['hello_interval']) ? (int)$iface['hello_interval'] : 10;
            $iface['dead_interval'] = isset($iface['dead_interval']) ? (int)$iface['dead_interval'] : 40;
            $iface['priority'] = isset($iface['priority']) ? (int)$iface['priority'] : 1;
            $iface['poll_interval'] = isset($iface['poll_interval']) ? (int)$iface['poll_interval'] : 120;
            $iface['iface_html'] = self::idSetRefHtml($iface['iface_display'] ?? null, (string)($iface['iface'] ?? ''));
        }
        unset($iface);
        $data['interfaces'] = $interfaces;

        // OSPFv3 global config
        $ospf6 = $data['ospf6_config'] ?? [];
        $ospf6['reference_bandwidth'] = isset($ospf6['reference_bandwidth']) ? (int)$ospf6['reference_bandwidth'] : 100;
        $ospf6['enabled'] = !empty($ospf6['enabled']);
        $ospf6['log_adjacency_changes'] = !empty($ospf6['log_adjacency_changes']);
        $ospf6['stub_router_administrative'] = !empty($ospf6['stub_router_administrative']);
        $ospf6['router_id_label'] = self::pickerLabel($ospf6['router_id_display'] ?? null, 'Select Router ID');
        $ospf6['router_id_clear_hidden'] = self::pickerClearHidden($ospf6['router_id_display'] ?? null);
        $data['ospf6_config'] = $ospf6;

        // OSPFv3 areas
        $areas6 = $data['areas6'] ?? [];
        foreach ($areas6 as &$a) {
            $a['can_delete'] = $canDelete;
            $a['area_id_label'] = self::displayFallback($a['area_id_display'] ?? null, 'name', (string)($a['area_id'] ?? ''));
            $a['network_html'] = self::simpleTitleSpan($a['network_set_display'] ?? null, (string)($a['network_set'] ?? ''));
            $a['type_label'] = (string)($a['type'] ?? 'normal');
        }
        unset($a);
        $data['areas6'] = $areas6;

        // OSPFv3 interface overrides
        $ifaces6 = $data['interfaces6'] ?? [];
        foreach ($ifaces6 as &$i) {
            $i['can_delete'] = $canDelete;
            $i['cost_display'] = isset($i['cost']) && $i['cost'] !== null ? (int)$i['cost'] : '-';
            $i['passive_label'] = !empty($i['passive']) ? 'Yes' : 'No';
            $i['hello_interval'] = isset($i['hello_interval']) ? (int)$i['hello_interval'] : 10;
            $i['dead_interval'] = isset($i['dead_interval']) ? (int)$i['dead_interval'] : 40;
            $i['priority'] = isset($i['priority']) ? (int)$i['priority'] : 1;
            $i['iface_label'] = self::firstNonEmpty($i['iface_display'] ?? null, (string)($i['iface'] ?? ''));
            $i['area_label'] = self::displayFallback($i['area_set_display'] ?? null, 'name', (string)($i['area_set'] ?? ''));
        }
        unset($i);
        $data['interfaces6'] = $ifaces6;

        // OSPFv2 neighbors (daemon-provided)
        $neighbors = $data['neighbors'] ?? [];
        foreach ($neighbors as &$n) {
            $n['state_bg_class'] = self::ospfStateBgClass($n['nbrState'] ?? null);
            $n['state_html'] = self::neighborStateHtml($n['state_bg_class'], $n['nbrState'] ?? null);
            $n['detail_json'] = Filter::escHtml((string) json_encode($n));
        }
        unset($n);
        $data['neighbors'] = $neighbors;

        // OSPFv3 neighbors (daemon-provided)
        $neighbors6 = $data['neighbors6'] ?? [];
        foreach ($neighbors6 as &$n) {
            $n['state_bg_class'] = self::ospfStateBgClass($n['state'] ?? null);
            $n['state_html'] = self::neighborStateHtml($n['state_bg_class'], $n['state'] ?? null);
            $n['detail_json'] = Filter::escHtml((string) json_encode($n));
        }
        unset($n);
        $data['neighbors6'] = $neighbors6;

        return $data;
    }

    //
    // Display helpers
    //

    /** @param mixed $d */
    private static function pickerLabel($d, string $placeholder): string
    {
        return !empty($d) && is_array($d) && !empty($d['name'])
            ? (string)$d['name']
            : $placeholder;
    }

    /** @param mixed $d */
    private static function pickerClearHidden($d): string
    {
        return !empty($d) ? '' : ' sets-hidden';
    }

    /**
     * Set-ref span titled by its id, or a plain fallback when absent.
     *
     * @param mixed $d
     */
    private static function idSetRefHtml($d, string $fallback): string
    {
        if (empty($d) || !is_array($d)) {
            return Filter::escHtml($fallback);
        }
        return '<span class="set-ref" title="ID: ' . Filter::escHtml((string)($d['id'] ?? '')) . '">'
            . '<span class="set-name">' . Filter::escHtml((string)($d['name'] ?? '')) . '</span>'
            . (!empty($d['value']) ? '<span class="set-type">' . Filter::escHtml((string)$d['value']) . '</span>' : '')
            . '</span>';
    }

    /** Set-ref span for a network set (family + name), or a dimmed placeholder. @param mixed $d */
    private static function networkHtml($d): string
    {
        if (empty($d) || !is_array($d)) {
            return '<span class="text-dim"> - </span>';
        }
        $title = Filter::escHtml(!empty($d['value']) ? (string)$d['value'] : (string)($d['name'] ?? ''));
        $html = '<span class="set-ref" title="' . $title . '">';
        if (!empty($d['family'])) {
            $html .= '<span class="set-type">' . Filter::escHtml((string)$d['family']) . '</span>';
        }
        $html .= '<span class="set-name">' . Filter::escHtml((string)($d['name'] ?? '')) . '</span></span>';
        return $html;
    }

    /** Plain span with title, used by OSPFv3 area network cells. @param mixed $d */
    private static function simpleTitleSpan($d, string $fallback): string
    {
        if (empty($d) || !is_array($d)) {
            return Filter::escHtml($fallback);
        }
        $title = $d['value'] ?? $d['name'] ?? $fallback;
        $text  = $d['name'] ?? $fallback;
        return '<span title="' . Filter::escHtml((string)$title) . '">' . Filter::escHtml((string)$text) . '</span>';
    }

    /** @param mixed $d */
    private static function displayFallback($d, string $key, string $fallback): string
    {
        return !empty($d) && is_array($d) && isset($d[$key])
            ? (string)$d[$key]
            : $fallback;
    }

    /** @param mixed $d */
    private static function firstNonEmpty($d, string $fallback): string
    {
        if (empty($d)) {
            return Filter::escHtml($fallback);
        }
        if (is_string($d) || is_numeric($d)) {
            return Filter::escHtml((string)$d);
        }
        if (is_array($d) && isset($d['name'])) {
            return Filter::escHtml((string)$d['name']);
        }
        return Filter::escHtml($fallback);
    }

    private static function neighborStateHtml(string $bgClass, ?string $state): string
    {
        return '<span class="std-badge std-badge--' . $bgClass . '">'
            . Filter::escHtml((string)($state ?? '-')) . '</span>';
    }

    /**
     * Background badge variant for an OSPF neighbor state.
     *
     * Display-only classification of the real FRR state value (RFC 2328). The
     * state is the token before "/" (e.g. ``nbrState`` may be ``"Full/-"``).
     * Unknown values map to 'warning' so a state we don't know is never green.
     */
    private static function ospfStateBgClass(?string $state): string
    {
        $s = strtolower((string)($state ?? ''));
        $s = explode('/', $s, 2)[0];
        switch ($s) {
            case 'full':
                return 'enabled';
            case '2-way':
            case 'attempt':
            case 'exstart':
            case 'exchange':
            case 'loading':
                return 'warning';
            case 'down':
            case 'init':
                return 'danger';
            default:
                return 'warning';
        }
    }
}
