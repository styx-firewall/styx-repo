<?php
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Services\AuthService;
use App\Pages\Fmt\SidebarFormatter;

class PageDefaults
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx, string $request_page): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $page['theme'] = $cfg->get('web.theme', 'default');
        $page['lang'] = 'en';
        $page['web_charset'] = $cfg->get('web.charset', 'UTF-8');
        $page['web_name'] = $cfg->get('web.name', 'Styx');
        $page['hostname'] = $cfg->get('hostname', '');
        $page['web_description'] = $cfg->get('web.description', '');
        $page['web_main']['scriptlink'] = [];
        $page['web_main']['scriptlink'][] = ['src' => '/scripts/core/common.js'];
        $page['web_main']['scriptlink'][] = ['src' => '/scripts/core/intl.js'];
        $page['web_main']['scriptlink'][] = ['src' => '/scripts/core/api-client.js'];
        if ($request_page !== 'login' && $request_page !== 'logout') {
            $page['web_main']['scriptlink'][] = ['src' => '/scripts/core/date-utils.js'];
            $page['web_main']['scriptlink'][] = ['src' => '/scripts/core/menu.js'];
            $page['web_main']['scriptlink'][] = ['src' => '/scripts/core/task-panel.js'];
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/core/refresh.js', 'module' => true];
        }

        // Inject user capabilities and role into all templates
        $auth = $ctx->get(AuthService::class);
        $userCaps = $auth->getCapabilities();
        $page['user_capabilities'] = $userCaps;
        $page['user_role'] = $auth->getRole();

        // Pre-compute sidebar section visibility
        $page['sidebar_visible'] = SidebarFormatter::compute(
            $userCaps,
            $cfg->get('features', [])
        );

        $page['web_main']['main_footer'] = $cfg->get('web.copyright') . "<br/>Codename: " . $cfg->get('app.codename', '');

        return $page;
    }
}
