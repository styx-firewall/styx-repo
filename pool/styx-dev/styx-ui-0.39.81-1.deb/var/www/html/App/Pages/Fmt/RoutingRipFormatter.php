<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class RoutingRipFormatter
{
    /** @var array<string,string> Display labels for redistribute protocols. */
    private const PROTO_LABELS = [
        'connected' => 'Connected',
        'static'    => 'Static',
        'bgp'       => 'BGP',
        'ospf'      => 'OSPF',
    ];

    /** @var string[] Redistribute protocols rendered in a fixed order. */
    private const REDISTRIBUTE_PROTOS = ['connected', 'static', 'bgp', 'ospf'];

    /**
     * Normalize RIP page data for template consumption.
     *
     * @param array<string,mixed> $data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(array $data, array $userCaps = []): array
    {
        $ripConfig = $data['rip_config'] ?? [];

        // Global config display flags
        $ripConfig['enabled_checked']   = !empty($ripConfig['enabled']) ? 'checked' : '';
        $version = isset($ripConfig['version']) ? (int)$ripConfig['version'] : 2;
        $ripConfig['version_selected_2'] = $version === 2 ? 'selected' : '';
        $ripConfig['version_selected_1'] = $version === 1 ? 'selected' : '';

        // BFD default profile select: mark the matching profile as selected.
        $defaultBfd = $ripConfig['bfd_default_profile'] ?? '';
        $bfdProfiles = $data['bfd_profiles'] ?? [];
        foreach ($bfdProfiles as &$bfp) {
            $bfp['selected'] = ($bfp['id'] ?? '') === $defaultBfd ? 'selected' : '';
        }
        unset($bfp);
        $data['bfd_profiles'] = $bfdProfiles;

        // Passive interfaces: normalize mixed array/scalar entries and flag
        // membership in the passive list.
        $passiveIds = $ripConfig['passive_interfaces'] ?? [];
        $ripIfaces = $data['rip_ifaces'] ?? [];
        $normIfaces = [];
        foreach ($ripIfaces as $iface) {
            $id = is_array($iface) ? (string)($iface['id'] ?? '') : (string)$iface;
            $name = is_array($iface) ? (string)($iface['interface'] ?? $id) : $id;
            $normIfaces[] = [
                'id'       => $id,
                'name'     => $name,
                'selected' => in_array($id, $passiveIds) ? 'selected' : '',
            ];
        }
        $data['rip_ifaces'] = $normIfaces;

        // Redistribute rows: merge per-protocol state with the route-map options.
        $ripRedist = $ripConfig['redistribute'] ?? [];
        $routeMaps = $data['route_maps'] ?? [];
        $redistRows = [];
        foreach (self::REDISTRIBUTE_PROTOS as $proto) {
            $existing = null;
            foreach ($ripRedist as $r) {
                if (($r['protocol'] ?? '') === $proto) {
                    $existing = $r;
                    break;
                }
            }
            $rmOptions = [];
            foreach ($routeMaps as $rm) {
                $rmOptions[] = [
                    'id'       => $rm['id'] ?? '',
                    'name'     => $rm['name'] ?? '',
                    'selected' => ($existing && ($existing['route_map'] ?? null) === ($rm['id'] ?? null)) ? 'selected' : '',
                ];
            }
            $redistRows[] = [
                'proto'      => $proto,
                'label'      => self::PROTO_LABELS[$proto],
                'checked'    => $existing ? 'checked' : '',
                'metric'     => $existing['metric'] ?? '',
                'route_maps' => $rmOptions,
            ];
        }
        $data['rip_redistribute'] = $redistRows;

        // Networks: pre-build display cells.
        $networks = $data['networks'] ?? [];
        foreach ($networks as &$net) {
            $net['network_html']         = self::setRefHtml($net['network_set_display'] ?? null);
            $net['bfd_label']            = !empty($net['bfd']) ? 'Yes' : 'No';
            $net['bfd_profile_label']    = (string)($net['bfd_profile_display']['name'] ?? '-');
            $net['prefix_list_in_label'] = (string)($net['prefix_list_in_display']['name'] ?? '-');
            $net['prefix_list_out_label'] = (string)($net['prefix_list_out_display']['name'] ?? '-');
        }
        unset($net);
        $data['networks'] = $networks;

        $data['rip_config'] = $ripConfig;

        return $data;
    }

    /**
     * Build the set-ref span for a *_set_display array, or a dimmed '-' when absent.
     *
     * @param mixed $d
     */
    private static function setRefHtml($d): string
    {
        if (empty($d) || !is_array($d)) {
            return '<span class="text-dim">-</span>';
        }
        $title = Filter::escHtml(!empty($d['value']) ? (string)$d['value'] : (string)($d['name'] ?? ''));
        $html = '<span class="set-ref" title="' . $title . '">';
        if (!empty($d['family'])) {
            $html .= '<span class="set-type">' . Filter::escHtml((string)$d['family']) . '</span>';
        }
        $html .= '<span class="set-name">' . Filter::escHtml((string)($d['name'] ?? '')) . '</span></span>';
        return $html;
    }
}
