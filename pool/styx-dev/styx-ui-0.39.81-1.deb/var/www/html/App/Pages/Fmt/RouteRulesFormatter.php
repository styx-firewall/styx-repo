<?php
/**
 * Formatter for net-routes-rules page data.
 * Normalizes gateway response into presentation-ready arrays
 * consumed by the net-routes-rules template.
 *
 * The gateway now returns rules with _display fields already resolved.
 * This formatter passes them through and normalizes minor differences
 * (e.g. family -> category mapping for src/dst).
 *
 * dp: 20260415
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class RouteRulesFormatter
{
    /**
     * Format route-rules page data for templates.
     *
     * Expected input $response keys:
     *   - rules => array of route rule objects with _display fields
     *
     * @param array $fmt_data  Current page data (may be empty)
     * @param array $response   Gateway response result from RouteRulesRequestController
     * @return array            Enriched page_data for template
     */
    public static function format(array $fmt_data, array $response): array
    {
        $rules = $response['rules'] ?? [];

        // Protocols (static lookup for the form)
        $fmt_data['protocols'] = [
            ''       => '- any -',
            'tcp'    => 'TCP',
            'udp'    => 'UDP',
            'icmp'   => 'ICMP',
            'icmpv6' => 'ICMPv6',
        ];

        // Normalize rules
        $normalized = [];
        foreach ($rules as $rule) {
            if (!is_array($rule)) {
                continue;
            }

            $md  = self::normalizeDisplayObj($rule['mark_display'] ?? null);
            $sd  = self::normalizeDisplayAddr($rule['src_display'] ?? null);
            $dd  = self::normalizeDisplayAddr($rule['dst_display'] ?? null);
            $iif = self::normalizeDisplayObj($rule['iif_display'] ?? null);
            $sp  = self::normalizeDisplayObj($rule['sport_display'] ?? null);
            $dp  = self::normalizeDisplayObj($rule['dport_display'] ?? null);
            $td  = self::normalizeDisplayObj($rule['table_display'] ?? null);

            $normalized[] = [
                'uuid'       => $rule['uuid'] ?? $rule['id'] ?? '',
                'name'       => $rule['name'] ?? '',
                'priority'   => $rule['priority'] ?? null,
                'invert'     => !empty($rule['invert']),
                'expression' => $rule['expression'] ?? '',
                'active'     => !empty($rule['active']),

                // Original UUIDs (for operations)
                'mark'       => $rule['mark'] ?? null,
                'src'        => $rule['src'] ?? null,
                'dst'        => $rule['dst'] ?? null,
                'iif'        => $rule['iif'] ?? null,
                'proto'      => $rule['proto'] ?? '',
                'sport'      => $rule['sport'] ?? null,
                'dport'      => $rule['dport'] ?? null,
                'action'     => $rule['action'] ?? 'lookup',
                'table'      => $rule['table'] ?? null,

                // Resolved display fields (normalized)
                'mark_display'  => $md,
                'src_display'   => $sd,
                'dst_display'   => $dd,
                'iif_display'   => $iif,
                'sport_display' => $sp,
                'dport_display' => $dp,
                'table_display' => $td,

                // Pre-built display HTML so the template only echoes.
                'uuid_short'   => substr($rule['uuid'] ?? $rule['id'] ?? '', 0, 8),
                'invert_html'  => self::invertHtml(!empty($rule['invert'])),
                'mark_html'    => self::markHtml($md),
                'src_html'     => self::addrHtml($sd),
                'dst_html'     => self::addrHtml($dd),
                'iif_html'     => self::iifHtml($iif),
                'proto_html'   => self::protoHtml($rule['proto'] ?? ''),
                'sport_html'   => self::portHtml($sp),
                'dport_html'   => self::portHtml($dp),
                'action_html'  => self::actionHtml($rule['action'] ?? 'lookup', $td, $rule['table'] ?? null),
                'status_html'  => self::statusHtml(!empty($rule['active'])),
                'active_flag'  => !empty($rule['active']) ? '1' : '0',
                'toggle_class' => !empty($rule['active']) ? 'rr-btn-toggle-on' : 'rr-btn-toggle-off',
                'toggle_label' => !empty($rule['active']) ? 'Deactivate' : 'Activate',
            ];
        }

        $fmt_data['rules']       = $normalized;
        $fmt_data['rules_count'] = count($normalized);

        return $fmt_data;
    }

    /**
     * Normalize a generic display object (mark, iif, sport, dport, table).
     * Ensures name and value are always present; returns null if input is null.
     */
    private static function normalizeDisplayObj(?array $obj): ?array
    {
        if ($obj === null) {
            return null;
        }
        return [
            'id'    => $obj['id'] ?? '',
            'name'  => $obj['name'] ?? '',
            'value' => $obj['value'] ?? '',
        ];
    }

    /**
     * Normalize an address display object (src, dst).
     * Maps gateway's 'family' field ("ip"|"ip6") to template's 'category' ("ipv4"|"ipv6").
     */
    private static function normalizeDisplayAddr(?array $obj): ?array
    {
        if ($obj === null) {
            return null;
        }
        $family = $obj['family'] ?? '';
        $category = ($family === 'ip6') ? 'ipv6' : 'ipv4';

        return [
            'id'       => $obj['id'] ?? '',
            'name'     => $obj['name'] ?? '',
            'value'    => $obj['value'] ?? '',
            'family'   => $family,
            'category' => $category,
        ];
    }

    //
    // Display HTML builders
    //

    private static function invertHtml(bool $invert): string
    {
        return $invert
            ? '<span class="std-badge std-badge--invert">NOT</span>'
            : '<span class="rr-dim">-</span>';
    }

    /** @param array<string,mixed>|null $md */
    private static function markHtml($md): string
    {
        if ($md === null) {
            return '<span class="rr-dim">any</span>';
        }
        return '<span class="std-badge std-badge--mark" title="value: '
            . Filter::escHtml((string)($md['value'] ?? '')) . '">'
            . Filter::escHtml((string)($md['name'] ?? '')) . '</span>';
    }

    /** @param array<string,mixed>|null $d */
    private static function addrHtml($d): string
    {
        if ($d === null) {
            return '<span class="rr-dim">any</span>';
        }
        return '<span class="rr-set-ref" title="' . Filter::escHtml((string)($d['id'] ?? '')) . '">'
            . '<span class="rr-set-type">' . Filter::escHtml((string)($d['category'] ?? '')) . '</span>'
            . '<span>' . Filter::escHtml((string)($d['name'] ?? '')) . ' ('
            . Filter::escHtml((string)($d['value'] ?? '')) . ')</span></span>';
    }

    /** @param array<string,mixed>|null $d */
    private static function iifHtml($d): string
    {
        if ($d === null) {
            return '<span class="rr-dim">any</span>';
        }
        return '<span class="rr-set-ref" title="' . Filter::escHtml((string)($d['id'] ?? '')) . '">'
            . '<span class="rr-set-type">iface</span>'
            . '<span>' . Filter::escHtml((string)($d['value'] ?? '')) . '</span></span>';
    }

    private static function protoHtml(string $proto): string
    {
        if ($proto === '') {
            return '<span class="rr-dim">any</span>';
        }
        return '<span class="std-badge std-badge--proto">'
            . Filter::escHtml(strtoupper($proto)) . '</span>';
    }

    /** @param array<string,mixed>|null $d */
    private static function portHtml($d): string
    {
        if ($d === null) {
            return '<span class="rr-dim">any</span>';
        }
        return '<span class="rr-set-ref">'
            . '<span class="rr-set-type">port</span>'
            . '<span>' . Filter::escHtml((string)($d['name'] ?? '')) . ' ('
            . Filter::escHtml((string)($d['value'] ?? '')) . ')</span></span>';
    }

    /** @param array<string,mixed>|null $td @param mixed $table */
    private static function actionHtml(string $action, $td, $table): string
    {
        if ($action === 'lookup' && $td !== null) {
            return '<span class="std-badge std-badge--action-lookup">lookup '
                . Filter::escHtml((string)($td['name'] ?? '')) . '</span>';
        }
        if ($action === 'lookup') {
            return '<span class="std-badge std-badge--action-lookup">lookup '
                . Filter::escHtml((string)($table ?? '?')) . '</span>';
        }
        if ($action === 'unreachable') {
            return '<span class="std-badge std-badge--action-block">unreachable</span>';
        }
        return '<span class="std-badge std-badge--chain">' . Filter::escHtml($action) . '</span>';
    }

    private static function statusHtml(bool $active): string
    {
        return $active
            ? '<span class="std-badge std-badge--active"><span class="rr-dot on"></span>Active</span>'
            : '<span class="std-badge std-badge--inactive"><span class="rr-dot off"></span>Inactive</span>';
    }
}

