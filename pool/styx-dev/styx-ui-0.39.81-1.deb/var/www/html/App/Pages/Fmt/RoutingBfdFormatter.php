<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

class RoutingBfdFormatter
{
    /**
     * Normalize BFD session fields for templates.
     *
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    public static function format(array $data): array
    {
        $canWrite  = true; // BFD profiles inherit routing:write via page guard
        $canDelete = true;
        $data['can_add']  = $canWrite;
        $data['can_save'] = $canWrite;

        $sessions = $data['sessions'] ?? [];

        foreach ($sessions as &$s) {
            $s['tx_interval'] = isset($s['tx_interval']) ? (int)$s['tx_interval'] : 0;
            $s['rx_interval'] = isset($s['rx_interval']) ? (int)$s['rx_interval'] : 0;
            $s['multiplier']   = isset($s['multiplier']) ? (int)$s['multiplier'] : 0;
            $s['status']       = $s['status'] ?? 'down';
            $s['state_class']  = $s['status'] === 'up' ? 'enabled' : 'disabled';
            $s['uptime']       = $s['uptime'] ?? '-';
            $s['status_badge_html'] = $s['status'] === 'up'
                ? '<span class="std-badge std-badge--active"><span class="std-status-dot on"></span>' . $s['status'] . '</span>'
                : '<span class="std-badge std-badge--inactive"><span class="std-status-dot off"></span>' . $s['status'] . '</span>';
        }
        unset($s);

        $data['sessions'] = $sessions;

        $profiles = $data['bfd_profiles'] ?? [];
        foreach ($profiles as &$p) {
            $p['can_delete'] = $canDelete;
            $p['detect_multiplier'] = isset($p['detect_multiplier']) ? (int)$p['detect_multiplier'] : 3;
            $p['receive_interval']  = isset($p['receive_interval']) ? (int)$p['receive_interval'] : 300;
            $p['transmit_interval'] = isset($p['transmit_interval']) ? (int)$p['transmit_interval'] : 300;
            $p['echo_mode_label']   = !empty($p['echo_mode']) ? 'Yes' : 'No';
            $p['passive_label']     = !empty($p['passive_mode']) ? 'Yes' : 'No';
            $p['echo_flag']         = !empty($p['echo_mode']) ? '1' : '0';
            $p['passive_flag']      = !empty($p['passive_mode']) ? '1' : '0';
        }
        unset($p);
        $data['bfd_profiles'] = $profiles;

        return $data;
    }
}
