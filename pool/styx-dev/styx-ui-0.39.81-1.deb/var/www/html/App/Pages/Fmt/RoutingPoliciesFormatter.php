<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class RoutingPoliciesFormatter
{
    /**
     * Normalize FRR policy objects for template consumption.
     *
     * @param array<string,mixed> $data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(array $data, array $userCaps = []): array
    {
        $canWrite  = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_add']    = $canWrite;
        $data['can_delete'] = $canDelete;

        $data['prefix_lists']    = self::annotateList($data['prefix_lists'] ?? [], $canDelete);
        $data['route_maps']      = self::annotateList($data['route_maps'] ?? [], $canDelete);
        $data['as_path_lists']   = self::annotateList($data['as_path_lists'] ?? [], $canDelete);
        $data['community_lists'] = self::annotateList($data['community_lists'] ?? [], $canDelete);

        // Single JSON payload for the JS __policiesData blob.
        $data['policies_json'] = json_encode([
            'prefix_list'    => $data['prefix_lists'],
            'route_map'      => $data['route_maps'],
            'as_path_list'   => $data['as_path_lists'],
            'community_list' => $data['community_lists'],
        ]);

        return $data;
    }

    /**
     * Normalize a policy list and annotate each entry with can_delete + entries_count.
     *
     * @param mixed $list
     * @param bool $canDelete
     * @return array<int, array<string, mixed>>
     */
    private static function annotateList($list, bool $canDelete): array
    {
        $out = [];
        foreach (self::normalizePolicyList($list, $canDelete) as $item) {
            $item['entries_count'] = count($item['entries'] ?? []);
            $out[] = $item;
        }
        return $out;
    }

    /**
     * Guard: ensure the value is an array of arrays before annotating with can_delete.
     *
     * @param mixed $list
     * @param bool $canDelete
     * @return array<int, array<string, mixed>>
     */
    private static function normalizePolicyList($list, bool $canDelete): array
    {
        if (!is_array($list)) {
            return [];
        }

        $out = [];
        foreach ($list as $item) {
            if (!is_array($item)) {
                continue;
            }
            $item['can_delete'] = $canDelete;
            $out[] = $item;
        }

        return $out;
    }
}
