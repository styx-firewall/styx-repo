<?php
/**
 * Formatter for the local firewall rule management form.
 *
 * Presentation logic only: builds the presentation-ready values/options the
 * template echoes. Business logic (resolving set IDs, etc.) stays in
 * PageFirewall.
 */
namespace App\Pages\Fmt;

class FwRulesMgmtLocalFormatter
{
    /**
     * Prepare presentation-ready form data under $fmt_data['rule_ui'].
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $rule = $fmt_data['rule'] ?? [];
        $create = !empty($fmt_data['create']);
        $modify = !empty($fmt_data['modify']);

        $chain = $rule['chain'] ?? null;
        $family = $rule['family'] ?? 'ip';
        $protocol = $rule['protocol'] ?? '';
        $action = $rule['action'] ?? '';

        $icmpStored = isset($rule['icmp_type'])
            ? array_map('strval', (array)$rule['icmp_type'])
            : [];
        $tcpFlags = (array)($rule['tcp_flags'] ?? []);
        $days = (array)($rule['time']['days'] ?? []);

        $fmt_data['rule_ui'] = [
            'error'          => $fmt_data['error'] ?? '',
            'create'         => $create,
            'modify'         => $modify,
            'title'          => $create ? 'Create local rule' : 'Edit local rule',
            'submit_label'   => $create ? 'Create rule' : 'Save changes',
            'command'        => $modify ? 'update_firewall_rule' : 'set_firewall_rule',
            'show_delete'    => $modify && !empty($rule['id']),
            'rule_id'        => $rule['id'] ?? '',
            'is_system_rule' => !empty($rule['system_rule']),
            'end_of_chain'   => !empty($rule['end_of_chain']),

            'name'       => $rule['name'] ?? '',
            'comment'    => $rule['comment'] ?? '',
            'log_limit'  => $rule['log_limit'] ?? '',
            'fwmark_id'  => is_array($rule['fwmark'] ?? null)
                ? ($rule['fwmark']['id'] ?? '')
                : ($rule['fwmark'] ?? ''),
            'time_start' => $rule['time']['start'] ?? '',
            'time_stop'  => $rule['time']['stop'] ?? '',
            'icmp_csv'   => implode(',', $icmpStored),

            'enabled_checked' => !isset($rule['enabled']) || $rule['enabled'],
            'log_checked'     => !empty($rule['log']),

            'chain_options' => self::optionList(
                ['input' => 'Input', 'output' => 'Output'],
                $chain === null ? '' : $chain
            ),
            'family_options'   => self::optionList(
                ['ip' => 'IPv4', 'ip6' => 'IPv6'],
                $family
            ),
            'protocol_options' => self::optionList(
                [
                    '' => 'Any',
                    'tcp' => 'TCP',
                    'udp' => 'UDP',
                    'icmp' => 'ICMP',
                    'icmpv6' => 'ICMPv6',
                    'esp' => 'ESP',
                    'ah' => 'AH',
                ],
                $protocol
            ),
            'action_options' => self::optionList(
                ['accept' => 'Accept', 'drop' => 'Drop', 'reject' => 'Reject'],
                $action
            ),
            'days_options' => self::optionList(
                [
                    'mon' => 'Monday',
                    'tue' => 'Tuesday',
                    'wed' => 'Wednesday',
                    'thu' => 'Thursday',
                    'fri' => 'Friday',
                    'sat' => 'Saturday',
                    'sun' => 'Sunday',
                ],
                $days,
                true
            ),
            'icmp_common' => self::checkboxList(
                [
                    '8' => 'Echo Request',
                    '0' => 'Echo Reply',
                    '3' => 'Destination Unreachable',
                    '11' => 'Time Exceeded',
                    '5' => 'Redirect',
                    '17' => 'Address Mask Request',
                ],
                $icmpStored
            ),
            'tcp_flags' => self::checkboxList(
                [
                    'syn' => 'SYN',
                    'ack' => 'ACK',
                    'fin' => 'FIN',
                    'rst' => 'RST',
                    'psh' => 'PSH',
                    'urg' => 'URG',
                ],
                $tcpFlags
            ),

            'iface'    => $rule['iface_meta'] ?? self::emptyPicker(),
            'src_ips'  => $rule['src_ips_meta'] ?? self::emptyPicker(),
            'dst_ips'  => $rule['dst_ips_meta'] ?? self::emptyPicker(),
            'src_ports' => $rule['src_ports_meta'] ?? self::emptyPicker(),
            'dst_ports' => $rule['dst_ports_meta'] ?? self::emptyPicker(),
        ];

        return $fmt_data;
    }

    /**
     * Build <select> options with a selected flag.
     *
     * @param array<string,string> $options value => label
     * @param string|string[] $current
     * @param bool $multi treat $current as a list of values
     * @return array<int,array<string,mixed>>
     */
    private static function optionList(array $options, $current, bool $multi = false): array
    {
        $currentArr = is_array($current) ? $current : [$current];
        $list = [];
        foreach ($options as $value => $label) {
            $list[] = [
                'value'    => $value,
                'label'    => $label,
                'selected' => in_array($value, $currentArr),
            ];
        }
        return $list;
    }

    /**
     * Build checkbox list with a checked flag.
     *
     * @param array<string,string> $options value => label
     * @param array<int,string> $current
     * @return array<int,array<string,mixed>>
     */
    private static function checkboxList(array $options, array $current): array
    {
        $list = [];
        foreach ($options as $value => $label) {
            // PHP casts numeric-looking keys to int; normalize to string for output
            // and for strict comparison against the (string) current values.
            $value = (string)$value;
            $list[] = [
                'value'   => $value,
                'label'   => $label,
                'checked' => in_array($value, $current, true),
            ];
        }
        return $list;
    }

    private static function emptyPicker(): array
    {
        return ['ids' => '', 'names' => '', 'hasVal' => false];
    }
}
