<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

class RoutingOverviewFormatter
{
    /**
     * Normalize daemon display names for the overview page.
     *
     * Adds `display_daemon_name` to each daemon entry.
     *
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    public static function format(array $data): array
    {
        // Normalize frr sub-object
        $data['frr'] = $data['frr'] ?? ['enabled' => false, 'daemons' => []];
        $data['frr']['enabled'] = !empty($data['frr']['enabled']);

        // Normalize igmp_proxy sub-object
        $data['igmp_proxy'] = $data['igmp_proxy'] ?? ['enabled' => false, 'daemon' => null];
        $data['igmp_proxy']['enabled'] = !empty($data['igmp_proxy']['enabled']);

        // Cast top-level counters
        $data['num_tables']       = isset($data['num_tables']) ? (int)$data['num_tables'] : 0;
        $data['num_policy_rules'] = isset($data['num_policy_rules']) ? (int)$data['num_policy_rules'] : 0;

        // Normalize route_summary.ipv4 / ipv6
        $data['route_summary'] = $data['route_summary'] ?? [];
        foreach (['ipv4', 'ipv6'] as $family) {
            $fam = $data['route_summary'][$family] ?? [];
            $fam['total']       = isset($fam['total']) ? (int)$fam['total'] : 0;
            $fam['by_protocol'] = self::intMap($fam['by_protocol'] ?? []);
            $fam['by_scope']    = self::intMap($fam['by_scope'] ?? []);
            $fam['by_table']    = self::intMap($fam['by_table'] ?? []);
            // Pre-built protocol rows with display labels.
            $protoRows = [];
            foreach ($fam['by_protocol'] as $proto => $count) {
                $protoRows[] = ['label' => ucfirst($proto), 'count' => $count];
            }
            $fam['by_protocol_rows'] = $protoRows;
            $data['route_summary'][$family] = $fam;
        }

        // Normalize frr_routes (from backend fr_routes)
        $data['frr_routes'] = $data['frr_routes'] ?? [];
        foreach (['ipv4', 'ipv6'] as $family) {
            $fr = $data['frr_routes'][$family] ?? [];
            $data['frr_routes'][$family] = self::intMap($fr, ['bgp','ospf','rip']);
        }

        // Default gateways
        $data['default_gateway_v4'] = $data['default_gateway_v4'] ?? null;
        $data['default_gateway_v6'] = $data['default_gateway_v6'] ?? null;

        // FRR daemon display names
        $labels = [
            'bgpd'      => 'BGP daemon',
            'ospfd'     => 'OSPF daemon',
            'ripd'      => 'RIP daemon',
            'bfdd'      => 'BFD daemon',
        ];
        $daemons = $data['frr']['daemons'] ?? [];
        foreach ($daemons as &$d) {
            $name = $d['name'] ?? '';
            if (isset($d['display'])) {
                $d['display_daemon_name'] = $d['display'];
            } elseif (isset($labels[$name])) {
                $d['display_daemon_name'] = $labels[$name];
            } else {
                $d['display_daemon_name'] = $name !== '' ? ucfirst($name) : '';
            }
            $d['status_badge_class'] = ($d['status'] ?? '') === 'running' ? 'success' : 'danger';
        }
        unset($d);
        $data['frr']['daemons'] = $daemons;

        // IGMP daemon display name + status class
        $igmpDaemon = $data['igmp_proxy']['daemon'] ?? null;
        if (is_array($igmpDaemon)) {
            $igmpDaemon['display_daemon_name'] = $igmpDaemon['display'] ?? 'IGMP Proxy';
            $igmpDaemon['status_badge_class'] = ($igmpDaemon['status'] ?? '') === 'running' ? 'success' : 'danger';
            $data['igmp_proxy']['daemon'] = $igmpDaemon;
        }

        return $data;
    }

    /**
     * Cast keys of an associative array to int, optionally ensuring a fixed set of keys exist.
     *
     * @param array<string,mixed> $map
     * @param string[] $defaultKeys
     * @return array<string,int>
     */
    private static function intMap(array $map, array $defaultKeys = []): array
    {
        foreach ($defaultKeys as $k) {
            if (!array_key_exists($k, $map)) {
                $map[$k] = 0;
            }
        }
        $out = [];
        foreach ($map as $k => $v) {
            $out[$k] = (int)$v;
        }
        return $out;
    }
}
