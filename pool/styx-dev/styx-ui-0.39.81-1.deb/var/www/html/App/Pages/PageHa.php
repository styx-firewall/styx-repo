<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Controllers\Request\HaRequestController;
use App\Pages\Fmt\HAFormatter;

class PageHa
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
        $page['web_main']['footer_script'][] = ['src' => '/scripts/ha/ha.js'];
        $page['web_main']['cssfile'][] = 'default-ha';
        $reqController = new HaRequestController($ctx);
        $response = $reqController->getHaData();
        $fmt_data = [];
        if (isset($response['status']) && $response['status'] === 'success') {
            $fmt_data = $response['result'] ?? [];
        }
        $fmt = HAFormatter::format($fmt_data);

        $page['page'] = 'ha';
        $page['page_data'] = $fmt ?? [];
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];
        // Self-contained sections, each rendered from the full formatted data.
        $page['load_tpl'][] = ['file' => 'ha-status',  'place' => 'ha_status',  'tpl_data' => $fmt];
        $page['load_tpl'][] = ['file' => 'ha-sync',    'place' => 'ha_sync',    'tpl_data' => $fmt];
        $page['load_tpl'][] = ['file' => 'ha-filter',  'place' => 'ha_filter',  'tpl_data' => $fmt];
        $page['load_tpl'][] = ['file' => 'ha-actions', 'place' => 'ha_actions', 'tpl_data' => $fmt];

        return $page;
    }
}
