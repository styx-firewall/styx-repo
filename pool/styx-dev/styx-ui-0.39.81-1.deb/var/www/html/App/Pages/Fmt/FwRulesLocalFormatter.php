<?php
namespace App\Pages\Fmt;

use App\Helpers\FormatHelper;

class FwRulesLocalFormatter
{
    /**
     * Format rules for fw-rules-local template.
     * Converts arrays to HTML multiline, prepares icons and table-ready rows.
     * @param array $fmt_data
     * @return array
     */
    public static function format(array $fmt_data): array
    {
        $rules = $fmt_data['rules'] ?? [];
        $input = [];
        $output = [];

        foreach ($rules as $r) {
            // Prepare small HTML snippets on separate lines to respect 120 char limit
            $logHtml = '<span class="fw-muted">-</span>';
            if (isset($r['log'])) {
                $logHtml = $r['log'] ? '<span class="fw-log-icon">📝</span>' : '<span class="fw-muted"> - </span>';
            }

            $enabledHtml = '<span class="fw-enabled-off">🔴</span>';
            if (isset($r['enabled'])) {
                $enabledHtml = $r['enabled'] ? '<span class="fw-enabled-on">🟢</span>' : '<span class="fw-enabled-off">🔴</span>';
            }
            // Append warning icon if discrepancies exist
            if (!empty($r['warnings']) && is_array($r['warnings'])) {
                $msgs = array_column($r['warnings'], 'msg');
                $title = implode("\n", $msgs);
                $enabledHtml .= ' <span class="fw-warning-icon" title="' . $title . '">⚠️</span>';
            }

            $srcIfaces = isset($r['src_ifaces']) && is_array($r['src_ifaces'])
                ? implode('<br>', array_column($r['src_ifaces'], 'name'))
                : '';
            $dstIfaces = isset($r['dst_ifaces']) && is_array($r['dst_ifaces'])
                ? implode('<br>', array_column($r['dst_ifaces'], 'name'))
                : '';
            $srcIps = isset($r['src_ips']) && is_array($r['src_ips'])
                ? implode('<br>', array_column($r['src_ips'], 'name'))
                : '';
            $dstIps = isset($r['dst_ips']) && is_array($r['dst_ips'])
                ? implode('<br>', array_column($r['dst_ips'], 'name'))
                : '';
            $srcPorts = isset($r['src_ports']) && is_array($r['src_ports'])
                ? implode('<br>', array_column($r['src_ports'], 'name'))
                : '';
            $dstPorts = isset($r['dst_ports']) && is_array($r['dst_ports'])
                ? implode('<br>', array_column($r['dst_ports'], 'name'))
                : '';

            $bytesFormatted = isset($r['bytes']) ? FormatHelper::formatBytes((int)$r['bytes']) : '';

            $row = [
                'chain'      => $r['chain'] ?? '',
                'name'       => $r['name'] ?? '',
                'family'     => $r['family'] ?? '',
                'src_ifaces' => $srcIfaces,
                'dst_ifaces' => $dstIfaces,
                'src_ips'    => $srcIps,
                'src_ports'  => $srcPorts,
                'dst_ips'    => $dstIps,
                'dst_ports'  => $dstPorts,
                'action'     => $r['action'] ?? '',
                'log'        => $logHtml,
                'enabled'    => $enabledHtml,
                'comment'    => $r['comment'] ?? '',
                'packets'    => $r['packets'] ?? '',
                'bytes'      => $bytesFormatted,
                'id'          => $r['id'] ?? '',
                'handle'      => $r['handle'] ?? '',
                // Flags consumed by the frontend to block moves relative to
                // system rules (move_firewall_rule rejects crossing them).
                'system_rule'  => $r['system_rule'] ?? 0,
                'end_of_chain' => $r['end_of_chain'] ?? 0,
            ];

            $chain = strtolower($r['chain'] ?? '');
            if ($chain === 'input') {
                $input[] = $row;
            } elseif ($chain === 'output') {
                $output[] = $row;
            }
        }

        $fmt_data['input_table_data'] = $input;
        $fmt_data['output_table_data'] = $output;

        // Prepare JSON payloads for template
        $thead = [
            'enabled'    => 'Enabled',
            'chain'      => 'Chain',
            'name'       => 'Name',
            'family'     => 'Family',
            'src_ifaces' => 'In Interface',
            'dst_ifaces' => 'Out Interface',
            'src_ips'    => 'Source IPs',
            'src_ports'  => 'Source Ports',
            'dst_ips'    => 'Destination IPs',
            'dst_ports'  => 'Destination Ports',
            'action'     => 'Action',
            'log'        => 'Log',
            'packets'    => 'Packets',
            'bytes'      => 'Bytes',
            'handle'     => 'Handle',
            'id'         => 'ID',
            'comment'    => 'Comment',
        ];

        $columnsConfig = [
            'handle' => false,
            'id' => false,
        ];

        $fmt_data['fw_local_thead_json'] = json_encode($thead, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
        $fmt_data['fw_local_input_rows_json'] = json_encode($input, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
        $fmt_data['fw_local_output_rows_json'] = json_encode($output, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
        $fmt_data['fw_local_columns_config_json'] = json_encode($columnsConfig);

        return $fmt_data;
    }
}
