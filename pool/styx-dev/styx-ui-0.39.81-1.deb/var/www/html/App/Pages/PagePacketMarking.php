<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Controllers\Request\PacketMarkingRequestController;
use App\Pages\Fmt\PacketMarkingFormatter;

class PagePacketMarking
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $section = 'packet-marking';

        $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
        $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
        $page['web_main']['footer_script'][] = ['src' => '/scripts/core/packet-marking.js'];
        $pmController = new PacketMarkingRequestController($ctx);
        $pmResponse = $pmController->getPageData();

        if (($pmResponse['status'] ?? '') === 'error') {
            $fmt = [
                'error' => $pmResponse['response_msg'] ?? 'Unknown error',
                'chains' => [],
                'protocols' => [],
                'rules' => [],
            ];
        } else {
            $fmt_data = [
                'rules' => $pmResponse['result']['rules'] ?? [],
            ];
            $fmt = PacketMarkingFormatter::format($ctx, $fmt_data);
        }

        $page['page'] = $section;
        $page['page_data'] = $fmt;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];
        return $page;
    }
}
