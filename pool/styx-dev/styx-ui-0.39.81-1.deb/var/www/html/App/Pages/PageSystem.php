<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Controllers\Request\SystemRequestController;
use App\Pages\Fmt\SysSettingsFormatter;
use App\Pages\Fmt\SysAppsFormatter;
use App\Pages\Fmt\SysServicesFormatter;
use App\Pages\Fmt\SysCertsFormatter;
use App\Pages\Fmt\SysLogsFormatter;
use App\Services\Filter;
use App\Services\AuthService;
use App\Helpers\RoleHelper;
use App\Constants\LogLevel;

class PageSystem
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'sys-settings',
            'sys-snmp',
            'sys-apps',
            'sys-services',
            'sys-certs',
            'sys-logs',
            'sys-reboot',

        ];

        // Define log levels using LogLevel
        $logLevels = [
            'DEBUG' => LogLevel::DEBUG,
            'INFO' => LogLevel::INFO,
            'NOTICE' => LogLevel::NOTICE,
            'WARNING' => LogLevel::WARNING,
            'ERROR' => LogLevel::ERROR,
            'CRITICAL' => LogLevel::CRITICAL,
            'ALERT' => LogLevel::ALERT,
            'EMERGENCY' => LogLevel::EMERGENCY,
        ];

        $section = Filter::getString('section');

        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'sys-settings';
        }

        $reqController = new SystemRequestController($ctx);

        if ($section === 'sys-settings') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/sys/sys-settings.js'];
            $response = $reqController->getSysSettings();
            $auth = $ctx->get(AuthService::class);
            $isAdmin = RoleHelper::hasCapability($auth->getCapabilities(), 'system:admin');
            if (
                isset($response['status']) &&
                ($response['status'] === 'success' ||
                $response['status'] === 'partial'))
            {
                $fmt_data = $response['result'] ?? [];
                if (!empty($response['warnings'])) {
                    $fmt_data['warnings'] = $response['warnings'];
                }
                if (!empty($response['response_msg'])) {
                    $fmt_data['response_msg'] = $response['response_msg'];
                }
                $fmt = SysSettingsFormatter::format($fmt_data, $isAdmin);
            } else {
                $fmt = [];
            }
        } else if ($section === 'sys-apps') {
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/sys/sys-apps.js'];
            $page['web_main']['scriptlink'][] = '/scripts/core/state-storage.js';
            $response = $reqController->getSystemApps();
            $fmt_data = [];
            if (isset($response['status']) && $response['status'] === 'success') {
                $fmt_data['packages'] = $response['result']['packages'] ?? [];
            } else {
                $fmt_data['packages'] = [];
            }
            // Fetch upgradable packages
            $upgResponse = $reqController->getUpgradablePackages();
            if (isset($upgResponse['status']) && $upgResponse['status'] === 'success') {
                $fmt_data['upgradable_packages'] = $upgResponse['result']['packages'] ?? [];
                $fmt_data['upgradable_count'] = $upgResponse['result']['count'] ?? 0;
                $fmt_data['security_count'] = $upgResponse['result']['security_count'] ?? 0;
            } else {
                $fmt_data['upgradable_packages'] = [];
                $fmt_data['upgradable_count'] = 0;
                $fmt_data['security_count'] = 0;
            }
            $auth = $ctx->get(AuthService::class);
            $fmt = SysAppsFormatter::format($fmt_data, $auth->getCapabilities());
        } else if ($section === 'sys-services') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/sys/sys-services.js'];
            $response = $reqController->getSystemServices();
            $fmt_data = [];
            if (isset($response['status']) && $response['status'] === 'success') {
                $fmt_data['services'] = $response['result']['services'] ?? [];
            } else {
                $fmt_data['services'] = [];
            }
            $auth = $ctx->get(AuthService::class);
            $fmt = SysServicesFormatter::format($fmt_data, $auth->getCapabilities());
        } else if ($section === 'sys-certs') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/sys/sys-certs.js'];
            $response = $reqController->getSystemCertificates();
            if (isset($response['status']) && $response['status'] === 'success') {
                $certs = $response['result']['certificates'] ?? [];
                $auth = $ctx->get(AuthService::class);
                $fmt = SysCertsFormatter::format($ctx, $certs, $auth->getCapabilities());
            } else {
                $fmt = ['certificates_grouped' => []];
            }
        } elseif ($section === 'sys-reboot') {
            $auth = $ctx->get(AuthService::class);
            $fmt = [
                'can_reboot' => RoleHelper::hasCapability(
                    $auth->getCapabilities(), 'system:admin'
                ),
            ];
        } elseif ($section === 'sys-logs') {
            $fmt_data = [
                'levels' => array_keys($logLevels),
                'selected_level' => 'DEBUG',
            ];
            $fmt = SysLogsFormatter::format($fmt_data);
            $page['web_main']['scriptlink'][] = '/scripts/core/state-storage.js';
            $page['web_main']['footer_script'][] = ['src' => '/scripts/logs/logs-parser.js'];
        }

        $page['page'] = $section;
        $page['page_data'] = $fmt ?? [];
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }
}
