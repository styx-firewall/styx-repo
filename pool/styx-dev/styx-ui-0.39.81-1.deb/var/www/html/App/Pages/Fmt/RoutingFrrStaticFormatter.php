<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class RoutingFrrStaticFormatter
{
    /**
     * @param array<string,mixed> $data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(array $data, array $userCaps = []): array
    {
        $canWrite  = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_save']   = $canWrite;
        $data['can_add']    = $canWrite;

        $routes = $data['frr_static_routes'] ?? [];
        foreach ($routes as &$r) {
            $r['can_delete'] = $canDelete;
            $r['type'] = $r['type'] ?? 'unicast';
            $r['network_label']  = self::displayPick($r['network_display'] ?? null, ['value', 'name'], (string)($r['network'] ?? ''));
            $r['gateway_label']  = self::displayPick($r['gateway_display'] ?? null, ['value', 'name'], '-');
            $r['interface_label'] = self::displayPick($r['interface_display'] ?? null, ['name', 'id'], '-');
            $r['route_tag_label'] = self::displayPick($r['route_tag_display'] ?? null, ['name', 'value'], '-');
            $r['table_label']    = self::displayPick($r['table_display'] ?? null, ['name', 'value'], '-');
            $r['distance']       = $r['distance'] ?? 1;
            $r['metric']         = $r['metric'] ?? 0;
            $r['onlink_flag']    = !empty($r['onlink']) ? '1' : '0';
        }
        unset($r);
        $data['frr_static_routes'] = $routes;

        return $data;
    }

    /**
     * Pick the first present key from a display object, else the fallback.
     *
     * @param mixed $d
     * @param string[] $keys
     */
    private static function displayPick($d, array $keys, string $fallback): string
    {
        if (is_array($d)) {
            foreach ($keys as $k) {
                if (isset($d[$k]) && $d[$k] !== null) {
                    return (string)$d[$k];
                }
            }
        }
        return $fallback;
    }
}
