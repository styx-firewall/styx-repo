<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;
use App\Services\Filter;

class RoutingEvpnFormatter
{
    /** @param array<string,mixed> $data @param string[] $userCaps */
    public static function format(array $data, array $userCaps = []): array
    {
        $canWrite = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_save'] = $canWrite;
        $data['can_add'] = $canWrite;
        $bindings = $data['vrf_bindings'] ?? [];
        foreach ($bindings as &$b) {
            $b['can_delete'] = $canDelete;
            $b['vrf_name_html']       = self::vrfNameHtml($b['vrf_iface_display'] ?? null);
            $b['l3vni_html']          = self::l3vniHtml($b['l3vni_display'] ?? null);
            $b['rd_html']             = self::autoOrValue($b['rd'] ?? null);
            $b['rt_export_html']      = self::autoOrValue($b['rt_export'] ?? null);
            $b['rt_import_html']      = self::autoOrValue($b['rt_import'] ?? null);
            $b['advertise_ipv4_label'] = !empty($b['advertise_ipv4_unicast']) ? 'Yes' : 'No';
            $b['advertise_ipv6_label'] = !empty($b['advertise_ipv6_unicast']) ? 'Yes' : 'No';
        }
        unset($b);
        $data['vrf_bindings'] = $bindings;
        return $data;
    }

    /** @param mixed $d */
    private static function vrfNameHtml($d): string
    {
        if (empty($d) || !is_array($d)) {
            return '<span class="text-dim">-</span>';
        }
        return '<strong>' . Filter::escHtml((string)($d['name'] ?? '')) . '</strong>';
    }

    /** @param mixed $d */
    private static function l3vniHtml($d): string
    {
        if (empty($d) || !is_array($d)) {
            return '<span class="text-dim">-</span>';
        }
        return '<span class="set-ref" title="ID: ' . Filter::escHtml((string)($d['id'] ?? '')) . '">'
            . '<span class="set-name">' . Filter::escHtml((string)($d['name'] ?? '')) . '</span>'
            . (!empty($d['value']) ? '<span class="set-type">' . Filter::escHtml((string)$d['value']) . '</span>' : '')
            . '</span>';
    }

    /** @param mixed $v */
    private static function autoOrValue($v): string
    {
        return $v === null ? '<span class="text-dim">auto</span>' : Filter::escHtml((string)$v);
    }
}
