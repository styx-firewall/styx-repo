<?php
/**
 * PageObjects - handles object management sections (currently 'sets')
 */
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Controllers\Request\SetsRequestController;
use App\Pages\Fmt\SetsFormatter;
use App\Pages\Fmt\LabelsFormatter;

class PageObjects
{
    /**
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'sets-mgmt',
            'sets-address',
            'sets-ports',
            'sets-interfaces',
            'sets-domain',
            'objects-labels',
        ];

        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'sets-mgmt';
        }

        $fmt_data = [];

        if ($section === 'sets-mgmt') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt.js'];

            $setsController = new SetsRequestController($ctx);
            $setsResp = $setsController->getFullSets();
            $fmt_data['sets'] = ($setsResp['status'] ?? '') === 'success' ? $setsResp['result'] : [];
            $fmt_data = SetsFormatter::format($fmt_data);
            $fmt_data['mode'] = 'mgmt';

            // Inject fragments  -  partials read from tpl_data
            $page['load_tpl'][] = [
                'file' => 'sets-address',
                'place' => 'sets_addresses',
                'weight' => 5,
                'tpl_data' => $fmt_data,
            ];
            $page['load_tpl'][] = [
                'file' => 'sets-ports',
                'place' => 'sets_ports',
                'weight' => 6,
                'tpl_data' => $fmt_data,
            ];
            $page['load_tpl'][] = [
                'file' => 'sets-interfaces',
                'place' => 'sets_interfaces',
                'weight' => 7,
                'tpl_data' => $fmt_data,
            ];
            $page['load_tpl'][] = [
                'file' => 'sets-domain',
                'place' => 'sets_domain',
                'weight' => 8,
                'tpl_data' => $fmt_data,
            ];
        }

        // Consolidated labels/tags management page
        if ($section === 'objects-labels') {
            $setsController = new SetsRequestController($ctx);
            $setsResp = $setsController->getLabelsWithTypes();
            $result = ($setsResp['status'] ?? '') === 'success' ? $setsResp['result'] : [];
            $fmt_data['labels'] = $result;
            $fmt_data['label_types'] = $result['label_types'] ?? [];
            $fmt_data = LabelsFormatter::format($fmt_data);
            $fmt_data['mode'] = 'mgmt';
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['load_tpl'][] = [
                'file' => 'objects-labels-fragment',
                'place' => 'labels_content',
                'weight' => 5,
                'tpl_data' => $fmt_data,
            ];
        }

        // Ajax sections - rendered as bare HTML fragments via ajax=1 (no page layout).
        $is_ajax_section = Filter::getString('ajax') === '1';

        if ($is_ajax_section) {
            $ajax_section_map = [
                'sets-address'    => 'sets-address',
                'sets-ports'      => 'sets-ports',
                'sets-interfaces' => 'sets-interfaces',
                'sets-domain'     => 'sets-domain',
                'objects-labels'  => 'objects-labels-fragment',
            ];

            if (!isset($ajax_section_map[$section])) {
                return $page;
            }

            $mode = 'picker';

            if ($section === 'objects-labels') {
                $setsController = new SetsRequestController($ctx);
                $setsResp = $setsController->getLabelsWithTypes();
                $ajax_data = $setsResp['status'] === 'success' ? $setsResp['result'] : [];
                $ajax_fmt = LabelsFormatter::format([
                    'labels' => $ajax_data,
                    'label_types' => $ajax_data['label_types'] ?? [],
                ]);
                $ajax_fmt['mode'] = $mode;
            } else {
                $ajax_fmt = self::loadSectionSets($ctx, $section);
                $ajax_fmt['mode'] = $mode;
            }

            $page['fragment_template'] = $ajax_section_map[$section];
            $page['tpl_data'] = $ajax_fmt;
            return $page;
        }

        $page['page'] = $section;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }

    /**
     * Load only the set type needed for the given AJAX section.
     * Avoids fetching all set types when only one picker/modal is opened.
     * Reads optional filter_scope[], filter_type[] from query string for server-side filtering.
     *
     * @param AppContext $ctx
     * @param string $section 'sets-address' | 'sets-ports' | 'sets-interfaces' | 'sets-domain'
     * @return array<string,mixed>
     */
    private static function loadSectionSets(AppContext $ctx, string $section): array
    {
        $setsController = new SetsRequestController($ctx);
        $filterScopes = Filter::sanArray('filter_scope', 'get');
        $filterTypes = Filter::sanArray('filter_type', 'get');

        // Start with empty placeholders for all types (Formatter expects them)
        $data = ['sets' => [
            'address' => [],
            'ports' => [],
            'interfaces_sets' => [],
            'domain' => [],
            'ifaces_names' => [],
        ]];

        switch ($section) {
            case 'sets-address':
                $filterType = !empty($filterTypes) ? $filterTypes[0] : null;
                $resp = $setsController->getAddress($filterScopes, $filterType);
                if (($resp['status'] ?? '') === 'success') {
                    $data['sets']['address'] = $resp['result']['address'] ?? [];
                }
                break;
            case 'sets-ports':
                $resp = $setsController->getPorts($filterScopes);
                if (($resp['status'] ?? '') === 'success') {
                    $data['sets']['ports'] = $resp['result']['ports'] ?? [];
                }
                break;
            case 'sets-interfaces':
                $filterType = !empty($filterTypes) ? $filterTypes[0] : null;
                $resp = $setsController->getInterfacesSets($filterType);
                if (($resp['status'] ?? '') === 'success') {
                    $data['sets']['interfaces_sets'] = $resp['result']['interfaces'] ?? [];
                }
                $ifacesResp = $setsController->getInterfacesNames();
                if (($ifacesResp['status'] ?? '') === 'success') {
                    $data['sets']['ifaces_names'] = $ifacesResp['result']['ifaces_names'] ?? [];
                }
                break;
            case 'sets-domain':
                $resp = $setsController->getDomains();
                if (($resp['status'] ?? '') === 'success') {
                    $data['sets']['domain'] = $resp['result']['domain'] ?? [];
                }
                break;
        }

        return SetsFormatter::format($data);
    }
}
