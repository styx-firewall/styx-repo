<?php
/**
 * Submit controller for discovery action commands (sweep, traceroute, pause, resume).
 */
namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class DiscoverySubmitController extends BaseController
{
    /**
     * Trigger an immediate ARP sweep on all subnets (or a specific CIDR if provided).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function sweepNow(array $data): array
    {
        $payload = null;
        if (!empty($data['cidr']) && is_string($data['cidr'])) {
            $payload = ['cidr' => $data['cidr']];
        }

        $commands = [[
            'method' => 'discovery.sweep_now',
            'id'     => 'sweep_now',
            'data'   => $payload,
        ]];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['sweep_now'] ?? $this->baseError('No response for sweep_now');
    }

    /**
     * Trigger ICMP traceroute to all discovered hosts (or a single IP if provided).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function tracerouteAll(array $data): array
    {
        $payload = null;
        if (!empty($data['ip']) && is_string($data['ip'])) {
            $payload = ['ip' => $data['ip']];
        }

        $commands = [[
            'method' => 'discovery.traceroute_now',
            'id'     => 'traceroute_now',
            'data'   => $payload,
        ]];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['traceroute_now'] ?? $this->baseError('No response for traceroute_now');
    }

    /**
     * Probe hosts for online/offline status now. With an 'ip' only that host is
     * probed; without one all pending candidates are probed.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function pingNow(array $data): array
    {
        $payload = null;
        if (!empty($data['ip']) && is_string($data['ip'])) {
            $payload = ['ip' => $data['ip']];
        }

        $commands = [[
            'method' => 'discovery.ping_now',
            'id'     => 'ping_now',
            'data'   => $payload,
        ]];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['ping_now'] ?? $this->baseError('No response for ping_now');
    }

    /**
     * Pause passive sniffing.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function pause(array $data): array
    {
        $commands = [[
            'method' => 'discovery.pause',
            'id'     => 'pause',
            'data'   => null,
        ]];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['pause'] ?? $this->baseError('No response for pause');
    }

    /**
     * Resume passive sniffing after a pause.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function resume(array $data): array
    {
        $commands = [[
            'method' => 'discovery.resume',
            'id'     => 'resume',
            'data'   => null,
        ]];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['resume'] ?? $this->baseError('No response for resume');
    }

    /**
     * Prune stale hosts older than the specified number of minutes.
     * Default: 10080 (7 days).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function pruneHosts(array $data): array
    {
        $minutes = isset($data['minutes']) ? (int)$data['minutes'] : 10080;

        $commands = [[
            'method' => 'discovery.prune_hosts',
            'id'     => 'prune_hosts',
            'data'   => ['minutes' => $minutes],
        ]];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['prune_hosts'] ?? $this->baseError('No response for prune_hosts');
    }

    /**
     * Update discovery settings at runtime (features toggles and max_wan_hops).
     *
     * @param array<string, mixed> $data  Expects 'features' (dict of bool) and/or 'max_wan_hops' (int).
     * @return array<string, mixed>
     */
    public function updateSettings(array $data): array
    {
        $payload = [];
        if (isset($data['features']) && is_array($data['features'])) {
            $features = [];
            foreach ($data['features'] as $key => $val) {
                if (is_string($key)) {
                    $features[$key] = (bool) $val;
                }
            }
            if (count($features) > 0) {
                $payload['features'] = $features;
            }
        }
        if (isset($data['max_wan_hops'])) {
            $payload['max_wan_hops'] = (int) $data['max_wan_hops'];
        }
        if (count($payload) === 0) {
            return $this->baseError('No valid settings provided');
        }

        $commands = [[
            'method' => 'discovery.update_settings',
            'id'     => 'update_settings',
            'data'   => $payload,
        ]];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['update_settings'] ?? $this->baseError('No response for update_settings');
    }
}
