<?php
namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class DhcpServerSubmitController extends BaseController
{

	/**
	 * Handle DHCP global config submission.
	 * @param array $data DHCP global configuration payload
	 * @return array Gateway command response or error array
	 */
	public function setDhcpGlobalConfig(array $data): array
	{
		$commands = [
			[
				'method' => 'dhcp-server.set_dhcp_global_config',
				'id' => 'set_dhcp_global_config',
				'data' => $data,
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		return $resp['commands']['set_dhcp_global_config'] ?? $this->baseError('No response for set_dhcp_global_config');
	}

	/**
	 * Handle DHCP config submission (IPv4 + IPv6).
	 * @param array $data DHCP configuration payload
	 * @return array Gateway command response or error array
	 */
	public function setDhcpConfig(array $data): array
	{
		$commands = [
			[
				'method' => 'dhcp-server.set_dhcp_config',
				'id' => 'set_dhcp_config',
				'data' => $data,
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		return $resp['commands']['set_dhcp_config'] ?? $this->baseError('No response for set_dhcp_config');
	}

	/**
	 * Handle DHCP reservations submission (IPv4 + IPv6).
	 * @param array $data Reservations payload (array of reservations)
	 * @return array Gateway command response or error array
	 */
	public function setDhcpReservations(array $data): array
	{
		$commands = [
			[
				'method' => 'dhcp-server.set_dhcp_reservations',
				'id' => 'set_dhcp_reservations',
				'data' => $data,
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		return $resp['commands']['set_dhcp_reservations'] ?? $this->baseError('No response for set_dhcp_reservations');
	}

	/**
	 * Handle DHCP config deletion for an interface (config + reservations + binding).
	 * Idempotent on the backend: succeeds even when no DHCP config is stored.
	 * @param array $data Payload with 'interface_id'
	 * @return array Gateway command response or error array
	 */
	public function deleteDhcpConfig(array $data): array
	{
		$commands = [
			[
				'method' => 'dhcp-server.delete_dhcp_config',
				'id' => 'delete_dhcp_config',
				'data' => $data,
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		return $resp['commands']['delete_dhcp_config'] ?? $this->baseError('No response for delete_dhcp_config');
	}
}
