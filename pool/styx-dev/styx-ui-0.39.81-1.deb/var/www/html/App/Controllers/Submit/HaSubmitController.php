<?php
// dr: 2025-12-01
namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class HaSubmitController extends BaseController
{

    public function saveConntrackdConfig($data = [])
    {
        $commands = [
            [
                'method' => 'conntrackd.save_conntrackd_config',
                'id' => 'save_conntrackd_config',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['save_conntrackd_config'] ?? $this->baseError('No response for save_conntrackd_config');
    }

    public function resetConntrackdConfig($data = [])
    {
        $commands = [
            [
                'method' => 'conntrackd.reset_conntrackd_config',
                'id' => 'reset_conntrackd_config',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['reset_conntrackd_config'] ?? $this->baseError('No response for reset_conntrackd_config');
    }
}
