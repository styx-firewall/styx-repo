<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class HaRequestController extends BaseController
{
    /**
     * Get High Availability (conntrackd) status, configuration and interface list.
     */
    public function getHaData()
    {
        $commands = [
            [
                'method' => 'conntrackd.get_conntrackd_status',
                'id' => 'get_conntrackd_status',
                'data' => (object)[],
            ],
            [
                'method' => 'network-config.get_interfaces_names_ds',
                'id' => 'ifaces_names',
                'data' => (object)[],
            ],
            [
                'method' => 'sets-mgmt.get_address',
                'id' => 'address_sets',
                'data' => (object)[],
            ],
            [
                'method' => 'sets-mgmt.get_ports',
                'id' => 'port_sets',
                'data' => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        $result = $cmds['get_conntrackd_status']['result'] ?? [];

        $ifacesCmd = $cmds['ifaces_names'] ?? null;
        if ($ifacesCmd && ($ifacesCmd['status'] ?? null) === 'success') {
            $res = $ifacesCmd['result'] ?? [];
            $result['ifaces'] = $res['ifaces_names_ds'] ?? [];
        } else {
            $result['ifaces'] = [];
        }

        $result['address_sets'] = [];
        $addrCmd = $cmds['address_sets'] ?? null;
        if ($addrCmd && ($addrCmd['status'] ?? null) === 'success') {
            $result['address_sets'] = $addrCmd['result']['address'] ?? [];
        }
        $result['port_sets'] = [];
        $portCmd = $cmds['port_sets'] ?? null;
        if ($portCmd && ($portCmd['status'] ?? null) === 'success') {
            $result['port_sets'] = $portCmd['result']['ports'] ?? [];
        }

        return ['status' => 'success', 'result' => $result];
    }
}
