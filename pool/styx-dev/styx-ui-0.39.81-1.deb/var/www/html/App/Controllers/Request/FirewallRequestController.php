<?php
/**
 * Controller for handling firewall-related requests
 *
 */
namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class FirewallRequestController extends BaseController
{
    /**
     * Get firewall rules
     *
     * @param array $tableFilters Table/chain/family filters
     * @param array $filters      Optional filters (system_rules, enabled, etc.)
     * @return array
     */
    public function getFirewallRules(array $tableFilters, array $filters = [])
    {
        $data = ['table_filters' => $tableFilters];

        if ($filters !== []) {
            $data['filters'] = $filters;
        }

        $commands[] = [
            'method' => 'firewall-rules.get_firewall_rules',
            'id'     => 'rules',
            'data'   => $data,
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $results = [];
        foreach ($resp['commands'] as $cmd) {
            if (!empty($cmd['result']['nftables'])) {
                $results = array_merge($results, $cmd['result']['nftables']);
            }
        }

        return [
            'status'   => $resp['status'],
            'result'   => $results,
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get firewall settings (conntrack bypass / drop invalid toggles)
     *
     * @return array
     */
    public function getFirewallSettings()
    {
        $commands[] = [
            'method' => 'firewall-settings.get_firewall_settings',
            'id'     => 'settings',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => [
                'settings' => $resp['commands']['settings']['result']['settings'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get ALL firewall rules from the gateway (no table/chain filter), each
     * rule already carrying its per-rule discrepancy warnings. Sends no data
     * so the gateway returns the whole ``nftables`` key untouched.
     *
     * @return array
     */
    public function getAllFirewallRules()
    {
        $commands[] = [
            'method' => 'firewall-rules.get_firewall_rules',
            'id'     => 'rules',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['rules']['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get the full firewall consistency report from the gateway
     * (per-rule discrepancies, ghosts, FIN/RST + NAT companions, order drift).
     *
     * @return array
     */
    public function getFirewallConsistency()
    {
        $commands[] = [
            'method' => 'firewall-rules.get_firewall_consistency',
            'id'     => 'consistency',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['consistency']['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get data needed to create a new firewall rule
     * TODO: submit ctrl
     */
    public function getCreateRuleFormData() {
        $commands[] = [
            'method' => 'sets-mgmt.get_address',
            'id' => 'address',
            'data' => ['scope' => ['network','host', 'set_host', 'set_range', 'set_networks', 'set_mixed']],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_ports',
            'id' => 'ports',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_interfaces_sets',
            'id' => 'ifaces_sets',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $this->logService->debug('Gateway response when preparing create firewall rule form: ' . print_r($resp, true));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status'   => $resp['status'],
            'result'   => [
                'addresses'   => $cmds['address']['result']['address'] ?? [],
                'ports'       => $cmds['ports']['result']['ports'] ?? [],
                'ifaces_sets' => $cmds['ifaces_sets']['result']['interfaces'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get data needed to edit a firewall rule
     * TODO: submit ctrl
     */
    public function getEditRuleFormData($ruleId)
    {
        $commands[] = [
            'method' => 'firewall-rules.get_edit_firewall_rule',
            'id' => 'rule',
            'data' => [
                    'id' => $ruleId
            ]
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_address',
            'id' => 'address',
            'data' => ['scope' => ['network','host', 'range', 'set_host', 'set_range', 'set_networks', 'set_mixed']],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_ports',
            'id' => 'ports',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_interfaces_sets',
            'id' => 'ifaces_sets',
            'data' => (object)[],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        $this->logService->debug('Gateway response when preparing edit firewall rule form: ' . print_r($resp, true));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status'   => $resp['status'],
            'result'   => [
                'rule'        => $cmds['rule']['result'] ?? [],
                'addresses'   => $cmds['address']['result']['address'] ?? [],
                'ports'       => $cmds['ports']['result']['ports'] ?? [],
                'ifaces_sets' => $cmds['ifaces_sets']['result']['interfaces'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }
}
