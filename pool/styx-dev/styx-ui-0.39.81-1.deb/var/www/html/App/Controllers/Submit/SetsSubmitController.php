<?php

namespace App\Controllers\Submit;

use App\Controllers\BaseController;
use App\Services\Filter;

class SetsSubmitController extends BaseController
{
    public function __construct($ctx)
    {
        parent::__construct($ctx);
    }

    public function set_port(array $data)
    {
        // Normalize tags: accept a string of tags (space or comma separated) or an array
        if (isset($data['tags'])) {
            if (is_string($data['tags'])) {
                $parts = preg_split('/[,\s]+/', $data['tags']);
                $parts = array_filter(array_map('trim', $parts));
                $data['tags'] = array_values($parts);
            } elseif (is_array($data['tags'])) {
                $data['tags'] = array_values(array_filter(array_map('trim', $data['tags'])));
            } else {
                unset($data['tags']);
            }
        }
        $commands = [
            [
                'method' => 'sets-mgmt.set_port',
                'id' => 'set_port',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['set_port'] ?? $this->baseError('No response for set_port');
    }

    public function set_address(array $data)
    {
        // Normalize tags: accept a string of tags (space or comma separated) or an array
        if (isset($data['tags'])) {
            if (is_string($data['tags'])) {
                $parts = preg_split('/[,\s]+/', $data['tags']);
                $parts = array_filter(array_map('trim', $parts));
                $data['tags'] = array_values($parts);
            } elseif (is_array($data['tags'])) {
                $data['tags'] = array_values(array_filter(array_map('trim', $data['tags'])));
            } else {
                unset($data['tags']);
            }
        }
        $commands = [
            [
                'method' => 'sets-mgmt.set_address',
                'id' => 'set_address',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['set_address'] ?? $this->baseError('No response for set_address');
    }

    public function set_interface_set(array $data)
    {
        // Normalize tags: accept a string of tags (space or comma separated) or an array
        if (isset($data['tags'])) {
            if (is_string($data['tags'])) {
                $parts = preg_split('/[,\s]+/', $data['tags']);
                $parts = array_filter(array_map('trim', $parts));
                $data['tags'] = array_values($parts);
            } elseif (is_array($data['tags'])) {
                $data['tags'] = array_values(array_filter(array_map('trim', $data['tags'])));
            } else {
                unset($data['tags']);
            }
        }
        $commands = [
            [
                'method' => 'sets-mgmt.set_interface_set',
                'id' => 'set_interface_set',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['set_interface_set'] ?? $this->baseError('No response for set_interface_set');
    }

    public function delete_port(array $data)
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Port ID not provided');
        }
        $commands = [
            [
                'method' => 'sets-mgmt.delete_port',
                'id' => 'delete_port',
                'data' => ['id' => $id],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['delete_port'] ?? $this->baseError('No response for delete_port');
    }

    public function delete_address(array $data)
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Address ID not provided');
        }
        $commands = [
            [
                'method' => 'sets-mgmt.delete_address',
                'id' => 'delete_address',
                'data' => ['id' => $id],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['delete_address'] ?? $this->baseError('No response for delete_address');
    }

    public function delete_interface_set(array $data)
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Interface set ID not provided');
        }
        $commands = [
            [
                'method' => 'sets-mgmt.delete_interface_set',
                'id' => 'delete_interface_set',
                'data' => ['id' => $id],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['delete_interface_set'] ?? $this->baseError('No response for delete_interface_set');
    }

    public function set_domain(array $data)
    {
        // Normalize tags: accept a string of tags (space or comma separated) or an array
        if (isset($data['tags'])) {
            if (is_string($data['tags'])) {
                $parts = preg_split('/[,\s]+/', $data['tags']);
                $parts = array_filter(array_map('trim', $parts));
                $data['tags'] = array_values($parts);
            } elseif (is_array($data['tags'])) {
                $data['tags'] = array_values(array_filter(array_map('trim', $data['tags'])));
            } else {
                // unsupported type: drop it
                unset($data['tags']);
            }
        }
        $commands = [
            [
                'method' => 'sets-mgmt.set_domain',
                'id' => 'set_domain',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['set_domain'] ?? $this->baseError('No response for set_domain');
    }

    public function set_label(array $data)
    {
        // Basic required fields
        $name = isset($data['name']) ? trim((string)$data['name']) : '';
        $value = isset($data['value']) ? trim((string)$data['value']) : '';

         if ($name === '') {
            return $this->baseError('Missing label name');
        }
        if ($value === '') {
            return $this->baseError('Missing value');
        }

        // Scope is now generated by the backend  -  no longer sent from the frontend.

        // Leave complex parsing/validation to gateway/backend
        $commands = [
            [
                'method' => 'sets-mgmt.set_label',
                'id' => 'set_label',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['set_label'] ?? $this->baseError('No response for set_label');
    }

    public function delete_label(array $data)
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Label ID not provided');
        }

        $commands = [[
            'method' => 'sets-mgmt.delete_label',
            'id' => 'delete_label',
            'data' => ['id' => $id],
        ]];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['delete_label'] ?? $this->baseError('No response for delete_label');
    }

    public function delete_domain(array $data)
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Domain ID not provided');
        }
        $commands = [
            [
                'method' => 'sets-mgmt.delete_domain',
                'id' => 'delete_domain',
                'data' => ['id' => $id],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['delete_domain'] ?? $this->baseError('No response for delete_domain');
    }

    public function delete_sets_by_tag(array $data)
    {
        // Sanitize via Filter::; varStrict accepts [A-Za-z0-9_-].
        $tag = Filter::varStrict($data['tag'] ?? '', 64);
        if ($tag === false) {
            return $this->baseError('Missing or invalid tag');
        }

        $cmd = [
            'method' => 'sets-mgmt.delete_sets_by_tag',
            'id' => 'delete_sets_by_tag',
            'data' => ['tag' => $tag],
        ];

        // Optional category filter (address|port|interface|domain|label).
        $setType = Filter::varStrict($data['set_type'] ?? '', 32);
        if ($setType !== false) {
            $cmd['data']['set_type'] = $setType;
        }

        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_sets_by_tag'] ?? $this->baseError('No response for delete_sets_by_tag');
    }
}
