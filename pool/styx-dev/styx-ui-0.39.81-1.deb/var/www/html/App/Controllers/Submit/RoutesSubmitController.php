<?php
# DP 20260211
# TESTED: 0

namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class RoutesSubmitController extends BaseController {
    public function deleteRouteById($data) {
        $routeId = $data['route_id'] ?? '';
        if (empty($routeId)) {
            return $this->baseError('Route ID is required');
        }
        $cmd = [
            'method' => 'routing-service.delete_route_by_id',
            'id' => 'delete_route_by_id',
            'data' => ['route_id' => $routeId],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_route_by_id'] ?? $this->baseError('No response for delete_route_by_id');
    }
    public function disableRoute($data) {
        $routeId = $data['route_id'] ?? '';
        if (empty($routeId)) {
            return $this->baseError('Route ID is required');
        }
        $cmd = [
            'method' => 'routing-service.disable_route',
            'id' => 'disable_route',
            'data' => ['route_id' => $routeId],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['disable_route'] ?? $this->baseError('No response for disable_route');
    }
    public function enableRoute($data) {
        $routeId = $data['route_id'] ?? '';
        if (empty($routeId)) {
            return $this->baseError('Route ID is required');
        }
        $cmd = [
            'method' => 'routing-service.enable_route',
            'id' => 'enable_route',
            'data' => ['route_id' => $routeId],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['enable_route'] ?? $this->baseError('No response for enable_route');
    }
    public function addRoute($data)
    {
        // Basic validation
        $route = $data['route'] ?? [];
        $dst = $route['dst'] ?? '';
        $pathMode = $route['path_mode'] ?? 'single';

        // Destination/gateway/dev must be address-set or interface UUIDs
        $uuidRegex = '/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/';

        // Backend requires `dst` to be an address-set UUID (no literal CIDR accepted)
        if (empty($dst) || !preg_match($uuidRegex, $dst)) {
            return $this->baseError('Destination must be an address-set UUID');
        }

        // Validate gateway in single-path mode: must be an address-set UUID
        if ($pathMode === 'single') {
            if (empty($route['gateway']) || !preg_match($uuidRegex, $route['gateway'])) {
                return $this->baseError('Gateway is required and must be an address-set UUID for single path routes');
            }
        }
        // Validar nexthops en modo multipath
        if ($pathMode === 'multipath') {
            if (empty($route['nexthops']) || !is_array($route['nexthops'])) {
                return $this->baseError('At least one nexthop is required for multipath routes');
            }
            // Validate nexthops and required fields
            foreach ($route['nexthops'] as $i => $nh) {
                if (empty($nh['gateway']) || empty($nh['dev'])) {
                    return $this->baseError('Each nexthop must have gateway and dev');
                }
                // Gateway must be an address-set UUID (no literal IP allowed when adding)
                if (!preg_match($uuidRegex, $nh['gateway'])) {
                    return $this->baseError('Nexthop gateway must be an address-set UUID');
                }
                // Dev must be an interface UUID
                if (!preg_match($uuidRegex, $nh['dev'])) {
                    return $this->baseError('Nexthop dev must be an interface UUID');
                }
                // Validate weight if provided: must be a positive integer
                if (isset($nh['weight'])) {
                    if (!is_numeric($nh['weight']) || (int)$nh['weight'] < 1) {
                        return $this->baseError('Nexthop weight must be a positive integer for nexthop index ' . $i);
                    }
                    $route['nexthops'][$i]['weight'] = (int)$nh['weight'];
                }
            }
            // Reindex nexthops to ensure sequential numeric keys
            $route['nexthops'] = array_values($route['nexthops']);
        }
        // Validate top-level metric if present: must be a non-negative integer
        if (isset($route['metric'])) {
            if (!is_numeric($route['metric']) || (int)$route['metric'] < 0) {
                return $this->baseError('Metric must be a non-negative integer');
            }
            $route['metric'] = (int) $route['metric'];
        }
        $cmd = [
            'method' => 'routing-service.add_route',
            'id' => 'add_route',
            'data' => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_route'] ?? $this->baseError('No response for add_route');
    }
}