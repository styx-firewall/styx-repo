<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 * v1.0
 */

namespace App\Constants;

trait ConstantsUtils
{
    /**
     *
     * @return array<string, int>
     */
    public static function getConstants(): array
    {
        return (new \ReflectionClass(self::class))->getConstants();
    }

    /**
     *
     * @param int $value
     * @return string|null
     */
    public static function getName(int $value): ?string
    {
        $constants = (new \ReflectionClass(self::class))->getConstants();
        $flipped = array_flip($constants);

        return $flipped[$value] ?? null;
    }
}