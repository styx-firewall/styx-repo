<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 * v1.0
 */

namespace App\Constants;

class LogLevel
{
    use ConstantsUtils;

    public const DEBUG = 7;
    public const INFO = 6;
    public const NOTICE = 5;
    public const WARNING = 4;
    public const ERROR = 3;
    public const CRITICAL = 2;
    public const ALERT = 1;
    public const EMERGENCY = 0;
}
