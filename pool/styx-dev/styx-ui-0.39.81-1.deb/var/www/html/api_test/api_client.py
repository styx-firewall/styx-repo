#!/usr/bin/env python3
"""Common API client for the Styx HTTP API (request.php / submit.php).

Python mirror of the frontend's scripts/core/api-client.js. Pure stdlib, no
external dependencies (no requests, no curl, no jmespath).

Handles: config loading, JSON encoding, bearer auth, TLS, timeouts, a unified
error shape, and dry-run flag injection for submit commands.

Typical usage (run from this directory so `api_client` is importable):

    from api_client import load_config, ApiClient, require_ok, dump

    cfg = load_config()                          # api_test/config.json (gitignored)
    api = ApiClient(cfg["base_url"], cfg.get("bearer_token", ""),
                    verify_tls=cfg.get("verify_tls", False),
                    timeout=cfg.get("timeout", 10))

    resp = api.request("get_interfaces_sets")         # POST /request.php
    require_ok(resp, "result.interfaces")             # raises if status != success or key missing

    created = api.submit("set_port", {"name": "p1", "type": "single", "value_single": 443})
    preview = api.preview("set_port", {...})          # dry-run: validates, no real change
"""

import json
import os
import ssl
import urllib.error
import urllib.request


class ApiError(Exception):
    """Raised on network/timeout/transport failures. Carries HTTP status + raw body."""

    def __init__(self, message, status=None, body=None):
        super().__init__(message)
        self.status = status
        self.body = body


REQUIRED_KEYS = ("base_url", "bearer_token")
PLACEHOLDER_TOKEN = "REPLACE_WITH_TOKEN"


def load_config(path=None):
    """Load the API config. Defaults to config.json next to this module.

    Raises FileNotFoundError if the file is missing and ValueError if it is
    malformed (not a JSON object), missing a required key (base_url,
    bearer_token), or still holds the placeholder bearer_token from
    config.example.json.
    """
    if path is None:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Config not found: {path}\n" "Copy config.example.json to config.json and set base_url + bearer_token."
        )
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    if not isinstance(cfg, dict):
        raise ValueError(f"Config {path} is not a JSON object (expected key/value pairs).")
    missing = [k for k in REQUIRED_KEYS if not cfg.get(k)]
    if missing:
        raise ValueError(
            f"Config {path} is missing required key(s): {', '.join(missing)}\n"
            "See config.example.json for the expected shape."
        )
    if cfg["bearer_token"] == PLACEHOLDER_TOKEN:
        raise ValueError(
            f"Config {path} still has the placeholder bearer_token ({PLACEHOLDER_TOKEN!r}).\n"
            "Replace it with a real token (see config.example.json)."
        )
    return cfg


def _unverified_context():
    """SSL context that skips certificate validation (self-signed appliance)."""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


class ApiClient:
    """Minimal POST-only client for the Styx JSON API."""

    def __init__(self, base_url, bearer_token="", verify_tls=False, timeout=10):
        self.base_url = base_url.rstrip("/")
        self.bearer_token = bearer_token
        self.verify_tls = verify_tls
        self.timeout = timeout

    # --- transport ---------------------------------------------------------

    def _post(self, endpoint, payload):
        req = urllib.request.Request(
            self.base_url + endpoint,
            data=json.dumps(payload).encode("utf-8"),
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.bearer_token}",
            },
        )
        context = None if self.verify_tls else _unverified_context()
        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=context) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                status = getattr(resp, "status", 200)
        except urllib.error.HTTPError as e:
            # The API returns JSON error envelopes even on HTTP errors
            raw = e.read().decode("utf-8", errors="replace")
            status = e.code
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                raise ApiError(f"HTTP {status} from {endpoint}", status=status, body=raw)
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise ApiError(f"Request to {self.base_url + endpoint} failed: {e}")

        if not raw:
            return {"status": "error", "response_msg": "Empty response"}
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            raise ApiError(f"Invalid JSON from {endpoint}", status=status, body=raw)

    # --- public API --------------------------------------------------------

    def request(self, action, data=None):
        """Query a read action on /request.php."""
        payload = dict(data or {})
        payload["action"] = action
        return self._post("/request.php", payload)

    def submit(self, command, data=None, dry_run=False):
        """Run a write command on /submit.php.

        dry_run=True injects ``"dry-run": true`` so the gateway validates the
        command (schema/logic) without applying real changes. Not every command
        supports it; see handlers/handler_client.py in the gateway.
        """
        payload = dict(data or {})
        payload["command"] = command
        if dry_run:
            payload["dry-run"] = True
        return self._post("/submit.php", payload)

    def preview(self, command, data=None):
        """Dry-run wrapper around submit(): validate without applying."""
        return self.submit(command, data, dry_run=True)

    # --- convenience -------------------------------------------------------

    def request_ok(self, action, data=None, *keys):
        """request() + require_ok(); returns the parsed response or raises."""
        return require_ok(self.request(action, data), *keys)

    def submit_ok(self, command, data=None, dry_run=False, *keys):
        """submit() + require_ok(); returns the parsed response or raises."""
        return require_ok(self.submit(command, data, dry_run), *keys)


# --- assertion helpers ------------------------------------------------------


def get(resp, dotted):
    """Resolve a dotted path into the response dict (no jmespath needed)."""
    cur = resp
    for part in dotted.split("."):
        if isinstance(cur, dict) and part in cur and cur[part] is not None:
            cur = cur[part]
        else:
            return None
    return cur


def ok(resp, *keys):
    """True if resp has status 'success' and every dotted key is present (not None).

    Empty collections (``[]``, ``{}``, ``""``) count as present: an endpoint that
    returns an empty list is healthy. Scripts that need a non-empty value check it
    explicitly.
    """
    if not isinstance(resp, dict) or resp.get("status") != "success":
        return False
    return all(get(resp, k) is not None for k in keys)


def require_ok(resp, *keys):
    """Like ok() but raises AssertionError with the response body on failure."""
    if ok(resp, *keys):
        return resp
    raise AssertionError(
        "assertion failed (status=%r, keys=%r): %s"
        % (
            resp.get("status") if isinstance(resp, dict) else resp,
            keys,
            json.dumps(resp, ensure_ascii=False, indent=2),
        )
    )


def dump(resp, indent=2):
    """Pretty-print a JSON response (handy for probing)."""
    print(json.dumps(resp, indent=indent, ensure_ascii=False))
