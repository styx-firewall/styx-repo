#!/usr/bin/env python3
"""Lifecycle verification for the Packet Marking module.

Real flow: create packet_marking labels, preview a rule (nft_run), create the
address/port/iface-set dependencies, create a matrix of rules (mark_target meta
and ct, input/forward chains, ipv6, inactive, src/dst port/addr, edit, toggle),
verify they appear in get_pm_rules, then delete rules and cleanup the sets.

Also ports a few dry-run validation cases from the old packet-marking-dry.json:
malformed rules must be rejected with status error and no side effects.

Replaces the old payloads/submit/packet-marking-real.json + packet-marking-dry.json.
Leaves no residual state.

Usage:
    python api_test/verify_packet_marking.py [--config path/to/config.json]
"""

import json
import secrets

from api_client import ApiError, require_ok
from verify_common import build_parser, build_client, cleanup, finish

ZERO_UUID = "00000000-0000-0000-0000-000000000000"


def run(client):
    created = []  # (delete_command, {"id": rid}) — cleanup in reverse order
    suffix = secrets.token_hex(4)

    def remember(cmd, data):
        created.append((cmd, data))

    def forget(cmd, data):
        try:
            created.remove((cmd, data))
        except ValueError:
            pass

    def create(label, cmd, data, delete_cmd=None):
        resp = require_ok(client.submit(cmd, data), "result.id")
        rid = resp["result"]["id"]
        if delete_cmd:
            remember(delete_cmd, {"id": rid})
        print(f"  OK   {label} (id={rid})")
        return rid

    def preview_error(label, data, contains=None):
        resp = client.preview("set_pm_rule", data)
        if resp.get("status") != "error":
            raise AssertionError(f"{label}: expected status error, got {json.dumps(resp, ensure_ascii=False)}")
        if contains and contains not in str(resp.get("response_msg", "")):
            raise AssertionError(f"{label}: response_msg {resp.get('response_msg')!r} does not contain {contains!r}")
        print(f"  OK   {label}")

    try:
        # ---- labels (packet_marking scope) --------------------------------
        L = {}
        for key, slug, value, comment in [
            ("DSCP", "dscp", "0x2e", "DSCP EF"),
            ("VOIP", "voip", "0x5", "VoIP"),
            ("CT", "ct", "0x3", "ct mark"),
            ("HIGH", "high", "200", "high priority"),
        ]:
            L[key] = create(
                f"label {key}",
                "sets-mgmt.set_label",
                {"type": "packet_marking", "name": f"pm-{slug}-{suffix}", "value": value, "comment": comment},
                delete_cmd="sets-mgmt.delete_label",
            )

        # ---- preview ------------------------------------------------------
        r = require_ok(
            client.submit(
                "preview_pm_rule",
                {
                    "name": f"pm-prev-{suffix}",
                    "chain": "forward",
                    "family": "ip",
                    "mark_target": "meta",
                    "mark": L["DSCP"],
                },
            ),
            "result.nft_run",
        )
        if "nft add rule" not in (r["result"].get("nft_run") or ""):
            raise AssertionError("preview result.nft_run does not mention 'nft add rule'")
        print("  OK   preview rule (nft_run)")

        # ---- dependencies (address/port/iface sets) ----------------------
        A = {
            "LAN": create(
                "address LAN",
                "set_address",
                {"name": f"pm-lan-{suffix}", "type": "set", "family": "ip", "value_set": ["192.168.10.0/24"]},
                "delete_address",
            ),
            "SRV": create(
                "address SRV",
                "set_address",
                {"name": f"pm-srv-{suffix}", "type": "single", "family": "ip", "value_single": "10.10.20.100"},
                "delete_address",
            ),
        }
        P = {
            "SSH": create(
                "port SSH",
                "set_port",
                {"name": f"pm-ssh-{suffix}", "type": "single", "value_single": 22},
                "delete_port",
            ),
            "HTTP": create(
                "port HTTP",
                "set_port",
                {"name": f"pm-http-{suffix}", "type": "single", "value_single": 80},
                "delete_port",
            ),
            "DNS": create(
                "port DNS",
                "set_port",
                {"name": f"pm-dns-{suffix}", "type": "single", "value_single": 53},
                "delete_port",
            ),
        }
        I_LO = create(
            "iface set lo",
            "set_interface_set",
            {"name": f"pm-lo-{suffix}", "type": "single", "value_single": "lo"},
            "delete_interface_set",
        )

        # ---- rules --------------------------------------------------------
        def rule(label, name, data):
            return create(label, "set_pm_rule", dict({"name": name}, **data), "delete_pm_rule")

        R = {}
        R["MIN"] = rule(
            "rule minimal",
            f"pm-min-{suffix}",
            {"chain": "forward", "family": "ip", "mark_target": "meta", "mark": L["DSCP"]},
        )
        R["HTTP"] = rule(
            "rule http",
            f"pm-http-{suffix}",
            {
                "chain": "forward",
                "family": "ip",
                "mark_target": "meta",
                "mark": L["HIGH"],
                "protocol": "tcp",
                "dst_port": P["HTTP"],
            },
        )
        R["SSH"] = rule(
            "rule ssh-input",
            f"pm-r-ssh-{suffix}",
            {
                "chain": "input",
                "family": "ip",
                "mark_target": "meta",
                "mark": L["VOIP"],
                "protocol": "tcp",
                "src_addr": A["LAN"],
                "dst_port": P["SSH"],
            },
        )
        R["CT"] = rule(
            "rule ct-dns",
            f"pm-ct-{suffix}",
            {
                "chain": "forward",
                "family": "ip",
                "mark_target": "ct",
                "mark": L["CT"],
                "protocol": "udp",
                "src_addr": A["LAN"],
                "dst_port": P["DNS"],
            },
        )
        R["SRV"] = rule(
            "rule srv-http",
            f"pm-srv-{suffix}",
            {
                "chain": "forward",
                "family": "ip",
                "mark_target": "meta",
                "mark": L["DSCP"],
                "protocol": "tcp",
                "dst_addr": A["SRV"],
                "dst_port": P["HTTP"],
                "priority": 10,
            },
        )
        R["IFACE"] = rule(
            "rule iface lo",
            f"pm-if-{suffix}",
            {
                "chain": "forward",
                "family": "ip",
                "mark_target": "meta",
                "mark": L["HIGH"],
                "iface_dir": "iifname",
                "iface_set": I_LO,
            },
        )
        R["INACT"] = rule(
            "rule inactive",
            f"pm-r-inact-{suffix}",
            {
                "chain": "forward",
                "family": "ip",
                "mark_target": "meta",
                "mark": L["DSCP"],
                "active": False,
                "protocol": "tcp",
                "dst_port": P["SSH"],
            },
        )
        R["IPV6"] = rule(
            "rule ipv6",
            f"pm-r-ipv6-{suffix}",
            {"chain": "forward", "family": "ip6", "mark_target": "meta", "mark": L["DSCP"], "protocol": "icmpv6"},
        )
        R["SRCP"] = rule(
            "rule src-port",
            f"pm-srcp-{suffix}",
            {
                "chain": "forward",
                "family": "ip",
                "mark_target": "meta",
                "mark": L["DSCP"],
                "protocol": "tcp",
                "src_port": P["SSH"],
            },
        )

        # ---- toggle + edit ------------------------------------------------
        require_ok(client.submit("toggle_pm_rule", {"id": R["MIN"]}))
        require_ok(client.submit("toggle_pm_rule", {"id": R["MIN"]}))
        print("  OK   toggle rule (off/back on)")

        R["EDIT"] = rule(
            "rule edit (create)",
            f"pm-edit0-{suffix}",
            {
                "chain": "forward",
                "family": "ip",
                "mark_target": "meta",
                "mark": L["DSCP"],
                "protocol": "tcp",
                "dst_port": P["HTTP"],
            },
        )
        require_ok(
            client.submit(
                "set_pm_rule",
                {
                    "id": R["EDIT"],
                    "name": f"pm-edit1-{suffix}",
                    "chain": "forward",
                    "family": "ip",
                    "mark_target": "meta",
                    "mark": L["DSCP"],
                    "priority": 5,
                },
            )
        )
        print("  OK   rule edit (update)")

        # ---- verify all rules are visible ---------------------------------
        resp = require_ok(client.request("get_pm_rules"), "result.rules")
        rule_ids = {item["id"] for item in resp["result"]["rules"]}
        missing = [k for k, rid in R.items() if rid not in rule_ids]
        if missing:
            raise AssertionError(f"rules missing from get_pm_rules: {missing}")
        print(f"  OK   get_pm_rules contains all {len(R)} rules")

        # ---- dry-run validation (malformed rules must be rejected) --------
        preview_error(
            "reject invalid mark",
            {
                "name": f"pm-bad-{suffix}",
                "chain": "forward",
                "family": "ip",
                "mark_target": "meta",
                "mark": "00000000-0000-0000-0000-000000000001",
            },
        )
        preview_error(
            "reject missing name",
            {"chain": "forward", "family": "ip", "mark_target": "meta", "mark": ZERO_UUID},
            contains="name",
        )
        preview_error(
            "reject bad family",
            {
                "name": f"pm-bad-{suffix}",
                "chain": "forward",
                "family": "inet",
                "mark_target": "meta",
                "mark": ZERO_UUID,
            },
            contains="family",
        )
        preview_error(
            "reject bad mark_target",
            {
                "name": f"pm-bad-{suffix}",
                "chain": "forward",
                "family": "ip",
                "mark_target": "skbmark",
                "mark": ZERO_UUID,
            },
            contains="mark_target",
        )
        preview_error(
            "reject icmp+ip6 mismatch",
            {
                "name": f"pm-bad-{suffix}",
                "chain": "forward",
                "family": "ip6",
                "mark_target": "meta",
                "mark": ZERO_UUID,
                "protocol": "icmp",
            },
        )
        preview_error(
            "reject iface_set without iface_dir",
            {
                "name": f"pm-bad-{suffix}",
                "chain": "forward",
                "family": "ip",
                "mark_target": "meta",
                "mark": ZERO_UUID,
                "iface_set": "00000000-0000-0000-0000-000000000001",
            },
        )
        preview_error(
            "reject dst_port without protocol",
            {
                "name": f"pm-bad-{suffix}",
                "chain": "forward",
                "family": "ip",
                "mark_target": "meta",
                "mark": ZERO_UUID,
                "dst_port": "00000000-0000-0000-0000-000000000001",
            },
        )

        # ---- explicit cleanup (rules -> sets/labels) ----------------------
        for k, rid in R.items():
            require_ok(client.submit("delete_pm_rule", {"id": rid}))
            forget("delete_pm_rule", {"id": rid})
        print("  OK   delete rules")

        resp = require_ok(client.request("get_labels"), "result.labels")
        label_ids = {item["id"] for item in resp["result"]["labels"]}
        missing_labels = [k for k, lid in L.items() if lid not in label_ids]
        if missing_labels:
            raise AssertionError(f"labels missing after rule deletion: {missing_labels}")
        print("  OK   labels still present after rule deletion")

        for lid in L.values():
            require_ok(client.submit("sets-mgmt.delete_label", {"id": lid}))
            forget("sets-mgmt.delete_label", {"id": lid})
        for aid in A.values():
            require_ok(client.submit("delete_address", {"id": aid}))
            forget("delete_address", {"id": aid})
        for pid in P.values():
            require_ok(client.submit("delete_port", {"id": pid}))
            forget("delete_port", {"id": pid})
        require_ok(client.submit("delete_interface_set", {"id": I_LO}))
        forget("delete_interface_set", {"id": I_LO})
        print("  OK   cleanup sets and labels")

    finally:
        cleanup(client, created)


def main():
    args = build_parser("Verify packet marking module: labels/rules lifecycle + dry-run validation").parse_args()
    client = build_client(args)
    try:
        run(client)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
