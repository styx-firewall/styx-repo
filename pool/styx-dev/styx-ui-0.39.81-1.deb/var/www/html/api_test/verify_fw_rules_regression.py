#!/usr/bin/env python3
"""Lifecycle + regression verification for firewall rules against the HTTP API.

Covers the firewall-rule mutation paths that were hardened in the gateway
(fw_rules_service): create, in-place update, update that moves a rule to another
chain, move relative to another rule, the disable/enable cycle, and delete.
Consistency is asserted two ways:
  - per-rule "warnings" attached by get_firewall_rules (system / handle), and
  - the dedicated get_firewall_consistency report (per-rule + ghosts + FIN/RST +
    NAT companions + order drift), which is the API "tell me if everything is
    correct" after each scenario.

Blast radius is kept near zero: every rule references a throwaway address set
built from the documentation net 198.51.100.0/24 (RFC 5737), so no real traffic
matches the test rules. FIN/RST log companions are chain-wide by design (the
builder has no selector), so the log-rule steps log FIN/RST packets while they
exist; the script creates and removes them quickly.

Assumptions on the target box:
  - the filter chains used here (forward and input) have end-of-chain rules, so
    user rules can be created/moved in them;
  - the baseline is consistent: no pre-existing per-rule discrepancy on the
    rules this script creates (otherwise the no-warnings assertions fail).

Run it on a lab box, not on a production gateway.

Usage:
    python api_test/verify_fw_rules_regression.py [--config path] [--skip-reload]
"""

import secrets

from api_client import ApiError, require_ok
from verify_common import build_parser, build_client, cleanup, finish

# Chains used for the placement tests (must have EOC rules on the target).
FORWARD_CHAIN = "forward"
INPUT_CHAIN = "input"


def get_all_rules(client):
    resp = require_ok(client.request("get_firewall_rules"), "result.nftables")
    out = []
    for r in resp["result"]["nftables"]:
        if isinstance(r, dict):
            r = r.copy()
            # A rule whose `enabled` key is absent is enabled by convention
            # (every fw_rules_service read defaults it to True), so surface
            # that default here for uniform assertions.
            r.setdefault("enabled", True)
        out.append(r)
    return out


def find_rule(rules, rid):
    for r in rules:
        if r.get("id") == rid:
            return r
    return None


def nat_companions(rules, parent_id):
    return [r for r in rules if r.get("is_nat") and r.get("ref") == parent_id]


def assert_no_warnings(client, ids, label):
    """get_firewall_rules attaches discrepancy warnings per existing rule; a clean
    rule (present in kernel, handle in sync) must have none."""
    rules = get_all_rules(client)
    for rid in ids:
        r = find_rule(rules, rid)
        if r is None:
            raise AssertionError(f"{label}: rule {rid} not found in get_firewall_rules")
        warns = r.get("warnings") or []
        if warns:
            detail = "; ".join(w["msg"] for w in warns)
            raise AssertionError(f"{label}: rule {rid} has unexpected warnings: {detail}")


def get_consistency_report(client):
    resp = require_ok(client.request("get_firewall_consistency"), "result.summary")
    return resp["result"]


def consistency_issues_for(report, ids):
    """Collect every consistency bucket entry that references any of ``ids``."""
    idset = set(ids)
    found = []
    for rid in idset:
        for w in (report.get("rules") or {}).get(rid, []):
            found.append(f"rule {rid}: {w.get('key')}")
    for e in report.get("extra") or []:
        if e.get("uuid") in idset:
            found.append(f"extra {e['uuid']} in {e['family']}/{e['table']}/{e['chain']}")
    for f in report.get("finrst") or []:
        if f.get("rule_id") in idset:
            found.append(f"finrst {f['issue']} for {f['rule_id']}")
    for c in report.get("companions") or []:
        if c.get("rule_id") in idset or c.get("ref") in idset:
            found.append(f"companion {c['issue']} ({c.get('rule_id')} ref {c.get('ref')})")
    for chain, seqs in (report.get("order") or {}).items():
        if idset & (set(seqs.get("config", [])) | set(seqs.get("system", []))):
            found.append(f"order drift in {chain}")
    return found


def check_consistency(client, ids, label):
    """Ask the gateway 'is everything correct?' via get_firewall_consistency and
    fail if any bucket references our test rules. Prints the global summary."""
    report = get_consistency_report(client)
    issues = consistency_issues_for(report, ids)
    if issues:
        raise AssertionError(f"{label}: consistency issues for test rules: {issues}")
    s = report["summary"]
    print(
        "  INFO consistency ({}): ok={} rules={} extra={} finrst={} companions={} "
        "order={} skipped={}".format(
            label,
            s["ok"],
            s["rules_with_issues"],
            s["extra"],
            s["finrst"],
            s["companions"],
            s["order_drift"],
            s["skipped_chains"],
        )
    )
    print(f"  OK   consistency clean for test rules ({label})")


def run(client, skip_reload=False):
    created = []  # (delete_command, {"id": rid}) - cleanup in reverse order
    our_rule_ids = []  # every rule this run creates, for the final consistency check
    suffix = secrets.token_hex(4)

    def create_rule(label, data):
        resp = require_ok(client.submit("set_firewall_rule", data), "result.id")
        rid = resp["result"]["id"]
        created.append(("delete_firewall_rule", {"id": rid}))
        our_rule_ids.append(rid)
        print(f"  OK   {label} created (id={rid})")
        return rid

    try:
        # 0. Throwaway address set (RFC 5737 TEST-NET-2) to scope every rule.
        addr_resp = require_ok(
            client.submit(
                "set_address",
                {"name": f"vr-addr-{suffix}", "type": "single", "family": "ip", "value_single": "198.51.100.240"},
            ),
            "result.id",
        )
        addr_id = addr_resp["result"]["id"]
        created.append(("delete_address", {"id": addr_id}))
        print(f"  OK   address set created (id={addr_id})")

        # 1. Create a NAT (masquerade) parent rule on filter/forward.
        nat_rule = create_rule(
            "nat parent (create)",
            {
                "name": f"vr-nat-{suffix}",
                "family": "ip",
                "table": "filter",
                "chain": FORWARD_CHAIN,
                "action": "accept",
                "nat": True,
                "dst_ips": [addr_id],
                "comment": "styx api-test nat",
            },
        )
        rules = get_all_rules(client)
        nat = find_rule(rules, nat_rule)
        comps = nat_companions(rules, nat_rule)
        assert nat and nat.get("enabled") and nat.get("handle") is not None, "nat parent must be enabled with handle"
        assert len(comps) == 1, f"expected exactly one NAT companion, got {len(comps)}"
        assert comps[0].get("handle") is not None, "NAT companion must carry a handle"
        comp_id = comps[0]["id"]
        print("  OK   nat companion present exactly once with handle")

        # 2. In-place update of the nat parent (keeps nat) -> companion
        #    replaced with a stable id, never duplicated.
        require_ok(client.submit("update_firewall_rule", {"id": nat_rule, "comment": "styx api-test nat edited"}))
        rules = get_all_rules(client)
        comps = nat_companions(rules, nat_rule)
        assert len(comps) == 1, f"in-place nat update left {len(comps)} companions"
        assert comps[0]["id"] == comp_id, "NAT companion id must stay stable across an in-place update"
        assert comps[0].get("handle") is not None, "NAT companion handle must be fresh after the update"
        print("  OK   in-place nat update: single companion, stable id")

        # 3. Disable / enable cycle (the classic nat re-enable drift).
        require_ok(client.submit("set_firewall_rule_enabled", {"id": nat_rule, "enabled": False}))
        rules = get_all_rules(client)
        nat = find_rule(rules, nat_rule)
        assert nat and not nat.get("enabled"), "rule must be disabled after disable"
        assert nat_companions(rules, nat_rule) == [], "companion must be gone from datastore after disable"
        print("  OK   disable: companion removed")

        require_ok(client.submit("set_firewall_rule_enabled", {"id": nat_rule, "enabled": True}))
        rules = get_all_rules(client)
        nat = find_rule(rules, nat_rule)
        comps = nat_companions(rules, nat_rule)
        assert nat and nat.get("enabled") and nat.get("handle") is not None, "rule must be enabled with handle"
        assert len(comps) == 1 and comps[0].get("handle") is not None, "re-enable must recreate the companion"
        assert_no_warnings(client, [nat_rule], "enable")
        check_consistency(client, [nat_rule], "nat enable")
        print("  OK   enable: companion recreated, no discrepancy warning")

        # 4. Log rule (FIN/RST companion) lifecycle on filter/forward.
        log_rule = create_rule(
            "log rule (create)",
            {
                "name": f"vr-log-{suffix}",
                "family": "ip",
                "table": "filter",
                "chain": FORWARD_CHAIN,
                "action": "accept",
                "protocol": "tcp",
                "log": True,
                "dst_ips": [addr_id],
                "comment": "styx api-test log",
            },
        )
        assert_no_warnings(client, [log_rule], "log create")

        # In-place edit keeping log -> finrst replace happens at execution time.
        require_ok(client.submit("update_firewall_rule", {"id": log_rule, "comment": "styx api-test log edited"}))
        assert_no_warnings(client, [log_rule], "log in-place edit")

        # Log off -> the stale FIN/RST companion must be removed (transition out).
        require_ok(client.submit("update_firewall_rule", {"id": log_rule, "log": False}))
        assert_no_warnings(client, [log_rule], "log off")

        # Log back on -> companion recreated.
        require_ok(client.submit("update_firewall_rule", {"id": log_rule, "log": True}))
        assert_no_warnings(client, [log_rule], "log on")
        check_consistency(client, [log_rule], "log lifecycle")
        print("  OK   log rule: create / in-place / off / on all clean")

        # 5. Update that MOVES a log rule to another chain (keeps log).
        chain_rule = create_rule(
            "chain-change rule (create)",
            {
                "name": f"vr-chn-{suffix}",
                "family": "ip",
                "table": "filter",
                "chain": FORWARD_CHAIN,
                "action": "accept",
                "protocol": "tcp",
                "log": True,
                "dst_ips": [addr_id],
                "comment": "styx api-test chain",
            },
        )
        require_ok(client.submit("update_firewall_rule", {"id": chain_rule, "chain": INPUT_CHAIN}))
        rules = get_all_rules(client)
        moved = find_rule(rules, chain_rule)
        assert moved is not None and moved.get("chain") == INPUT_CHAIN, "rule must live in the new chain"
        assert moved.get("enabled") and moved.get("handle") is not None, "moved rule must stay enabled with handle"
        assert_no_warnings(client, [chain_rule], "chain change")
        check_consistency(client, [chain_rule], "chain change")
        print("  OK   chain change: rule relocated to input, no consistency issues")

        # 6. Move a log rule relative to a sibling (FIN/RST follows the move).
        ref_rule = create_rule(
            "move anchor (create)",
            {
                "name": f"vr-ref-{suffix}",
                "family": "ip",
                "table": "filter",
                "chain": FORWARD_CHAIN,
                "action": "accept",
                "dst_ips": [addr_id],
                "comment": "styx api-test move anchor",
            },
        )

        def order_index(rid):
            return [r.get("id") for r in get_all_rules(client)].index(rid)

        require_ok(client.submit("move_firewall_rule", {"id": log_rule, "ref_id": ref_rule, "position": "after"}))
        assert order_index(log_rule) > order_index(ref_rule), "log rule must sit after the anchor after the move"
        assert_no_warnings(client, [log_rule, ref_rule], "move after")
        print("  OK   move 'after': order ok")

        require_ok(client.submit("move_firewall_rule", {"id": log_rule, "ref_id": ref_rule, "position": "before"}))
        assert order_index(log_rule) < order_index(ref_rule), "log rule must sit before the anchor after the move"
        assert_no_warnings(client, [log_rule, ref_rule], "move before")
        check_consistency(client, [log_rule, ref_rule], "move")
        print("  OK   move 'before': order ok")

        # 7. Delete everything explicitly; assert no residue.
        for rid, label in (
            (ref_rule, "anchor"),
            (chain_rule, "chain-change rule"),
            (log_rule, "log rule"),
            (nat_rule, "nat parent"),
        ):
            require_ok(client.submit("delete_firewall_rule", {"id": rid}))
            created[:] = [c for c in created if not (c[0] == "delete_firewall_rule" and c[1].get("id") == rid)]
            print(f"  OK   deleted {label} ({rid})")

        rules = get_all_rules(client)
        leftover = [rid for rid in (ref_rule, chain_rule, log_rule, nat_rule) if find_rule(rules, rid) is not None]
        assert not leftover, f"rules not deleted: {leftover}"
        print("  OK   no test rules left in the datastore")

        # Consistency after cleanup: nothing may reference our rules anymore --
        # in particular no stranded FIN/RST companion or leftover masquerade.
        check_consistency(client, our_rule_ids, "post-delete")

        # 8. (optional) Reload: full flush+apply + handle resync, then confirm
        #    no residue and a success status. Assumes a consistent baseline.
        if not skip_reload:
            require_ok(client.submit("firewall_reload"))
            rules = get_all_rules(client)
            assert all(find_rule(rules, rid) is None for rid in (ref_rule, chain_rule, log_rule, nat_rule))
            print("  OK   firewall_reload succeeded")
        else:
            print("  SKIP firewall_reload (--skip-reload)")
    finally:
        cleanup(client, created)


def main():
    parser = build_parser("Verify firewall rule mutation lifecycle + regression (create/update/move/toggle/delete)")
    parser.add_argument("--skip-reload", action="store_true", help="Do not run the firewall_reload step")
    args = parser.parse_args()
    client = build_client(args)
    try:
        run(client, skip_reload=args.skip_reload)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
