#!/usr/bin/env python3
"""Read-only firewall consistency check against the HTTP API.

Runs the gateway's ``get_firewall_consistency`` command (the "is everything
correct?" report: per-rule discrepancies, ghost rules, FIN/RST and NAT
companions, kernel-vs-datastore order drift) and prints the full report.

Exits 0 when ``summary.ok`` is true (no discrepancies and no chain that could
not be verified); exits 1 otherwise. Makes no changes to the system.

Usage:
    python api_test/verify_firewall_consistency.py [--config path/to/config.json]
"""

from api_client import ApiError, require_ok
from verify_common import build_parser, build_client, finish


def _report_row(prefix, fields):
    parts = " ".join(f"{k}={v}" for k, v in fields.items() if v is not None)
    print(f"    {prefix} {parts}")


def run(client):
    resp = require_ok(client.request("get_firewall_consistency"), "result.summary")
    report = resp["result"]
    s = report["summary"]
    print(f"  INFO consistency summary: ok={s['ok']}")
    print(
        f"      rules_with_issues={s['rules_with_issues']} extra={s['extra']} "
        f"finrst={s['finrst']} companions={s['companions']} "
        f"order_drift={s['order_drift']} skipped_chains={s['skipped_chains']}"
    )

    for rid, warns in sorted((report.get("rules") or {}).items()):
        for w in warns:
            _report_row(
                "rule",
                {
                    "id": rid,
                    "key": w.get("key"),
                    "config": w.get("config"),
                    "system": w.get("system"),
                    "msg": w.get("msg"),
                },
            )
    for e in report.get("extra") or []:
        _report_row("extra", {"uuid": e.get("uuid"), "loc": f"{e.get('family')}/{e.get('table')}/{e.get('chain')}",
                              "handle": e.get("handle")})
    for f in report.get("finrst") or []:
        _report_row("finrst", {"issue": f.get("issue"), "rule_id": f.get("rule_id"), "chain": f.get("chain")})
    for c in report.get("companions") or []:
        _report_row(
            "companion",
            {"issue": c.get("issue"), "rule_id": c.get("rule_id"), "ref": c.get("ref"),
             "config": c.get("config"), "system": c.get("system"), "msg": c.get("msg")},
        )
    for chain, seqs in (report.get("order") or {}).items():
        print(f"    order drift {chain}: datastore={seqs.get('config')} kernel={seqs.get('system')}")

    if not s["ok"]:
        raise AssertionError("firewall consistency check found issues (or could not verify every chain)")
    print("  OK   firewall state is consistent")


def main():
    parser = build_parser("Check firewall consistency via get_firewall_consistency (read-only)")
    args = parser.parse_args()
    client = build_client(args)
    try:
        run(client)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
