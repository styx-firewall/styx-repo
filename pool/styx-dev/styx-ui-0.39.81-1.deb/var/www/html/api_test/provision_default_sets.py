#!/usr/bin/env python3
"""Provision default sets from the default-sets catalog via the HTTP API.

api_test equivalent of the gateway's ``tools/seed_default_sets.py``. Seeds
address, port, domain and label sets from ``files/default_sets.json``, plus
interface sets (``all_physical`` / ``all_virtual`` / ``if_<name>``) collected
from the target machine.

Runs against a live gateway (``/request.php`` + ``/submit.php``) — no gateway
stop needed. Creating/updating writes to running-config only; pass ``--save``
for a final ``save_config`` persisting to startup-config (the seed's
``--commit`` equivalent).

Differences vs ``tools/seed_default_sets.py``:
  - Runs remotely via the HTTP API instead of reading/writing the datastore
    files with the gateway stopped.
  - Interface sets are classified from the OS interface list
    (``network-config.get_interfaces_names``) by name pattern only; the seed
    additionally requires a sysfs device entry for physical interfaces, so the
    classification here is a close approximation, not identical.

Usage:
    python api_test/provision_default_sets.py                       # apply, running-config only
    python api_test/provision_default_sets.py --save                # apply + save_config
    python api_test/provision_default_sets.py --dry-run             # preview (no changes)
    python api_test/provision_default_sets.py --update --dry-run    # preview updates too
    python api_test/provision_default_sets.py --skip-interfaces     # only catalog sets
"""

import argparse
import json
import re
import sys

from api_client import ApiError, get
from verify_common import build_client

# Same catalog the gateway's seed tool uses (GW_ROOT_DIR/files/default_sets.json).
DEFAULT_CATALOG = "/opt/styx-gateway/files/default_sets.json"

# Interface name patterns considered virtual, mirroring
# utils/interfaces_collector.py's _VIRTUAL_NAME_RE.
_VIRTUAL_RE = re.compile(
    r"^(lo|vir|veth|docker|br|bond|team|vlan|vxlan|macvlan|" r"ipvlan|tun|tap|kube|dummy|wg|gre|sit|erspan|geneve|ifb)"
)

# Catalog-only field stripped from every payload before it reaches the backend.
# Labels additionally carry a `comment` field that the backend stores, so it is
# deliberately kept.
_STRIP_FIELDS = {"description"}

# Catalog section -> HTTP API mapping.
SECTIONS = [
    {"name": "address", "cmd": "set_address", "get_action": "get_address", "list_key": "address"},
    {"name": "port", "cmd": "set_port", "get_action": "get_ports", "list_key": "ports"},
    {"name": "domain", "cmd": "set_domain", "get_action": "get_domains", "list_key": "domain"},
    # set_label is a write command exposed under a namespaced submit command.
    {"name": "label", "cmd": "sets-mgmt.set_label", "get_action": "get_labels", "list_key": "labels"},
]


def load_catalog(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def fetch_existing(client, action: str, list_key: str, label: str) -> list:
    """Return the current entities for one set kind, or raise."""
    resp = client.request(action)
    items = get(resp, f"result.{list_key}")
    if get(resp, "status") != "success" or items is None:
        raise AssertionError(f"{action} failed: {resp}")
    print(f"  INFO {label}: {len(items)} existing set(s)")
    return items


def build_payload(entry: dict, existing_entry: dict | None, is_label: bool) -> dict:
    """Map a catalog entry to the HTTP payload for its set command.

    Drops catalog-only fields; when updating an existing entry the backend is
    told to reuse its id so the set is updated in place (refs preserved)
    instead of duplicated. Labels are matched by the backend on name+type, so
    they never need the id.
    """
    payload = {k: v for k, v in entry.items() if k not in _STRIP_FIELDS}
    if existing_entry is not None and not is_label and existing_entry.get("id"):
        payload["id"] = existing_entry["id"]
    return payload


def seed_section(client, sec: dict, entries: list, update: bool, dry_run: bool) -> dict:
    """Seed one catalog section; returns {ok, skip, fail} counts."""
    stats = {"ok": 0, "skip": 0, "fail": 0}
    name, cmd, get_action, list_key = sec["name"], sec["cmd"], sec["get_action"], sec["list_key"]
    try:
        existing = fetch_existing(client, get_action, list_key, name)
    except (ApiError, AssertionError) as e:
        # Without the current state we cannot safely decide create-vs-update.
        stats["fail"] = len(entries) if entries else 1
        print(f"  FAIL {name}: cannot list existing sets ({e})")
        return stats

    for entry in entries:
        ename = entry.get("name")
        if not ename:
            stats["fail"] += 1
            print(f"  FAIL {name}: catalog entry missing 'name'")
            continue
        existing_entry = next((e for e in existing if e.get("name") == ename), None)
        if existing_entry is not None:
            if not update:
                stats["skip"] += 1
                print(f"  SKIP {name} {ename!r} already exists")
                continue
        payload = build_payload(entry, existing_entry, is_label=(name == "label"))
        try:
            resp = client.submit(cmd, payload, dry_run=dry_run)
            if get(resp, "status") != "success":
                raise AssertionError(get(resp, "response_msg"))
        except (ApiError, AssertionError) as e:
            stats["fail"] += 1
            print(f"  FAIL {name} {ename!r}: {e}")
            continue
        stats["ok"] += 1
        verb = "would create" if dry_run else ("update" if existing_entry is not None else "create")
        print(f"  OK   {name} {ename!r} ({verb})")
    return stats


def build_interface_entries(names: list) -> list:
    """Build all_physical / all_virtual / if_<name> set entries from OS names."""
    phys = [n for n in names if n and not _VIRTUAL_RE.match(n)]
    virt = [n for n in names if n and _VIRTUAL_RE.match(n)]
    entries = []
    if phys:
        entries.append({"name": "all_physical", "type": "set", "value_set": phys})
    if virt:
        entries.append({"name": "all_virtual", "type": "set", "value_set": virt})
    for n in phys + virt:
        entries.append({"name": f"if_{n}", "type": "single", "value_single": n})
    return entries


def seed_interfaces(client, dry_run: bool) -> dict:
    """Seed interface sets from the machine's OS interfaces; returns stats."""
    stats = {"ok": 0, "skip": 0, "fail": 0}
    try:
        resp = client.request("get_interfaces_names_sets")
        names = get(resp, "result.ifaces_names")
        if get(resp, "status") != "success" or names is None:
            raise AssertionError(f"get_interfaces_names_sets failed: {resp}")
        existing = fetch_existing(client, "get_interfaces_sets", "interfaces", "interface-set")
    except (ApiError, AssertionError) as e:
        stats["fail"] = 1
        print(f"  FAIL interfaces: cannot collect interface sets ({e})")
        return stats
    print(f"  INFO interfaces: {len(names)} OS interface(s) detected")
    for entry in build_interface_entries(names):
        ename = entry["name"]
        if any(e.get("name") == ename for e in existing):
            stats["skip"] += 1
            print(f"  SKIP interface-set {ename!r} already exists")
            continue
        try:
            resp = client.submit("set_interface_set", entry, dry_run=dry_run)
            if get(resp, "status") != "success":
                raise AssertionError(get(resp, "response_msg"))
        except (ApiError, AssertionError) as e:
            stats["fail"] += 1
            print(f"  FAIL interface-set {ename!r}: {e}")
            continue
        stats["ok"] += 1
        verb = "would create" if dry_run else "create"
        print(f"  OK   interface-set {ename!r} ({verb})")
    return stats


def deploy(client, catalog: dict, update: bool, skip_interfaces: bool, dry_run: bool) -> dict:
    """Seed every catalog section (and optionally interface sets)."""
    summary = {
        sec["name"]: seed_section(client, sec, catalog.get(sec["name"], []), update, dry_run) for sec in SECTIONS
    }
    if not skip_interfaces:
        summary["interfaces"] = seed_interfaces(client, dry_run)
    return summary


def print_summary(summary: dict) -> int:
    """Print per-section counts and return the number of failed entries."""
    total_fail = 0
    print("\nSummary:")
    for kind, stats in summary.items():
        parts = [f"ok={stats['ok']}"]
        if stats["skip"]:
            parts.append(f"skipped={stats['skip']}")
        parts.append(f"fail={stats['fail']}")
        total_fail += stats["fail"]
        print(f" - {kind}: " + " ".join(parts))
    return total_fail


def main():
    p = argparse.ArgumentParser(description="Provision default sets via the HTTP API (api_test)")
    p.add_argument("--config", default=None, help="Path to api config.json (default: api_test/config.json)")
    p.add_argument("--catalog", default=DEFAULT_CATALOG, help=f"Catalog JSON to seed (default: {DEFAULT_CATALOG})")
    p.add_argument("--dry-run", action="store_true", help="Validate every change without applying it")
    p.add_argument("--update", action="store_true", help="Update sets whose name already exists (default: skip them)")
    p.add_argument("--skip-interfaces", action="store_true", help="Do not seed interface sets")
    p.add_argument(
        "--save",
        action="store_true",
        help="Persist to startup-config (save_config) after seeding (default: running-config only)",
    )
    args = p.parse_args()

    try:
        catalog = load_catalog(args.catalog)
    except OSError as exc:
        print(f"ERROR: cannot read catalog {args.catalog}: {exc}")
        return 2

    client = build_client(args)
    mode = "dry-run (no changes applied)" if args.dry_run else "live (changes applied)"
    print(f"Catalog: {args.catalog}")
    print(f"Mode:    {mode}")
    print(f"Existing sets: {'update in place' if args.update else 'skip'}")
    if not args.dry_run and args.save:
        print("Persist: save_config (running-config -> startup-config) after seeding")
    else:
        print("Persist: none (running-config only; use --save to persist)")
    if args.skip_interfaces:
        print("Interfaces: skipped")

    summary = deploy(client, catalog, update=args.update, skip_interfaces=args.skip_interfaces, dry_run=args.dry_run)
    fails = print_summary(summary)

    if fails:
        print("\nSome entries failed; see FAIL lines above.")
        return 1
    if not args.dry_run and args.save:
        resp = client.submit("save_config")
        if get(resp, "status") != "success":
            print(f"\nWARN: seeding succeeded but save_config failed: {resp}")
        else:
            print("\nConfiguration saved to startup-config.")
    print("\nDone.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
