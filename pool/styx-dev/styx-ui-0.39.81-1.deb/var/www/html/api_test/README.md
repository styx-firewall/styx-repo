# Styx API tooling

Python tooling para interactuar con la API HTTP de una máquina Styx
(`/request.php` + `/submit.php`) contra una máquina objetivo real. Sustituye al
antiguo runner declarativo basado en payloads JSON.

Tres usos en un mismo conjunto de scripts:

1. **Probing** — explorar la API y encadenar verificaciones ad-hoc.
2. **Verificación / regresión** — flujos completos (crear → verificar → borrar).
3. **Provisioning / despliegue** — configurar una máquina con una configuración concreta.

## Requisitos

- `python3` (solo stdlib, sin dependencias externas: no `requests`, no `jmespath`, no `curl`).
- `api_test/config.json` (gitignored) con la máquina objetivo:

```json
{
  "base_url": "https://IP_MAQUINA",
  "bearer_token": "tk_live_...",
  "timeout": 10,
  "verify_tls": false
}
```

Copia `config.example.json` → `config.json` y rellénalo. El token se valida en el
backend; mantén `config.json` fuera del control de versiones (ya está en `.gitignore`).

## Archivos

| Archivo | Función |
|---|---|
| `api_client.py` | Cliente común de la API (stdlib). Espejo de `scripts/core/api-client.js`. |
| `verify_common.py` | Pequeños helpers compartidos por los scripts `verify_*` (argparse, cliente, cleanup). |
| `probe.py` | Probing genérico: cualquier action/command con pretty-print. |
| `verify_readonly.py` | Smoke checks read-only de `/request.php`. |
| `verify_sets.py` | Lifecycle de sets (ports/addresses/domains/interface-sets) con la matriz de tipos. |
| `verify_tc.py` | Lifecycle de Traffic Control (qdisc/class/rule en if0 e if1). |
| `verify_packet_marking.py` | Lifecycle de Packet Marking + casos de validación dry-run. |
| `verify_virtual_interfaces.py` | Lifecycle de interfaces virtuales (todos los subtipos). |
| `verify_orphan_refs.py` | Health check de `cleanup_orphan_refs` (reporte por defecto; `--apply` purga running-config; `--commit` purga + `save_config`). |
| `verify_cert_metadata.py` | Health check de `refresh_cert_metadata` (preview por defecto; `--apply`/`--force`). |
| `provision_example.py` | Plantilla idempotente para scripts de provisioning/despliegue. |
| `provision_default_sets.py` | Siembra los sets por defecto (equivalente HTTP de `tools/seed_default_sets.py`). |

## Uso rápido

```bash
# Smoke checks read-only (no modifica nada)
python api_test/verify_readonly.py

# Flujos lifecycle completos (crean y borran; dejan el estado limpio)
python api_test/verify_sets.py
python api_test/verify_tc.py
python api_test/verify_packet_marking.py
python api_test/verify_virtual_interfaces.py

# Probing interactivo
python api_test/probe.py --action get_interfaces_sets
python api_test/probe.py --command set_port --dry-run --name p1 --type single --value_single 8080

# Provisioning (preview sin aplicar, luego aplicar)
python api_test/provision_example.py --dry-run
python api_test/provision_example.py

# Seed de sets por defecto (catálogo files/default_sets.json)
python api_test/provision_default_sets.py --dry-run             # preview (no aplica nada)
python api_test/provision_default_sets.py                       # aplicar (running-config)
python api_test/provision_default_sets.py --save                # aplicar + persistir a startup-config
python api_test/provision_default_sets.py --update --dry-run    # preview incl. updates

# Cleanup de refs huérfanos (report-only; --apply purga running-config sin persistir; --commit purga + save_config)
python api_test/verify_orphan_refs.py
python api_test/verify_orphan_refs.py --apply
python api_test/verify_orphan_refs.py --commit

# Refresh de metadata parseada de certificados (preview; --apply para aplicar)
python api_test/verify_cert_metadata.py
python api_test/verify_cert_metadata.py --apply --force
```

## Dry-run

La API soporta una bandera `"dry-run": true` en los comandos de `/submit.php`
(ver `handlers/handler_client.py` del gateway): el backend **valida** el comando
(schema/lógica) pero **no aplica** el cambio real; responde `status: success` con
una traza `debug` y `response_msg` prefijada con `"dry-run: "`. No todos los
comandos la soportan.

En el cliente: `client.submit(command, data, dry_run=True)` o `client.preview(command, data)`.
Cada script decide por llamada si quiere preview o cambio real — no hay un "modo"
global.

## El cliente común (`api_client.py`)

```python
from api_client import load_config, ApiClient, require_ok, dump

cfg = load_config()                       # api_test/config.json
api = ApiClient(cfg["base_url"], cfg.get("bearer_token", ""),
                verify_tls=cfg.get("verify_tls", False),
                timeout=cfg.get("timeout", 10))

resp = api.request("get_interfaces_sets")      # POST /request.php
require_ok(resp, "result.interfaces")          # lanza AssertionError si falla

created = api.submit("set_port", {"name": "p1", "type": "single", "value_single": 443})
preview = api.preview("set_port", {...})       # dry-run
dump(resp)                                     # pretty-print
```

Errores de red/timeout/HTTP no-200 lanzan `ApiError`; una respuesta con
`status != 'success'` (o sin las claves pedidas) hace fallar `require_ok`.

## Escribir scripts de provisioning

Copia `provision_example.py` por perfil (p. ej. `provision_office.py`) y rellena
`deploy()`. Patrón recomendado:

1. Consulta `get_*` para ver qué existe.
2. Crea solo lo que falta (idempotente).
3. Pasa `--dry-run` para validar el despliegue completo antes de aplicarlo.

## Notas

- Los scripts `verify_*` se ejecutan contra `config.json`; deben terminar con `0` y sin dejar recursos residuales (los borrados están dentro del propio script).
- Opcionalmente se puede borrar `api_test/.venv` (ya no se usa ninguna dependencia).
- Para one-liners rápidos de solo lectura, bash + `curl | jq` sigue siendo una alternativa válida; esta herramienta no lo reemplaza.
