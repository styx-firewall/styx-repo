#!/usr/bin/env python3
"""Verification for the allowed-label-types endpoint and backend type validation.

Checks that `get_allowed_labels` returns exactly the 15 supported label types
and that `set_label` with an unknown type is rejected by the backend (the PHP
frontend no longer keeps its own copy of the allowed list).

Usage:
    python api_test/verify_labels.py [--config path/to/config.json]
"""

from api_client import ApiError, require_ok
from verify_common import build_parser, build_client, finish

EXPECTED = {
    "vlans",
    "packet_marking",
    "routing_tables",
    "route_tag",
    "community",
    "as_path_regex",
    "as_path_prepend",
    "as_number",
    "router_id",
    "cluster_id",
    "ospf_area",
    "vni",
    "gre_ikey",
    "gre_okey",
    "xfrm_if_id",
}


def run(client):
    resp = require_ok(client.request("get_allowed_labels"), "result.label_types")
    got = set(resp["result"]["label_types"])
    if got != EXPECTED:
        missing = sorted(EXPECTED - got)
        extra = sorted(got - EXPECTED)
        raise AssertionError(f"label_types mismatch: missing={missing} extra={extra}")
    print("  OK   get_allowed_labels returns all 15 types")

    # Invalid type is rejected by the backend (proves the PHP whitelist is gone).
    bad = client.preview("sets-mgmt.set_label", {"type": "bogus_type", "name": "vt-x", "value": "1"})
    if bad.get("status") == "success":
        raise AssertionError("set_label with invalid type unexpectedly succeeded")
    if "Invalid type" not in (bad.get("response_msg") or ""):
        raise AssertionError(f"expected backend Invalid type error, got: {bad.get('response_msg')}")
    print("  OK   set_label rejects invalid type via backend")


def main():
    args = build_parser("Verify allowed label types").parse_args()
    client = build_client(args)
    try:
        run(client)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
