#!/usr/bin/env python3
"""Generic API probing: run any action or command and pretty-print the response.

For interactive exploration and ad-hoc verification against a live target.
Combined with the client's dry-run flag it lets you validate a write command
without applying it.

Usage:
    python api_test/probe.py --action get_interfaces_sets
    python api_test/probe.py --action get_pm_rules --data-json '{"limit": 5}'
    python api_test/probe.py --command set_port --dry-run --name my-port --type single --value_single 8080
    python api_test/probe.py --command get_system_logs --data-json '{"lines": 10}'
"""

import argparse
import json
import sys

from api_client import ApiError, dump
from verify_common import build_client


def parse_kv(pairs):
    """Turn ['a=1', 'b=2'] into {'a': '1', 'b': '2'} (values stay strings)."""
    data = {}
    for pair in pairs:
        if "=" not in pair:
            raise ValueError(f"expected key=value, got {pair!r}")
        key, value = pair.split("=", 1)
        data[key] = value
    return data


def main():
    p = argparse.ArgumentParser(description="Generic Styx API probe (pretty-print responses)")
    p.add_argument("--config", default=None, help="Path to config.json")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--action", default=None, help="request.php action (read)")
    g.add_argument("--command", default=None, help="submit.php command (write)")
    p.add_argument("--data-json", default=None, help="Payload as a JSON string, e.g. '{\"limit\": 5}'")
    p.add_argument(
        "--dry-run", action="store_true", help="(submit only) inject dry-run:true — validate without applying"
    )
    p.add_argument("kv", nargs="*", metavar="KEY=VALUE", help="Extra payload keys, merged over --data-json")
    args = p.parse_args()

    client = build_client(args)

    data = json.loads(args.data_json) if args.data_json else {}
    data.update(parse_kv(args.kv))

    try:
        if args.action:
            resp = client.request(args.action, data)
        else:
            resp = client.submit(args.command, data, dry_run=args.dry_run)
        dump(resp)
    except (ApiError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
