#!/usr/bin/env python3
"""Lifecycle verification for the sets module (ports, addresses, domains, interface-sets).

Creates each supported *type variant* for real (single / range / set / mixed),
verifies the object shows up in the corresponding get_* response, then deletes
it. Leaves no residual state.

Replaces the old payloads/submit/sets.json tests (selective: the simple
single-type creates are dropped because more complex flows already exercise
them; the type matrix is kept because each variant exercises a different
validation path).

Usage:
    python api_test/verify_sets.py [--config path/to/config.json]
"""

import secrets

from api_client import ApiError, require_ok
from verify_common import build_parser, build_client, cleanup, finish

# (label, submit_command, create_data, delete_command, get_action, get_list_key)
# Ports -----------------------------------------------------------------
CASES = [
    ("port.single", "set_port", {"type": "single", "value_single": 9997}, "delete_port", "get_ports", "ports"),
    (
        "port.range",
        "set_port",
        {"type": "range", "value_range_start": 8000, "value_range_end": 8080},
        "delete_port",
        "get_ports",
        "ports",
    ),
    (
        "port.set",
        "set_port",
        {"type": "set", "value_set": [80, "443", "10000-10010"]},
        "delete_port",
        "get_ports",
        "ports",
    ),
    ("port.mixed", "set_port", {"type": "set", "value_set": [22, "80-90", 10000]}, "delete_port", "get_ports", "ports"),
    # Addresses ----------------------------------------------------------
    (
        "address.single",
        "set_address",
        {"type": "single", "family": "ip", "value_single": "10.99.99.77"},
        "delete_address",
        "get_address",
        "address",
    ),
    (
        "address.set",
        "set_address",
        {"type": "set", "family": "ip", "value_set": ["10.0.0.0/8", "198.51.100.0/24"]},
        "delete_address",
        "get_address",
        "address",
    ),
    (
        "address.range",
        "set_address",
        {"type": "range", "family": "ip", "value_range_start": "10.0.0.1", "value_range_end": "10.0.0.10"},
        "delete_address",
        "get_address",
        "address",
    ),
    (
        "address.mixed",
        "set_address",
        {"type": "set", "family": "ip", "value_set": ["10.0.0.1", "192.0.2.0/24", "203.0.113.5-203.0.113.10"]},
        "delete_address",
        "get_address",
        "address",
    ),
    # Interface sets ------------------------------------------------------
    (
        "iface_set.single",
        "set_interface_set",
        {"type": "single", "value_single": "lo"},
        "delete_interface_set",
        "get_interfaces_sets",
        "interfaces",
    ),
    (
        "iface_set.set",
        "set_interface_set",
        {"type": "set", "value_set": ["lo", "eth0"]},
        "delete_interface_set",
        "get_interfaces_sets",
        "interfaces",
    ),
    # Domains -------------------------------------------------------------
    (
        "domain.single",
        "set_domain",
        {"type": "single", "value_single": "example.com"},
        "delete_domain",
        "get_domains",
        "domain",
    ),
    (
        "domain.set",
        "set_domain",
        {"type": "set", "value_set": ["example.com", "example.org", "example.net"]},
        "delete_domain",
        "get_domains",
        "domain",
    ),
]


def run(client):
    created = []  # (delete_command, {"id": rid}) — cleanup in reverse order
    suffix = secrets.token_hex(4)

    def create(label, cmd, data, delete_cmd):
        data = dict(data, name=f"vt-{label.replace('.', '-')}-{suffix}")
        resp = require_ok(client.submit(cmd, data), "result.id")
        rid = resp["result"]["id"]
        created.append((delete_cmd, {"id": rid}))
        print(f"  OK   {label} (id={rid})")
        return rid

    def visible(label, action, list_key, rid):
        resp = require_ok(client.request(action), "result." + list_key)
        items = resp["result"].get(list_key) or []
        if not any(item.get("id") == rid for item in items):
            raise AssertionError(f"{label}: id {rid} not found in {action} result.{list_key}")
        print(f"  OK   {label} visible in {action}")

    try:
        for label, cmd, data, del_cmd, get_action, list_key in CASES:
            rid = create(label, cmd, data, del_cmd)
            visible(label, get_action, list_key, rid)
    finally:
        cleanup(client, created)


def main():
    args = build_parser("Verify sets module: create/verify/delete for every type variant").parse_args()
    client = build_client(args)
    try:
        run(client)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
