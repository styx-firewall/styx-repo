# exec_audit/exec_audit_companion.py
#
# Mirrors the two maps of exec_audit: the per-CPU counters and the exec event.

import ctypes

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import aggregate_percpu, ktime_to_epoch

TASK_COMM_LEN = 16
FILENAME_LEN = 128


@register_deserializer("exec_audit", "stats")
class StatsDeserializer(FeedbackDeserializer):
    """Executions seen and ring drops, summed across CPUs."""

    def from_map(self, raw, spec, key=None) -> dict:
        totals = aggregate_percpu(raw, ["execs", "ring_drops"], ["<Q", "Q"])
        return {"execs": totals["execs"], "ring_drops": totals["ring_drops"]}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")


@register_deserializer("exec_audit", "events")
class EventDeserializer(FeedbackDeserializer):
    """One execve() call, as the syscall tracepoint saw it."""

    class _Struct(ctypes.Structure):
        _pack_ = 1
        _fields_ = [
            ("ts_ns", ctypes.c_uint64),
            ("pid", ctypes.c_uint32),
            ("tgid", ctypes.c_uint32),
            ("ppid", ctypes.c_uint32),
            ("uid", ctypes.c_uint32),
            ("gid", ctypes.c_uint32),
            ("comm", ctypes.c_uint8 * TASK_COMM_LEN),
            ("filename", ctypes.c_uint8 * FILENAME_LEN),
        ]

    def from_map(self, raw, spec, key=None) -> dict:
        raise NotImplementedError("events is an event buffer, not a telemetry map")

    def from_event(self, data: bytes, size: int, spec) -> dict:
        ev = self._Struct.from_buffer_copy(bytes(data[: ctypes.sizeof(self._Struct)]))
        comm = bytes(ev.comm).split(b"\x00", 1)[0].decode(errors="replace")
        filename = bytes(ev.filename).split(b"\x00", 1)[0].decode(errors="replace")
        return {
            "ts": ktime_to_epoch(ev.ts_ns),
            "pid": ev.pid,
            "tgid": ev.tgid,
            "ppid": ev.ppid,
            "uid": ev.uid,
            "gid": ev.gid,
            "comm": comm,
            "filename": filename,
            "summary": f"{comm} ({ev.pid}) exec {filename}",
        }
