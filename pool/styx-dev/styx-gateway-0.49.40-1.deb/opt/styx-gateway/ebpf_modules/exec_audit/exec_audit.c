// SPDX-License-Identifier: (LGPL-2.1 OR BSD-2-Clause)
// exec_audit.c - process execution events from the execve syscall.
//
// Ported from bcc/libbpf-tools/execsnoop.bpf.c, which is based on execsnoop from
// BCC by Brendan Gregg and others. The original header carries no copyright line;
// see NOTICE in this directory.
//
// It records what ran and who ran it. It does not decide anything about the
// process: the syscall tracepoint cannot change the syscall's result.

#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_core_read.h>
#include <bpf/bpf_tracing.h>

#define TASK_COMM_LEN 16
#define FILENAME_LEN  128

// Must match exec_audit_companion.py EventDeserializer._Struct
struct event_t {
    __u64 ts_ns;
    __u32 pid;
    __u32 tgid;
    __u32 ppid;
    __u32 uid;
    __u32 gid;
    __u8  comm[TASK_COMM_LEN];
    __u8  filename[FILENAME_LEN];
} __attribute__((packed));

struct stats_t {
    __u64 execs;
    __u64 ring_drops;
};

// Telemetry: executions seen and events lost to a full ring.
struct {
    __uint(type,        BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key,         __u32);
    __type(value,       struct stats_t);
} stats SEC(".maps");

// Event: one entry per execve().
struct {
    __uint(type,        BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);
} events SEC(".maps");

SEC("tracepoint/syscalls/sys_enter_execve")
int handle_execve(struct trace_event_raw_sys_enter *ctx)
{
    __u32 zero = 0;
    struct stats_t *st = bpf_map_lookup_elem(&stats, &zero);

    if (st)
        __sync_fetch_and_add(&st->execs, 1);

    struct event_t ev = {};
    __u64 id = bpf_get_current_pid_tgid();
    __u64 uid_gid = bpf_get_current_uid_gid();
    struct task_struct *task = (struct task_struct *)bpf_get_current_task();

    ev.ts_ns = bpf_ktime_get_ns();
    ev.pid = (__u32)id;
    ev.tgid = (__u32)(id >> 32);
    ev.uid = (__u32)uid_gid;
    ev.gid = (__u32)(uid_gid >> 32);
    ev.ppid = BPF_CORE_READ(task, real_parent, tgid);
    bpf_get_current_comm(&ev.comm, sizeof(ev.comm));
    bpf_probe_read_user_str(&ev.filename, sizeof(ev.filename), (const void *)ctx->args[0]);

    struct event_t *out = bpf_ringbuf_reserve(&events, sizeof(*out), 0);
    if (!out) {
        if (st)
            __sync_fetch_and_add(&st->ring_drops, 1);
        return 0;
    }
    __builtin_memcpy(out, &ev, sizeof(ev));
    bpf_ringbuf_submit(out, 0);
    return 0;
}

char LICENSE[] SEC("license") = "GPL";
