// SPDX-License-Identifier: GPL-2.0
// tcp_connect.c - outbound IPv4 TCP connect attempts.
//
// Ported from bcc/libbpf-tools/tcpconnect.bpf.c
// Copyright (c) 2020 Anton Protopopov
// Based on tcpconnect(8) from BCC by Brendan Gregg
//
// This port watches the entry only: it records the destination the caller asked
// for, not whether the connect succeeded. The return code needs a kretprobe, a
// hook the framework does not expose yet.

#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_core_read.h>
#include <bpf/bpf_tracing.h>
#include <bpf/bpf_endian.h>

#ifndef AF_INET
#define AF_INET 2
#endif

#define TASK_COMM_LEN 16

// Must match tcp_connect_companion.py EventDeserializer._Struct
struct event_t {
    __u64 ts_ns;
    __u32 pid;
    __u32 tgid;
    __u32 uid;
    __u32 daddr;  // network byte order, as the packet carries it
    __u16 dport;  // host byte order
    __u8  comm[TASK_COMM_LEN];
} __attribute__((packed));

struct stats_t {
    __u64 connects;
    __u64 ring_drops;
};

// Telemetry: attempts seen and events lost to a full ring.
struct {
    __uint(type,        BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key,         __u32);
    __type(value,       struct stats_t);
} stats SEC(".maps");

// Event: one entry per connect() attempt.
struct {
    __uint(type,        BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);
} events SEC(".maps");

// tcp_v4_connect(struct sock *sk, struct sockaddr *uaddr, int addr_len)
SEC("kprobe/tcp_v4_connect")
int BPF_KPROBE(handle_tcp_v4_connect, struct sock *sk, struct sockaddr *uaddr, int addr_len)
{
    struct sockaddr_in sa = {};

    // The address is a kernel copy made by move_addr_to_kernel() before connect().
    if (bpf_probe_read_kernel(&sa, sizeof(sa), uaddr) != 0)
        return 0;
    if (sa.sin_family != AF_INET)
        return 0;

    __u32 zero = 0;
    struct stats_t *st = bpf_map_lookup_elem(&stats, &zero);
    if (st)
        __sync_fetch_and_add(&st->connects, 1);

    struct event_t ev = {};
    __u64 id = bpf_get_current_pid_tgid();
    __u64 uid_gid = bpf_get_current_uid_gid();

    ev.ts_ns = bpf_ktime_get_ns();
    ev.pid = (__u32)id;
    ev.tgid = (__u32)(id >> 32);
    ev.uid = (__u32)uid_gid;
    ev.daddr = sa.sin_addr.s_addr;
    ev.dport = bpf_ntohs(sa.sin_port);
    bpf_get_current_comm(&ev.comm, sizeof(ev.comm));

    struct event_t *out = bpf_ringbuf_reserve(&events, sizeof(*out), 0);
    if (!out) {
        if (st)
            __sync_fetch_and_add(&st->ring_drops, 1);
        return 0;
    }
    __builtin_memcpy(out, &ev, sizeof(ev));
    bpf_ringbuf_submit(out, 0);
    return 0;
}

char LICENSE[] SEC("license") = "GPL";
