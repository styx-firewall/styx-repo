# tcp_connect/tcp_connect_companion.py
#
# Mirrors the two maps of tcp_connect: the per-CPU counters and the connect event.

import ctypes

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import aggregate_percpu, ktime_to_epoch, u32_to_ip

TASK_COMM_LEN = 16


@register_deserializer("tcp_connect", "stats")
class StatsDeserializer(FeedbackDeserializer):
    """Connect attempts seen and ring drops, summed across CPUs."""

    def from_map(self, raw, spec, key=None) -> dict:
        totals = aggregate_percpu(raw, ["connects", "ring_drops"], ["<Q", "Q"])
        return {"connects": totals["connects"], "ring_drops": totals["ring_drops"]}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")


@register_deserializer("tcp_connect", "events")
class EventDeserializer(FeedbackDeserializer):
    """One outbound connect() attempt, as tcp_v4_connect saw it on entry."""

    class _Struct(ctypes.Structure):
        _pack_ = 1
        _fields_ = [
            ("ts_ns", ctypes.c_uint64),
            ("pid", ctypes.c_uint32),
            ("tgid", ctypes.c_uint32),
            ("uid", ctypes.c_uint32),
            ("daddr", ctypes.c_uint32),
            ("dport", ctypes.c_uint16),
            ("comm", ctypes.c_uint8 * TASK_COMM_LEN),
        ]

    def from_map(self, raw, spec, key=None) -> dict:
        raise NotImplementedError("events is an event buffer, not a telemetry map")

    def from_event(self, data: bytes, size: int, spec) -> dict:
        ev = self._Struct.from_buffer_copy(bytes(data[: ctypes.sizeof(self._Struct)]))
        comm = bytes(ev.comm).split(b"\x00", 1)[0].decode(errors="replace")
        dst = u32_to_ip(ev.daddr)
        return {
            "ts": ktime_to_epoch(ev.ts_ns),
            "pid": ev.pid,
            "tgid": ev.tgid,
            "uid": ev.uid,
            "dst_ip": dst,
            "dst_port": ev.dport,
            "comm": comm,
            "summary": f"{comm} ({ev.pid}) connect {dst}:{ev.dport}",
        }
