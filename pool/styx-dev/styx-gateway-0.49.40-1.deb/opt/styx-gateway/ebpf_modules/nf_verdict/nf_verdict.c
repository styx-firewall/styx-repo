// SPDX-License-Identifier: MIT
// nf_verdict.c - netfilter verdict and drop monitor.
//
// Ported from microsoft/retina pkg/plugin/dropreason/_cprog/drop_reason.c
// (the fexit/nf_hook_slow part), Copyright (c) Microsoft Corporation.
// Licensed under the MIT license; see NOTICE in this directory.
//
// nf_hook_slow() returns 1 when the packet is accepted, a negative errno when
// it is dropped or stolen, and other values for the queue path. The fexit sees
// the same skb and state the entry saw plus that return value, so one program
// can count the verdict per hook and emit a drop event with the packet's
// addresses without a pid stash or a kretprobe.

#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_core_read.h>
#include <bpf/bpf_tracing.h>
#include <bpf/bpf_endian.h>

#define ETH_P_IP 0x0800
#define IPPROTO_TCP 6
#define IPPROTO_UDP 17

// Must match nf_verdict_companion.py EventDeserializer._Struct
struct event_t {
    __u64 ts_ns;
    __u32 skb_len;
    __s32 verdict;
    __u32 in_ifindex;
    __u32 out_ifindex;
    __u32 saddr;  // network byte order
    __u32 daddr;  // network byte order
    __u16 sport;  // host byte order
    __u16 dport;  // host byte order
    __u8  hook;
    __u8  pf;
    __u8  proto;
} __attribute__((packed));

struct stats_t {
    __u64 accepted;
    __u64 dropped;
    __u64 queued;
    __u64 ring_drops;
};

// Telemetry: one counter per verdict class.
struct {
    __uint(type,        BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key,         __u32);
    __type(value,       struct stats_t);
} verdicts SEC(".maps");

// Event: one entry per drop.
struct {
    __uint(type,        BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);
} drops SEC(".maps");

// int nf_hook_slow(struct sk_buff *skb, struct nf_hook_state *state,
//                  const struct nf_hook_entries *e, unsigned int s)
SEC("fexit/nf_hook_slow")
int BPF_PROG(nf_verdict, struct sk_buff *skb, struct nf_hook_state *state,
             const struct nf_hook_entries *e, unsigned int s, int ret)
{
    __u32 zero = 0;
    struct stats_t *st = bpf_map_lookup_elem(&verdicts, &zero);

    if (st) {
        if (ret < 0)
            __sync_fetch_and_add(&st->dropped, 1);
        else if (ret == 1)
            __sync_fetch_and_add(&st->accepted, 1);
        else
            __sync_fetch_and_add(&st->queued, 1);
    }

    // Only drops carry an event: accepted traffic is the counter above.
    if (ret >= 0)
        return 0;

    struct event_t ev = {};
    ev.ts_ns = bpf_ktime_get_ns();
    ev.verdict = ret;
    ev.skb_len = BPF_CORE_READ(skb, len);
    ev.hook = BPF_CORE_READ(state, hook);
    ev.pf = BPF_CORE_READ(state, pf);

    struct net_device *indev = BPF_CORE_READ(state, in);
    struct net_device *outdev = BPF_CORE_READ(state, out);
    if (indev)
        ev.in_ifindex = BPF_CORE_READ(indev, ifindex);
    if (outdev)
        ev.out_ifindex = BPF_CORE_READ(outdev, ifindex);

    if (BPF_CORE_READ(skb, protocol) == bpf_htons(ETH_P_IP)) {
        unsigned char *head = BPF_CORE_READ(skb, head);
        __u16 nhoff = BPF_CORE_READ(skb, network_header);
        __u16 thoff = BPF_CORE_READ(skb, transport_header);
        struct iphdr ip = {};

        if (bpf_probe_read_kernel(&ip, sizeof(ip), head + nhoff) == 0) {
            ev.saddr = ip.saddr;
            ev.daddr = ip.daddr;
            ev.proto = ip.protocol;
            if (ip.protocol == IPPROTO_TCP) {
                struct tcphdr th = {};
                if (bpf_probe_read_kernel(&th, sizeof(th), head + thoff) == 0) {
                    ev.sport = bpf_ntohs(th.source);
                    ev.dport = bpf_ntohs(th.dest);
                }
            } else if (ip.protocol == IPPROTO_UDP) {
                struct udphdr uh = {};
                if (bpf_probe_read_kernel(&uh, sizeof(uh), head + thoff) == 0) {
                    ev.sport = bpf_ntohs(uh.source);
                    ev.dport = bpf_ntohs(uh.dest);
                }
            }
        }
    }

    struct event_t *out = bpf_ringbuf_reserve(&drops, sizeof(*out), 0);
    if (!out) {
        if (st)
            __sync_fetch_and_add(&st->ring_drops, 1);
        return 0;
    }
    __builtin_memcpy(out, &ev, sizeof(ev));
    bpf_ringbuf_submit(out, 0);
    return 0;
}

char LICENSE[] SEC("license") = "GPL";
