# nf_verdict/nf_verdict_companion.py
#
# Mirrors the two maps of nf_verdict: the per-CPU verdict counters and the drop event.

import ctypes
import os

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import aggregate_percpu, ktime_to_epoch, u32_to_ip

# enum nf_inet_hooks
HOOK_NAMES = {
    0: "prerouting",
    1: "local_in",
    2: "forward",
    3: "local_out",
    4: "postrouting",
}

# NFPROTO_*
PF_NAMES = {
    1: "inet",
    2: "ipv4",
    3: "arp",
    5: "netdev",
    7: "bridge",
    10: "ipv6",
}

IPPROTO_TCP = 6
IPPROTO_UDP = 17


@register_deserializer("nf_verdict", "verdicts")
class StatsDeserializer(FeedbackDeserializer):
    """Verdict counters, summed across CPUs."""

    def from_map(self, raw, spec, key=None) -> dict:
        totals = aggregate_percpu(raw, ["accepted", "dropped", "queued", "ring_drops"], ["<Q", "Q", "Q", "Q"])
        return {
            "accepted": totals["accepted"],
            "dropped": totals["dropped"],
            "queued": totals["queued"],
            "ring_drops": totals["ring_drops"],
        }

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("verdicts is a telemetry map, not an event buffer")


@register_deserializer("nf_verdict", "drops")
class EventDeserializer(FeedbackDeserializer):
    """One dropped packet, as nf_hook_slow returned it."""

    class _Struct(ctypes.Structure):
        _pack_ = 1
        _fields_ = [
            ("ts_ns", ctypes.c_uint64),
            ("skb_len", ctypes.c_uint32),
            ("verdict", ctypes.c_int32),
            ("in_ifindex", ctypes.c_uint32),
            ("out_ifindex", ctypes.c_uint32),
            ("saddr", ctypes.c_uint32),
            ("daddr", ctypes.c_uint32),
            ("sport", ctypes.c_uint16),
            ("dport", ctypes.c_uint16),
            ("hook", ctypes.c_uint8),
            ("pf", ctypes.c_uint8),
            ("proto", ctypes.c_uint8),
        ]

    def from_map(self, raw, spec, key=None) -> dict:
        raise NotImplementedError("drops is an event buffer, not a telemetry map")

    def from_event(self, data: bytes, size: int, spec) -> dict:
        ev = self._Struct.from_buffer_copy(bytes(data[: ctypes.sizeof(self._Struct)]))
        hook = HOOK_NAMES.get(ev.hook, f"hook_{ev.hook}")
        pf = PF_NAMES.get(ev.pf, f"pf_{ev.pf}")
        verdict = os.strerror(-ev.verdict) if ev.verdict < 0 else f"verdict {ev.verdict}"

        src = u32_to_ip(ev.saddr) if ev.saddr else None
        dst = u32_to_ip(ev.daddr) if ev.daddr else None
        has_ports = ev.proto in (IPPROTO_TCP, IPPROTO_UDP)
        src_port = ev.sport if has_ports else None
        dst_port = ev.dport if has_ports else None

        if src and dst and has_ports:
            flow = f"{src}:{src_port} -> {dst}:{dst_port}"
        elif src and dst:
            flow = f"{src} -> {dst}"
        else:
            flow = f"{ev.skb_len} bytes"

        return {
            "ts": ktime_to_epoch(ev.ts_ns),
            "hook": hook,
            "pf": pf,
            "verdict": ev.verdict,
            "verdict_text": verdict,
            "skb_len": ev.skb_len,
            "in_ifindex": ev.in_ifindex,
            "out_ifindex": ev.out_ifindex,
            "src_ip": src,
            "dst_ip": dst,
            "src_port": src_port,
            "dst_port": dst_port,
            "proto": ev.proto,
            "summary": f"{hook}/{pf} {flow} dropped ({verdict})",
        }
