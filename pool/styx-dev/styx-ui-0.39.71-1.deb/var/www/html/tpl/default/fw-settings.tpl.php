<?php

/**
 * TemplateService->getTpl()
 *
 * Included: fw-settings.js
 *
 * @var array<mixed> $tdata
 */
// Firewall settings provided by PageFirewall (trusted, normalized by the backend)
$settings = $tdata['page_data']['settings'] ?? [];
// Same firewall:write capability used to create/edit rules
$can_edit = !empty($tdata['page_data']['can_create']);
$settings_error = $tdata['page_data']['settings_error'] ?? false;

// The backend always returns the full normalized settings object. A missing or
// incomplete object is treated as an error: no frontend defaults are
// substituted here, otherwise a backend default change would silently drift
// from the values shown in the UI.
$settings_valid = is_array($settings);
if ($settings_valid) {
    $cb = $settings['conntrack_bypass'] ?? null;
    $di = $settings['drop_invalid'] ?? null;
    $settings_valid = is_array($cb)
        && is_array($di)
        && is_bool($cb['input'] ?? null)
        && is_bool($cb['forward'] ?? null)
        && is_bool($di['input'] ?? null)
        && is_bool($di['forward'] ?? null)
        && is_int($settings['fw_logs_max'] ?? null)
        && is_int($settings['ct_logs_max'] ?? null);
}
if (!$settings_valid) {
    $settings_error = $settings_error ?: 'Firewall settings are missing or incomplete';
}

// Render OFF / empty (and disabled via $disabled_attr) when the data is invalid.
$cb_forward = $settings_valid ? $settings['conntrack_bypass']['forward'] : false;
$cb_input   = $settings_valid ? $settings['conntrack_bypass']['input'] : false;
$di_forward = $settings_valid ? $settings['drop_invalid']['forward'] : false;
$di_input   = $settings_valid ? $settings['drop_invalid']['input'] : false;
$fw_logs_max = $settings_valid ? $settings['fw_logs_max'] : '';
$ct_logs_max = $settings_valid ? $settings['ct_logs_max'] : '';

$disabled_attr = ($can_edit && !$settings_error) ? '' : 'disabled';
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Firewall Settings</h1>
        <div class="content-box fw-settings-box">
            <?php if ($settings_error): ?>
                <div class="std-error-box">
                    <strong>Error:</strong> could not load the firewall settings. Nothing was changed; the toggles are
                    disabled until the page is reloaded.
                    <?php if (is_string($settings_error)): ?>
                        <span class="fw-text-muted">(<?= htmlspecialchars($settings_error) ?>)</span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <p class="fw-settings-desc">
                Control which system firewall rules are created. Disabling a rule stops it from being applied to
                nftables for both IPv4 and IPv6 of the selected chain; the change takes effect immediately.
            </p>

            <div class="fw-settings-section">
                <h2 class="text-center">Conntrack bypass</h2>
                <div class="setting-row">
                    <div>
                        <strong>Conntrack bypass — Forward</strong>
                        <div class="fw-setting-hint">
                            Accept <code>ct state established,related</code> on the forward chain. Disable when
                            asymmetric routing / load balancing makes return traffic not match an existing connection.
                        </div>
                    </div>
                    <div class="setting-toggle">
                    <label class="std-switch">
                        <input type="checkbox"
                            class="fw-setting-toggle"
                            data-role="conntrack_bypass"
                            data-chain="forward"
                            <?= $cb_forward ? 'checked' : '' ?>
                            <?= $disabled_attr ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                    </div>
                </div>
                <div class="setting-row">
                    <div>
                        <strong>Conntrack bypass — Input</strong>
                        <div class="fw-setting-hint">
                            Accept <code>ct state established,related</code> on the input chain.
                        </div>
                    </div>
                    <div class="setting-toggle">
                    <label class="std-switch">
                        <input type="checkbox"
                            class="fw-setting-toggle"
                            data-role="conntrack_bypass"
                            data-chain="input"
                            <?= $cb_input ? 'checked' : '' ?>
                            <?= $disabled_attr ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                    </div>
                </div>
            </div>

            <div class="fw-settings-section">
                <h2 class="text-center">Log cache</h2>
                <div class="setting-row">
                    <div>
                        <strong>Firewall logs cache</strong>
                        <div class="fw-setting-hint">
                            Maximum number of firewall log entries kept in memory (default 4000).
                        </div>
                    </div>
                    <div class="setting-toggle">
                        <input type="number"
                            class="fw-setting-number"
                            data-setting-key="fw_logs_max"
                            value="<?= $fw_logs_max ?>"
                            min="1" max="100000" step="1"
                            <?= $disabled_attr ?>>
                    </div>
                </div>
                <div class="setting-row">
                    <div>
                        <strong>Conntrack logs cache</strong>
                        <div class="fw-setting-hint">
                            Maximum number of conntrack flow log entries kept in memory (default 2000).
                        </div>
                    </div>
                    <div class="setting-toggle">
                        <input type="number"
                            class="fw-setting-number"
                            data-setting-key="ct_logs_max"
                            value="<?= $ct_logs_max ?>"
                            min="1" max="100000" step="1"
                            <?= $disabled_attr ?>>
                    </div>
                </div>
            </div>

            <div class="fw-settings-section">
                <h2 class="text-center">Drop invalid</h2>
                <div class="setting-row">
                    <div>
                        <strong>Drop invalid — Forward</strong>
                        <div class="fw-setting-hint">
                            Drop <code>ct state invalid</code> on the forward chain. Disable when asymmetric routing
                            makes otherwise valid traffic appear invalid.
                        </div>
                    </div>
                    <div class="setting-toggle">
                    <label class="std-switch">
                        <input type="checkbox"
                            class="fw-setting-toggle"
                            data-role="drop_invalid"
                            data-chain="forward"
                            <?= $di_forward ? 'checked' : '' ?>
                            <?= $disabled_attr ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                    </div>
                </div>
                <div class="setting-row">
                    <div>
                        <strong>Drop invalid — Input</strong>
                        <div class="fw-setting-hint">
                            Drop <code>ct state invalid</code> on the input chain.
                        </div>
                    </div>
                    <div class="setting-toggle">
                    <label class="std-switch">
                        <input type="checkbox"
                            class="fw-setting-toggle"
                            data-role="drop_invalid"
                            data-chain="input"
                            <?= $di_input ? 'checked' : '' ?>
                            <?= $disabled_attr ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                    </div>
                </div>
            </div>

            <?php if (!$can_edit): ?>
                <p class="fw-settings-note">
                    You do not have permission to modify the firewall settings.
                </p>
            <?php endif; ?>
        </div>
    </main>
</div>
