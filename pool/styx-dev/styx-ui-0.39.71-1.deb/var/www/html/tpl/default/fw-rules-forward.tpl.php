<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */

$rules = isset($tdata['page_data']['rules']) ? $tdata['page_data']['rules'] : [];

// Rules are pre-formatted by App\Pages\Fmt\FwRulesForwardFormatter
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Firewall Rules Forward</h1>
        <div class="content-box">
            <div class="margin-bottom-12 fw-toolbar">
                <?php if (!empty($tdata['page_data']['can_create'])): ?>
                <a href="?page=firewall&section=fw-rules-mgmt-forward&create=1" class="std-btn">Create new rule</a>
                <?php endif; ?>
                <label class="std-switch filter-toggle">
                    <span class="filter-toggle-label">Filters</span>
                    <span class="filter-toggle-track">
                        <input type="checkbox"
                            onchange="window.location.href='?page=firewall&section=fw-rules-forward&bypass_filter=' + (this.checked ? '1' : '0')"
                            <?= !empty($tdata['page_data']['bypass_filter']) ? 'checked' : '' ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </span>
                </label>
            </div>

            <!-- Family Tabs -->
            <div class="std-tabs margin-bottom-12">
                <button class="std-tab-btn active"
                    data-tab-btn-context="dynamic-table"
                    data-tab-btn-family="ipv4">
                    IPv4
                </button>
                <button class="std-tab-btn"
                    data-tab-btn-context="dynamic-table"
                    data-tab-btn-family="ipv6">
                    IPv6
                </button>
            </div>

            <?php if (empty($rules)): ?>
                <div class="std-msg-info fw-std-msg-info">No rules configured for this chain.</div>
            <?php endif; ?>

            <!-- IPv4 Tab Content -->
            <div data-tab-context="dynamic-table" data-tab-family="ipv4">
                <div id="column-controls-ipv4"></div>
                <table class="std-table" id="dynamic-table-ipv4"></table>
            </div>

            <!-- IPv6 Tab Content -->
            <div data-tab-context="dynamic-table" data-tab-family="ipv6" style="display: none;">
                <div id="column-controls-ipv6"></div>
                <table class="std-table" id="dynamic-table-ipv6"></table>
            </div>
        </div>
    </main>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const columnsConfig = <?= $tdata['page_data']['fw_columns_config_json'] ?? 'null' ?>;
    initForwardRulesTabs({
        thead: <?= $tdata['page_data']['fw_thead_json'] ?? 'null' ?>,
        data: <?= $tdata['page_data']['fw_rows_json'] ?? '[]' ?>,
        controlsId: 'column-controls',
        tableIdPrefix: 'dynamic-table',
        rowLinkFn: function(row) {
            return '?page=firewall&section=fw-rules-mgmt-forward&modify=1&id=' + encodeURIComponent(row.id);
        },
        endpoint: '/submit.php',
        columnsConfig: columnsConfig
    });
});
</script>
