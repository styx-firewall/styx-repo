<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */

// Table data prepared by App\Pages\Fmt\FwRulesLocalFormatter
$input_table_data = $tdata['page_data']['input_table_data'] ?? [];
$output_table_data = $tdata['page_data']['output_table_data'] ?? [];
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Local Firewall Rules</h1>
        <div class="content-box">
            <div class="margin-bottom-12 fw-toolbar">
                <?php if (!empty($tdata['page_data']['can_create'])): ?>
                <a href="?page=firewall&section=fw-rules-mgmt-local&create=1" class="std-btn">Create new rule</a>
                <?php endif; ?>
                <label class="std-switch filter-toggle">
                    <span class="filter-toggle-label">Filters</span>
                    <span class="filter-toggle-track">
                        <input type="checkbox"
                            onchange="window.location.href='?page=firewall&section=fw-rules-local&bypass_filter=' + (this.checked ? '1' : '0')"
                            <?= !empty($tdata['page_data']['bypass_filter']) ? 'checked' : '' ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </span>
                </label>
            </div>

            <!-- Family Tabs (controls both INPUT and OUTPUT) -->
            <div class="std-tabs margin-bottom-12">
                <button class="std-tab-btn active"
                    data-tab-btn-context="fw-local"
                    data-tab-btn-family="ipv4">
                    IPv4
                </button>
                <button class="std-tab-btn"
                    data-tab-btn-context="fw-local"
                    data-tab-btn-family="ipv6">
                    IPv6
                </button>
            </div>

            <h2>INPUT Rules</h2>
            <?php if (empty($input_table_data)): ?>
                <div class="std-msg-info fw-std-msg-info">
                    There are no INPUT rules configured for this section.
                </div>
            <?php endif; ?>
            <!-- IPv4 INPUT Tab -->
            <div data-tab-context="fw-local" data-tab-family="ipv4">
                <div id="column-controls-input-ipv4"></div>
                <table class="std-table" id="dynamic-table-input-ipv4"></table>
            </div>
            <!-- IPv6 INPUT Tab -->
            <div data-tab-context="fw-local" data-tab-family="ipv6" style="display: none;">
                <div id="column-controls-input-ipv6"></div>
                <table class="std-table" id="dynamic-table-input-ipv6"></table>
            </div>

            <h2>OUTPUT Rules</h2>
            <?php if (empty($output_table_data)): ?>
                <div class="std-msg-info fw-std-msg-info">There are no OUTPUT rules configured for this section.</div>
            <?php endif; ?>
            <!-- IPv4 OUTPUT Tab -->
            <div data-tab-context="fw-local" data-tab-family="ipv4">
                <div id="column-controls-output-ipv4"></div>
                <table class="std-table" id="dynamic-table-output-ipv4"></table>
            </div>
            <!-- IPv6 OUTPUT Tab -->
            <div data-tab-context="fw-local" data-tab-family="ipv6" style="display: none;">
                <div id="column-controls-output-ipv6"></div>
                <table class="std-table" id="dynamic-table-output-ipv6"></table>
            </div>
        </div>
    </main>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const columnsConfig = <?= $tdata['page_data']['fw_local_columns_config_json'] ?? 'null' ?>;
    initLocalRulesTabs({
        thead: <?= $tdata['page_data']['fw_local_thead_json'] ?? 'null' ?>,
        inputData: <?= $tdata['page_data']['fw_local_input_rows_json'] ?? '[]' ?>,
        outputData: <?= $tdata['page_data']['fw_local_output_rows_json'] ?? '[]' ?>,
        controlsIdPrefix: 'column-controls',
        tableIdPrefix: 'dynamic-table',
        rowLinkFn: function(row) {
            return '?page=firewall&section=fw-rules-mgmt-local&modify=1&id=' + encodeURIComponent(row.id);
        },
        endpoint: '/submit.php',
        columnsConfig: columnsConfig
    });
});
</script>

