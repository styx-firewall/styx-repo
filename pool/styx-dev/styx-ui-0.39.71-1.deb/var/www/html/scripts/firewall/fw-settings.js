/*
 * Firewall Settings: toggles (conntrack bypass / drop invalid) and log cache
 * sizes (fw_logs_max / ct_logs_max).
 *
 * Each control submits only its own delta ({ role: { chain: value } } or
 * { key: value }). The backend merges the payload over the current settings,
 * so an unrelated setting can never be overwritten and future settings not
 * rendered here are preserved.
 *
 * While a request is in flight every control is disabled, which serializes the
 * changes and prevents out-of-order overwrites from rapid clicks.
 */
document.addEventListener('DOMContentLoaded', function() {
    const toggles = document.querySelectorAll('.fw-setting-toggle');
    const numbers = document.querySelectorAll('.fw-setting-number');

    if (toggles.length === 0 && numbers.length === 0) {
        return;
    }

    let saving = false;

    function setSaving(active) {
        saving = active;
        toggles.forEach(function(toggle) {
            toggle.disabled = active;
        });
        numbers.forEach(function(input) {
            input.disabled = active;
        });
    }

    // apiClient.submit never rejects (network failures resolve as
    // {status:'error'}), so errors are handled in the else branch.
    function submitDelta(payload, onSuccess, onFailure) {
        setSaving(true);
        apiClient.submit('set_firewall_settings', payload)
            .then(function(data) {
                if (data.status === 'success') {
                    if (onSuccess) onSuccess();
                    showApiResult(data, { closeText: 'Close' });
                } else {
                    if (onFailure) onFailure();
                    showApiResult(data, { title: 'Error', closeText: 'Close' });
                }
            })
            .finally(function() {
                setSaving(false);
            });
    }

    toggles.forEach(function(toggle) {
        toggle.addEventListener('change', function() {
            // Guard: controls are disabled while saving, so this is belt-and-suspenders.
            if (saving) {
                toggle.checked = !toggle.checked;
                return;
            }
            const prev = toggle.checked;
            const payload = {};
            payload[toggle.dataset.role] = {};
            payload[toggle.dataset.role][toggle.dataset.chain] = prev;
            submitDelta(payload, null, function() {
                toggle.checked = !prev;
            });
        });
    });

    numbers.forEach(function(input) {
        // Last value successfully committed to the gateway.
        input.dataset.committed = input.value;

        input.addEventListener('change', function() {
            if (saving) {
                input.value = input.dataset.committed;
                return;
            }
            const committed = input.dataset.committed;
            const value = Number(input.value);
            if (!Number.isInteger(value) || value < 1 || value > 100000) {
                input.value = committed;
                showError('The log cache size must be an integer between 1 and 100000.', 'Invalid value');
                return;
            }
            const payload = {};
            payload[input.dataset.settingKey] = value;
            submitDelta(payload, function() {
                input.dataset.committed = String(value);
            }, function() {
                input.value = committed;
            });
        });
    });
});
