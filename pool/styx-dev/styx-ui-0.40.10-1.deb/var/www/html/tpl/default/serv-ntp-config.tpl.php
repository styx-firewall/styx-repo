<?php
/**
 * NTP fragment: Configuración.
 *
 * Echo-only; all derived values come from the formatter ($pd).
 * js: scripts/ntp/ntp.js
 */
$pd = $tdata['tpl_data'] ?? [];
$da = $pd['disabled_attr'] ?? 'disabled';   // '' (admin) or 'disabled' (read-only)
?>
<?php if (!empty($pd['cfg_error'])): ?>
    <div class="std-error-box">
        <strong>Error:</strong> <?= $pd['cfg_error'] ?>
    </div>
<?php else: ?>

    <div class="ntp-config-section">
        <h2>Provider</h2>
        <div class="std-form form-compact">
            <div class="form-row">
                <div class="form-col">
                    <label>Provider</label>
                    <span><?= $pd['cfg_provider_label'] ?></span>
                    <span class="text-muted">(fixed - read only)</span>
                </div>
            </div>
        </div>
    </div>

    <div class="ntp-config-section">
        <h2>Time Sources</h2>
        <p class="text-muted">Sources managed by styx. An empty list disables the factory pools: chrony then only uses your own
            sources under sources.d / conf.d.</p>
        <?php if (!empty($pd['cfg_sources_empty_note'])): ?>
        <p class="text-muted"><?= $pd['cfg_sources_empty_note'] ?></p>
        <?php endif; ?>

        <div id="ntp-sources">
            <?php foreach (($pd['cfg_sources_rows'] ?? []) as $row): ?>
            <div class="ntp-source-row">
                <div class="ntp-source-field ntp-source-type-wrap">
                    <label>Type</label>
                    <select class="std-select ntp-source-type" <?= $da ?>>
                        <option value="pool"<?= $row['type_pool_sel'] ?>>pool</option>
                        <option value="server"<?= $row['type_server_sel'] ?>>server</option>
                    </select>
                </div>
                <div class="ntp-source-field ntp-source-address-wrap">
                    <label>Address / host</label>
                    <input type="text" class="ntp-source-address" value="<?= $row['address_esc'] ?>"
                        placeholder="2.pool.ntp.org or 192.0.2.1" <?= $da ?>>
                </div>
                <div class="ntp-source-field ntp-source-boolean">
                    <label>iburst</label>
                    <label class="std-switch">
                        <input type="checkbox" class="ntp-source-iburst" <?= $row['iburst_checked'] ?> <?= $da ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                </div>
                <div class="ntp-source-field ntp-source-boolean">
                    <label>prefer</label>
                    <label class="std-switch">
                        <input type="checkbox" class="ntp-source-prefer" <?= $row['prefer_checked'] ?> <?= $da ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                </div>
                <div class="ntp-source-field ntp-source-maxsources-col"<?php if (empty($row['is_pool'])): ?> style="display:none"<?php endif; ?>>
                    <label>maxsources</label>
                    <input type="number" class="ntp-source-maxsources" min="<?= $pd['cfg_maxsources_min'] ?>" max="<?= $pd['cfg_maxsources_max'] ?>" step="1"
                        value="<?= $row['maxsources_val'] ?>" placeholder="auto" <?= $da ?>>
                </div>
                <div class="ntp-source-actions">
                    <button type="button" class="std-btn ntp-source-remove" <?= $da ?>>Remove</button>
                </div>
                <div class="ntp-source-advanced">
                    <details class="ntp-source-advanced-box">
                        <summary>Advanced polling (leave blank for chrony defaults)</summary>
                        <div class="ntp-source-advanced-fields">
                            <div class="ntp-source-field">
                                <label>minpoll</label>
                                <input type="number" class="ntp-source-minpoll" min="<?= $pd['cfg_minpoll_min'] ?>" max="<?= $pd['cfg_minpoll_max'] ?>" step="1"
                                    value="<?= $row['minpoll_val'] ?>" placeholder="default (64 s)" <?= $da ?>>
                            </div>
                            <div class="ntp-source-field">
                                <label>maxpoll</label>
                                <input type="number" class="ntp-source-maxpoll" min="<?= $pd['cfg_maxpoll_min'] ?>" max="<?= $pd['cfg_maxpoll_max'] ?>" step="1"
                                    value="<?= $row['maxpoll_val'] ?>" placeholder="default (1024 s)" <?= $da ?>>
                            </div>
                        </div>
                    </details>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="form-row">
            <button type="button" class="std-btn" data-js="ntp-source-add" <?= $da ?>>Add source</button>
        </div>

        <!-- Skeleton for JS-added source rows (scripts/ntp/ntp.js clones this;
             values are assigned via DOM properties, never innerHTML). -->
        <template id="ntp-source-row-tpl">
            <div class="ntp-source-row">
                <div class="ntp-source-field ntp-source-type-wrap">
                    <label>Type</label>
                    <select class="std-select ntp-source-type">
                        <option value="pool">pool</option>
                        <option value="server">server</option>
                    </select>
                </div>
                <div class="ntp-source-field ntp-source-address-wrap">
                    <label>Address / host</label>
                    <input type="text" class="ntp-source-address" placeholder="2.pool.ntp.org or 192.0.2.1">
                </div>
                <div class="ntp-source-field ntp-source-boolean">
                    <label>iburst</label>
                    <label class="std-switch">
                        <input type="checkbox" class="ntp-source-iburst">
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                </div>
                <div class="ntp-source-field ntp-source-boolean">
                    <label>prefer</label>
                    <label class="std-switch">
                        <input type="checkbox" class="ntp-source-prefer">
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                </div>
                <div class="ntp-source-field ntp-source-maxsources-col">
                    <label>maxsources</label>
                    <input type="number" class="ntp-source-maxsources" min="<?= $pd['cfg_maxsources_min'] ?>" max="<?= $pd['cfg_maxsources_max'] ?>" step="1" placeholder="auto">
                </div>
                <div class="ntp-source-actions">
                    <button type="button" class="std-btn ntp-source-remove">Remove</button>
                </div>
                <div class="ntp-source-advanced">
                    <details class="ntp-source-advanced-box">
                        <summary>Advanced polling (leave blank for chrony defaults)</summary>
                        <div class="ntp-source-advanced-fields">
                            <div class="ntp-source-field">
                                <label>minpoll</label>
                                <input type="number" class="ntp-source-minpoll" min="<?= $pd['cfg_minpoll_min'] ?>" max="<?= $pd['cfg_minpoll_max'] ?>" step="1" placeholder="default (64 s)">
                            </div>
                            <div class="ntp-source-field">
                                <label>maxpoll</label>
                                <input type="number" class="ntp-source-maxpoll" min="<?= $pd['cfg_maxpoll_min'] ?>" max="<?= $pd['cfg_maxpoll_max'] ?>" step="1" placeholder="default (1024 s)">
                            </div>
                        </div>
                    </details>
                </div>
            </div>
        </template>
    </div>

    <div class="ntp-config-section">
        <h2>NTP Server Role</h2>
        <p class="text-muted">Serve time to the LAN. Enabling this role does <strong>not</strong> open UDP 123 in the firewall.</p>

        <div class="std-form">
            <div class="form-row">
                <div class="form-col">
                    <label>Enable server role</label>
                    <label class="std-switch">
                        <input type="checkbox" id="ntp-server-enabled" <?= $pd['cfg_server_enabled_checked'] ?> <?= $da ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                </div>
            </div>
            <?php if (!empty($pd['cfg_server_role_note_require'])): ?>
            <div class="form-row">
                <div class="form-col" style="flex:0 0 100%">
                    <p class="form-warning"><?= $pd['cfg_server_role_note_require'] ?></p>
                </div>
            </div>
            <?php endif; ?>
            <div class="form-row">
                <div class="form-col" style="flex:0 0 100%">
                    <label for="ntp-server-allow">allow &mdash; one network / address / <code>all</code> per line</label>
                    <textarea id="ntp-server-allow" name="allow" class="ntp-server-allow" rows="4" placeholder="192.168.100.0/24&#10;10.0.0.1&#10;all" <?= $da ?>><?= $pd['cfg_server_allow_esc'] ?></textarea>
                </div>
            </div>

            <div class="form-row" id="ntp-server-local">
                <div class="form-col">
                    <label>Local reference (serve time with no upstream)</label>
                    <label class="std-switch">
                        <input type="checkbox" id="ntp-local-enabled" <?= $pd['cfg_server_local_enabled_checked'] ?> <?= $da ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                </div>
            </div>
            <div class="form-row" id="ntp-local-fields">
                <div class="form-col">
                    <label for="ntp-local-stratum">local stratum</label>
                    <input type="number" id="ntp-local-stratum" class="ntp-local-stratum" min="<?= $pd['cfg_stratum_min'] ?>" max="<?= $pd['cfg_stratum_max'] ?>" step="1"
                        value="<?= $pd['cfg_server_local_stratum_val'] ?>" placeholder="10" <?= $da ?>>
                </div>
                <div class="form-col">
                    <label>orphan</label>
                    <label class="std-switch">
                        <input type="checkbox" id="ntp-local-orphan" <?= $pd['cfg_server_local_orphan_checked'] ?> <?= $da ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                </div>
            </div>
        </div>
    </div>

    <div class="ntp-config-section">
        <h2>Global Options</h2>
        <div class="std-form">
            <div class="form-row">
                <div class="form-col">
                    <label for="ntp-global-port">Port (0 = client only)</label>
                    <input type="number" id="ntp-global-port" class="ntp-global-port" min="<?= $pd['cfg_port_min'] ?>" max="<?= $pd['cfg_port_max'] ?>" step="1"
                        value="<?= $pd['cfg_global_port_val'] ?>" placeholder="123" <?= $da ?>>
                </div>
                <div class="form-col">
                    <label for="ntp-global-threshold">makestep threshold</label>
                    <input type="number" id="ntp-global-threshold" class="ntp-global-threshold" step="1"
                        value="<?= $pd['cfg_global_threshold_val'] ?>" placeholder="1" <?= $da ?>>
                </div>
                <div class="form-col">
                    <label for="ntp-global-limit">makestep limit (negative = unlimited)</label>
                    <input type="number" id="ntp-global-limit" class="ntp-global-limit" step="1"
                        value="<?= $pd['cfg_global_limit_val'] ?>" placeholder="3" <?= $da ?>>
                </div>
                <div class="form-col">
                    <label for="ntp-global-skew">maxupdateskew</label>
                    <input type="number" id="ntp-global-skew" class="ntp-global-skew" step="any"
                        value="<?= $pd['cfg_global_skew_val'] ?>" placeholder="100.0" <?= $da ?>>
                </div>
                <div class="form-col">
                    <label>rtcsync</label>
                    <label class="std-switch">
                        <input type="checkbox" id="ntp-global-rtcsync" <?= $pd['cfg_global_rtcsync_checked'] ?> <?= $da ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                </div>
            </div>
        </div>
    </div>

    <div class="form-row ntp-config-actions">
        <?= $pd['cfg_buttons_html'] ?? '' ?>
    </div>

<?php endif; ?>
