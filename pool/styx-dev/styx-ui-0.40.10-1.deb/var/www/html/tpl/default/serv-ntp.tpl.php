<?php
/**
 * NTP (chrony) page shell.
 *
 * The two tabs are rendered from named places injected by PageServices:
 *   serv_ntp_status  - serv-ntp-status.tpl.php
 *   serv_ntp_config  - serv-ntp-config.tpl.php
 *
 * Tab switching is handled by the global std-tabs handler (no JS needed).
 * js: scripts/ntp/ntp.js
 */
$pagep = $tdata['page_data'] ?? [];
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>NTP</h1>
        <p>Network Time Protocol backed by chrony: managed time sources and the optional NTP server role for the LAN.</p>

        <script>
        window.ntpConfig  = <?= json_encode($pagep['config'] ?? null, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
        window.ntpCanEdit = <?= !empty($pagep['can_edit']) ? 'true' : 'false' ?>;
        </script>

        <section class="content-box">
            <div class="std-tabs" id="ntp-tabs">
                <button class="std-tab-btn active" data-tab="estado">Estado</button>
                <button class="std-tab-btn" data-tab="config">Configuración</button>
            </div>
            <div class="std-tab-panel active" id="tab-estado">
                <?= $tdata['serv_ntp_status'] ?? '' ?>
            </div>
            <div class="std-tab-panel" id="tab-config">
                <?= $tdata['serv_ntp_config'] ?? '' ?>
            </div>
        </section>
    </main>
</div>
