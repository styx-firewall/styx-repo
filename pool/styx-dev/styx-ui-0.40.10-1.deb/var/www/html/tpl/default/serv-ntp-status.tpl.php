<?php
/**
 * NTP fragment: Estado (runtime status).
 *
 * Echo-only. All derived text/badges come pre-escaped from the formatter ($pd).
 * js: scripts/ntp/ntp.js (Refresh status button)
 */
$pd = $tdata['tpl_data'] ?? [];
?>
<?php if (!empty($pd['st_load_error'])): ?>
    <div class="std-error-box">
        <strong>Error:</strong> <?= $pd['st_load_error'] ?>
    </div>
<?php else: ?>

    <div class="ntp-status-card">
        <h2>NTP Service</h2>
        <div class="std-form form-compact">
            <div class="form-row">
                <div class="form-col">
                    <label>Provider</label>
                    <span><?= $pd['st_provider'] ?></span>
                </div>
                <div class="form-col">
                    <label>Status</label>
                    <span class="std-badge <?= $pd['st_active_badge'] ?? '' ?>"><?= $pd['st_active_text'] ?></span>
                    <?php if (!empty($pd['st_not_installed_note'])): ?>
                        <span class="text-muted"><?= $pd['st_not_installed_note'] ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-col">
                    <label>Enabled at boot</label>
                    <span><?= $pd['st_enabled_text'] ?></span>
                </div>
                <div class="form-col">
                    <label>Managed sources</label>
                    <span><?= (int)($pd['st_source_count'] ?? 0) ?></span>
                </div>
            </div>
        </div>

        <?php if (!empty($pd['st_error'])): ?>
        <div class="std-error-box" style="margin-top:12px;">
            <strong>chrony runtime:</strong> <?= $pd['st_error'] ?>
        </div>
        <?php endif; ?>

        <?php if (!empty($pd['st_has_notes']) && is_array($pd['st_notes'])): ?>
        <div class="ntp-notes" style="margin-top:12px;">
            <?php foreach ($pd['st_notes'] as $note): ?>
                <p class="text-muted"><?= $note ?></p>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="ntp-status-card std-collapse-box">
        <div class="std-collapse-header" onclick="this.parentNode.classList.toggle('open')">Tracking</div>
        <div class="std-collapse-content">
            <?php if (!empty($pd['st_tracking_has']) && is_array($pd['st_tracking_rows'])): ?>
            <table class="std-table">
                <tbody>
                    <?php foreach ($pd['st_tracking_rows'] as $r): ?>
                    <tr>
                        <td class="text-muted"><?= $r['label'] ?></td>
                        <td><?= $r['value'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p class="text-muted"><?= $pd['st_tracking_absent_note'] ?></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="ntp-status-card std-collapse-box open">
        <div class="std-collapse-header" onclick="this.parentNode.classList.toggle('open')">Sources</div>
        <div class="std-collapse-content">
            <?php if (!empty($pd['st_sources_has']) && is_array($pd['st_sources_rows'])): ?>
            <table class="std-table">
                <thead>
                    <tr>
                        <th>State</th>
                        <th>Name</th>
                        <th>Stratum</th>
                        <th>Poll</th>
                        <th>Reach</th>
                        <th>Last RX</th>
                        <th>Last sample offset</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pd['st_sources_rows'] as $s): ?>
                    <tr>
                        <td><span class="std-badge <?= $s['state_badge'] ?>"><?= $s['state_display'] ?></span></td>
                        <td><?= $s['name'] ?></td>
                        <td><?= $s['stratum'] ?></td>
                        <td><?= $s['poll'] ?></td>
                        <td><?= $s['reach'] ?></td>
                        <td><?= $s['last_rx'] ?></td>
                        <td><?= $s['last_sample_offset'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p class="text-muted"><?= $pd['st_sources_empty_note'] ?></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="ntp-status-card std-collapse-box open">
        <div class="std-collapse-header" onclick="this.parentNode.classList.toggle('open')">NTP Server Role</div>
        <div class="std-collapse-content">
            <div class="std-form form-compact">
                <div class="form-row">
                    <div class="form-col">
                        <label>Role</label>
                        <span class="std-badge <?= $pd['st_server_role_badge'] ?>"><?= $pd['st_server_role_text'] ?></span>
                    </div>
                </div>
            </div>

            <?php if (!empty($pd['st_clients_has']) && is_array($pd['st_clients_rows'])): ?>
            <h3 style="margin-top:16px;">Connected clients</h3>
            <table class="std-table">
                <thead>
                    <tr>
                        <?php foreach (($pd['st_clients_cols'] ?? []) as $label): ?>
                        <th><?= $label ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pd['st_clients_rows'] as $row): ?>
                    <tr>
                        <?php foreach (array_keys($pd['st_clients_cols'] ?? []) as $c): ?>
                        <td><?= $row[$c] ?></td>
                        <?php endforeach; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p class="text-muted"><?= $pd['st_clients_note'] ?></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="ntp-status-card" style="margin-top:16px;">
        <button type="button" class="std-btn" data-js="ntp-refresh-status">Refresh status</button>
    </div>

<?php endif; ?>
