// ntp.js
// NTP (chrony) configuration and status.
//
// Reads/writes go through the same gateway envelope as the rest of the app:
//   reads   -> apiClient.request('ntp.get_config'|'ntp.get_status', {})
//   writes  -> apiClient.submit('ntp.save_config'|'ntp.reset_config', payload)
//
// The ntp backend reports messages canonically in result.msg (the top-level
// response_msg legacy bridge is not used by this module). showApiResult() reads
// result.msg, so save/reset errors (validation joined by "; " or FORBIDDEN)
// surface automatically.

document.addEventListener('DOMContentLoaded', () => {
    // Restore the tab that was active before a Save/Reset reload.
    restoreActiveTab();
    bindRefreshStatus();

    // Non-admin users see a read-only page: never bind editing.
    if (window.ntpCanEdit !== true) return;

    initSourcesEditor();
    initServerRole();
    bindSaveReset();
});

function $id(id) {
    return document.getElementById(id);
}

function numOrNull(v) {
    const s = (v === null || v === undefined) ? '' : String(v).trim();
    if (s === '') return null;
    const n = Number(s);
    return Number.isFinite(n) ? n : null;
}

/** Read a numeric field. Returns '' when empty/invalid so callers can fall back. */
function numEl(id) {
    const el = $id(id);
    if (!el) return '';
    const s = el.value.trim();
    if (s === '') return '';
    const n = Number(s);
    return Number.isFinite(n) ? n : '';
}

/** Numeric field with fallback to the existing config value, then a default. */
function numOr(id, existing, dflt) {
    const n = numEl(id);
    if (n !== '') return n;
    let ex = (existing === null || existing === undefined || existing === '') ? dflt : Number(existing);
    if (!Number.isFinite(ex)) ex = dflt;
    return ex;
}

function toggleMaxsources(row) {
    const type = row.querySelector('.ntp-source-type').value;
    const col = row.querySelector('.ntp-source-maxsources-col');
    if (col) {
        col.style.display = type === 'pool' ? '' : 'none';
    }
}


// Estado: Refresh status (all roles)

function bindRefreshStatus() {
    const btn = document.querySelector('[data-js="ntp-refresh-status"]');
    if (!btn) return;
    btn.addEventListener('click', async () => {
        try {
            const res = await apiClient.request('ntp.get_status', {});
            if (res && res.status === 'success') {
                window.location.reload();
            } else {
                showApiResult(res, { title: 'NTP status', closeText: 'Close' });
            }
        } catch (err) {
            showApiResult({ status: 'error', result: { msg: err.message } }, { title: 'NTP status', closeText: 'Close' });
        }
    });
}


// Configuración: dynamic source editor

function initSourcesEditor() {
    const container = $id('ntp-sources');
    if (!container) return;

    container.addEventListener('change', (e) => {
        if (e.target.classList.contains('ntp-source-type')) {
            toggleMaxsources(e.target.closest('.ntp-source-row'));
        }
    });
    container.addEventListener('click', (e) => {
        const btn = e.target.closest('.ntp-source-remove');
        if (btn && btn.disabled !== true) {
            e.preventDefault();
            const row = btn.closest('.ntp-source-row');
            if (row) row.remove();
        }
    });

    const addBtn = document.querySelector('[data-js="ntp-source-add"]');
    if (addBtn) {
        addBtn.addEventListener('click', () => {
            const row = buildSourceRow({
                type: 'pool',
                address: '',
                iburst: true,
                prefer: false,
                minpoll: null,
                maxpoll: null,
                maxsources: null,
            });
            if (row) container.appendChild(row);
        });
    }
}

/**
 * Clone the source-row <template> (serv-ntp-config.tpl.php) and fill it.
 * Markup lives in the template; values are assigned via DOM properties, never
 * innerHTML, so there is no escaping/HTML-injection concern here.
 */
function buildSourceRow(src) {
    const tpl = document.getElementById('ntp-source-row-tpl');
    const row = tpl ? tpl.content.firstElementChild.cloneNode(true) : null;
    if (!row) {
        return null;
    }

    row.querySelector('.ntp-source-type').value = (src.type === 'server') ? 'server' : 'pool';
    row.querySelector('.ntp-source-address').value = src.address || '';
    row.querySelector('.ntp-source-iburst').checked = !!src.iburst;
    row.querySelector('.ntp-source-prefer').checked = !!src.prefer;
    row.querySelector('.ntp-source-minpoll').value = (src.minpoll === null || src.minpoll === undefined) ? '' : src.minpoll;
    row.querySelector('.ntp-source-maxpoll').value = (src.maxpoll === null || src.maxpoll === undefined) ? '' : src.maxpoll;
    row.querySelector('.ntp-source-maxsources').value = (src.maxsources === null || src.maxsources === undefined) ? '' : src.maxsources;
    toggleMaxsources(row);
    return row;
}


// Configuración: server role + local reference visibility

function initServerRole() {
    const localEnabled = $id('ntp-local-enabled');
    const localFields = $id('ntp-local-fields');
    if (localEnabled && localFields) {
        const sync = () => {
            localFields.style.display = localEnabled.checked ? '' : 'none';
        };
        localEnabled.addEventListener('change', sync);
        sync();
    }
}


// Configuración: build partial save payload + Save / Reset

function buildConfig() {
    const base = (window.ntpConfig && typeof window.ntpConfig === 'object') ? window.ntpConfig : {};
    const gbase = (base.global && typeof base.global === 'object') ? base.global : {};

    const sources = [];
    document.querySelectorAll('#ntp-sources .ntp-source-row').forEach((row) => {
        const typeEl = row.querySelector('.ntp-source-type');
        const type = typeEl ? typeEl.value : 'server';
        const addrEl = row.querySelector('.ntp-source-address');
        const iburstEl = row.querySelector('.ntp-source-iburst');
        const preferEl = row.querySelector('.ntp-source-prefer');
        sources.push({
            type: type,
            address: (addrEl ? addrEl.value : '').trim(),
            iburst: !!(iburstEl && iburstEl.checked),
            prefer: !!(preferEl && preferEl.checked),
            minpoll: optNumId(row, '.ntp-source-minpoll'),
            maxpoll: optNumId(row, '.ntp-source-maxpoll'),
            maxsources: type === 'pool' ? optNumId(row, '.ntp-source-maxsources') : null,
        });
    });

    const serverEnabled = !!(($id('ntp-server-enabled')) && $id('ntp-server-enabled').checked);
    const allowText = $id('ntp-server-allow') ? $id('ntp-server-allow').value : '';
    const allow = allowText.split(/[\n,]/).map((s) => s.trim()).filter(Boolean);

    const localEnabled = !!($id('ntp-local-enabled') && $id('ntp-local-enabled').checked);
    const existingLocal = (base.server && base.server.local && typeof base.server.local === 'object')
        ? base.server.local
        : {};
    const local = (serverEnabled && localEnabled)
        ? {
            enabled: true,
            stratum: numOr('ntp-local-stratum', existingLocal.stratum, 10),
            orphan: !!($id('ntp-local-orphan') && $id('ntp-local-orphan').checked),
        }
        : null;

    return {
        sources,
        server: {
            enabled: serverEnabled,
            allow,
            local,
        },
        global: {
            port: numOr('ntp-global-port', gbase.port, 123),
            makestep_threshold: numOr('ntp-global-threshold', gbase.makestep_threshold, 1),
            makestep_limit: numOr('ntp-global-limit', gbase.makestep_limit, 3),
            maxupdateskew: numOr('ntp-global-skew', gbase.maxupdateskew, 100),
            rtcsync: !!($id('ntp-global-rtcsync') && $id('ntp-global-rtcsync').checked),
        },
    };
}

/** Optional numeric input scoped to a row; '' -> null (chrony default). */
function optNumId(row, sel) {
    const el = row.querySelector(sel);
    return el ? numOrNull(el.value) : null;
}

function bindSaveReset() {
    const saveBtn = document.querySelector('[data-js="ntp-save-config"]');
    if (saveBtn) {
        saveBtn.addEventListener('click', async () => {
            // reloadOnOk reloads the page on success; remember the current tab so
            // the reload lands back on Configuración.
            rememberActiveTab();
            try {
                const result = await apiClient.submit('ntp.save_config', buildConfig());
                showApiResult(result, { title: 'NTP Configuration', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', result: { msg: err.message } }, { title: 'NTP Configuration', closeText: 'Close' });
            }
        });
    }

    const resetBtn = document.querySelector('[data-js="ntp-reset-config"]');
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            showModal('Reset the NTP (chrony) configuration to defaults?', {
                title: 'Confirm Reset',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Reset',
                onConfirm: async () => {
                    rememberActiveTab();
                    try {
                        const result = await apiClient.submit('ntp.reset_config', {});
                        showApiResult(result, { title: 'Reset NTP', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', result: { msg: err.message } }, { title: 'Reset NTP', closeText: 'Close' });
                    }
                },
            });
        });
    }
}


// Tab persistence: keep the page on the same tab across the reload that
// showApiResult(reloadOnOk: true) performs after Save / Reset.

function currentActiveTab() {
    const active = document.querySelector('#ntp-tabs .std-tab-btn.active');
    return active ? (active.getAttribute('data-tab') || 'estado') : 'estado';
}

function activateTab(name) {
    const tabs = document.getElementById('ntp-tabs');
    if (!tabs) return;
    tabs.querySelectorAll('.std-tab-btn').forEach((btn) => {
        btn.classList.toggle('active', btn.getAttribute('data-tab') === name);
    });
    const panel = document.getElementById('tab-' + name);
    if (panel) {
        if (panel.parentElement) {
            panel.parentElement.querySelectorAll('.std-tab-panel').forEach((p) => p.classList.remove('active'));
        }
        panel.classList.add('active');
    }
}

function rememberActiveTab() {
    try {
        sessionStorage.setItem('ntp.activeTab', currentActiveTab());
    } catch (e) { /* storage unavailable - keep the default tab */ }
}

function restoreActiveTab() {
    let name = null;
    try {
        name = sessionStorage.getItem('ntp.activeTab');
        sessionStorage.removeItem('ntp.activeTab');
    } catch (e) { /* ignore */ }
    if (name) activateTab(name);
}
