<?php

namespace App\Controllers\Submit;

use App\Controllers\BaseController;
use App\Helpers\NtpResp;

/**
 * NTP (chrony) write path.
 *
 * Registered commands (SubmitRegistry):
 *   ntp.save_config  -> saveConfig()
 *   ntp.reset_config -> resetConfig()
 *
 * Responses are canonicalized through App\Helpers\NtpResp: messages always
 * come from result.msg (the top-level response_msg legacy bridge is ignored).
 * RBAC is enforced by the backend (ntp.save_config / ntp.reset_config need
 * system:admin); the UI gates the buttons separately.
 */
class NtpSubmitController extends BaseController
{
    /** Top-level keys accepted by the partial save payload. */
    private const DATA_KEYS = ['provider', 'sources', 'server', 'global'];

    /**
     * Save a (partial) NTP configuration. Omitted top-level keys keep their
     * current value; `sources` is replaced wholesale, so the frontend always
     * sends complete source rows.
     *
     * @param array<string,mixed> $data request body (includes command/metadata - whitelisted out)
     * @return array<string,mixed>
     */
    public function saveConfig(array $data = []): array
    {
        $payload  = array_intersect_key($data, array_flip(self::DATA_KEYS));
        $commands = [
            [
                'method' => 'ntp.save_config',
                'id'     => 'save_config',
                'data'   => $payload,
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return NtpResp::single($resp, 'save_config');
    }

    /**
     * Restore the factory-default NTP configuration and apply it.
     *
     * @param array<string,mixed> $data unused
     * @return array<string,mixed>
     */
    public function resetConfig(array $data = []): array
    {
        $commands = [
            [
                'method' => 'ntp.reset_config',
                'id'     => 'reset_config',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return NtpResp::single($resp, 'reset_config');
    }
}
