<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Controllers\Request\RouteRulesRequestController;
use App\Controllers\Request\RoutingRequestController;
use App\Pages\Fmt\RoutesFormatter;
use App\Pages\Fmt\RouteRulesFormatter;
use App\Pages\Fmt\RoutingFormatter;
use App\Services\Filter;
use App\Services\AuthService;

class PageRouting
{
    /**
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);
        $features = $cfg->get('features') ?? [];
        $auth = $ctx->get(AuthService::class);

        $sections_array = [
            'routing-overview',
            'routing-routes',
            'routing-rules',
            'routing-frr',
            'routing-bgp',
            'routing-ospf',
            'routing-rip',
            'routing-bfd',
            'routing-igmp-proxy',
            'routing-policies',
            'routing-frr-static',
            'routing-vrrp',
            'routing-zebra',
            'routing-evpn',
        ];

        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'routing-overview';
        }

        // Guard: BGP/OSPF/RIP/BFD require frrouting; igmp-proxy requires igmp_proxy
        $frrouting_sections = ['routing-bgp', 'routing-ospf', 'routing-rip', 'routing-bfd'];
        if (in_array($section, $frrouting_sections) && empty($features['frrouting'])) {
            $section = 'routing-overview';
        }
        if ($section === 'routing-igmp-proxy' && empty($features['igmp_proxy'])) {
            $section = 'routing-overview';
        }

        $controller = new RoutingRequestController($ctx);
        $fmt_data = [
            'section' => $section,
            'features' => $features,
            'frr' => ['enabled' => false, 'daemons' => []],
            'igmp_proxy' => ['enabled' => false, 'daemon' => null],
            'route_summary' => [],
            'frr_routes' => [],
            'default_gateway_v4' => null,
            'default_gateway_v6' => null,
            'num_tables' => 0,
            'num_policy_rules' => 0,
            'bgp_config' => [],
            'neighbors' => [],
            'ospf_config' => [],
            'areas' => [],
            'rip_config' => [],
            'networks' => [],
            'sessions' => [],
            'igmp_config' => [],
            'interfaces' => [],
            'frr_profile' => null,
            'frr_max_fds' => null,
            'frr_no_root' => null,
            'vtysh_enable' => null,
        ];

        if ($section === 'routing-overview') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-overview.js'];
            $response = $controller->getOverviewData();
            if (($response['status'] ?? '') === 'success') {
                $result = $response['result'] ?? [];
                $fmt_data['frr']                = $result['frr'] ?? ['enabled' => false, 'daemons' => []];
                $fmt_data['igmp_proxy']         = $result['igmp_proxy'] ?? ['enabled' => false, 'daemon' => null];
                $fmt_data['route_summary']      = $result['route_summary'] ?? [];
                $fmt_data['frr_routes']         = $result['frr_routes'] ?? [];
                $fmt_data['default_gateway_v4'] = $result['default_gateway_v4'] ?? null;
                $fmt_data['default_gateway_v6'] = $result['default_gateway_v6'] ?? null;
                $fmt_data['num_tables']         = (int)($result['num_tables'] ?? 0);
                $fmt_data['num_policy_rules']   = (int)($result['num_policy_rules'] ?? 0);
            }
        } elseif ($section === 'routing-routes') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/network/routes.js'];
            $response = $controller->getRoutingPageData();
            if (is_array($response) && ($response['status'] ?? '') !== 'error') {
                $fmt_data = RoutesFormatter::format($fmt_data, $response['result'] ?? [], $auth->getCapabilities());
                $page['load_tpl'][] = [
                    'file'     => 'routing-routes-view',
                    'place'    => 'routes_view',
                    'tpl_data' => $fmt_data,
                    'weight'   => 5,
                ];
                $page['load_tpl'][] = [
                    'file'     => 'routing-routes-add',
                    'place'    => 'routes_add',
                    'tpl_data' => $fmt_data,
                    'weight'   => 6,
                ];
            }
        } elseif ($section === 'routing-rules') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/network/net-routing-rules.js'];
            $rrController = new RouteRulesRequestController($ctx);
            $response = $rrController->getRoutingRulesPageData();
            if (is_array($response) && ($response['status'] ?? '') !== 'error') {
                $fmt_data = RouteRulesFormatter::format($fmt_data, $response['result'] ?? []);
            }
        } elseif ($section === 'routing-bgp') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-bgp.js'];
            $response = $controller->getBgpPageData();
            if (($response['status'] ?? '') === 'success') {
                $result = $response['result'] ?? [];
                $fmt_data['bgp_config']   = $result['bgp_config'] ?? [];
                $fmt_data['neighbors']    = $result['neighbors'] ?? [];
                $fmt_data['networks']     = $result['networks'] ?? [];
                $fmt_data['bgp_ifaces']   = $result['bgp_ifaces'] ?? [];
                $fmt_data['route_maps']   = $result['route_maps'] ?? [];
                $fmt_data['prefix_lists'] = $result['prefix_lists'] ?? [];
                $fmt_data['peer_groups']  = $result['peer_groups'] ?? [];
                $fmt_data['bfd_profiles'] = $result['bfd_profiles'] ?? [];
            }
        } elseif ($section === 'routing-ospf') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-ospf.js'];
            $response = $controller->getOspfData();
            if (($response['status'] ?? '') === 'success') {
                $fmt_data['ospf_config'] = $response['result']['ospf_config'] ?? [];
                $fmt_data['areas'] = $response['result']['areas'] ?? [];
                $fmt_data['interfaces'] = $response['result']['interfaces'] ?? [];
                $fmt_data['neighbors'] = $response['result']['neighbors'] ?? [];
                $fmt_data['ospf_ifaces'] = $response['result']['ifaces_names'] ?? [];
            }
            // OSPFv3 data
            $response6 = $controller->getOspf6Data();
            if (($response6['status'] ?? '') === 'success') {
                $fmt_data['ospf6_config'] = $response6['result']['ospf6_config'] ?? [];
                $fmt_data['areas6'] = $response6['result']['areas'] ?? [];
                $fmt_data['interfaces6'] = $response6['result']['interfaces'] ?? [];
                $fmt_data['neighbors6'] = $response6['result']['neighbors'] ?? [];
            }
        } elseif ($section === 'routing-rip') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-rip.js'];
            $response = $controller->getRipPageData();
            if (($response['status'] ?? '') === 'success') {
                $fmt_data['rip_config']   = $response['result']['rip_config'] ?? [];
                $fmt_data['networks']     = $response['result']['networks'] ?? [];
                $fmt_data['neighbors']    = $response['result']['neighbors'] ?? [];
                $fmt_data['rip_ifaces']   = $response['result']['rip_ifaces'] ?? [];
                $fmt_data['bfd_profiles'] = $response['result']['bfd_profiles'] ?? [];
                $fmt_data['prefix_lists'] = $response['result']['prefix_lists'] ?? [];
                $fmt_data['route_maps']   = $response['result']['route_maps'] ?? [];
            }
        } elseif ($section === 'routing-bfd') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-bfd.js'];
            $response = $controller->getBfdPageData();
            if (($response['status'] ?? '') === 'success') {
                $fmt_data['sessions'] = $response['result']['sessions'] ?? [];
                $fmt_data['bfd_profiles'] = $response['result']['bfd_profiles'] ?? [];
            }
        } elseif ($section === 'routing-frr') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-frr.js'];
            $response = $controller->getFrrGlobal();
            if (($response['status'] ?? '') !== 'error') {
                $result = $response['result'] ?? [];
                $fmt_data['frr_profile']  = $result['profile'] ?? null;
                $fmt_data['frr_max_fds']  = $result['max_fds'] ?? null;
                $fmt_data['frr_no_root']  = $result['frr_no_root'] ?? null;
                $fmt_data['vtysh_enable'] = $result['vtysh_enable'] ?? null;
                $fmt_data['frr_overview'] = $result['overview'] ?? [];
            }
        } elseif ($section === 'routing-igmp-proxy') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-igmp-proxy.js'];
            $response = $controller->getIgmpProxyData();
            if (($response['status'] ?? '') === 'success') {
                $fmt_data['igmp_config'] = $response['result']['igmp_config'] ?? [];
                $fmt_data['interfaces'] = $response['result']['interfaces'] ?? [];
                $fmt_data['igmp_ifaces'] = $response['result']['ifaces_names'] ?? [];
            }
        } elseif ($section === 'routing-policies') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-policies.js'];
            $response = $controller->getPoliciesPageData();
            if (($response['status'] ?? '') !== 'error') {
                $result = $response['result'] ?? [];
                $fmt_data['prefix_lists']    = $result['prefix_lists'] ?? [];
                $fmt_data['route_maps']      = $result['route_maps'] ?? [];
                $fmt_data['as_path_lists']   = $result['as_path_lists'] ?? [];
                $fmt_data['community_lists'] = $result['community_lists'] ?? [];
            }
        } elseif ($section === 'routing-frr-static') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-frr-static.js'];
            $response = $controller->getFrrStatic();
            if (($response['status'] ?? '') === 'success') {
                $result = $response['result'] ?? [];
                $fmt_data['frr_static_config'] = ['enabled' => $result['enabled'] ?? false];
                $fmt_data['frr_static_routes'] = $result['routes'] ?? [];
                $fmt_data['frr_static_ifaces'] = $result['ifaces_names'] ?? [];
            }
        } elseif ($section === 'routing-vrrp') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-vrrp.js'];
            $response = $controller->getVrrp();
            if (($response['status'] ?? '') === 'success') {
                $result = $response['result'] ?? [];
                $fmt_data['vrrp_config'] = ['enabled' => $result['enabled'] ?? false];
                $fmt_data['vrrp_global_defaults'] = $result['global_defaults'] ?? [];
                $fmt_data['vrrp_instances'] = $result['instances'] ?? [];
                $fmt_data['vrrp_ifaces'] = $result['ifaces_names'] ?? [];
            }
        } elseif ($section === 'routing-zebra') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-zebra.js'];
            $response = $controller->getZebra();
            if (($response['status'] ?? '') === 'success') {
                $result = $response['result'] ?? [];
                $fmt_data['zebra_config'] = $result;
                $fmt_data['route_maps']   = $result['route_maps'] ?? [];
                unset($fmt_data['zebra_config']['route_maps']);
            }
        } elseif ($section === 'routing-evpn') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/routing/routing-evpn.js'];
            $response = $controller->getEvpnPageData();
            if (($response['status'] ?? '') === 'success') {
                $result = $response['result'] ?? [];
                $fmt_data['evpn_config']   = $result['evpn_config'] ?? [];
                $fmt_data['vrf_bindings']  = $result['vrf_bindings'] ?? [];
                $fmt_data['vrf_ifaces']    = $result['vrf_ifaces'] ?? [];
            }
        }

        $fmt = RoutingFormatter::format($section, $fmt_data, $auth->getCapabilities());

        $page['page'] = $section;
        $page['page_data'] = $fmt;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $features],
            'place' => 'sidebar',
        ];

        return $page;
    }
}
