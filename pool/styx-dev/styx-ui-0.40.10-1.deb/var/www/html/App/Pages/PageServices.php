<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Services\AuthService;
use App\Helpers\RoleHelper;
use App\Controllers\Request\DhcpRequestController;
use App\Controllers\Request\NtpRequestController;
use App\Pages\Fmt\ServDhcpFormatter;
use App\Pages\Fmt\ServNtpFormatter;

class PageServices
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'serv-dhcp',
            'serv-ntp',
        ];

        $features = $cfg->get('features', []);

        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            // chrony is a core service: boxes without the kea DHCP feature land on NTP;
            // DHCP boxes keep the historical DHCP default.
            $section = !empty($features['kea_dhcp4']) ? 'serv-dhcp' : 'serv-ntp';
        }

        if ($section === 'serv-dhcp') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/dhcp/serv-dhcp.js'];
            $dhcpController = new DhcpRequestController($ctx);
            $dhcp_response = $dhcpController->getPageData();

            $fmt_data = [];
            $fmt_data['iface_list'] = [];
            $fmt_data['dhcp_config'] = [];
            $fmt_data['dhcp_global_config'] = [];
            $fmt_data['leases'] = [];
            if ($dhcp_response['status'] !== 'error') {
                $all_ifaces = $dhcp_response['result']['interfaces'] ?? [];
                $fmt_data['iface_list'] = array_values(array_filter($all_ifaces, function($iface) {
                    if (isset($iface['interface']) && strtolower($iface['interface']) === 'lo') return false;
                    if (!isset($iface['ip_mode']) || strtolower($iface['ip_mode']) !== 'static') return false;
                    if (!empty($iface['missing'])) return false;
                    return (!empty($iface['ipv4']) || !empty($iface['ipv6']));
                }));
                $fmt_data['dhcp_config'] = $dhcp_response['result']['dhcp_config'] ?? [];
                $fmt_data['dhcp_global_config'] = $dhcp_response['result']['dhcp_global_config'] ?? [];
                $fmt_data['leases'] = $dhcp_response['result']['leases'] ?? [];
            }
            $fmt_data['features'] = $cfg->get('features', []);
            $fmt = ServDhcpFormatter::format($ctx, $fmt_data);

            // Inject serv-dhcp fragments with formatted data (PHP COW)
            $page['load_tpl'][] = [
                'file'     => 'serv-dhcp-global',
                'place'    => 'serv_dhcp_global',
                'tpl_data' => $fmt,
                'weight'   => 5,
            ];
            $page['load_tpl'][] = [
                'file'     => 'serv-dhcp-config',
                'place'    => 'serv_dhcp_config',
                'tpl_data' => $fmt,
                'weight'   => 6,
            ];
            $page['load_tpl'][] = [
                'file'     => 'serv-dhcp-leases',
                'place'    => 'serv_dhcp_leases',
                'tpl_data' => $fmt,
                'weight'   => 7,
            ];
        }

        if ($section === 'serv-ntp') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/ntp/ntp.js'];
            $ntpController = new NtpRequestController($ctx);
            $ntp_response  = $ntpController->getPageData();

            $fmt_data = ['config' => [], 'status' => []];
            if (
                isset($ntp_response['status']) &&
                ($ntp_response['status'] === 'success' || $ntp_response['status'] === 'partial')
            ) {
                $result = $ntp_response['result'] ?? [];
                $fmt_data['config']       = $result['config'] ?? [];
                $fmt_data['status']       = $result['status'] ?? [];
                $fmt_data['config_error'] = $result['config_error'] ?? null;
                $fmt_data['status_error'] = $result['status_error'] ?? null;
            } else {
                $msg = $ntp_response['result']['msg'] ?? 'Could not load NTP data';
                $fmt_data['config_error'] = $msg;
                $fmt_data['status_error'] = $msg;
            }

            $auth    = $ctx->get(AuthService::class);
            $isAdmin = RoleHelper::hasCapability($auth->getCapabilities(), 'system:admin');
            $fmt = ServNtpFormatter::format($fmt_data, $isAdmin);

            $page['load_tpl'][] = [
                'file'     => 'serv-ntp-status',
                'place'    => 'serv_ntp_status',
                'tpl_data' => $fmt,
                'weight'   => 5,
            ];
            $page['load_tpl'][] = [
                'file'     => 'serv-ntp-config',
                'place'    => 'serv_ntp_config',
                'tpl_data' => $fmt,
                'weight'   => 6,
            ];
        }

        $page['page'] = $section;
        $page['page_data'] = $fmt ?? [];
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }
}
