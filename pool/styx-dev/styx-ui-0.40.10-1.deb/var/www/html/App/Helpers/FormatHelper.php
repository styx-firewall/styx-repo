<?php

/**
 * FormatHelper
 *
 * Utility methods for formatting values for display in templates.
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */

namespace App\Helpers;

class FormatHelper
{
    /**
     * Format bytes to human-readable string.
     *
     * @param int $bytes
     * @return string
     */
    public static function formatBytes(int $bytes): string
    {
        if ($bytes === 0) {
            return '0 B';
        }
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = floor(log($bytes, 1024));
        $i = min((int)$i, count($units) - 1);
        $val = $bytes / pow(1024, $i);
        return number_format($val, $i > 0 ? 1 : 0) . ' ' . $units[$i];
    }

    /**
     * Render a firewall verdict (accept/drop/reject) as a semantic status badge.
     *
     * Reuses the `.std-badge` chips from default-badge.css with the same
     * accept=success / drop=danger / reject=warning mapping used by the
     * firewall log rows (fw-logs-firewall.js). Returns a `<span>` fragment for
     * known verdicts (the rules tables render it as HTML via `cellHtml`);
     * unknown values are returned unchanged so they render as plain text.
     *
     * @param mixed $action
     * @return string
     */
    public static function verdictBadge(mixed $action): string
    {
        $raw = is_scalar($action) ? (string)$action : '';
        $key = strtolower(trim($raw));
        return match ($key) {
            'accept' => '<span class="std-badge std-badge--success">ACCEPT</span>',
            'drop'   => '<span class="std-badge std-badge--danger">DROP</span>',
            'reject' => '<span class="std-badge std-badge--warning">REJECT</span>',
            default  => $raw,
        };
    }
}
