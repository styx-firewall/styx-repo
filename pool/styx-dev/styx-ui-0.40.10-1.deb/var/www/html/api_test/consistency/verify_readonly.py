#!/usr/bin/env python3
"""Read-only smoke checks against /request.php.

Runs a data-driven list of read actions and asserts status=='success' plus the
expected keys. Does not modify state. Replaces the old payloads/request/*.json
tests (selective: keeps the endpoints that are actually exercised).

Usage:
    python api_test/consistency/verify_readonly.py --target NAME
"""

import os
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, get, require_ok
from api_test.apicore.verify_common import build_parser, build_client, finish

# Each entry: (label, action, data, required_keys, expect)
#   required_keys: dotted paths that must be present and truthy
#   expect:        list of (dotted_path, expected_value) equality checks
CHECKS = [
    # Metrics
    ("metrics.cpu", "metrics", {"metric": "cpu", "range": "5m"}, (), []),
    ("metrics.memory", "metrics", {"metric": "memory", "range": "5m"}, (), []),
    ("metrics.network", "metrics", {"metric": "network", "range": "5m"}, (), []),
    ("metrics.network_tx", "metrics", {"metric": "network_tx", "range": "5m"}, (), []),
    ("metrics.network_rx", "metrics", {"metric": "network_rx", "range": "5m"}, (), []),
    # Refresh orchestration
    ("refresh.dashboard", "refresh", {"page": "dashboard", "firstRefresh": True}, (), [("action", "refreshed")]),
    ("refresh.logs", "refresh", {"page": "logs", "section": "logs-system"}, ("commands",), [("action", "refreshed")]),
    # Network / interfaces
    ("network.get_interfaces_names", "get_interfaces_names", {}, ("result.interfaces",), []),
    ("network.get_interfaces_names_ds", "get_interfaces_names_ds", {}, ("result.ifaces_list",), []),
    # Sets (read side)
    ("sets.get_ports", "get_ports", {}, ("result.ports",), []),
    ("sets.get_address", "get_address", {}, ("result.address",), []),
    ("sets.get_interfaces_sets", "get_interfaces_sets", {}, ("result.interfaces",), []),
    ("sets.get_domains", "get_domains", {}, ("result.domain",), []),
    ("sets.get_labels", "get_labels", {}, ("result.labels",), []),
    # Packet marking page data (backend returns only result.rules today)
    ("pm.get_pm_rules", "get_pm_rules", {}, ("result.rules",), []),
    # strongSwan
    ("swan.get_status", "swan_get_status", {}, (), []),
    ("swan.get_connections", "swan_get_connections", {}, (), []),
    # Styx (special-cased download endpoint returns {status, filename, result}).
    # Valid backup types: startup-config, running-config, profiles, events,
    # discovery-data, dns-data.
    ("styx.backup_download", "styx-backup-download", {"data": {"type": "startup-config"}}, ("filename",), []),
    # System
    ("system.get_ssh_config", "get_ssh_config", {}, (), []),
    # Users
    ("user.get_user_info", "get_user_info", {"username": "admin"}, (), []),
    ("user.get_bearer_tokens", "get_bearer_tokens", {}, ("result",), []),
    # Firewall logs
    ("firewall.fw_logs", "fw_logs", {"limit": 5}, (), []),
]


def run(client, continue_on_fail):
    failures = 0
    for label, action, data, keys, expect in CHECKS:
        try:
            resp = client.request(action, data)
            require_ok(resp, *keys)
            for path, expected in expect:
                actual = get(resp, path)
                if actual != expected:
                    raise AssertionError(f"{path} = {actual!r}, expected {expected!r}")
            print(f"  OK   {label}")
        except (ApiError, AssertionError) as e:
            print(f"  FAIL {label}: {e}")
            failures += 1
            if not continue_on_fail:
                break
    return failures


def main():
    p = build_parser("Read-only smoke checks against /request.php")
    p.add_argument("--continue-on-fail", action="store_true", help="Keep going after a check fails")
    args = p.parse_args()
    client = build_client(args)
    failures = run(client, args.continue_on_fail)

    finish(failures)


if __name__ == "__main__":
    main()
