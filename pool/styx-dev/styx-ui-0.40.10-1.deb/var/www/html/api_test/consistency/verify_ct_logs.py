#!/usr/bin/env python3
"""Read-only helper: fetch conntrack (CT) logs from a live machine and summarize.

Queries the same endpoint the "Connection Logs" UI uses (`get_ct_logs` on
/request.php) and prints a per-protocol / per-event breakdown plus a few of the
latest rows, so you can see at a glance what the backend actually returns
(e.g. whether ICMP flows are present) without opening a browser.

Read-only: does not modify any state.

Usage:
    python api_test/consistency/verify_ct_logs.py --target NAME                   # last 100 logs
    python api_test/consistency/verify_ct_logs.py --target NAME --limit 500
    python api_test/consistency/verify_ct_logs.py --target NAME --query 'protocol == "ICMP"'
"""

import collections
import os
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import build_parser, build_client, finish


def fmt_ports(log):
    """Compact 'src:port -> dst:port' (ports may be null for ICMP)."""
    sp = log.get("src_port")
    dp = log.get("dest_port")
    src = f"{log.get('src_ip') or '?'}:{sp if sp is not None else '-'}"
    dst = f"{log.get('dest_ip') or '?'}:{dp if dp is not None else '-'}"
    return f"{src} -> {dst}"


def main():
    parser = build_parser("Fetch and summarize conntrack (CT) logs (read-only)")
    parser.add_argument("--limit", type=int, default=100, help="Number of logs to fetch (default 100)")
    parser.add_argument(
        "--query", default=None, help='Filter expression, e.g. protocol == "ICMP" or ct.event == "destroy"'
    )
    parser.add_argument("--rows", type=int, default=5, help="How many of the latest rows to print (default 5)")
    args = parser.parse_args()

    client = build_client(args)
    if args.limit < 1:
        print(f"  FAIL --limit must be >= 1 (got {args.limit})")
        finish(1)

    data = {"limit": args.limit}
    if args.query:
        data["query"] = args.query

    try:
        resp = require_ok(client.request("get_ct_logs", data), "logs")
    except (ApiError, AssertionError) as e:
        print(f"  FAIL get_ct_logs: {e}")
        finish(1)

    logs = resp.get("logs") or []
    mark = resp.get("mark")

    print(f"  OK   get_ct_logs: {len(logs)} logs returned (mark={mark})")
    if not logs:
        finish(0)

    by_proto = collections.Counter(log.get("protocol") for log in logs)
    by_event = collections.Counter(log.get("ct.event") for log in logs)
    print("  protos:", dict(by_proto) or "(none)")
    print("  events:", dict(by_event) or "(none)")

    icmp = [log for log in logs if (log.get("protocol") or "").upper() == "ICMP"]
    print(f"  ICMP rows present: {'yes (' + str(len(icmp)) + ')' if icmp else 'NO'}")

    print(f"  latest {min(args.rows, len(logs))} rows:")
    for log in logs[: args.rows]:
        print(
            "    %-22s %-6s %-44s ev=%-7s dur=%-8s"
            % (
                log.get("timestamp") or "",
                log.get("protocol") or "",
                fmt_ports(log),
                log.get("ct.event") or "",
                log.get("flow.duration") if log.get("flow.duration") is not None else "-",
            )
        )

    if icmp:
        print("  example ICMP row keys:")
        ex = icmp[0]
        for k in ("timestamp", "protocol", "src_ip", "dest_ip", "src_port", "dest_port", "icmp", "ct.event", "flow_id"):
            if k in ex:
                print(f"    {k}: {ex[k]}")


if __name__ == "__main__":
    main()
