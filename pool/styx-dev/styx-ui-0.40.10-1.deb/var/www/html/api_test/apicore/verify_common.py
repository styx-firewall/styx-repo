#!/usr/bin/env python3
"""Shared scaffolding for the verify_*.py scripts.

Avoids repeating the same argparse / client construction / cleanup pattern in
every lifecycle script. This is intentionally small — it is NOT a test runner;
each script keeps its own linear flow.
"""

import argparse
import sys

from api_test.apicore.api_client import ApiClient, ApiError, load_config, resolve_target


def build_parser(description):
    p = argparse.ArgumentParser(description=description)
    p.add_argument("--config", default=None, help="Path to config file (default: api_test/config.json)")
    p.add_argument("--target", default=None, help="Target name in the config's 'targets' map (required)")
    return p


def build_client(args):
    """Build an ApiClient for the --target selected in the config.

    The config must carry a named-target map; every invocation names exactly one
    target (no implicit default). Missing/unknown target and config errors print
    as ``  FAIL <msg>`` and exit 1 — no traceback.
    """
    try:
        cfg = load_config(getattr(args, "config", None))
        profile = resolve_target(cfg, getattr(args, "target", None))
    except (FileNotFoundError, ValueError) as e:
        # Missing/malformed config and target-selection are common setup errors.
        print(f"  FAIL {e}")
        sys.exit(1)
    return ApiClient(
        profile["base_url"],
        profile["bearer_token"],
        verify_tls=profile["verify_tls"],
        timeout=profile["timeout"],
    )


def cleanup(client, created, label="cleanup"):
    """Best-effort deletion of resources created during a run.

    ``created`` is a list of (delete_command, delete_data) tuples, appended in
    creation order; deletion happens in reverse so dependencies (children before
    parents) are respected. Never raises: a leftover is reported as WARN.
    """
    for cmd, data in reversed(created):
        try:
            client.submit(cmd, data)
        except (ApiError, AssertionError) as e:
            print(f"  WARN {label} {cmd}: {e}")


class ResourceTracker:
    """Undo log for lifecycle tests that create resources against the live API.

    A sequential test against a stateful API (no transactions) needs to remember
    what it created: if a later step fails, everything created so far must still
    be deleted (children before parents), or the machine is left dirty. This is
    that ``created`` list plus the remember/forget helpers every lifecycle script
    used to redefine locally.
    """

    def __init__(self):
        self.items = []  # [(delete_command, delete_data)] in creation order

    def remember(self, command, data):
        """Record ``data`` (usually {"id": rid}) so cleanup() deletes it later."""
        self.items.append((command, data))

    def forget(self, command, data):
        """Drop a resource that was already deleted explicitly. Never raises."""
        try:
            self.items.remove((command, data))
        except ValueError:
            pass

    def discard(self, predicate):
        """Drop every recorded resource for which ``predicate((cmd, data))`` is true."""
        self.items[:] = [c for c in self.items if not predicate(c)]

    def cleanup(self, client, label="cleanup"):
        """Delete remaining recorded resources in reverse order (module cleanup)."""
        cleanup(client, self.items, label)


def finish(failures):
    """Print a summary and exit with the right code."""
    print(f"Summary: {failures} failed")
    sys.exit(1 if failures else 0)
