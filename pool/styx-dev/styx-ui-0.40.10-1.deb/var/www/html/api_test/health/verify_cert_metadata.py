#!/usr/bin/env python3
"""Health check for the ``refresh_cert_metadata`` command.

Runs the parsed-metadata refresh in preview mode (protocol ``dry-run``) by
default: asserts the command succeeds and the response carries
``result.total``/``result.refreshed``, then prints the counts. No state changes.

With ``--apply`` it runs for real (repairs stale entries and persists to
running-config when any changed; ``--force`` re-parses every certificate).
startup-config is never touched — call ``save_config`` manually to persist.

Usage:
    python api_test/health/verify_cert_metadata.py --target NAME             # preview, no changes
    python api_test/health/verify_cert_metadata.py --target NAME --apply     # real run (repair stale)
    python api_test/health/verify_cert_metadata.py --target NAME --force --apply   # force full re-parse
"""

import os
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, get, require_ok
from api_test.apicore.verify_common import build_parser, build_client, finish


def run(client, apply, force):
    try:
        resp = client.submit("refresh_cert_metadata", {"force": force}, dry_run=not apply)
        require_ok(resp, "result.total", "result.refreshed")
        total = get(resp, "result.total")
        refreshed = get(resp, "result.refreshed")
        persisted = get(resp, "result.persisted")
        mode = "apply" if apply else "preview"
        print(
            "  OK   refresh_cert_metadata "
            f"({mode}, force={force}): {refreshed}/{total} re-parsed, "
            f"persisted={persisted}"
        )
        msg = get(resp, "response_msg")
        if msg:
            print(f"  INFO {msg}")
    except (ApiError, AssertionError) as e:
        print(f"  FAIL refresh_cert_metadata: {e}")
        return 1
    return 0


def main():
    p = build_parser("Verify the refresh_cert_metadata command (preview by default)")
    p.add_argument("--apply", action="store_true", help="Run for real (repair stale entries and persist if changed)")
    p.add_argument("--force", action="store_true", help="Re-parse every certificate (invalidate all cached metadata)")
    args = p.parse_args()
    client = build_client(args)
    finish(run(client, args.apply, args.force))


if __name__ == "__main__":
    main()
