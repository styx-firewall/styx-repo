#!/usr/bin/env python3
"""TEMPLATE / example for provisioning (deployment) scripts.

The third use of the api_test tooling: configuring a machine with a specific
configuration. Copy this file to a script per target profile (e.g.
provision_office.py) and fill in the `deploy()` function with the resources that
profile needs. The pattern is: check what already exists (get_*), create only
what is missing, and pass `--dry-run` to preview the whole provisioning without
applying any change.

This example "provisions" a tiny set of port-sets, address-sets and a label as a
demonstration. It is idempotent: running it twice is a no-op for existing sets.

Usage:
    python api_test/deploy/provision_example.py --target NAME --dry-run     # preview (no changes)
    python api_test/deploy/provision_example.py --target NAME               # apply for real
    python api_test/deploy/provision_example.py --target NAME --name dc1    # per-machine suffix
"""

import argparse
import os
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiClient, ApiError, get
from api_test.apicore.verify_common import build_client

# The resources this profile wants to ensure exist. For sets, existence is
# matched by name (the backend stores the name). Add your own here.
WANTED_SETS = [
    # (kind, create_command, delete_command, get_action, list_key, name, payload)
    ("port", "set_port", "delete_port", "get_ports", "ports", "lan-http", {"type": "single", "value_single": 80}),
    (
        "address",
        "set_address",
        "delete_address",
        "get_address",
        "address",
        "lan-net",
        {"type": "set", "family": "ip", "value_set": ["192.168.1.0/24"]},
    ),
]


def deploy(client: ApiClient, name: str, dry_run: bool) -> None:
    """Ensure the wanted configuration exists. Idempotent."""
    created = []

    for kind, create_cmd, delete_cmd, get_action, list_key, wanted_name, payload in WANTED_SETS:
        resp = client.request(get_action)
        if get(resp, "status") != "success":
            raise AssertionError(f"{get_action} failed: {resp}")

        exists = any(item.get("name") == wanted_name for item in (get(resp, f"result.{list_key}") or []))
        if exists:
            print(f"  OK    {kind} {wanted_name!r} already exists")
            continue

        data = dict(payload, name=wanted_name)
        if dry_run:
            # Validate the request without applying it (dry-run:true)
            resp = client.submit(create_cmd, data, dry_run=True)
            if get(resp, "status") != "success":
                raise AssertionError(f"dry-run create {kind} {wanted_name!r} failed: {resp}")
            print(f"  DRY   create {kind} {wanted_name!r} would succeed")
            continue

        resp = client.submit(create_cmd, data)
        if get(resp, "status") != "success":
            raise AssertionError(f"create {kind} {wanted_name!r} failed: {resp}")
        rid = get(resp, "result.id")
        created.append((delete_cmd, {"id": rid}))
        print(f"  OK    create {kind} {wanted_name!r} (id={rid})")

    # Real provisioning scripts usually leave the resources in place; this run
    # tracks what it created so a profile script can offer an --undo that tears
    # down exactly what it applied (deleting in reverse dependency order).
    return created


def main():
    p = argparse.ArgumentParser(
        description="Example provisioning script (idempotent). Template for per-profile deploy scripts."
    )
    p.add_argument("--config", default=None, help="Path to config file (default: api_test/config.json)")
    p.add_argument("--target", default=None, help="Target name in the config's 'targets' map (required)")
    p.add_argument("--name", default="example", help="Machine/profile name (used as name suffix)")
    p.add_argument("--dry-run", action="store_true", help="Preview every change without applying it")
    args = p.parse_args()

    client = build_client(args)
    try:
        deploy(client, args.name, dry_run=args.dry_run)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
