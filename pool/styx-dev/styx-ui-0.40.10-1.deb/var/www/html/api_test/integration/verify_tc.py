#!/usr/bin/env python3
"""Lifecycle verification for the Traffic Control module.

Basic (if0): clean qdisc -> add HTB qdisc -> add class 1:10 -> edit qdisc ->
delete class -> delete qdisc.
Advanced (if1): clean qdisc -> add HTB qdisc -> add classes 1:10/1:20(with child
sfq)/1:30 -> add u32/flower/matchall rules -> edit rule prio -> toggle rule
off/on -> delete rules -> delete classes -> delete qdisc.

Replaces the old payloads/submit/tc-basic.json + tc-advanced.json. Leaves no
residual state (cleanup also runs on failure).

Usage:
    python api_test/integration/verify_tc.py --target NAME
"""

import os
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish


def run(client):
    tracker = ResourceTracker()  # undo log: borra en orden inverso pase lo que pase
    remember = tracker.remember
    forget = tracker.forget

    def step(label, fn):
        fn()
        print(f"  OK   {label}")

    def iface_id(name):
        resp = require_ok(client.request("get_interfaces_names_ds"), "result.ifaces_list")
        for item in resp["result"]["ifaces_list"]:
            if item.get("interface") == name and item.get("id"):
                return item["id"]
        raise AssertionError(f"interface {name} not found in get_interfaces_names_ds")

    try:
        if0 = iface_id("if0")
        if1 = iface_id("if1")
        print(f"  OK   discovered if0={if0} if1={if1}")

        step(
            "tc_get_config",
            lambda: require_ok(client.request("tc_get_config"), "result.config.interfaces", "result.valid_qdisc"),
        )
        step("tc_get_stats", lambda: require_ok(client.request("tc_get_stats")))

        # basic on if0
        remember("delete_tc_qdisc", {"interface_uuid": if0})
        step("basic clean qdisc", lambda: require_ok(client.submit("delete_tc_qdisc", {"interface_uuid": if0})))
        step(
            "basic add HTB qdisc",
            lambda: require_ok(
                client.submit(
                    "add_tc_qdisc", {"interface_uuid": if0, "kind": "htb", "handle": "1:", "params": "default:10"}
                )
            ),
        )
        r = require_ok(
            client.submit(
                "add_tc_class",
                {
                    "interface_uuid": if0,
                    "parent": "1:",
                    "handle": "1:10",
                    "rate": "10mbit",
                    "ceil": "20mbit",
                    "classname": "Basic-Test-Class",
                },
            ),
            "result.id",
        )
        class_id = r["result"]["id"]
        remember("delete_tc_class", {"interface_uuid": if0, "id": class_id})
        print(f"  OK   basic add class 1:10 (id={class_id})")
        step(
            "basic edit qdisc",
            lambda: require_ok(
                client.submit(
                    "edit_tc_qdisc", {"interface_uuid": if0, "kind": "htb", "handle": "1:", "params": "default:20"}
                )
            ),
        )
        step(
            "basic delete class",
            lambda: require_ok(client.submit("delete_tc_class", {"interface_uuid": if0, "id": class_id})),
        )
        forget("delete_tc_class", {"interface_uuid": if0, "id": class_id})
        step("basic delete qdisc", lambda: require_ok(client.submit("delete_tc_qdisc", {"interface_uuid": if0})))
        forget("delete_tc_qdisc", {"interface_uuid": if0})

        # advanced on if1
        remember("delete_tc_qdisc", {"interface_uuid": if1})
        step("adv clean qdisc", lambda: require_ok(client.submit("delete_tc_qdisc", {"interface_uuid": if1})))
        step(
            "adv add HTB qdisc",
            lambda: require_ok(
                client.submit(
                    "add_tc_qdisc", {"interface_uuid": if1, "kind": "htb", "handle": "1:", "params": "default:10"}
                )
            ),
        )

        classes = {}  # handle -> id
        for handle, rate, ceil, prio, classname, child in [
            ("1:10", "50mbit", "100mbit", 1, "High-Priority", None),
            ("1:20", "10mbit", "50mbit", 5, "Bulk", {"kind": "sfq", "options": {"perturb": 10}}),
            ("1:30", "5mbit", "100mbit", 7, "Best-Effort", None),
        ]:
            data = {
                "interface_uuid": if1,
                "parent": "1:",
                "handle": handle,
                "rate": rate,
                "ceil": ceil,
                "prio": prio,
                "classname": classname,
            }
            if child:
                data["child_qdisc"] = child
            r = require_ok(client.submit("add_tc_class", data), "result.id")
            classes[handle] = r["result"]["id"]
            remember("delete_tc_class", {"interface_uuid": if1, "id": r["result"]["id"]})
            print(f"  OK   adv add class {handle} (id={r['result']['id']})")

        rules = {}  # name -> id
        rule_specs = [
            # matchall only accepts an action (drop/ok/pass/mirror) — no ip_proto,
            # no flowid. Use action "ok" so the classifier is exercised without
            # dropping/limiting traffic: an egress drop or police on a management
            # interface takes the device off the network.
            (
                "TCP-to-High",
                {
                    "interface_uuid": if1,
                    "direction": "egress",
                    "classifier": "u32",
                    "protocol": "ip",
                    "ip_proto": "tcp",
                    "parent": "1:",
                    "flowid": "1:10",
                    "prio": 10,
                },
            ),
            (
                "UDP-to-Bulk",
                {
                    "interface_uuid": if1,
                    "direction": "egress",
                    "classifier": "flower",
                    "protocol": "ip",
                    "ip_proto": "udp",
                    "parent": "1:",
                    "flowid": "1:20",
                    "prio": 20,
                },
            ),
            (
                "Accept-Rest",
                {
                    "interface_uuid": if1,
                    "direction": "egress",
                    "classifier": "matchall",
                    "protocol": "all",
                    "parent": "1:",
                    "action": "ok",
                    "prio": 99,
                },
            ),
        ]
        for name, data in rule_specs:
            r = require_ok(client.submit("add_tc_rule", dict(data, name=name)), "result.id")
            rules[name] = r["result"]["id"]
            remember("delete_tc_rule", {"id": r["result"]["id"]})
            print(f"  OK   adv add rule {name} (id={r['result']['id']})")

        step(
            "adv edit rule prio (10->5)",
            lambda: require_ok(client.submit("edit_tc_rule", {"id": rules["TCP-to-High"], "prio": 5})),
        )
        step(
            "adv toggle matchall off",
            lambda: require_ok(client.submit("toggle_tc_rule", {"id": rules["Accept-Rest"], "active": False})),
        )
        step(
            "adv toggle matchall on",
            lambda: require_ok(client.submit("toggle_tc_rule", {"id": rules["Accept-Rest"], "active": True})),
        )

        # explicit cleanup (rules -> classes -> qdisc)
        for name, rid in rules.items():
            require_ok(client.submit("delete_tc_rule", {"id": rid}))
            forget("delete_tc_rule", {"id": rid})
        print("  OK   adv delete rules")
        for handle, rid in classes.items():
            require_ok(client.submit("delete_tc_class", {"interface_uuid": if1, "id": rid}))
            forget("delete_tc_class", {"interface_uuid": if1, "id": rid})
        print("  OK   adv delete classes")
        require_ok(client.submit("delete_tc_qdisc", {"interface_uuid": if1}))
        forget("delete_tc_qdisc", {"interface_uuid": if1})
        print("  OK   adv delete qdisc")

    finally:
        tracker.cleanup(client)


def main():
    args = build_parser("Verify TC module: qdisc/class/rule lifecycle on if0+if1").parse_args()
    client = build_client(args)
    try:
        run(client)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
