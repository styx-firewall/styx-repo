#!/usr/bin/env python3
"""Lifecycle verification for virtual interfaces.

Covers every virtual interface subtype: dummy (loopback), veth, bridge, bond,
macvlan, vlan, vxlan, gre, vti, pppoe. Each is created for real and then
deleted; the resources they depend on (vlan/vni labels, address sets, a
destination-port set) are created as pre-requisites and cleaned up afterwards.

This flow subsumes the old payloads/submit/labels.json tests (labels are created
and deleted here) and the simple set tests, so those were dropped.

Replaces the old payloads/submit/create_virtual_interfaces.json. Leaves no
residual state.

Usage:
    python api_test/integration/verify_virtual_interfaces.py --target NAME
"""

import os
import secrets
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish


def run(client):
    tracker = ResourceTracker()  # undo log: borra en orden inverso pase lo que pase
    suffix = secrets.token_hex(4)
    remember = tracker.remember
    forget = tracker.forget

    def create_iface(label, data):
        resp = require_ok(client.submit("create_virtual_interface", data), "result.id")
        rid = resp["result"]["id"]
        remember("delete_virtual_interface", {"id": rid})
        print(f"  OK   {label} (id={rid})")
        return rid

    def del_iface(label, rid):
        data = {"id": rid}
        require_ok(client.submit("delete_virtual_interface", data))
        forget("delete_virtual_interface", data)
        print(f"  OK   {label}")

    def create_set(label, cmd, data, delete_cmd):
        resp = require_ok(client.submit(cmd, data), "result.id")
        rid = resp["result"]["id"]
        remember(delete_cmd, {"id": rid})
        print(f"  OK   {label} (id={rid})")
        return rid

    def del_set(label, delete_cmd, rid):
        data = {"id": rid}
        require_ok(client.submit(delete_cmd, data))
        forget(delete_cmd, data)
        print(f"  OK   {label}")

    def parent(subtype):
        """First valid parent UUID for a subtype, or None if the machine has none.

        Interface subtypes that need a parent (vlan/macvlan/pppoe) are skipped
        when the machine offers no valid parent.
        """
        resp = require_ok(client.request("get_valid_parents", {"iface_subtype": subtype}), "result.interfaces")
        ifaces = resp["result"]["interfaces"]
        return ifaces[0]["id"] if ifaces else None

    def skip(subtype):
        print(f"  SKIP {subtype} (no valid parent on this machine)")

    try:
        # pre-requisites (sets/labels used by the interfaces) ---------
        # Created first so cleanup runs last on them.
        vlan_label = create_set(
            "label vlan",
            "sets-mgmt.set_label",
            {"type": "vlans", "name": f"vt-vlan-{suffix}", "value": "100"},
            "sets-mgmt.delete_label",
        )
        addr_local = create_set(
            "address local",
            "set_address",
            {"type": "single", "family": "ip", "name": f"vt-local-{suffix}", "value_single": "10.99.99.1"},
            "delete_address",
        )
        addr_remote = create_set(
            "address remote",
            "set_address",
            {"type": "single", "family": "ip", "name": f"vt-remote-{suffix}", "value_single": "10.99.99.2"},
            "delete_address",
        )
        vni_label = create_set(
            "label vni",
            "sets-mgmt.set_label",
            {"type": "vni", "name": f"vt-vni-{suffix}", "value": "10000"},
            "sets-mgmt.delete_label",
        )
        port_dst = create_set(
            "port dstport",
            "set_port",
            {"type": "single", "name": f"vt-dport-{suffix}", "value_single": 4789},
            "delete_port",
        )

        # parents (machine-dependent; subtypes without parent are skipped) ----
        vlan_parent = parent("vlan")
        macvlan_parent = parent("macvlan")
        pppoe_parent = parent("pppoe")
        print(
            "  OK   discovered parents "
            f"(vlan={vlan_parent or 'none'} macvlan={macvlan_parent or 'none'} "
            f"pppoe={pppoe_parent or 'none'})"
        )

        # dummy (loopback)
        loop_id = create_iface(
            "create loopback (dummy)", {"iface_subtype": "dummy", "iface_name": f"lo-vt-{suffix}", "status": "up"}
        )
        del_iface("delete loopback", loop_id)

        # veth pair
        r = require_ok(
            client.submit(
                "create_virtual_interface",
                {
                    "iface_subtype": "veth",
                    "iface_name": f"vt-va-{suffix}",
                    "peer_name": f"vt-vb-{suffix}",
                    "status": "up",
                },
            ),
            "result.id",
            "result.peer_id",
        )
        veth_a, veth_peer = r["result"]["id"], r["result"]["peer_id"]
        remember("delete_virtual_interface", {"id": veth_a})
        print(f"  OK   create veth (id={veth_a} peer={veth_peer})")

        # bridge (veth pair as ports)
        bridge_id = create_iface(
            "create bridge",
            {
                "iface_subtype": "bridge",
                "iface_name": f"br-vt-{suffix}",
                "ports": [veth_a, veth_peer],
                "stp": True,
                "status": "up",
            },
        )
        del_iface("delete bridge", bridge_id)

        # bond (veth pair as slaves)
        bond_id = create_iface(
            "create bond",
            {
                "iface_subtype": "bond",
                "iface_name": f"bd-vt-{suffix}",
                "mode": "active-backup",
                "slaves": [veth_a, veth_peer],
                "status": "up",
            },
        )
        del_iface("delete bond", bond_id)

        del_iface("delete veth", veth_a)

        # macvlan
        if macvlan_parent:
            macvlan_id = create_iface(
                "create macvlan",
                {
                    "iface_subtype": "macvlan",
                    "parent_iface": macvlan_parent,
                    "iface_name": f"mv-{suffix}",
                    "macvlan_mode": "bridge",
                    "status": "up",
                },
            )
            del_iface("delete macvlan", macvlan_id)
        else:
            skip("macvlan")

        # vlan
        if vlan_parent:
            vlan_id = create_iface(
                "create vlan",
                {
                    "iface_subtype": "vlan",
                    "parent_iface": vlan_parent,
                    "vlan_id": vlan_label,
                    "status": "up",
                    "mtu": 1500,
                },
            )
            del_iface("delete vlan", vlan_id)
        else:
            skip("vlan")

        # vxlan
        vxlan_id = create_iface(
            "create vxlan",
            {
                "iface_subtype": "vxlan",
                "iface_name": f"vxlan-{suffix}",
                "vni": vni_label,
                "local_ip": addr_local,
                "dstport": port_dst,
                "nolearning": True,
                "status": "up",
            },
        )
        del_iface("delete vxlan", vxlan_id)

        # gre / vti
        gre_id = create_iface(
            "create gre",
            {
                "iface_subtype": "gre",
                "iface_name": f"gre-{suffix}",
                "local": addr_local,
                "remote": addr_remote,
                "gre_ttl": 64,
                "status": "up",
            },
        )
        del_iface("delete gre", gre_id)

        vti_id = create_iface(
            "create vti",
            {
                "iface_subtype": "vti",
                "iface_name": f"vti-{suffix}",
                "local": addr_local,
                "remote": addr_remote,
                "status": "up",
            },
        )
        del_iface("delete vti", vti_id)

        # pppoe
        if pppoe_parent:
            pppoe_id = create_iface(
                "create pppoe",
                {
                    "iface_subtype": "pppoe",
                    "iface_name": f"ppp-vt-{suffix}",
                    "parent_iface": pppoe_parent,
                    "pppoe": {"username": "test@isp", "password": "testpass"},
                    "status": "down",
                },
            )
            del_iface("delete pppoe", pppoe_id)
        else:
            skip("pppoe")

        # cleanup pre-requisites
        del_set("cleanup port dstport", "delete_port", port_dst)
        del_set("cleanup label vni", "sets-mgmt.delete_label", vni_label)
        del_set("cleanup label vlan", "sets-mgmt.delete_label", vlan_label)
        del_set("cleanup address remote", "delete_address", addr_remote)
        del_set("cleanup address local", "delete_address", addr_local)

    finally:
        tracker.cleanup(client)


def main():
    args = build_parser("Verify virtual interfaces: create/delete for every subtype").parse_args()
    client = build_client(args)
    try:
        run(client)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
