#!/usr/bin/env python3
"""Lifecycle verification for certificate upload and detection.

Real flow against the HTTP API: uploads a CA certificate (single) and a leaf
certificate + private key (pair), then verifies each was detected correctly by
reading it back with ``get_certificate(id, include_metadata=true)`` and
asserting the parsed metadata (type, is_ca, subject, fingerprint, key_size,
status/dates, and for the pair that the private key was found and matched).
Finally deletes both and asserts they are gone. Leaves no residue.

The PEM fixtures are generated on the fly with the system ``openssl`` (unique
CN per run), so nothing is committed and no cryptography dependency is needed;
the expected sha256 fingerprint of each generated cert is computed from its DER
and compared against the one the backend reports.

Usage:
    python api_test/integration/verify_certificates.py --target NAME
"""

import base64
import hashlib
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, get, require_ok
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish

UTC_DATE = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} UTC$")


def _run_openssl(args):
    """Run openssl, raising AssertionError with stderr on failure."""
    if shutil.which("openssl") is None:
        raise AssertionError("openssl not found on PATH; required to generate the test certificates")
    try:
        return subprocess.run(["openssl"] + args, capture_output=True, check=True)
    except subprocess.CalledProcessError as e:
        raise AssertionError(f"openssl {' '.join(args)} failed: {e.stderr.decode(errors='replace')}")


def _b64(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")


def _der_sha256(path):
    der = _run_openssl(["x509", "-in", path, "-outform", "DER"]).stdout
    return hashlib.sha256(der).hexdigest()


def _generate_fixtures(tmp, suffix):
    """Create a throwaway CA (single) and leaf cert+key (pair) with openssl.

    Returns base64 contents plus the expected sha256 fingerprint (of the DER)
    and subject CN for each, so the test can assert what the backend detected.
    """
    ca_pem, ca_key = os.path.join(tmp, "ca.pem"), os.path.join(tmp, "ca.key")
    leaf_pem, leaf_key = os.path.join(tmp, "leaf.pem"), os.path.join(tmp, "leaf.key")
    ca_subj = f"/CN=styx-test-ca-{suffix}/O=Styx Test"
    leaf_subj = f"/CN=styx-test-leaf-{suffix}/O=Styx Test"

    _run_openssl(
        [
            "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-sha256",
            "-keyout", ca_key, "-out", ca_pem, "-days", "7300",
            "-subj", ca_subj,
            "-addext", "basicConstraints=critical,CA:TRUE",
            "-addext", "keyUsage=critical,keyCertSign,cRLSign",
        ]
    )
    _run_openssl(
        [
            "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-sha256",
            "-keyout", leaf_key, "-out", leaf_pem, "-days", "730",
            "-subj", leaf_subj,
            "-addext", "basicConstraints=CA:FALSE",
            "-addext", "keyUsage=critical,digitalSignature,keyEncipherment",
            "-addext", "extendedKeyUsage=serverAuth",
        ]
    )
    return {
        "ca_b64": _b64(ca_pem),
        "leaf_b64": _b64(leaf_pem),
        "leaf_key_b64": _b64(leaf_key),
        "ca_fingerprint": _der_sha256(ca_pem),
        "leaf_fingerprint": _der_sha256(leaf_pem),
        "ca_cn": f"styx-test-ca-{suffix}",
        "leaf_cn": f"styx-test-leaf-{suffix}",
    }


def _norm_fingerprint(value):
    """Normalize a fingerprint to lowercase hex without colons for comparison."""
    return str(value or "").replace(":", "").lower()


def _find_cert_id(client, file_name, kind):
    """Resolve the datastore id of an uploaded cert via sys_get_certs."""
    resp = require_ok(client.request("sys_get_certs"), "result.certificates")
    items = get(resp, "result.certificates") or []
    for item in items:
        name = item.get("file_name") or os.path.basename(item.get("cert_path") or "")
        if name == file_name and item.get("id"):
            return item["id"]
    raise AssertionError(f"{kind}: uploaded certificate {file_name!r} not found in sys_get_certs")


def _detail(client, cert_id, kind):
    resp = require_ok(client.request("get_certificate", {"id": cert_id, "include_metadata": True}), "result.certificate")
    return get(resp, "result.certificate")


def _assert_gone(client, cert_id, kind):
    """Delete is authoritative in the datastore; sys_get_certs may be cached."""
    resp = client.request("get_certificate", {"id": cert_id})
    if get(resp, "status") == "success":
        raise AssertionError(f"{kind}: certificate {cert_id} still present after delete")
    print(f"  OK   {kind}: gone after delete")


def run(client):
    tracker = ResourceTracker()  # undo log: borra en orden inverso pase lo que pase
    suffix = secrets.token_hex(4)
    tmp = tempfile.mkdtemp(prefix="styx-cert-test-")

    try:
        fx = _generate_fixtures(tmp, suffix)

        # --- Scenario A: CA uploaded single (no private key) -----------------
        ca_fname = f"vt-ca-{suffix}.pem"
        up_ca = client.submit(
            "upload_certificate", {"type": "single", "cert_b64": fx["ca_b64"], "file_name": ca_fname}
        )
        require_ok(up_ca)
        ca_id = get(up_ca, "result.certificate.id") or _find_cert_id(client, ca_fname, "CA")
        tracker.remember("delete_certificate", {"id": ca_id})
        print(f"  OK   uploaded CA (id={ca_id})")

        ca = _detail(client, ca_id, "CA")
        assert ca["type"] == "CERT", ca
        assert ca["is_ca"] is True, ca
        assert ca["has_key"] is False, ca
        assert f"CN={fx['ca_cn']}" in (ca.get("subject") or ""), ca
        assert _norm_fingerprint(ca.get("fingerprint_sha256")) == fx["ca_fingerprint"], ca
        assert ca.get("key_algorithm") == "RSA", ca
        assert ca.get("key_size") == 2048, ca
        assert ca.get("status") == "valid", ca
        assert ca.get("format") == "PEM", ca
        assert ca.get("expiration") and UTC_DATE.match(ca["expiration"]), ca
        assert ca.get("not_before") and UTC_DATE.match(ca["not_before"]), ca
        print("  OK   CA detected: type/is_ca/subject/fingerprint/dates/key_size correct")

        # Explicit delete, then assert gone (authoritative in the datastore).
        require_ok(client.submit("delete_certificate", {"id": ca_id}))
        tracker.forget("delete_certificate", {"id": ca_id})
        _assert_gone(client, ca_id, "CA")

        # --- Scenario B: leaf certificate + private key (pair) --------------
        leaf_fname = f"vt-leaf-{suffix}.pem"
        up_pair = client.submit(
            "upload_certificate",
            {
                "type": "pair",
                "cert_b64": fx["leaf_b64"],
                "key_b64": fx["leaf_key_b64"],
                "file_name": leaf_fname,
                "key_file_name": f"vt-leaf-key-{suffix}.pem",
            },
        )
        require_ok(up_pair)
        leaf_id = get(up_pair, "result.certificate.id")
        leaf_key_id = get(up_pair, "result.key.id")
        if not (leaf_id and leaf_key_id):
            raise AssertionError(
                "upload_certificate did not return result.certificate.id / result.key.id; "
                "cannot verify/clean a pair (the front must forward the gateway result)"
            )
        tracker.remember("delete_certificate", {"id": leaf_id})
        tracker.remember("delete_certificate", {"id": leaf_key_id})
        print(f"  OK   uploaded leaf pair (cert={leaf_id} key={leaf_key_id})")

        leaf = _detail(client, leaf_id, "leaf")
        assert leaf["type"] == "CERT", leaf
        assert leaf["is_ca"] is False, leaf
        assert leaf["has_key"] is True, leaf
        assert (leaf.get("matched_key_path") or "").endswith(leaf_fname), leaf
        assert leaf.get("key_present_on_disk") is True, leaf
        assert leaf.get("has_key_embedded") is False, leaf
        assert f"CN={fx['leaf_cn']}" in (leaf.get("subject") or ""), leaf
        assert _norm_fingerprint(leaf.get("fingerprint_sha256")) == fx["leaf_fingerprint"], leaf
        assert leaf.get("status") == "valid", leaf
        print("  OK   leaf detected: type/is_ca/has_key/matched_key_path/subject/fingerprint correct")

        # Explicit delete of both (key first), then assert they are gone.
        require_ok(client.submit("delete_certificate", {"id": leaf_key_id}))
        tracker.forget("delete_certificate", {"id": leaf_key_id})
        require_ok(client.submit("delete_certificate", {"id": leaf_id}))
        tracker.forget("delete_certificate", {"id": leaf_id})
        _assert_gone(client, leaf_key_id, "leaf key")
        _assert_gone(client, leaf_id, "leaf cert")
    finally:
        tracker.cleanup(client)
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    parser = build_parser("Certificate upload + detection lifecycle (real)")
    args = parser.parse_args()
    client = build_client(args)
    try:
        run(client)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
