# Route Rules — Policy-based routing (ip rule)

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Create/update route rule | `POST /submit.php` | `command: "set_routing_rule"` |
| Preview route rule | `POST /submit.php` | `command: "preview_routing_rule"` |
| Delete route rule | `POST /submit.php` | `command: "delete_routing_rule"` |
| Toggle route rule | `POST /submit.php` | `command: "toggle_routing_rule"` |
| Get route rules page data | `POST /request.php` | `action: "get_routing_rules_page_data"` |

> **Note:** `update_routing_rule` is registered in the `SubmitRegistry` but its gateway backend method is **not yet implemented** (marked TODO in the controller). Use `set_routing_rule` with the `id` parameter to update existing rules instead.

## Common concepts

Route rules (Linux `ip rule`) implement policy-based routing. Each rule selects traffic based on match conditions (source/destination address, interface, port, fwmark, protocol) and routes it via a specific routing table.

### Set-based addressing

All references to addresses, ports, interfaces, and marks use **UUIDs** referencing pre-existing sets:

| Field type | Source | Examples |
|---|---|---|
| `src`, `dst` | Address set (via `set_address`) | `uuid-address-set-lan` |
| `iif` | Interface set (via `set_interface_set`) | `uuid-iface-set-wan` |
| `sport`, `dport` | Port set (via `set_port`) | `uuid-port-set-ssh` |
| `mark` | Fwmark label (via `sets-mgmt.set_label`, type `packet_marking`) | `uuid-mark-label-voip` |
| `table` | Routing table label (via `sets-mgmt.set_label`, type `routing_tables`) | `uuid-routing-table-corp` |

### Actions

| Action | Description |
|---|---|
| `lookup` | Route traffic via the specified `table` |
| `unreachable` | Reject with ICMP unreachable |
| `prohibit` | Reject with ICMP prohibited |
| `blackhole` | Silently discard the packet |

---

# submit.php — Write operations

All submit operations return the **command response object** from the gateway, which includes `id`, `method`, `status`, `result`, and optionally `response_msg` for errors.

---

## `set_routing_rule`

Creates a new route rule or updates an existing one (if `id` is provided).

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ❌ | Rule UUID to edit (omit to create) |
| `name` | `string` | ✅ | Rule name (non-empty) |
| `priority` | `integer` | ❌ | Rule priority (0–32767, lower = higher priority). Auto-assigned when omitted |
| `invert` | `boolean` | ❌ | Invert match conditions (`true` = match everything except the specified criteria). Default: `false` |
| `mark` | `string` (UUID) | ❌ | Fwmark label UUID (from label type `packet_marking`) |
| `src` | `string` (UUID) | ❌ | Source address set UUID |
| `dst` | `string` (UUID) | ❌ | Destination address set UUID |
| `iif` | `string` (UUID) | ❌ | Input interface set UUID |
| `proto` | `string` | ❌ | Protocol: `"tcp"`, `"udp"`, `"icmp"`, `"icmpv6"` |
| `sport` | `string` (UUID) | ❌ | Source port set UUID. Requires `proto` = `tcp` or `udp` |
| `dport` | `string` (UUID) | ❌ | Destination port set UUID. Requires `proto` = `tcp` or `udp` |
| `action` | `string` | ✅ | `"lookup"`, `"unreachable"`, `"prohibit"`, `"blackhole"` |
| `table` | `string` (UUID) | ❌ | UUID of a **routing_tables label set**. Required when `action` = `"lookup"` |
| `active` | `boolean` | ❌ | Whether the rule is active. Default: `true` |

### Request — create

```json
{
  "command": "set_routing_rule",
  "name": "Route VoIP traffic to table 100",
  "priority": 100,
  "proto": "udp",
  "dport": "uuid-port-set-sip",
  "action": "lookup",
  "table": "uuid-routing-table-voip",
  "active": true
}
```

### Request — with source and destination

```json
{
  "command": "set_routing_rule",
  "name": "Route LAN to WAN via table 200",
  "priority": 200,
  "src": "uuid-address-set-lan",
  "dst": "uuid-address-set-any",
  "iif": "uuid-iface-set-lan",
  "action": "lookup",
  "table": "uuid-routing-table-corp",
  "active": true
}
```

### Request — invert match

```json
{
  "command": "set_routing_rule",
  "name": "Route all except mgmt traffic",
  "priority": 300,
  "invert": true,
  "iif": "uuid-iface-set-mgmt",
  "action": "lookup",
  "table": "uuid-routing-table-main",
  "active": true
}
```

### Response (success)

```json
{
  "id": "set_routing_rule",
  "method": "routing-rules.set_routing_rule",
  "status": "success",
  "result": {
    "id": "route-rule-uuid-1",
    "ip_run": "ip rule add priority 100 dport 5060 lookup 100"
  }
}
```

| Field | Type | Description |
|---|---|---|
| `id` | `string` | Command identifier (`"set_routing_rule"`) |
| `method` | `string` | Gateway method (`"routing-rules.set_routing_rule"`) |
| `status` | `string` | `"success"` or `"error"` |
| `result.id` | `string` (UUID) | Rule UUID (newly created or updated) |
| `result.ip_run` | `string` | The `ip rule` command that was built/executed |

### Response (error)

```json
{
  "id": "set_routing_rule",
  "method": "routing-rules.set_routing_rule",
  "status": "error",
  "response_msg": "Rule name is required"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "set_routing_rule",
    "name": "Route VoIP",
    "priority": 100,
    "proto": "udp",
    "dport": "uuid-port-set-sip",
    "action": "lookup",
    "table": "uuid-routing-table-voip",
    "active": true
  }' | jq
```

---

## `preview_routing_rule`

Validates a route rule without persisting it or applying to the OS. Accepts the same parameters as `set_routing_rule`.

### Request

```json
{
  "command": "preview_routing_rule",
  "name": "Preview VoIP rule",
  "priority": 100,
  "proto": "udp",
  "dport": "uuid-port-set-sip",
  "action": "lookup",
  "table": "uuid-routing-table-voip"
}
```

### Response (success)

```json
{
  "id": "preview_routing_rule",
  "method": "routing-rules.preview_routing_rule",
  "status": "success",
  "result": {
    "ip_run": "ip rule add priority 100 dport 5060 lookup 100"
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.ip_run` | `string` | The `ip rule` command that would be executed |

---

## `delete_routing_rule`

Deletes a route rule by UUID.

### Parameters

The payload can be either a plain string (the UUID) or an object:

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Rule UUID |

### Request

```json
{
  "command": "delete_routing_rule",
  "id": "route-rule-uuid-1"
}
```

### Response (success)

```json
{
  "id": "delete_routing_rule",
  "method": "routing-rules.delete_routing_rule",
  "status": "success",
  "result": {
    "id": "route-rule-uuid-1"
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.id` | `string` (UUID) | UUID of the deleted rule |

---

## `toggle_routing_rule`

Enables or disables a route rule.

### Parameters

The payload can be either a plain string (the UUID) or an object:

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Rule UUID |
| `active` | `boolean` | ❌ | Desired active state (`true` = active, `false` = inactive). Omit to flip the current state |

### Request

```json
{
  "command": "toggle_routing_rule",
  "id": "route-rule-uuid-1",
  "active": false
}
```

### Response (success)

```json
{
  "id": "toggle_routing_rule",
  "method": "routing-rules.toggle_routing_rule",
  "status": "success",
  "result": {
    "id": "route-rule-uuid-1",
    "active": false
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.id` | `string` (UUID) | UUID of the toggled rule |
| `result.active` | `boolean` | New active state after the toggle |

---

# request.php — Read operations

---

## `get_routing_rules_page_data`

Returns all route rules with resolved display fields for the UI.

### Parameters

None.

### Request

```json
{
  "action": "get_routing_rules_page_data"
}
```

### Response (success)

```json
{
  "status": "success",
  "warnings": [],
  "result": {
    "rules": [
      {
        "id": "route-rule-uuid-1",
        "uuid": "route-rule-uuid-1",
        "name": "Route VoIP traffic to table 100",
        "priority": 100,
        "invert": false,
        "mark": null,
        "mark_display": null,
        "src": null,
        "src_display": null,
        "dst": null,
        "dst_display": null,
        "iif": null,
        "iif_display": null,
        "proto": "udp",
        "sport": null,
        "sport_display": null,
        "dport": "uuid-port-set-sip",
        "dport_display": {
          "id": "uuid-port-set-sip",
          "name": "SIP ports",
          "value": "5060,5061"
        },
        "action": "lookup",
        "table": "uuid-routing-table-voip",
        "table_display": {
          "id": "uuid-routing-table-voip",
          "name": "VoIP Table",
          "value": "100"
        },
        "active": true,
        "created_at": 1714000000,
        "updated_at": 1714000000
      }
    ]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `status` | `string` | `"success"` or `"error"` |
| `warnings` | `string[]` | Warning messages (may be empty) |
| `result.rules[]` | `array` | Array of route rule objects |
| `result.rules[].id` | `string` (UUID) | Rule UUID |
| `result.rules[].uuid` | `string` (UUID) | Rule UUID (alias for `id`, added by controller for compatibility) |
| `result.rules[].name` | `string` | Rule name |
| `result.rules[].priority` | `integer` \| `null` | Rule priority (0–32767) |
| `result.rules[].invert` | `boolean` | Whether match is inverted |
| `result.rules[].active` | `boolean` | Whether the rule is active |
| `result.rules[].action` | `string` | Rule action: `"lookup"`, `"unreachable"`, `"prohibit"`, `"blackhole"` |
| `result.rules[].proto` | `string` \| `null` | Protocol filter: `"tcp"`, `"udp"`, `"icmp"`, `"icmpv6"`, or `null` |
| `result.rules[].mark` | `string` (UUID) \| `null` | Fwmark label UUID |
| `result.rules[].src` | `string` (UUID) \| `null` | Source address set UUID |
| `result.rules[].dst` | `string` (UUID) \| `null` | Destination address set UUID |
| `result.rules[].iif` | `string` (UUID) \| `null` | Input interface set UUID |
| `result.rules[].sport` | `string` (UUID) \| `null` | Source port set UUID |
| `result.rules[].dport` | `string` (UUID) \| `null` | Destination port set UUID |
| `result.rules[].table` | `string` (UUID) \| `null` | Routing table label UUID |
| `result.rules[].created_at` | `integer` | Unix timestamp of creation |
| `result.rules[].updated_at` | `integer` | Unix timestamp of last update |
| `result.rules[].mark_display` | `object` \| `null` | Resolved fwmark label: `{id, name, value}` |
| `result.rules[].src_display` | `object` \| `null` | Resolved source address set: `{id, name, value, family}` |
| `result.rules[].dst_display` | `object` \| `null` | Resolved destination address set: `{id, name, value, family}` |
| `result.rules[].iif_display` | `object` \| `null` | Resolved interface set: `{id, name, value}` |
| `result.rules[].sport_display` | `object` \| `null` | Resolved source port set: `{id, name, value}` |
| `result.rules[].dport_display` | `object` \| `null` | Resolved destination port set: `{id, name, value}` |
| `result.rules[].table_display` | `object` \| `null` | Resolved routing table label: `{id, name, value}` |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_routing_rules_page_data"}' | jq
```

---

## Important notes

1. **Priority:** If omitted, the kernel auto-assigns a priority. It is strongly recommended to always provide an explicit priority (0–32767).

2. **Sets and labels:** All match fields (`src`, `dst`, `iif`, `sport`, `dport`, `mark`, `table`) require **UUIDs** referencing pre-existing sets or label sets. Raw values (e.g., `"100"` for table, `"10.0.0.0/8"` for address) are **not** accepted at the API level — the gateway resolves the UUID to the actual value internally.

3. **Fwmark labels:** The `mark` field requires a **label UUID** from `sets-mgmt.set_label` with type `packet_marking`, not a raw numeric mark.

4. **Routing table labels:** The `table` field requires a **label UUID** from `sets-mgmt.set_label` with type `routing_tables`. The label's value will be the numeric table ID.

5. **Match conditions:** At least one matcher (`src`, `dst`, `iif`, `mark`, `sport`, `dport`, `proto`) should be provided. A rule with no matchers matches all traffic.

6. **Action is required:** Unlike what the old table implied, `action` is a required field (per the schema). While `"lookup"` is the common default, the API will reject a request without an explicit action.

7. **Active state:** Disabled rules are persisted in the datastore but not applied to the OS (`ip rule`).

8. **Resolved display fields:** The `get_routing_rules_page_data` response includes `*_display` objects with resolved names and values for display in the UI. These are populated by the gateway — the API controller passes them through without modification.

9. **`id` vs `uuid`:** Rule objects in the `get_routing_rules_page_data` response contain both `id` and `uuid` fields (same value) for compatibility. The underlying gateway schema uses `id`; the API controller normalizes both.

---

## References

- PHP implementation (submit): `App\Controllers\Submit\RouteRulesSubmitController`
- PHP implementation (request): `App\Controllers\Request\RouteRulesRequestController`
- Frontend JS: `scripts/network/net-routing-rules.js`
- Backend schemas: `api/schemas/routing_rules/{requests,responses}/*.json`
