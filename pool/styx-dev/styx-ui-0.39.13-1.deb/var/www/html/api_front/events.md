# Events — System event log

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Toggle event ack | `POST /submit.php` | `command: "toggle_ack"` |
| Get events | `POST /request.php` | `action: "styx_get_events"` |

This page covers event-related operations. Events are also documented under [styx.md](styx.md) as part of the Styx management interface. This page provides additional detail on event fields and filtering.

---

# submit.php — Write operations

---

## `toggle_ack`

Toggles the acknowledgement flag on an event.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `event_id` | `string` (UUID) | ✅ | Event UUID |

### Request

```json
{
  "command": "toggle_ack",
  "event_id": "123e4567-e89b-12d3-a456-426614174000"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Event ack toggled",
  "result": {
    "event_id": "123e4567-e89b-12d3-a456-426614174000"
  }
}
```

---

# request.php — Read operations

---

## `styx_get_events`

Returns events from the event manager.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `limit` | `integer` | ❌ | Maximum number of events (default: 50) |
| `event_type` | `integer` | ❌ | Filter by event type code |
| `level` | `integer` | ❌ | Filter by minimum log level |
| `message_contains` | `string` | ❌ | Filter by message substring |

### Request

```json
{
  "action": "styx_get_events",
  "limit": 50,
  "level": 3
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Events retrieved",
  "result": {
    "events": [
      {
        "id": "123e4567-e89b-12d3-a456-426614174000",
        "timestamp": 1720180000.0,
        "timestamp_iso": "2026-03-18T12:34:56Z",
        "event_type": 701,
        "event_name": "EVENT_FIREWALL_ALERT",
        "message": "Firewall rule matched",
        "data": { "rule_id": 42 },
        "level": 1,
        "level_name": "ALERT",
        "ack": 0
      }
    ]
  }
}
```

### Event fields

| Field | Type | Description |
|---|---|---|
| `id` | `string` (UUID) | Event UUID |
| `timestamp` | `number` | Epoch timestamp (seconds) |
| `timestamp_iso` | `string` (ISO8601) | UTC timestamp for display |
| `event_type` | `integer` | Numeric event type code |
| `event_name` | `string` | Human-readable event name (e.g. `EVENT_FIREWALL_ALERT`) |
| `message` | `string` | Short event description |
| `data` | `object` \| `null` | Optional event-specific payload |
| `level` | `integer` | Numeric log level |
| `level_name` | `string` | Level name (`INFO`, `ALERT`, etc.) |
| `ack` | `integer` | Acknowledgement flag (`0` = not acked, `1` = acked) |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "styx_get_events", "limit": 10}' | jq
```

---

## Important notes

1. **Event timestamps** are provided in both formats. Use `timestamp` (epoch) for sorting/comparison and `timestamp_iso` for display.

2. **Event types** are numeric codes. Common types include firewall alerts, system events, and SLA monitor notifications.

3. **Acknowledgement:** The `ack` field is an integer (`0` or `1`), not a boolean. Use `toggle_ack` to flip it.

---

## References

- Backend handler: `api/handlers/event_manager.md`
- PHP implementation: `App\Controllers\Submit\EventSubmitController`
