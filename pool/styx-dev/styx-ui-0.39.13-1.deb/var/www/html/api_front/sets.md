# Sets — Address, port, interface, and domain sets

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Create/update address set | `POST /submit.php` | `command: "set_address"` |
| Create/update port set | `POST /submit.php` | `command: "set_port"` |
| Create/update interface set | `POST /submit.php` | `command: "set_interface_set"` |
| Create/update domain set | `POST /submit.php` | `command: "set_domain"` |
| Set label | `POST /submit.php` | `command: "sets-mgmt.set_label"` |
| Delete label | `POST /submit.php` | `command: "sets-mgmt.delete_label"` |
| Delete address set | `POST /submit.php` | `command: "delete_address"` |
| Delete port set | `POST /submit.php` | `command: "delete_port"` |
| Delete interface set | `POST /submit.php` | `command: "delete_interface_set"` |
| Delete domain set | `POST /submit.php` | `command: "delete_domain"` |
| Get address sets | `POST /request.php` | `action: "get_address"` |
| Get port sets | `POST /request.php` | `action: "get_ports"` |
| Get interface sets | `POST /request.php` | `action: "get_interfaces_sets"` |
| Get domain sets | `POST /request.php` | `action: "get_domains"` |
| Get all sets (combined) | `POST /request.php` | `action: "getFullSets"` |
| Get labels | `POST /request.php` | `action: "get_labels"` |

## Common concepts

Sets are the fundamental building blocks used throughout the API. Instead of sending literal IPs, ports, or interface names, you create **sets** and reference them by UUID in other commands (firewall rules, routes, DHCP config, interfaces, etc.).

### Set types summary

| Set type | `type` values | Description |
|---|---|---|
| Address (`set_address`) | `"single"`, `"set"`, `"range"` | IP addresses and CIDR networks (IPv4 and IPv6) |
| Port (`set_port`) | `"single"`, `"range"`, `"set"` | TCP/UDP port numbers |
| Interface (`set_interface_set`) | `"single"`, `"set"` | Network interface names |
| Domain (`set_domain`) | `"single"`, `"set"` | FQDN domain names |

### Tags (optional)

All create/update commands accept an optional `tags` field: an array of tag strings (`^[A-Za-z0-9_-]{1,50}$`, max 50 tags).

---

# submit.php — Write operations

---

## `set_address`

Creates or updates an address set (IP addresses or CIDR networks).

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | `string` | ✅ | `"single"`, `"set"`, or `"range"` |
| `family` | `string` | ✅ | `"ip"` (IPv4) or `"ip6"` (IPv6) |
| `name` | `string` | ✅ | Set name (nftables-compatible) |
| `value_single` | `string` | depends | Single IP or CIDR (required when `type: "single"`) |
| `value_set` | `string[]` | depends | List of IPs, CIDRs or ranges (required when `type: "set"`) |
| `value_range_start` | `string` | depends | Range start IP (required when `type: "range"`) |
| `value_range_end` | `string` | depends | Range end IP (required when `type: "range"`) |
| `tags` | `string[]` | ❌ | Optional tags |

> **⚠️ Note:** CIDRs with host bits set (e.g. `172.20.4.10/22`) are stored with `scope: "host_prefix"`. This is intended for interface/VPN assignment and is considered ambiguous for firewall use. Firewall consumers accept only `host` or `network` scopes.

### Request examples

**Single IP (IPv4):**

```json
{
  "command": "set_address",
  "type": "single",
  "family": "ip",
  "name": "single_host",
  "value_single": "192.0.2.5"
}
```

**Address set (multiple networks):**

```json
{
  "command": "set_address",
  "type": "set",
  "family": "ip",
  "name": "networks",
  "value_set": ["10.0.0.0/8", "198.51.100.0/24", "203.0.113.5-203.0.113.10"],
  "tags": ["private", "v4"]
}
```

**IP range (IPv6):**

```json
{
  "command": "set_address",
  "type": "range",
  "family": "ip6",
  "name": "v6_block",
  "value_range_start": "2001:db8::1",
  "value_range_end": "2001:db8::ffff"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Address configuration saved",
  "result": {
    "id": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.id` | `string` (UUID) | Address set identifier — use this UUID to reference this set elsewhere |

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Validation failed: name is required"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "set_address",
    "type": "single",
    "family": "ip",
    "name": "dns_server",
    "value_single": "8.8.8.8"
  }' | jq
```

---

## `set_port`

Creates or updates a port set.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | `string` | ✅ | `"single"`, `"range"`, or `"set"` |
| `name` | `string` | ✅ | Set name |
| `value_single` | `integer` | depends | Single port (1–65535). Required when `type: "single"` |
| `value_set` | `array` | depends | List of ports and/or ranges (e.g. `[22, "80-90", 443]`). Required when `type: "set"` |
| `value_range_start` | `integer` | depends | Range start port. Required when `type: "range"` |
| `value_range_end` | `integer` | depends | Range end port. Required when `type: "range"` |
| `tags` | `string[]` | ❌ | Optional tags |

### Request examples

**Single port:**

```json
{
  "command": "set_port",
  "type": "single",
  "name": "ssh_port",
  "value_single": 22
}
```

**Port range:**

```json
{
  "command": "set_port",
  "type": "range",
  "name": "ephemeral",
  "value_range_start": 30000,
  "value_range_end": 32767
}
```

**Port set (mixed):**

```json
{
  "command": "set_port",
  "type": "set",
  "name": "web_and_custom",
  "value_set": [80, "443", "10000-10010"]
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Port configuration saved",
  "result": {
    "id": "bbbbbbbb-cccc-dddd-eeee-ffffffffffff"
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "set_port",
    "type": "single",
    "name": "https_port",
    "value_single": 443
  }' | jq
```

---

## `set_interface_set`

Creates or updates an interface set (group of network interface names).

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | `string` | ✅ | `"single"` or `"set"` |
| `name` | `string` | ✅ | Set name |
| `value_single` | `string` | depends | Interface name (required when `type: "single"`) |
| `value_set` | `string[]` | depends | List of interface names (required when `type: "set"`) |
| `tags` | `string[]` | ❌ | Optional tags |

### Request examples

**Single interface:**

```json
{
  "command": "set_interface_set",
  "type": "single",
  "name": "wan_iface",
  "value_single": "eth0"
}
```

**Multiple interfaces:**

```json
{
  "command": "set_interface_set",
  "type": "set",
  "name": "uplinks",
  "value_set": ["eth0", "eth1"],
  "tags": ["uplink"]
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Interface set saved",
  "result": {
    "id": "cccccccc-dddd-eeee-ffff-aaaaaaaaaaaa"
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "set_interface_set",
    "type": "set",
    "name": "lan_interfaces",
    "value_set": ["eth0", "br-lan"]
  }' | jq
```

---

## `set_domain`

Creates or updates a domain set (FQDN names).

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | `string` | ✅ | `"single"` or `"set"` |
| `name` | `string` | ✅ | Set name |
| `value_single` | `string` | depends | FQDN (e.g. `"example.com"` or `"*.example.com"`). Required when `type: "single"` |
| `value_set` | `string[]` | depends | List of FQDNs. Required when `type: "set"` |
| `tags` | `string[]` | ❌ | Optional tags |

> **⚠️ Domain validation requires** a dot-separated FQDN with a trailing label of at least 2 letters. Wildcards (`*.example.com`) are accepted. Single-label names (e.g. `intranet`) are rejected.

### Request examples

**Single domain:**

```json
{
  "command": "set_domain",
  "type": "single",
  "name": "company_domain",
  "value_single": "example.com"
}
```

**Domain set with wildcard:**

```json
{
  "command": "set_domain",
  "type": "set",
  "name": "internal_domains",
  "value_set": ["example.com", "*.internal.example.com"]
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Domain set saved",
  "result": {
    "id": "dddddddd-eeee-ffff-aaaa-bbbbbbbbbbbb"
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "set_domain",
    "type": "single",
    "name": "primary_domain",
    "value_single": "example.com"
  }' | jq
```

---

## `delete_address` / `delete_port` / `delete_interface_set` / `delete_domain`

Deletes a set by its UUID.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | UUID of the set to delete |

### Request

```json
{
  "command": "delete_address",
  "id": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Configuration deleted"
}
```

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Cannot delete set: it is referenced by 2 rules"
}
```

> **⚠️ Rule:** The set must not be referenced by any firewall rule, route, or other entity. If it has active refs, deletion is rejected.

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "delete_address",
    "id": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
  }' | jq
```

---


## `sets-mgmt.set_label`

Assigns a label for a target type. The server MUST return `result.id` on success; clients MUST treat missing `result.id` as an error.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | `string` | ✅ | Target type: `vlans`, `packet_marking`, `routing_tables`, `as_number`, `router_id`, `ospf_area`, `vni`, `gre_ikey`, `gre_okey`, `xfrm_if_id`, `route_tag`, `community`, `as_path_regex`, or `as_path_prepend` |
| `name` | `string` | ✅ | Label name |
| `value` | `string` | ✅ | Value associated with the label (e.g. VLAN id, mark expression) |
| `comment` | `string` | ❌ | Optional comment |

> **Note:** `scope` is no longer sent by the client. The backend generates it automatically based on the label type.

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Label created",
  "result": { "id": "eeeeeeee-ffff-1111-2222-333333333333" }
}
```

> **Note:** The UI requires `result.id` to be present; if the server responds `success` but `result.id` is missing, treat as error and do not create a client-side row.

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "sets-mgmt.set_label",
    "type": "packet_marking",
    "name": "blue-net",
    "value": "meta mark 0x1",
    "comment": "Example label"
  }' | jq
```


## `sets-mgmt.delete_label`

Deletes a label by UUID. The command accepts only `id` and will be rejected if `id` is missing.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | UUID of the label to delete |

### Request

```json
{
  "command": "sets-mgmt.delete_label",
  "id": "eeeeeeee-ffff-1111-2222-333333333333"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Label deleted"
}
```

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Label ID not provided"
}
```

---

# request.php — Read operations

---

## `get_address`

Returns address sets, optionally filtered by scope.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `scope` | `string[]` | ❌ | Filter by scope: `"host"`, `"network"`, `"host_prefix"`, `"range"`, `"set_host"`, `"set_networks"`, `"set_range"`, `"set_mixed"`. Omit for all |

### Request

```json
{
  "action": "get_address"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Address sets retrieved",
  "result": {
    "address": [
      {
        "id": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
        "name": "single_host",
        "type": "single",
        "family": "ip",
        "scope": "host",
        "values": ["192.0.2.5"],
        "tags": []
      }
    ]
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_address", "scope": ["host", "network"]}' | jq
```

---

## `get_ports`

Returns port sets, optionally filtered by scope.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `scope` | `string[]` | ❌ | Filter: `"single"`, `"range"`, `"set_single"`, `"set_range"`, `"set_mixed"`. Omit for all |

### Request

```json
{
  "action": "get_ports"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Port sets retrieved",
  "result": {
    "ports": [
      {
        "id": "bbbbbbbb-cccc-dddd-eeee-ffffffffffff",
        "name": "ssh_port",
        "type": "single",
        "scope": "single",
        "values": [22],
        "tags": ["ssh"]
      }
    ]
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_ports", "scope": ["single"]}' | jq
```

---

## `get_interfaces_sets`

Returns all interface sets.

### Parameters

None.

### Request

```json
{
  "action": "get_interfaces_sets"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Interface sets retrieved",
  "result": {
    "interfaces": [
      {
        "id": "cccccccc-dddd-eeee-ffff-aaaaaaaaaaaa",
        "name": "uplinks",
        "type": "set",
        "values": ["eth0", "eth1"],
        "tags": ["uplink"]
      }
    ]
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_interfaces_sets"}' | jq
```

---

## `get_domains`

Returns all domain sets.

### Parameters

None.

### Request

```json
{
  "action": "get_domains"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Domain sets retrieved",
  "result": {
    "domains": [
      {
        "id": "dddddddd-eeee-ffff-aaaa-bbbbbbbbbbbb",
        "name": "company_domain",
        "type": "single",
        "values": ["example.com"],
        "tags": []
      }
    ]
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_domains"}' | jq
```

---

## `getFullSets`

Returns all set types in a single combined response.

### Parameters

None.

### Request

```json
{
  "action": "getFullSets"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Sets retrieved",
  "result": {
    "address": [...],
    "ports": [...],
    "interfaces": [...],
    "domains": [...]
  }
}
```

---

## `get_labels`

Returns all labels assigned to sets.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `scope` | `string[]` | ❌ | Filter by backend-assigned scope: `mark`, `mark_match`, `vlan`, `routing_table`, `as_number`, `router_id`, `ospf_area`, `route_tag`, `community`, `as_path_regex`, `as_path_prepend`. Omit for all |
| `type` | `string` | ❌ | Filter by label type (e.g. `packet_marking`, `vlans`, `routing_tables`, etc.) |

### Request

```json
{
  "action": "get_labels"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Labels retrieved",
  "result": {
    "labels": [
      {
        "id": "eeeeeeee-ffff-1111-2222-333333333333",
        "type": "packet_marking",
        "name": "blue-net",
        "value": "0x1",
        "scope": "mark",
        "comment": "Blue network mark",
        "refs": []
      }
    ]
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_labels", "scope": ["mark", "vlan"]}' | jq
```

---

## Important notes

1. **Scope is computed automatically.** When creating a `type: "set"` address set, the system assigns a scope (`set_host`, `set_networks`, `set_range`, or `set_mixed`) based on the contents.

2. **Edit restrictions:** Once created, the `type` and `family` of a set cannot be changed. If a set has active `refs`, changing its computed `scope` is also rejected.

3. **Deletion protection:** Sets referenced by firewall rules, routes, or other entities cannot be deleted until all references are removed.

4. **Firewall-ready filtering:** To get address sets suitable for firewall rules (only hosts and networks), use `"scope": ["host", "network"]`.

---

## References

- Backend handler: `api/handlers/sets.md`
- Request schemas: `api/schemas/sets/requests/`
- Response schemas: `api/schemas/sets/responses/`
- PHP implementation (submit): `App\Controllers\Submit\SetsSubmitController`
- PHP implementation (request): `App\Controllers\Request\SetsRequestController`
