# Packet Marking — Netfilter packet marking rules

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Set packet marking rule | `POST /submit.php` | `command: "set_pm_rule"` |
| Preview packet marking rule | `POST /submit.php` | `command: "preview_pm_rule"` |
| Delete packet marking rule | `POST /submit.php` | `command: "delete_pm_rule"` |
| Toggle packet marking rule | `POST /submit.php` | `command: "toggle_pm_rule"` |
| Get packet marking rules | `POST /request.php` | `action: "get_pm_rules"` |

---

# submit.php — Write operations

---

## `set_pm_rule`

Creates or updates a packet marking rule. The backend treats the presence of an `id` field as an edit (update), otherwise a new rule is created.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ❌ | Rule ID to edit (omit to create) |
| `name` | `string` | ✅ | Rule name |
| `chain` | `string` | ✅ | Netfilter chain: `input`, `output`, `forward`, `prerouting`, `postrouting`, `ingress`, `egress` |
| `family` | `string` | ✅ | IP family: `"ip"` (IPv4) or `"ip6"` (IPv6) |
| `mark_target` | `string` | ✅ | Mark target: `"meta"` (metatag) or `"ct"` (conntrack) |
| `mark` | `string` (UUID) | ✅ | UUID of the mark **label** (from `sets-mgmt.get_labels`, type `packet_marking`). The label holds the numeric mark value. |
| `protocol` | `string` | ❌ | Protocol filter: `"tcp"`, `"udp"`, `"icmp"`, `"icmpv6"`, `"sctp"`, `"esp"`, `"ah"`, `"any"`. Required when using port sets. **Family binding:** `icmp` is only valid with `family="ip"` (IPv4), `icmpv6` only with `family="ip6"` (IPv6). The frontend filters options accordingly. |
| `priority` | `integer` | ❌ | Rule evaluation priority within the chain. Lower values are evaluated first. If omitted, the rule uses the chain default priority. |
| `active` | `boolean` | ❌ | Initial active state (`true` = enabled, `false` = disabled). Defaults to `true`. |
| `iface_dir` | `string` | ❌ | Interface direction: `"iifname"` (input) or `"oifname"` (output). Not valid in `ingress`/`egress` chains. |
| `iface_set` | `string` (UUID) | ❌ | UUID of an interface set (from `sets-mgmt.get_interfaces_sets`). Required for `ingress`/`egress` chains. |
| `src_addr` | `string` (UUID) | ❌ | UUID of a single source address set (from `sets-mgmt.get_address`). |
| `dst_addr` | `string` (UUID) | ❌ | UUID of a single destination address set (from `sets-mgmt.get_address`). |
| `src_port` | `string` (UUID) | ❌ | UUID of a source port set (from `sets-mgmt.get_ports`). Requires `protocol` = `tcp`, `udp` or `sctp`. |
| `dst_port` | `string` (UUID) | ❌ | UUID of a destination port set (from `sets-mgmt.get_ports`). Requires `protocol` = `tcp`, `udp` or `sctp`. |

> **Note:** At least one matcher must be provided (interface set, IP set, or port set). The `mark` parameter receives a **label UUID** (not a raw integer); the numeric mark value is stored in the referenced label object.

### Request (create)

```json
{
  "command": "set_pm_rule",
  "name": "Mark VoIP traffic",
  "chain": "forward",
  "family": "ip",
  "mark_target": "meta",
  "mark": "label-uuid-voip-mark",
  "protocol": "udp",
  "priority": 10,
  "dst_port": "port-set-uuid-sip",
  "active": true
}
```

### Request (edit — include `id`)

```json
{
  "command": "set_pm_rule",
  "id": "pm-rule-uuid-1",
  "name": "Mark VoIP traffic (updated)",
  "mark": "label-uuid-voip-mark",
  "active": false
}
```

### Response (success)

```json
{
  "id": "set_pm_rule",
  "status": "success",
  "result": {
    "id": "pm-rule-uuid-1",
    "name": "Mark VoIP traffic",
    "chain": "forward",
    "family": "ip",
    "mark_target": "meta",
    "mark": "label-uuid-voip-mark",
    "protocol": "udp",
    "priority": 10,
    "active": true,
    "created_at": 1700000000,
    "updated_at": 1700000000,
    "iface_dir": null,
    "iface_set": null,
    "src_addr": null,
    "dst_addr": null,
    "src_port": null,
    "dst_port": "port-set-uuid-sip"
  },
  "response_msg": "Packet marking rule saved"
}
```

---

## `delete_pm_rule`

Deletes a packet marking rule by UUID.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Rule UUID |

### Request

```json
{
  "command": "delete_pm_rule",
  "id": "pm-rule-uuid-1"
}
```

### Response (success)

```json
{
  "id": "delete_pm_rule",
  "status": "success",
  "result": {
    "id": "pm-rule-uuid-1"
  },
  "response_msg": "Packet marking rule deleted"
}
```

---

## `toggle_pm_rule`

Enables or disables a packet marking rule.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Rule UUID |

### Request

```json
{
  "command": "toggle_pm_rule",
  "id": "pm-rule-uuid-1"
}
```

### Response (success)

```json
{
  "id": "toggle_pm_rule",
  "status": "success",
  "result": {
    "id": "pm-rule-uuid-1",
    "active": false
  },
  "response_msg": "Packet marking rule toggled"
}
```

---

## `preview_pm_rule`

Validates a packet marking rule without persisting it or applying it to nftables. Accepts the same parameters as `set_pm_rule`.

### Parameters

Same as `set_pm_rule`.

### Request

```json
{
  "command": "preview_pm_rule",
  "name": "Preview VoIP mark",
  "chain": "forward",
  "family": "ip",
  "mark_target": "meta",
  "mark": "label-uuid-voip-mark",
  "protocol": "udp",
  "priority": 10,
  "dst_port": "port-set-uuid-sip",
  "active": true
}
```

### Response (success)

```json
{
  "id": "preview_pm_rule",
  "status": "success",
  "result": {
    "nft_run": "nft add rule ip packet_marking forward udp dport @sip_port meta mark set 0x1a2b3c4d"
  },
  "response_msg": "Packet marking rule preview: valid"
}
```

---

# request.php — Read operations

---

## `get_pm_rules`

Returns all packet marking rules. Referenced sets (interfaces, addresses, ports) and mark labels must be fetched separately via the sets API (e.g. `sets-mgmt.get_labels`, `sets-mgmt.get_address`, `sets-mgmt.get_ports`, `sets-mgmt.get_interfaces_sets`).

### Parameters

None.

### Request

```json
{
  "action": "get_pm_rules"
}
```

### Response (success)

```json
{
  "status": "success",
  "result": {
    "rules": [
      {
        "id": "pm-rule-uuid-1",
        "name": "Mark VoIP traffic",
        "chain": "forward",
        "protocol": "udp",
        "family": "ip",
        "mark_target": "meta",
        "mark": "label-uuid-voip-mark",
        "priority": 10,
        "active": true,
        "created_at": 1700000000,
        "updated_at": 1700000000,
        "iface_dir": null,
        "iface_set": null,
        "src_addr": null,
        "dst_addr": null,
        "src_port": null,
        "dst_port": "port-set-uuid-sip"
      }
    ]
  },
  "warnings": []
}
```

### Response fields

| Field | Type | Description |
|---|---|---|
| `result.rules[]` | `object[]` | Array of packet marking rules (see rule fields below) |
| `warnings` | `string[]` | Array of warning messages (empty on success) |

### Rule object fields

| Field | Type | Description |
|---|---|---|---|
| `id` | `string` (UUID) | Rule identifier |
| `name` | `string` | Rule name |
| `chain` | `string` | Netfilter chain (`input`, `output`, `forward`, `prerouting`, `postrouting`, `ingress`, `egress`) |
| `family` | `string` | IP family (`"ip"` / `"ip6"`) |
| `mark_target` | `string` | Mark target (`"meta"` / `"ct"`) |
| `mark` | `string` (UUID) | UUID of the mark label |
| `protocol` | `string` or `null` | Protocol filter (`"tcp"`, `"udp"`, `"icmp"`, `"icmpv6"`, `"sctp"`, `"esp"`, `"ah"`, `"any"`) |
| `priority` | `integer` or `null` | Rule priority within the chain. `null` if not set. |
| `active` | `boolean` | Whether the rule is enabled |
| `created_at` | `integer` or `null` | Unix timestamp when the rule was created. `null` for rules created before this field was tracked. |
| `updated_at` | `integer` or `null` | Unix timestamp of the last update. `null` if never updated. |
| `iface_dir` | `string` or `null` | Interface direction (`"iifname"` / `"oifname"`) |
| `iface_set` | `string` (UUID) or `null` | UUID of the interface set |
| `src_addr` | `string` (UUID) or `null` | UUID of the source address set |
| `dst_addr` | `string` (UUID) or `null` | UUID of the destination address set |
| `src_port` | `string` (UUID) or `null` | UUID of the source port set |
| `dst_port` | `string` (UUID) or `null` | UUID of the destination port set |

---

## References

- PHP implementation (submit): `App\Controllers\Submit\PacketMarkingSubmitController`
- PHP implementation (request): `App\Controllers\Request\PacketMarkingRequestController`
- JavaScript frontend: `scripts/core/packet-marking.js`
- Template: `tpl/default/packet-marking.tpl.php`
- Formatter: `App\Pages\Fmt\PacketMarkingFormatter`
