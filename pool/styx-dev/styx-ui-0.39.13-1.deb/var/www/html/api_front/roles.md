# Roles — Role definitions and user-role assignments

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Create role | `POST /submit.php` | `command: "create_role"` |
| Update role | `POST /submit.php` | `command: "update_role"` |
| Delete role | `POST /submit.php` | `command: "delete_role"` |
| Assign role to user | `POST /submit.php` | `command: "set_role"` |
| Remove role from user | `POST /submit.php` | `command: "remove_role"` |
| Get role definitions | `POST /request.php` | `action: "get_role_definitions"` |
| Get roles assigned to users | `POST /request.php` | `action: "get_roles"` |
| Get capabilities (permissions) | `POST /request.php` | `action: "get_capabilities"` |

---

# submit.php — Write operations

---

## `create_role`

Creates a new role definition with a set of capabilities.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | `string` | ✅ | Role name (identifier) |
| `description` | `string` | ❌ | Human-readable description |
| `capabilities` | `array` | ✅ | Array of capability IDs to assign to this role |

### Request

```json
{
  "command": "create_role",
  "name": "network_admin",
  "description": "Can manage network interfaces and firewall",
  "capabilities": ["iface_read", "iface_write", "fw_read", "fw_write"]
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Role created",
  "result": {
    "id": "role-uuid-1"
  }
}
```

---

## `update_role`

Updates an existing role definition (name, description, capabilities).

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Role UUID |
| `name` | `string` | ❌ | New role name |
| `description` | `string` | ❌ | New description |
| `capabilities` | `array` | ❌ | Replaces entire capability list |

### Request

```json
{
  "command": "update_role",
  "id": "role-uuid-1",
  "description": "Full network admin including VPN",
  "capabilities": ["iface_read", "iface_write", "fw_read", "fw_write", "vpn_read", "vpn_write"]
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Role updated"
}
```

### Request — rename only

```json
{
  "command": "update_role",
  "id": "role-uuid-1",
  "name": "net_admin"
}
```

---

## `delete_role`

Deletes a role definition.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Role UUID |

### Request

```json
{
  "command": "delete_role",
  "id": "role-uuid-1"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Role deleted"
}
```

---

## `set_role`

Assigns a role to a user.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ✅ | Username |
| `role_id` | `string` (UUID) | ✅ | Role UUID |

### Request

```json
{
  "command": "set_role",
  "username": "alice",
  "role_id": "role-uuid-1"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Role assigned"
}
```

---

## `remove_role`

Removes a role from a user.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ✅ | Username |
| `role_id` | `string` (UUID) | ✅ | Role UUID |

### Request

```json
{
  "command": "remove_role",
  "username": "alice",
  "role_id": "role-uuid-1"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Role removed"
}
```

---

# request.php — Read operations

---

## `get_roles`

Returns all roles currently assigned to users.

### Parameters

None.

### Request

```json
{
  "action": "get_roles"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Roles retrieved",
  "result": {
    "roles": [
      {
        "id": "role-uuid-1",
        "name": "network_admin",
        "description": "Can manage network interfaces and firewall",
        "capabilities": ["iface_read", "iface_write", "fw_read", "fw_write"]
      }
    ]
  }
}
```

---

## `get_role_definitions`

Returns all role definitions (the template of capabilities available for roles).

### Parameters

None.

### Request

```json
{
  "action": "get_role_definitions"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Role definitions retrieved",
  "result": {
    "definitions": [
      {
        "id": "capability-def-uuid",
        "code": "iface_read",
        "name": "Interface Read",
        "description": "View network interface configuration"
      }
    ]
  }
}
```

---

## `get_capabilities`

Returns all available capabilities (permissions) that can be assigned to roles.

### Parameters

None.

### Request

```json
{
  "action": "get_capabilities"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Capabilities retrieved",
  "result": {
    "capabilities": [
      {
        "id": "cap-uuid-1",
        "code": "iface_read",
        "name": "Interface Read",
        "description": "View network interface configuration"
      }
    ]
  }
}
```

---

## Important notes

1. **Capabilities are additive:** When assigning capabilities to a role, the list replaces any previously assigned capabilities for that role.

2. **Role-user assignment:** A user can have multiple roles. The effective permissions are the union of all capabilities from all assigned roles.

3. **Deletion protection:** A role with assigned users cannot be deleted until all assignments are removed via `remove_role`.

---

## References

- PHP implementation (submit): `App\Controllers\Submit\RoleSubmitController`
- PHP implementation (request): `App\Controllers\Request\RoleRequestController`
