# Certificates — Upload, list, inspect, and delete

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Upload certificate | `POST /submit.php` | `command: "upload_certificate"` |
| Delete certificate | `POST /submit.php` | `command: "delete_certificate"` |
| Get certificates | `POST /request.php` | `action: "sys_get_certs"` |

For detailed certificate management, also see [system.md](system.md).

---

# submit.php — Write operations

---

## `upload_certificate`

Uploads a certificate (single PEM file or cert+key pair).

### Single certificate

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | `string` | ✅ | Display name |
| `type` | `string` | ✅ | `"CERT"`, `"KEY"`, or `"CERT_KEY"` |
| `file_name` | `string` | ✅ | Original filename |
| `content` | `string` | ✅ | Base64-encoded PEM content |

```json
{
  "command": "upload_certificate",
  "name": "server.pem",
  "type": "CERT",
  "file_name": "server.pem",
  "content": "<base64-encoded-pem>"
}
```

### Certificate + key pair

| Field | Type | Required | Description |
|---|---|---|---|
| `pair` | `boolean` | ✅ | Must be `true` |
| `cert` | `object` | ✅ | Certificate object (name, type, file_name, content) |
| `key` | `object` | ✅ | Key object (name, type, file_name, content) |

```json
{
  "command": "upload_certificate",
  "pair": true,
  "cert": {
    "name": "server.crt",
    "type": "CERT",
    "file_name": "server.crt",
    "content": "<base64-pem>"
  },
  "key": {
    "name": "server.key",
    "type": "KEY",
    "file_name": "server.key",
    "content": "<base64-pem>"
  }
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Upload successful",
  "result": {
    "id": "cert-uuid-1234",
    "name": "server.pem",
    "type": "CERT",
    "file_name": "server.pem",
    "is_ca": false
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.id` | `string` (UUID) | Certificate UUID for future reference |
| `result.name` | `string` | Certificate name |
| `result.type` | `string` | `"CERT"`, `"KEY"`, or `"CERT_KEY"` |
| `result.is_ca` | `boolean` | Whether the cert is a CA certificate |

---

## `delete_certificate`

Deletes a certificate by its UUID.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Certificate UUID |

### Request

```json
{
  "command": "delete_certificate",
  "id": "cert-uuid-1234"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Certificate deleted"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "upload_certificate",
    "name": "ca.pem",
    "type": "CERT",
    "file_name": "ca.pem",
    "content": "<base64-encoded-content>"
  }' | jq
```

---

# request.php — Read operations

---

## `sys_get_certs`

Returns a list of stored certificates with metadata.

### Parameters

None.

### Request

```json
{
  "action": "sys_get_certs"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Certificates retrieved",
  "result": {
    "certificates": [
      {
        "id": "cert-uuid-1",
        "name": "server.crt",
        "type": "CERT_KEY",
        "file_name": "server.crt",
        "has_key": true,
        "matched_key_path": "/etc/ssl/local-private/server.key",
        "is_ca": false,
        "expires_at": "2027-01-01T00:00:00Z"
      },
      {
        "id": "cert-uuid-2",
        "name": "ca.pem",
        "type": "CERT",
        "file_name": "ca.pem",
        "has_key": false,
        "matched_key_path": null,
        "is_ca": true,
        "expires_at": null
      }
    ]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.certificates[].id` | `string` (UUID) | Certificate UUID |
| `result.certificates[].name` | `string` | Certificate name |
| `result.certificates[].type` | `string` | `"CERT"`, `"KEY"`, or `"CERT_KEY"` |
| `result.certificates[].file_name` | `string` | Original filename |
| `result.certificates[].has_key` | `boolean` | Whether a matching private key was found |
| `result.certificates[].matched_key_path` | `string` \| `null` | Filesystem path to matched key |
| `result.certificates[].is_ca` | `boolean` | Whether this is a CA certificate |
| `result.certificates[].expires_at` | `string` \| `null` | Expiry timestamp |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "sys_get_certs"}' | jq
```

---

## Important notes

1. **Base64 encoding:** Certificate content must be base64-encoded. The raw PEM text should be base64-encoded before sending.

2. **Key matching:** The system attempts to match certificates to private keys by filename heuristics and cryptographic matching.

3. **Certificate UUIDs** can be used in strongSwan connection fields (`local_cert`, `remote_cert`, `remote_cacerts`) to reference stored certificates.

---

## References

- Backend handler: `api/handlers/certificates.md`
- PHP implementation: `App\Controllers\Submit\SystemSubmitController`
