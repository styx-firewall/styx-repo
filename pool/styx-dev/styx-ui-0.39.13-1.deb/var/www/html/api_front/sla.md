# SLA — Network monitoring

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Add monitor | `POST /submit.php` | `command: "add_monitor"` |
| Enable monitor | `POST /submit.php` | `command: "enable_monitor"` |
| Disable monitor | `POST /submit.php` | `command: "disable_monitor"` |
| Delete monitor | `POST /submit.php` | `command: "delete_monitor"` |
| Get SLA page data | `POST /request.php` | `action: "sla_get_page_data"` |

---

# submit.php — Write operations

---

## `add_monitor`

Creates a new SLA monitor to track reachability and performance to a target.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| *varies* | *varies* | ✅ | Monitor definition object validated by the service |

### Request

```json
{
  "command": "add_monitor",
  "name": "Monitor ISP",
  "target": "8.8.8.8",
  "interval": 5,
  "type": "icmp"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Monitor added",
  "result": {
    "monitor_id": "monitor-uuid-1"
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.monitor_id` | `string` (UUID) | Monitor identifier for future operations |

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "add_monitor",
    "name": "Google DNS",
    "target": "8.8.8.8",
    "interval": 10,
    "type": "icmp"
  }' | jq
```

---

## `enable_monitor`

Enables a monitor that was previously disabled.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `monitor_id` | `string` (UUID) | ✅ | Monitor identifier |

### Request

```json
{
  "command": "enable_monitor",
  "monitor_id": "monitor-uuid-1"
}
```

---

## `disable_monitor`

Disables a running monitor.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `monitor_id` | `string` (UUID) | ✅ | Monitor identifier |

### Request

```json
{
  "command": "disable_monitor",
  "monitor_id": "monitor-uuid-1"
}
```

---

## `delete_monitor`

Permanently deletes a monitor.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `monitor_id` | `string` (UUID) | ✅ | Monitor identifier |

### Request

```json
{
  "command": "delete_monitor",
  "monitor_id": "monitor-uuid-1"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Monitor deleted"
}
```

---

# request.php — Read operations

---

## `sla_get_page_data`

Returns all configured monitors and their latest stats.

### Parameters

None.

### Request

```json
{
  "action": "sla_get_page_data"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "SLA page data retrieved",
  "result": {
    "monitors": [
      {
        "monitor_id": "monitor-uuid-1",
        "name": "Google DNS",
        "target": "8.8.8.8",
        "type": "icmp",
        "interval": 10,
        "enabled": true,
        "stats": {
          "rtt": 12.3,
          "loss": 0,
          "jitter": 1.2
        }
      }
    ]
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "sla_get_page_data"}' | jq
```

---

## Important notes

1. **Incremental stats:** The SLA service supports incremental polling via `since_timestamp` for time-series data. Pass the `last_timestamp` from a previous response (converted to epoch) to get only newer entries.

2. **Monitor IDs** are UUIDs returned when the monitor is created. Store them for enable/disable/delete operations.

---

## References

- Backend handler: `api/handlers/sla.md`
- Request schemas: `api/schemas/sla/requests/`
- Response schemas: `api/schemas/sla/responses/`
- PHP implementation (submit): `App\Controllers\Submit\SLASubmitController`
- PHP implementation (request): `App\Controllers\Request\SLARequestController`
