# Network — Network interfaces

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| List OS interface names | `POST /request.php` | `action: "get_interfaces_names"` |
| List datastore interfaces (name + id) | `POST /request.php` | `action: "get_interfaces_names_ds"` |
| Get single interface configuration | `POST /request.php` | `action: "get_interface_config"` |
| Get valid parents for virtual interface | `POST /request.php` | `action: "get_valid_parents"` |
| Get network sysctl keys | `POST /request.php` | `action: "get_sysctl_keys"` |
| Get full routing page data | `POST /request.php` | `action: "get_routing_page_data"` |
| Get static interface addresses | `POST /request.php` | `action: "get_static_interface_addresses"` |
| Create virtual interface | `POST /submit.php` | `command: "create_virtual_interface"` |
| Update interface configuration | `POST /submit.php` | `command: "set_iface_config"` |
| Delete virtual interface | `POST /submit.php` | `command: "delete_virtual_interface"` |

## Authentication

All operations require an active session. Authentication is performed via:
- **Bearer token** in `Authorization: Bearer <token>` header
- Or **session cookie** (set after login via the `login` command)

Read-only operations (`request.php`) return `status: "error"` if the token is invalid or expired.

## Common response format

All **`request.php`** responses follow this structure:

```json
{
  "status": "success" | "error",
  "response_msg": "Human-readable message",
  "result": { /* command-specific data */ }
}
```

All **`submit.php`** responses follow this structure:

```json
{
  "status": "success" | "error",
  "response_msg": "Human-readable message"
}
```

On error, `status` is `"error"` and `response_msg` describes the problem.

---

# request.php — Read operations

---

## `get_interfaces_names`

Returns the names of network interfaces available on the operating system.

### Parameters

None. The body only needs `{"action": "get_interfaces_names"}`.

### Request

```json
{
  "action": "get_interfaces_names"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Interfaces names retrieved",
  "result": {
    "ifaces_names": ["eth0", "eth1", "lo", "wg0", "eth0.100"]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.ifaces_names` | `string[]` | List of OS-detected interface names |

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Authentication required"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_interfaces_names"}' | jq
```

---

## `get_interfaces_names_ds`

Returns interfaces stored in the datastore (local database), with name and UUID.

### Parameters

None.

### Request

```json
{
  "action": "get_interfaces_names_ds"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Interfaces names retrieved",
  "result": {
    "ifaces_names_ds": [
      {
        "interface": "eth0",
        "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
      },
      {
        "interface": "eth1",
        "id": "b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      {
        "interface": "eth0.100",
        "id": "c3d4e5f6-a7b8-9012-cdef-123456789012"
      }
    ]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.ifaces_names_ds` | `object[]` | List of datastore interfaces |
| `result.ifaces_names_ds[].interface` | `string` | Interface name (e.g. `"eth0"`, `"br-lan"`) |
| `result.ifaces_names_ds[].id` | `string` (UUID) | Unique interface identifier |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_interfaces_names_ds"}' | jq
```

---

## `get_interface_config`

Returns the full configuration of a specific interface by its ID.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Interface identifier |

### Request

```json
{
  "action": "get_interface_config",
  "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Interface config retrieved",
  "result": {
    "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "interface": "eth0",
    "type": "physical",
    "subtype": null,
    "status": "up",
    "operstate": "up",
    "mtu": 1500,
    "mac": "02:11:22:33:44:55",
    "role": "lan",
    "parent_iface": null,
    "ip_mode": "static",
    "ipv4": ["uuid-address-set-1", "uuid-address-set-2"],
    "ipv6": [],
    "ipv4_resolved": [
      {
        "id": "uuid-address-set-1",
        "name": "LAN subnet",
        "type": "set",
        "family": "ip",
        "values": ["192.168.1.0/24"]
      }
    ],
    "ipv6_resolved": [],
    "pppoe": null,
    "refs": ["uuid-vlan-interface", "uuid-other-ref"],
    "warnings": [
      {
        "key": "status",
        "msg": "Interface is configured as 'up' but OS reports it as 'down'",
        "config": "up",
        "system": "down"
      }
    ]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.id` | `string` (UUID) | Unique interface identifier |
| `result.interface` | `string` | Interface name |
| `result.type` | `string` | Type: `"physical"`, `"virtual"`, etc. |
| `result.subtype` | `string` \| `null` | Subtype: `"vlan"`, `"bridge"`, `"bond"`, `"veth"`, `"macvlan"`, `"pppoe"`, `"loopback"`, `"vxlan"`, `"gre"`, `"vti"` or `null` for physical |
| `result.status` | `string` | `"up"` \| `"down"` |
| `result.operstate` | `string` | OS-reported operational state (`"up"`, `"down"`, `"unknown"`) |
| `result.mtu` | `integer` | Configured MTU |
| `result.mac` | `string` \| `null` | MAC address |
| `result.role` | `string` \| `null` | Logical role: `"lan"`, `"wan"`, `"dmz"`, `"mgmt"`, `"vpn"`, `"guest"`, `"iot"`, `"infra"`, `"ha"` |
| `result.parent_iface` | `string` \| `null` | UUID of parent interface (for VLAN, macvlan, pppoe) |
| `result.ip_mode` | `string` | `"static"` \| `"dhcp"` \| `"none"` |
| `result.ipv4` | `string[]` (UUIDs) | List of address-set UUIDs for IPv4 |
| `result.ipv6` | `string[]` (UUIDs) | List of address-set UUIDs for IPv6 |
| `result.ipv4_resolved` | `object[]` | Resolved address-sets for display (see table below) |
| `result.ipv6_resolved` | `object[]` | Resolved address-sets for display (see table below) |
| `result.pppoe` | `object` \| `null` | PPPoE configuration (only if `subtype: "pppoe"`) |
| `result.refs` | `string[]` (UUIDs) | List of UUIDs that reference this interface |
| `result.warnings` | `object[]` \| `null` | Warnings array when config differs from system state |

**`ipv4_resolved[]` / `ipv6_resolved[]` structure:**

| Field | Type | Description |
|---|---|---|
| `id` | `string` (UUID) | Address-set ID |
| `name` | `string` | Address-set name |
| `type` | `string` | Type: `"single"`, `"set"`, `"range"` |
| `family` | `string` \| `null` | Family: `"ip"` \| `"ip6"` |
| `values` | `string[]` | List of values (IPs with prefix) |

**`pppoe` structure (when applicable):**

| Field | Type | Description |
|---|---|---|
| `username` | `string` | PPPoE username |
| `service` | `string` | Service name |
| `password` | `string` \| `null` | Password (may be `null` for security) |

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Interface id (id) is required."
}
```

```json
{
  "status": "error",
  "response_msg": "Interface with id a1b2c3d4... not found in configuration."
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_interface_config", "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"}' | jq
```

---

## `get_valid_parents`

Returns candidate parent interfaces suitable for creating a virtual interface of a given type.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `iface_subtype` | `string` | ✅ | Virtual interface type: `"vlan"`, `"macvlan"`, `"bridge"`, `"bond"`, `"veth"`, `"pppoe"` |
| `id` | `string` (UUID) | ❌ | If provided, excludes this interface from results (useful when editing) |

### Request

```json
{
  "action": "get_valid_parents",
  "iface_subtype": "vlan"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Valid parents retrieved",
  "result": {
    "parents": [
      {
        "interface": "eth0",
        "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        "type": "physical",
        "subtype": null,
        "role": "lan",
        "mac": "02:11:22:33:44:55",
        "ip_mode": "static"
      },
      {
        "interface": "bond0",
        "id": "d4e5f6a7-b8c9-0123-def4-567890abcdef",
        "type": "virtual",
        "subtype": "bond",
        "role": "wan",
        "mac": "02:aa:bb:cc:dd:ee",
        "ip_mode": "dhcp"
      }
    ]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.parents` | `object[]` | List of candidate interfaces |
| `result.parents[].interface` | `string` | Interface name |
| `result.parents[].id` | `string` \| `null` | Interface UUID |
| `result.parents[].type` | `string` | `"physical"` \| `"virtual"` |
| `result.parents[].subtype` | `string` \| `null` | Subtype if virtual |
| `result.parents[].role` | `string` \| `null` | Assigned role |
| `result.parents[].mac` | `string` \| `null` | MAC address |
| `result.parents[].ip_mode` | `string` \| `null` | IP mode |

If `iface_subtype` is invalid or no candidates exist, returns `parents: []`.

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_valid_parents", "iface_subtype": "vlan"}' | jq
```

---

## `get_static_interface_addresses`

Returns a mapping of interface names to their static IPv4/IPv6 addresses (only interfaces with `ip_mode: "static"`).

### Parameters

None.

### Request

```json
{
  "action": "get_static_interface_addresses"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Static interface addresses retrieved successfully",
  "result": {
    "static_addresses": {
      "eth0": {
        "ipv4": [{ "ip": "192.168.1.1", "netmask": 24 }],
        "ipv6": []
      }
    }
  }
}
```

---

# submit.php — Write operations

---

## `create_virtual_interface`

Creates a virtual network interface. The type is specified via `iface_subtype`, which
determines which additional parameters are required.

### Supported subtypes

The backend supports **10 subtypes**:

| Subtype | Description |
|---|---|
| `vlan` | 802.1q VLAN interface |
| `bridge` | Network bridge |
| `bond` | Link aggregation (bonding) |
| `veth` | Virtual Ethernet pair |
| `macvlan` | MAC VLAN |
| `pppoe` | PPPoE (Point-to-Point over Ethernet) |
| `loopback` | Loopback (kernel dummy device) |
| `vxlan` | VXLAN tunnel |
| `gre` | GRE tunnel |
| `vti` | VTI (Virtual Tunnel Interface) for IPsec |

### General parameters (common to all subtypes)

| Field | Type | Required | Values | Description |
|---|---|---|---|---|
| `iface_subtype` | `string` | ✅ | See table above | Type of virtual interface to create |
| `status` | `string` | ❌ | `"up"`, `"down"` | Initial state. Default: `"down"` |
| `mtu` | `integer` | ❌ | 576 – 9000 | Interface MTU |
| `ip_mode` | `string` | ❌ | `"static"`, `"dhcp"`, `"none"` | IP configuration mode. Default: `"none"` |
| `role` | `string` | ❌ | `"lan"`, `"wan"`, `"dmz"`, `"mgmt"`, `"vpn"`, `"guest"`, `"iot"`, `"infra"`, `"ha"` | Logical interface role |
| `ipv4` | `string[]` (UUID) | ❌ | — | List of IPv4 address-set UUIDs |
| `ipv6` | `string[]` (UUID) | ❌ | — | List of IPv6 address-set UUIDs |
| `refs` | `string[]` (UUID) | ❌ | — | References to other entities |

> **⚠️ Important:** The `ipv4` and `ipv6` fields do NOT accept literal IP addresses. They
> must be UUIDs referencing existing entries in the `config_set_address` table (created via
> the `set_address` command). The service validates that each UUID exists and has the
> correct address family (`ip` for IPv4, `ip6` for IPv6).

> **⚠️ Role:** Pass empty string to clear the role.

---

### Per-subtype parameters

#### `vlan` — VLAN interface (802.1q)

| Field | Type | Required | Description |
|---|---|---|---|
| `parent_iface` | `string` (UUID) | ✅ | UUID of the parent interface |
| `vlan_id` | `string` (UUID) | ✅ | UUID of a **label-set** with scope `"vlan"`. The actual VLAN ID (1-4094) is resolved from the label-set's value |
| `iface_name` | `string` | ❌ | Ignored — the backend auto-generates the name as `<parent_name>.<vlan_id_value>` |
| `mac` | `string` | ❌ | Custom MAC address (6 hex octets, e.g. `02:11:22:33:44:55`) |

> **Note:** `vlan_id` is now a UUID referencing a label-set with scope `"vlan"`.
> Create the label-set first via the `sets-mgmt.set_label` command with scope `"vlan"`.

#### `bridge` — Network bridge

| Field | Type | Required | Description |
|---|---|---|---|
| `iface_name` | `string` | ✅ | Interface name |
| `ports` | `string[]` (UUID) | ❌ | List of slave interface UUIDs |
| `vlan_filtering` | `boolean` | ❌ | Enables VLAN filtering on the bridge |
| `stp` | `boolean` | ❌ | Spanning Tree Protocol. Default: `true` (enabled) |
| `bridge_vlans` | `object[]` | ❌ | VLAN configuration on the bridge (see structure below) |
| `mac` | `string` | ❌ | Custom MAC address (6 hex octets, e.g. `02:11:22:33:44:55`) |

**`bridge_vlans[]` structure:**

| Field | Type | Required | Description |
|---|---|---|---|
| `vlan_id` | `integer` | ✅ | VLAN ID |
| `pvid` | `boolean` | ❌ | Port VLAN ID |
| `untagged` | `boolean` | ❌ | If `true`, packets leave without VLAN tag |
| `port` | `string` (UUID) | ❌ | UUID of the port this applies to. If omitted/null, applies to the bridge itself |

#### `bond` — Link aggregation

| Field | Type | Required | Description |
|---|---|---|---|
| `iface_name` | `string` | ✅ | Interface name |
| `mode` | `string` | ❌ | `"balance-rr"`, `"active-backup"`, `"balance-xor"`, `"broadcast"`, `"802.3ad"`, `"balance-tlb"`, `"balance-alb"` |
| `slaves` | `string[]` (UUID) | ❌ | List of slave interface UUIDs |
| `mac` | `string` | ❌ | Custom MAC address (6 hex octets, e.g. `02:11:22:33:44:55`) |

#### `veth` — Virtual Ethernet pair

| Field | Type | Required | Description |
|---|---|---|---|
| `iface_name` | `string` | ✅ | Name of the local interface |
| `peer_name` | `string` | ✅ | Name of the peer interface (the other end of the veth pair) |

**Response includes `peer_id`:**

```json
{
  "status": "success",
  "response_msg": "Veth pair veth0+veth1 created",
  "result": {
    "id": "uuid-local-end",
    "interface": "veth0",
    "peer_name": "veth1",
    "peer_id": "uuid-peer-end"
  }
}
```

> The `peer_id` field contains the UUID of the other end of the veth pair.
> Use it to reference the peer in other operations (bridge ports, bond slaves, etc.).

#### `macvlan` — MAC VLAN

| Field | Type | Required | Description |
|---|---|---|---|
| `parent_iface` | `string` (UUID) | ✅ | UUID of the parent interface |
| `iface_name` | `string` | ❌ | Interface name. If omitted, auto-generated as `<parent_name>.mv` |
| `macvlan_mode` | `string` | ❌ | `"bridge"`, `"private"`, `"vepa"`, `"passthru"`, `"source"` |

#### `pppoe` — PPPoE (Point-to-Point over Ethernet)

| Field | Type | Required | Description |
|---|---|---|---|
| `parent_iface` | `string` (UUID) | ✅ | UUID of the parent interface (physical or VLAN) |
| `iface_name` | `string` | ✅ | Logical interface name (e.g. `"pppoe-wan"`). Max 15 chars, alphanumeric + `._-` |
| `pppoe` | `object` | ✅ | Object with credentials and options (see structure below) |

> **⚠️ Important:** Unlike other subtypes, `create_virtual_interface` for PPPoE does NOT
> create a kernel device at this point. The `pppd` process creates `ppp<N>` when the
> interface is brought up via `set_iface_config(status: "up")`. The `iface_name` is
> passed as the pppd `ifname` parameter for deterministic naming.

**`pppoe` structure:**

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ❌ | PPPoE username |
| `password` | `string` | ❌ | Password |
| `service` | `string` | ❌ | Service/AC name |
| `options` | `object` | ❌ | Map of pppd options (see table below) |

**Supported `pppoe.options` keys (validated by the backend):**

| Key | Type | Description |
|---|---|---|
| `defaultroute` | `boolean` | Add default route |
| `replacedefaultroute` | `boolean` | Replace existing default route |
| `usepeerdns` | `boolean` | Use DNS from peer |
| `persist` | `boolean` | Retry connection on disconnect |
| `noauth` | `boolean` | Do not require peer authentication |
| `refuse-eap` | `boolean` | Reject EAP authentication |
| `mtu` | `integer` | MTU (typical: 1492) |
| `mru` | `integer` | MRU |
| `lcp-echo-interval` | `integer` | LCP echo interval (seconds) |
| `lcp-echo-failure` | `integer` | Echo failures before disconnect |
| `holdoff` | `integer` | Wait between reconnections (seconds) |
| `demand` | `boolean` | Dial-on-demand |
| `name` | `string` | Authentication name |
| `password` | `string` | Authentication password override |
| `ac` | `string` | Access Concentrator name |
| `service` | `string` | Service name |
| `proxyarp` | `boolean` | Proxy ARP |
| `ipv6` | `boolean` | Enable IPv6 on the PPP link |
| `maxfail` | `integer` | Maximum failures (0 = infinite) |
| `connect-retry` | `integer` | Connection retry interval |

> **⚠️ Internal options NOT allowed:** `plugin`, `connect`, `updetach` — these are
> managed internally by the service and will be rejected if sent.

> **⚠️ MTU policy for PPPoE:** The backend enforces that the parent interface MTU
> is >= child MTU + 8. If not provided, the child MTU defaults to 1492.

#### `loopback` — Loopback interface

| Field | Type | Required | Description |
|---|---|---|---|
| `iface_name` | `string` | ✅ | Interface name (e.g. `"lo1"`) |

> **Note:** Loopback interfaces are created as kernel `dummy` devices. The same
> common fields (`status`, `mtu`, `ip_mode`, `ipv4`, `ipv6`) are supported.

#### `vxlan` — VXLAN tunnel

| Field | Type | Required | Description |
|---|---|---|---|
| `iface_name` | `string` | ✅ | Interface name (e.g. `"vxlan-lan1"`, `"vni100"`) |
| `vni` | `string` (UUID) | ✅ | UUID of a **label-set** (single type) — VXLAN Network Identifier (1-16777215) |
| `local_ip` | `string` (UUID) | ✅ | UUID of an **address-set** (single, host scope) — local VTEP IP |
| `dstport` | `string` (UUID) | ❌ | UUID of an **address-set** (single) — UDP port. Default: `4789` |
| `nolearning` | `boolean` | ❌ | Disable dynamic MAC learning. Default: `true` |
| `external` | `boolean` | ❌ | Enable collect metadata / SVD mode. Default: `false` |
| `vnifilter` | `boolean` | ❌ | Enable VNI filtering (requires `external=true`). Default: `false` |

#### `gre` — GRE tunnel

| Field | Type | Required | Description |
|---|---|---|---|
| `iface_name` | `string` | ✅ | Interface name (e.g. `"gre-tunnel"`, `"gre-sede1"`) |
| `local` | `string` (UUID) | ✅ | UUID of an **address-set** (single, host scope) — local tunnel endpoint IP |
| `remote` | `string` (UUID) | ✅ | UUID of an **address-set** (single, host scope) — remote tunnel endpoint IP |
| `gre_ttl` | `integer` | ❌ | Tunnel TTL (0 = inherit from payload, default). Values: 0-255 |
| `ikey` | `string` (UUID) | ❌ | UUID of a **label-set** (scope `gre_ikey`) — input GRE key (0-4294967295) |
| `okey` | `string` (UUID) | ❌ | UUID of a **label-set** (scope `gre_okey`) — output GRE key (0-4294967295) |

#### `vti` — VTI (Virtual Tunnel Interface for IPsec)

| Field | Type | Required | Description |
|---|---|---|---|
| `iface_name` | `string` | ✅ | Interface name (e.g. `"vti-ipsec"`, `"vti-sede1"`) |
| `local` | `string` (UUID) | ✅ | UUID of an **address-set** (single, host scope) — local tunnel endpoint |
| `remote` | `string` (UUID) | ✅ | UUID of an **address-set** (single, host scope) — remote tunnel endpoint |
| `key` | `string` (UUID) | ❌ | UUID of a **label-set** (scope `"mark"`) — IPsec marking key (0-4294967295). Default: `100` |

---

### Request examples by subtype

**VLAN:**

```json
{
  "command": "create_virtual_interface",
  "iface_subtype": "vlan",
  "parent_iface": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "vlan_id": "uuid-label-set-vlan-100",
  "status": "up",
  "role": "lan",
  "mtu": 1500,
  "ip_mode": "static",
  "ipv4": ["uuid-address-set-1"]
}
```

**Bridge:**

```json
{
  "command": "create_virtual_interface",
  "iface_subtype": "bridge",
  "iface_name": "br-lan",
  "ports": [
    "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "b2c3d4e5-f6a7-8901-bcde-f12345678901"
  ],
  "vlan_filtering": true,
  "stp": true,
  "bridge_vlans": [
    { "vlan_id": 10, "pvid": true, "untagged": true, "port": "a1b2c3d4-..." },
    { "vlan_id": 20, "untagged": false, "port": "b2c3d4e5-..." }
  ],
  "mac": "02:11:22:33:44:55",
  "status": "up",
  "ip_mode": "static",
  "ipv4": ["uuid-address-set-lan"]
}
```

**Bond:**

```json
{
  "command": "create_virtual_interface",
  "iface_subtype": "bond",
  "iface_name": "bond0",
  "mode": "802.3ad",
  "slaves": [
    "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "b2c3d4e5-f6a7-8901-bcde-f12345678901"
  ],
  "mac": "02:aa:bb:cc:dd:ee",
  "status": "up",
  "role": "wan",
  "ip_mode": "dhcp"
}
```

**PPPoE:**

```json
{
  "command": "create_virtual_interface",
  "iface_subtype": "pppoe",
  "iface_name": "pppoe-wan",
  "parent_iface": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "pppoe": {
    "username": "user@isp",
    "password": "secret",
    "service": "isp-service",
    "options": {
      "defaultroute": true,
      "usepeerdns": true,
      "persist": true,
      "mtu": 1492,
      "mru": 1492
    }
  },
  "status": "up",
  "ip_mode": "static",
  "ipv4": ["uuid-address-set-pppoe"]
}
```

**Macvlan:**

```json
{
  "command": "create_virtual_interface",
  "iface_subtype": "macvlan",
  "parent_iface": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "iface_name": "macvlan0",
  "macvlan_mode": "bridge",
  "status": "up"
}
```

**Veth:**

```json
{
  "command": "create_virtual_interface",
  "iface_subtype": "veth",
  "iface_name": "veth0",
  "peer_name": "veth1",
  "status": "up"
}
```

**Loopback:**

```json
{
  "command": "create_virtual_interface",
  "iface_subtype": "loopback",
  "iface_name": "lo1",
  "status": "up",
  "mtu": 9000,
  "ip_mode": "static",
  "ipv4": ["uuid-address-set-loopback"]
}
```

**VXLAN:**

```json
{
  "command": "create_virtual_interface",
  "iface_subtype": "vxlan",
  "iface_name": "vxlan-lan1",
  "vni": "uuid-label-set-vni-100",
  "local_ip": "uuid-address-set-local-vtep",
  "dstport": "uuid-address-set-dstport",
  "nolearning": true,
  "external": false,
  "vnifilter": false,
  "status": "up",
  "role": "infra",
  "mtu": 1500
}
```

**GRE:**

```json
{
  "command": "create_virtual_interface",
  "iface_subtype": "gre",
  "iface_name": "gre-tunnel-01",
  "local": "uuid-address-set-local-tunnel",
  "remote": "uuid-address-set-remote-tunnel",
  "gre_ttl": 64,
  "ikey": "uuid-label-set-ikey",
  "okey": "uuid-label-set-okey",
  "status": "up",
  "role": "vpn"
}
```

**VTI:**

```json
{
  "command": "create_virtual_interface",
  "iface_subtype": "vti",
  "iface_name": "vti-ipsec-01",
  "local": "uuid-address-set-local",
  "remote": "uuid-address-set-remote",
  "key": "uuid-label-set-mark",
  "status": "up",
  "role": "vpn"
}
```

### Response (success) — General

```json
{
  "status": "success",
  "response_msg": "Virtual interface eth0.100 created."
}
```

### Response (success) — Bridge (extended)

```json
{
  "status": "success",
  "response_msg": "Bridge br-lan created",
  "result": {
    "id": "new-bridge-uuid",
    "interface": "br-lan",
    "vlan_filtering": true,
    "stp": "1",
    "ports": ["uuid-port-1", "uuid-port-2"],
    "effective_ports": ["uuid-port-1", "uuid-port-2"],
    "bridge_vlans": [
      { "vlan_id": 10, "pvid": true, "untagged": true, "port": "uuid-port-1" }
    ],
    "mac": "02:11:22:33:44:55"
  }
}
```

### Response (success) — Bond (extended)

```json
{
  "status": "success",
  "response_msg": "Bond bond0 created",
  "result": {
    "id": "new-bond-uuid",
    "interface": "bond0",
    "mode": "802.3ad",
    "slaves": ["uuid-slave-1", "uuid-slave-2"],
    "effective_slaves": ["uuid-slave-1", "uuid-slave-2"],
    "mac": "02:aa:bb:cc:dd:ee"
  }
}
```

### Response (success) — VLAN (extended)

```json
{
  "status": "success",
  "response_msg": "VLAN eth0.100 created",
  "result": {
    "id": "new-vlan-uuid",
    "interface": "eth0.100",
    "parent_iface": "uuid-parent",
    "vlan_id_label": "uuid-label-set-100",
    "vlan_id_display": {
      "id": "uuid-label-set-100",
      "value": "100",
      "name": "VLAN 100",
      "scope": "vlan"
    },
    "mac": "02:11:22:33:44:55"
  }
}
```

### Response (success) — VXLAN (extended)

```json
{
  "status": "success",
  "response_msg": "VXLAN vxlan-lan1 created",
  "result": {
    "id": "new-vxlan-uuid",
    "interface": "vxlan-lan1",
    "vni_label": "uuid-label-set-vni-100",
    "vni_display": { "id": "uuid-label-set-vni-100", "value": "100", "name": "VNI 100", "scope": null },
    "local_ip_set": "uuid-address-set-local-vtep",
    "local_ip_display": { "id": "uuid-address-set-local-vtep", "value": "10.0.0.1", "name": "Local VTEP" },
    "dstport_set": "uuid-address-set-dstport",
    "dstport_display": { "id": "uuid-address-set-dstport", "value": "4789", "name": "VXLAN port" },
    "nolearning": true,
    "external": false,
    "vnifilter": false
  }
}
```

### Response (success) — GRE (extended)

```json
{
  "status": "success",
  "response_msg": "GRE gre-tunnel-01 created",
  "result": {
    "id": "new-gre-uuid",
    "interface": "gre-tunnel-01",
    "local_set": "uuid-address-set-local",
    "local_display": { "id": "uuid-address-set-local", "value": "10.0.0.1", "name": "Local endpoint" },
    "remote_set": "uuid-address-set-remote",
    "remote_display": { "id": "uuid-address-set-remote", "value": "10.0.0.2", "name": "Remote endpoint" },
    "ttl": 64,
    "ikey_label": "uuid-label-set-ikey",
    "ikey_display": { "id": "uuid-label-set-ikey", "value": "123", "name": "Input Key", "scope": "gre_ikey" },
    "okey_label": "uuid-label-set-okey",
    "okey_display": { "id": "uuid-label-set-okey", "value": "456", "name": "Output Key", "scope": "gre_okey" }
  }
}
```

### Response (success) — VTI (extended)

```json
{
  "status": "success",
  "response_msg": "VTI vti-ipsec-01 created",
  "result": {
    "id": "new-vti-uuid",
    "interface": "vti-ipsec-01",
    "local_set": "uuid-address-set-local",
    "local_display": { "id": "uuid-address-set-local", "value": "10.0.0.1", "name": "Local" },
    "remote_set": "uuid-address-set-remote",
    "remote_display": { "id": "uuid-address-set-remote", "value": "10.0.0.2", "name": "Remote" },
    "key_label": "uuid-label-set-mark",
    "key_display": { "id": "uuid-label-set-mark", "value": "100", "name": "IPsec mark", "scope": "mark" }
  }
}
```

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Unsupported iface_subtype 'foo'. Supported: vlan, bridge, veth, bond, macvlan, loopback, pppoe, vxlan, gre, vti."
}
```

```json
{
  "status": "error",
  "response_msg": "eth0.100 creation failed at system level. Not saved to datastore."
}
```

```json
{
  "status": "error",
  "response_msg": "Invalid role value. Supported: lan, wan, dmz, mgmt, vpn, guest, iot, infra, ha"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "create_virtual_interface",
    "iface_subtype": "vlan",
    "parent_iface": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "vlan_id": "uuid-label-set-vlan-100",
    "status": "up"
  }' | jq
```

---

## `set_iface_config`

Updates an existing interface configuration. Only the fields included in the request are modified.

### Parameters

| Field | Type | Required | Values | Description |
|---|---|---|---|---|
| `id` | `string` (UUID) | ✅ | — | Interface identifier to modify |
| `status` | `string` | ❌ | `"up"`, `"down"` | Change operational status |
| `mtu` | `integer` | ❌ | 576 – 9000 | MTU |
| `ip_mode` | `string` | ❌ | `"static"`, `"dhcp"`, `"none"` | IP configuration mode |
| `set_default_v4_route` | `boolean` | ❌ | `true`, `false` | Only when `ip_mode: "static"`. Set/remove IPv4 default route |
| `set_default_v6_route` | `boolean` | ❌ | `true`, `false` | Only when `ip_mode: "static"`. Set/remove IPv6 default route |
| `role` | `string` \| `null` | ❌ | `"lan"`, `"wan"`, `"dmz"`, `"mgmt"`, `"vpn"`, `"guest"`, `"iot"`, `"infra"`, `"ha"` | Logical role. Pass `null` or empty string to clear |
| `mac` | `string` | ❌ | — | MAC address (6 hex octets, e.g. `02:11:22:33:44:55`). Multicast/broadcast MACs are rejected. **Only virtual interfaces** |
| `ipv4` | `string[]` (UUID) | ❌ | — | List of IPv4 address-set UUIDs (replaces the entire list) |
| `ipv6` | `string[]` (UUID) | ❌ | — | List of IPv6 address-set UUIDs (replaces the entire list) |
| `pppoe` | `object` | ❌ | — | Only for interfaces with `subtype: "pppoe"`. See structure in `create_virtual_interface` |
| `listen_ssh` | `boolean` | ❌ | — | Bind SSH service to this interface (requires feature) |
| `listen_styx_ui` | `boolean` | ❌ | — | Bind Styx UI (lighttpd) to this interface (requires feature) |

> **⚠️ MAC validation:** Changing MAC is only allowed on virtual interfaces. The system
> validates it is not multicast/broadcast and checks it is not already in use by another
> interface.

### Request

```json
{
  "command": "set_iface_config",
  "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "status": "down",
  "mtu": 9000,
  "role": "lan",
  "ip_mode": "static",
  "set_default_v4_route": true,
  "ipv4": ["new-address-set-uuid"],
  "ipv6": []
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Configuration applied to interface eth0. Changed: status, mtu, ipv4."
}
```

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Interface id (id) is required."
}
```

```json
{
  "status": "error",
  "response_msg": "Interface with id a1b2c3d4... not found in configuration."
}
```

```json
{
  "status": "error",
  "response_msg": "MAC address 01:00:5e:00:00:01 is a multicast address and is not allowed."
}
```

```json
{
  "status": "error",
  "response_msg": "Changing MAC is only allowed on virtual interfaces."
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "set_iface_config",
    "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "status": "down",
    "mtu": 9000
  }' | jq
```

---

## `delete_virtual_interface`

Deletes a virtual interface from the operating system and the datastore.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | UUID of the virtual interface to delete |

### Request

```json
{
  "command": "delete_virtual_interface",
  "id": "c3d4e5f6-a7b8-9012-cdef-123456789012"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Virtual interface eth0.100 deleted."
}
```

For PPPoE interfaces:

```json
{
  "status": "success",
  "response_msg": "PPPoE session stopped and interface removed from datastore."
}
```

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Interface id (id) is required."
}
```

```json
{
  "status": "error",
  "response_msg": "Interface with id a1b2c3d4... not found."
}
```

```json
{
  "status": "error",
  "response_msg": "Interface 'eth0' is not a virtual interface and cannot be deleted."
}
```

```json
{
  "status": "error",
  "response_msg": "Interface 'eth0.100' cannot be deleted because it still has active refs: [uuid-1, uuid-2]. Remove all refs first using the update_interface_refs command."
}
```

> **⚠️ Rule:** The interface must not have active references (`refs`). If it does,
> the system rejects the deletion and lists the blocking refs. Remove them first via
> `InterfacesService.update_interface_refs()`.

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "delete_virtual_interface",
    "id": "c3d4e5f6-a7b8-9012-cdef-123456789012"
  }' | jq
```

---

## Important notes

1. **UUIDs vs names:** All reference fields (`parent_iface`, `ports`, `slaves`, `ipv4`, `ipv6`, `vlan_id`, `vni`, `local`, `remote`, `ikey`, `okey`, `key`, `local_ip`, `dstport`) use UUIDs, NOT literal names.
   - Interface references (`parent_iface`, `ports`, `slaves`, `port` in `bridge_vlans`) use UUIDs from `config_interfaces` (datastore).
   - Address references (`ipv4`, `ipv6`, `local_ip`, `dstport`, `local`, `remote`) use UUIDs from `config_set_address` (address-sets).
   - Label references (`vlan_id`, `vni`, `ikey`, `okey`, `key`) use UUIDs from label-sets (created via `sets-mgmt.set_label`).

2. **VLAN ID as label-set:** `vlan_id` is a UUID referencing a label-set with scope `"vlan"`. The actual numeric VLAN ID is resolved from the label-set's stored value. Create the label-set first:
   ```json
   {
     "command": "sets-mgmt.set_label",
     "type": "vlans",
     "name": "VLAN 100",
     "value": "100"
   }
   ```

3. **Address-sets:** IP addresses are stored as references to address-sets (created via the `set_address` command on `submit.php`). Literal IP addresses cannot be sent in `ipv4`/`ipv6` fields.

4. **Role:** The role is a logical label that identifies the interface's function. It is used for alerting and detection logic.

5. **Custom MAC:** When changing the MAC address, the system validates:
   - It is not multicast/broadcast
   - It is not already in use by another interface
   - The interface is virtual (not physical)

6. **Physical interfaces:** Physical interfaces cannot be created or deleted. Only their configuration can be modified via `set_iface_config`.

7. **PPPoE lifecycle:** PPPoE interfaces are logical entries in the datastore. No kernel device is created at `create_virtual_interface` time. The `pppd` process creates `ppp<N>` when the interface is brought up via `set_iface_config(status: "up")`.

8. **Cascading status to children:** When a parent interface (physical or bond) is brought UP, the system restores child VLANs and MACVLANs with `status: "up"` in the datastore.

---

## References

- Backend handler: `handlers/handler_network.py`
- Backend lifecycle: `services/interface_lifecycle_service.py`
- Backend interfaces service: `services/interfaces_service.py`
- Backend OS service: `services/interface_os_service.py`
- Per-type services: `services/interfaces/` (vlan_service, bridge_service, bond_service, veth_service, macvlan_service, vxlan_service, gre_service, vti_service, pppoe_config)
- PPPoE service: `services/pppoe_service.py`
- Request schemas: `api/schemas/network/requests/`
- Response schemas: `api/schemas/network/responses/`
- PHP controller (request): `App\Controllers\Request\NetworkRequestController`
- PHP controller (submit): `App\Controllers\Submit\InterfaceSubmitController`
- Role validation: `services/interfaces/interface_validation.py`
- PPPoE option validation: `services/interfaces/pppoe_validation.py`
- Address-set resolution: `services/interfaces/network_sets_resolution.py`
