# strongSwan — IPsec VPN connections, pools, and secrets

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Add connection | `POST /submit.php` | `command: "swan_add_connection"` |
| Edit connection | `POST /submit.php` | `command: "swan_edit_connection"` |
| Delete connection | `POST /submit.php` | `command: "swan_delete_connection"` |
| Bring connection up | `POST /submit.php` | `command: "swan_conn_up"` |
| Bring connection down | `POST /submit.php` | `command: "swan_conn_down"` |
| Add pool | `POST /submit.php` | `command: "swan_add_pool"` |
| Edit pool | `POST /submit.php` | `command: "swan_edit_pool"` |
| Delete pool | `POST /submit.php` | `command: "swan_delete_pool"` |
| Add secret | `POST /submit.php` | `command: "swan_add_secret"` |
| Edit secret | `POST /submit.php` | `command: "swan_edit_secret"` |
| Delete secret | `POST /submit.php` | `command: "swan_delete_secret"` |
| Set global config | `POST /submit.php` | `command: "swan_set_global_config"` |
| Reload all | `POST /submit.php` | `command: "swan_reload_all"` |
| Get page data | `POST /request.php` | `action: "swan_get_page_data"` |
| Get status | `POST /request.php` | `action: "swan_get_status"` |
| Get connections | `POST /request.php` | `action: "swan_get_connections"` |

---

# submit.php — Write operations

---

## `swan_add_connection`

Creates a new IPsec VPN connection definition.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `connection` | `object` | ✅ | Connection object (see below) |

**Connection object fields:**

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | `string` | ✅ | Unique connection name (alphanumeric, dashes, underscores) |
| `type` | `string` | ❌ | `"tunnel"` (default) or `"transport"` |
| `remote_access` | `boolean` | ❌ | Remote access (road warrior) mode |
| `role` | `string` | ❌ | `"client"` or `"server"`. Required when `remote_access` is true |
| `interface_id` | `string` (UUID) | ❌ | Interface UUID. Resolved to IPs at config time. Use this OR `local_addrs` |
| `local_addrs` | `string` (UUID) | ❌ | Address-set UUID (scope `host`/`set_host`). Resolved to IP at config time. Use this OR `interface_id` |
| `ike_version` | `integer` | ❌ | `0`, `1`, or `2` (default: `2`). `0` = accept both as responder |
| `start_action` | `string` | ❌ | `"none"`, `"start"`, or `"trap"` |
| `keyingtries` | `integer` | ❌ | Retransmission sequences on connect. `0` = infinite, `1` = one attempt. Default: `0` |
| `dpd_action` | `string` | ❌ | `"clear"`, `"restart"`, or `"trap"` |
| `close_action` | `string` | ❌ | `"none"`, `"trap"`, or `"start"` |
| `dpd_delay` | `integer` | ❌ | Dead peer detection delay (seconds) |
| `dpd_timeout` | `integer` | ❌ | DPD timeout (IKEv1 only; ignored on IKEv2). `0` = use charon default |
| `ike_rekey` | `integer` | ❌ | IKE rekey time (seconds) |
| `child_rekey` | `integer` | ❌ | Child SA rekey time (seconds) |
| `reauth_time` | `integer` | ❌ | Reauthentication time (seconds). IKEv2 only |
| `local_id` | `string` | ❌ | Local IKE identity |
| `local_auth` | `string` | ❌ | `"pubkey"`, `"psk"`, `"eap-mschapv2"`, `"eap-tls"`, `"eap-radius"` |
| `local_cert` | `string` (UUID) | ❌ | Certificate UUID |
| `local_ts` | `string[]` (UUIDs) | ❌ | Array of address-set UUIDs for local traffic selectors |
| `remote_id` | `string` | ❌ | Remote IKE identity |
| `remote_addrs` | `string` (UUID) | ❌ | Address-set UUID for remote peer endpoint. Empty = `%any` |
| `remote_auth` | `string` | ❌ | Same values as `local_auth` |
| `remote_cert` | `string` (UUID) | ❌ | Certificate UUID |
| `remote_cacerts` | `string[]` (UUIDs) | ❌ | Array of CA certificate UUIDs |
| `remote_ts` | `string[]` (UUIDs) | ❌ | Array of address-set UUIDs for remote traffic selectors |
| `ike_proposals` | `string[]` | ❌ | IKE proposals e.g. `["aes256gcm16-prfsha256-modp2048"]` |
| `esp_proposals` | `string[]` | ❌ | ESP proposals e.g. `["aes256gcm16-modp2048"]` |
| `pool` | `string` | ❌ | Pool name for road-warrior address assignment |
| `vips` | `string` (UUID) | ❌ | Address-set UUID for virtual IPs to request. Type: `single` or `set`. Scope: `host` or `set_host` |
| `mobike` | `boolean` | ❌ | Enable MOBIKE (IKEv2) |
| `compress` | `boolean` | ❌ | Enable IPComp compression |
| `forceudp` | `boolean` | ❌ | Force UDP encapsulation |
| `eap_id` | `string` | ❌ | EAP identity (separate from IKE `local_id`). For EAP auth methods |
| `send_certreq` | `boolean` | ❌ | Send certificate request payloads. Default: `true` |
| `unique` | `string` | ❌ | Per-connection uniqueness: `""`, `"never"`, `"no"`, `"keep"`, `"replace"` |
| `fragmentation` | `string` | ❌ | Per-connection IKE fragmentation: `""`, `"yes"`, `"accept"`, `"force"`, `"no"` |
| `if_id_in` | `string` (UUID) | ❌ | XFRM interface label UUID (type=`xfrm_if_id`). Empty = unset |
| `if_id_out` | `string` (UUID) | ❌ | XFRM interface label UUID (type=`xfrm_if_id`). Empty = unset |

### Request

```json
{
  "command": "swan_add_connection",
  "connection": {
    "name": "office-vpn",
    "type": "tunnel",
    "interface_id": "11111111-2222-3333-4444-555555555555",
    "ike_version": 2,
    "local_addrs": "22222222-3333-4444-5555-666666666666",
    "remote_addrs": "33333333-4444-5555-6666-777777777777",
    "local_auth": "pubkey",
    "remote_auth": "psk",
    "eap_id": "",
    "ike_proposals": ["aes256gcm16-prfsha256-modp2048"],
    "esp_proposals": ["aes256gcm16-modp2048"],
    "dpd_delay": 30,
    "dpd_timeout": 0,
    "start_action": "start",
    "unique": "",
    "fragmentation": "",
    "send_certreq": true,
    "keyingtries": 0
  }
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Connection added"
}
```

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Validation failed: missing required fields",
  "result": {
    "error_type": "validation_error",
    "fields": { "local.endpoint": "required" }
  }
}
```

---

## `swan_edit_connection`

Modifies an existing connection. Only the fields included in the request are updated.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `connection` | `object` | ✅ | Must include `id` + fields to update |

### Request

```json
{
  "command": "swan_edit_connection",
  "connection": {
    "id": "office-vpn",
    "dpd_delay": 60,
    "start_action": "trap"
  }
}
```

---

## `swan_delete_connection`

Deletes a connection by its ID.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` | ✅ | Connection identifier |

### Request

```json
{
  "command": "swan_delete_connection",
  "id": "office-vpn"
}
```

---

## `swan_conn_up` / `swan_conn_down`

Brings a connection up or down immediately.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` | ✅ | Connection identifier |

### Request

```json
{
  "command": "swan_conn_up",
  "id": "office-vpn"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Connection brought up"
}
```

---

## Pool management

### `swan_add_pool`

Creates a virtual IP pool.

| Field | Type | Required | Description |
|---|---|---|---|
| `pool` | `object` | ✅ | Pool object |

**Pool object:**

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | `string` | ✅ | Pool name (alphanumeric, dashes, underscores) |
| `addrs` | `string` (UUID) | ✅ | Address-set UUID for the pool address range |
| `dns` | `string` (UUID) | ❌ | Address-set UUID for the DNS server IP |
| `split_include` | `string[]` (UUIDs) | ❌ | Address-set UUIDs for split-include routes (pushed to client) |
| `split_exclude` | `string[]` (UUIDs) | ❌ | Address-set UUIDs for split-exclude routes |

```json
{
  "command": "swan_add_pool",
  "pool": {
    "name": "rw-pool",
    "addrs": "44444444-5555-6666-7777-888888888888",
    "dns": "55555555-6666-7777-8888-999999999999",
    "split_include": ["66666666-7777-8888-9999-aaaaaaaaaaaa"]
  }
}
```

### `swan_edit_pool`

Modifies a pool.

```json
{
  "command": "swan_edit_pool",
  "pool": {
    "name": "rw-pool",
    "dns": "55555555-6666-7777-8888-999999999999"
  }
}
```

### `swan_delete_pool`

Deletes a pool.

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | `string` | ✅ | Pool name |

```json
{
  "command": "swan_delete_pool",
  "name": "rw-pool"
}
```

---

## Secret management

### `swan_add_secret`

Creates a PSK or EAP secret.

| Field | Type | Required | Description |
|---|---|---|---|
| `secret` | `object` | ✅ | Secret object |

**Secret object:**

| Field | Type | Required | Description |
|---|---|---|---|
| `label` | `string` | ✅ | Unique label (alphanumeric, dashes, underscores) |
| `type` | `string` | ✅ | `"ike"` (PSK) or `"eap-mschapv2"` |
| `value` | `string` | ✅ | Secret value (PSK or password). Required on add, optional on edit |
| `local_id` | `string` | ❌ | IKE identity for PSK matching. Default: `"%any"` |
| `remote_id` | `string` | ❌ | IKE identity for PSK matching. Default: `"%any"` |
| `username` | `string` | ❌ | Required when `type` is `"eap-mschapv2"`. EAP username |

```json
{
  "command": "swan_add_secret",
  "secret": {
    "label": "psk-1",
    "type": "ike",
    "value": "s3cr3tK3y",
    "local_id": "%any",
    "remote_id": "%any"
  }
}
```

### `swan_edit_secret`

Modifies a secret.

```json
{
  "command": "swan_edit_secret",
  "secret": {
    "label": "psk-1",
    "value": "new-secret"
  }
}
```

### `swan_delete_secret`

Deletes a secret.

| Field | Type | Required | Description |
|---|---|---|---|
| `label` | `string` | ✅ | Secret label |

```json
{
  "command": "swan_delete_secret",
  "label": "psk-1"
}
```

---

## `swan_set_global_config`

Sets global strongSwan daemon configuration.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `config` | `object` | ✅ | Configuration object with daemon options |

**Common config keys:**

| Key | Type | Description |
|---|---|---|
| `install_routes` | `boolean` | Install routes for IPsec tunnels. Default: `true` |
| `install_virtual_ip` | `boolean` | Install virtual IPs on interfaces. Default: `true` |
| `install_virtual_ip_on` | `string` (UUID) | Interface UUID for VIP installation. Empty = auto-detect |
| `uniqueids` | `string` | Connection uniqueness: `"replace"`, `"no"`, `"keep"`, `"never"` |
| `listen_mode` | `string` | Socket listen scope: `"all"` or `"connections"`. Default: `"all"` |
| `charon_syslog` | `string` | Syslog verbosity e.g. `"ike 2, knl 3"` |
| `interfaces_use` | `string[]` (UUIDs) | Interface UUIDs to bind charon IKE sockets to |
| `fragmentation` | `string` | IKE fragmentation: `"yes"`, `"accept"`, `"force"`, `"no"`. Default: `"yes"` |
| `threads` | `integer` | Worker threads. Default: `16` |
| `keep_alive` | `string` | NAT keep-alive interval e.g. `"20s"` |
| `port` | `integer` | IKE port. Default: `500` |
| `port_nat_t` | `integer` | NAT-T port. Default: `4500` |
| `tls` | `object` | TLS settings: `{ "version_min": "1.2", "version_max": "1.3", "cipher": "...", "ke_group": "...", "key_exchange": "...", "mac": "...", "signature": "...", "suites": "...", "send_certreq_authorities": true }` |
| `x509` | `object` | X.509 settings: `{ "enforce_critical": true }` |

### Request

```json
{
  "command": "swan_set_global_config",
  "config": {
    "install_routes": true,
    "uniqueids": "replace",
    "listen_mode": "all",
    "threads": 16,
    "charon_syslog": "ike 2, knl 3",
    "port": 500,
    "port_nat_t": 4500
  }
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Global configuration saved"
}
```

---

## `swan_reload_all`

Reloads all strongSwan configuration and services.

### Parameters

None.

```json
{
  "command": "swan_reload_all"
}
```

---

# request.php — Read operations

---

## `swan_get_page_data`

Returns initial page data for the VPN UI.

### Parameters

None.

```json
{
  "action": "swan_get_page_data"
}
```

---

## `swan_get_status`

Returns live IKE_SA and CHILD_SA status from `swanctl --list-sas --pretty`.

### Parameters

None.

```json
{
  "action": "swan_get_status"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Status retrieved",
  "result": [
    {
      "name": "office-vpn",
      "uniqueid": 1,
      "version": 2,
      "state": "ESTABLISHED",
      "local-host": "10.0.0.1",
      "local-port": 500,
      "local-id": "C=ES, CN=gateway",
      "remote-host": "203.0.113.5",
      "remote-port": 500,
      "remote-id": "C=ES, CN=office",
      "initiator": true,
      "encr-alg": "AES_GCM_16",
      "encr-keysize": 256,
      "prf-alg": "PRF_HMAC_SHA2_256",
      "dh-group": "MODP_2048",
      "established": 3600,
      "rekey-time": 10800,
      "children": [
        {
          "name": "office-vpn",
          "uniqueid": 1,
          "reqid": 1,
          "state": "INSTALLED",
          "mode": "TUNNEL",
          "protocol": "ESP",
          "encr-alg": "AES_GCM_16",
          "encr-keysize": 256,
          "bytes-in": 1048576,
          "packets-in": 1500,
          "bytes-out": 524288,
          "packets-out": 1200,
          "local-ts": ["10.1.0.0/24"],
          "remote-ts": ["10.2.0.0/24"],
          "rekey-time": 1800,
          "life-time": 3600,
          "install-time": 3600
        }
      ]
    }
  ]
}
```

**IKE_SA fields:** `name`, `uniqueid`, `version`, `state` (ESTABLISHED|CONNECTING|CREATED|PASSIVE), `local-host`, `remote-host`, `local-id`, `remote-id`, `initiator`, `encr-alg`, `encr-keysize`, `integ-alg`, `prf-alg`, `dh-group`, `established`, `rekey-time`.

**CHILD_SA fields** (`children[]`): `name`, `uniqueid`, `state` (INSTALLED|REKEYED|REKEYING), `mode`, `protocol`, `bytes-in`, `bytes-out`, `packets-in`, `packets-out`, `local-ts[]`, `remote-ts[]`, `rekey-time`, `life-time`, `install-time`.

---

## `swan_get_connections`

Returns all configured connections with their runtime state.

### Parameters

None.

```json
{
  "action": "swan_get_connections"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Connections list",
  "result": [
    { "id": "office-vpn", "state": "up" },
    { "id": "home", "state": "down" }
  ]
}
```

---

## Important notes

1. **Connection IDs** are user-defined strings (not UUIDs) and must be unique.

2. **Certificate references:** The `local_cert`, `remote_cert`, and `remote_cacerts` fields reference certificate IDs stored via the certificate management commands.

3. **Boolean and numeric types:** Send booleans as `true`/`false`, numbers as integers (not strings). The API validates types strictly.

4. **Reload after changes:** After changing global config, the backend automatically attempts a reload. The response indicates success even if reload has a non-fatal warning.

---

## References

- Backend handler: `api/handlers/strongswan.md`
- PHP implementation (submit): `App\Controllers\Submit\StrongswanSubmitController`
- PHP implementation (request): `App\Controllers\Request\StrongswanRequestController`
