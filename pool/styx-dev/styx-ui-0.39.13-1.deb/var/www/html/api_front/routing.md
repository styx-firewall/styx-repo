# Routing — Dynamic routing protocols (BGP, OSPF, RIP, IGMP Proxy, BFD)

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Save BGP config | `POST /submit.php` | `command: "routing_save_bgp_config"` |
| Add BGP neighbor | `POST /submit.php` | `command: "routing_add_bgp_neighbor"` |
| Delete BGP neighbor | `POST /submit.php` | `command: "routing_delete_bgp_neighbor"` |
| Save OSPF config | `POST /submit.php` | `command: "routing_save_ospf_config"` |
| Add OSPF area | `POST /submit.php` | `command: "routing_add_ospf_area"` |
| Delete OSPF area | `POST /submit.php` | `command: "routing_delete_ospf_area"` |
| Add OSPF interface override | `POST /submit.php` | `command: "routing_add_ospf_iface"` |
| Delete OSPF interface override | `POST /submit.php` | `command: "routing_delete_ospf_iface"` |
| Save RIP config | `POST /submit.php` | `command: "routing_save_rip_config"` |
| Add RIP network | `POST /submit.php` | `command: "routing_add_rip_network"` |
| Delete RIP network | `POST /submit.php` | `command: "routing_delete_rip_network"` |
| Save IGMP Proxy config | `POST /submit.php` | `command: "routing_save_igmp_config"` |
| Add IGMP Proxy interface | `POST /submit.php` | `command: "routing_add_igmp_iface"` |
| Delete IGMP Proxy interface | `POST /submit.php` | `command: "routing_delete_igmp_iface"` |
| Save FRR global config | `POST /submit.php` | `command: "routing_save_frr_global"` |
| Get routing overview | `POST /request.php` | `action: "routing_get_overview"` |
| Get BGP data | `POST /request.php` | `action: "routing_get_bgp"` |
| Get OSPF data | `POST /request.php` | `action: "routing_get_ospf"` |
| Get RIP data | `POST /request.php` | `action: "routing_get_rip"` |
| Get BFD data | `POST /request.php` | `action: "routing_get_bfd"` |
| Get IGMP Proxy data | `POST /request.php` | `action: "routing_get_igmp_proxy"` |
| Get FRR global config | `POST /request.php` | `action: "routing_get_frr_global"` |

## Common concepts

### Label-based identifiers

Routing configuration uses **label UUIDs** (not raw values) for certain fields:

| Field | Label type | Description |
|---|---|---|
| `router_as` | `as_number` | Local AS number (1–4294967295) |
| `remote_as` | `as_number` | Peer AS number |
| `router_id` | `router_id` | Dotted-quad router ID |
| `area_id` | `ospf_area` | OSPF area ID (dotted-quad or decimal) |

These labels are created via `sets-mgmt.set_label` with the appropriate `type`.

### Set-based addressing

| Field | Set type | Source |
|---|---|---|
| `neighbor_ip_set` | Address set | `set_address` (scope `host`) |
| `network_set` | Address set | `set_address` (scope `network`) |
| `iface_set` | Interface set | `set_interface_set` |
| `iface` | Individual interface UUID | `config_interfaces` entry |
| `update_source_set` | Interface set | `set_interface_set` |
| `whitelist` | Address set | `set_address` (scope `network`)

---

# submit.php — Write operations

---

## `routing_save_bgp_config`

Saves BGP global configuration. Creates or replaces existing config.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `router_as` | `string` (UUID) | ✅ | Label UUID for AS number |
| `router_id` | `string` (UUID) | ✅ | Label UUID for router ID |
| `enabled` | `boolean` | ✅ | Enable/disable BGP daemon |
| `keepalive` | `integer` | ✅ | Keepalive interval in seconds (default: 60) |
| `hold_time` | `integer` | ✅ | Hold time in seconds (default: 180) |
| `default_local_pref` | `integer` | ✅ | Default local preference (default: 100) |
| `log_neighbor_changes` | `boolean` | ✅ | Log neighbor up/down events |
| `always_compare_med` | `boolean` | ✅ | Compare MED across different ASes |
| `graceful_restart` | `boolean` | ✅ | Enable graceful restart |

### Request

```json
{
  "command": "routing_save_bgp_config",
  "router_as": "uuid-as-65001",
  "router_id": "uuid-rid-1-1-1-1",
  "enabled": true,
  "keepalive": 60,
  "hold_time": 180,
  "default_local_pref": 100,
  "log_neighbor_changes": true,
  "always_compare_med": false,
  "graceful_restart": false
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "BGP configuration saved"
}
```

---

## `routing_add_bgp_neighbor`

Adds a BGP neighbor.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `neighbor_ip_set` | `string` (UUID) | ✅ | Address set UUID (host-scoped, single address) |
| `remote_as` | `string` (UUID) | ✅ | Label UUID for peer AS number |
| `description` | `string` | ❌ | Free-text description |
| `password` | `string` | ❌ | BGP MD5 session password |
| `ebgp_multihop` | `integer` | ❌ | EBGP multihop TTL (0 = disabled) |
| `update_source_set` | `string` (UUID) | ❌ | Interface set UUID for update-source |
| `keepalive` | `integer` | ❌ | Per-neighbor keepalive override |
| `hold_time` | `integer` | ❌ | Per-neighbor hold time override |
| `next_hop_self` | `boolean` | ❌ | Force next-hop to self |
| `soft_reconfiguration_inbound` | `boolean` | ❌ | Store received routes for soft reset |
| `route_reflector_client` | `boolean` | ❌ | Route reflector client |
| `bfd` | `boolean` | ❌ | Enable BFD for this neighbor |

### Request

```json
{
  "command": "routing_add_bgp_neighbor",
  "neighbor_ip_set": "uuid-addr-peer",
  "remote_as": "uuid-as-65002",
  "description": "Upstream peer",
  "ebgp_multihop": 0,
  "next_hop_self": false,
  "soft_reconfiguration_inbound": true,
  "bfd": true
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "BGP neighbor added"
}
```

---

## `routing_delete_bgp_neighbor`

Deletes a BGP neighbor by its UUID.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Neighbor UUID |

### Request

```json
{
  "command": "routing_delete_bgp_neighbor",
  "id": "bgp-neighbor-uuid-1"
}
```

---

## `routing_save_ospf_config`

Saves OSPF global configuration.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `router_id` | `string` (UUID) | ✅ | Label UUID for router ID |
| `reference_bandwidth` | `integer` | ✅ | Reference bandwidth in Mbps (default: 100) |
| `enabled` | `boolean` | ✅ | Enable/disable OSPF daemon |
| `log_adjacency_changes` | `boolean` | ✅ | Log adjacency state changes |
| `passive_interface_default` | `boolean` | ✅ | Make all interfaces passive by default |

### Request

```json
{
  "command": "routing_save_ospf_config",
  "router_id": "uuid-rid-1-1-1-1",
  "reference_bandwidth": 1000,
  "enabled": true,
  "log_adjacency_changes": true,
  "passive_interface_default": false
}
```

---

## `routing_add_ospf_area`

Adds an OSPF area with its associated network prefix.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `area_id` | `string` (UUID) | ✅ | Label UUID for OSPF area ID |
| `type` | `string` | ✅ | `"normal"`, `"stub"`, or `"nssa"` |
| `no_summary` | `boolean` | ❌ | Totally stub/NSSA (suppress summary LSAs) |
| `network_set` | `string` (UUID) | ✅ | Address set UUID for the area network |

### Request

```json
{
  "command": "routing_add_ospf_area",
  "area_id": "uuid-ospf-area-backbone",
  "type": "normal",
  "network_set": "uuid-addr-set-lan"
}
```

---

## `routing_delete_ospf_area`

Deletes an OSPF area by UUID.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Area UUID |

---

## `routing_add_ospf_iface`

Adds per-interface OSPF parameter overrides.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `iface_set` | `string` (UUID) | ✅ | Interface set UUID |
| `priority` | `integer` | ✅ | DR/BDR election priority (0–255) |
| `cost` | `integer` | ❌ | Interface cost (null = auto from ref bandwidth) |
| `hello_interval` | `integer` | ✅ | Hello interval in seconds |
| `dead_interval` | `integer` | ✅ | Dead interval in seconds |
| `poll_interval` | `integer` | ✅ | Poll interval for NBMA in seconds |
| `passive` | `boolean` | ✅ | Passive interface (suppress hellos) |

### Request

```json
{
  "command": "routing_add_ospf_iface",
  "iface_set": "uuid-iface-set-eth0",
  "priority": 10,
  "hello_interval": 5,
  "dead_interval": 20,
  "poll_interval": 120,
  "passive": false
}
```

---

## `routing_delete_ospf_iface`

Deletes an OSPF interface override by UUID.

---

## `routing_save_rip_config`

Saves RIP global configuration.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `enabled` | `boolean` | ✅ | Enable/disable RIP daemon |
| `version` | `integer` | ✅ | RIP version: `1` or `2` |
| `default_metric` | `integer` | ✅ | Default metric for redistributed routes (1–16) |
| `update_timer` | `integer` | ✅ | Update timer in seconds (default: 30) |
| `timeout_timer` | `integer` | ✅ | Route timeout in seconds (default: 180) |
| `garbage_timer` | `integer` | ✅ | Garbage collection timer in seconds (default: 120) |

### Request

```json
{
  "command": "routing_save_rip_config",
  "enabled": true,
  "version": 2,
  "default_metric": 1,
  "update_timer": 30,
  "timeout_timer": 180,
  "garbage_timer": 120
}
```

---

## `routing_add_rip_network`

Adds a network to advertise via RIP.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `network_set` | `string` (UUID) | ✅ | Address set UUID for the network to advertise |

### Request

```json
{
  "command": "routing_add_rip_network",
  "network_set": "uuid-addr-set-rip-lan"
}
```

---

## `routing_delete_rip_network`

Deletes a RIP network by UUID.

---

## `routing_save_igmp_config`

Saves IGMP Proxy global configuration.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `enabled` | `boolean` | ✅ | Enable/disable IGMP Proxy daemon |

### Request

```json
{
  "command": "routing_save_igmp_config",
  "enabled": true
}
```

---

## `routing_add_igmp_iface`

Adds an IGMP Proxy interface configuration.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `iface` | `string` (UUID) | ✅ | Individual interface UUID (from `config_interfaces`) |
| `role` | `string` | ✅ | `"upstream"` or `"downstream"` |
| `whitelist` | `string` (UUID) | ❌ | Address set UUID for allowed multicast groups — networks only (downstream only) |

### Request

```json
{
  "command": "routing_add_igmp_iface",
  "iface": "uuid-config-iface-eth0",
  "role": "upstream"
}
```

```json
{
  "command": "routing_add_igmp_iface",
  "iface": "uuid-config-iface-lan",
  "role": "downstream",
  "whitelist": "uuid-addr-set-mcast-groups"
}
```

---

## `routing_delete_igmp_iface`

Deletes an IGMP Proxy interface by UUID.

---

## `routing_save_frr_global`

Saves FRRouting global configuration (integrated config file).

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| *varies* | *varies* | ❌ | FRR global configuration fields |

### Request

```json
{
  "command": "routing_save_frr_global",
  "...": "..."
}
```

---

# request.php — Read operations

---

## `routing_get_overview`

Returns the status of all routing daemons and a route summary.

### Parameters

None.

### Request

```json
{
  "action": "routing_get_overview"
}
```

### Response (success)

```json
{
  "status": "success",
  "result": {
    "daemons": [
      { "name": "bgpd", "status": "running" },
      { "name": "ospfd", "status": "running" },
      { "name": "ripd", "status": "stopped" },
      { "name": "bfdd", "status": "running" },
      { "name": "igmpproxy", "status": "stopped" }
    ],
    "route_summary": {
      "connected": 4,
      "static": 2,
      "bgp": 12,
      "ospf": 0,
      "rip": 0,
      "kernel": 1,
      "total": 19
    }
  }
}
```

---

## `routing_get_bgp`

Returns BGP global configuration and neighbor list with resolved display fields.

### Parameters

None.

### Response (success)

```json
{
  "status": "success",
  "result": {
    "bgp_config": {
      "enabled": true,
      "router_as": "uuid-as-65001",
      "router_id": "uuid-rid-1-1-1-1",
      "keepalive": 60,
      "hold_time": 180,
      "default_local_pref": 100,
      "log_neighbor_changes": true,
      "always_compare_med": false,
      "graceful_restart": false
    },
    "neighbors": [
      {
        "id": "bgp-neighbor-uuid-1",
        "remote_as": "uuid-as-65002",
        "description": "Upstream peer",
        "ebgp_multihop": 0,
        "next_hop_self": false,
        "soft_reconfiguration_inbound": true,
        "bfd": true,
        "neighbor_ip_set": "uuid-addr-peer"
      }
    ]
  }
}
```

---

## `routing_get_ospf`

Returns OSPF configuration, areas, interface overrides, and discovered neighbors.

### Parameters

None.

---

## `routing_get_rip`

Returns RIP configuration, networks, and discovered neighbors.

### Parameters

None.

---

## `routing_get_bfd`

Returns active BFD sessions (read-only).

### Parameters

None.

### Response (success)

```json
{
  "status": "success",
  "result": {
    "sessions": [
      {
        "peer": "10.0.0.2",
        "local": "10.0.0.1",
        "iface": "eth0",
        "status": "up",
        "uptime": "02:14:33"
      }
    ]
  }
}
```

---

## `routing_get_igmp_proxy`

Returns IGMP Proxy configuration and interfaces.

### Parameters

None.

### Response (success)

```json
{
  "status": "success",
  "result": {
    "igmp_config": { "enabled": true },
    "interfaces": [
      {
        "id": "igmp-iface-uuid-1",
        "role": "upstream",
        "iface": "uuid-config-iface-eth0",
        "iface_display": { "id": "uuid-config-iface-eth0", "name": "eth0" },
        "whitelist": null,
        "whitelist_display": null
      },
      {
        "id": "igmp-iface-uuid-2",
        "role": "downstream",
        "iface": "uuid-config-iface-lan",
        "iface_display": { "id": "uuid-config-iface-lan", "name": "lan" },
        "whitelist": "uuid-addr-set-mcast-groups",
        "whitelist_display": { "id": "uuid-addr-set-mcast-groups", "name": "IPTV channels", "family": "ip" }
      }
    ]
  }
}
```

---

## `routing_get_frr_global`

Returns FRRouting global configuration.

### Parameters

None.

---

## Important notes

1. **Set creation order:** Create address sets, interface sets, and labels (AS number, router ID, OSPF area) before referencing them in routing commands.

2. **Label types:** Use `sets-mgmt.set_label` with the correct `type` parameter (`as_number`, `router_id`, `ospf_area`) to create labels for routing identifiers.

3. **BGP passwords:** The `password` field is write-only — it is never returned in GET responses for security.

4. **Daemon restarts:** Configuration changes automatically trigger daemon reloads where needed.

---

## References

- PHP implementation (submit): `App\Controllers\Submit\RoutingSubmitController`
- PHP implementation (request): `App\Controllers\Request\RoutingRequestController`
