# Authentication — login, logout, and bearer tokens

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Login | `POST /submit.php` | `command: "login"` |
| Logout | `POST /submit.php` | `command: "logout"` |
| Generate bearer token | `POST /submit.php` | `command: "generate_bearer_token"` |
| Revoke bearer token | `POST /submit.php` | `command: "revoke_bearer_token"` |
| List bearer tokens | `POST /submit.php` | `command: "list_bearer_tokens"` |
| Get user info | `POST /request.php` | `action: "get_user_info"` |
| Get bearer tokens (list) | `POST /request.php` | `action: "get_bearer_tokens"` |

## Authentication

Login itself does not require prior authentication. All other operations require either:
- A valid **session cookie** obtained from a previous `login` call, or
- A valid **bearer token** in the `Authorization: Bearer <token>` header.

---

# submit.php — Write operations

---

## `login`

Authenticates a user and establishes a session.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ✅ | Username |
| `password` | `string` | ✅ | Password |

### Request

```json
{
  "command": "login",
  "username": "alice",
  "password": "secret"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Login successful"
}
```

The server sets a session cookie on success. Subsequent requests in the same browser session are authenticated.

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Invalid credentials"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Content-Type: application/json' \
  -c /tmp/cookies.txt \
  -d '{"command": "login", "username": "alice", "password": "secret"}' | jq
```

---

## `logout`

Invalidates the current session.

### Parameters

None.

### Request

```json
{
  "command": "logout"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Logout successful"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"command": "logout"}' | jq
```

---

## `generate_bearer_token`

Creates a new long-lived bearer token for API access. The raw token value is returned **only at creation time** and cannot be retrieved later.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | `string` | ✅ | Human-readable label for the token |
| `expires_at` | `string` | ❌ | ISO8601 UTC expiry (ending with `Z`). Omit or set to `null` for no expiry |

### Request

```json
{
  "command": "generate_bearer_token",
  "name": "My CI Token",
  "expires_at": "2027-01-01T00:00:00Z"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Token generated successfully",
  "result": {
    "token": "tk_live_xxxxxxxxxxxxxxxx",
    "token_id": "tok_abcdef1234567890",
    "name": "My CI Token",
    "user": "alice",
    "created_at": "2026-03-26T10:00:00Z",
    "expires_at": "2027-01-01T00:00:00Z",
    "revoked_at": null,
    "revoked_notified_at": null
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.token` | `string` | **Full bearer token** — save this immediately; it will never be shown again |
| `result.token_id` | `string` | Public token identifier (prefix `tok_`) — used for revocation |
| `result.name` | `string` | Label for the token |
| `result.user` | `string` | Username that created the token |
| `result.created_at` | `string` (ISO8601) | Creation timestamp |
| `result.expires_at` | `string` \| `null` | Expiry timestamp (or null if no expiry) |
| `result.revoked_at` | `string` \| `null` | Revocation timestamp (null if not revoked) |

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Token name is required"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "generate_bearer_token",
    "name": "CI Automation",
    "expires_at": "2027-06-01T00:00:00Z"
  }' | jq
```

---

## `revoke_bearer_token`

Permanently invalidates a bearer token.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `token_id` | `string` | ✅ | Token identifier (prefix `tok_`) returned at creation |

### Request

```json
{
  "command": "revoke_bearer_token",
  "token_id": "tok_abcdef1234567890"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Token revoked successfully"
}
```

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Token not found"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "revoke_bearer_token",
    "token_id": "tok_abcdef1234567890"
  }' | jq
```

---

## `list_bearer_tokens`

Lists all bearer tokens with metadata. The raw token secret is **never** included.

### Parameters

None.

### Request

```json
{
  "command": "list_bearer_tokens"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Tokens retrieved",
  "result": [
    {
      "token_id": "tok_abcdef1234567890",
      "user": "alice",
      "name": "My CI Token",
      "created_at": "2026-03-26T10:00:00Z",
      "last_used_at": "2026-03-27T08:00:00Z",
      "expires_at": "2027-01-01T00:00:00Z",
      "revoked": false,
      "revoked_at": null,
      "revoked_notified_at": null
    }
  ]
}
```

| Field | Type | Description |
|---|---|---|
| `result[].token_id` | `string` | Token identifier (prefix `tok_`) |
| `result[].user` | `string` | Creator username |
| `result[].name` | `string` | Token label |
| `result[].created_at` | `string` (ISO8601) | Creation timestamp |
| `result[].last_used_at` | `string` \| `null` | Last usage timestamp |
| `result[].expires_at` | `string` \| `null` | Expiry timestamp |
| `result[].revoked` | `boolean` | Whether the token is revoked |
| `result[].revoked_at` | `string` \| `null` | Revocation timestamp |

---

# request.php — Read operations

---

## `get_user_info`

Returns information about the currently authenticated user.

### Parameters

None.

### Request

```json
{
  "action": "get_user_info"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "User info retrieved",
  "result": {
    "username": "alice",
    "gecos": "Alice Smith",
    "shell": "/bin/bash",
    "groups": ["admin", "styx"]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.username` | `string` | Username |
| `result.gecos` | `string` | Full name / GECOS field |
| `result.shell` | `string` | Login shell |
| `result.groups` | `string[]` | Unix groups the user belongs to |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_user_info"}' | jq
```

---

# request.php — Read operations

---

## `get_bearer_tokens`

Returns all bearer tokens with metadata (same data as `list_bearer_tokens` submit command, but via the read endpoint).

### Parameters

None.

### Request

```json
{
  "action": "get_bearer_tokens"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Tokens retrieved",
  "result": [
    {
      "token_id": "tok_abcdef1234567890",
      "user": "alice",
      "name": "My CI Token",
      "created_at": "2026-03-26T10:00:00Z",
      "last_used_at": "2026-03-27T08:00:00Z",
      "expires_at": "2027-01-01T00:00:00Z",
      "revoked": false,
      "revoked_at": null,
      "revoked_notified_at": null
    }
  ]
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_bearer_tokens"}' | jq
```

---

## `metrics`

Returns system metrics data.

### Parameters

None.

### Request

```json
{
  "action": "metrics"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Metrics retrieved",
  "result": { }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "metrics"}' | jq
```

---

## Important notes

1. **Token storage:** The raw bearer token (`tk_live_...`) is returned **only once** at creation. Store it securely. If lost, revoke the old token and generate a new one.

2. **Token expiry:** Expired tokens are automatically rejected. Expired or revoked tokens are purged after a configurable number of days.

3. **Session vs token:** Session cookies are suitable for browser-based usage. Bearer tokens are recommended for automated/script access.

---

## References

- Backend handler: `api/handlers/auth.md`
- PHP implementation (submit): `App\Controllers\Submit\BearerTokenSubmitController`
- PHP implementation (request): `App\Controllers\Request\UserRequestController`
