# Traffic Control — Qdiscs, classes, and filters

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Add qdisc | `POST /submit.php` | `command: "add_tc_qdisc"` |
| Edit qdisc | `POST /submit.php` | `command: "edit_tc_qdisc"` |
| Delete qdisc | `POST /submit.php` | `command: "delete_tc_qdisc"` |
| Add class | `POST /submit.php` | `command: "add_tc_class"` |
| Delete class | `POST /submit.php` | `command: "delete_tc_class"` |
| Add rule (filter) | `POST /submit.php` | `command: "add_tc_rule"` |
| Edit rule (filter) | `POST /submit.php` | `command: "edit_tc_rule"` |
| Delete rule (filter) | `POST /submit.php` | `command: "delete_tc_rule"` |
| Toggle rule | `POST /submit.php` | `command: "toggle_tc_rule"` |
| Get TC config (includes valid qdiscs) | `POST /request.php` | `action: "tc_get_config"` |
| Get TC stats | `POST /request.php` | `action: "tc_get_stats"` |

> **Most operations require `interface_uuid`** instead of `dev`/`interface`/`qdisc_iface`.
> Interfaces are identified by their UUID, obtained from `tc_get_config` (keys of `result.config.interfaces`).
> The exception is `delete_tc_rule`, which uses the rule `id` directly. `edit_tc_rule` and `toggle_tc_rule` also use `id` and resolve `interface_uuid` internally.

---

# submit.php — Write operations

---

## Qdisc operations

### `add_tc_qdisc`

Adds a new qdisc configuration on an interface. If a qdisc already exists, it is replaced.

| Field | Type | Required | Description |
|---|---|---|---|
| `interface_uuid` | `string` (UUID) | ✅ | Interface UUID |
| `kind` | `string` | ✅ | Qdisc type (e.g. `"htb"`, `"fq_codel"`, `"cake"`, `"tbf"`, `"netem"`, `"prio"`, `"hfsc"`, `"pfifo_fast"`) |
| `handle` | `string` | ❌ | Qdisc handle (e.g. `"1:"`). System picks one if omitted. |
| `params` | `string` | ❌ | Comma-separated key:value parameters for the qdisc, e.g. `"rate:10mbit,burst:15k"`. Boolean options like `ecn:true` → `ecn`, `ecn:false` → `noecn`. |

```json
{
  "command": "add_tc_qdisc",
  "interface_uuid": "11111111-1111-1111-1111-111111111111",
  "kind": "htb",
  "handle": "1:",
  "params": "default:10"
}
```

### `edit_tc_qdisc`

Edits an existing qdisc configuration (same parameters as `add_tc_qdisc`). Classes and filters are reapplied with updated parent handles if the qdisc handle changed.

| Field | Type | Required | Description |
|---|---|---|---|
| `interface_uuid` | `string` (UUID) | ✅ | Interface UUID |
| `kind` | `string` | ✅ | Qdisc type (e.g. `"htb"`, `"fq_codel"`) |
| `handle` | `string` | ❌ | Qdisc handle (e.g. `"1:"`). System picks one if omitted. |
| `params` | `string` | ❌ | Comma-separated key:value parameters |

```json
{
  "command": "edit_tc_qdisc",
  "interface_uuid": "11111111-1111-1111-1111-111111111111",
  "kind": "htb",
  "handle": "1:",
  "params": "default:10"
}
```

### Response (success)

```json
{
  "status": "success",
  "stdout": "",
  "stderr": "",
  "errors": [],
  "skipped": false
}
```

| Field | Type | Description |
|---|---|---|
| `status` | `string` | `"success"` or `"error"` |
| `stdout` | `string` | Command stdout, if any |
| `stderr` | `string` | System error output, if any |
| `errors` | `string[]` | Validation errors, if any |
| `skipped` | `boolean` | `true` if the edit was skipped because config was already identical |

### `delete_tc_qdisc`

Deletes a qdisc on an interface (resets to `noqueue`), removing all classes and filters under it.

| Field | Type | Required | Description |
|---|---|---|---|
| `interface_uuid` | `string` (UUID) | ✅ | Interface UUID |

```json
{
  "command": "delete_tc_qdisc",
  "interface_uuid": "11111111-1111-1111-1111-111111111111"
}
```

### Response (success)

```json
{
  "status": "success",
  "stdout": "",
  "stderr": "",
  "errors": []
}
```

> If the qdisc was already `noqueue`, `stdout` will contain `"Already noqueue"`.

---

## Class operations

### `add_tc_class`

Adds a traffic class under a qdisc. The class kind (`htb`/`hfsc`/`prio`) is resolved automatically from the parent qdisc/class. Optionally creates a child qdisc inside the class.

| Field | Type | Required | Description |
|---|---|---|---|
| `interface_uuid` | `string` (UUID) | ✅ | Interface UUID |
| `parent` | `string` | ✅ | Parent qdisc/class handle, e.g. `"1:0"` or `"1:10"`. Ignored if `root` is `true`. |
| `handle` | `string` | ✅ | Class handle (classid), e.g. `"1:10"` |
| `id` | `string` (UUID) | ❌ | Backend UUID for the class (auto-generated if omitted) |
| `root` | `boolean` | ❌ | If `true`, sets parent to `"1:"` (overrides `parent` field) |
| `classname` | `string` | ❌ | Display name for the class |
| `rate` | `string` or `integer` | ❌ | Minimum guaranteed bandwidth. Required for HTB classes. E.g. `"10mbit"`, `"100kbit"`, `500` (bytes/s) |
| `ceil` | `string` or `integer` | ❌ | Maximum bandwidth (ceiling) for HTB, e.g. `"20mbit"` |
| `prio` | `integer` | ❌ | Priority (lower = higher priority, HTB/HFSC) |
| `burst` | `string` or `integer` | ❌ | Burst size for HTB, e.g. `"15k"` |
| `cburst` | `string` or `integer` | ❌ | Ceiling burst size for HTB, e.g. `"15k"` |
| `quantum` | `integer` | ❌ | Quantum (bytes) for HTB |
| `mtu` | `integer` | ❌ | MTU for HTB class |
| `rt` | `string` or `integer` | ❌ | Real-time service curve bandwidth for HFSC |
| `ls` | `string` or `integer` | ❌ | Link-share service curve bandwidth for HFSC |
| `ul` | `string` or `integer` | ❌ | Upper-limit service curve bandwidth for HFSC |
| `d` | `string` or `integer` | ❌ | Delay for HFSC service curve |
| `m1`, `d1`, `m2`, `d2` | `string` or `integer` | ❌ | Two-slope curve parameters for HFSC |
| `bands` | `integer` | ❌ | Number of priority bands for PRIO classes |
| `priomap` | `integer[]` | ❌ | Priority map for PRIO classes (16 ints, band 0–7 per priority) |
| `child_qdisc` | `object` | ❌ | Optional child qdisc attached inside this class: `{ "kind": "sfq", "options": { "perturb": 10 } }` |

```json
{
  "command": "add_tc_class",
  "interface_uuid": "11111111-1111-1111-1111-111111111111",
  "parent": "1:",
  "handle": "1:10",
  "rate": "10mbit",
  "ceil": "20mbit",
  "classname": "Bulk"
}
```

### Response (success)

```json
{
  "status": "success",
  "stderr": "",
  "errors": []
}
```

When a `child_qdisc` is included, the response may also contain:

| Field | Type | Description |
|---|---|---|
| `class_result` | `object` | Result of the `tc class add` command: `{ status, stdout, stderr }` |
| `child_qdisc_result` | `object` | Result of the `tc qdisc add` command for the child: `{ status, stdout, stderr }` |
| `step` | `string` | Step where an error occurred, e.g. `"child_qdisc"` |

### `delete_tc_class`

Deletes a traffic class. Child classes are deleted recursively before the target class.

| Field | Type | Required | Description |
|---|---|---|---|
| `interface_uuid` | `string` (UUID) | ✅ | Interface UUID |
| `id` | `string` (UUID) | ✅ | Class UUID |

```json
{
  "command": "delete_tc_class",
  "interface_uuid": "11111111-1111-1111-1111-111111111111",
  "id": "22222222-2222-2222-2222-222222222222"
}
```

### Response (success)

```json
{
  "status": "success",
  "stderr": "",
  "errors": []
}
```

---

## Filter/rule operations

### `add_tc_rule`

Adds a traffic control filter rule. The valid match fields depend on the chosen `classifier`:

| Classifier | Description | Match Fields |
|---|---|---|
| `u32` | Universal 32-bit filter. Matches IP header fields. | `src_ip`, `dst_ip`, `src_port`, `dst_port`, `ip_proto`, `tos`, `flowid`, `mark` |
| `flower` | Flow-based classifier. Supports extended matches. | All u32 fields + `tcp_flags`, `vlan_id`, `ct_state`, `connmark`, `flowid`, `mark` |
| `fw` | Firewall mark classifier. Matches on nftables fwmark. | `fwmark`, `flowid`, `mark` (**requires** `fwmark`) |
| `matchall` | Matches every packet. No IP/port/VLAN fields. | `mark`, `action` (drop, mirror, police) |
| custom | Any classifier via raw `filter` string. | `filter` (overrides all structured fields) |

#### Common parameters (all classifiers)

| Field | Type | Required | Description |
|---|---|---|---|
| `interface_uuid` | `string` (UUID) | ✅ | Interface UUID |
| `direction` | `string` | ✅ | `"ingress"` or `"egress"` |
| `classifier` | `string` | ✅ | Classifier type: `"u32"`, `"flower"`, `"fw"`, `"matchall"`, or custom |
| `name` | `string` | ✅ | Human-readable rule name |
| `active` | `boolean` | ❌ | Whether the rule is applied to the OS (default `true`) |
| `prio` | `integer` | ❌ | Filter priority (lower = evaluated earlier) |
| `parent` | `string` | ✅ (egress) | Egress parent qdisc, e.g. `"1:"` or `"1:0"`. Required for egress direction. |
| `protocol` | `string` | ❌ | EtherType: `"ip"`, `"ipv6"`, `"all"`, or hex value |
| `flowid` | `string` | ❌ | Target class ID, e.g. `"1:10"` (egress only) |
| `mark` | `string` (UUID) | ❌ | `packet_marking` label UUID; sets skb mark via `skbedit` action |
| `action` | `string` | ❌ | Filter action: `"drop"`, `"ok"`, `"pass"`, `"mirror"` |
| `mirror_dev` | `string` | ❌ | Target interface for mirror action |
| `rate` | `string` | ❌ | Police rate, e.g. `"1mbit"` |
| `burst` | `string` | ❌ | Police burst size |
| `limit` | `string` | ❌ | Police limit |
| `latency` | `string` | ❌ | Netem latency |
| `mtu` | `string` | ❌ | Netem MTU |
| `filter` | `string` | ❌ | Raw tc filter string. **Overrides all structured match/action fields when present.** |

#### u32 / flower match fields

| Field | Type | Required | Description |
|---|---|---|---|
| `src_ip` | `string` (UUID) | ❌ | Source IP set UUID |
| `dst_ip` | `string` (UUID) | ❌ | Destination IP set UUID |
| `src_port` | `string` (UUID) | ❌ | Source port set UUID |
| `dst_port` | `string` (UUID) | ❌ | Destination port set UUID |
| `ip_proto` | `string` | ❌ | IP protocol number or name, e.g. `"tcp"`, `"udp"`, `"icmp"` |
| `tos` | `string` | ❌ | Type of Service / DSCP value |

#### flower-only fields

| Field | Type | Required | Description |
|---|---|---|---|
| `tcp_flags` | `string` | ❌ | TCP flags in hex (flower only) |
| `vlan_id` | `string` (UUID) | ❌ | VLAN label UUID (flower only) |
| `ct_state` | `string` | ❌ | Conntrack state, e.g. `"+trk+est"` (flower only) |
| `connmark` | `string` (UUID) | ❌ | `packet_marking` label UUID (flower only) |

#### fw-only fields

| Field | Type | Required | Description |
|---|---|---|---|
| `fwmark` | `string` (UUID) | ✅ (for fw) | `packet_marking` label UUID (fw classifier only) |

**Examples:**

```json
{
  "command": "add_tc_rule",
  "name": "Match VoIP traffic",
  "interface_uuid": "11111111-1111-1111-1111-111111111111",
  "direction": "egress",
  "classifier": "u32",
  "parent": "1:",
  "protocol": "ip",
  "dst_port": "port-set-uuid-sip",
  "ip_proto": "udp",
  "flowid": "1:10",
  "prio": 1
}
```

```json
{
  "command": "add_tc_rule",
  "name": "Drop marked traffic",
  "interface_uuid": "11111111-1111-1111-1111-111111111111",
  "direction": "ingress",
  "classifier": "fw",
  "fwmark": "label-uuid-drop-mark",
  "action": "drop"
}
```

### Response (success)

```json
{
  "status": "success",
  "stderr": "",
  "errors": []
}
```

---

### `edit_tc_rule`

Edits an existing TC filter rule by its UUID. Only send the fields you want to change; omitted fields keep their current values. If the rule is active, it is re-applied to the OS with the updated configuration.

Accepts the same parameters as `add_tc_rule`, plus:

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Rule UUID to edit |

```json
{
  "command": "edit_tc_rule",
  "id": "tc-rule-uuid-1",
  "name": "Updated rule name",
  "prio": 5,
  "flowid": "1:20"
}
```

### Response (success)

```json
{
  "status": "success",
  "stderr": "",
  "errors": []
}
```

---

### `delete_tc_rule`

Deletes a filter by its UUID.

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ (one of) | Rule UUID |
| `rule_id` | `string` (UUID) | ✅ (one of) | Alias for `id` |

```json
{
  "command": "delete_tc_rule",
  "id": "tc-rule-uuid-1"
}
```

### Response (success)

```json
{
  "status": "success",
  "stderr": "",
  "errors": []
}
```

---

### `toggle_tc_rule`

Enables or disables a TC rule. Activated rules are added to the OS; deactivated rules are removed from the OS but kept in the datastore.

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ (one of) | Rule UUID |
| `rule_id` | `string` (UUID) | ✅ (one of) | Alias for `id` |
| `active` | `boolean` | ✅ | `true` = activate (add to OS), `false` = deactivate (remove from OS) |

```json
{
  "command": "toggle_tc_rule",
  "id": "tc-rule-uuid-1",
  "active": false
}
```

### Response (success)

```json
{
  "status": "success",
  "stderr": "",
  "errors": []
}
```

---

# request.php — Read operations

---

## `tc_get_config`

Returns the current traffic control configuration.

### Parameters

None.

### Request

```json
{
  "action": "tc_get_config"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "TC Config obtained successfully (2 orphaned interfaces)",
  "result": {
    "config": {
      "interfaces": {
        "11111111-1111-1111-1111-111111111111": {
          "interface_name": "eth0",
          "qdiscs": [
            {
              "kind": "fq_codel",
              "handle": "1:",
              "root": true,
              "options": { "flows": 1024, "ecn": true }
            }
          ],
          "classes": [
            {
              "classname": "Bulk",
              "class": "htb",
              "handle": "1:10",
              "parent": "1:",
              "root": false,
              "rate": "10mbit",
              "ceil": "20mbit"
            }
          ],
          "filters": []
        },
        "22222222-2222-2222-2222-222222222222": {
          "interface_name": "gre0",
          "qdiscs": [
            {
              "kind": "noqueue",
              "handle": "0:",
              "root": true,
              "options": {}
            }
          ],
          "warnings": [
            {
              "key": "interface",
              "msg": "Interface 'gre0' does not exist on the system"
            }
          ]
        }
      }
    },
    "valid_qdisc": ["htb", "tbf", "fq_codel", "cake", "netem", "prio", "hfsc", "noqueue", "pfifo_fast"]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.config` | `object` | Container with `interfaces` key (wrapper added by PHP middleware) |
| `result.config.interfaces` | `object` | Map of interface **UUID** → interface TC config |
| `result.config.interfaces.{uuid}.interface_name` | `string` | Display name of the interface |
| `result.config.interfaces.{uuid}.qdiscs` | `object[]` | Configured qdiscs (one per interface) |
| `result.config.interfaces.{uuid}.classes` | `object[]` | Traffic classes under that interface |
| `result.config.interfaces.{uuid}.filters` | `object[]` | Filter rules on that interface |
| `result.config.interfaces.{uuid}.warnings` | `object[]` | Per-interface warnings (e.g. orphaned config) |
| `result.config.interfaces.{uuid}.warnings[].key` | `string` | Warning category (e.g. `"interface"`) |
| `result.config.interfaces.{uuid}.warnings[].msg` | `string` | Warning message |
| `result.valid_qdisc` | `string[]` | List of known valid qdisc kinds |
| `response_msg` | `string` | May include orphaned interface count, e.g. `"(2 orphaned interfaces)"` |

---

## `tc_get_stats`

Returns TC statistics (byte/packet counters per class).

### Parameters

None.

### Request

```json
{
  "action": "tc_get_stats"
}
```

### Response (success)

No structured schema — returns the raw stats object from the backend.
The PHP middleware wraps the response as `result` (no `config` wrapper).
See `api/handlers/tc.md` for the stats shape.

---

> **Note:** The list of valid qdisc kinds is returned as `result.valid_qdisc` inside the `tc_get_config` response (see above). There is no standalone `tc_get_valid_qdisc` action.

---

## Important notes

1. **Supported qdisc kinds:** `htb`, `tbf`, `fq_codel`, `cake`, `netem`, `prio`, `hfsc`, `noqueue`, `pfifo_fast` (and more).

2. **Error details:** Write operations may include `stdout`, `stderr`, and `errors` in the result from the underlying `tc` command.

3. **Handle notation:** Qdisc/class handles use the standard TC notation (e.g. `1:`, `1:10`).

4. **Filter UUID identifiers:** When TC config returns UUID fields (`src_ip`, `dst_ip`, `src_port`, `dst_port`, `vlan_id`, `mark`, `connmark`, `fwmark`), each includes a `_resolved` object with `{ id, name, value }` for display purposes.

---

## References

- Backend schemas: `api/schemas/tc/`
- PHP implementation (submit): `App\Controllers\Submit\TCSubmitController`
- PHP implementation (request): `App\Controllers\Request\TCRequestController`
