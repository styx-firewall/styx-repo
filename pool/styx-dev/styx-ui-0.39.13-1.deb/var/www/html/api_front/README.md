# Styx Gateway — HTTP API Reference

This directory documents the **public HTTP API** exposed by the Styx gateway. Frontend JavaScript developers call these endpoints directly via `POST` requests.

WARNING: This API is automatically generated using AI. It will not be reviewed until it reaches a stable version.

## Endpoints

| Endpoint | Purpose | Key parameter |
|---|---|---|
| `POST /request.php` | All read-only operations (query config, list data, get status) | `action` (string) |
| `POST /submit.php` | All write operations (create, update, delete, enable/disable) | `command` (string) |

> **Note:** The `refresh` action on `request.php` is reserved for internal page orchestration (dynamic commands based on page/section) and should not be called directly by external API consumers.

> All requests must use `Content-Type: application/json`.

## Authentication

Two authentication methods are supported:

### 1. Bearer Token

Include the token in the `Authorization` header:

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_interfaces_names"}'
```

Tokens are generated via the `generate_bearer_token` command (see [auth.md](auth.md)) and have the prefix `tk_live_`.

### 2. Session Cookie

After a successful `login` command, the server sets a session cookie. Subsequent requests in the same browser session are authenticated automatically.

## Common response format

### request.php responses

```json
{
  "status": "success" | "error",
  "response_msg": "Human-readable message",
  "result": { /* operation-specific data */ }
}
```

### submit.php responses

```json
{
  "status": "success" | "error",
  "response_msg": "Human-readable message"
}
```

Some submit operations also return a `result` object with additional data (e.g. created resource ID).

### Error responses

On error, `status` is `"error"` and `response_msg` describes the problem. Common errors:

- `"Authentication required"` — missing or invalid token
- `"Token expired"` — bearer token has expired
- `"Unknown command: ..."` — invalid `command` value
- `"Unknown action: ..."` — invalid `action` value

## Common patterns

### UUIDs as references

The API uses **UUIDs** (not literal names) to reference entities across the system:

- **Interface UUIDs**: used for `parent_iface`, `ports`, `slaves`, `dev` in routes
- **Address-set UUIDs**: used for IP addresses in interfaces (`ipv4`, `ipv6`), routes (`dst`, `gateway`), firewall rules (`src_ips`, `dst_ips`), and DHCP config
- **Port-set UUIDs**: used for ports in firewall rules (`src_ports`, `dst_ports`)
- **Interface-set UUIDs**: used for interfaces in firewall rules (`src_ifaces`, `dst_ifaces`)
- **Domain-set UUIDs**: used for domains in DHCP config

Use the `get_interfaces_names_ds` action to resolve interface names to UUIDs. Use the `sets-*` commands to manage address/port/interface/domain sets.

### Pagination and filtering

Read operations that return lists support optional filtering:

- Most list endpoints accept no parameters and return all entries
- Some support `query` strings (firewall logs), `scope` filters (sets), `limit` (events, logs)

## Topic reference

| File | Topics covered |
|---|---|
| [auth.md](auth.md) | Login, logout, bearer tokens |
| [network.md](network.md) | Interfaces, virtual interfaces, sysctl |
| [firewall.md](firewall.md) | Firewall rules, NAT rules, log queries |
| [sets.md](sets.md) | Address sets, port sets, interface sets, domain sets |
| [routes.md](routes.md) | Routes, routing tables |
| [dhcp.md](dhcp.md) | DHCP server config, reservations, leases |
| [strongswan.md](strongswan.md) | IPsec VPN connections, pools, secrets |
| [sla.md](sla.md) | SLA monitors, stats |
| [system.md](system.md) | System settings, SSH, reboot, packages, services, certificates, sysctl |
| [styx.md](styx.md) | Backups, logs, web settings, features, events |
| [tc.md](tc.md) | Traffic control qdiscs, classes, filters |
| [iperf.md](iperf.md) | iperf3 server/client tests |
| [users.md](users.md) | User management |
| [certificates.md](certificates.md) | Certificate upload, list, inspect, and delete |
| [events.md](events.md) | Event log and acknowledgements |
| [ebpf.md](ebpf.md) | eBPF modules |
| [packet_marking.md](packet_marking.md) | Packet marking rules |
| [roles.md](roles.md) | Role definitions and user-role assignments |
| [route_rules.md](route_rules.md) | Policy-based routing (ip rule) |
| [discovery.md](discovery.md) | Network host discovery |
| [traffic_stats.md](traffic_stats.md) | Interface traffic counters |
| [security.md](security.md) | Security audit, auditd, AIDE |

## Detailed schemas

For implementers who need deeper detail: backend JSON Schemas are available under `api/schemas/`. Each file in this directory references the relevant schemas in the "References" section.

## API test payloads

Real-world request/response examples are available in `api_test/payloads/`. These can be used as reference for building and testing your API calls.
