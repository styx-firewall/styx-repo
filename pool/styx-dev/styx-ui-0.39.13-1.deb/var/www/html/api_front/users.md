# Users — Account management

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Add user | `POST /submit.php` | `command: "add_user"` |
| Edit user | `POST /submit.php` | `command: "edit_user"` |
| Delete user | `POST /submit.php` | `command: "delete_user"` |
| Lock user | `POST /submit.php` | `command: "lock_user"` |
| Unlock user | `POST /submit.php` | `command: "unlock_user"` |
| Save user profile | `POST /submit.php` | `command: "save_profile"` |
| Reset password | `POST /submit.php` | `command: "reset_password"` |
| Assign role to user | `POST /submit.php` | `command: "set_role"` |
| Remove role from user | `POST /submit.php` | `command: "remove_role"` |
| Get users | `POST /request.php` | `action: "get_users"` |
| Get user info | `POST /request.php` | `action: "get_user_info"` |

---

# submit.php — Write operations

---

## `add_user`

Creates a new user account.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ✅ | Username (letters, numbers, underscores, hyphens; starts with letter; max 32 chars) |
| `password` | `string` | ✅ | Password |
| `gecos` | `string` | ❌ | Full name / GECOS field |
| `nologin` | `integer` | ❌ | `0` = normal shell, `1` = no-login shell account |

### Request

```json
{
  "command": "add_user",
  "username": "bob",
  "password": "secureP@ss123",
  "gecos": "Bob Smith",
  "nologin": 0
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "User created successfully"
}
```

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Cannot create user: username is reserved for system use"
}
```

```json
{
  "status": "error",
  "response_msg": "Invalid username format"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "add_user",
    "username": "bob",
    "password": "secureP@ss123",
    "gecos": "Bob Smith"
  }' | jq
```

---

## `edit_user`

Modifies an existing user account.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ✅ | Username to edit |
| `password` | `string` | ❌ | New password |
| `gecos` | `string` | ❌ | New full name |
| `group` | `string` | ❌ | Primary group |
| `shell` | `string` | ❌ | Login shell |
| `home` | `string` | ❌ | Home directory |
| `nologin` | `integer` | ❌ | `0` or `1` |

At least one field to modify (besides `username`) must be provided.

### Request

```json
{
  "command": "edit_user",
  "username": "bob",
  "gecos": "Bob Smith Jr.",
  "shell": "/bin/zsh"
}
```

---

## `delete_user`

Permanently deletes a user account.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ✅ | Username to delete |

### Request

```json
{
  "command": "delete_user",
  "username": "bob"
}
```

---

## `lock_user` / `unlock_user`

Locks or unlocks a user account.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ✅ | Username |

### Request

```json
{
  "command": "lock_user",
  "username": "bob"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "User locked successfully"
}
```

---

## `reset_password`

Resets a user's password.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ✅ | Username |
| `new_password` | `string` | ✅ | New password |

### Request

```json
{
  "command": "reset_password",
  "username": "bob",
  "new_password": "newSecureP@ss456"
}
```

---

## `save_profile`

Saves the current user's profile preferences.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| *varies* | *varies* | ❌ | Profile fields |

### Request

```json
{
  "command": "save_profile",
  "theme": "dark",
  "language": "en"
}
```

---

## `set_role`

Assigns a role definition to a user.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ✅ | Username |
| `role_id` | `string` (UUID) | ✅ | Role UUID |

### Request

```json
{
  "command": "set_role",
  "username": "alice",
  "role_id": "role-uuid-1"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Role assigned"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "set_role",
    "username": "alice",
    "role_id": "role-uuid-1"
  }' | jq
```

---

## `remove_role`

Removes a role assignment from a user.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ✅ | Username |
| `role_id` | `string` (UUID) | ✅ | Role UUID |

### Request

```json
{
  "command": "remove_role",
  "username": "alice",
  "role_id": "role-uuid-1"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Role removed"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "remove_role",
    "username": "alice",
    "role_id": "role-uuid-1"
  }' | jq
```

---

# request.php — Read operations

---

## `get_users`

Returns a list of all system users.

### Parameters

None.

### Request

```json
{
  "action": "get_users"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Users retrieved",
  "result": {
    "users": [
      {
        "username": "alice",
        "gecos": "Alice Smith",
        "shell": "/bin/bash"
      },
      {
        "username": "bob",
        "gecos": "Bob Smith",
        "shell": "/bin/bash"
      }
    ]
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_users"}' | jq
```

---

## `get_user_info`

Returns detailed information about a single user by username.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `username` | `string` | ✅ | Username to query |

### Request

```json
{
  "action": "get_user_info",
  "username": "bob"
}
```

### Response (success)

```json
{
  "status": "success",
  "result": {
    "username": "bob",
    "gecos": "Bob Smith",
    "shell": "/bin/bash",
    "groups": ["styx"]
  }
}
```

> **Note:** The fields in `result` are what the backend `user-mgmt.get_user_info` command returns. The example above shows typical fields (`username`, `gecos`, `shell`, `groups`), but the exact set depends on the `UserManager` implementation.

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_user_info", "username": "bob"}' | jq
```

---

## Important notes

1. **Username rules:** Must start with a letter, can contain letters, numbers, underscores, and hyphens. Maximum 32 characters.

2. **Reserved usernames:** Certain system usernames cannot be created, edited, or deleted.

3. **Locking vs deleting:** Locking preserves the account but prevents login. Deleting removes the account permanently.

---

## References

- Backend handler: `api/handlers/user_mgmt.md`
- PHP implementation (submit): `App\Controllers\Submit\UserSubmitController`
- PHP implementation (request): `App\Controllers\Request\UserRequestController`
