# Firewall — Rules, NAT, and logs

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Create firewall rule | `POST /submit.php` | `command: "set_firewall_rule"` |
| Preview firewall rule | `POST /submit.php` | `command: "preview_firewall_rule"` |
| Update firewall rule | `POST /submit.php` | `command: "update_firewall_rule"` |
| Delete firewall rule | `POST /submit.php` | `command: "delete_firewall_rule"` |
| Move firewall rule | `POST /submit.php` | `command: "move_rule"` |
| Create/update NAT rule | `POST /submit.php` | `command: "set_nat_rule"` |
| Toggle NAT rule | `POST /submit.php` | `command: "set_nat_rule_enabled"` |
| Delete NAT rule | `POST /submit.php` | `command: "delete_nat_rule"` |
| Create/update static NAT rule | `POST /submit.php` | `command: "set_static_nat_rule"` |
| Delete static NAT rule | `POST /submit.php` | `command: "delete_static_nat_rule"` |
| Get forward filter rules | `POST /request.php` | `action: "fw_get_rules_forward"` |
| Get local filter rules | `POST /request.php` | `action: "fw_get_rules_local"` |
| Get NAT rules | `POST /request.php` | `action: "get_nat_rules"` |
| Get NAT page data | `POST /request.php` | `action: "get_nat_page_data"` |
| Get create rule form data | `POST /request.php` | `action: "fw_get_create_rule_form"` |
| Get edit rule form data | `POST /request.php` | `action: "fw_get_edit_rule_form"` |
| Query firewall logs | `POST /request.php` | `action: "fw_logs"` |

## Common concepts

### Sets-based model

All address, port, and interface references in firewall rules use **set UUIDs** (not literal values):

- `src_ips` / `dst_ips` → UUIDs of **address sets** (created via `set_address`)
- `src_ports` / `dst_ports` → UUIDs of **port sets** (created via `set_port`)
- `src_ifaces` / `dst_ifaces` → UUIDs of **interface sets** (created via `set_interface_set`)

> **⚠️ Important:** Legacy fields like `in_iface`/`out_iface` (literal interface names) are **rejected** by validation. Always use set UUIDs.

### Rule structure

Rules belong to a `table` + `chain` + `family` combination:

| Table | Chain | Family | Purpose |
|---|---|---|---|
| `filter` | `input` | `ip` / `ip6` / `inet` | Traffic destined to the firewall itself |
| `filter` | `output` | `ip` / `ip6` / `inet` | Traffic originating from the firewall |
| `filter` | `forward` | `ip` / `ip6` / `inet` | Traffic passing through the firewall |
| `nat` | `prerouting` | `ip` / `ip6` | DNAT (port forwarding) |
| `nat` | `postrouting` | `ip` / `ip6` | SNAT (masquerading) |

> **⚠️ NAT rules** (`table: nat`) only support `family: "ip"` (IPv4) or `family: "ip6"` (IPv6). `family: "inet"` is **not supported** and will be rejected.

### Actions

| Action | Description |
|---|---|
| `accept` | Allow the packet |
| `drop` | Silently discard the packet |
| `reject` | Discard with ICMP rejection |
| `dnat` | Destination NAT (port forwarding) — requires `to_set` (address set) and optionally `to_port_set` (port set) |
| `snat` | Source NAT — requires `to_set` (address set) |
| `masquerade` | Dynamic source NAT (automatic, typically used on WAN interfaces) |
| `log` | Log the packet (used with another action) |

---

# submit.php — Write operations

---

## `set_firewall_rule`

Creates a new firewall rule or updates an existing one (if `id` is provided).

> **Alias:** `update_firewall_rule` is a separate command that also updates an existing rule by UUID. It functions identically to `set_firewall_rule` with an `id` parameter. Both are registered for compatibility.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ❌ | Rule ID to edit (omit to create a new rule) |
| `name` | `string` | ✅ | Display name |
| `family` | `string` | ✅ | `"ip"`, `"ip6"`, or `"inet"` for filter rules |
| `table` | `string` | ✅ | `"filter"` or `"nat"` |
| `chain` | `string` | ✅ | `"input"`, `"output"`, `"forward"`, `"prerouting"`, `"postrouting"` |
| `action` | `string` | ✅ | `"accept"`, `"drop"`, `"reject"`, `"dnat"`, `"snat"`, `"masquerade"`, `"log"` |
| `enabled` | `boolean` | ❌ | `true` or `false`. Use real booleans (not `0`/`1`) |
| `log` | `boolean` | ❌ | Whether to log matches |
| `src_ips` | `string[]` (UUID) | ❌ | Address-set UUIDs for source IPs |
| `dst_ips` | `string[]` (UUID) | ❌ | Address-set UUIDs for destination IPs |
| `src_ports` | `string[]` (UUID) | ❌ | Port-set UUIDs for source ports |
| `dst_ports` | `string[]` (UUID) | ❌ | Port-set UUIDs for destination ports |
| `src_ifaces` | `string[]` (UUID) | ❌ | Interface-set UUIDs for input interfaces |
| `dst_ifaces` | `string[]` (UUID) | ❌ | Interface-set UUIDs for output interfaces |
| `protocol` | `string` | ❌ | `"tcp"`, `"udp"`, `"icmp"`, `"icmpv6"`, etc. |
| `to_set` | `string` (UUID) | depends | Address-set UUID (required for `dnat`/`snat` actions) |
| `to_port_set` | `string` (UUID) | ❌ | Port-set UUID (for `dnat` with port forwarding — must be a single port) |

### Request — create allow rule

```json
{
  "command": "set_firewall_rule",
  "name": "Allow SSH from LAN",
  "family": "ip",
  "table": "filter",
  "chain": "input",
  "action": "accept",
  "src_ifaces": ["uuid-interface-set-lan"],
  "dst_ports": ["uuid-port-set-ssh"],
  "protocol": "tcp",
  "enabled": true
}
```

### Request — create DNAT port forward rule

```json
{
  "command": "set_firewall_rule",
  "name": "Port forward HTTP",
  "family": "ip",
  "table": "nat",
  "chain": "prerouting",
  "action": "dnat",
  "dst_ports": ["uuid-port-set-http"],
  "to_set": "uuid-address-set-internal-server",
  "to_port_set": "uuid-port-set-http-internal",
  "enabled": true
}
```

### Request — edit existing rule

```json
{
  "command": "set_firewall_rule",
  "id": "11111111-2222-3333-4444-555555555555",
  "name": "Allow SSH from LAN (updated)",
  "enabled": false
}
```

### Response (success — created)

```json
{
  "status": "success",
  "response_msg": "Rule saved successfully",
  "result": {
    "id": "11111111-2222-3333-4444-555555555555",
    "handle": 42
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.id` | `string` (UUID) | Rule identifier |
| `result.handle` | `integer` \| `null` | nftables rule handle (null if rule is disabled) |

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Validation failed: invalid action 'reject' for nat table"
}
```

```json
{
  "status": "error",
  "response_msg": "Cannot edit system rule: rule '11111111-...' is a system rule and is immutable"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "set_firewall_rule",
    "name": "Allow DNS",
    "family": "ip",
    "table": "filter",
    "chain": "input",
    "action": "accept",
    "protocol": "udp",
    "dst_ports": ["uuid-port-set-dns"],
    "enabled": true
  }' | jq
```

---

## `update_firewall_rule`

Updates an existing firewall rule by UUID. Functions identically to `set_firewall_rule` with an `id` parameter.

### Parameters

Same as `set_firewall_rule`, but `id` is **required**.

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Rule UUID to update |
| *other fields* | *varies* | ❌ | Fields to modify (same as `set_firewall_rule`) |

### Request

```json
{
  "command": "update_firewall_rule",
  "id": "11111111-2222-3333-4444-555555555555",
  "name": "Allow SSH from LAN (updated)",
  "enabled": false
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Rule updated successfully"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "update_firewall_rule",
    "id": "11111111-2222-3333-4444-555555555555",
    "enabled": false
  }' | jq
```

---

## `preview_firewall_rule`

Previews a firewall rule without persisting. Accepts the same payload as `set_firewall_rule`.
Useful during rule creation/editing to see the nftables command that would be generated.

### Parameters

Same as `set_firewall_rule`.

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Rule preview generated",
  "result": {
    "nft_run": "nft add rule ip filter input ip saddr @lan_set tcp dport 22 accept"
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.nft_run` | `string` | The nftables command that would be applied |

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Rule name is required"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "preview_firewall_rule",
    "name": "Allow SSH",
    "family": "ip",
    "table": "filter",
    "chain": "input",
    "action": "accept",
    "protocol": "tcp",
    "dst_ports": ["uuid-port-set-ssh"]
  }' | jq
```

---

## `delete_firewall_rule`

Deletes a firewall rule by its UUID.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Rule identifier |

### Request

```json
{
  "command": "delete_firewall_rule",
  "id": "11111111-2222-3333-4444-555555555555"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Rule deleted successfully"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "delete_firewall_rule",
    "id": "11111111-2222-3333-4444-555555555555"
  }' | jq
```

---

## `move_rule`

Moves a firewall rule to a new position within its chain.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `rule_id` | `string` (UUID) | ✅ | UUID of the rule to move |
| `position` | `string` | ✅ | Position identifier (e.g. rule UUID to move before/after, or `"first"`/`"last"`) |

---

## `set_nat_rule`

Creates or updates a NAT rule. Similar to `set_firewall_rule` but specific to the `nat` table.

### Parameters

Same as `set_firewall_rule`, with:
- `table` is implicitly `"nat"` (or can be explicitly set)
- `chain` must be `"prerouting"` (DNAT) or `"postrouting"` (SNAT)
- `family` must be `"ip"` or `"ip6"` (not `"inet"`)

### Request

```json
{
  "command": "set_nat_rule",
  "name": "Masquerade WAN",
  "family": "ip",
  "chain": "postrouting",
  "action": "masquerade",
  "src_ifaces": ["uuid-interface-set-lan"],
  "enabled": true
}
```

---

## `delete_nat_rule`

Deletes a NAT rule by UUID.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Rule identifier |

---

## `set_static_nat_rule` / `delete_static_nat_rule`

Creates/deletes a 1:1 static NAT mapping (one-to-one DNAT+SNAT between a public IP and a private IP).

### Request (create)

```json
{
  "command": "set_static_nat_rule",
  "name": "Web server 1:1",
  "family": "ip",
  "public_ip": "uuid-address-set-public",
  "private_ip": "uuid-address-set-private",
  "enabled": true,
  "src_ifaces": ["uuid-interface-set-wan"]
}
```

---

# request.php — Read operations

---

## `fw_get_rules_forward`

Returns all filter rules in the `forward` chain.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `family` | `string` | ❌ | `"ip"`, `"ip6"`, or `"inet"`. Omit for all |

### Request

```json
{
  "action": "fw_get_rules_forward"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Firewall rules retrieved",
  "result": {
    "nftables": [
      {
        "id": "11111111-2222-3333-4444-555555555555",
        "name": "Allow LAN to WAN",
        "family": "ip",
        "table": "filter",
        "chain": "forward",
        "action": "accept",
        "enabled": true,
        "handle": 42,
        "src_ifaces": [
          {
            "id": "uuid-iface-set",
            "name": "LAN interfaces",
            "type": "set",
            "values": ["br-lan", "eth0"]
          }
        ],
        "dst_ips": [
          {
            "id": "uuid-addr-set",
            "name": "Any",
            "type": "set",
            "values": ["0.0.0.0/0"]
          }
        ]
      }
    ]
  }
}
```

> The response returns **resolved** set objects (with `id`, `name`, `type`, `values`) instead of bare UUIDs, making them display-ready.

---

## `fw_get_rules_local`

Returns filter rules in `input` and `output` chains.

### Parameters

Same as `fw_get_rules_forward`.

```json
{
  "action": "fw_get_rules_local"
}
```

---

## `get_nat_rules`

Returns NAT rules from the `nat` table.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `family` | `string` | ❌ | `"ip"` or `"ip6"`. Omit for all |

```json
{
  "action": "get_nat_rules"
}
```

---

## `fw_logs`

Queries the firewall log with optional filtering.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `query` | `string` | ❌ | Filter expression (see below for syntax) |
| `limit` | `integer` | ❌ | Maximum number of log entries to return |
| `mark` | `integer` | ❌ | File-line index for pagination |
| `start` | `integer` | ❌ | Range start index |
| `end` | `integer` | ❌ | Range end index |

### Query expression language

| Operator | Description |
|---|---|
| `==` | Exact equality (string or numeric) |
| `!=` | Not equal |
| `AND` | Logical conjunction |
| `OR` | Logical disjunction |
| `NOT` | Logical negation (prefix) |
| `( )` | Grouping / precedence |

Precedence: `NOT` > `AND` > `OR`.

### Queryable fields

| Field | Description |
|---|---|
| `src_ip` / `SRC` | Source IP address |
| `dest_ip` / `DST` | Destination IP address |
| `src_port` / `SPT` | Source port |
| `dest_port` / `DPT` | Destination port |
| `protocol` | Protocol name (e.g. `"TCP"`, `"UDP"`, `"ICMP"`) |
| `network.hook` | nftables hook: `"input"`, `"output"`, `"forward"`, `"prerouting"`, `"postrouting"` |
| `network.in_iface` | Input interface name |
| `network.out_iface` | Output interface name |
| `action` | Rule action: `"accept"`, `"deny"`, `"drop"` |
| `rule` | Rule name |
| `uuid` | Rule UUID |

### Query examples

```
src_ip == "192.168.1.100"
network.hook == "input" AND dest_port == 443
action == "deny" AND (network.hook == "input" OR network.hook == "forward")
NOT protocol == "ICMP" AND dest_port == 22
rule == "AllowHTTPS"
```

### Request

```json
{
  "action": "fw_logs",
  "query": "action == \"deny\" AND dest_port == 443",
  "limit": 50
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Firewall logs retrieved",
  "result": {
    "mark": 12345,
    "logs": [
      {
        "timestamp": 1700000000.0,
        "timestamp_iso": "2024-11-14T12:26:40Z",
        "src_ip": "10.0.0.5",
        "dest_ip": "192.0.2.10",
        "src_port": "52345",
        "dest_port": "443",
        "protocol": "TCP",
        "network": {
          "in_iface": "eth0",
          "out_iface": "",
          "hook": "input",
          "direction": "inbound"
        },
        "action": "deny",
        "rule": "DefaultDrop",
        "uuid": "c389cba1-...",
        "flow_id": 1234567890123456
      }
    ]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.mark` | `integer` | File-line index for next pagination request |
| `result.logs[].timestamp` | `number` | Epoch timestamp (seconds) |
| `result.logs[].timestamp_iso` | `string` (ISO8601) | UTC timestamp for display |
| `result.logs[].src_ip` | `string` | Source IP |
| `result.logs[].dest_ip` | `string` | Destination IP |
| `result.logs[].src_port` | `string` | Source port |
| `result.logs[].dest_port` | `string` | Destination port |
| `result.logs[].protocol` | `string` | Protocol name |
| `result.logs[].network` | `object` | Network context (hook, direction, interfaces) |
| `result.logs[].action` | `string` | Action taken |
| `result.logs[].rule` | `string` | Rule name |
| `result.logs[].uuid` | `string` (UUID) | Rule UUID |
| `result.logs[].flow_id` | `integer` | Flow identifier |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "fw_logs", "query": "action == \"deny\"", "limit": 20}' | jq
```

---

## `fw_get_create_rule_form`

Returns form configuration data needed to build the rule creation UI (available chains, families, actions, etc.).

### Parameters

None.

---

## `fw_get_edit_rule_form`

Returns form data for editing an existing rule.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` (UUID) | ✅ | Rule identifier |

---

## `get_nat_page_data`

Returns combined NAT page data (rules and available sets for form building).

### Parameters

None.

---

## Important notes

1. **Boolean fields:** `enabled` and `log` must be sent as real booleans (`true`/`false`), not as integers (`0`/`1`).

2. **Disabled rules are persisted:** A rule with `enabled: false` is stored in the datastore but is not applied to nftables. Its `handle` will be `null`.

3. **System rules are immutable:** Rules marked with `system_rule: true` (built-in end-of-chain rules) cannot be edited or deleted.

4. **DNAT port forwarding** requires both `to_set` (address set, type `ip`, scope `host`) and `to_port_set` (port set, type `single`). The backend combines them to generate the `dnat to IP:PORT` expression.

5. **Resolved sets in responses:** When reading rules (via `fw_get_rules_*`), set UUIDs are resolved to full objects with `id`, `name`, `type`, and `values` for direct display.

---

## References

- Backend handler: `api/handlers/firewall_rules.md`
- Firewall logs handler: `api/handlers/firewall_logs.md`
- Request schemas: `api/schemas/firewall_rules/requests/`
- Response schemas: `api/schemas/firewall_rules/responses/`
- PHP implementation (submit): `App\Controllers\Submit\FirewallSubmitController`, `App\Controllers\Submit\NatSubmitController`
- PHP implementation (request): `App\Controllers\Request\FirewallRequestController`, `App\Controllers\Request\NatRequestController`, `App\Controllers\Request\FwLogsRequestController`
