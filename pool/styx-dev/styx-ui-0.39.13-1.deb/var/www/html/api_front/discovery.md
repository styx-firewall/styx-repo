# Discovery — Network host discovery

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Trigger ARP sweep | `POST /submit.php` | `command: "discovery_sweep_now"` |
| Trigger traceroute | `POST /submit.php` | `command: "discovery_traceroute_all"` |
| Pause discovery | `POST /submit.php` | `command: "discovery_pause"` |
| Resume discovery | `POST /submit.php` | `command: "discovery_resume"` |
| Prune stale hosts | `POST /submit.php` | `command: "discovery_prune_hosts"` |
| Get overview data | `POST /request.php` | `action: "discovery_get_overview"` |
| Get single host | `POST /request.php` | `action: "discovery_get_host"` |

---

# submit.php — Write operations

---

## `discovery_sweep_now`

Triggers an immediate ARP sweep on all subnets, or on a specific CIDR if provided.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `cidr` | `string` | ❌ | Optional CIDR to restrict the sweep (e.g. `"192.168.1.0/24"`). Omit for all subnets |

### Request

```json
{
  "command": "discovery_sweep_now"
}
```

### Request — specific subnet

```json
{
  "command": "discovery_sweep_now",
  "cidr": "192.168.1.0/24"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Sweep started"
}
```

---

## `discovery_traceroute_all`

Triggers ICMP traceroute to all discovered hosts, or to a single IP if provided.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `ip` | `string` | ❌ | Optional single IP to traceroute. Omit for all hosts |

### Request

```json
{
  "command": "discovery_traceroute_all"
}
```

### Request — single IP

```json
{
  "command": "discovery_traceroute_all",
  "ip": "192.168.1.1"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Traceroute started"
}
```

---

## `discovery_pause`

Pauses passive network discovery sniffing.

### Parameters

None.

### Request

```json
{
  "command": "discovery_pause"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Discovery paused"
}
```

---

## `discovery_resume`

Resumes passive network discovery sniffing after a pause.

### Parameters

None.

### Request

```json
{
  "command": "discovery_resume"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Discovery resumed"
}
```

---

## `discovery_prune_hosts`

Removes stale hosts older than the specified number of minutes.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `minutes` | `integer` | ❌ | Age threshold in minutes (default: 10080 = 7 days). Hosts not seen within this period are removed |

### Request

```json
{
  "command": "discovery_prune_hosts",
  "minutes": 1440
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Stale hosts pruned"
}
```

---

# request.php — Read operations

---

## `discovery_get_overview`

Returns all discovery data in a single batched response: host list, host statistics, topology graph, and service status.

### Parameters

None.

### Request

```json
{
  "action": "discovery_get_overview"
}
```

### Response (success)

```json
{
  "status": "success",
  "result": {
    "hosts": [
      {
        "ip": "192.168.1.1",
        "mac": "00:11:22:33:44:55",
        "vendor": "Cisco",
        "hostname": "gateway",
        "first_seen": 1700000000,
        "last_seen": 1700086400,
        "open_ports": [22, 80, 443]
      }
    ],
    "stats": {
      "total_hosts": 42,
      "new_hosts_24h": 3
    },
    "graph": {
      "nodes": [],
      "edges": []
    },
    "service_status": {
      "running": true,
      "paused": false,
      "packet_count": 150000
    }
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.hosts` | `object[]` | List of discovered hosts |
| `result.hosts[].ip` | `string` | IP address |
| `result.hosts[].mac` | `string` | MAC address |
| `result.hosts[].vendor` | `string` \| `null` | OUI vendor name |
| `result.hosts[].hostname` | `string` \| `null` | Resolved hostname |
| `result.hosts[].first_seen` | `integer` | Epoch timestamp of first discovery |
| `result.hosts[].last_seen` | `integer` | Epoch timestamp of last sighting |
| `result.stats` | `object` | Aggregate statistics |
| `result.graph` | `object` | Topology graph data (nodes + edges) |
| `result.service_status` | `object` | Discovery service status |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "discovery_get_overview"}' | jq
```

---

## `discovery_get_host`

Returns details for a single host by its IP address.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `ip` | `string` | ✅ | IP address of the host |

### Request

```json
{
  "action": "discovery_get_host",
  "ip": "192.168.1.100"
}
```

### Response (success)

```json
{
  "status": "success",
  "result": {
    "host": {
      "ip": "192.168.1.100",
      "mac": "aa:bb:cc:dd:ee:ff",
      "vendor": "Intel",
      "hostname": "nas.local",
      "first_seen": 1700000000,
      "last_seen": 1700086400,
      "open_ports": [22, 80, 443, 445]
    }
  }
}
```

### Response (error)

```json
{
  "status": "error",
  "response_msg": "Host not found"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "discovery_get_host", "ip": "192.168.1.100"}' | jq
```

---

## Important notes

1. **Asynchronous operations:** `discovery_sweep_now` and `discovery_traceroute_all` start background tasks. The immediate response indicates the task was accepted, not completed.

2. **Pause/Resume:** Pausing stops passive sniffing. Active discovery tasks (sweep, traceroute) can still be triggered manually while paused.

3. **Prune threshold:** The default prune threshold is 10080 minutes (7 days). Use `discovery_prune_hosts` to remove old entries periodically.

---

## References

- PHP implementation (submit): `App\Controllers\Submit\DiscoverySubmitController`
- PHP implementation (request): `App\Controllers\Request\DiscoveryRequestController`
