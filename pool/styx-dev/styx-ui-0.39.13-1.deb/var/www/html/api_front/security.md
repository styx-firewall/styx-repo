# Security — Audit, auditd, and AIDE

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Get security overview | `POST /request.php` | `action: "get_sec_overview"` |
| Get audit report | `POST /request.php` | `action: "get_sec_audit"` |
| Get auditd config | `POST /request.php` | `action: "get_sec_auditd"` |
| Get AIDE data | `POST /request.php` | `action: "get_sec_aide"` |

## Common concepts

The security subsystem provides system hardening visibility through three complementary tools:

| Tool | Purpose |
|---|---|
| **Lynis** | System security audit — scans configuration, installed packages, kernel parameters, and file permissions against best-practice benchmarks |
| **auditd** | Linux Audit Framework — configurable system call and file access monitoring with persistent rule sets |
| **AIDE** | Advanced Intrusion Detection Environment — file integrity monitoring via cryptographic checksum baselines |

---

# request.php — Read operations

---

## `get_sec_overview`

Returns a high-level summary of the security audit subsystem status.

### Parameters

None.

### Request

```json
{
  "action": "get_sec_overview"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Security overview retrieved",
  "result": {
    "audit_summary": {
      "status": "pass",
      "hardening_index": 72,
      "last_audit": "2026-03-26T10:00:00Z",
      "suggestions": 3,
      "tests": 258
    }
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.audit_summary.status` | `string` | Overall audit status: `"pass"`, `"fail"`, or `"warn"` |
| `result.audit_summary.hardening_index` | `integer` | Hardening score (0–100, higher is better) |
| `result.audit_summary.last_audit` | `string` (ISO8601) \| `null` | Timestamp of the last audit run |
| `result.audit_summary.suggestions` | `integer` | Number of improvement suggestions |
| `result.audit_summary.tests` | `integer` | Number of tests performed |

If no audit has been run yet:

```json
{
  "status": "success",
  "result": {
    "audit_summary": {
      "status": "fail"
    }
  }
}
```

### Backend command

This action calls the backend daemon command `security.get_overview`.

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_sec_overview"}' | jq
```

---

## `get_sec_audit`

Returns the latest full Lynis audit report.

### Parameters

None.

### Request

```json
{
  "action": "get_sec_audit"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Audit report retrieved",
  "result": {
    "report": {
      "hostname": "styx-gateway",
      "os_version": "Debian 12",
      "kernel": "6.1.0-20-amd64",
      "hardening_index": 72,
      "test_count": 258,
      "last_scan": "2026-03-26T10:00:00Z",
      "scanned_files": 12000,
      "warnings": [
        {
          "test": "AUTH-9282",
          "description": "Configure minimum password aging",
          "suggestion": "Set PASS_MIN_DAYS to 7 in /etc/login.defs"
        }
      ],
      "suggestions": [
        {
          "test": "KRNL-5830",
          "description": "Enable kernel hardening features"
        }
      ]
    }
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.report` | `object` \| `null` | Full audit report object, or `null` if no audit has been run |
| `result.report.hardening_index` | `integer` | Hardening score |
| `result.report.warnings` | `object[]` | Items requiring attention |
| `result.report.suggestions` | `object[]` | Improvement suggestions |
| `result.report.last_scan` | `string` (ISO8601) | When the audit was last executed |

### Backend command

This action calls the backend daemon command `security.get_audit`.

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_sec_audit"}' | jq
```

---

## `get_sec_auditd`

Returns the current `auditd` daemon configuration.

### Parameters

None.

### Request

```json
{
  "action": "get_sec_auditd"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Auditd config retrieved",
  "result": {
    "config": {
      "log_file": "/var/log/audit/audit.log",
      "log_format": "RAW",
      "max_log_file": "8",
      "max_log_file_action": "ROTATE",
      "space_left": "75",
      "space_left_action": "SYSLOG",
      "admin_space_left": "50",
      "admin_space_left_action": "SUSPEND",
      "disk_full_action": "SUSPEND",
      "disk_error_action": "SUSPEND",
      "flush": "INCREMENTAL"
    }
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.config` | `object` | Parsed `auditd.conf` key-value pairs (keys vary by configuration) |

### Backend command

This action calls the backend daemon command `security.get_auditd_config`.

> **⚠️ Note:** The auditd config endpoint currently returns only the configuration keys known to the parser. If `auditd` is not installed or the config file is missing, the response may return an empty config object.

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_sec_auditd"}' | jq
```

---

## `get_sec_aide`

Returns AIDE (Advanced Intrusion Detection Environment) baseline and scan summary.

### Parameters

None.

### Request

```json
{
  "action": "get_sec_aide"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "AIDE data retrieved",
  "result": {
    "database": {
      "initialized": true,
      "last_scan": "2026-03-20T08:00:00Z",
      "file_count": 45000
    },
    "report": {
      "added": 0,
      "removed": 0,
      "changed": 5,
      "summary": "5 files have changed since the last baseline"
    },
    "scan_summary": {
      "total_entries": 45000,
      "added_entries": 0,
      "removed_entries": 0,
      "changed_entries": 5
    }
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.database.initialized` | `boolean` | Whether an AIDE database (baseline) exists |
| `result.database.last_scan` | `string` (ISO8601) \| `null` | Last AIDE scan timestamp |
| `result.report.added` | `integer` | Files added since baseline |
| `result.report.removed` | `integer` | Files removed since baseline |
| `result.report.changed` | `integer` | Files changed since baseline |
| `result.scan_summary` | `object` | Detailed scan breakdown |

If AIDE is not installed:

```json
{
  "status": "success",
  "result": {
    "database": { "initialized": false, "last_scan": null, "file_count": 0 },
    "report": null
  }
}
```

### Implementation note

Unlike the other security actions (which call the backend daemon), `get_sec_aide` runs AIDE checks **locally in the PHP layer** via `AideService`. It does not send a command to the Python daemon.

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_sec_aide"}' | jq
```

---

## Accessing audit rules

The backend daemon also supports retrieving the currently loaded audit rules via the `security.get_audit_rules` command. This is available as a raw daemon command but is **not currently exposed** as a request.php action. To access it directly against the daemon:

```json
{
  "commands": [
    {
      "method": "security.get_audit_rules",
      "id": "get_rules"
    }
  ]
}
```

Response:

```json
{
  "get_rules": {
    "status": "success",
    "result": {
      "rules": [],
      "total": 0
    }
  }
}
```

---

## Important notes

1. **Audit runs are asynchronous:** Running a security audit (`security.run_audit`) kicks off an asynchronous background task on the backend. The result is stored and can be retrieved with `get_sec_audit` after completion.

2. **AIDE baseline:** AIDE requires an initialized database (baseline) before it can detect file changes. If `database.initialized` is `false`, run an initial scan to create the baseline.

3. **Lynis vs AIDE:** Lynis audits configuration hardening (equivalent to CIS benchmarks). AIDE monitors file integrity. Both are complementary; run both for comprehensive security visibility.

---

## References

- Backend handler: `api/handlers/security.md`
- Request schemas: `api/schemas/security/requests/`
- Response schemas: `api/schemas/security/responses/`
- PHP implementation (request): `App\Controllers\Request\SecurityRequestController`
- AIDE Service: `App\Services\AideService`
