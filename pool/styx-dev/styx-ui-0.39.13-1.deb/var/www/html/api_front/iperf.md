# iperf3 — Network bandwidth testing

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Start iperf server | `POST /submit.php` | `command: "iperf_start_server"` |
| Stop iperf server | `POST /submit.php` | `command: "iperf_stop_server"` |
| Start client test | `POST /submit.php` | `command: "iperf_start_client_test"` |
| Get status and tasks | `POST /request.php` | `action: "iperf_status_and_tasks"` |
| Get task result | `POST /request.php` | `action: "iperf_get_task_result"` |
| Get page data | `POST /request.php` | `action: "iperf_get_page_data"` |

---

# submit.php — Write operations

---

## `iperf_start_server`

Starts an iperf3 server process in the background.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `port` | `integer` | ❌ | Server port (default: 5201) |
| `one_off` | `boolean` | ❌ | Handle one connection then exit |
| `udp` | `boolean` | ❌ | Use UDP instead of TCP |
| `bind_address` | `string` | ❌ | Bind to specific IP |
| `window` | `integer` | ❌ | TCP window size |
| `tos` | `integer` | ❌ | Type of Service byte |
| `forceflush` | `boolean` | ❌ | Force flushing output |
| `username` | `string` | ❌ | Authentication username |
| `password` | `string` | ❌ | Authentication password |

### Request

```json
{
  "command": "iperf_start_server",
  "port": 5201,
  "bind_address": "0.0.0.0"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "iperf server started",
  "result": {
    "pid": 142828,
    "port": 5201,
    "started_at": "2026-03-20T09:26:58Z",
    "cmd": ["iperf3", "-s", "-p", "5201", "-B", "0.0.0.0"],
    "status": "running"
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.pid` | `integer` | Server process PID |
| `result.port` | `integer` | Listening port |
| `result.started_at` | `string` (ISO8601) | Start timestamp |
| `result.status` | `string` | `"running"` or `"stopped"` |

### Response (error)

```json
{
  "status": "error",
  "response_msg": "iperf server died on startup",
  "result": {
    "pid": 142828,
    "returncode": 1,
    "stderr": "bind: Address already in use"
  }
}
```

---

## `iperf_stop_server`

Stops a running iperf3 server.

### Parameters

None.

### Request

```json
{
  "command": "iperf_stop_server"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "iperf server stopped"
}
```

---

## `iperf_start_client_test`

Starts an iperf3 client test (asynchronous — returns a `task_id`).

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `server_ip` | `string` | ✅ | Target server IP address |
| `port` | `integer` | ❌ | Server port (default: 5201) |
| `duration` | `integer` | ❌ | Test duration in seconds |
| `parallel` | `integer` | ❌ | Number of parallel streams |
| `bandwidth` | `string` | ❌ | Target bandwidth (e.g. `"100m"`) |
| `udp` | `boolean` | ❌ | Use UDP |
| `reverse` | `boolean` | ❌ | Reverse mode (server sends, client receives) |
| `interval` | `integer` | ❌ | Reporting interval |
| `window` | `integer` | ❌ | TCP window size |
| `tos` | `integer` | ❌ | Type of Service |
| `omit` | `integer` | ❌ | Omit first N seconds |
| `forceflush` | `boolean` | ❌ | Force flush |
| `get_server_output` | `boolean` | ❌ | Include server-side output |
| `username` | `string` | ❌ | Authentication username |
| `password` | `string` | ❌ | Authentication password |
| `verbose` | `boolean` | ❌ | Verbose output |

### Request

```json
{
  "command": "iperf_start_client_test",
  "server_ip": "192.168.1.100",
  "port": 5201,
  "duration": 10,
  "parallel": 4
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Test started",
  "result": {
    "task_id": "task-uuid-1"
  }
}
```

---

# request.php — Read operations

---

## `iperf_status_and_tasks`

Returns the server status and any active/completed tasks.

### Parameters

None.

### Request

```json
{
  "action": "iperf_status_and_tasks"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Status retrieved",
  "result": {
    "server_running": true,
    "server_pid": 142828,
    "tasks": [
      { "task_id": "task-uuid-1", "status": "completed" }
    ]
  }
}
```

---

## `iperf_get_page_data`

Returns initial page data for the iperf UI (server status, active tasks, recent results).

### Parameters

None.

### Request

```json
{
  "action": "iperf_get_page_data"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Page data retrieved",
  "result": {
    "server_running": true,
    "server_pid": 142828,
    "server_port": 5201,
    "tasks": []
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "iperf_get_page_data"}' | jq
```

---

## `iperf_get_task_result`

Returns the result of a completed iperf test.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `task_id` | `string` | ✅ | Task UUID returned by `iperf_start_client_test` |

### Request

```json
{
  "action": "iperf_get_task_result",
  "task_id": "task-uuid-1"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Task result retrieved",
  "result": {
    "task_id": "task-uuid-1",
    "status": "completed",
    "result": {
      "bits_per_second": 950000000,
      "jitter_ms": 0.5,
      "lost_percent": 0.01
    }
  }
}
```

---

## Important notes

1. **Client tests are asynchronous:** `iperf_start_client_test` returns a `task_id`. Poll `iperf_get_task_result` or `iperf_status_and_tasks` to get the result.

2. **Server diagnostics:** On server start failure, check `result.stderr` and `result.returncode` for diagnostics. `result.stderr_head` may contain the first 500 characters of stderr.

3. **Multiple servers:** Only one iperf3 server can run at a time on a given port.

---

## References

- Backend handler: `api/handlers/iperf.md`
- PHP implementation (submit): `App\Controllers\Submit\IperfSubmitController`
- PHP implementation (request): `App\Controllers\Request\IperfRequestController`
