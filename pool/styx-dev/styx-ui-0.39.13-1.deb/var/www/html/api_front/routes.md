# Routes — Static routing

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Add route | `POST /submit.php` | `command: "add_route"` |
| Delete route by ID | `POST /submit.php` | `command: "delete_route_by_id"` |
| Get routing page data | `POST /request.php` | `action: "get_routing_page_data"` |

## Common concepts

### Set-based addressing

Routes use **address-set UUIDs** (not literal IPs/CIDRs) for `dst` and `gateway`, and **interface UUIDs** for `dev`:

- `dst` — UUID of an **address set** with `type: "single"` and `scope: "host"` or `"network"`
- `gateway` — UUID of an **address set** with `type: "single"` and `scope: "host"`
- `dev` — UUID of an **interface** (from `config_interfaces`)

### How to create a route

1. Create the destination address set via `set_address` → get its UUID
2. (Optional) Create the gateway address set via `set_address` → get its UUID
3. Get the interface UUID via `get_interfaces_names_ds`
4. Call `add_route` with these UUIDs

---

# submit.php — Write operations

---

## `add_route`

Adds a new static route.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `route` | `object` | ✅ | Route object (see below) |
| `ipv6` | `boolean` | ❌ | Set to `true` for IPv6 routes (default: `false`) |

**`route` object:**

| Field | Type | Required | Description |
|---|---|---|---|
| `dst` | `string` (UUID) | ✅ | Address-set UUID for destination (type: `single`, scope: `host` or `network`) |
| `gateway` | `string` (UUID) | ❌ | Address-set UUID for gateway (type: `single`, scope: `host`) |
| `dev` | `string` (UUID) | ❌ | Interface UUID |
| `metric` | `integer` | ❌ | Route metric |
| `mtu` | `integer` | ❌ | Route MTU |
| `table` | `string` | ❌ | Routing table name or ID |
| `custom_table_id` | `integer` | ❌ | Custom routing table ID |
| `prefsrc` | `string` | ❌ | Preferred source address |
| `flags` | `string[]` | ❌ | Route flags |
| `path_mode` | `string` | ❌ | `"single"` or `"multipath"` |
| `nexthops` | `object[]` | ❌ | Multipath nexthops (see below) |

**`nexthops[]` object:**

| Field | Type | Required | Description |
|---|---|---|---|
| `gateway` | `string` (UUID) | ❌ | Gateway address-set UUID |
| `dev` | `string` (UUID) | ❌ | Interface UUID |
| `weight` | `integer` | ❌ | Nexthop weight |
| `metric` | `integer` | ❌ | Nexthop metric |
| `flags` | `string[]` | ❌ | Nexthop flags |

### Request — simple route

```json
{
  "command": "add_route",
  "route": {
    "dst": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
    "gateway": "bbbbbbbb-cccc-dddd-eeee-ffffffffffff",
    "dev": "11111111-2222-3333-4444-555555555555",
    "metric": 100
  },
  "ipv6": false
}
```

### Request — multipath route

```json
{
  "command": "add_route",
  "route": {
    "dst": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
    "path_mode": "multipath",
    "nexthops": [
      {
        "gateway": "bbbbbbbb-cccc-dddd-eeee-ffffffffffff",
        "dev": "11111111-2222-3333-4444-555555555555",
        "weight": 1,
        "metric": 100
      },
      {
        "gateway": "cccccccc-dddd-eeee-ffff-aaaaaaaaaaaa",
        "dev": "22222222-3333-4444-5555-666666666666",
        "weight": 1,
        "metric": 200
      }
    ]
  }
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Route added successfully",
  "result": {
    "id": "route-uuid-1"
  }
}
```

### Response (error)

```json
{
  "status": "error",
  "response_msg": "dst address set not found"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "add_route",
    "route": {
      "dst": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
      "gateway": "bbbbbbbb-cccc-dddd-eeee-ffffffffffff",
      "dev": "11111111-2222-3333-4444-555555555555",
      "metric": 100
    }
  }' | jq
```

---

## `delete_route_by_id`

Deletes a route by its datastore route ID.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `route_id` | `string` (UUID) | ✅ | Route identifier |
| `ipv6` | `boolean` | ❌ | Set to `true` for IPv6 routes |

### Request

```json
{
  "command": "delete_route_by_id",
  "route_id": "route-uuid-1",
  "ipv6": false
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Route deleted"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "delete_route_by_id",
    "route_id": "route-uuid-1"
  }' | jq
```

---

# request.php — Read operations

---

## `get_routing_page_data`

Returns all routes (IPv4 and IPv6) with resolved values for display, plus routing tables.

### Parameters

None.

### Request

```json
{
  "action": "get_routing_page_data"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Routing data retrieved",
  "result": {
    "ipv4": [
      {
        "id": "route-uuid-1",
        "dst": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
        "dst_value": "192.0.2.0/24",
        "gateway": "bbbbbbbb-cccc-dddd-eeee-ffffffffffff",
        "gateway_value": "198.51.100.1",
        "dev": "11111111-2222-3333-4444-555555555555",
        "dev_name": "eth0",
        "metric": 100,
        "table": "main"
      }
    ],
    "ipv6": [],
    "routing_tables": [
      { "table_id": "main", "priority": 32766 },
      { "table_id": "220", "name": "custom", "priority": 220 }
    ]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.ipv4` | `object[]` | IPv4 routes |
| `result.ipv4[].id` | `string` (UUID) | Route identifier |
| `result.ipv4[].dst` | `string` (UUID) | Stored destination address-set UUID |
| `result.ipv4[].dst_value` | `string` | Resolved destination IP/CIDR for display |
| `result.ipv4[].gateway` | `string` (UUID) \| `null` | Stored gateway address-set UUID |
| `result.ipv4[].gateway_value` | `string` \| `null` | Resolved gateway IP for display |
| `result.ipv4[].dev` | `string` (UUID) \| `null` | Stored interface UUID |
| `result.ipv4[].dev_name` | `string` \| `null` | Resolved interface name for display |
| `result.ipv4[].metric` | `integer` | Route metric |
| `result.routing_tables` | `object[]` | Configured routing tables |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "get_routing_page_data"}' | jq
```

---

## Important notes

1. **Address-set UUIDs:** The `dst` and `gateway` fields must reference existing address sets. Create them first via `set_address`, then use the returned UUID.

2. **Interface UUIDs:** The `dev` field must reference an existing interface UUID. Get it via `get_interfaces_names_ds`.

3. **Refs management:** When a route is created, the system automatically adds the route ID to the `refs` list of referenced address sets and interfaces. This prevents deleting a set while it's in use.

4. **Resolved fields in responses:** Responses include `dst_value`, `gateway_value`, and `dev_name` — these are the resolved, human-readable versions of the stored UUIDs.

---

## References

- Backend handler: `api/handlers/routing.md`
- Request schemas: `api/schemas/routing/requests/`
- Response schemas: `api/schemas/routing/responses/`
- PHP implementation (submit): `App\Controllers\Submit\RoutesSubmitController`
- PHP implementation (request): `App\Controllers\Request\NetworkRequestController`
