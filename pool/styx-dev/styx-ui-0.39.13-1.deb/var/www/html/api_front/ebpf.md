# eBPF — Extended Berkeley Packet Filter modules

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Attach eBPF module | `POST /submit.php` | `command: "ebpf_attach"` |
| Detach eBPF module | `POST /submit.php` | `command: "ebpf_detach"` |
| Get available modules | `POST /request.php` | `action: "ebpf_get_modules"` |
| Get attached modules | `POST /request.php` | `action: "ebpf_get_attached"` |
| Get feedback stats | `POST /request.php` | `action: "ebpf_get_feedback_stats"` |
| Get feedback events | `POST /request.php` | `action: "ebpf_get_feedback_events"` |
| Get feedback alerts | `POST /request.php` | `action: "ebpf_get_feedback_alerts"` |

---

# submit.php — Write operations

---

## `ebpf_attach`

Attaches an eBPF module to the system.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| *varies* | *varies* | ✅ | Module attachment parameters |

### Request

```json
{
  "command": "ebpf_attach",
  "module_name": "packet_stats",
  "interface": "eth0"
}
```

---

## `ebpf_detach`

Detaches a running eBPF module.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `module_name` | `string` | ✅ | Module name to detach |

### Request

```json
{
  "command": "ebpf_detach",
  "module_name": "packet_stats"
}
```

---

# request.php — Read operations

---

## `ebpf_get_modules`

Returns the list of available eBPF modules.

### Parameters

None.

### Request

```json
{
  "action": "ebpf_get_modules"
}
```

---

## `ebpf_get_attached`

Returns the list of currently attached eBPF modules.

### Parameters

None.

### Request

```json
{
  "action": "ebpf_get_attached"
}
```

---

## `ebpf_get_feedback_stats`

Returns statistical data from eBPF feedback modules.

### Parameters

None.

---

## `ebpf_get_feedback_events`

Returns event data from eBPF feedback modules.

### Parameters

None.

---

## `ebpf_get_feedback_alerts`

Returns alert data from eBPF feedback modules.

### Parameters

None.

---

## References

- PHP implementation (submit): `App\Controllers\Submit\EbpfSubmitController`
- PHP implementation (request): `App\Controllers\Request\EbpfRequestController`
