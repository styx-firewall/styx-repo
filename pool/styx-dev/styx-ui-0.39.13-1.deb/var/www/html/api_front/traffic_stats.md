# Traffic Statistics — Interface traffic counters

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Reset traffic stats | `POST /submit.php` | `command: "traffic-stats-reset"` |
| Get traffic stats | `POST /request.php` | `action: "traffic-stats-get"` |

---

# submit.php — Write operations

---

## `traffic-stats-reset`

Resets accumulated traffic statistics (bytes/packets counters) for interfaces.

### Parameters

None.

### Request

```json
{
  "command": "traffic-stats-reset"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Traffic stats reset"
}
```

---

# request.php — Read operations

---

## `traffic-stats-get`

Returns current traffic statistics for all interfaces.

### Parameters

None.

### Request

```json
{
  "action": "traffic-stats-get"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Traffic stats retrieved",
  "result": {
    "interfaces": [
      {
        "interface": "eth0",
        "rx_bytes": 1500000000,
        "tx_bytes": 800000000,
        "rx_packets": 1200000,
        "tx_packets": 900000,
        "timestamp": 1700000000
      }
    ]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.interfaces[].interface` | `string` | Interface name |
| `result.interfaces[].rx_bytes` | `integer` | Received bytes |
| `result.interfaces[].tx_bytes` | `integer` | Transmitted bytes |
| `result.interfaces[].rx_packets` | `integer` | Received packets |
| `result.interfaces[].tx_packets` | `integer` | Transmitted packets |
| `result.interfaces[].timestamp` | `integer` | Epoch timestamp of the sample |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "traffic-stats-get"}' | jq
```

---

## Important notes

1. **Cumulative counters:** The returned values are cumulative since the last reset (or system boot).

2. **Reset scope:** `traffic-stats-reset` clears all interface counters at once.

---

## References

- PHP implementation (submit): `App\Controllers\Submit\TrafficStatsSubmitController`
- PHP implementation (request): `App\Controllers\Request\TrafficStatsRequestController`
