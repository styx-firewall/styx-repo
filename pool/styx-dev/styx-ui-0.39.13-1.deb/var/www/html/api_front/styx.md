# Styx — Backups, logs, settings, features, and events

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Restore backup | `POST /submit.php` | `command: "styx-backup-restore"` |
| Get Styx logs | `POST /submit.php` | `command: "get_styx_logs"` |
| Update web settings | `POST /submit.php` | `command: "update_web_settings"` |
| Restart Styx UI | `POST /submit.php` | `command: "restart_styx_ui"` |
| Toggle event ack | `POST /submit.php` | `command: "toggle_ack"` |
| Get Styx settings | `POST /request.php` | `action: "styx_get_settings"` |
| Get events | `POST /request.php` | `action: "styx_get_events"` |
| Get features full | `POST /request.php` | `action: "styx_get_features_full"` |
| Get enabled features | `POST /request.php` | `action: "styx_get_features_full"` with flag |
| Get backup types | `POST /request.php` | `action: "styx_get_backup_types"` |
| Download backup | `POST /request.php` | `action: "styx-backup-download"` |

---

# submit.php — Write operations

---

## `styx-backup-restore`

Restores the system from a backup configuration.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | `string` | ✅ | Backup type (e.g. `"startup"`) |
| `backup` | `string` | ✅ | Backup content |

### Request

```json
{
  "command": "styx-backup-restore",
  "type": "startup",
  "backup": "{...JSON content...}"
}
```

---

## `get_styx_logs`

Retrieves Styx daemon logs.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `limit` | `integer` | ❌ | Maximum number of log entries (default: 50) |
| `level` | `integer` | ❌ | Minimum log level |

### Request

```json
{
  "command": "get_styx_logs",
  "limit": 100
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Logs retrieved",
  "result": [
    { "timestamp": "2026-03-26T10:00:00Z", "level": 4, "message": "Service started" }
  ]
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"command": "get_styx_logs", "limit": 50}' | jq
```

---

## `update_web_settings`

Updates Styx web interface settings.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| *varies* | *varies* | ❌ | Settings object |

### Request

```json
{
  "command": "update_web_settings",
  "theme": "dark",
  "language": "en"
}
```

---

## `restart_styx_ui`

Restarts the Styx UI web service.

### Parameters

None.

### Request

```json
{
  "command": "restart_styx_ui"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Styx UI restarted"
}
```

---

## `toggle_ack`

Toggles the acknowledgement flag on an event.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `event_id` | `string` (UUID) | ✅ | Event identifier |

### Request

```json
{
  "command": "toggle_ack",
  "event_id": "123e4567-e89b-12d3-a456-426614174000"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Event ack toggled",
  "result": {
    "event_id": "123e4567-e89b-12d3-a456-426614174000"
  }
}
```

---

# request.php — Read operations

---

## `styx_get_settings`

Returns Styx system settings.

### Parameters

None.

### Request

```json
{
  "action": "styx_get_settings"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Settings retrieved",
  "result": {
    "settings": {
      "log_level": 4,
      "log_max_size": 10485760
    }
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "styx_get_settings"}' | jq
```

---

## `styx_get_events`

Returns events from the event manager with optional filtering.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `limit` | `integer` | ❌ | Maximum number of events (default: 50) |
| `event_type` | `integer` | ❌ | Filter by event type code |
| `level` | `integer` | ❌ | Filter by minimum log level |
| `message_contains` | `string` | ❌ | Filter by message substring |

### Request

```json
{
  "action": "styx_get_events",
  "limit": 20
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Events retrieved",
  "result": {
    "events": [
      {
        "id": "123e4567-e89b-12d3-a456-426614174000",
        "timestamp": 1720180000.0,
        "timestamp_iso": "2026-03-18T12:34:56Z",
        "event_type": 701,
        "event_name": "EVENT_FIREWALL_ALERT",
        "message": "Firewall rule matched",
        "data": { "rule_id": 42 },
        "level": 1,
        "level_name": "ALERT",
        "ack": 0
      }
    ]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.events[].id` | `string` (UUID) | Event UUID |
| `result.events[].timestamp` | `number` | Epoch timestamp (seconds) |
| `result.events[].timestamp_iso` | `string` (ISO8601) | UTC timestamp for display |
| `result.events[].event_type` | `integer` | Numeric event type code |
| `result.events[].event_name` | `string` | Human-readable event name |
| `result.events[].message` | `string` | Event description |
| `result.events[].data` | `object` \| `null` | Event-specific payload |
| `result.events[].level` | `integer` | Numeric log level |
| `result.events[].level_name` | `string` | Level name (`INFO`, `ALERT`, etc.) |
| `result.events[].ack` | `integer` | `0` = not acknowledged, `1` = acknowledged |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "styx_get_events", "limit": 10}' | jq
```

---

## `styx_get_features_full`

Returns the full features definition with option states.

### Parameters

None.

### Request

```json
{
  "action": "styx_get_features_full"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Features retrieved",
  "result": {
    "features": {
      "routing": { "enabled": true, "options": { "advanced_routing": true } },
      "vpn": { "enabled": true },
      "sla_monitor": { "enabled": true }
    }
  }
}
```

---

## `styx-backup-download`

Downloads a full backup configuration from the backend. Used by the backup page's download button.

### Parameters

Pass the backup type nested under a `data` key:

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | `string` | ✅ | Backup type identifier (obtained from `styx_get_backup_types`) |

### Request

```json
{
  "action": "styx-backup-download",
  "data": {
    "type": "startup"
  }
}
```

### Response (success)

```json
{
  "status": "success",
  "result": {
    "backup_content": "{...escaped json...}",
    "type": "startup",
    "filename": "styx-backup-startup-20260326-120000.json"
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.backup_content` | `string` \| `object` | Backup configuration content |
| `result.type` | `string` | Backup type |
| `result.filename` | `string` | Suggested filename for download |

> **Note:** The `backup_content` is raw backup data — the frontend JSON-stringifies it before creating the downloadable blob.

### Backend command

This action calls `styx-mgmt.get_backup` on the daemon.

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "styx-backup-download", "data": {"type": "startup"}}' | jq
```

---

## `styx_get_backup_types`

Returns available backup types for restoring configurations.

### Parameters

None.

### Request

```json
{
  "action": "styx_get_backup_types"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Backup types retrieved",
  "result": {
    "backup_types": [
      {
        "id": "startup",
        "label": "Startup configuration",
        "description": "Last known good startup configuration"
      },
      {
        "id": "running",
        "label": "Running configuration",
        "description": "Currently active configuration"
      }
    ]
  }
}
```

| Field | Type | Description |
|---|---|---|
| `result.backup_types[].id` | `string` | Backup type identifier (use in `styx-backup-restore.type`) |
| `result.backup_types[].label` | `string` | Display label |
| `result.backup_types[].description` | `string` | Human-readable description |

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "styx_get_backup_types"}' | jq
```

---

## Important notes

1. **Events** use a numeric `ack` field (`0`/`1`), not booleans. Toggle with `toggle_ack`.

2. **Event timestamps** are available in both epoch (`timestamp`) and ISO8601 (`timestamp_iso`) formats. Use `timestamp_iso` for display.

---

## References

- Backend handler (events): `api/handlers/event_manager.md`
- Backend handler (features): `api/handlers/styx_features.md`
- Backend handler (management): `api/handlers/styx_mgmt.md`
- PHP implementation (submit): `App\Controllers\Submit\StyxSubmitController`, `App\Controllers\Submit\EventSubmitController`, `App\Controllers\Submit\FeaturesSubmitController`
- PHP implementation (request): `App\Controllers\Request\StyxRequestController`
