# DHCP — Server configuration, reservations, and leases

## Endpoints used

| Operation | Endpoint | Key parameter |
|---|---|---|
| Set per-interface DHCP config | `POST /submit.php` | `command: "set_dhcp_config"` |
| Set DHCP reservations | `POST /submit.php` | `command: "set_dhcp_reservations"` |
| Set global DHCP config | `POST /submit.php` | `command: "set_dhcp_global_config"` |
| Get DHCP page data | `POST /request.php` | `action: "dhcp_get_page_data"` |

## Common concepts

DHCP configuration uses **set UUIDs** for IP ranges, gateways, DNS servers, and domain names — similar to firewall rules and routes.

| Field type | Set command | Set types accepted |
|---|---|---|
| `range_set_id`, `range6_set_id` | `set_address` | `type: "range"` |
| `gateway_set_id`, `gateway6_set_id` | `set_address` | `type: "single"`, `scope: "host"` |
| `dns_set_id`, `dns6_set_id` | `set_address` | `type: "single"` or `"set"` |
| `domain_set_id`, `domain6_set_id` | `set_domain` | `type: "single"` |
| `domain_search_set_id` | `set_domain` | `type: "single"` or `"set"` |

---

# submit.php — Write operations

---

## `set_dhcp_global_config`

Sets global DHCP server defaults.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `default_lease_time` | `integer` | ❌ | Default lease duration in seconds (default: 3600) |
| `max_lease_time` | `integer` | ❌ | Maximum lease duration a client may request (default: 3600) |
| `renew_timer` | `integer` | ❌ | T1 timer — time until client begins unicast renewal (default: 900) |
| `rebind_timer` | `integer` | ❌ | T2 timer — time until client begins broadcast rebind (default: 1800) |
| `global_dns_set_id` | `string` (UUID) | ❌ | Address-set UUID for global DNS servers |
| `global_domain_set_id` | `string` (UUID) | ❌ | Domain-set UUID for global domain name |
| `global_domain_search_set_id` | `string` (UUID) | ❌ | Domain-set UUID for global domain search list |

### Request

```json
{
  "command": "set_dhcp_global_config",
  "default_lease_time": 3600,
  "max_lease_time": 7200,
  "renew_timer": 900,
  "rebind_timer": 1800,
  "global_dns_set_id": "uuid-address-set-dns",
  "global_domain_set_id": "uuid-domain-set"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Global DHCP configuration saved"
}
```

---

## `set_dhcp_config`

Sets per-interface DHCP configuration.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `interface_id` | `string` (UUID) | ✅ | Interface UUID |
| `range_set_id` | `string` (UUID) | ❌ | Address-set UUID for IPv4 pool range |
| `range6_set_id` | `string` (UUID) | ❌ | Address-set UUID for IPv6 pool range |
| `gateway_set_id` | `string` (UUID) | ❌ | Address-set UUID for IPv4 gateway |
| `gateway6_set_id` | `string` (UUID) | ❌ | Address-set UUID for IPv6 gateway |
| `dns_set_id` | `string` (UUID) | ❌ | Address-set UUID for IPv4 DNS servers |
| `dns6_set_id` | `string` (UUID) | ❌ | Address-set UUID for IPv6 DNS servers |
| `domain_set_id` | `string` (UUID) | ❌ | Domain-set UUID for IPv4 domain name |
| `domain6_set_id` | `string` (UUID) | ❌ | Domain-set UUID for IPv6 domain name |
| `lease_time` | `integer` | ❌ | Per-interface lease duration override (seconds) |

### Request

```json
{
  "command": "set_dhcp_config",
  "interface_id": "11111111-2222-3333-4444-555555555555",
  "range_set_id": "uuid-address-set-dhcp-range",
  "gateway_set_id": "uuid-address-set-gateway",
  "dns_set_id": "uuid-address-set-dns",
  "domain_set_id": "uuid-domain-set",
  "lease_time": 3600
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "DHCP configuration saved"
}
```

---

## `set_dhcp_reservations`

Sets DHCP reservations for an interface (static leases).

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `interface_id` | `string` (UUID) | ✅ | Interface UUID |
| `reservations` | `object[]` | ❌ | IPv4 reservation list |
| `reservations6` | `object[]` | ❌ | IPv6 reservation list |

**Reservation object:**

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | `string` | ✅ | Host name |
| `ip` | `string` | ✅ | IPv4 address |
| `mac` | `string` | ✅ | MAC address |

### Request

```json
{
  "command": "set_dhcp_reservations",
  "interface_id": "11111111-2222-3333-4444-555555555555",
  "reservations": [
    {
      "name": "printer",
      "ip": "192.168.1.100",
      "mac": "00:11:22:33:44:55"
    },
    {
      "name": "nas",
      "ip": "192.168.1.101",
      "mac": "00:aa:bb:cc:dd:ee"
    }
  ],
  "reservations6": []
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "Reservations saved"
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/submit.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "command": "set_dhcp_config",
    "interface_id": "11111111-2222-3333-4444-555555555555",
    "range_set_id": "uuid-address-set-range",
    "gateway_set_id": "uuid-address-set-gw",
    "dns_set_id": "uuid-address-set-dns"
  }' | jq
```

---

# request.php — Read operations

---

## `dhcp_get_page_data`

Returns all DHCP configuration — global config, per-interface config, reservations, and leases.

### Parameters

| Field | Type | Required | Description |
|---|---|---|---|
| `interface_id` | `string` (UUID) | ❌ | Filter by interface |
| `ip_version` | `string` | ❌ | `"ipv4"` or `"ipv6"` |

### Request

```json
{
  "action": "dhcp_get_page_data"
}
```

### Response (success)

```json
{
  "status": "success",
  "response_msg": "DHCP page data retrieved",
  "result": {
    "global_config": {
      "default_lease_time": 3600,
      "max_lease_time": 7200,
      "global_dns_set_id": "uuid-dns-set"
    },
    "interfaces": {
      "11111111-2222-3333-4444-555555555555": {
        "range_set_id": "uuid-range-set",
        "gateway_set_id": "uuid-gw-set",
        "dns_set_id": "uuid-dns-set",
        "reservations": [
          { "name": "printer", "ip": "192.168.1.100", "mac": "00:11:22:33:44:55" }
        ]
      }
    },
    "leases": [
      {
        "ip": "192.168.1.50",
        "mac": "aa:bb:cc:dd:ee:ff",
        "hostname": "laptop",
        "expires": "2026-04-01T12:00:00Z"
      }
    ]
  }
}
```

### curl example

```bash
curl -s -X POST 'https://styx.local/request.php' \
  -H 'Authorization: Bearer tk_live_xxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"action": "dhcp_get_page_data"}' | jq
```

---

## Important notes

1. **Set UUIDs:** DHCP configuration uses the same set-based model as firewall rules and routes. Create address sets and domain sets first, then reference them by UUID.

2. **Reservations use literal values** (IP and MAC), not set references. They are stored with their explicit payload.

3. **Timer values** are all in seconds. The defaults map directly to Kea DHCP server parameters.

---

## References

- Backend handler: `api/handlers/dhcp_server.md`
- Request schemas: `api/schemas/dhcp_server/requests/`
- Response schemas: `api/schemas/dhcp_server/responses/`
- PHP implementation (submit): `App\Controllers\Submit\DhcpServerSubmitController`
- PHP implementation (request): `App\Controllers\Request\DhcpRequestController`
