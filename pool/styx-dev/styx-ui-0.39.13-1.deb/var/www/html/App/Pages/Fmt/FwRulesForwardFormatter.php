<?php
/**
 * Formatter for forward firewall rules presentation.
 */
namespace App\Pages\Fmt;

use App\Helpers\FormatHelper;

class FwRulesForwardFormatter
{
    /**
     * Prepare rules for presentation in templates.
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        if (!isset($fmt_data['rules']) || !is_array($fmt_data['rules'])) {
            return $fmt_data;
        }

        foreach ($fmt_data['rules'] as &$rule) {
            $rule['src_ifaces'] = isset($rule['src_ifaces']) && is_array($rule['src_ifaces'])
                ? implode('<br>', array_column($rule['src_ifaces'], 'name'))
                : '';
            $rule['dst_ifaces'] = isset($rule['dst_ifaces']) && is_array($rule['dst_ifaces'])
                ? implode('<br>', array_column($rule['dst_ifaces'], 'name'))
                : '';
            $rule['src_ips'] = isset($rule['src_ips']) && is_array($rule['src_ips'])
                ? implode('<br>', array_column($rule['src_ips'], 'name'))
                : '';
            $rule['dst_ips'] = isset($rule['dst_ips']) && is_array($rule['dst_ips'])
                ? implode('<br>', array_column($rule['dst_ips'], 'name'))
                : '';
            $rule['src_ports'] = isset($rule['src_ports']) && is_array($rule['src_ports'])
                ? implode('<br>', array_column($rule['src_ports'], 'name'))
                : '';
            $rule['dst_ports'] = isset($rule['dst_ports']) && is_array($rule['dst_ports'])
                ? implode('<br>', array_column($rule['dst_ports'], 'name'))
                : '';

            if (isset($rule['nat'])) {
                $rule['nat'] = $rule['nat'] ? '<span class="fw-status-ok">✔️</span>' : '<span class="fw-status-ko">✖️</span>';
            }
            if (isset($rule['log'])) {
                $rule['log'] = $rule['log'] ? '<span class="fw-log-icon">📝</span>' : '<span class="fw-muted">—</span>';
            }
            // Pre-format bytes for display
            $rule['bytes_formatted'] = isset($rule['bytes']) ? FormatHelper::formatBytes((int)$rule['bytes']) : '';

            if (isset($rule['enabled'])) {
                $enabledIcon = $rule['enabled'] ? '<span class="fw-enabled-on">🟢</span>' : '<span class="fw-enabled-off">🔴</span>';
                // Append warning icon if discrepancies exist
                if (!empty($rule['warnings']) && is_array($rule['warnings'])) {
                    $msgs = array_column($rule['warnings'], 'msg');
                    $title = implode("\n", $msgs);
                    $enabledIcon .= ' <span class="fw-warning-icon" title="' . $title . '">⚠️</span>';
                }
                $rule['enabled'] = $enabledIcon;
            }
        }
        unset($rule);

        // Prepare JSON-encoded payloads for the template presentation layer.
        $thead = [
            'enabled'    => 'Enabled',
            'name'       => 'Name',
            'family'     => 'Family',
            'chain'      => 'Chain',
            'src_ifaces' => 'In Interface',
            'dst_ifaces' => 'Out Interface',
            'src_ips'    => 'Source IPs',
            'src_ports'  => 'Source Ports',
            'dst_ips'    => 'Destination IPs',
            'dst_ports'  => 'Destination Ports',
            'action'     => 'Action',
            'nat'        => 'NAT',
            'log'        => 'Log',
            'packets'    => 'Packets',
            'bytes'      => 'Bytes',
            'handle'     => 'Handle',
            'id'         => 'ID',
            'comment'    => 'Comment',
        ];

        $columnsConfig = [
            'handle' => false,
            'id'     => false,
        ];

        $rows = array_map(function($r) {
            return [
                'name'       => $r['name'] ?? '',
                'family'     => $r['family'] ?? '',
                'chain'      => $r['chain'] ?? '',
                'src_ifaces' => $r['src_ifaces'] ?? '',
                'dst_ifaces' => $r['dst_ifaces'] ?? '',
                'src_ips'    => $r['src_ips'] ?? '',
                'src_ports'  => $r['src_ports'] ?? '',
                'dst_ips'    => $r['dst_ips'] ?? '',
                'dst_ports'  => $r['dst_ports'] ?? '',
                'action'     => $r['action'] ?? '',
                'nat'        => $r['nat'] ?? '',
                'log'        => $r['log'] ?? '',
                'enabled'    => $r['enabled'] ?? '',
                'comment'    => $r['comment'] ?? '',
                'packets'    => $r['packets'] ?? '',
                'bytes'      => $r['bytes_formatted'] ?? ($r['bytes'] ?? ''),
                'id'         => $r['id'] ?? '',
                'handle'     => $r['handle'] ?? '',
            ];
        }, $fmt_data['rules']);

        // Safe JSON encoding for embedding into HTML/JS
        $fmt_data['fw_thead_json'] = json_encode($thead, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
        $fmt_data['fw_rows_json'] = json_encode($rows, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
        $fmt_data['fw_columns_config_json'] = json_encode($columnsConfig);

        return $fmt_data;
    }
}
