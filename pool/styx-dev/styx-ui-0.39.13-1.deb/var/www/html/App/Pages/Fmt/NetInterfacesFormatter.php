<?php
/**
 * Formatter for network interfaces page.
 * Prepares presentation-ready arrays for the template to consume
 */
namespace App\Pages\Fmt;

class NetInterfacesFormatter
{
    /**
     * @param array $fmt_data
     * @param array $response
     * @return array
     */
    public static function format(array $fmt_data, array $response): array
    {
        if (isset($response['result'])) {
            $data = $response['result'];
        } else {
            $data = [];
        }

        if (is_array($data)) {
            if (isset($data['interfaces']) && is_array($data['interfaces'])) {
                $interfaces = $data['interfaces'];
            } else {
                $interfaces = $data;
            }
        } else {
            $interfaces = [];
        }

        $physical = [];
        $virtual = [];

        $backend_missing = [];
        foreach ($interfaces as $iface) {
            $row = $iface;

            // Prepare ipv4 rows — for DHCP interfaces use `ipv4_system`, otherwise use resolved sets
            $ipv4_rows = [];
            if (!empty($iface['ip_mode']) && $iface['ip_mode'] === 'dhcp') {
                if (!empty($iface['ipv4_system']) && is_array($iface['ipv4_system'])) {
                    foreach ($iface['ipv4_system'] as $sys) {
                        $ip = $sys['ip'] ?? '';
                        $mask = $sys['netmask'] ?? '';
                        if ($ip !== '') {
                            $tooltip = $mask !== '' ? "{$ip}/{$mask}" : $ip;
                            $ipv4_rows[] = ['label' => $tooltip, 'tooltip' => 'dhcp provided'];
                        }
                    }
                }
            } elseif (!empty($iface['ipv4_resolved']) && is_array($iface['ipv4_resolved'])) {
                foreach ($iface['ipv4_resolved'] as $resolved) {
                    if (!empty($resolved['values']) && is_array($resolved['values'])) {
                        $tooltip = $resolved['values'][0] ?? '';
                        $label = $resolved['name'] ?? '';
                        if ($label === '') {
                            $backend_missing['ipv4_name'] = true;
                        }
                        $ipv4_rows[] = ['label' => $label, 'tooltip' => $tooltip];
                    }
                }
            } else {
                $unmanaged = ($iface['managed'] ?? null) === false;
                if ($unmanaged && !empty($iface['ipv4']) && is_array($iface['ipv4'])) {
                    foreach ($iface['ipv4'] as $sys) {
                        $ip = $sys['ip'] ?? '';
                        $mask = $sys['netmask'] ?? '';
                        if ($ip !== '') {
                            $tooltip = $mask !== '' ? "{$ip}/{$mask}" : $ip;
                            $ipv4_rows[] = ['label' => $tooltip, 'tooltip' => ''];
                        }
                    }
                }
            }

            // Fallback: if no rows were produced but system-level IPs are present,
            // display them (covers cases like link-local addresses that never appear
            // in resolved sets).
            if (empty($ipv4_rows) && !empty($iface['ipv4_system']) && is_array($iface['ipv4_system'])) {
                foreach ($iface['ipv4_system'] as $sys) {
                    $ip = $sys['ip'] ?? '';
                    $mask = $sys['netmask'] ?? '';
                    if ($ip !== '') {
                        $tooltip = $mask !== '' ? "{$ip}/{$mask}" : $ip;
                        $ipv4_rows[] = ['label' => $tooltip, 'tooltip' => 'system'];
                    }
                }
            }

            // Prepare ipv6 rows — for DHCP interfaces use `ipv6_system`, otherwise use resolved sets
            $ipv6_rows = [];
            if (!empty($iface['ip_mode']) && $iface['ip_mode'] === 'dhcp') {
                if (!empty($iface['ipv6_system']) && is_array($iface['ipv6_system'])) {
                    foreach ($iface['ipv6_system'] as $sys) {
                        $ip = $sys['ip'] ?? '';
                        $prefix = $sys['prefix'] ?? '';
                        if ($ip !== '') {
                            $tooltip = $prefix !== '' ? "{$ip}/{$prefix}" : $ip;
                            $ipv6_rows[] = ['label' => $tooltip, 'tooltip' => 'dhcp provided'];
                        }
                    }
                }
            } elseif (!empty($iface['ipv6_resolved']) && is_array($iface['ipv6_resolved'])) {
                foreach ($iface['ipv6_resolved'] as $resolved) {
                    if (!empty($resolved['values']) && is_array($resolved['values'])) {
                        $tooltip = $resolved['values'][0] ?? '';
                        $label = $resolved['name'] ?? '';
                        if ($label === '') {
                            $backend_missing['ipv6_name'] = true;
                        }
                        $ipv6_rows[] = ['label' => $label, 'tooltip' => $tooltip];
                    }
                }
            } else {
                $unmanaged = ($iface['managed'] ?? null) === false;
                if ($unmanaged && !empty($iface['ipv6']) && is_array($iface['ipv6'])) {
                    foreach ($iface['ipv6'] as $sys) {
                        $ip = $sys['ip'] ?? '';
                        $prefix = $sys['prefix'] ?? '';
                        if ($ip !== '') {
                            $tooltip = $prefix !== '' ? "{$ip}/{$prefix}" : $ip;
                            $ipv6_rows[] = ['label' => $tooltip, 'tooltip' => ''];
                        }
                    }
                }
            }

            // Fallback: if no rows were produced but system-level IPs are present,
            // display them (covers link-local IPv6 addresses that never appear in
            // resolved sets).
            if (empty($ipv6_rows) && !empty($iface['ipv6_system']) && is_array($iface['ipv6_system'])) {
                foreach ($iface['ipv6_system'] as $sys) {
                    $ip = $sys['ip'] ?? '';
                    $prefix = $sys['prefix'] ?? '';
                    if ($ip !== '') {
                        $tooltip = $prefix !== '' ? "{$ip}/{$prefix}" : $ip;
                        $ipv6_rows[] = ['label' => $tooltip, 'tooltip' => 'system'];
                    }
                }
            }

            $row['ipv4_rows'] = $ipv4_rows;
            $row['ipv6_rows'] = $ipv6_rows;

            // Normalize warnings
            $row['warning_msg'] = '';
            if (!empty($iface['warnings']) && is_array($iface['warnings'])) {
                $msgs = [];
                foreach ($iface['warnings'] as $w) {
                    if (!empty($w['msg'])) {
                        $msgs[] = $w['msg'];
                    }
                }
                $row['warning_msg'] = implode('&#10;', $msgs);
            }

            // Row class, managed flag, and missing flag
            $row['missing'] = !empty($iface['missing']);
            $managed = !(($iface['managed'] ?? null) === false);
            $row['managed'] = $managed;

            if (!$managed) {
                $row['row_class'] = 'ni-unmanaged';
            } else {
                $row['row_class'] = 'ni-pointer';
            }
            if (!empty($row['missing'])) {
                $row['row_class'] .= ' ni-missing';
            }

            // Hide actions when unmanaged or when id is missing (handlers require id)
            $row['hide_actions'] = !$managed || empty($iface['id']);

            // Oper state -> led class
            $oper = strtolower($iface['operstate'] ?? 'unknown');
            $ledClass = 'led-gray';
            if ($oper === 'up') {
                $ledClass = 'led-green blink4';
            } elseif ($oper === 'down') {
                $ledClass = 'led-red-on';
            } elseif ($oper === 'testing') {
                $ledClass = 'led-blue blink4';
            } elseif ($oper === 'dormant') {
                $ledClass = 'led-orange blink4';
            }
            $row['oper_led_class'] = $ledClass;

            $row['is_loopback'] = strtolower($iface['interface'] ?? '') === 'lo';
            $row['refs_count'] = count($iface['refs'] ?? []);
            // expose canonical identifier for frontend usage (use backend 'id')
            $row['iface_id'] = $iface['id'] ?? '';
            // Expose type/subtype for frontend actions
            $row['iface_type'] = $iface['type'] ?? '';
            $row['iface_subtype'] = $iface['subtype'] ?? '';

            // For virtual interfaces compute association/parent display
            if (($iface['type'] ?? '') === 'virtual') {
                $assoc = '';
                if (!empty($iface['brif']) && is_array($iface['brif'])) {
                    $assoc = implode(', ', $iface['brif']);
                } elseif (!$managed && !empty($iface['ports']) && is_array($iface['ports'])) {
                    $assoc = implode(', ', $iface['ports']);
                } elseif (!empty($iface['bonding']['slaves']) && is_string($iface['bonding']['slaves'])) {
                    $assoc = implode(', ', preg_split('/\s+/', $iface['bonding']['slaves']));
                } elseif (!empty($iface['interface']) && strpos($iface['interface'], '.') !== false) {
                    $assoc = explode('.', $iface['interface'])[0];
                }
                $row['assoc'] = $assoc;
                $virtual[] = $row;
            } else {
                $physical[] = $row;
            }
        }

        $fmt_data['physical_interfaces'] = $physical;
        $fmt_data['virtual_interfaces'] = $virtual;

        if (!empty($backend_missing)) {
            $fmt_data['backend_missing_fields'] = array_keys($backend_missing);
        }

        // Default dropdown options for creating new virtual interfaces
        $fmt_data['virtualInterfaceTypes'] = [
            '' => 'Create Interface...',
            'vlan' => 'VLAN',
            'bridge' => 'Bridge',
            'macvlan' => 'MacVLAN',
            'bond' => 'Bond',
            'pppoe' => 'PPPoE',
            'vti' => 'VTI',
            'gre' => 'GRE',
            'vxlan' => 'VXLAN',
            'vrf' => 'VRF',
            'xfrm' => 'XFRM',
        ];

        return $fmt_data;
    }
}
