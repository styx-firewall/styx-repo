<?php
/**
 * Formatter for net-routes-rules page data.
 * Normalizes gateway response into presentation-ready arrays
 * consumed by the net-routes-rules template.
 *
 * The gateway now returns rules with _display fields already resolved.
 * This formatter passes them through and normalizes minor differences
 * (e.g. family -> category mapping for src/dst).
 *
 * dp: 20260415
 */
namespace App\Pages\Fmt;

class RouteRulesFormatter
{
    /**
     * Format route-rules page data for templates.
     *
     * Expected input $response keys:
     *   - rules => array of route rule objects with _display fields
     *
     * @param array $fmt_data  Current page data (may be empty)
     * @param array $response   Gateway response result from RouteRulesRequestController
     * @return array            Enriched page_data for template
     */
    public static function format(array $fmt_data, array $response): array
    {
        $rules = $response['rules'] ?? [];

        // ── Protocols (static lookup for the form) ───────────────────────────
        $fmt_data['protocols'] = [
            ''       => '— any —',
            'tcp'    => 'TCP',
            'udp'    => 'UDP',
            'icmp'   => 'ICMP',
            'icmpv6' => 'ICMPv6',
        ];

        // ── Normalize rules ──────────────────────────────────────────────────
        $normalized = [];
        foreach ($rules as $rule) {
            if (!is_array($rule)) {
                continue;
            }

            $normalized[] = [
                'uuid'       => $rule['uuid'] ?? $rule['id'] ?? '',
                'name'       => $rule['name'] ?? '',
                'priority'   => $rule['priority'] ?? null,
                'invert'     => !empty($rule['invert']),
                'expression' => $rule['expression'] ?? '',
                'active'     => !empty($rule['active']),

                // Original UUIDs (for operations)
                'mark'       => $rule['mark'] ?? null,
                'src'        => $rule['src'] ?? null,
                'dst'        => $rule['dst'] ?? null,
                'iif'        => $rule['iif'] ?? null,
                'proto'      => $rule['proto'] ?? '',
                'sport'      => $rule['sport'] ?? null,
                'dport'      => $rule['dport'] ?? null,
                'action'     => $rule['action'] ?? 'lookup',
                'table'      => $rule['table'] ?? null,

                // Resolved display fields (passed through from gateway)
                'mark_display'  => self::normalizeDisplayObj($rule['mark_display'] ?? null),
                'src_display'   => self::normalizeDisplayAddr($rule['src_display'] ?? null),
                'dst_display'   => self::normalizeDisplayAddr($rule['dst_display'] ?? null),
                'iif_display'   => self::normalizeDisplayObj($rule['iif_display'] ?? null),
                'sport_display' => self::normalizeDisplayObj($rule['sport_display'] ?? null),
                'dport_display' => self::normalizeDisplayObj($rule['dport_display'] ?? null),
                'table_display' => self::normalizeDisplayObj($rule['table_display'] ?? null),
            ];
        }

        $fmt_data['rules']       = $normalized;
        $fmt_data['rules_count'] = count($normalized);

        return $fmt_data;
    }

    /**
     * Normalize a generic display object (mark, iif, sport, dport, table).
     * Ensures name and value are always present; returns null if input is null.
     */
    private static function normalizeDisplayObj(?array $obj): ?array
    {
        if ($obj === null) {
            return null;
        }
        return [
            'id'    => $obj['id'] ?? '',
            'name'  => $obj['name'] ?? '',
            'value' => $obj['value'] ?? '',
        ];
    }

    /**
     * Normalize an address display object (src, dst).
     * Maps gateway's 'family' field ("ip"|"ip6") to template's 'category' ("ipv4"|"ipv6").
     */
    private static function normalizeDisplayAddr(?array $obj): ?array
    {
        if ($obj === null) {
            return null;
        }
        $family = $obj['family'] ?? '';
        $category = ($family === 'ip6') ? 'ipv6' : 'ipv4';

        return [
            'id'       => $obj['id'] ?? '',
            'name'     => $obj['name'] ?? '',
            'value'    => $obj['value'] ?? '',
            'family'   => $family,
            'category' => $category,
        ];
    }
}

