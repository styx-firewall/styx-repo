<?php
namespace App\Pages\Fmt;

class TsTcRulesFormatter
{
    /**
     * Minimal formatter for TC rules page.
     * Expects $fmt_data['tc_config'] to be an array of interfaces => config.
     * Produces: tc_parents (id => label), tc_qdiscs (kind => label), qdisc_with_classes array.
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $tc_config = $fmt_data['tc_config'] ?? [];

        $qdiscWithClasses = ['htb', 'hfsc', 'prio'];

        // preserve backend keys and display labels in UPPERCASE (no other changes)
        $tc_qdiscs = [];
        foreach ((array)$fmt_data['tc_valid_qdisc'] as $kind) {
            if (!is_string($kind)) continue;
            $tc_qdiscs[$kind] = strtoupper($kind);
        }

        $tc_parents = ['root' => ['root', '']];

        foreach ($tc_config as $iface => $qconf) {
            $iface_label = $qconf['interface_name'] ?? $iface;
            if (!empty($qconf['qdiscs']) && isset($qconf['qdiscs'][0]['kind'])) {
                $qd = $qconf['qdiscs'][0];
                if (in_array($qd['kind'], $qdiscWithClasses, true)) {
                    $handle = $qd['handle'] ?? '';
                    $id = $qd['id'] ?? '';
                    $label = $iface_label . ' - ' . $qd['kind'] . ' - ' . $handle;
                    $tc_parents[$id] = [$label, $iface];
                }
            }
            if (!empty($qconf['classes']) && is_array($qconf['classes'])) {
                foreach ($qconf['classes'] as $ch) {
                    $kind = isset($qconf['qdiscs'][0]['kind']) ? $qconf['qdiscs'][0]['kind'] : '';
                    $className = !empty($ch['name']) ? ' (' . $ch['name'] . ')' : '';
                    $handle = $ch['handle'] ?? '';
                    $id = $ch['id'] ?? '';
                    $label = $iface_label . ' - ' . $kind . ' - ' . $handle . $className;
                    $tc_parents[$id] = [$label, $iface];
                }
            }
        }

        $fmt_data['tc_parents'] = $tc_parents;

        // Build interface select options (only interfaces with at least one qdisc)
        $interfaceOptions = [];
        foreach ($tc_config as $ifaceUuid => $qconf) {
            $ifaceName = $qconf['interface_name'] ?? $ifaceUuid;
            if (!empty($qconf['qdiscs'])) {
                $interfaceOptions[] = ['value' => $ifaceUuid, 'label' => $ifaceName];
            }
        }
        $fmt_data['interface_options'] = $interfaceOptions;

        // Pre-compute human-readable summary for each filter
        foreach ($fmt_data['tc_config'] as $ifaceUuid => &$qconf) {
            if (!empty($qconf['filters']) && is_array($qconf['filters'])) {
                foreach ($qconf['filters'] as &$filter) {
                    self::enrichFilter($filter, $qconf, $tc_qdiscs, $tc_parents);
                }
                unset($filter);
            }
        }
        unset($qconf);

        return $fmt_data;
    }

    /**
     * Pre-compute all display fields for a single filter table row,
     * avoiding business logic in the template.
     *
     * @param array<string,mixed> $filter
     * @param array<string,mixed> $qconf
     * @param array<string,string> $tc_qdiscs
     * @param array<string,array> $tc_parents
     */
    private static function enrichFilter(array &$filter, array $qconf, array $tc_qdiscs, array $tc_parents): void
    {
        $direction = $filter['direction'] ?? '';

        // ── Filter summary (Filter / Extra column)
        $filter['_filter_summary'] = self::filterSummary($filter);

        // ── Qdisc label
        $filterQdisc = $filter['qdisc'] ?? '';
        if ($filterQdisc) {
            $filter['_qdisc_label'] = $tc_qdiscs[$filterQdisc] ?? $filterQdisc;
        } elseif ($direction === 'ingress') {
            $filter['_qdisc_label'] = 'ingress';
        } else {
            $qdiscKind = $qconf['qdiscs'][0]['kind'] ?? '';
            $filter['_qdisc_label'] = $tc_qdiscs[$qdiscKind] ?? ($qdiscKind ?: '-');
        }

        // ── Parent display (only for egress) — resolve UUID to label
        if ($direction === 'egress') {
            $parentId = $filter['parent'] ?? '';
            $filter['_parent_display'] = $tc_parents[$parentId][0] ?? ($parentId ?: '-');
        } else {
            $filter['_parent_display'] = '-';
        }

        // ── Active state
        $isActive = !empty($filter['active']);
        $filter['_is_active'] = $isActive;
        $filter['_toggle_text'] = $isActive ? 'Deactivate' : 'Activate';
        $filter['_toggle_active'] = $isActive ? '0' : '1';
        $filter['_active_badge_class'] = $isActive ? 'std-badge--active' : 'std-badge--inactive';        $filter['_active_badge_text'] = $isActive ? 'Active' : 'Inactive';
    }

    /**
     * Build a human-readable summary of a filter's matching/action fields
     * for display in the "Filter / Extra" table column.
     *
     * @param array<string,mixed> $filter
     * @return string  Summary string, or '-' if no structured fields.
     */
    public static function filterSummary(array $filter): string
    {
        // Custom mode: raw filter string
        if (!empty($filter['filter'])) {
            return $filter['filter'];
        }

        $parts = [];

        // Resolved picker fields (single item or list)
        $pickerFields = [
            'src_ip'   => 'src',
            'dst_ip'   => 'dst',
            'src_port' => 'sport',
            'dst_port' => 'dport',
            'vlan_id'  => 'vlan',
            'connmark' => 'connmark',
            'fwmark'   => 'fwmark',
            'mark'     => 'mark',
        ];
        foreach ($pickerFields as $key => $label) {
            $resolved = $filter[$key . '_resolved'] ?? null;
            if (!$resolved) {
                continue;
            }
            // Single item (assoc keys) vs list of items
            $items = (isset($resolved['name']) || isset($resolved['id']))
                ? [$resolved]
                : $resolved;
            $vals = [];
            foreach ($items as $item) {
                $n = $item['name'] ?? '';
                $v = $item['value'] ?? '';
                if ($n === '' && $v === '') {
                    continue;
                }
                $vals[] = $n ? "$n ($v)" : $v;
            }
            if ($vals) {
                $parts[] = $label . ' ' . implode(', ', $vals);
            }
        }

        // Scalar match fields
        if (!empty($filter['flowid'])) {
            $parts[] = 'flowid ' . $filter['flowid'];
        }
        if (!empty($filter['ip_proto'])) {
            $parts[] = 'proto ' . $filter['ip_proto'];
        }
        if (!empty($filter['tos'])) {
            $parts[] = 'tos ' . $filter['tos'];
        }
        if (!empty($filter['tcp_flags'])) {
            $parts[] = 'tcp-flags ' . $filter['tcp_flags'];
        }
        if (!empty($filter['ct_state'])) {
            $parts[] = 'ct ' . $filter['ct_state'];
        }

        // Action fields
        if (!empty($filter['action'])) {
            $a = 'action ' . $filter['action'];
            if (!empty($filter['rate'])) {
                $a .= ' (' . $filter['rate'] . ')';
            }
            if (!empty($filter['mirror_dev'])) {
                $a .= ' →' . $filter['mirror_dev'];
            }
            $parts[] = $a;
        }

        return $parts ? implode(' · ', $parts) : '-';
    }
}
