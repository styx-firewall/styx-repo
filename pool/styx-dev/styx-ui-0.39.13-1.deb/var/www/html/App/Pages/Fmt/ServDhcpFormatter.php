<?php
namespace App\Pages\Fmt;

use App\Core\AppContext;
use App\Services\DateFormatter;

class ServDhcpFormatter
{
    /**
     * Prepare presentation-ready data for serv-dhcp template.
     * @param array $fmt_data
     * @return array
     */
    public static function format(AppContext $ctx, array $fmt_data): array
    {
        // Ensure dhcp_global_config exists with sensible defaults for the template
        $defaults = [
            'default_lease_time' => '3600',
            'max_lease_time' => '3600',
            'renew_timer' => '900',
            'rebind_timer' => '1800',
            'global_dns_set_id' => null,
            'global_domain_set_id' => null,
            'global_domain_search_set_id' => null,
        ];
        $dhcp_global = $fmt_data['dhcp_global_config'] ?? [];
        $fmt_data['dhcp_global_config'] = array_merge($defaults, $dhcp_global);
        $dhcp_global_cfg = $fmt_data['dhcp_global_config'];

        $leases_raw = $fmt_data['leases']['leases'] ?? [];
        $leases_rows = [];
        foreach ($leases_raw as $lease) {
            if (!is_array($lease) || empty($lease['ip'])) continue;
            $expire = null;
            if (!empty($lease['expire'])) {
                $expire = is_numeric($lease['expire']) ? (int)$lease['expire'] : strtotime($lease['expire']);
            }
            $lease_time = !empty($lease['lease_time']) ? (int)$lease['lease_time'] : null;
            $start = ($expire && $lease_time) ? DateFormatter::fromTimestamp($ctx, $expire - $lease_time) : ($lease['start'] ?? '—');
            $end = $expire ? DateFormatter::fromTimestamp($ctx, $expire) : ($lease['end'] ?? '—');

            $state = $lease['state'] ?? '';
            $state_html = $state ?: '—';
            if ($state === 'active' || $state === 'bound') {
                $state_html = '<span class="dhcp-lease-active">Active</span>';
            } elseif ($state === 'expired') {
                $state_html = '<span class="dhcp-lease-expired">Expired</span>';
            }

            $version = $lease['version'] ?? '';
            $duid = $lease['duid'] ?? '';
            if ($version === 'ipv4') {
                $mac_html = $lease['mac'] ?: '—';
            } elseif ($version === 'ipv6') {
                $mac_html = !empty($duid) ? '<span title="DUID: ' . $duid . '">DUID</span>' : '—';
            } else {
                $mac_html = '—';
            }

            $leases_rows[] = [
                'state_html' => $state_html,
                'ip'         => $lease['ip'] ?? '—',
                'mac_html'   => $mac_html,
                'start'      => $start,
                'end'        => $end,
                'hostname'   => $lease['hostname'] ?? '—',
            ];
        }
        $fmt_data['leases_rows'] = $leases_rows;
        $fmt_data['default_lease_time_val'] = $dhcp_global_cfg['default_lease_time'] ?? '3600';
        $fmt_data['max_lease_time_val']      = $dhcp_global_cfg['max_lease_time'] ?? '3600';
        $fmt_data['renew_timer_val']         = $dhcp_global_cfg['renew_timer'] ?? '900';
        $fmt_data['rebind_timer_val']        = $dhcp_global_cfg['rebind_timer'] ?? '1800';
        $fmt_data['dhcp_timer_min']          = '1';
        $fmt_data['dhcp_timer_max']          = '4294967295';
        $iface_list = $fmt_data['iface_list'] ?? [];

        // Global picker aliases — value and display label from backend
        $v = $dhcp_global_cfg['global_dns_set_id'] ?? '';
        $d = $dhcp_global_cfg['global_dns_set_id_display'] ?? $v;
        $fmt_data['g_dns_val']   = $v;
        $fmt_data['g_dns_label'] = is_array($d) ? ($d['name'] ?? $d['value'] ?? $v) : ($d ?: '— None —');

        $v = $dhcp_global_cfg['global_domain_set_id'] ?? '';
        $d = $dhcp_global_cfg['global_domain_set_id_display'] ?? $v;
        $fmt_data['g_dom_val']   = $v;
        $fmt_data['g_dom_label'] = is_array($d) ? ($d['name'] ?? $d['value'] ?? $v) : ($d ?: '— None —');

        $v = $dhcp_global_cfg['global_domain_search_set_id'] ?? '';
        $d = $dhcp_global_cfg['global_domain_search_set_id_display'] ?? $v;
        $fmt_data['g_ds_val']   = $v;
        $fmt_data['g_ds_label'] = is_array($d) ? ($d['name'] ?? $d['value'] ?? $v) : ($d ?: '— None —');

        $normalized_ifaces = [];
        foreach ($iface_list as $iface) {
            if (!is_array($iface)) {
                $normalized_ifaces[] = [
                    'id' => (string)$iface,
                    'interface' => (string)$iface,
                    'ipv4' => [[]],
                    'ipv6' => [[]],
                    'missing' => true,
                    'first_ipv4' => '',
                    'first_netmask' => '',
                    'first_ipv6' => '',
                    'first_prefix' => '',
                ];
                continue;
            }
            $ifcopy = $iface;
            // Normalize arrays if missing
            $ifcopy['ipv4'] = $ifcopy['ipv4'] ?? [];
            $ifcopy['ipv6'] = $ifcopy['ipv6'] ?? [];

            // Determine first IPv4: check legacy structure, then resolved entries, then system entries
            $first_ipv4 = '';
            $first_netmask = '';
            if (!empty($ifcopy['ipv4']) && isset($ifcopy['ipv4'][0]['ip'])) {
                $first_ipv4 = $ifcopy['ipv4'][0]['ip'];
                $first_netmask = $ifcopy['ipv4'][0]['netmask'] ?? '';
            }
            if (empty($first_ipv4) && !empty($ifcopy['ipv4_resolved']) && !empty($ifcopy['ipv4_resolved'][0]['values'][0])) {
                $v = $ifcopy['ipv4_resolved'][0]['values'][0];
                $parts = explode('/', $v, 2);
                $first_ipv4 = $parts[0] ?? '';
                $first_netmask = $parts[1] ?? $first_netmask;
            }
            if (empty($first_ipv4) && !empty($ifcopy['ipv4_system']) && !empty($ifcopy['ipv4_system'][0]['ip'])) {
                $first_ipv4 = $ifcopy['ipv4_system'][0]['ip'];
                $first_netmask = $ifcopy['ipv4_system'][0]['netmask'] ?? $first_netmask;
            }

            // Determine first IPv6 similarly
            $first_ipv6 = '';
            $first_prefix = '';
            if (!empty($ifcopy['ipv6']) && isset($ifcopy['ipv6'][0]['ip'])) {
                $first_ipv6 = $ifcopy['ipv6'][0]['ip'];
                $first_prefix = $ifcopy['ipv6'][0]['prefix'] ?? '';
            }
            if (empty($first_ipv6) && !empty($ifcopy['ipv6_resolved']) && !empty($ifcopy['ipv6_resolved'][0]['values'][0])) {
                $v6 = $ifcopy['ipv6_resolved'][0]['values'][0];
                $parts6 = explode('/', $v6, 2);
                $first_ipv6 = $parts6[0] ?? '';
                $first_prefix = $parts6[1] ?? $first_prefix;
            }
            if (empty($first_ipv6) && !empty($ifcopy['ipv6_system']) && !empty($ifcopy['ipv6_system'][0]['ip'])) {
                $first_ipv6 = $ifcopy['ipv6_system'][0]['ip'];
                $first_prefix = $ifcopy['ipv6_system'][0]['prefix'] ?? $first_prefix;
            }

            $ifcopy['first_ipv4'] = $first_ipv4;
            $ifcopy['first_netmask'] = $first_netmask;
            $ifcopy['first_ipv6'] = $first_ipv6;
            $ifcopy['first_prefix'] = $first_prefix;
            $ifcopy['missing'] = empty($first_ipv4) && empty($first_ipv6);
            // Ensure id and interface keys exist
            if (!isset($ifcopy['id'])) {
                $ifcopy['id'] = $ifcopy['interface'] ?? '';
            }
            if (!isset($ifcopy['interface'])) {
                $ifcopy['interface'] = (string)$ifcopy['id'];
            }
            $normalized_ifaces[] = $ifcopy;
        }
        $fmt_data['iface_list'] = $normalized_ifaces;

        // Features and JS-ready config
        $features = $fmt_data['features'] ?? [];
        $fmt_data['is_kea'] = (!empty($features['kea_dhcp4']) || !empty($features['kea_dhcp6']));
        $fmt_data['dhcpv4_enabled'] = !empty($features['dhcp_server_ipv4']);
        $fmt_data['dhcpv6_enabled'] = !empty($features['dhcp_server_ipv6']);
        $dhcp_config = $fmt_data['dhcp_config'] ?? [];

        // Normalize dhcp_config per interface so templates can rely on config/reservations keys
        $normalized_dhcp_config = [];
        foreach ($fmt_data['iface_list'] as $iface) {
            $id = $iface['id'] ?? '';
            $entry = $dhcp_config[$id] ?? [];
            $config = $entry['config'] ?? [];
            // Derive UI enable flags from presence of range set IDs
            $config['dhcpv4_enabled'] = !empty($config['range_set_id']) ? 1 : 0;
            $config['dhcpv6_enabled'] = !empty($config['range6_set_id']) ? 1 : 0;
            // Merge _display fields from entry level into config so JS can access them via entry.config
            foreach ($entry as $key => $val) {
                if (str_ends_with($key, '_display')) {
                    $config[$key] = $val;
                }
            }
            $normalized_dhcp_config[$id] = [
                'config' => $config,
                'reservations' => $entry['reservations'] ?? [],
                'reservations6' => $entry['reservations6'] ?? [],
            ];
        }
        $fmt_data['dhcp_config'] = $normalized_dhcp_config;

        // Expose the normalized dhcp_config (including any *_display fields) to JS
        $fmt_data['dhcp_config_json'] = json_encode(
            $normalized_dhcp_config,
            JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
        );
        return $fmt_data;
    }


}
