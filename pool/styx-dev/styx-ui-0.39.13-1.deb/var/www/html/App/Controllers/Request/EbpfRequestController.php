<?php
/**
 * Controller for eBPF read operations.
 *
 * Sends commands to the gateway using the ebpf.<command> protocol.
 * Each loaded module has a UUID (instance_id) — operations reference it.
 */
namespace App\Controllers\Request;

use App\Controllers\BaseController;

class EbpfRequestController extends BaseController
{
    /** Return error response, preserving the actual message */
    private function fallback(string $msg): array
    {
        $this->logService->warning('eBPF request failed: ' . $msg);
        return ['status' => 'error', 'response_msg' => $msg, 'result' => []];
    }

    // ─── ebpf.module-list ──────────────────────────────────────────────

    /**
     * List all eBPF modules (Styx-managed + foreign + conflicts).
     */
    public function getModuleList(): array
    {
        $commands = [
            ['method' => 'ebpf.module-list', 'id' => 'module_list', 'data' => []],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['response_msg'] ?? 'module-list failed');
        }
        $cmd = $resp['commands']['module_list'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('module-list: ' . ($cmd['response_msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }

    // ─── ebpf.module-info ──────────────────────────────────────────────

    /**
     * Get full descriptor for a module (by UUID or name).
     */
    public function getModuleInfo(string $module): array
    {
        $commands = [
            ['method' => 'ebpf.module-info', 'id' => 'module_info', 'data' => ['module' => $module]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['response_msg'] ?? 'module-info failed');
        }
        $cmd = $resp['commands']['module_info'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('module-info: ' . ($cmd['response_msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }

    // ─── ebpf.telemetry-get ────────────────────────────────────────────

    /**
     * Get current telemetry values for a module.
     */
    public function getTelemetry(string $module): array
    {
        $commands = [
            ['method' => 'ebpf.telemetry-get', 'id' => 'telemetry', 'data' => ['module' => $module]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['response_msg'] ?? 'telemetry-get failed');
        }
        $cmd = $resp['commands']['telemetry'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('telemetry-get: ' . ($cmd['response_msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }

    // ─── ebpf.map-get ──────────────────────────────────────────────────

    /**
     * Read current content of a control map from the kernel.
     */
    public function getControlMap(string $module, string $map): array
    {
        $commands = [
            ['method' => 'ebpf.map-get', 'id' => 'map_get', 'data' => ['module' => $module, 'map' => $map]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['response_msg'] ?? 'map-get failed');
        }
        $cmd = $resp['commands']['map_get'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('map-get: ' . ($cmd['response_msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }

    // ─── ebpf.autoload-get ─────────────────────────────────────────────

    /**
     * Get the list of UUIDs configured for autoload.
     */
    public function getAutoload(): array
    {
        $commands = [
            ['method' => 'ebpf.autoload-get', 'id' => 'autoload', 'data' => []],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['response_msg'] ?? 'autoload-get failed');
        }
        $cmd = $resp['commands']['autoload'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('autoload-get: ' . ($cmd['response_msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }

    // ─── ebpf.map-source (get) ────────────────────────────────────────

    /**
     * Get the data source config for a control map.
     */
    public function getMapSource(string $module, string $map): array
    {
        $commands = [
            ['method' => 'ebpf.map-source', 'id' => 'map_source', 'data' => ['module' => $module, 'map' => $map]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['response_msg'] ?? 'map-source failed');
        }
        $cmd = $resp['commands']['map_source'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('map-source: ' . ($cmd['response_msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }
}
