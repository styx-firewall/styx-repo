<?php
/**
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 */
namespace App\Controllers\Request;

use App\Controllers\BaseController;
use App\Core\AppContext;

class RoutingRequestController extends BaseController
{
    public function __construct(AppContext $ctx)
    {
        parent::__construct($ctx);
    }

    /**
     * Routing overview: daemon status + route protocol summary.
     * @return array<string, mixed>
     */
    public function getOverviewData(): array
    {
        $cmd = [
            'method' => 'routing-overview.get_overview',
            'id'     => 'get_overview',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        return ['status' => 'success', 'result' => $resp['commands']['get_overview']['result'] ?? []];
    }


    /**
     * Get data for routing page (routes, tables, interfaces, addresses).
     * @return array<string, mixed>
     */
    public function getRoutingPageData()
    {
        $commands[] = [
            'method' => 'network-config.get_interfaces_names_ds',
            'id' => 'ifaces_names',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'routing-service.get_routes',
            'id' => 'get_routes',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'routing-service.get_tables',
            'id' => 'get_tables',
            'data' => (object)[],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmds = $resp['commands'];
        $ifaces_names = [];
        $routes_ipv4 = [];
        $routes_ipv6 = [];
        $routing_protocols = [];
        $routing_scopes = [];
        $routing_types = [];

        $ifacesCmd = $cmds['ifaces_names'] ?? null;
        if ($ifacesCmd && ($ifacesCmd['status'] ?? null) === 'success') {
            $res = $ifacesCmd['result'] ?? [];
            if (!empty($res['ifaces_names_ds']) && is_array($res['ifaces_names_ds'])) {
                $ifaces_names = $res['ifaces_names_ds'];
            }
        }

        $routesCmd = $cmds['get_routes'] ?? null;
        if ($routesCmd && ($routesCmd['status'] ?? null) === 'success') {
                if (!empty($routesCmd['result']['ipv4'])) {
                foreach ($routesCmd['result']['ipv4'] as &$route) {
                    if (empty($route['table'])) {
                        $route['table'] = 'main';
                    }
                    if (empty($route['protocol'])) {
                        $route['protocol'] = 'kernel';
                    }
                    if (!in_array($route['protocol'], $routing_protocols)) {
                        $routing_protocols[] = $route['protocol'];
                    }
                    if (empty($route['scope'])) {
                        $route['scope'] = 'global';
                    }
                    if (!in_array($route['scope'], $routing_scopes)) {
                        $routing_scopes[] = $route['scope'];
                    }
                    if (empty($route['type'])) {
                        $route['type'] = 'unicast';
                    }
                    if (!in_array($route['type'], $routing_types)) {
                        $routing_types[] = $route['type'];
                    }
                    // Normalize destination key and metric
                    $route['dst'] = $route['dst'] ?? $route['destination'] ?? '';
                    $route['metric'] = is_numeric($route['metric'] ?? null) ? (int)$route['metric'] : 0;
                }
                unset($route);
                $routes_ipv4 = $routesCmd['result']['ipv4'];
            }
            if (!empty($routesCmd['result']['ipv6'])) {
                foreach ($routesCmd['result']['ipv6'] as &$route) {
                    if (empty($route['table'])) {
                        $route['table'] = 'main';
                    }
                    if (empty($route['protocol'])) {
                        $route['protocol'] = 'kernel';
                    }
                    if (!in_array($route['protocol'], $routing_protocols)) {
                        $routing_protocols[] = $route['protocol'];
                    }
                    if (empty($route['scope'])) {
                        $route['scope'] = 'global';
                    }
                    if (!in_array($route['scope'], $routing_scopes)) {
                        $routing_scopes[] = $route['scope'];
                    }
                    if (empty($route['type'])) {
                        $route['type'] = 'unicast';
                    }
                    if (!in_array($route['type'], $routing_types)) {
                        $routing_types[] = $route['type'];
                    }
                    // Normalize destination key and metric
                    $route['dst'] = $route['dst'] ?? $route['destination'] ?? '';
                    $route['metric'] = is_numeric($route['metric'] ?? null) ? (int)$route['metric'] : 0;
                }
                unset($route);
                $routes_ipv6 = $routesCmd['result']['ipv6'];
            }
        }

        $routing_tables = [];
        $tablesCmd = $cmds['get_tables'] ?? null;
        if ($tablesCmd && ($tablesCmd['status'] ?? null) === 'success') {
            if (empty($tablesCmd['result']['routing_tables']) || !is_array($tablesCmd['result']['routing_tables'])) {
                return $this->baseError('routing-service.get_tables returned unexpected format ' . json_encode($tablesCmd));
            }

            $routing_tables = $tablesCmd['result']['routing_tables'];

            // Normalize fields so templates can rely on `table_id` and `table_name`.
            foreach ($routing_tables as &$table) {
                // Prefer explicit `name` field from new API, then `table_name`, then fallback to empty string.
                $table['table_name'] = $table['name'] ?? $table['table_name'] ?? ($table['table_id'] ?? '');
                if (empty($table['table_id']) && !empty($table['table_name'])) {
                    $table['table_id'] = $table['table_name'];
                }
            }
            unset($table);
        }

        return [
            'status'   => $resp['status'],
            'result'   => [
                'ifaces_names'          => $ifaces_names,
                'routes_ipv4'           => $routes_ipv4,
                'routes_ipv6'           => $routes_ipv6,
                'routing_tables'        => $routing_tables,
                'routing_protocols'     => $routing_protocols,
                'routing_scopes'        => $routing_scopes,
                'routing_types'         => $routing_types,
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * BGP configuration, neighbor list + datastore interfaces.
     * @return array<string, mixed>
     */
    public function getBgpData(): array
    {
        $commands = [
            [
                'method' => 'frr-service.get_bgp',
                'id'     => 'get_bgp',
                'data'   => (object)[],
            ],
            [
                'method' => 'network-config.get_interfaces_names_ds',
                'id'     => 'ifaces_names',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmds   = $resp['commands'];
        $result = $cmds['get_bgp']['result'] ?? [];

        $ifacesCmd = $cmds['ifaces_names'] ?? null;
        if ($ifacesCmd && ($ifacesCmd['status'] ?? null) === 'success') {
            $res = $ifacesCmd['result'] ?? [];
            $result['ifaces_names'] = $res['ifaces_names_ds'] ?? [];
        } else {
            $result['ifaces_names'] = [];
        }

        return ['status' => 'success', 'result' => $result];
    }

    /**
     * BGP page data: config + route maps + peer groups + BFD profiles in a single batched request.
     * @return array<string, mixed>
     */
    public function getBgpPageData(): array
    {
        $cmds = [
            ['method' => 'frr-service.get_bgp',                 'id' => 'get_bgp',           'data' => (object)[]],
            ['method' => 'network-config.get_interfaces_names_ds', 'id' => 'ifaces_names',   'data' => (object)[]],
            ['method' => 'frr-service.get_route_maps',          'id' => 'get_route_maps',    'data' => (object)[]],
            ['method' => 'frr-service.get_bgp_peer_groups',     'id' => 'get_peer_groups',   'data' => (object)[]],
            ['method' => 'frr-service.get_bfd_profiles',        'id' => 'get_bfd_profiles',  'data' => (object)[]],
        ];
        $resp = $this->processGwResp($this->sendCommands($cmds));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmds = $resp['commands'];

        $bgpResult = $cmds['get_bgp']['result'] ?? [];
        $bgpConfig = $bgpResult['bgp_config'] ?? [];
        $neighbors = $bgpResult['neighbors'] ?? [];
        $networks  = $bgpResult['networks'] ?? [];

        $ifacesCmd = $cmds['ifaces_names'] ?? null;
        if ($ifacesCmd && ($ifacesCmd['status'] ?? null) === 'success') {
            $ifacesRes = $ifacesCmd['result'] ?? [];
            $bgpIfaces = $ifacesRes['ifaces_names_ds'] ?? [];
        } else {
            $bgpIfaces = [];
        }

        $rmResult    = $cmds['get_route_maps']['result'] ?? [];
        $routeMaps   = $rmResult['route_maps'] ?? [];

        $pgResult    = $cmds['get_peer_groups']['result'] ?? [];
        $peerGroups  = $pgResult['peer_groups'] ?? [];

        $bfpResult   = $cmds['get_bfd_profiles']['result'] ?? [];
        $bfdProfiles = $bfpResult['bfd_profiles'] ?? [];

        return [
            'status' => 'success',
            'result' => [
                'bgp_config'    => $bgpConfig,
                'neighbors'     => $neighbors,
                'networks'      => $networks,
                'bgp_ifaces'    => $bgpIfaces,
                'route_maps'    => $routeMaps,
                'peer_groups'   => $peerGroups,
                'bfd_profiles'  => $bfdProfiles,
            ],
        ];
    }

    /**
     * OSPF configuration, areas, interface overrides, neighbor list + datastore interfaces.
     * @return array<string, mixed>
     */
    public function getOspfData(): array
    {
        $commands = [
            [
                'method' => 'frr-service.get_ospf',
                'id'     => 'get_ospf',
                'data'   => (object)[],
            ],
            [
                'method' => 'network-config.get_interfaces_names_ds',
                'id'     => 'ifaces_names',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmds   = $resp['commands'];
        $result = $cmds['get_ospf']['result'] ?? [];

        $ifacesCmd = $cmds['ifaces_names'] ?? null;
        if ($ifacesCmd && ($ifacesCmd['status'] ?? null) === 'success') {
            $res = $ifacesCmd['result'] ?? [];
            $result['ifaces_names'] = $res['ifaces_names_ds'] ?? [];
        } else {
            $result['ifaces_names'] = [];
        }

        return ['status' => 'success', 'result' => $result];
    }

    /**
     * RIP configuration, networks and neighbor list.
     * @return array<string, mixed>
     */
    public function getRipData(): array
    {
        $cmd = [
            'method' => 'frr-service.get_rip',
            'id'     => 'get_rip',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        return ['status' => 'success', 'result' => $resp['commands']['get_rip']['result'] ?? []];
    }

    /**
     * RIP page data with auxiliary lookups for pickers.
     *
     * Fetches RIP config/networks/neighbors plus BFD profiles, prefix lists,
     * route maps, and interface names so the UI can populate select pickers.
     *
     * @return array<string, mixed>
     */
    public function getRipPageData(): array
    {
        $cmds = [
            ['method' => 'frr-service.get_rip',                   'id' => 'get_rip',            'data' => (object)[]],
            ['method' => 'network-config.get_interfaces_names_ds', 'id' => 'ifaces_names',     'data' => (object)[]],
            ['method' => 'frr-service.get_bfd_profiles',          'id' => 'get_bfd_profiles',  'data' => (object)[]],
            ['method' => 'frr-service.get_prefix_lists',          'id' => 'get_prefix_lists',  'data' => (object)[]],
            ['method' => 'frr-service.get_route_maps',            'id' => 'get_route_maps',    'data' => (object)[]],
        ];
        $resp = $this->processGwResp($this->sendCommands($cmds));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmds = $resp['commands'];

        $ripResult = $cmds['get_rip']['result'] ?? [];
        $ripConfig = $ripResult['rip_config'] ?? [];
        $networks  = $ripResult['networks'] ?? [];
        $neighbors = $ripResult['neighbors'] ?? [];

        $ifacesCmd = $cmds['ifaces_names'] ?? null;
        if ($ifacesCmd && ($ifacesCmd['status'] ?? null) === 'success') {
            $ifacesRes = $ifacesCmd['result'] ?? [];
            $ripIfaces = $ifacesRes['ifaces_names_ds'] ?? [];
        } else {
            $ripIfaces = [];
        }

        $bfpResult   = $cmds['get_bfd_profiles']['result'] ?? [];
        $bfdProfiles = $bfpResult['bfd_profiles'] ?? [];

        $plResult    = $cmds['get_prefix_lists']['result'] ?? [];
        $prefixLists = $plResult['prefix_lists'] ?? [];

        $rmResult    = $cmds['get_route_maps']['result'] ?? [];
        $routeMaps   = $rmResult['route_maps'] ?? [];

        return [
            'status' => 'success',
            'result' => [
                'rip_config'    => $ripConfig,
                'networks'      => $networks,
                'neighbors'     => $neighbors,
                'rip_ifaces'    => $ripIfaces,
                'bfd_profiles'  => $bfdProfiles,
                'prefix_lists'  => $prefixLists,
                'route_maps'    => $routeMaps,
            ],
        ];
    }

    /**
     * BFD session list.
     * @return array<string, mixed>
     */
    public function getBfdData(): array
    {
        $cmd = [
            'method' => 'frr-service.get_bfd',
            'id'     => 'get_bfd',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        return ['status' => 'success', 'result' => $resp['commands']['get_bfd']['result'] ?? []];
    }

    /**
     * BFD profiles list.
     * @return array<string, mixed>
     */
    public function getBfdProfiles(): array
    {
        $cmd = [
            'method' => 'frr-service.get_bfd_profiles',
            'id'     => 'get_bfd_profiles',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $result = $resp['commands']['get_bfd_profiles']['result'] ?? [];
        return ['status' => 'success', 'result' => $result['bfd_profiles'] ?? []];
    }

    /**
     * BFD page data: sessions + profiles in a single batched request.
     * @return array<string, mixed>
     */
    public function getBfdPageData(): array
    {
        $cmds = [
            ['method' => 'frr-service.get_bfd',          'id' => 'get_bfd',          'data' => (object)[]],
            ['method' => 'frr-service.get_bfd_profiles', 'id' => 'get_bfd_profiles', 'data' => (object)[]],
        ];
        $resp = $this->processGwResp($this->sendCommands($cmds));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $sessionsRaw = $resp['commands']['get_bfd']['result'] ?? [];
        $profilesRaw = $resp['commands']['get_bfd_profiles']['result'] ?? [];
        $sessions = $sessionsRaw['sessions'] ?? [];
        $profiles = $profilesRaw['bfd_profiles'] ?? [];

        return [
            'status' => 'success',
            'result' => [
                'sessions' => $sessions,
                'bfd_profiles' => $profiles,
            ],
        ];
    }

    /**
     * IGMP Proxy configuration and interface assignments.
     * @return array<string, mixed>
     */
    public function getIgmpProxyData(): array
    {
        $commands = [
            [
                'method' => 'igmp-service.get_igmp_proxy',
                'id'     => 'get_igmp_proxy',
                'data'   => (object)[],
            ],
            [
                'method' => 'network-config.get_interfaces_names_ds',
                'id'     => 'ifaces_names',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmds = $resp['commands'];
        $result = $cmds['get_igmp_proxy']['result'] ?? [];

        $ifacesCmd = $cmds['ifaces_names'] ?? null;
        if ($ifacesCmd && ($ifacesCmd['status'] ?? null) === 'success') {
            $res = $ifacesCmd['result'] ?? [];
            $result['ifaces_names'] = $res['ifaces_names_ds'] ?? [];
        } else {
            $result['ifaces_names'] = [];
        }

        return ['status' => 'success', 'result' => $result];
    }

    /**
     * FRR Global profile (traditional / datacenter).
     * @return array<string, mixed>
     */
    public function getFrrGlobal(): array
    {
        $cmds = [
            ['method' => 'frr-service.get_frr_global',        'id' => 'get_frr_global',   'data' => (object)[]],
            ['method' => 'routing-overview.get_frr_overview', 'id' => 'get_frr_overview', 'data' => (object)[]],
        ];
        $resp = $this->processGwResp($this->sendCommands($cmds));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $global   = $resp['commands']['get_frr_global']['result'] ?? [];
        $overview = $resp['commands']['get_frr_overview']['result'] ?? [];

        return [
            'status' => $resp['status'],
            'result' => [
                'profile'      => $global['profile'] ?? null,
                'max_fds'      => $global['max_fds'] ?? null,
                'frr_no_root'  => $global['frr_no_root'] ?? null,
                'vtysh_enable' => $global['vtysh_enable'] ?? null,
                'overview'     => $overview,
            ],
        ];
    }

    // ── FRR Policies ─────────────────────────────────────────────────────────

    /**
     * FRR policies page data: prefix lists + route maps + AS path lists + community lists
     * in a single batched request.
     * @return array<string, mixed>
     */
    public function getPoliciesPageData(): array
    {
        $cmds = [
            ['method' => 'frr-service.get_prefix_lists',         'id' => 'get_prefix_lists',     'data' => (object)[]],
            ['method' => 'frr-service.get_route_maps',           'id' => 'get_route_maps',       'data' => (object)[]],
            ['method' => 'frr-service.get_bgp_as_path_lists',    'id' => 'get_as_path_lists',    'data' => (object)[]],
            ['method' => 'frr-service.get_bgp_community_lists',  'id' => 'get_community_lists',  'data' => (object)[]],
        ];
        $resp = $this->processGwResp($this->sendCommands($cmds));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmds = $resp['commands'];

        $plResult  = $cmds['get_prefix_lists']['result'] ?? [];
        $rmResult  = $cmds['get_route_maps']['result'] ?? [];
        $asResult  = $cmds['get_as_path_lists']['result'] ?? [];
        $clResult  = $cmds['get_community_lists']['result'] ?? [];

        return [
            'status' => $resp['status'],
            'result' => [
                'prefix_lists'    => $plResult['prefix_lists'] ?? [],
                'route_maps'      => $rmResult['route_maps'] ?? [],
                'as_path_lists'   => $asResult['bgp_as_path_lists'] ?? [],
                'community_lists' => $clResult['bgp_community_lists'] ?? [],
            ],
        ];
    }

    /**
     * Prefix lists with resolved display fields.
     * @return array<string, mixed>
     */
    public function getPrefixLists(): array
    {
        $cmd = [
            'method' => 'frr-service.get_prefix_lists',
            'id'     => 'get_prefix_lists',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $result = $resp['commands']['get_prefix_lists']['result'] ?? [];
        return ['status' => 'success', 'result' => $result['prefix_lists'] ?? []];
    }

    /**
     * Route maps with resolved display fields.
     * @return array<string, mixed>
     */
    public function getRouteMaps(): array
    {
        $cmd = [
            'method' => 'frr-service.get_route_maps',
            'id'     => 'get_route_maps',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $result = $resp['commands']['get_route_maps']['result'] ?? [];
        return ['status' => 'success', 'result' => $result['route_maps'] ?? []];
    }

    /**
     * BGP AS path lists with resolved display fields.
     * @return array<string, mixed>
     */
    public function getAsPathLists(): array
    {
        $cmd = [
            'method' => 'frr-service.get_bgp_as_path_lists',
            'id'     => 'get_as_path_lists',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $result = $resp['commands']['get_as_path_lists']['result'] ?? [];
        return ['status' => 'success', 'result' => $result['bgp_as_path_lists'] ?? []];
    }

    /**
     * BGP community lists with resolved display fields.
     * @return array<string, mixed>
     */
    public function getCommunityLists(): array
    {
        $cmd = [
            'method' => 'frr-service.get_bgp_community_lists',
            'id'     => 'get_community_lists',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $result = $resp['commands']['get_community_lists']['result'] ?? [];
        return ['status' => 'success', 'result' => $result['bgp_community_lists'] ?? []];
    }

    /**
     * BGP peer groups.
     * @return array<string, mixed>
     */
    public function getPeerGroups(): array
    {
        $cmd = [
            'method' => 'frr-service.get_bgp_peer_groups',
            'id'     => 'get_peer_groups',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $result = $resp['commands']['get_peer_groups']['result'] ?? [];
        return ['status' => 'success', 'result' => $result['peer_groups'] ?? []];
    }

    /**
     * FRR static routes (config + routes list) + available datastore interfaces.
     * @return array<string, mixed>
     */
    public function getFrrStatic(): array
    {
        $commands = [
            [
                'method' => 'frr-service.get_frr_static',
                'id'     => 'get_frr_static',
                'data'   => (object)[],
            ],
            [
                'method' => 'network-config.get_interfaces_names_ds',
                'id'     => 'ifaces_names',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmds   = $resp['commands'];
        $result = $cmds['get_frr_static']['result'] ?? [];

        $ifacesCmd = $cmds['ifaces_names'] ?? null;
        if ($ifacesCmd && ($ifacesCmd['status'] ?? null) === 'success') {
            $res = $ifacesCmd['result'] ?? [];
            $result['ifaces_names'] = $res['ifaces_names_ds'] ?? [];
        } else {
            $result['ifaces_names'] = [];
        }

        return ['status' => 'success', 'result' => $result];
    }

    /**
     * VRRP config + instances + available datastore interfaces.
     * @return array<string, mixed>
     */
    public function getVrrp(): array
    {
        $commands = [
            [
                'method' => 'frr-service.get_vrrp',
                'id'     => 'get_vrrp',
                'data'   => (object)[],
            ],
            [
                'method' => 'network-config.get_interfaces_names_ds',
                'id'     => 'ifaces_names',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmds   = $resp['commands'];
        $result = $cmds['get_vrrp']['result'] ?? [];

        $ifacesCmd = $cmds['ifaces_names'] ?? null;
        if ($ifacesCmd && ($ifacesCmd['status'] ?? null) === 'success') {
            $res = $ifacesCmd['result'] ?? [];
            $result['ifaces_names'] = $res['ifaces_names_ds'] ?? [];
        } else {
            $result['ifaces_names'] = [];
        }

        return ['status' => 'success', 'result' => $result];
    }

    /**
     * OSPFv3 configuration, areas, interface overrides and neighbor list.
     * @return array<string, mixed>
     */
    public function getOspf6Data(): array
    {
        $cmd = [
            'method' => 'frr-service.get_ospf6',
            'id'     => 'get_ospf6',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        return ['status' => 'success', 'result' => $resp['commands']['get_ospf6']['result'] ?? []];
    }

    /**
     * Zebra configuration.
     * @return array<string, mixed>
     */
    public function getZebra(): array
    {
        $cmds = [
            ['method' => 'frr-service.get_zebra',       'id' => 'get_zebra',       'data' => (object)[]],
            ['method' => 'frr-service.get_route_maps',  'id' => 'get_route_maps',  'data' => (object)[]],
        ];
        $resp = $this->processGwResp($this->sendCommands($cmds));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $result = $resp['commands']['get_zebra']['result'] ?? [];
        $result['route_maps'] = $resp['commands']['get_route_maps']['result']['route_maps'] ?? [];

        return ['status' => 'success', 'result' => $result];
    }

    /**
     * EVPN configuration + VRF bindings.
     * @return array<string, mixed>
     */
    public function getEvpn(): array
    {
        $cmd = [
            'method' => 'frr-service.get_evpn',
            'id'     => 'get_evpn',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        return ['status' => 'success', 'result' => $resp['commands']['get_evpn']['result'] ?? []];
    }

    /**
     * EVPN page data: config + VRF bindings + available VRF interfaces in a single batched request.
     * @return array<string, mixed>
     */
    public function getEvpnPageData(): array
    {
        $cmds = [
            ['method' => 'frr-service.get_evpn',                    'id' => 'get_evpn',       'data' => (object)[]],
            ['method' => 'network-config.get_interfaces_names_ds',  'id' => 'ifaces_names',   'data' => (object)[]],
        ];
        $resp = $this->processGwResp($this->sendCommands($cmds));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmds = $resp['commands'];

        $evpnResult = $cmds['get_evpn']['result'] ?? [];
        $enabled    = $evpnResult['enabled'] ?? false;
        $allVni     = $evpnResult['advertise_all_vni'] ?? false;
        $sviIp      = $evpnResult['advertise_svi_ip'] ?? false;
        $bindings   = $evpnResult['vrf_bindings'] ?? [];

        $ifacesCmd = $cmds['ifaces_names'] ?? null;
        $allIfaces = [];
        if ($ifacesCmd && ($ifacesCmd['status'] ?? null) === 'success') {
            $allIfaces = $ifacesCmd['result']['ifaces_names_ds'] ?? [];
        }

        return [
            'status' => 'success',
            'result' => [
                'evpn_config'  => [
                    'enabled'           => $enabled,
                    'advertise_all_vni' => $allVni,
                    'advertise_svi_ip'  => $sviIp,
                ],
                'vrf_bindings' => $bindings,
                'vrf_ifaces'   => $allIfaces,
            ],
        ];
    }
}
