<?php

namespace App\Services;

/**
 * Manages per-user UI profile settings (timezone, debug).
 *
 * Profiles are loaded into the session at login time and read from
 * $_SESSION on every page view — no per-request I/O.
 *
 * Writes are delegated to the backend via Gateway (SubmitRegistry).
 * After a successful Gateway write, the caller must update the session
 * cache via storeProfileInSession() so the change is visible immediately.
 *
 * Session structure:
 *   $_SESSION['profile'] = ['timezone' => '...', 'debug' => true|false]
 */
class UserProfileService
{
    private static function validateUsername(string $username): void
    {
        if (!preg_match('/^[a-zA-Z0-9._-]{1,64}$/', $username)) {
            throw new \InvalidArgumentException("Invalid username for profile lookup: $username");
        }
    }

    /**
     * Returns the profile for the given user from the session cache.
     * Returns an empty array if no profile is stored in session.
     *
     * @return array{timezone?: string, debug?: bool}
     */
    public static function readProfile(string $username): array
    {
        self::validateUsername($username);

        $profile = $_SESSION['profile'] ?? [];
        if (!is_array($profile)) {
            return [];
        }

        return $profile;
    }

    /**
     * Stores a profile array in the session so subsequent readProfile()
     * calls are instant (no I/O, no Gateway round-trip).
     *
     * @param array{timezone?: string, debug?: bool} $profile
     */
    public static function storeProfileInSession(string $username, array $profile): void
    {
        self::validateUsername($username);
        $_SESSION['profile'] = $profile;
    }
}
