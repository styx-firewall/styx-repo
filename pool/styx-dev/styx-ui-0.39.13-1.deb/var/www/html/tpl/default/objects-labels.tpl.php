<?php
/**
 * Object Labels management page — shell template.
 * The reusable form + table fragment is injected via $tdata['labels_content'].
 */
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Object Labels</h1>
        <div class="content-box">
            <p>Manage lightweight labels that can be applied to multiple object types (VLANs, packet marking).</p>
            <?= $tdata['labels_content'] ?? '' ?>
        </div>
    </main>
</div>

