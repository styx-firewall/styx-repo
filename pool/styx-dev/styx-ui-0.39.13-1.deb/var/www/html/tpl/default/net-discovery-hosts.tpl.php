<?php
/**
 * Fragment: Network Discovery Hosts tab.
 * Loaded via load_tpl into the disc-hosts panel.
 * Expects $tdata['tpl_data']['hosts_tab'] with segments and unassigned.
 *
 * @var array<mixed> $tdata
 */

$hosts_tab = $tdata['tpl_data']['hosts_tab'] ?? [];
?>
<?php /** @param array<mixed> $h */ ?>
<?php $renderHostRow = function (array $h): void { ?>
<tr class="disc-host-row" data-ip="<?= $h['ip'] ?>">
    <td class="disc-ip-cell">
        <span class="disc-status-dot <?= $h['seen_class'] ?>"
              title="<?= $h['seen_title'] ?>"></span>
        <?= $h['ip'] ?>
    </td>
    <td class="disc-hostname"<?= $h['mdns_title'] ?? '' ?>><?= $h['hostname_html'] ?? '—' ?></td>
    <td class="disc-mac"><?= $h['mac_display'] ?></td>
    <td class="disc-vendor"><?= $h['vendor_display'] ?></td>
    <td class="disc-os"><?= $h['os_display'] ?></td>
    <td class="disc-source"><?= $h['source_label'] ?></td>
    <td><?= $h['iface'] ?></td>
    <td><?= $h['l2_confirmed_html'] ?></td>
    <td class="disc-roles"><?= !empty($h['roles_html']) ? $h['roles_html'] : '—' ?></td>
    <td class="disc-date"><?= $h['last_seen_display'] ?? '—' ?></td>
</tr>
<?php }; ?>

<div class="disc-hosts-toolbar">
    <input type="text" class="std-input disc-filter-input"
           id="disc-host-filter"
           placeholder="Filter by IP, hostname, vendor, MAC..." />
</div>

<?php foreach ($hosts_tab['segments'] ?? [] as $seg): ?>
<?php $segHosts = $seg['hosts'] ?? []; ?>
<div class="content-box disc-section">
    <details class="disc-segment">
    <summary class="disc-segment-summary">
        <span class="disc-node-icon disc-icon-local"></span>
        <?= $seg['cidr'] ?>
        <span class="disc-wan-count">(<?= count($segHosts) ?>)</span>
        <?php if ($seg['iface']): ?>
            <span class="disc-tree-hostname"><?= $seg['iface'] ?></span>
        <?php endif ?>
    </summary>
    <?php if (!empty($segHosts)): ?>
    <table class="std-table disc-hosts-table">
        <thead>
            <tr>
                <th>IP</th><th>Hostname</th><th>MAC</th><th>Vendor</th>
                <th>OS</th><th>Source</th><th>Iface</th><th>L2</th><th>Roles</th><th>Last Seen</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($segHosts as $h) { $renderHostRow($h); } ?>
        </tbody>
    </table>
    <?php else: ?>
    <p class="disc-empty-segment">No hosts discovered in this segment.</p>
    <?php endif ?>
    </details>
</div>
<?php endforeach ?>
