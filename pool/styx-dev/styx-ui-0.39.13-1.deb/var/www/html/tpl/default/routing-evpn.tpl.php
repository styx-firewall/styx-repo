<?php
/** EVPN @var array<mixed> $tdata js: scripts/routing/routing-evpn.js */
$ec = $tdata['page_data']['evpn_config'] ?? [];
$bindings = $tdata['page_data']['vrf_bindings'] ?? [];
$vrf_ifaces = $tdata['page_data']['vrf_ifaces'] ?? [];
$can_add = !empty($tdata['page_data']['can_add']);
$can_save = !empty($tdata['page_data']['can_save']);
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>EVPN</h1>

        <details class="nat-help">
            <summary>Help</summary>
            <div class="nat-help-content">
                <p><strong>EVPN (Ethernet VPN)</strong> extends BGP to carry L2/L3 VPN information. Used in VXLAN datacenter fabrics for multi-tenant overlay networks.</p>
                <ul>
                    <li><strong>Advertise All VNI:</strong> Automatically advertise all local VNIs as EVPN Type-3 routes.</li>
                    <li><strong>VRF Bindings:</strong> Map a VRF (tenant) to an L3VNI for inter-VXLAN routing. Enable Type-5 route advertisement to leak routes between VRFs.</li>
                    <li><strong>Requires:</strong> BGP enabled, VXLAN tunnels and bridges configured at the OS level.</li>
                </ul>
            </div>
        </details>
        <div class="content-box">
            <h2>Configuration</h2>
            <form class="std-form form-compact" data-js="evpn-config-form">
                <div class="form-row">
                    <div class="form-col form-col--tight">
                        <label for="evpn_enabled">Enabled</label>
                        <label class="std-switch">
                            <input type="checkbox" id="evpn_enabled" <?= !empty($ec['enabled']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="evpn_all_vni">Advertise All VNI</label>
                        <label class="std-switch">
                            <input type="checkbox" id="evpn_all_vni" <?= !empty($ec['advertise_all_vni']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="evpn_svi_ip">Advertise SVI IP</label>
                        <label class="std-switch">
                            <input type="checkbox" id="evpn_svi_ip" <?= !empty($ec['advertise_svi_ip']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <?php if ($can_save): ?>
                <button type="button" class="std-btn" data-js="evpn-save-config">Save</button>
                <?php endif; ?>
            </form>
        </div>

        <div class="content-box">
            <div class="content-box-header">
                <h2>VRF Bindings</h2>
                <?php if ($can_add): ?>
                <button type="button" class="std-btn" data-js="evpn-toggle-form"
                    data-target="evpn-vrf-add-form">+ Add VRF</button>
                <?php endif; ?>
            </div>
            <div class="content-box" id="evpn-vrf-add-form" style="display:none;">
                <h3>Add VRF Binding</h3>
                <form class="std-form form-compact" data-js="evpn-vrf-form">
                    <div class="form-row">
                        <div class="form-col">
                            <label for="evpn_vrf_iface">VRF Interface</label>
                            <select id="evpn_vrf_iface" class="std-input" required>
                                <option value="">— Select VRF —</option>
                                <?php foreach ($vrf_ifaces as $vrf): ?>
                                <option value="<?= $vrf['id'] ?>"><?= $vrf['interface'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label>L3VNI</label>
                            <div class="set-picker-field" data-js="label-picker-field"
                                 data-set-type="vni" data-max-select="1"
                                 data-label-title="Select VNI label">
                                <input type="hidden" id="evpn_l3vni" name="l3vni" value="">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select VNI label">
                                    <span class="js-set-picker-label">Select VNI label</span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear">&#215;</button>
                            </div>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="evpn_adv_v4">Advertise IPv4</label>
                            <label class="std-switch">
                                <input type="checkbox" id="evpn_adv_v4" checked>
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="evpn_adv_v6">Advertise IPv6</label>
                            <label class="std-switch">
                                <input type="checkbox" id="evpn_adv_v6">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="evpn_vrf_rd">Route Distinguisher</label>
                            <input type="text" id="evpn_vrf_rd" class="std-input"
                                placeholder="e.g. 10.0.0.1:1 or 65000:1 (optional)">
                        </div>
                        <div class="form-col">
                            <label for="evpn_vrf_rt_export">RT Export</label>
                            <input type="text" id="evpn_vrf_rt_export" class="std-input"
                                placeholder="e.g. 65000:100 (optional)">
                        </div>
                        <div class="form-col">
                            <label for="evpn_vrf_rt_import">RT Import</label>
                            <input type="text" id="evpn_vrf_rt_import" class="std-input"
                                placeholder="e.g. 65000:100 (optional)">
                        </div>
                    </div>
                    <div class="form-row">
                        <button type="button" class="std-btn" data-js="evpn-vrf-save">Add VRF</button>
                        <button type="button" class="std-btn std-btn--secondary"
                            data-js="evpn-toggle-form" data-target="evpn-vrf-add-form">Cancel</button>
                    </div>
                </form>
            </div>
            <table class="std-table">
                <thead><tr><th>VRF Name</th><th>L3VNI</th><th>RD</th><th>RT Export</th><th>RT Import</th><th>IPv4</th><th>IPv6</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if (empty($bindings)): ?>
                    <tr class="std-table-empty"><td colspan="8">No VRF bindings.</td></tr>
                <?php else: ?>
                    <?php foreach ($bindings as $b): ?>
                    <?php $l3vniD = $b['l3vni_display'] ?? null; ?>
                    <tr data-vrf-id="<?= $b['id'] ?>">
                        <td>
                            <?php $vrfD = $b['vrf_iface_display'] ?? null; ?>
                            <?php if ($vrfD): ?>
                                <strong><?= $vrfD['name'] ?></strong>
                            <?php else: ?>
                                <span class="text-dim">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($l3vniD): ?>
                                <span class="set-ref" title="ID: <?= $l3vniD['id'] ?>">
                                    <span class="set-name"><?= $l3vniD['name'] ?></span>
                                    <?php if (!empty($l3vniD['value'])): ?>
                                    <span class="set-type"><?= $l3vniD['value'] ?></span>
                                    <?php endif; ?>
                                </span>
                            <?php else: ?>
                                <span class="text-dim">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?= $b['rd'] ?? '<span class="text-dim">auto</span>' ?></td>
                        <td><?= $b['rt_export'] ?? '<span class="text-dim">auto</span>' ?></td>
                        <td><?= $b['rt_import'] ?? '<span class="text-dim">auto</span>' ?></td>
                        <td><?= !empty($b['advertise_ipv4_unicast']) ? 'Yes' : 'No' ?></td>
                        <td><?= !empty($b['advertise_ipv6_unicast']) ? 'Yes' : 'No' ?></td>
                        <td>
                            <?php if (!empty($b['can_delete'])): ?>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="evpn-delete-vrf" data-id="<?= $b['id'] ?>">Delete</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
