<?php
/**
 * TemplateService->getTpl()
 * @var array<mixed> $tdata
 * Included
 * firewall-mgmt-rules.js
 */

$rule = $tdata['page_data']['rule'] ?? [];
$addresses = $tdata['page_data']['addresses'] ?? [];
$ports = $tdata['page_data']['ports'] ?? [];
$ifaces_sets = $tdata['page_data']['ifaces_sets'] ?? [];
$create = $tdata['page_data']['create'] ?? false;
$modify = $tdata['page_data']['modify'] ?? false;
if (isset($rule['src_ifaces'])) {
    $rule['iface'] = $rule['src_ifaces'];
} elseif (isset($rule['dst_ifaces'])) {
    $rule['iface'] = $rule['dst_ifaces'];
}

// Helper: resolve IDs to display names and build picker metadata.
$pickMeta = function (array $ids, array $sets): array {
    $names = [];
    foreach ($ids as $id) {
        foreach ($sets as $s) {
            if (($s['id'] ?? '') === $id) {
                $names[] = $s['name'] ?? $id;
                break;
            }
        }
    }
    return [
        'ids'    => implode(',', $ids),
        'names'  => implode(', ', $names),
        'hasVal' => !empty($ids),
    ];
};

// fwmark: the picker fetches labels via AJAX; just pass the UUID if present.
$fwmarkId = is_array($rule['fwmark'] ?? null) ? ($rule['fwmark']['id'] ?? '') : ($rule['fwmark'] ?? '');
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
    <h1><?= $create ? 'Create local rule' : 'Edit local rule' ?>
        <span class="js-info-icon" data-info-modal="help-local-rule-page"></span>
    </h1>
    <h2>Local firewall rule management</h2>
        <div class="content-box">
            <?php
            if (!empty($tdata['page_data']['error'])):
                ?>
                <div class="error-message fw-error-message">
                    <strong>Error:</strong> <?= $tdata['page_data']['error'] ?>
                </div>
                </div></main></div> <!-- END/FINISH THE TEMPLATE -->
                <?php
                return;
            endif;
            ?>
            <form id="firewall-rule-form" method="post" class="std-form fw-maxwidth"
                <?= !empty($rule['system_rule']) ? 'data-system-rule="1"' : '' ?>
                <?= !empty($rule['end_of_chain']) ? 'data-end-of-chain="1"' : '' ?>
                data-redirect-section="fw-rules-local">
                <input type="hidden" name="table" value="filter" data-field="table">
                <input type="hidden" name="command" value="<?= $modify ? 'update_firewall_rule' : 'set_firewall_rule' ?>">
                <?php if (!empty($rule['id'])): ?>
                    <input type="hidden" name="id" value="<?= $rule['id'] ?>">
                <?php endif; ?>
                <h3 class="form-section-title">Identification</h3>
                <div class="std-flex-row">
                    <label>Rule name
                        <span class="js-info-icon" data-info-modal="help-rule-name"></span>
                        <input type="text" name="name" id="rule-name" data-field="name" required maxlength="64"
                            placeholder="E.g.: Rule name"
                            value="<?= $rule['name'] ?? '' ?>">
                    </label>
                    <label>Comment
                        <span class="js-info-icon" data-info-modal="help-comment"></span>
                        <input type="text" name="comment" id="rule-comment" data-field="comment" maxlength="128"
                            placeholder="Optional comment"
                            value="<?= $rule['comment'] ?? '' ?>">
                    </label>
                </div>
                <h3 class="form-section-title">Context</h3>
                <div class="std-flex-row">
                    <label>Chain
                        <span class="js-info-icon" data-info-modal="help-chain"></span>
                        <select name="chain_select" id="rule-chain" required>
                            <option value="input"
                                <?= (isset($rule['chain']) && $rule['chain'] === 'input') ? 'selected' : '' ?>
                            >Input</option>
                            <option value="output"
                                <?= (isset($rule['chain']) && $rule['chain'] === 'output') ? 'selected' : '' ?>
                            >Output</option>
                        </select>
                    </label>
                    <label>Family</span>
                        <span class="js-info-icon" data-info-modal="help-family"></span>
                        <select name="family" id="rule-family" data-field="family" required>
                            <option value="ip"
                                <?= ((!isset($rule['family']) || $rule['family'] === 'ip') ? 'selected' : '') ?>>
                                IPv4
                            </option>
                            <option value="ip6"
                                <?= (isset($rule['family']) && $rule['family'] === 'ip6') ? 'selected' : '' ?>>
                                IPv6
                            </option>
                        </select>
                    </label>
                    <label>Interface set
                        <span class="js-info-icon" data-info-modal="help-interface-set"></span>
                        <?php
                        $ifaceIds = [];
                        if (isset($rule['iface'])) {
                            $ifaceIds = is_array($rule['iface']) ? $rule['iface'] : [$rule['iface']];
                        }
                        $m = $pickMeta($ifaceIds, $ifaces_sets);
                        ?>
                        <div class="set-picker-field" data-js="set-picker-field"
                            data-set-type="interfaces" data-max-select="20">
                            <input type="hidden" data-field="iface" data-picker-array="true"
                                value="<?= $m['ids'] ?>">
                            <button type="button"
                                class="set-picker-trigger js-set-picker-open<?= $m['hasVal'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="Any (select interface sets…)">
                                <span class="js-set-picker-label">
                                    <?= $m['hasVal'] ? $m['names'] : 'Any (select interface sets…)' ?>
                                </span>
                            </button>
                            <button type="button"
                                class="set-picker-clear js-set-picker-clear<?= $m['hasVal'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                </div>
                <h3 class="form-section-title">Traffic matching — Layer 3</h3>
                <div class="std-flex-row">
                    <label>Source IP(s)
                        <span class="js-info-icon" data-info-modal="help-src-ips"></span>
                        <?php $m = $pickMeta((array)($rule['src_ips'] ?? []), $addresses); ?>
                        <div class="set-picker-field" data-js="set-picker-field"
                            data-set-type="address" data-max-select="20">
                            <input type="hidden" data-field="src_ips" data-picker-array="true"
                                value="<?= $m['ids'] ?>">
                            <button type="button"
                                class="set-picker-trigger js-set-picker-open<?= $m['hasVal'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="Any (select address sets…)">
                                <span class="js-set-picker-label">
                                    <?= $m['hasVal'] ? $m['names'] : 'Any (select address sets…)' ?>
                                </span>
                            </button>
                            <button type="button"
                                class="set-picker-clear js-set-picker-clear<?= $m['hasVal'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                    <label>Destination IP(s)
                        <span class="js-info-icon" data-info-modal="help-dst-ips"></span>
                        <?php $m = $pickMeta((array)($rule['dst_ips'] ?? []), $addresses); ?>
                        <div class="set-picker-field" data-js="set-picker-field"
                            data-set-type="address" data-max-select="20">
                            <input type="hidden" data-field="dst_ips" data-picker-array="true"
                                value="<?= $m['ids'] ?>">
                            <button type="button"
                                class="set-picker-trigger js-set-picker-open<?= $m['hasVal'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="Any (select address sets…)">
                                <span class="js-set-picker-label">
                                    <?= $m['hasVal'] ? $m['names'] : 'Any (select address sets…)' ?>
                                </span>
                            </button>
                            <button type="button"
                                class="set-picker-clear js-set-picker-clear<?= $m['hasVal'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                    <label>Packet mark (fwmark)
                        <span class="js-info-icon" data-info-modal="help-fwmark"></span>
                        <div class="set-picker-field" data-js="label-picker-field"
                            data-set-type="packet_marking"
                            data-max-select="1" data-label-title="Select packet mark">
                            <input type="hidden" data-field="fwmark"
                                value="<?= $fwmarkId ?>">
                            <button type="button"
                                class="std-btn-picker set-picker-trigger js-set-picker-open<?= $fwmarkId ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="None (select mark…)">
                                <span class="js-set-picker-label"><?= $fwmarkId ?: 'None (select mark…)' ?></span>
                            </button>
                            <button type="button"
                                class="std-btn-picker set-picker-clear js-set-picker-clear<?= $fwmarkId ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                </div>
                <h3 class="form-section-title">Traffic matching — Layer 4</h3>
                <div class="std-flex-row">
                    <label>Protocol
                        <span class="js-info-icon" data-info-modal="help-protocol"></span>
                        <select name="protocol" id="rule-protocol" data-field="protocol">
                            <option value="">Any</option>
                            <option value="tcp"
                                <?= (isset($rule['protocol']) && $rule['protocol'] === 'tcp') ? 'selected' : '' ?>>
                                TCP
                            </option>
                            <option value="udp"
                                <?= (isset($rule['protocol']) && $rule['protocol'] === 'udp') ? 'selected' : '' ?>>
                                UDP
                            </option>
                            <option value="icmp"
                                <?= (isset($rule['protocol']) && $rule['protocol'] === 'icmp') ? 'selected' : '' ?>>
                                ICMP
                            </option>
                            <option value="icmpv6"
                                <?= (isset($rule['protocol']) && $rule['protocol'] === 'icmpv6') ? 'selected' : '' ?>>
                                ICMPv6
                            </option>
                        </select>
                    </label>
                    <label>Source port(s)
                        <span class="js-info-icon" data-info-modal="help-src-ports"></span>
                        <?php $m = $pickMeta((array)($rule['src_ports'] ?? []), $ports); ?>
                        <div class="set-picker-field" data-js="set-picker-field"
                            data-set-type="ports" data-max-select="20">
                            <input type="hidden" data-field="src_ports" data-picker-array="true"
                                value="<?= $m['ids'] ?>">
                            <button type="button"
                                class="set-picker-trigger js-set-picker-open<?= $m['hasVal'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="Any (select port sets…)">
                                <span class="js-set-picker-label">
                                    <?= $m['hasVal'] ? $m['names'] : 'Any (select port sets…)' ?>
                                </span>
                            </button>
                            <button type="button"
                                class="set-picker-clear js-set-picker-clear<?= $m['hasVal'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                    <label>Destination port(s)
                        <span class="js-info-icon" data-info-modal="help-dst-ports"></span>
                        <?php $m = $pickMeta((array)($rule['dst_ports'] ?? []), $ports); ?>
                        <div class="set-picker-field" data-js="set-picker-field"
                            data-set-type="ports" data-max-select="20">
                            <input type="hidden" data-field="dst_ports" data-picker-array="true"
                                value="<?= $m['ids'] ?>">
                            <button type="button"
                                class="set-picker-trigger js-set-picker-open<?= $m['hasVal'] ? ' set-picker-trigger--has-value' : '' ?>"
                                data-placeholder="Any (select port sets…)">
                                <span class="js-set-picker-label">
                                    <?= $m['hasVal'] ? $m['names'] : 'Any (select port sets…)' ?>
                                </span>
                            </button>
                            <button type="button"
                                class="set-picker-clear js-set-picker-clear<?= $m['hasVal'] ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </label>
                </div>
                <h3 class="form-section-title">Action</h3>
                <div class="std-flex-row">
                    <label>Action
                        <span class="js-info-icon" data-info-modal="help-action"></span>
                        <select name="action" id="rule-action" data-field="action" required>
                            <option value="accept"
                                <?= (isset($rule['action']) && $rule['action'] === 'accept') ? 'selected' : '' ?>>
                                Accept
                            </option>
                            <option value="drop"
                                <?= (isset($rule['action']) && $rule['action'] === 'drop') ? 'selected' : '' ?>>
                                Drop
                            </option>
                            <option value="reject"
                                <?= (isset($rule['action']) && $rule['action'] === 'reject') ? 'selected' : '' ?>>
                                Reject
                            </option>
                        </select>
                    </label>
                    <label>Rate limit
                        <span class="js-info-icon" data-info-modal="help-rate-limit"></span>
                        <input type="text" name="log_limit" id="rule-log-limit" data-field="log_limit"
                            placeholder="E.g.: 10/minute"
                            value="<?= $rule['log_limit'] ?? '' ?>">
                    </label>
                </div>
                <div class="std-flex-row">
                    <div class="std-collapse-box">
                        <div class="std-collapse-header">Time restriction (optional)</div>
                        <div class="std-collapse-content">
                            <fieldset class="fieldset-no-border">
                                <label>Start time
                                                <span class="js-info-icon" data-info-modal="help-time-restriction"></span>
                                                <input type="time" name="time[start]"
                                                    value="<?= $rule['time']['start'] ?? '' ?>">
                                            </label>
                                <label>End time
                                    <input type="time" name="time[stop]"
                                        value="<?= $rule['time']['stop'] ?? '' ?>">
                                </label>
                                <label>Days of the week
                                    <select name="time[days][]" multiple size="4">
                                        <option value="mon"
                                            <?= isset($rule['time']['days']) &&
                                                in_array('mon', (array)$rule['time']['days']) ? 'selected' : '' ?>>
                                            Monday
                                        </option>
                                        <option value="tue"
                                            <?= isset($rule['time']['days']) &&
                                                in_array('tue', (array)$rule['time']['days']) ? 'selected' : '' ?>>
                                            Tuesday
                                        </option>
                                        <option value="wed"
                                            <?= isset($rule['time']['days']) &&
                                                in_array('wed', (array)$rule['time']['days']) ? 'selected' : '' ?>>
                                            Wednesday
                                        </option>
                                        <option value="thu"
                                            <?= isset($rule['time']['days']) &&
                                                in_array('thu', (array)$rule['time']['days']) ? 'selected' : '' ?>>
                                            Thursday
                                        </option>
                                        <option value="fri"
                                            <?= isset($rule['time']['days']) &&
                                                in_array('fri', (array)$rule['time']['days']) ? 'selected' : '' ?>>
                                            Friday
                                        </option>
                                        <option value="sat"
                                            <?= isset($rule['time']['days']) &&
                                                in_array('sat', (array)$rule['time']['days']) ? 'selected' : '' ?>>
                                            Saturday
                                        </option>
                                        <option value="sun"
                                            <?= isset($rule['time']['days']) &&
                                                in_array('sun', (array)$rule['time']['days']) ? 'selected' : '' ?>>
                                            Sunday
                                        </option>
                                    </select>
                                    <small>Ctrl+Click to select multiple</small>
                                </label>
                            </fieldset>
                        </div>
                    </div>
                </div>
                <div class="std-flex-row">
                    <label class="toggle-switch">
                        <input type="checkbox" name="enabled" value="1"
                            <?= (!isset($rule['enabled']) || $rule['enabled']) ? 'checked' : '' ?>>
                        <span class="toggle-slider" data-on="Enabled" data-off="Disabled"></span>
                    </label>
                    <label class="toggle-switch">
                        <input type="checkbox" name="log" id="rule-log" value="1"
                            <?= !empty($rule['log']) ? 'checked' : '' ?>>
                        <span class="toggle-slider" data-on="LOG" data-off="LOG"></span>
                    </label>
                </div>
                <div class="std-flex-row" id="icmp-type-row">
                    <label>ICMP type
                        <span class="js-info-icon" data-info-modal="help-icmp-type"></span>
                        <input list="icmp-types" name="icmp_type" id="rule-icmp-type" placeholder="Type number or pick…"
                            value="<?= isset($rule['icmp_type']) ? (int)$rule['icmp_type'] : '' ?>">
                        <datalist id="icmp-types">
                            <option value="8">8 — Echo Request</option>
                            <option value="0">0 — Echo Reply</option>
                            <option value="3">3 — Destination Unreachable</option>
                            <option value="11">11 — Time Exceeded</option>
                            <option value="5">5 — Redirect</option>
                            <option value="12">12 — Parameter Problem</option>
                            <option value="13">13 — Timestamp</option>
                            <option value="14">14 — Timestamp Reply</option>
                            <option value="17">17 — Address Mask Request</option>
                            <option value="18">18 — Address Mask Reply</option>
                        </datalist>
                        <small>Pick a common type or type a number (0–255).</small>
                    </label>
                </div>
                <div class="std-flex-row tcp-flags-row" id="tcp-flags-row">
                    <?php $tcpFlags = isset($rule['tcp_flags']) ? (array)$rule['tcp_flags'] : []; ?>
                    <fieldset class="fieldset-no-border">
                        <legend>Flags TCP <span class="js-info-icon" data-info-modal="help-tcp-flags"></span></legend>
                        <div class="flex-row-gap-1em">
                            <label class="inline-flex-center">
                                <input type="checkbox"
                                    name="tcp_flags[]"
                                    value="syn"
                                    <?= in_array('syn', $tcpFlags) ? 'checked' : '' ?>
                                > SYN
                            </label>
                            <label class="inline-flex-center">
                                <input type="checkbox"
                                    name="tcp_flags[]"
                                    value="ack"
                                    <?= in_array('ack', $tcpFlags) ? 'checked' : '' ?>
                                > ACK
                            </label>
                            <label class="inline-flex-center">
                                <input type="checkbox"
                                    name="tcp_flags[]"
                                    value="fin"
                                    <?= in_array('fin', $tcpFlags) ? 'checked' : '' ?>
                                > FIN
                            </label>
                            <label class="inline-flex-center">
                                <input type="checkbox"
                                    name="tcp_flags[]"
                                    value="rst"
                                    <?= in_array('rst', $tcpFlags) ? 'checked' : '' ?>
                                > RST
                            </label>
                            <label class="inline-flex-center">
                                <input type="checkbox"
                                    name="tcp_flags[]"
                                    value="psh"
                                    <?= in_array('psh', $tcpFlags) ? 'checked' : '' ?>
                                > PSH
                            </label>
                            <label class="inline-flex-center">
                                <input type="checkbox"
                                    name="tcp_flags[]"
                                    value="urg"
                                    <?= in_array('urg', $tcpFlags) ? 'checked' : '' ?>
                                > URG
                            </label>
                        </div>
                    </fieldset>
                </div>
                <div class="std-flex-row">
                    <!-- Firewall rule preview -->
                    <div class="fw-preview" style="margin-top:1rem; padding:0.7rem; background:var(--bg-secondary); border-radius:4px; font-family:monospace; font-size:0.9rem; width:100%;">
                        <strong style="display:block; margin-bottom:0.3rem; font-size:0.8rem; color:var(--text-muted);">nft rule preview</strong>
                        <code class="fw-preview-code" style="color:var(--fw-bright); white-space:pre-wrap; word-break:break-all;"></code>
                    </div>
                </div>
                <div class="std-flex-row">
                    <button type="submit"
                        class="std-btn"
                        name="command"
                        value="<?= $modify ? 'update_firewall_rule' : 'set_firewall_rule' ?>"
                    >
                        <?= $create ? 'Create rule' : 'Save changes' ?>
                    </button>
                    <?php if ($modify && !empty($rule['id'])): ?>
                        <button type="submit"
                            class="std-btn std-btn-danger"
                            name="command"
                            value="delete_firewall_rule"
                            onclick="return confirm('Are you sure you want to delete this rule?');"
                            class="margin-left-1em"
                        >
                            Delete rule
                        </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </main>
</div>

<!-- Help content for Local firewall rule editor (referenced by data-info-modal) -->
<div id="help-local-rule-page" style="display:none">
    <p><strong>Local rule editor</strong>: Create or edit a local firewall rule. Fields marked with * are required.</p>
</div>
<div id="help-rule-name" style="display:none">
    <p><strong>Rule name</strong>: Descriptive name for the rule.</p>
</div>
<div id="help-chain" style="display:none">
    <p><strong>Chain</strong>: Choose whether the rule applies to INPUT or OUTPUT chain.</p>
</div>
<div id="help-family" style="display:none">
    <p><strong>Family</strong>: Select IP family (IPv4 or IPv6) for matching.</p>
</div>
<div id="help-interface-set" style="display:none">
    <p><strong>Interface set</strong>: One or more interface sets to match traffic on.</p>
</div>
<div id="help-protocol" style="display:none">
    <p><strong>Protocol</strong>: Protocol to match (TCP/UDP/ICMP) or leave empty for any.</p>
</div>
<div id="help-src-ips" style="display:none">
    <p><strong>Source IPs</strong>: Addresses or address-sets to match as packet sources.</p>
</div>
<div id="help-dst-ips" style="display:none">
    <p><strong>Destination IPs</strong>: Addresses or sets to match as packet destinations.</p>
</div>
<div id="help-src-ports" style="display:none">
    <p><strong>Source ports</strong>: Source ports or port groups to match.</p>
</div>
<div id="help-dst-ports" style="display:none">
    <p><strong>Destination ports</strong>: Destination ports or port groups to match.</p>
</div>
<div id="help-action" style="display:none">
    <p><strong>Action</strong>: What to do with matching traffic: Accept, Drop, or Reject.</p>
</div>
<div id="help-rate-limit" style="display:none">
    <p><strong>Rate limit</strong>: Optional logging or rate-limiting expression (e.g., 10/minute).</p>
</div>
<div id="help-comment" style="display:none">
    <p><strong>Comment</strong>: Optional note for operator reference.</p>
</div>
<div id="help-time-restriction" style="display:none">
    <p><strong>Time restriction</strong>: Schedule when the rule is active.</p>
</div>
<div id="help-icmp-type" style="display:none">
    <p><strong>ICMP type</strong>: Numeric ICMP type or leave blank for all types.</p>
</div>
<div id="help-tcp-flags" style="display:none">
    <p><strong>TCP Flags</strong>: Match packets by TCP flags (SYN, ACK, etc.).</p>
</div>
<div id="help-fwmark" style="display:none">
    <p><strong>Packet mark (fwmark)</strong>: Match packets that have been marked with a specific firewall mark value.
    Select a packet marking label to filter traffic by its mark.</p>
</div>
