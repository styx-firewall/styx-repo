<?php
/**
 * Routing Overview page
 * @var array<mixed> $tdata
 * js: scripts/routing/routing-overview.js
 */
$page_data          = $tdata['page_data'];
$frr                 = $page_data['frr'] ?? ['enabled' => false, 'daemons' => []];
$frr_enabled         = !empty($frr['enabled']);
$frr_daemons         = $frr['daemons'] ?? [];
$igmp_proxy          = $page_data['igmp_proxy'] ?? ['enabled' => false, 'daemon' => null];
$igmp_enabled        = !empty($igmp_proxy['enabled']);
$igmp_daemon         = $igmp_proxy['daemon'] ?? null;
$route_summary       = $page_data['route_summary'] ?? [];
$frr_routes          = $page_data['frr_routes'] ?? [];
$default_gateway_v4  = $page_data['default_gateway_v4'] ?? null;
$default_gateway_v6  = $page_data['default_gateway_v6'] ?? null;
$num_tables          = $page_data['num_tables'] ?? 0;
$num_policy_rules    = $page_data['num_policy_rules'] ?? 0;

$ipv4 = $route_summary['ipv4'] ?? [];
$ipv6 = $route_summary['ipv6'] ?? [];
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>Routing Overview</h1>

        <!-- System Routing Stats (always visible) -->
        <div class="overview-stats-grid">
            <div class="overview-stat-card">
                <div class="overview-stat-value"><?= $ipv4['total'] ?? 0 ?></div>
                <div class="overview-stat-label">IPv4 Routes</div>
            </div>
            <div class="overview-stat-card">
                <div class="overview-stat-value"><?= $ipv6['total'] ?? 0 ?></div>
                <div class="overview-stat-label">IPv6 Routes</div>
            </div>
            <div class="overview-stat-card">
                <div class="overview-stat-value"><?= $num_tables ?></div>
                <div class="overview-stat-label">Routing Tables</div>
            </div>
            <div class="overview-stat-card">
                <div class="overview-stat-value"><?= $num_policy_rules ?></div>
                <div class="overview-stat-label">Policy Rules</div>
            </div>
        </div>

        <!-- Default Gateways -->
        <div class="content-box">
            <h2>Default Gateways</h2>
            <div class="overview-inline-row">
                <span class="overview-inline-label">IPv4:</span>
                <span class="overview-inline-value"><?= $default_gateway_v4 ?: '—' ?></span>
                <span class="overview-inline-label" style="margin-left: 24px;">IPv6:</span>
                <span class="overview-inline-value"><?= $default_gateway_v6 ?: '—' ?></span>
            </div>
        </div>

        <!-- Route Summary by Protocol -->
        <div class="content-box">
            <h2>Route Summary by Protocol</h2>
            <div class="overview-protocol-grid">
                <div>
                    <h3>IPv4</h3>
                    <table class="std-table">
                        <thead>
                            <tr><th>Protocol</th><th>Routes</th></tr>
                        </thead>
                        <tbody>
                        <?php foreach (($ipv4['by_protocol'] ?? []) as $proto => $count): ?>
                            <tr><td><?= ucfirst($proto) ?></td><td><?= $count ?></td></tr>
                        <?php endforeach; ?>
                        <?php if (empty($ipv4['by_protocol'])): ?>
                            <tr class="std-table-empty"><td colspan="2">No data</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div>
                    <h3>IPv6</h3>
                    <table class="std-table">
                        <thead>
                            <tr><th>Protocol</th><th>Routes</th></tr>
                        </thead>
                        <tbody>
                        <?php foreach (($ipv6['by_protocol'] ?? []) as $proto => $count): ?>
                            <tr><td><?= ucfirst($proto) ?></td><td><?= $count ?></td></tr>
                        <?php endforeach; ?>
                        <?php if (empty($ipv6['by_protocol'])): ?>
                            <tr class="std-table-empty"><td colspan="2">No data</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php if ($frr_enabled): ?>
        <!-- FRRouting Daemons -->
        <div class="content-box">
            <h2>FRRouting Daemons</h2>
            <table class="std-table" id="routing-daemons-table">
                <thead>
                    <tr><th>Daemon</th><th>Status</th></tr>
                </thead>
                <tbody>
                <?php foreach ($frr_daemons as $daemon): ?>
                    <tr>
                        <td><?= $daemon['display_daemon_name'] ?></td>
                        <td>
                            <span class="std-badge std-badge--<?= $daemon['status'] === 'running' ? 'success' : 'danger' ?>">

                                <?= $daemon['status'] ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- FRR Route Summary -->
        <div class="content-box">
            <h2>FRR Route Summary</h2>
            <table class="std-table" id="routing-frr-summary-table">
                <thead>
                    <tr><th>Protocol</th><th>IPv4</th><th>IPv6</th></tr>
                </thead>
                <tbody>
                    <tr><td>BGP</td><td id="frr-bgp-ipv4"><?= $frr_routes['ipv4']['bgp'] ?? 0 ?></td><td id="frr-bgp-ipv6"><?= $frr_routes['ipv6']['bgp'] ?? 0 ?></td></tr>
                    <tr><td>OSPF</td><td id="frr-ospf-ipv4"><?= $frr_routes['ipv4']['ospf'] ?? 0 ?></td><td id="frr-ospf-ipv6"><?= $frr_routes['ipv6']['ospf'] ?? 0 ?></td></tr>
                    <tr><td>RIP</td><td id="frr-rip-ipv4"><?= $frr_routes['ipv4']['rip'] ?? 0 ?></td><td id="frr-rip-ipv6"><?= $frr_routes['ipv6']['rip'] ?? 0 ?></td></tr>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <?php if ($igmp_enabled && $igmp_daemon): ?>
        <!-- IGMP Proxy -->
        <div class="content-box">
            <h2>IGMP Proxy</h2>
            <table class="std-table" id="routing-igmp-table">
                <thead>
                    <tr><th>Daemon</th><th>Status</th></tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?= $igmp_daemon['display_daemon_name'] ?? 'IGMP Proxy' ?></td>
                        <td>
                            <span class="std-badge std-badge--<?= ($igmp_daemon['status'] ?? '') === 'running' ? 'success' : 'danger' ?>">
                                <?= $igmp_daemon['status'] ?? 'unknown' ?>
                            </span>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

    </main>
</div>
