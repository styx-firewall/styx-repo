<?php
/**
 * Partial: Address pool form for strongSwan
 * Included into the main vpn-strongswan template via TemplateService load_tpl.
 * Rendered directly inside the Pools tab inline editor; JS toggles visibility
 * and populates fields for add / edit.
 */
?>

<form data-js="swan-pool-form" class="std-form" autocomplete="off">
    <div class="form-row">
        <div class="form-col">
            <label>Pool Name *</label>
            <input type="text" name="name" required value="" placeholder="e.g.: rw-pool">
        </div>
    </div>
    <div class="form-row">
        <div class="form-col">
            <label>Address Range *</label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                data-filter-scope="network,host,host_prefix">
                <input type="hidden" name="addrs" value="">
                <button type="button" class="js-set-picker-open set-picker-trigger"
                    data-placeholder="Select address set…">
                    <span class="js-set-picker-label">Select address set…</span>
                </button>
                <button type="button" class="js-set-picker-clear sets-hidden">×</button>
            </div>
        </div>
        <div class="form-col">
            <label>DNS Server</label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                data-filter-scope="host">
                <input type="hidden" name="dns" value="">
                <button type="button" class="js-set-picker-open set-picker-trigger"
                    data-placeholder="Select DNS address set…">
                    <span class="js-set-picker-label">Select DNS address set…</span>
                </button>
                <button type="button" class="js-set-picker-clear sets-hidden">×</button>
            </div>
        </div>
    </div>
    <div class="form-row">
        <div class="form-col">
            <label>Split-include (routes pushed to client)</label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                data-filter-scope="network,host,host_prefix" data-max-select="20">
                <input type="hidden" name="split_include" value="">
                <button type="button" class="js-set-picker-open set-picker-trigger"
                    data-placeholder="Select subnets to push…">
                    <span class="js-set-picker-label">Select subnets to push…</span>
                </button>
                <button type="button" class="js-set-picker-clear sets-hidden">×</button>
            </div>
        </div>
        <div class="form-col">
            <label>Split-exclude</label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                data-filter-scope="network,host,host_prefix" data-max-select="20">
                <input type="hidden" name="split_exclude" value="">
                <button type="button" class="js-set-picker-open set-picker-trigger"
                    data-placeholder="Select subnets to exclude…">
                    <span class="js-set-picker-label">Select subnets to exclude…</span>
                </button>
                <button type="button" class="js-set-picker-clear sets-hidden">×</button>
            </div>
        </div>
    </div>
</form>
