<?php
/**
 * Partial: Connection form for strongSwan
 * Included into the main vpn-strongswan template via TemplateService load_tpl.
 * Rendered directly inside the Connections tab inline editor; JS toggles
 * visibility and populates fields for add / edit.
 *
 * Select options (interfaces, certs, pools) are server-rendered from
 * StrongswanFormatter data passed via load_tpl['data'].
 * Auth method options use data-versions attributes for JS-driven IKE version filtering.
 *
 * @var array<mixed> $tdata
 */

$interfaceOpts = $tdata['tpl_data']['interface_options'] ?? [];
$certOpts      = $tdata['tpl_data']['cert_options'] ?? [];
$poolOpts      = $tdata['tpl_data']['pool_options'] ?? [];
$propOpts      = $tdata['tpl_data']['proposal_options'] ?? [];
?>

<form data-js="swan-conn-form" class="std-form" autocomplete="off">
    <style>
    .section-head { background:#35528c; padding:7px 14px; border-radius:4px; margin:16px 0 10px; font-size:1.05em; }
    .sub-head { font-weight:600; margin:8px 0 4px; color:#555; font-size:0.95em; }
    </style>

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- Auto-config Wizards                                             -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <div class="form-row">
        <div class="form-col">
            <label>Auto-config Wizards</label>
            <div>
                <button type="button" class="std-btn btn-sm" data-js="auto-site-to-site">Site-to-Site</button>
                <button type="button" class="std-btn btn-sm" data-js="auto-roadwarrior-server">Roadwarrior Server</button>
                <button type="button" class="std-btn btn-sm" data-js="auto-roadwarrior-client">Roadwarrior Client</button>
                <small style="margin-left:8px;color:#666;display:inline-block">Apply a safe, sensible preset to the form.</small>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- Connection Basics                                               -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <h3 class="section-head">Connection Basics</h3>
    <div class="form-row">
        <div class="form-col">
            <label>Connection Name *</label>
            <input type="text" name="name" required value="" placeholder="e.g.: site-to-site-hq">
        </div>
        <div class="form-col">
            <label>Type *
                <span class="js-info-icon" data-info-modal="help-type" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="type" required>
                <option value="tunnel">Tunnel (Site-to-Site / Remote Access)</option>
                <option value="transport">Transport</option>
            </select>
            <div id="help-type" style="display:none">
                <strong>Tunnel</strong>: Encapsulates the entire IP packet. Recommended for both
                site-to-site and remote access (roadwarrior) VPNs.
                <br><br>
                <strong>Transport</strong>: Encrypts only the payload (the IP packet header is
                preserved). Typically used for host-to-host connections rather than
                roadwarrior setups.
            </div>
        </div>
    </div>
    <div class="form-row">
        <div class="form-col">
            <label class="checkbox-label">
                <input type="checkbox" name="remote_access"> Remote Access (Roadwarrior)
                <span class="js-info-icon" data-info-modal="help-remote-access" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div id="help-remote-access" style="display:none">
                Enable remote (roadwarrior) clients to authenticate and receive an IP from a
                pool for access to internal networks.
            </div>
        </div>
        <div class="form-col" data-cond="role" style="display:none;">
            <label>Role
                <span class="js-info-icon" data-info-modal="help-role" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="role">
                <option value="">— Select Role —</option>
                <option value="client">Client</option>
                <option value="server">Server</option>
            </select>
            <div id="help-role" style="display:none">
                Select whether this endpoint should act as client or server.
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- Endpoint                                                        -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <h3 class="section-head">Endpoint</h3>
    <div class="form-row" data-js="iface-warning-row" style="display:none;">
        <div class="form-col">
            <p class="form-warning">No interfaces with IPv4 available.
                Configure an interface before creating a VPN connection.</p>
        </div>
    </div>
    <div class="form-row">
        <div class="form-col">
            <label>Local Address *
                <span class="js-info-icon" data-info-modal="help-local-addrs" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div class="set-picker-field" data-js="set-picker-field"
                data-set-type="address" data-filter-scope="host">
                <input type="hidden" name="local_addrs" value="">
                <button type="button" class="js-set-picker-open set-picker-trigger"
                    data-placeholder="Select local address set…">
                    <span class="js-set-picker-label">Select local address set…</span>
                </button>
                <button type="button" class="js-set-picker-clear sets-hidden">×</button>
            </div>
            <div id="help-local-addrs" style="display:none">
                Local IKE endpoint address set. Standard StrongSwan method — select
                an address set whose IP will be used for IKE communication.
            </div>
        </div>
        <div class="form-col">
            <label>Local Interface (auto-fill)
                <span class="js-info-icon" data-info-modal="help-local-interface" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="interface_id">
                <option value="">— Auto-detect —</option>
                <?php foreach ($interfaceOpts as $iface) : ?>
                <option value="<?= $iface['value'] ?>"<?php if ($iface['disabled']) : ?> disabled<?php endif; ?>>
                    <?= $iface['label'] ?>
                </option>
                <?php endforeach; ?>
            </select>
            <div id="help-local-interface" style="display:none">
                Convenience override: auto-resolves local_addrs from all interface
                address sets. Selecting this clears the explicit Local Address.
            </div>
        </div>
        <div class="form-col">
            <label>IKE Version
                <span class="js-info-icon" data-info-modal="help-ike-version" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="ike_version">
                <option value="2" selected>IKEv2</option>
                <option value="1">IKEv1</option>
                <option value="0">Auto (accept both)</option>
            </select>
            <div id="help-ike-version" style="display:none">
                Select IKE protocol version. IKEv2 is recommended for modern deployments;
                IKEv1 is legacy.
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- Authentication                                                  -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <h3 class="section-head">Authentication</h3>

    <div class="sub-head">Local</div>
    <div class="form-row">
        <div class="form-col">
            <label>Local ID
                <span class="js-info-icon" data-info-modal="help-local-id" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <input type="text" name="local_id" value="" placeholder="e.g.: gw1.example.com or %any">
            <div id="help-local-id" style="display:none">
                Local identity presented to the peer (FQDN, ASN1 DN, or %any). Used for
                certificate and ID matching.
            </div>
        </div>
        <div class="form-col">
            <label>Local Auth
                <span class="js-info-icon" data-info-modal="help-local-auth" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="local_auth">
                <option value="pubkey" data-versions="1,2">Certificate (pubkey)</option>
                <option value="psk" data-versions="1,2">Pre-Shared Key</option>
                <option value="eap-mschapv2" data-versions="2">EAP-MSCHAPv2</option>
                <option value="eap-tls" data-versions="2">EAP-TLS</option>
                <option value="eap-radius" data-versions="2">EAP-RADIUS</option>
            </select>
            <div id="help-local-auth" style="display:none">
                Local authentication method (e.g., PSK, certificate). Choose based on peer
                configuration.
            </div>
        </div>
        <div class="form-col" data-cond="eap-id">
            <label>EAP Identity
                <span class="js-info-icon" data-info-modal="help-eap-id" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <input type="text" name="eap_id" value="" placeholder="e.g.: user@realm">
            <div id="help-eap-id" style="display:none">
                EAP identity sent during EAP authentication. Defaults to local_id if empty.
                Only relevant when local_auth is an EAP method.
            </div>
        </div>
        <div class="form-col" data-cond="local-cert">
            <label>Local Certificate
                <span class="js-info-icon" data-info-modal="help-local-cert" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="local_cert">
                <option value="">— Select Certificate —</option>
                <?php foreach ($certOpts as $cert) : ?>
                <option value="<?= $cert['value'] ?>"><?= $cert['label'] ?></option>
                <?php endforeach; ?>
            </select>
            <div id="help-local-cert" style="display:none">
                Certificate used to authenticate this gateway. Certificate and key cannot be in the same file
            </div>
        </div>
    </div>

    <div class="sub-head">Remote</div>
    <div class="form-row">
        <div class="form-col">
            <label>Remote ID
                <span class="js-info-icon" data-info-modal="help-remote-id" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <input type="text" name="remote_id" value="" placeholder="e.g.: gw2.example.com or %any">
            <div id="help-remote-id" style="display:none">
                Expected identity of the peer for matching (FQDN, ASN1 DN, or %any).
            </div>
        </div>
        <div class="form-col">
            <label>Remote Address
                <span class="js-info-icon" data-info-modal="help-remote-addrs" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                data-filter-scope="host">
                <input type="hidden" name="remote_addrs" value="">
                <button type="button" class="js-set-picker-open set-picker-trigger"
                    data-placeholder="Select remote peer address…">
                    <span class="js-set-picker-label">Select remote peer address…</span>
                </button>
                <button type="button" class="js-set-picker-clear sets-hidden">×</button>
            </div>
            <div id="help-remote-addrs" style="display:none">
                Address set for the remote peer endpoint IP. Empty = %any (roadwarrior).
            </div>
        </div>
        <div class="form-col">
            <label>Remote Auth
                <span class="js-info-icon" data-info-modal="help-remote-auth" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="remote_auth">
                <option value="pubkey" data-versions="1,2">Certificate (pubkey)</option>
                <option value="psk" data-versions="1,2">Pre-Shared Key</option>
                <option value="eap-mschapv2" data-versions="2">EAP-MSCHAPv2</option>
                <option value="eap-tls" data-versions="2">EAP-TLS</option>
                <option value="eap-radius" data-versions="2">EAP-RADIUS</option>
            </select>
            <div id="help-remote-auth" style="display:none">
                Authentication method expected from the remote peer (PSK, certificate, EAP,
                etc.).
            </div>
        </div>
    </div>
    <div class="form-row" data-cond="remote-cert">
        <div class="form-col">
            <label>Remote Certificate
                <span class="js-info-icon" data-info-modal="help-remote-cert" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="remote_cert">
                <option value="">— Select Certificate —</option>
                <?php foreach ($certOpts as $cert) : ?>
                <option value="<?= $cert['value'] ?>"><?= $cert['label'] ?></option>
                <?php endforeach; ?>
            </select>
            <div id="help-remote-cert" style="display:none">
                Select a certificate to validate the remote peer when using certificate auth.
            </div>
        </div>
        <div class="form-col" data-cond="remote-cert">
            <label>Remote CA Certificate(s)
                <span class="js-info-icon" data-info-modal="help-remote-cacerts" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="remote_cacerts[]" multiple size="3" data-js="swan-remote-cacerts">
                <?php foreach ($certOpts as $cert) : ?>
                <option value="<?= $cert['value'] ?>"><?= $cert['label'] ?></option>
                <?php endforeach; ?>
            </select>
            <button type="button" class="std-btn btn-sm" data-js="swan-cacerts-clear" style="margin-top:4px;">Clear selection</button>
            <div id="help-remote-cacerts" style="display:none">
                CA certificate(s) used to verify the remote peer's certificate chain.
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- Traffic Selectors                                               -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <h3 class="section-head">Traffic Selectors</h3>
    <div class="form-row">
        <div class="form-col">
            <label>Local Subnets
                <span class="js-info-icon" data-info-modal="help-local-ts" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                data-filter-scope="network,host,host_prefix" data-max-select="20">
                <input type="hidden" name="local_ts" value="">
                <button type="button" class="js-set-picker-open set-picker-trigger"
                    data-placeholder="Select local subnets…">
                    <span class="js-set-picker-label">Select local subnets…</span>
                </button>
                <button type="button" class="js-set-picker-clear sets-hidden">×</button>
            </div>
            <div id="help-local-ts" style="display:none">
                Address sets for local traffic selectors advertised to the peer.
            </div>
        </div>
        <div class="form-col" data-cond="remote-ts">
            <label>Remote Subnets
                <span class="js-info-icon" data-info-modal="help-remote-ts" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                data-filter-scope="network,host,host_prefix" data-max-select="20">
                <input type="hidden" name="remote_ts" value="">
                <button type="button" class="js-set-picker-open set-picker-trigger"
                    data-placeholder="Select remote subnets…">
                    <span class="js-set-picker-label">Select remote subnets…</span>
                </button>
                <button type="button" class="js-set-picker-clear sets-hidden">×</button>
            </div>
            <div id="help-remote-ts" style="display:none">
                Address sets for remote traffic selectors; routes traffic through the tunnel.
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- Virtual IPs (remote-access client only)                         -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <div class="form-row">
        <div class="form-col" data-cond="vips">
            <label>Virtual IPs (request)
                <span class="js-info-icon" data-info-modal="help-vips" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div class="set-picker-field" data-js="set-picker-field"
                data-set-type="address" data-filter-scope="host">
                <input type="hidden" name="vips" value="">
                <button type="button" class="js-set-picker-open set-picker-trigger"
                    data-placeholder="Select 0.0.0.0 address set…">
                    <span class="js-set-picker-label">Select 0.0.0.0 address set…</span>
                </button>
                <button type="button" class="js-set-picker-clear sets-hidden">×</button>
            </div>
            <div id="help-vips" style="display:none">
                Virtual IP address set to request from the server. Create an address set
                with value 0.0.0.0 (single) or 0.0.0.0, :: (set) to request any IP from
                the server pool.
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- IKE Proposals                                                   -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <h3 class="section-head">IKE Proposals</h3>
    <div class="proposal-builder" data-prefix="ike">
        <div class="proposal-list" data-js="ike-proposal-list"><em>No proposals yet</em></div>
        <input type="hidden" name="ike_proposals" value='[]'>
        <div class="form-row">
            <div class="form-col">
                <label>Encryption</label>
                <select data-role="encryption">
                    <?php foreach ($propOpts['encryption'] as $alg) : ?>
                    <option value="<?= $alg ?>"><?= $alg ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-col" data-role="integrity-col">
                <label>Integrity</label>
                <select data-role="integrity">
                    <?php foreach ($propOpts['integrity'] as $alg) : ?>
                    <option value="<?= $alg ?>"><?= $alg ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-col">
                <label>DH Group</label>
                <select data-role="dh">
                    <?php foreach ($propOpts['dh_groups'] as $alg) : ?>
                    <option value="<?= $alg ?>"><?= $alg ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-col">
                <label>PRF</label>
                <select data-role="prf">
                    <?php foreach ($propOpts['prf'] as $alg) : ?>
                    <option value="<?= $alg ?>"><?= $alg ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <button type="button" class="std-btn btn-sm proposal-add" data-prefix="ike">+ Add Proposal</button>
    </div>

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- ESP Proposals                                                   -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <h3 class="section-head">ESP Proposals</h3>
    <div class="proposal-builder" data-prefix="esp">
        <div class="proposal-list" data-js="esp-proposal-list"><em>No proposals yet</em></div>
        <input type="hidden" name="esp_proposals" value='[]'>
        <div class="form-row">
            <div class="form-col">
                <label>Encryption</label>
                <select data-role="encryption">
                    <?php foreach ($propOpts['encryption'] as $alg) : ?>
                    <option value="<?= $alg ?>"><?= $alg ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-col" data-role="integrity-col">
                <label>Integrity</label>
                <select data-role="integrity">
                    <?php foreach ($propOpts['integrity'] as $alg) : ?>
                    <option value="<?= $alg ?>"><?= $alg ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-col">
                <label>DH Group</label>
                <select data-role="dh">
                    <?php foreach ($propOpts['dh_groups'] as $alg) : ?>
                    <option value="<?= $alg ?>"><?= $alg ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <button type="button" class="std-btn btn-sm proposal-add" data-prefix="esp">+ Add Proposal</button>
    </div>

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- DPD & Lifecycle                                                 -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <h3 class="section-head">DPD &amp; Lifecycle</h3>
    <div class="form-row">
        <div class="form-col">
            <label>Startup Action
                <span class="js-info-icon" data-info-modal="help-start-action" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="start_action">
                <option value="none">None (manual)</option>
                <option value="start">Start (initiate)</option>
                <option value="trap">Trap (on-demand)</option>
            </select>
            <div id="help-start-action" style="display:none">
                Controls how the connection is brought up: manual, initiated by this host, or
                on-demand when traffic arrives.
            </div>
        </div>
        <div class="form-col">
            <label>DPD Delay (s, 0 = disabled)
                <span class="js-info-icon" data-info-modal="help-dpd-delay" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <input type="number" name="dpd_delay" min="0" value="30" placeholder="30">
            <div id="help-dpd-delay" style="display:none">
                Dead Peer Detection delay in seconds. 0 disables DPD.
            </div>
        </div>
        <div class="form-col" data-cond="dpd-timeout">
            <label>DPD Timeout (s, IKEv1 only)
                <span class="js-info-icon" data-info-modal="help-dpd-timeout" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <input type="number" name="dpd_timeout" min="0" value="0" placeholder="0">
            <div id="help-dpd-timeout" style="display:none">
                Timeout before declaring peer dead after DPD probes. IKEv1 only;
                has no effect on IKEv2 connections (which use retransmission timeouts).
            </div>
        </div>
        <div class="form-col" data-cond="dpd-action">
            <label>DPD Action
                <span class="js-info-icon" data-info-modal="help-dpd-action" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="dpd_action">
                <option value="clear">Clear</option>
                <option value="restart">Restart</option>
                <option value="trap">Trap</option>
            </select>
            <div id="help-dpd-action" style="display:none">
                Action to take when peer is considered dead: clear state, restart the
                connection, or trap (on-demand).
            </div>
        </div>
        <div class="form-col">
            <label>Close Action
                <span class="js-info-icon" data-info-modal="help-close-action" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="close_action">
                <option value="none">None</option>
                <option value="start">Start</option>
                <option value="trap">Trap</option>
            </select>
            <div id="help-close-action" style="display:none">
                Behavior when a connection is closed: do nothing, restart (start), or
                trap for on-demand.
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- Timers — collapsible, folded by default                         -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <h3 class="section-head section-head--collapsible" data-js="swan-timers-toggle">
        Timers <span class="collapse-indicator">&#9654;</span>
    </h3>
    <div class="swan-timers-body" style="display:none;">
    <div class="form-row">
        <div class="form-col">
            <label>IKE Rekey Time (s)
                <span class="js-info-icon" data-info-modal="help-ike-rekey" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <input type="number" name="ike_rekey" min="0" value="14400" placeholder="14400">
            <div id="help-ike-rekey" style="display:none">
                Seconds before IKE SA rekey. Set 0 to disable automatic rekeying.
            </div>
        </div>
        <div class="form-col" data-cond="reauth-time">
            <label>Re-auth Time (s, 0 = disabled)</label>
            <input type="number" name="reauth_time" min="0" value="0" placeholder="0">
        </div>
        <div class="form-col">
            <label>Child SA Rekey Time (s)
                <span class="js-info-icon" data-info-modal="help-child-rekey" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <input type="number" name="child_rekey" min="0" value="3600" placeholder="3600">
            <div id="help-child-rekey" style="display:none">
                Seconds before Child SA (ESP) rekey. Controls how often child SAs are refreshed.
            </div>
        </div>
    </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- Advanced — collapsible, folded by default                       -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <h3 class="section-head section-head--collapsible" data-js="swan-advanced-toggle">
        Advanced <span class="collapse-indicator">&#9654;</span>
    </h3>
    <div class="swan-advanced-body" style="display:none;">
    <div class="form-row">
        <div class="form-col">
            <label>Connection Uniqueness
                <span class="js-info-icon" data-info-modal="help-unique" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="unique">
                <option value="">Global default</option>
                <option value="never">Never</option>
                <option value="no">No</option>
                <option value="keep">Keep</option>
                <option value="replace">Replace</option>
            </select>
            <div id="help-unique" style="display:none">
                Connection uniqueness policy. Replace deletes existing connections
                for the same identity; keep rejects new ones; never disables the check.
            </div>
        </div>
        <div class="form-col">
            <label>IKE Fragmentation
                <span class="js-info-icon" data-info-modal="help-fragmentation-conn" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="fragmentation">
                <option value="">Global default</option>
                <option value="yes">Yes</option>
                <option value="accept">Accept</option>
                <option value="force">Force</option>
                <option value="no">No</option>
            </select>
            <div id="help-fragmentation-conn" style="display:none">
                IKE message fragmentation. Useful when EAP or large certificates
                cause oversized IKE packets (common behind NAT).
            </div>
        </div>
        <div class="form-col">
            <label class="checkbox-label">
                <input type="checkbox" name="send_certreq" checked> Send Certificate Request
                <span class="js-info-icon" data-info-modal="help-send-certreq" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div id="help-send-certreq" style="display:none">
                Send certificate request payloads to offer trusted CA certificates
                to the peer. Disable if too many CAs cause oversized packets.
            </div>
        </div>
        <div class="form-col">
            <label>Keying Tries
                <span class="js-info-icon" data-info-modal="help-keyingtries" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <input type="number" name="keyingtries" min="0" value="0" placeholder="0">
            <div id="help-keyingtries" style="display:none">
                Number of retransmission sequences before giving up on connecting.
                0 = retry indefinitely, 1 = try once.
            </div>
        </div>
        <div class="form-col" data-cond="pool">
            <label>Pool (remote-access)
                <span class="js-info-icon" data-info-modal="help-pool" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <select name="pool">
                <option value="">— Select Pool —</option>
                <?php foreach ($poolOpts as $pool) : ?>
                <option value="<?= $pool['value'] ?>"><?= $pool['label'] ?></option>
                <?php endforeach; ?>
            </select>
            <div id="help-pool" style="display:none">
                Name of the address pool to assign to remote-access clients (used with
                roadwarrior).
            </div>
        </div>
        <div class="form-col" data-cond="mobike">
            <label class="checkbox-label">
                <input type="checkbox" name="mobike" checked> MOBIKE
                <span class="js-info-icon" data-info-modal="help-mobike" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div id="help-mobike" style="display:none">
                MOBIKE enables IKE mobility and multihoming for mobile clients (recommended
                for roaming clients).
            </div>
        </div>
        <div class="form-col">
            <label class="checkbox-label">
                <input type="checkbox" name="compress"> IPComp
                <span class="js-info-icon" data-info-modal="help-compress" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div id="help-compress" style="display:none">
                Enable IPComp to compress IP payloads. May reduce bandwidth but can increase
                CPU usage.
            </div>
        </div>
        <div class="form-col">
            <label class="checkbox-label">
                <input type="checkbox" name="forceudp"> Force UDP
                <span class="js-info-icon" data-info-modal="help-forceudp" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div id="help-forceudp" style="display:none">
                Force encapsulation of ESP in UDP (useful for traversing NAT or restricted
                networks).
            </div>
        </div>
    </div>
    <div class="form-row">
        <div class="form-col">
            <label>XFRM Interface ID (Inbound, optional)
                <span class="js-info-icon" data-info-modal="help-if-id" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div class="set-picker-field" data-js="label-picker-field" data-set-type="xfrm_if_id"
                 data-max-select="1" data-label-title="Select XFRM Interface ID">
                <input type="hidden" name="if_id_in" value="">
                <button type="button"
                    class="std-btn-picker set-picker-trigger js-set-picker-open"
                    data-placeholder="Select XFRM if_id (optional)">
                    <span class="js-set-picker-label">Select XFRM if_id (optional)</span>
                </button>
                <button type="button"
                    class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                    title="Clear selection">&#215;</button>
            </div>
            <div id="help-if-id" style="display:none">
                XFRM interface ID for inbound policy. When set, traffic selectors become
                optional — the kernel routes via the XFRM interface. Typically set to the same
                value for both inbound and outbound.
            </div>
        </div>
        <div class="form-col">
            <label>XFRM Interface ID (Outbound, optional)
                <span class="js-info-icon" data-info-modal="help-if-id" aria-label="Info" role="button" tabindex="0"></span>
            </label>
            <div class="set-picker-field" data-js="label-picker-field" data-set-type="xfrm_if_id"
                 data-max-select="1" data-label-title="Select XFRM Interface ID">
                <input type="hidden" name="if_id_out" value="">
                <button type="button"
                    class="std-btn-picker set-picker-trigger js-set-picker-open"
                    data-placeholder="Select XFRM if_id (optional)">
                    <span class="js-set-picker-label">Select XFRM if_id (optional)</span>
                </button>
                <button type="button"
                    class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                    title="Clear selection">&#215;</button>
            </div>
        </div>
    </div>
    </div>

</form>
