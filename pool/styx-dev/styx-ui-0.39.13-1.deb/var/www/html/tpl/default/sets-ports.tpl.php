<?php
/**
 * Fragment: Port objects — unified panel.
 * mode=mgmt   : accordion panel on Objects page (headings + text filter)
 * mode=picker : selection modal — CRUD available + checkbox column + confirm button
 * Expects $tdata['tpl_data']['ports_sets'], $tdata['tpl_data']['mode']
 */
$ports_sets = $tdata['tpl_data']['ports_sets'] ?? [];
$ports_scopes = $tdata['tpl_data']['ports_scopes'] ?? [];
$mode = $tdata['tpl_data']['mode'] ?? 'picker';
?>
<?php if ($mode === 'mgmt'): ?>
<h2>Port Objects</h2>
<?php endif; ?>
<form id="port-object-form" class="std-form" autocomplete="off">
    <input type="hidden" name="id" id="port_id" value="">
    <div class="std-flex-row">
        <label>Type*
            <span class="js-info-icon" data-info-modal="help-port-type"></span>
            <select name="type" required>
                <option value="single">Single port</option>
                <option value="range">Range</option>
                <option value="set">Port set</option>
            </select>
        </label>
        <label>Name*
            <span class="js-info-icon" data-info-modal="help-port-name"></span>
            <input type="text" name="name" required maxlength="32" placeholder="Unique name">
        </label>
        <label>Description
            <span class="js-info-icon" data-info-modal="help-port-description"></span>
            <input type="text" name="description" maxlength="64" placeholder="Optional">
        </label>
        <label>Tags
            <span class="js-info-icon" data-info-modal="help-port-tags"></span>
            <input type="text" name="tags" placeholder="Tags separated by spaces or commas">
        </label>
    </div>

    <div class="std-flex-row value-row value-row-single">
        <label>Port*
            <span class="js-info-icon" data-info-modal="help-port-value-single"></span>
            <input type="number" name="value_single" min="1" max="65535" placeholder="E.g.: 80">
        </label>
    </div>

    <div class="std-flex-row value-row value-row-range sets-hidden">
        <label>Range*
            <span class="js-info-icon" data-info-modal="help-port-value-range"></span>
            <input type="number" name="value_range_start" min="1" max="65535" placeholder="Start">
            <input type="number" name="value_range_end" min="1" max="65535" placeholder="End">
        </label>
    </div>

    <div class="std-flex-row value-row value-row-set sets-hidden">
        <label>Set*
            <span class="js-info-icon" data-info-modal="help-port-value-set"></span>
            <div class="set-list"></div>
            <button type="button" class="add-set-btn std-btn">Add</button>
        </label>
    </div>

    <div id="help-port-type" style="display:none">
        <p><strong>Type</strong>: Single port, range, or a named port set.</p>
    </div>
    <div id="help-port-name" style="display:none">
        <p><strong>Name</strong>: Unique identifier for this port object.</p>
    </div>
    <div id="help-port-description" style="display:none">
        <p><strong>Description</strong>: Optional human-readable description.</p>
    </div>
    <div id="help-port-tags" style="display:none">
        <p><strong>Tags</strong>: Space or comma-separated tags for filtering.</p>
    </div>
    <div id="help-port-value-single" style="display:none">
        <p><strong>Port</strong>: Enter a single numeric port (1-65535).</p>
    </div>
    <div id="help-port-value-range" style="display:none">
        <p><strong>Range</strong>: Start and end ports for a range.</p>
    </div>
    <div id="help-port-value-set" style="display:none">
        <p><strong>Set</strong>: Build a set of ports using the Add button.</p>
    </div>

    <div class="std-flex-row">
        <button type="submit" class="std-btn">Save</button>
        <button type="button" class="std-btn cancel-edit-btn sets-hidden">Cancel</button>
    </div>
</form>

<hr>
<?php if ($mode === 'mgmt'): ?>
<h3>Existing Objects</h3>
<?php endif; ?>
<?php if ($mode === 'mgmt'): ?>
<div class="std-flex-row filters-row">
    <label>Filter
        <input type="text" id="port-filter" class="set-filter-input" placeholder="Filter by name, value or tags">
    </label>
    <label>Filter Scope
        <select id="port-filter-scope" name="filter_scope" class="std-select">
            <option value="">All</option>
            <?php foreach ($ports_scopes as $sval => $slabel): ?>
                <option value="<?= $sval ?>"><?= $slabel ?></option>
            <?php endforeach; ?>
        </select>
    </label>
</div>
<?php elseif ($mode === 'picker'): ?>
<div class="std-flex-row filters-row">
    <label>Filter
        <input type="text" id="port-filter" class="set-filter-input" placeholder="Filter by name, value or tags">
    </label>
</div>
<?php endif; ?>
<table class="std-table" id="port-table">
    <thead>
        <tr>
            <?php if ($mode === 'picker'): ?><th>Select</th><?php endif; ?>
            <th>Name</th>
            <th>Type</th>
            <th>Scope</th>
            <th>Value</th>
            <th>Description</th>
            <th>Tags</th>
            <th>Refs</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($ports_sets as $p): ?>
            <tr>
                <?php if ($mode === 'picker'): ?>
                <td>
                    <input type="checkbox" class="js-set-pick-row"
                        value="<?= $p['id'] ?? '' ?>"
                        data-name="<?= $p['name'] ?? '' ?>">
                </td>
                <?php endif; ?>
                <td class="col-name"><?= $p['name'] ?? '' ?></td>
                <td class="col-type"><?= $p['type'] ?? '' ?></td>
                <td class="col-scope"><?= $p['scope'] ?? '' ?></td>
                <td class="col-value"><?= $p['value_display'] ?? '' ?></td>
                <td class="col-description"><?= $p['description'] ?? '' ?></td>
                <td class="tags-cell col-tags"><?= $p['tags_html'] ?? '' ?></td>
                <td class="col-refs"><?= $p['refs_count'] ?? 0 ?></td>
                <td>
                    <button class="std-btn std-btn-edit"
                        data-id="<?= $p['id'] ?? '' ?>"
                        aria-label="Edit" title="Edit"></button>
                    <?php if (($p['refs_count'] ?? 0) == 0): ?>
                        <button class="std-btn std-btn-delete"
                            data-id="<?= $p['id'] ?? '' ?>"
                            aria-label="Delete" title="Delete"></button>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php if ($mode === 'picker'): ?>
<div class="js-set-picker-actions sets-hidden">
    <button type="button" class="std-btn js-set-picker-confirm">Use selected</button>
</div>
<?php endif; ?>
