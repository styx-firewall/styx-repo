<?php
/**
 * Fragment: Global DHCP configuration
 * Expects formatter-provided presentation keys in $tdata['tpl_data']:
 * - default_lease_time_val, max_lease_time_val, renew_timer_val, rebind_timer_val
 * - dhcp_timer_min, dhcp_timer_max
 * - g_dom_val, g_dom_label, g_dns_val, g_dns_label, g_ds_val, g_ds_label
 * - is_kea
 */
$pagep = $tdata['tpl_data'];
?>
<!-- Global configuration form -->
<form id="dhcp-global-form" method="post" action="submit.php" class="std-form dhcp-global-form">
    <h2 class="dhcp-global-title">DHCP Global Configuration</h2>
    <div class="form-row dhcp-global-row">
        <div class="form-col dhcp-global-col">
            <label for="default_lease_time" class="dhcp-label">Default Lease Time (s)
                <span class="js-info-icon" data-info-modal="help-default-lease-time"></span>
            </label>
            <input
                type="number"
                id="default_lease_time"
                name="default_lease_time"
                class="input-number dhcp-input-number"
                min="<?= $pagep['dhcp_timer_min'] ?>" max="<?= $pagep['dhcp_timer_max'] ?>"
                value="<?= $pagep['default_lease_time_val'] ?>"
            >
        </div>
        <div class="form-col dhcp-global-col">
            <label for="max_lease_time" class="dhcp-label">Max Lease Time (s)
                <span class="js-info-icon" data-info-modal="help-max-lease-time"></span>
            </label>
            <input
                type="number"
                id="max_lease_time"
                name="max_lease_time"
                class="input-number dhcp-input-number"
                min="<?= $pagep['dhcp_timer_min'] ?>" max="<?= $pagep['dhcp_timer_max'] ?>"
                value="<?= $pagep['max_lease_time_val'] ?>"
            >
        </div>
        <div class="form-col dhcp-global-col">
            <label for="renew_timer" class="dhcp-label">Renew Timer (s)
                <span class="js-info-icon" data-info-modal="help-renew-timer"></span>
            </label>
            <input
                type="number"
                id="renew_timer"
                name="renew_timer"
                class="input-number dhcp-input-number"
                min="<?= $pagep['dhcp_timer_min'] ?>" max="<?= $pagep['dhcp_timer_max'] ?>"
                value="<?= $pagep['renew_timer_val'] ?>"
            >
        </div>
        <div class="form-col dhcp-global-col">
            <label for="rebind_timer" class="dhcp-label">Rebind Timer (s)
                <span class="js-info-icon" data-info-modal="help-rebind-timer"></span>
            </label>
            <input
                type="number"
                id="rebind_timer"
                name="rebind_timer"
                class="input-number dhcp-input-number"
                min="<?= $pagep['dhcp_timer_min'] ?>" max="<?= $pagep['dhcp_timer_max'] ?>"
                value="<?= $pagep['rebind_timer_val'] ?>"
            >
        </div>
    </div>
    <div class="form-row dhcp-global-row2">
        <div class="form-col dhcp-global-col2">
            <label for="global_domain_set_id" class="dhcp-label">Domain Name
                <span class="js-info-icon" data-info-modal="help-global-domain"></span>
            </label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="domain" data-max-select="1">
                <input type="hidden" name="global_domain_set_id" id="global_domain_set_id" value="<?= $pagep['g_dom_val'] ?? '' ?>">
                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open<?= !empty($pagep['g_dom_val']) ? ' set-picker-trigger--has-value' : '' ?>" data-placeholder="Select domain…">
                    <span class="js-set-picker-label"><?= $pagep['g_dom_label'] ?? 'Select domain…' ?></span>
                </button>
                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear<?= empty($pagep['g_dom_val']) ? ' sets-hidden' : '' ?>" title="Clear selection">&#215;</button>
            </div>
        </div>
        <div class="form-col dhcp-global-col2">
            <label for="global_dns_set_id" class="dhcp-label">DNS Servers
                <span class="js-info-icon" data-info-modal="help-global-dns"></span>
            </label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-max-select="1">
                <input type="hidden" name="global_dns_set_id" id="global_dns_set_id" value="<?= $pagep['g_dns_val'] ?? '' ?>">
                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open<?= !empty($pagep['g_dns_val']) ? ' set-picker-trigger--has-value' : '' ?>" data-placeholder="Select DNS…">
                    <span class="js-set-picker-label"><?= $pagep['g_dns_label'] ?? 'Select DNS…' ?></span>
                </button>
                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear<?= empty($pagep['g_dns_val']) ? ' sets-hidden' : '' ?>" title="Clear selection">&#215;</button>
            </div>
        </div>
        <div class="form-col dhcp-global-col2">
            <label for="global_domain_search_set_id" class="dhcp-label">Domain Search
                <span class="js-info-icon" data-info-modal="help-global-domain-search"></span>
            </label>
            <div class="set-picker-field" data-js="set-picker-field" data-set-type="domain" data-max-select="1">
                <input type="hidden" name="global_domain_search_set_id" id="global_domain_search_set_id" value="<?= $pagep['g_ds_val'] ?? '' ?>">
                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open<?= !empty($pagep['g_ds_val']) ? ' set-picker-trigger--has-value' : '' ?>" data-placeholder="Select domain search…">
                    <span class="js-set-picker-label"><?= $pagep['g_ds_label'] ?? 'Select domain search…' ?></span>
                </button>
                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear<?= empty($pagep['g_ds_val']) ? ' sets-hidden' : '' ?>" title="Clear selection">&#215;</button>
            </div>
        </div>
    </div>
    <?php if (!empty($pagep['is_kea'])): ?>
    <fieldset class="dhcp-kea-fieldset">
        <legend class="dhcp-kea-legend">Kea-specific Options</legend>
        <div class="form-row dhcp-kea-row">
            <div class="form-col dhcp-kea-col">
                <label for="kea_log_level" class="dhcp-kea-label">Kea Log Level</label>
                <select id="kea_log_level" name="kea_log_level" class="std-select dhcp-kea-select">
                    <option value="INFO">INFO</option>
                    <option value="WARN">WARN</option>
                    <option value="ERROR">ERROR</option>
                    <option value="DEBUG">DEBUG</option>
                </select>
            </div>
        </div>
    </fieldset>
    <?php endif; ?>
    <div class="form-row dhcp-btn-row">
        <button type="submit" class="std-btn dhcp-btn-save-global">Save Global Settings</button>
    </div>

    <!-- Help content for DHCP Global Config (referenced by data-info-modal) -->
    <div id="help-default-lease-time" class="dhcp-help">
        <p><strong>Default Lease Time</strong>: The default lease duration (in seconds) assigned to clients when no per-subnet value is configured.</p>
    </div>

    <div id="help-max-lease-time" class="dhcp-help">
        <p><strong>Max Lease Time</strong>: The maximum lease duration (in seconds) a client may receive. This limits the upper bound of leases.</p>
    </div>

    <div id="help-renew-timer" class="dhcp-help">
        <p><strong>Renew Timer</strong>: Time (in seconds) after which a DHCP client attempts to renew its lease with the server.</p>
    </div>

    <div id="help-rebind-timer" class="dhcp-help">
        <p><strong>Rebind Timer</strong>: Time (in seconds) after which a DHCP client will try to contact any available server to rebind its lease.</p>
    </div>

    <div id="help-global-domain" class="dhcp-help">
        <p><strong>Domain Name</strong>: Select a predefined domain name set to assign to DHCP clients. These domain names are delivered to clients as the DHCP domain option.</p>
    </div>

    <div id="help-global-dns" class="dhcp-help">
        <p><strong>DNS Servers</strong>: Choose a DNS server set to be provided to DHCP clients. The set contains one or more DNS server IP addresses.</p>
    </div>

    <div id="help-global-domain-search" class="dhcp-help">
        <p><strong>Domain Search</strong>: Select a domain search list set to send to clients. This list is used by clients for DNS search suffixes.</p>
    </div>

</form>
