<?php
/**
 * Fragment: Object Labels — unified panel.
 * mode=mgmt   : inline on Objects page (full form + table, no picker column)
 * mode=picker : selection modal — create form + radio-select table + confirm button
 * Expects $tdata['tpl_data']['labels_list'], $tdata['tpl_data']['labels_target_opts'],
 *          $tdata['tpl_data']['mode'], $tdata['tpl_data']['requested_type'] (picker only)
 */
$labels_list = $tdata['tpl_data']['labels_list'] ?? [];
$labels_opts = $tdata['tpl_data']['labels_target_opts'] ?? [];
$mode = $tdata['tpl_data']['mode'] ?? 'mgmt';
?>

<?php if ($mode === 'mgmt'): ?>
<h2>Existing labels</h2>
<?php endif; ?>

<?php if ($mode === 'picker'): ?>
<h2>Select Label</h2>
<?php endif; ?>

<!-- Create form — shared between mgmt and picker modes -->
<div class="content-box picker-create-box">
    <form id="form-create-label" autocomplete="off" class="labels-create-form">
        <label class="labels-field-label">Type</label>
        <select name="type" id="label-type" required>
            <?php foreach ($labels_opts as $k => $v): ?>
            <option value="<?= $k ?>"><?= $v ?></option>
            <?php endforeach; ?>
        </select>

        <?php if ($mode === 'picker'): ?>
        <label class="labels-field-label">Scope</label>
        <select name="label_scope" id="label-scope" disabled>
            <option value="" disabled selected>Select scope...</option>
            <option value="mark">mark</option>
            <option value="ct">ct</option>
            <option value="skbprio">skbprio</option>
            <option value="priority">priority</option>
            <option value="custom">Custom...</option>
        </select>
        <input type="text" id="label-scope-custom" placeholder="Custom scope (e.g. my_scope)"
            class="label-scope-custom" style="display:none" />
        <small id="scope-help" class="scope-help" style="display:none">Examples: mark, nfqueue, ct</small>
        <?php endif; ?>

        <label class="labels-field-label">Label name</label>
        <input type="text" name="label_name" id="label-name" placeholder="e.g. blue-net" required disabled />

        <label class="labels-field-label">Value</label>
        <input type="text" name="label_value" id="label-value" placeholder="" disabled />

        <label class="labels-field-label">Comment</label>
        <input type="text" name="label_comment" id="label-comment" placeholder="Short comment" disabled />

        <button class="std-btn" type="submit" id="label-create-btn" disabled>Create</button>
    </form>
    <div id="labels-result" class="labels-result"></div>
</div>

<?php if ($mode === 'picker'): ?>
<div class="std-flex-row filters-row">
    <label>Filter
        <input type="text" id="label-filter" class="set-filter-input" placeholder="Filter by name or value">
    </label>
</div>
<?php endif; ?>

<!-- .labels-table class is required by initLabelsMgmt() in labels-mgmt.js
     to find the tbody and attach create/delete handlers -->
<table class="std-table labels-table" id="label-table">
    <thead>
        <tr>
            <?php if ($mode === 'picker'): ?><th>Select</th><?php endif; ?>
            <th>Type</th>
            <th>Label</th>
            <th>Scope</th>
            <th>Value</th>
            <th>Comment</th>
            <th>Refs</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php if (empty($labels_list)): ?>
        <tr><td colspan="<?= $mode === 'picker' ? '8' : '7' ?>" style="color:#888;">
            No labels available.
        </td></tr>
    <?php else:
        foreach ($labels_list as $lbl): ?>
        <tr data-id="<?= $lbl['id'] ?? '' ?>"
            data-type="<?= $lbl['type'] ?>"
            data-value="<?= $lbl['value'] ?? '' ?>"
            data-comment="<?= $lbl['comment'] ?? '' ?>">
            <?php if ($mode === 'picker'): ?>
            <td>
                <input type="radio" class="js-set-pick-row" name="label_pick"
                    value="<?= $lbl['id'] ?? '' ?>"
                    data-name="<?= $lbl['name'] ?? '' ?>"
                    data-value="<?= $lbl['value'] ?? '' ?>">
            </td>
            <?php endif; ?>
            <td class="col-type"><?= ($labels_opts[$lbl['type']] ?? $lbl['type']) ?></td>
            <td class="col-name"><?= $lbl['name'] ?></td>
            <td class="col-scope"><?= $lbl['scope'] ?? '-' ?></td>
            <td class="col-value"><?= $lbl['value'] ?? '' ?></td>
            <td class="col-comment"><?= $lbl['comment'] ?? '' ?></td>
            <td class="col-refs"><?= $lbl['refs_count'] ?? 0 ?></td>
            <td>
                <?php if (($lbl['refs_count'] ?? 0) == 0): ?>
                    <button type="button" class="std-btn std-btn-delete"
                        data-id="<?= $lbl['id'] ?? '' ?>"
                        aria-label="Delete" title="Delete"></button>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; endif; ?>
    </tbody>
</table>

<?php if ($mode === 'picker'): ?>
<div class="js-set-picker-actions sets-hidden">
    <button type="button" class="std-btn js-set-picker-confirm">Use selected</button>
</div>
<?php endif; ?>
