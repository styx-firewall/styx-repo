<?php
/**
 * strongSwan IPSec VPN management template
 *
 * TemplateService->getTpl()
 * Includes: vpn-strongswan.js
 *
 * Data is pre-formatted by StrongswanFormatter — this template only
 * echoes ready-to-render values; no data transformation here.
 *
 * @var array<mixed> $tdata
 */

$pd = $tdata['page_data'] ?? [];

// Pre-formatted row arrays (from StrongswanFormatter)
$connRows   = $pd['conn_rows'] ?? [];
$poolRows   = $pd['pool_rows'] ?? [];
$secretRows = $pd['secret_rows'] ?? [];
$certRows   = $pd['cert_rows'] ?? [];
$statusRows = $pd['status_rows'] ?? [];
$global     = $pd['global'] ?? [];
?>

<script>
// Data needed by JS for edit-mode population and dynamic refresh
window.swanConnections = <?= $pd['json_connections'] ?? '[]' ?>;
window.swanSecrets     = <?= $pd['json_secrets'] ?? '[]' ?>;
window.swanPools       = <?= $pd['json_pools'] ?? '[]' ?>;
</script>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>IPSec / strongSwan</h1>
        <section class="content-box">
            <!-- Tabs -->
            <div class="std-tabs" id="swan-tabs">
                <button class="std-tab-btn active" data-tab="status">Status</button>
                <button class="std-tab-btn" data-tab="connections">Connections</button>
                <button class="std-tab-btn" data-tab="pools">Pools</button>
                <button class="std-tab-btn" data-tab="secrets">Secrets</button>
                <button class="std-tab-btn" data-tab="certs">Certificates</button>
                <button class="std-tab-btn" data-tab="global">Global</button>
            </div>

            <!-- ===================== TAB: Connections ===================== -->
            <div class="std-tab-panel" id="tab-connections" data-tab="connections">
                <h2>IPSec Connections</h2>
                <div class="table-actions">
                    <?php if (!empty($tdata['page_data']['can_create'])): ?>
                    <button class="std-btn" id="btn-add-connection">+ Add Connection</button>
                    <?php endif; ?>
                    <button class="std-btn" id="btn-refresh-connections">Refresh</button>
                </div>
                <table class="std-table" id="swan-connections-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Type</th>
                            <th>IKE Version</th>
                            <th>Local ID</th>
                            <th>Remote ID</th>
                            <th>Local Subnets</th>
                            <th>Remote Subnets</th>
                            <th>Auth</th>
                            <th>DPD</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($connRows)): ?>
                        <tr><td colspan="11" class="text-center">No connections configured</td></tr>
                        <?php else: ?>
                        <?php foreach ($connRows as $conn): ?>
                        <tr data-conn-id="<?= $conn['id'] ?>">
                            <td><?= $conn['name'] ?></td>
                            <td><?= $conn['type'] ?></td>
                            <td><?= $conn['ike_version'] ?></td>
                            <td><?= $conn['local_id'] ?></td>
                            <td><?= $conn['remote_id'] ?></td>
                            <td><?= $conn['local_ts'] ?></td>
                            <td><?= $conn['remote_ts'] ?></td>
                            <td><?= $conn['local_auth'] ?></td>
                            <td><?= $conn['dpd_text'] ?></td>
                            <td class="swan-status-cell">
                                <span class="std-badge ike-badge <?= $conn['status_class'] ?>">
                                    <?= $conn['status_text'] ?>
                                </span>
                                <?php if (strtolower((string) ($conn['status_text'] ?? '')) === 'up'): ?>
                                <span class="std-badge tunnel-badge <?= $conn['tunnel_class'] ?>">
                                    <?= $conn['tunnel_text'] ?>
                                </span>
                                <?php endif; ?>
                            </td>
                            <td class="actions-cell">
                                <?php if (!empty($conn['can_up'])): ?>
                                <button class="std-btn btn-sm swan-conn-up"
                                    data-id="<?= $conn['id'] ?>"
                                    title="<?= $conn['initiate_allowed'] ? 'Bring Up' : $conn['initiate_disabled_title'] ?>"
                                    <?php if (!$conn['initiate_allowed']): ?> disabled<?php endif; ?>>&#9654;</button>
                                <?php endif; ?>
                                <?php if (!empty($conn['can_down'])): ?>
                                <button class="std-btn btn-sm swan-conn-down"
                                    data-id="<?= $conn['id'] ?>" title="Tear Down">&#9632;</button>
                                <?php endif; ?>
                                <?php if (!empty($conn['can_edit'])): ?>
                                <button class="std-btn btn-sm swan-conn-edit"
                                    data-id="<?= $conn['id'] ?>" title="Edit">Edit</button>
                                <?php endif; ?>
                                <?php if (!empty($conn['can_delete'])): ?>
                                <button class="std-btn btn-sm btn-danger swan-conn-delete"
                                    data-id="<?= $conn['id'] ?>" title="Delete">Del</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Inline editor for connection add / edit -->
                <div id="swan-conn-inline" class="inline-editor" data-entity="connection" style="display:none;margin-top:16px;">
                    <div class="content-box">
                        <h3 data-js="inline-title">Add Connection</h3>
                        <div style="max-width:920px;margin:0 auto;box-sizing:border-box;padding:0 12px;">
                            <?= $tdata['swan_conn_form'] ?? '' ?>
                        </div>
                        <div class="form-actions" style="margin-top:8px;">
                            <button class="std-btn" data-js="inline-save">Create</button>
                            <button class="std-btn" data-js="inline-cancel">Cancel</button>
                        </div>
                    </div>
                </div>

            </div>

            <!-- ===================== TAB: Pools ===================== -->
            <div class="std-tab-panel" id="tab-pools" data-tab="pools">
                <h2>Address Pools</h2>
                <p class="tab-description">
                    IP address pools for roadwarrior / remote-access VPN clients.
                </p>
                <div class="table-actions">
                    <?php if (!empty($tdata['page_data']['can_create'])): ?>
                    <button class="std-btn" id="btn-add-pool">+ Add Pool</button>
                    <?php endif; ?>
                </div>
                <table class="std-table" id="swan-pools-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Address Range</th>
                            <th>DNS</th>
                            <th>Split Routing</th>
                            <th>Assigned</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($poolRows)): ?>
                        <tr><td colspan="6" class="text-center">No pools configured</td></tr>
                        <?php else: ?>
                        <?php foreach ($poolRows as $pool): ?>
                        <tr data-pool-id="<?= $pool['id'] ?>">
                            <td><?= $pool['name'] ?></td>
                            <td><?= $pool['addrs'] ?></td>
                            <td><?= $pool['dns'] ?></td>
                            <td><?= $pool['split_include'] ?></td>
                            <td><?= $pool['online'] ?> / <?= $pool['size'] ?></td>
                            <td class="actions-cell">
                                <?php if (!empty($pool['can_edit'])): ?>
                                <button class="std-btn btn-sm swan-pool-edit"
                                    data-id="<?= $pool['id'] ?>">Edit</button>
                                <?php endif; ?>
                                <?php if (!empty($pool['can_delete'])): ?>
                                <button class="std-btn btn-sm btn-danger swan-pool-delete"
                                    data-id="<?= $pool['id'] ?>">Del</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Inline editor for pool add / edit -->
                <div id="swan-pool-inline" class="inline-editor" data-entity="pool" style="display:none;margin-top:16px;">
                    <div class="content-box">
                        <h3 data-js="inline-title">Add Address Pool</h3>
                        <div style="max-width:920px;margin:0 auto;box-sizing:border-box;padding:0 12px;">
                            <?= $tdata['swan_pool_form'] ?? '' ?>
                        </div>
                        <div class="form-actions" style="margin-top:8px;">
                            <button class="std-btn" data-js="inline-save">Create</button>
                            <button class="std-btn" data-js="inline-cancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ===================== TAB: Secrets ===================== -->
            <div class="std-tab-panel" id="tab-secrets" data-tab="secrets">
                <h2>Secrets</h2>
                <p class="tab-description">Pre-shared keys, EAP credentials, and private key references.</p>
                <div class="table-actions">
                    <?php if (!empty($tdata['page_data']['can_create'])): ?>
                    <button class="std-btn" id="btn-add-secret">+ Add Secret</button>
                    <?php endif; ?>
                </div>
                <table class="std-table" id="swan-secrets-table">
                    <thead>
                        <tr>
                            <th>ID / Label</th>
                            <th>Type</th>
                            <th>Username</th>
                            <th>Local ID</th>
                            <th>Remote ID</th>
                            <th>Value</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($secretRows)): ?>
                        <tr><td colspan="7" class="text-center">No secrets configured</td></tr>
                        <?php else: ?>
                        <?php foreach ($secretRows as $sec): ?>
                        <tr data-secret-id="<?= $sec['id'] ?>">
                            <td><?= $sec['label'] ?></td>
                            <td><?= $sec['type_text'] ?></td>
                            <td><?= $sec['username'] ?></td>
                            <td><?= $sec['local_id'] ?></td>
                            <td><?= $sec['remote_id'] ?></td>
                            <td class="secret-value-cell">
                                <span class="secret-masked">••••••••</span>
                            </td>
                            <td class="actions-cell">
                                <?php if (!empty($sec['can_edit'])): ?>
                                <button class="std-btn btn-sm swan-secret-edit"
                                    data-id="<?= $sec['id'] ?>">Edit</button>
                                <?php endif; ?>
                                <?php if (!empty($sec['can_delete'])): ?>
                                <button class="std-btn btn-sm btn-danger swan-secret-delete"
                                    data-id="<?= $sec['id'] ?>">Del</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Inline editor for secret add / edit -->
                <div id="swan-secret-inline" class="inline-editor" data-entity="secret" style="display:none;margin-top:16px;">
                    <div class="content-box">
                        <h3 data-js="inline-title">Add Secret</h3>
                        <div style="max-width:920px;margin:0 auto;box-sizing:border-box;padding:0 12px;">
                            <?= $tdata['swan_secret_form'] ?? '' ?>
                        </div>
                        <div class="form-actions" style="margin-top:8px;">
                            <button class="std-btn" data-js="inline-save">Add</button>
                            <button class="std-btn" data-js="inline-cancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ===================== TAB: Certificates ===================== -->
            <div class="std-tab-panel" id="tab-certs" data-tab="certs">
                <h2>Certificates</h2>
                <p class="tab-description">
                    Certificates managed via System &gt; Certificates. Below are the ones available for IPSec.
                </p>
                <table class="std-table" id="swan-certs-table">
                    <thead>
                        <tr>
                            <th>Subject / CN</th>
                            <th>Type</th>
                            <th>Issuer</th>
                            <th>Expiration</th>
                            <th>Status</th>
                            <th>Used By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($certRows)): ?>
                        <tr><td colspan="6" class="text-center">No certificates available</td></tr>
                        <?php else: ?>
                        <?php foreach ($certRows as $cert): ?>
                        <tr>
                            <td><?= $cert['name'] ?></td>
                            <td><?= $cert['type'] ?></td>
                            <td><?= $cert['issuer'] ?></td>
                            <td><?= $cert['expiration'] ?></td>
                            <td>
                                <span class="std-badge <?= $cert['status_class'] ?>">
                                    <?= $cert['status_text'] ?>
                                </span>
                            </td>
                            <td><?= $cert['used_by'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- ===================== TAB: Status ===================== -->
            <div class="std-tab-panel active" id="tab-status" data-tab="status">
                <h2>Connection Status</h2>
                <div class="table-actions">
                    <button class="std-btn" id="btn-refresh-status">Refresh Status</button>
                    <button class="std-btn" id="btn-reload-all">Reload All Connections</button>
                </div>
                <table class="std-table swan-status-table" id="swan-status-table">
                    <thead>
                        <tr>
                            <th class="swan-expand-col"></th>
                            <th>Connection</th>
                            <th>State</th>
                            <th>Remote</th>
                            <th>IKE Proposal</th>
                            <th>Established</th>
                            <th>Rekey In</th>
                            <th>Traffic</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($statusRows)): ?>
                        <tr><td colspan="8" class="text-center">No active SAs</td></tr>
                        <?php else: ?>
                        <?php foreach ($statusRows as $sa): ?>
                        <?php $isRw = count($sa['children'] ?? []) >= 2; ?>
                        <tr class="swan-ike-row<?= $isRw ? ' swan-ike-row--rw' : '' ?>" data-ike-id="<?= $sa['uniqueid'] ?>">
                            <td class="swan-expand-col">
                                <?php if (!empty($sa['children'])): ?>
                                <button class="swan-expand-btn" data-js="swan-expand-ike" title="Show CHILD_SAs"><?= $isRw ? '&#9660;' : '&#9654;' ?></button>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="swan-ike-name"><?= $sa['name'] ?></span>
                                <?php if (!empty($sa['remote_id'])): ?>
                                <div class="swan-sub"><?= $sa['remote_id'] ?></div>
                                <?php endif; ?>
                                <?php if (!empty($sa['local_id'])): ?>
                                <div class="swan-sub text-muted">local: <?= $sa['local_id'] ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="std-badge <?= $sa['state_class'] ?>">
                                    <?= $sa['state_text'] ?>
                                </span>
                                <?php if (!empty($sa['version'])): ?>
                                <div class="swan-sub text-muted">IKEv<?= $sa['version'] ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= $sa['remote_host'] ?>
                                <?php if (!empty($sa['local_host'])): ?>
                                <div class="swan-sub text-muted">via <?= $sa['local_host'] ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="swan-mono"><?= $sa['proposal'] ?></td>
                            <td><?= $sa['established'] ?></td>
                            <td><?= $sa['rekey_time'] ?></td>
                            <td>
                                <?php if (!empty($sa['child_count'])): ?>
                                <span class="swan-traffic-in">↓ <?= $sa['bytes_in_fmt'] ?></span>
                                <span class="swan-traffic-out">↑ <?= $sa['bytes_out_fmt'] ?></span>
                                <div class="swan-sub text-muted"><?= $sa['child_count'] ?> child SA(s)</div>
                                <?php else: ?>
                                <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php if (!empty($sa['children'])): ?>
                        <?php foreach ($sa['children'] as $child): ?>
                        <tr class="swan-child-row" data-ike-parent="<?= $sa['uniqueid'] ?>"<?= $isRw ? '' : ' style="display:none"' ?>>
                            <td></td>
                            <td>
                                <span class="swan-child-name"><?= $child['name'] ?></span>
                                <div class="swan-sub text-muted">reqid <?= $child['uniqueid'] ?></div>
                            </td>
                            <td>
                                <span class="std-badge <?= $child['state_class'] ?>">
                                    <?= $child['state_text'] ?>
                                </span>
                            </td>
                            <td>
                                <?php if (!empty($child['local_ts']) || !empty($child['remote_ts'])): ?>
                                <div class="swan-sub"><?= $child['local_ts'] ?> → <?= $child['remote_ts'] ?></div>
                                <?php endif; ?>
                                <div class="swan-sub text-muted"><?= $child['mode'] ?> / <?= $child['protocol'] ?></div>
                            </td>
                            <td class="text-muted">—</td>
                            <td><?= $child['install_time'] ?></td>
                            <td><?= $child['rekey_time'] ?></td>
                            <td>
                                <span class="swan-traffic-in">↓ <?= $child['bytes_in_fmt'] ?></span>
                                <span class="swan-traffic-out">↑ <?= $child['bytes_out_fmt'] ?></span>
                                <div class="swan-sub text-muted">
                                    <?= $child['packets_in'] ?> / <?= $child['packets_out'] ?> pkt
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- ===================== TAB: Global Config ===================== -->
            <div class="std-tab-panel" id="tab-global" data-tab="global">
                <h2>Global Configuration</h2>
                <form id="swan-global-form" class="std-form std-form--compact" autocomplete="off"
                      style="max-width:920px;margin:0 auto;">

                    <!-- ═══════════════════════════════════════════ -->
                    <!-- Connection Behavior                          -->
                    <!-- ═══════════════════════════════════════════ -->
                    <h3 class="section-head">Connection Behavior</h3>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="swan-uniqueids">Unique IDs
                                <span class="js-info-icon" data-info-modal="help-uniqueids"></span>
                            </label>
                            <select id="swan-uniqueids" name="uniqueids">
                                <?php if (($global['uniqueids'] ?? '') === ''): ?>
                                <option value="" disabled selected>— Select —</option>
                                <?php endif; ?>
                                <option value="replace"
                                    <?= $global['uniqueids'] === 'replace' ? 'selected' : '' ?>>
                                    Replace
                                </option>
                                <option value="no"
                                    <?= $global['uniqueids'] === 'no' ? 'selected' : '' ?>>
                                    No
                                </option>
                                <option value="keep"
                                    <?= $global['uniqueids'] === 'keep' ? 'selected' : '' ?>>
                                    Keep
                                </option>
                                <option value="never"
                                    <?= $global['uniqueids'] === 'never' ? 'selected' : '' ?>>
                                    Never
                                </option>
                            </select>
                        </div>
                        <div class="form-col">
                            <label class="checkbox-label">
                                <input type="checkbox" name="install_routes"
                                    <?= ($global['install_routes'] === true) ? 'checked' : '' ?>>
                                Install Routes
                                <span class="js-info-icon" data-info-modal="help-install-routes"></span>
                            </label>
                        </div>
                        <div class="form-col">
                            <label class="checkbox-label">
                                <input type="checkbox" name="install_virtual_ip"
                                    <?= ($global['install_virtual_ip'] === true) ? 'checked' : '' ?>>
                                Install Virtual IPs
                                <span class="js-info-icon" data-info-modal="help-virtual-ips"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="swan-install-vip-on">Install Virtual IPs On
                                <span class="js-info-icon" data-info-modal="help-install-vip-on"></span>
                            </label>
                            <select id="swan-install-vip-on" name="install_virtual_ip_on">
                                <option value="">— Auto-detect —</option>
                                <?php $ifaceOpts = $pd['interface_options'] ?? []; ?>
                                <?php foreach ($ifaceOpts as $iface) : ?>
                                <option value="<?= $iface['value'] ?>"
                                    <?= !$iface['disabled'] && ($global['install_virtual_ip_on'] ?? '') === $iface['value'] ? 'selected' : '' ?>
                                    <?php if ($iface['disabled']) : ?> disabled<?php endif; ?>>
                                    <?= $iface['label'] ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <div id="help-install-vip-on" style="display:none">
                                Interface where virtual IPs are installed. Empty = auto-detect
                                per-connection outbound interface. Set to loopback for stability on
                                multi-WAN setups.
                            </div>
                        </div>
                        <div class="form-col">
                            <label for="swan-charondebug">Charon Debug
                                <span class="js-info-icon" data-info-modal="help-charondebug"></span>
                            </label>
                            <input type="text" id="swan-charondebug" name="charon_syslog"
                                value="<?= $global['charon_syslog'] ?>"
                                placeholder="e.g.: ike 2, knl 2, cfg 2">
                        </div>
                    </div>

                    <!-- ═══════════════════════════════════════════ -->
                    <!-- Networking                                  -->
                    <!-- ═══════════════════════════════════════════ -->
                    <h3 class="section-head">Networking</h3>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="swan-listen-mode">Socket Listen Mode
                                <span class="js-info-icon" data-info-modal="help-listen-mode"></span>
                            </label>
                            <select id="swan-listen-mode" name="listen_mode"
                                title="Restricts strongSwan to open IKE sockets only on the interfaces referenced by active connections.">
                                <?php if (($global['listen_mode'] ?? '') === ''): ?>
                                <option value="" disabled selected>&mdash; Select &mdash;</option>
                                <?php endif; ?>
                                <option value="all"
                                    <?= $global['listen_mode'] === 'all' ? 'selected' : '' ?>>
                                    All interfaces
                                </option>
                                <option value="connections"
                                    <?= $global['listen_mode'] === 'connections' ? 'selected' : '' ?>>
                                    Connection interfaces only
                                </option>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="swan-fragmentation">IKE Fragmentation
                                <span class="js-info-icon" data-info-modal="help-fragmentation"></span>
                            </label>
                            <select id="swan-fragmentation" name="fragmentation">
                                <?php $frag = $global['fragmentation'] ?? 'yes'; ?>
                                <option value="yes"
                                    <?= $frag === 'yes' ? 'selected' : '' ?>>Yes (accept)</option>
                                <option value="accept"
                                    <?= $frag === 'accept' ? 'selected' : '' ?>>Accept only</option>
                                <option value="force"
                                    <?= $frag === 'force' ? 'selected' : '' ?>>Force</option>
                                <option value="no"
                                    <?= $frag === 'no' ? 'selected' : '' ?>>No</option>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="swan-keep-alive">Keep Alive Interval
                                <span class="js-info-icon" data-info-modal="help-keep-alive"></span>
                            </label>
                            <input type="text" id="swan-keep-alive" name="keep_alive"
                                value="<?= $global['keep_alive'] ?>" placeholder="20s">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="swan-interfaces-use">Bind IKE Sockets To
                                <span class="js-info-icon" data-info-modal="help-interfaces-use"></span>
                            </label>
                            <select id="swan-interfaces-use" name="interfaces_use[]" multiple size="3"
                                title="Restrict charon IKE sockets to the selected interfaces. Empty = auto-detect from connections.">
                                <?php $ifaceUseIds = is_array($global['interfaces_use'] ?? null) ? $global['interfaces_use'] : []; ?>
                                <?php foreach ($ifaceOpts as $iface) : ?>
                                <option value="<?= $iface['value'] ?>"
                                    <?= in_array($iface['value'], $ifaceUseIds) ? 'selected' : '' ?>
                                    <?php if ($iface['disabled']) : ?> disabled<?php endif; ?>>
                                    <?= $iface['label'] ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <div id="help-interfaces-use" style="display:none">
                                Restrict charon IKE sockets to specific interfaces.
                                Empty = auto-compute from all connection interface_ids.
                                Hold Ctrl/Cmd to select multiple.
                            </div>
                        </div>
                    </div>

                    <!-- ═══════════════════════════════════════════ -->
                    <!-- Daemon Resources                             -->
                    <!-- ═══════════════════════════════════════════ -->
                    <h3 class="section-head">Daemon Resources</h3>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="swan-threads">Worker Threads
                                <span class="js-info-icon" data-info-modal="help-threads"></span>
                            </label>
                            <input type="number" id="swan-threads" name="threads" min="1" max="64"
                                value="<?= $global['threads'] ?>" placeholder="16">
                        </div>
                        <div class="form-col">
                            <label for="swan-port">IKE Port
                                <span class="js-info-icon" data-info-modal="help-port"></span>
                            </label>
                            <input type="number" id="swan-port" name="port" min="1" max="65535"
                                value="<?= $global['port'] ?>" placeholder="500">
                        </div>
                        <div class="form-col">
                            <label for="swan-port-nat-t">NAT-T Port
                                <span class="js-info-icon" data-info-modal="help-port-nat-t"></span>
                            </label>
                            <input type="number" id="swan-port-nat-t" name="port_nat_t" min="1" max="65535"
                                value="<?= $global['port_nat_t'] ?>" placeholder="4500">
                        </div>
                    </div>

                    <!-- ═══════════════════════════════════════════ -->
                    <!-- TLS & X.509 — collapsible                       -->
                    <!-- ═══════════════════════════════════════════ -->
                    <h3 class="section-head section-head--collapsible" data-js="swan-tls-toggle">
                        TLS &amp; X.509 <span class="collapse-indicator">&#9654;</span>
                    </h3>
                    <div class="swan-tls-body" style="display:none;">
                    <div class="form-row">
                        <div class="form-col">
                            <label for="swan-tls-version-min">TLS Min Version
                                <span class="js-info-icon" data-info-modal="help-tls-version"></span>
                            </label>
                            <select id="swan-tls-version-min" name="tls_version_min">
                                <option value=""
                                    <?= ($global['tls_version_min'] ?? '') === '' ? 'selected' : '' ?>>&mdash; Default &mdash;</option>
                                <option value="1.0"
                                    <?= $global['tls_version_min'] === '1.0' ? 'selected' : '' ?>>1.0</option>
                                <option value="1.1"
                                    <?= $global['tls_version_min'] === '1.1' ? 'selected' : '' ?>>1.1</option>
                                <option value="1.2"
                                    <?= $global['tls_version_min'] === '1.2' ? 'selected' : '' ?>>1.2</option>
                                <option value="1.3"
                                    <?= $global['tls_version_min'] === '1.3' ? 'selected' : '' ?>>1.3</option>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="swan-tls-version-max">TLS Max Version
                                <span class="js-info-icon" data-info-modal="help-tls-version"></span>
                            </label>
                            <select id="swan-tls-version-max" name="tls_version_max">
                                <option value=""
                                    <?= ($global['tls_version_max'] ?? '') === '' ? 'selected' : '' ?>>&mdash; Default &mdash;</option>
                                <option value="1.0"
                                    <?= $global['tls_version_max'] === '1.0' ? 'selected' : '' ?>>1.0</option>
                                <option value="1.1"
                                    <?= $global['tls_version_max'] === '1.1' ? 'selected' : '' ?>>1.1</option>
                                <option value="1.2"
                                    <?= $global['tls_version_max'] === '1.2' ? 'selected' : '' ?>>1.2</option>
                                <option value="1.3"
                                    <?= $global['tls_version_max'] === '1.3' ? 'selected' : '' ?>>1.3</option>
                            </select>
                        </div>
                        <div class="form-col">
                            <label class="checkbox-label">
                                <input type="checkbox" name="x509_enforce_critical"
                                    <?= ($global['x509_enforce_critical'] === true) ? 'checked' : '' ?>>
                                X.509 Enforce Critical
                                <span class="js-info-icon" data-info-modal="help-x509-enforce"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="swan-tls-cipher">TLS Cipher
                                <span class="js-info-icon" data-info-modal="help-tls-advanced"></span>
                            </label>
                            <input type="text" id="swan-tls-cipher" name="tls_cipher"
                                value="<?= $global['tls_cipher'] ?? '' ?>" placeholder="e.g.: AES-256-CBC">
                        </div>
                        <div class="form-col">
                            <label for="swan-tls-ke-group">TLS Key Exchange Group
                                <span class="js-info-icon" data-info-modal="help-tls-advanced"></span>
                            </label>
                            <input type="text" id="swan-tls-ke-group" name="tls_ke_group"
                                value="<?= $global['tls_ke_group'] ?? '' ?>" placeholder="e.g.: secp256r1">
                        </div>
                        <div class="form-col">
                            <label for="swan-tls-key-exchange">TLS Key Exchange
                                <span class="js-info-icon" data-info-modal="help-tls-advanced"></span>
                            </label>
                            <input type="text" id="swan-tls-key-exchange" name="tls_key_exchange"
                                value="<?= $global['tls_key_exchange'] ?? '' ?>" placeholder="e.g.: ECDHE">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="swan-tls-mac">TLS MAC
                                <span class="js-info-icon" data-info-modal="help-tls-advanced"></span>
                            </label>
                            <input type="text" id="swan-tls-mac" name="tls_mac"
                                value="<?= $global['tls_mac'] ?? '' ?>" placeholder="e.g.: SHA-256">
                        </div>
                        <div class="form-col">
                            <label for="swan-tls-signature">TLS Signature
                                <span class="js-info-icon" data-info-modal="help-tls-advanced"></span>
                            </label>
                            <input type="text" id="swan-tls-signature" name="tls_signature"
                                value="<?= $global['tls_signature'] ?? '' ?>" placeholder="e.g.: RSA-SHA256">
                        </div>
                        <div class="form-col">
                            <label for="swan-tls-suites">TLS Cipher Suites
                                <span class="js-info-icon" data-info-modal="help-tls-advanced"></span>
                            </label>
                            <input type="text" id="swan-tls-suites" name="tls_suites"
                                value="<?= $global['tls_suites'] ?? '' ?>" placeholder="e.g.: TLS_AES_256_GCM_SHA384">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label class="checkbox-label">
                                <input type="checkbox" name="tls_send_certreq_authorities"
                                    <?= ($global['tls_send_certreq_authorities'] === true) ? 'checked' : '' ?>>
                                Send CA DNs in Certificate Request
                                <span class="js-info-icon" data-info-modal="help-tls-advanced"></span>
                            </label>
                        </div>
                    </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="std-btn">
                        <?= !empty($tdata['page_data']['can_apply']) ? 'Save Global Configuration' : 'View Global Configuration' ?>
                    </button>
                    </div>
                </form>

                <!-- Help content for Global Config (referenced by data-info-modal) -->
                <div id="help-uniqueids" style="display:none">
                    <p><strong>Unique IDs</strong>: Controls how strongSwan handles identity payloads when peers
                        use duplicate or conflicting IDs. Options:
                        <em>Replace</em> (rewrite IDs to ensure uniqueness),
                        <em>No</em> (do not send unique IDs),
                        <em>Keep</em> (preserve configured IDs),
                        <em>Never</em> (disable unique ID handling).</p>
                </div>

                <div id="help-charondebug" style="display:none">
                    <p><strong>Charon Debug</strong>: Logging selectors for strongSwan's charon daemon.
                        Use comma-separated facility levels (example: <code>ike 2, knl 2, cfg 2</code>) to
                        increase or reduce diagnostic output.</p>
                </div>

                <div id="help-fragmentation" style="display:none">
                    <p><strong>IKE Fragmentation</strong>: Controls IKE message fragmentation.
                        <em>Yes</em> (accept and send fragments),
                        <em>Accept only</em> (accept but don't send),
                        <em>Force</em> (always fragment), or
                        <em>No</em> (disable). Default: Yes.</p>
                </div>

                <div id="help-install-routes" style="display:none">
                    <p><strong>Install Routes</strong>: When enabled, traffic selector routes (remote/local
                        subnets) are added to the system routing table for established connections. Useful
                        for site-to-site tunnels that require direct reachability.</p>
                </div>

                <div id="help-virtual-ips" style="display:none">
                    <p><strong>Install Virtual IPs</strong>: Assigns and installs virtual (client) IP
                        addresses provided by pools for remote-access (roadwarrior) clients. Needed when
                        clients should receive a specific address from the VPN server.</p>
                </div>

                <div id="help-listen-mode" style="display:none">
                    <p><strong>Socket Listen Mode</strong>: Choose whether strongSwan listens for IKE on
                        <em>All interfaces</em> or only on interfaces referenced by active connections.
                        Restricting to connection interfaces can improve security on multi-homed hosts.</p>
                </div>

                <div id="help-threads" style="display:none">
                    <p><strong>Worker Threads</strong>: Number of worker threads for the charon daemon.
                        Increase for high-throughput or multi-core systems. (Default: 16)</p>
                </div>

                <div id="help-port" style="display:none">
                    <p><strong>IKE Port</strong>: UDP port for IKE traffic. (Default: 500)</p>
                </div>

                <div id="help-port-nat-t" style="display:none">
                    <p><strong>NAT-T Port</strong>: UDP port for NAT-Traversal (ESP-in-UDP). (Default: 4500)</p>
                </div>

                <div id="help-keep-alive" style="display:none">
                    <p><strong>Keep Alive Interval</strong>: NAT keep-alive interval sent by the daemon.
                        Format: number + unit (e.g. <code>20s</code>, <code>5m</code>). (Default: <code>20s</code>)</p>
                </div>

                <div id="help-tls-version" style="display:none">
                    <p><strong>TLS Version</strong>: Minimum/maximum TLS protocol version for the
                        strongSwan TLS listener. Leave at default unless you have specific compatibility
                        requirements.</p>
                </div>

                <div id="help-tls-advanced" style="display:none">
                    <p><strong>TLS Advanced Settings</strong>: Fine-grained EAP-TLS parameters
                        (cipher, key exchange, MAC, signature, suites). Leave empty to use
                        strongSwan defaults. Only needed for compliance or interop requirements.</p>
                </div>
            </div>

        </section>
    </main>
</div>
