<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */

// Datos simulados para el template
$servers = [
    [
        'name' => 'wg0',
        'interface' => 'eth0',
        'listen_port' => 51820,
        'private_key' => 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
        'public_key' => 'yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy',
        'peers' => [
            [
                'name' => 'user1',
                'public_key' => 'peerkey1',
                'allowed_ips' => '10.0.0.2/32',
                'last_handshake' => '2025-07-22 10:15',
                'rx' => '1.2 MB',
                'tx' => '0.8 MB',
                'endpoint' => '1.2.3.4:51820',
                'connected' => true
            ],
            [
                'name' => 'user2',
                'public_key' => 'peerkey2',
                'allowed_ips' => '10.0.0.3/32',
                'last_handshake' => '2025-07-22 09:50',
                'rx' => '0.5 MB',
                'tx' => '0.2 MB',
                'endpoint' => '5.6.7.8:51820',
                'connected' => false
            ]
        ]
    ],
    [
        'name' => 'wg1',
        'interface' => 'eth1',
        'listen_port' => 51821,
        'private_key' => 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
        'public_key' => 'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz',
        'peers' => []
    ]
];

$logs = [
    ['date' => '2025-07-22 10:15', 'server' => 'wg0', 'event' => 'Conexión establecida', 'peer' => 'user1'],
    ['date' => '2025-07-22 09:50', 'server' => 'wg0', 'event' => 'Desconexión', 'peer' => 'user2'],
    ['date' => '2025-07-22 09:30', 'server' => 'wg1', 'event' => 'Servidor iniciado', 'peer' => ''],
];

$globalConfig = [
    'enable_ipv4_forwarding' => true,
    'enable_ipv6_forwarding' => false,
    'dns' => '1.1.1.1, 8.8.8.8',
    'mtu' => 1420
];

// Lista de peers posibles para selección en el modal
$possiblePeers = [
    [
        'name' => 'user1',
        'public_key' => 'peerkey1',
        'allowed_ips' => '10.0.0.2/32'
    ],
    [
        'name' => 'user2',
        'public_key' => 'peerkey2',
        'allowed_ips' => '10.0.0.3/32'
    ],
    [
        'name' => 'user3',
        'public_key' => 'peerkey3',
        'allowed_ips' => '10.0.0.4/32'
    ]
];
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout" style="display: flex; flex-direction: row; gap: 24px;">
    <aside style="flex: 0 0 260px;"><?= $tdata['sidebar'] ?></aside>
    <main class="page-content" style="flex: 1 1 0;">
        <h1>WireGuard VPN (No Functional)</h1>
        <div class="content-box">
            <div class="std-tabs">
                <button type="button" class="std-tab-btn active" data-tab="servers">Servidores</button>
                <button type="button" class="std-tab-btn" data-tab="users">Usuarios conectados</button>
                <button type="button" class="std-tab-btn" data-tab="logs">Logs</button>
                <button type="button" class="std-tab-btn" data-tab="global">Config global</button>
                <button type="button" class="std-tab-btn" data-tab="peers">Crear peer</button>
            </div>
            <!-- Tab: Servidores -->
            <div class="std-tab-panel active" data-tab="servers">
                <h2>Servidores WireGuard</h2>
                <button class="std-btn" id="btn-create-server" style="margin-bottom:12px;">+ Crear nuevo servidor</button>
                <?php foreach ($servers as $srv): ?>
                <div class="std-grid" style="margin-bottom:18px;">
                    <div class="std-grid-item-type1">
                        <h3><?= $srv['name'] ?> (<?= $srv['interface'] ?>)</h3>
                        <div>Puerto: <b><?= $srv['listen_port'] ?></b></div>
                        <div>Clave pública: <span style="font-size:0.95em;"><?= $srv['public_key'] ?></span></div>
                        <div>Peers: <b><?= count($srv['peers']) ?></b></div>
                        <button class="std-btn" style="margin-top:8px;">Edit server</button>
                    </div>
                    <div class="std-grid-item-type1 std-grid-item-type1--double">
                        <h3>Peers</h3>
                        <?php if ($srv['peers']): ?>
                        <table class="std-table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>IP Permitida</th>
                                    <th>Último handshake</th>
                                    <th>RX</th>
                                    <th>TX</th>
                                    <th>Endpoint</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($srv['peers'] as $peer): ?>
                                <tr>
                                    <td><?= $peer['name'] ?></td>
                                    <td><?= $peer['allowed_ips'] ?></td>
                                    <td><?= $peer['last_handshake'] ?></td>
                                    <td><?= $peer['rx'] ?></td>
                                    <td><?= $peer['tx'] ?></td>
                                    <td><?= $peer['endpoint'] ?></td>
                                    <td>
                                        <?php if ($peer['connected']): ?>
                                            <span style="color:green;font-weight:bold;">Conectado</span>
                                        <?php else: ?>
                                            <span style="color:#888;">Desconectado</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="std-btn">Edit</button>
                                        <button class="std-btn" style="background:#e74c3c;">Eliminar</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                            <div style="color:#888;">No hay peers configurados.</div>
                        <?php endif; ?>
                        <button class="std-btn" id="btn-add-peer" style="margin-top:8px;">Añadir peer</button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <!-- Tab: Usuarios conectados -->
            <div class="std-tab-panel" data-tab="users">
                <h2>Usuarios/Peers conectados</h2>
                <table class="std-table">
                    <thead>
                        <tr>
                            <th>Servidor</th>
                            <th>Peer</th>
                            <th>IP Permitida</th>
                            <th>Último handshake</th>
                            <th>RX</th>
                            <th>TX</th>
                            <th>Endpoint</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($servers as $srv): ?>
                            <?php foreach ($srv['peers'] as $peer): ?>
                                <tr>
                                    <td><?= $srv['name'] ?></td>
                                    <td><?= $peer['name'] ?></td>
                                    <td><?= $peer['allowed_ips'] ?></td>
                                    <td><?= $peer['last_handshake'] ?></td>
                                    <td><?= $peer['rx'] ?></td>
                                    <td><?= $peer['tx'] ?></td>
                                    <td><?= $peer['endpoint'] ?></td>
                                    <td>
                                        <?php if ($peer['connected']): ?>
                                            <span style="color:green;font-weight:bold;">Conectado</span>
                                        <?php else: ?>
                                            <span style="color:#888;">Desconectado</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <!-- Tab: Logs -->
            <div class="std-tab-panel" data-tab="logs">
                <h2>Logs de WireGuard</h2>
                <table class="std-table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Servidor</th>
                            <th>Peer</th>
                            <th>Evento</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= $log['date'] ?></td>
                            <td><?= $log['server'] ?></td>
                            <td><?= $log['peer'] ?></td>
                            <td><?= $log['event'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <!-- Tab: Configuración global -->
            <div class="std-tab-panel" data-tab="global">
                <h2>Configuración global</h2>
                <form id="vpn-wireguard-global-form" class="std-form" autocomplete="off">
                    <div class="form-row">
                        <div class="form-col">
                            <label>IPv4 Forwarding</label>
                            <input type="checkbox" name="enable_ipv4_forwarding" <?= $globalConfig['enable_ipv4_forwarding'] ? 'checked' : '' ?>>
                        </div>
                        <div class="form-col">
                            <label>IPv6 Forwarding</label>
                            <input type="checkbox" name="enable_ipv6_forwarding" <?= $globalConfig['enable_ipv6_forwarding'] ? 'checked' : '' ?>>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label>DNS</label>
                            <input type="text" name="dns" value="<?= $globalConfig['dns'] ?>">
                        </div>
                        <div class="form-col">
                            <label>MTU</label>
                            <input type="number" name="mtu" value="<?= $globalConfig['mtu'] ?>">
                        </div>
                    </div>
                    <button type="submit" class="std-btn">Save configuration</button>
                </form>
            </div>
            <!-- Tab: Crear peer -->
            <div class="std-tab-panel" data-tab="peers">
                <h2>Crear peer</h2>
                <form id="form-create-peer" autocomplete="off" style="max-width:420px;margin-bottom:18px;">
                    <div class="form-row">
                        <label style="color:#ccc;">Nombre del peer</label>
                        <input type="text" name="peer_name" required placeholder="Ej: userX" style="background:#333;color:#eee;border:1px solid #444;">
                    </div>
                    <div class="form-row">
                        <label style="color:#ccc;">Clave pública del peer</label>
                        <input type="text" name="peer_public_key" required placeholder="Clave pública generada por el peer" style="background:#333;color:#eee;border:1px solid #444;">
                    </div>
                    <div class="form-row">
                        <label style="color:#ccc;">IP permitida</label>
                        <input type="text" name="peer_allowed_ips" required placeholder="Ej: 10.0.0.5/32" style="background:#333;color:#eee;border:1px solid #444;">
                    </div>
                    <div class="form-row">
                        <label style="color:#ccc;">Endpoint (opcional)</label>
                        <input type="text" name="peer_endpoint" placeholder="Ej: 1.2.3.4:51820" style="background:#333;color:#eee;border:1px solid #444;">
                    </div>
                    <div class="form-row" style="margin-top:18px;display:flex;gap:12px;">
                        <button type="submit" class="std-btn" style="background:#2d8cf0;color:#fff;">Crear peer</button>
                    </div>
                </form>
                <div id="peer-create-result" style="margin-top:18px;display:none;background:#333;padding:12px;border-radius:8px;color:#eee;"></div>
            </div>
        </div>
    </main>
</div>
<!-- Modal para crear nuevo servidor -->
<div id="modal-create-server" class="std-modal" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.6);z-index:999;align-items:center;justify-content:center;">
    <div class="std-modal-content" style="background:#222;color:#eee;padding:32px 24px;border-radius:10px;min-width:340px;max-width:96vw;box-shadow:0 2px 24px #0008;">
        <h2 style="color:#fff;">Crear nuevo servidor WireGuard</h2>
        <form id="form-create-server" autocomplete="off">
            <div class="form-row">
                <label style="color:#ccc;">Nombre del servidor</label>
                <input type="text" name="name" required placeholder="Ej: wg0" style="background:#333;color:#eee;border:1px solid #444;">
            </div>
            <div class="form-row">
                <label style="color:#ccc;">Interfaz</label>
                <input type="text" name="interface" required placeholder="Ej: eth0" style="background:#333;color:#eee;border:1px solid #444;">
            </div>
            <div class="form-row">
                <label style="color:#ccc;">Puerto de escucha</label>
                <input type="number" name="listen_port" required min="1" max="65535" value="51820" style="background:#333;color:#eee;border:1px solid #444;">
            </div>
            <div class="form-row">
                <label style="color:#ccc;">Clave privada</label>
                <input type="text" name="private_key" required placeholder="Clave privada" style="background:#333;color:#eee;border:1px solid #444;">
            </div>
            <div class="form-row">
                <label style="color:#ccc;">Clave pública</label>
                <input type="text" name="public_key" required placeholder="Clave pública" style="background:#333;color:#eee;border:1px solid #444;">
            </div>
            <div class="form-row">
                <label style="color:#ccc;">Peers iniciales (opcional, formato: nombre,ip)</label>
                <textarea name="peers" rows="2" placeholder="user1,10.0.0.2\nuser2,10.0.0.3" style="background:#333;color:#eee;border:1px solid #444;"></textarea>
                <div style="margin-top:8px;">
                    <label style="color:#bbb;font-size:0.98em;">Seleccionar peers posibles:</label>
                    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:4px;">
                        <?php foreach ($possiblePeers as $peer): ?>
                            <label style="background:#333;padding:6px 12px;border-radius:6px;color:#eee;cursor:pointer;">
                                <input type="checkbox" class="peer-checkbox" value="<?= $peer['name'] ?>,<?= $peer['allowed_ips'] ?>" style="margin-right:6px;vertical-align:middle;">
                                <?= $peer['name'] ?> <span style="color:#aaa;font-size:0.95em;">(<?= $peer['allowed_ips'] ?>)</span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="form-row" style="margin-top:18px;display:flex;gap:12px;">
                <button type="submit" class="std-btn" style="background:#2d8cf0;color:#fff;">Crear servidor</button>
                <button type="button" class="std-btn" id="btn-cancel-create-server" style="background:#444;color:#eee;">Cancel</button>
            </div>
        </form>
    </div>
</div>
<!-- Modal para añadir peer a servidor -->
<div id="modal-add-peer" class="std-modal" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.6);z-index:999;align-items:center;justify-content:center;">
    <div class="std-modal-content" style="background:#222;color:#eee;padding:32px 24px;border-radius:10px;min-width:340px;max-width:96vw;box-shadow:0 2px 24px #0008;">
        <h2 style="color:#fff;">Añadir peer a servidor</h2>
        <form id="form-add-peer" autocomplete="off">
            <div class="form-row">
                <label style="color:#ccc;">Servidor destino</label>
                <select name="server_name" required style="background:#333;color:#eee;border:1px solid #444;">
                    <?php foreach ($servers as $srv): ?>
                        <option value="<?= $srv['name'] ?>"><?= $srv['name'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row">
                <label style="color:#ccc;">Peer existente</label>
                <select name="peer_name" required style="background:#333;color:#eee;border:1px solid #444;">
                    <?php foreach ($possiblePeers as $peer): ?>
                        <option value="<?= $peer['name'] ?>"><?= $peer['name'] ?> (<?= $peer['allowed_ips'] ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row" style="margin-top:18px;display:flex;gap:12px;">
                <button type="submit" class="std-btn" style="background:#2d8cf0;color:#fff;">Añadir peer</button>
                <button type="button" class="std-btn" id="btn-cancel-add-peer" style="background:#444;color:#eee;">Cancel</button>
            </div>
        </form>
        <div id="add-peer-result" style="margin-top:18px;display:none;background:#333;padding:12px;border-radius:8px;color:#eee;"></div>
    </div>
</div>
<script>
document.querySelectorAll('.std-tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.std-tab-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const tab = this.getAttribute('data-tab');
        document.querySelectorAll('.std-tab-panel').forEach(panel => {
            panel.classList.remove('active');
            panel.style.display = (panel.getAttribute('data-tab') === tab) ? 'block' : 'none';
        });
    });
});
// Modal logic
const btnCreateServer = document.getElementById('btn-create-server');
const modalCreateServer = document.getElementById('modal-create-server');
const btnCancelCreateServer = document.getElementById('btn-cancel-create-server');
btnCreateServer.addEventListener('click', () => {
    modalCreateServer.style.display = 'flex';
});
btnCancelCreateServer.addEventListener('click', () => {
    modalCreateServer.style.display = 'none';
});
document.getElementById('form-create-server').addEventListener('submit', function(e) {
    e.preventDefault();
    // Aquí iría la lógica para enviar los datos al backend
    alert('Servidor creado (simulado).');
    modalCreateServer.style.display = 'none';
    this.reset();
});
document.getElementById('form-create-peer').addEventListener('submit', function(e) {
    e.preventDefault();
    // Simula la creación del peer y muestra los datos generados
    const name = this.peer_name.value.trim();
    const pubkey = this.peer_public_key.value.trim();
    const allowed = this.peer_allowed_ips.value.trim();
    const endpoint = this.peer_endpoint.value.trim();
    let result = `<b>Peer generado:</b><br>`;
    result += `<b>Nombre:</b> ${name}<br>`;
    result += `<b>Clave pública:</b> ${pubkey}<br>`;
    result += `<b>IP permitida:</b> ${allowed}<br>`;
    if(endpoint) result += `<b>Endpoint:</b> ${endpoint}<br>`;
    document.getElementById('peer-create-result').innerHTML = result;
    document.getElementById('peer-create-result').style.display = 'block';
});
// Modal añadir peer logic
const btnAddPeer = document.getElementById('btn-add-peer');
const modalAddPeer = document.getElementById('modal-add-peer');
const btnCancelAddPeer = document.getElementById('btn-cancel-add-peer');
const addPeerResult = document.getElementById('add-peer-result');
if(btnAddPeer && modalAddPeer && btnCancelAddPeer) {
    btnAddPeer.addEventListener('click', () => {
        modalAddPeer.style.display = 'flex';
        addPeerResult.style.display = 'none';
        addPeerResult.innerHTML = '';
        document.getElementById('form-add-peer').reset();
    });
    btnCancelAddPeer.addEventListener('click', () => {
        modalAddPeer.style.display = 'none';
    });
    document.getElementById('form-add-peer').addEventListener('submit', function(e) {
        e.preventDefault();
        // Simula la acción de añadir peer a servidor
        const server = this.server_name.value;
        const peer = this.peer_name.value;
        let result = `<b>Peer añadido:</b><br>`;
        result += `<b>Servidor:</b> ${server}<br>`;
        result += `<b>Peer:</b> ${peer}<br>`;
        addPeerResult.innerHTML = result;
        addPeerResult.style.display = 'block';
    });
}
// Añadir peers seleccionados al textarea
const peerCheckboxes = document.querySelectorAll('.peer-checkbox');
const peersTextarea = document.querySelector('textarea[name="peers"]');
peerCheckboxes.forEach(cb => {
    cb.addEventListener('change', function() {
        let selected = Array.from(peerCheckboxes).filter(c => c.checked).map(c => c.value);
        peersTextarea.value = selected.join('\n');
    });
});
</script>
