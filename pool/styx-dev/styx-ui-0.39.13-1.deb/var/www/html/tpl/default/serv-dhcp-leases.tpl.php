<?php
/**
 * Fragment: DHCP leases table
 * Expects $tdata['tpl_data']['leases_rows']
 */
$leases_rows = $tdata['tpl_data']['leases_rows'] ?? [];
?>
<div class="dhcp-leases-header">
    <h2 class="dhcp-leases-title">Active Leases</h2>
</div>
<table class="std-table">
    <thead>
        <tr>
            <th>Status</th>
            <th>IP Address</th>
            <th>MAC Address</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Hostname</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($leases_rows)): ?>
            <?php foreach ($leases_rows as $row): ?>
                <tr>
                    <td><?= $row['state_html'] ?></td>
                    <td><?= $row['ip'] ?></td>
                    <td><?= $row['mac_html'] ?></td>
                    <td><?= $row['start'] ?></td>
                    <td><?= $row['end'] ?></td>
                    <td><?= $row['hostname'] ?></td>
                    <td><span class="text-muted">—</span></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="7" class="text-muted">No active leases</td></tr>
        <?php endif; ?>
    </tbody>
</table>
