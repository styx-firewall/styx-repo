<?php
/**
 * NAT Rules page — Port Forwarding, Outbound NAT, Static NAT (1:1)
 * @var array<mixed> $tdata
 * Scripts: fw-nat.js, api-client.js
 */
?>
<script>
window.__natData = {
    portForwarding: <?= $tdata['page_data']['port_forwarding_rules_json'] ?? '[]' ?>,
    outbound:       <?= $tdata['page_data']['outbound_rules_json'] ?? '[]' ?>,
    staticNat:      <?= $tdata['page_data']['static_nat_rules_json'] ?? '[]' ?>
};
window.__natSetsData = {
    addresses: <?= $tdata['page_data']['addresses_json'] ?? '[]' ?>,
    ports:     <?= $tdata['page_data']['ports_json'] ?? '[]' ?>,
    ifaces:    <?= $tdata['page_data']['ifaces_json'] ?? '[]' ?>
};
</script>
<?php
$pfRows = $tdata['page_data']['pf_rows'] ?? [];
$obRows = $tdata['page_data']['ob_rows'] ?? [];
$snRows = $tdata['page_data']['sn_rows'] ?? [];
$ovRows = $tdata['page_data']['ov_rows'] ?? [];
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>NAT Rules</h1>
        <section class="content-box">
            <div class="std-tabs" id="nat-tabs">
                <button class="std-tab-btn active" data-tab="overview">Overview</button>
                <button class="std-tab-btn" data-tab="port-forwarding">Port Forwarding</button>
                <button class="std-tab-btn" data-tab="outbound">Outbound NAT</button>
                <button class="std-tab-btn" data-tab="static-nat">Static NAT (1:1)</button>
            </div>
            <div class="std-tab-panel active nat-tab-panel" id="tab-overview">
                <div class="margin-bottom-12">
                    <div class="std-note">Overview of all NAT entries (read-only).</div>
                </div>
                <div id="nat-overview-wrap">
                    <?php if (empty($ovRows)): ?>
                    <div class="std-msg-info fw-std-msg-info">No NAT rules configured.</div>
                    <?php else: ?>
                    <table class="std-table"><thead><tr>
                        <th>Type</th><th>Name</th><th>Family</th><th>Action</th>
                        <th>Source</th><th>Destination / Target</th><th>Out Interface</th>
                        <th>Enabled</th><th>Packets</th><th>Bytes</th>
                    </tr></thead><tbody>
                    <?php foreach ($ovRows as $r): ?>
                    <tr<?= $r['system'] ? ' class="nat-system-row"' : '' ?>>
                        <td><?= $r['type'] ?></td>
                        <td><?= $r['name'] ?></td>
                        <td><?= $r['family'] ?></td>
                        <td><?= $r['action'] ?></td>
                        <td><?= $r['source'] ?></td>
                        <td><?= $r['dest'] ?></td>
                        <td><?= $r['outiface'] ?></td>
                        <td><?= $r['enabled'] ? '🟢' : '🔴' ?></td>
                        <td><?= $r['packets'] ?></td>
                        <td><?= $r['bytes'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody></table>
                    <?php endif; ?>
                </div>
            </div>
            <div class="std-tab-panel nat-tab-panel" id="tab-port-forwarding">
                <details class="nat-help">
                    <summary>Help &amp; common use cases</summary>
                    <div class="nat-help-content">
                        <p><strong>What it does:</strong> Redirects traffic arriving at a public port on the gateway to an internal host and port (DNAT on prerouting).</p>
                        <ul>
                            <li><strong>Expose a web server:</strong> Incoming connections on WAN port 80 or 443 are forwarded to an internal server (e.g. 192.168.1.10:80). Pick the WAN interface and the corresponding port.</li>
                            <li><strong>Remote desktop / SSH access:</strong> Forward WAN:2222 to an internal host at 192.168.1.20:22 so you can reach it from the internet without exposing port 22 directly.</li>
                            <li><strong>Game servers / VoIP:</strong> Forward specific UDP or TCP ports to the internal machine running the game server or PBX.</li>
                            <li><strong>Multiple services on one IP:</strong> Create one rule per service. Each rule can target a different internal host and port.</li>
                        </ul>
                        <p><strong>Hairpin NAT (LAN → LAN via public domain):</strong> If internal clients need to reach an internal server using its public domain name, combine a Port Forwarding rule (with the LAN interface as incoming) with an Outbound Masquerade rule that also targets the LAN interface. Both rules are created independently in their respective tabs.</p>
                        <p><strong>Tips:</strong> The <em>Target IP</em> field requires an address with scope <em>host</em> (plain IP, e.g. <code>192.168.1.10</code>). Use the <em>Target port</em> field to specify the destination port. The family selector supports explicit <code>IPv4</code> and <code>IPv6</code> only — address entries are family-specific. If you need the rule to apply to both families, create two rules (one for IPv4 and one for IPv6). Use the interface and port pickers — literal values are not accepted.</p>
                    </div>
                </details>
                <div class="margin-bottom-12">
            <?php if (!empty($tdata['page_data']['can_create'])): ?>
            <button class="std-btn" id="nat-pf-create-btn">Create rule</button>
            <?php endif; ?>
                </div>
                <div id="nat-pf-form-panel" class="sets-hidden"></div>
                <div id="nat-pf-table-wrap">
                    <?php if (empty($pfRows)): ?>
                    <div class="std-msg-info fw-std-msg-info">No port forwarding rules configured.</div>
                    <?php else: ?>
                    <table class="std-table"><thead><tr>
                        <th>Enabled</th><th>Name</th><th>Family</th>
                        <th>In Interface</th><th>Incoming port</th><th>Src IPs</th>
                        <th>Target IP</th><th>Target Port</th><th>Protocol</th>
                        <th>Packets</th><th>Bytes</th><th>Actions</th>
                    </tr></thead><tbody>
                    <?php foreach ($pfRows as $r): ?>
                    <tr>
                        <td><?= $r['enabled'] ? '🟢' : '🔴' ?></td>
                        <td><?= $r['name'] ?></td>
                        <td><?= $r['family'] ?></td>
                        <td><?= $r['src_ifaces'] ?></td>
                        <td><?= $r['dst_ports'] ?></td>
                        <td><?= $r['src_ips'] ?></td>
                        <td><?= $r['to_set'] ?></td>
                        <td><?= $r['to_ports'] ?></td>
                        <td><?= $r['protocol'] ?></td>
                        <td><?= $r['packets'] ?></td>
                        <td><?= $r['bytes'] ?></td>
                        <td class="nat-actions">
                            <button class="std-btn btn-sm" data-js="nat-pf-edit" data-id="<?= $r['id'] ?>">Edit</button>
                            <button class="std-btn btn-sm" data-js="nat-pf-toggle"
                                data-id="<?= $r['id'] ?>" data-enabled="<?= $r['enabled'] ? '1' : '0' ?>">
                                <?= $r['enabled'] ? 'Disable' : 'Enable' ?></button>
                            <button class="std-btn btn-sm btn-danger" data-js="nat-pf-delete"
                                data-id="<?= $r['id'] ?>" data-name="<?= $r['name'] ?>">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody></table>
                    <?php endif; ?>
                </div>
            </div>
            <div class="std-tab-panel nat-tab-panel" id="tab-outbound">
                <details class="nat-help">
                    <summary>Help &amp; common use cases</summary>
                    <div class="nat-help-content">
                        <p><strong>What it does:</strong> Rewrites the source IP of packets leaving the gateway (SNAT / Masquerade on postrouting). Required for internal hosts to reach the internet.</p>
                        <ul>
                            <li><strong>Basic internet access for a LAN:</strong> Use <em>Masquerade</em> as the action, the LAN address as source, and the WAN interface as outgoing. The gateway's current WAN IP is used automatically — ideal for DHCP WAN connections.</li>
                            <li><strong>Static WAN IP (SNAT):</strong> If the WAN address is fixed, use <em>SNAT</em> and enter the public IP in the <em>Fixed source IP</em> field. This is slightly more efficient than masquerade.</li>
                            <li><strong>Multiple LAN segments:</strong> Create one rule per LAN subnet (or use a group that contains all of them).</li>
                            <li><strong>Restrict outbound NAT to specific destinations:</strong> Fill in the <em>Destination IPs</em> to apply masquerade only when traffic goes to certain external ranges.</li>
                        </ul>
                        <p><strong>Hairpin NAT (LAN → LAN via public domain):</strong> Add an Outbound Masquerade rule with the LAN interface as the <em>outgoing interface</em>. Combine it with a Port Forwarding rule in the previous tab that has the same LAN interface as <em>incoming</em>.</p>
                        <p><strong>Tips:</strong> For most setups a single Masquerade rule on the WAN interface is enough. SNAT is only needed when the WAN address is stable and performance matters at high packet rates.</p>
                    </div>
                </details>
                <div class="margin-bottom-12">
                    <button class="std-btn" id="nat-ob-create-btn">Create rule</button>
                </div>
                <div id="nat-ob-form-panel" class="sets-hidden"></div>
                <div id="nat-ob-table-wrap">
                    <?php if (empty($obRows)): ?>
                    <div class="std-msg-info fw-std-msg-info">No outbound NAT rules configured.</div>
                    <?php else: ?>
                    <table class="std-table"><thead><tr>
                        <th>Enabled</th><th>Name</th><th>Family</th>
                        <th>Action</th><th>Fixed IP (to_set)</th><th>Src IPs</th>
                        <th>Out Interface</th><th>Dst IPs</th><th>Protocol</th>
                        <th>Packets</th><th>Bytes</th><th>Actions</th>
                    </tr></thead><tbody>
                    <?php foreach ($obRows as $r): ?>
                    <tr>
                        <td><?= $r['enabled'] ? '🟢' : '🔴' ?></td>
                        <td><?= $r['name'] ?></td>
                        <td><?= $r['family'] ?></td>
                        <td><?= $r['action'] ?></td>
                        <td><?= $r['to_set'] ?></td>
                        <td><?= $r['src_ips'] ?></td>
                        <td><?= $r['dst_ifaces'] ?></td>
                        <td><?= $r['dst_ips'] ?></td>
                        <td><?= $r['protocol'] ?></td>
                        <td><?= $r['packets'] ?></td>
                        <td><?= $r['bytes'] ?></td>
                        <td class="nat-actions">
                            <button class="std-btn btn-sm" data-js="nat-ob-edit" data-id="<?= $r['id'] ?>">Edit</button>
                            <button class="std-btn btn-sm" data-js="nat-ob-toggle"
                                data-id="<?= $r['id'] ?>" data-enabled="<?= $r['enabled'] ? '1' : '0' ?>">
                                <?= $r['enabled'] ? 'Disable' : 'Enable' ?></button>
                            <button class="std-btn btn-sm btn-danger" data-js="nat-ob-delete"
                                data-id="<?= $r['id'] ?>" data-name="<?= $r['name'] ?>">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody></table>
                    <?php endif; ?>
                </div>
            </div>
            <div class="std-tab-panel nat-tab-panel" id="tab-static-nat">
                <details class="nat-help">
                    <summary>Help &amp; common use cases</summary>
                    <div class="nat-help-content">
                        <p><strong>What it does:</strong> Creates a full bidirectional 1:1 IP mapping — a dedicated public IP is permanently bound to a single internal host. Inbound traffic to the public IP is forwarded to the private IP (DNAT), and outbound traffic from the private IP exits with the public IP as source (SNAT).</p>
                        <ul>
                            <li><strong>Server with its own public IP:</strong> A database server, mail relay, or any host that must always appear as a specific public IP — both for incoming connections and for outgoing connections.</li>
                            <li><strong>IP reputation / allowlisting:</strong> Third-party services that allowlist a fixed source IP. With static NAT the internal host always uses the same public IP, so it passes those checks without any configuration on the host itself.</li>
                            <li><strong>VoIP / SIP trunks:</strong> SIP providers often require a static source IP. Map the internal PBX to a dedicated public IP so all SIP and RTP traffic carries the correct source.</li>
                            <li><strong>Testing / staging with a separate IP:</strong> Assign a different public IP to a staging server so it is fully isolated from production traffic while sharing the same physical WAN link.</li>
                        </ul>
                        <p><strong>Key difference from Port Forwarding:</strong> Port Forwarding only redirects specific ports inbound and does not affect the source IP for outbound traffic. Static NAT maps the entire IP in both directions, regardless of port.</p>
                        <p><strong>Tips:</strong> Both DNAT and SNAT rules are created and deleted together as a pair — you cannot have one without the other here. Use the <em>Public IP</em> and <em>Private IP</em> fields to restrict the match condition, and the <em>Map to</em> fields to specify the actual IPs to translate to.</p>
                    </div>
                </details>
                <div class="margin-bottom-12">
                    <button class="std-btn" id="nat-sn-create-btn">Create rule</button>
                </div>
                <div id="nat-sn-form-panel" class="sets-hidden"></div>
                <div id="nat-sn-table-wrap">
                    <?php if (empty($snRows)): ?>
                    <div class="std-msg-info fw-std-msg-info">No static NAT rules configured.</div>
                    <?php else: ?>
                    <table class="std-table"><thead><tr>
                        <th>Enabled</th><th>Name</th><th>Family</th>
                        <th>Public &harr; Private</th><th>In Interface</th>
                        <th>Packets</th><th>Bytes</th><th>Actions</th>
                    </tr></thead><tbody>
                    <?php foreach ($snRows as $r): ?>
                    <tr>
                        <td><?= $r['enabled'] ? '🟢' : '🔴' ?></td>
                        <td><?= $r['name'] ?></td>
                        <td><?= $r['family'] ?></td>
                        <td><?= $r['to_public_set'] ?> &harr; <?= $r['to_private_set'] ?></td>
                        <td><?= $r['src_ifaces'] ?></td>
                        <td><?= $r['packets'] ?></td>
                        <td><?= $r['bytes'] ?></td>
                        <td class="nat-actions">
                            <button class="std-btn btn-sm" data-js="nat-sn-toggle"
                                data-id="<?= $r['id'] ?>" data-enabled="<?= $r['enabled'] ? '1' : '0' ?>">
                                <?= $r['enabled'] ? 'Disable' : 'Enable' ?></button>
                            <button class="std-btn btn-sm btn-danger" data-js="nat-sn-delete"
                                data-id="<?= $r['id'] ?>" data-name="<?= $r['name'] ?>">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody></table>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</div>

<template id="tmpl-nat-pf-form">
    <form id="nat-pf-form" class="std-form">
        <div class="std-flex-row">
            <label>Name <span class="fw-required-star">*</span>
                <input type="text" name="name" id="pf-name" required maxlength="64" placeholder="E.g.: Redirect HTTPS">
            </label>
            <label>Family <span class="fw-required-star">*</span>
                <select id="pf-family" name="pf-family">
                    <option value="ip">IPv4</option>
                    <option value="ip6">IPv6</option>
                </select>
            </label>
        </div>
        <div class="std-flex-row">
            <label>Incoming interface
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="interfaces" data-max-select="20">
                    <input type="hidden" id="pf-src_ifaces" name="pf-src_ifaces" value="">
                    <button type="button" class="set-picker-trigger js-set-picker-open"
                        data-placeholder="Any (select interface sets…)">
                        <span class="js-set-picker-label">Any (select interface sets…)</span>
                    </button>
                    <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
            </label>
            <label>Incoming port
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="ports" data-max-select="20">
                    <input type="hidden" id="pf-dst_ports" name="pf-dst_ports" value="">
                    <button type="button" class="set-picker-trigger js-set-picker-open"
                        data-placeholder="Any (select port sets…)">
                        <span class="js-set-picker-label">Any (select port sets…)</span>
                    </button>
                    <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
            </label>
            <label>Source IP
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="address" data-max-select="20">
                    <input type="hidden" id="pf-src_ips" name="pf-src_ips" value="">
                    <button type="button" class="set-picker-trigger js-set-picker-open"
                        data-placeholder="Any (select address sets…)">
                        <span class="js-set-picker-label">Any (select address sets…)</span>
                    </button>
                    <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
            </label>
        </div>
        <div class="std-flex-row">
            <label>Target IP <span class="fw-required-star">*</span>
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="address" data-filter-scope="host">
                    <input type="hidden" id="pf-to_set" name="pf-to_set" value="">
                    <button type="button" class="set-picker-trigger js-set-picker-open"
                        data-placeholder="Select target IP…">
                        <span class="js-set-picker-label">Select target IP…</span>
                    </button>
                    <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
                <small>Address with the target host IP (scope <em>host</em>)</small>
            </label>
            <label>Target port
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="ports">
                    <input type="hidden" id="pf-to_ports" name="pf-to_ports" value="">
                    <button type="button" class="set-picker-trigger js-set-picker-open"
                        data-placeholder="Select target port…">
                        <span class="js-set-picker-label">Select target port…</span>
                    </button>
                    <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
                <small>Port to redirect traffic to</small>
            </label>
            <label>Protocol
                <select id="pf-protocol" name="pf-protocol">
                    <option value="">Any</option>
                    <option value="tcp">TCP</option>
                    <option value="udp">UDP</option>
                </select>
            </label>
        </div>
        <div class="std-flex-row">
            <label>Comment
                <input type="text" name="comment" id="pf-comment" maxlength="128">
            </label>
            <label class="inline-flex-center">
                <input type="checkbox" name="enabled" value="1" checked>
                &nbsp;Enabled
            </label>
        </div>
        <div class="std-flex-row">
            <button type="submit" class="std-btn js-submit-btn">Create</button>
            <button type="button" class="std-btn" data-js="nat-pf-cancel">Cancel</button>
        </div>
    </form>
</template>

<template id="tmpl-nat-overview">
    <div>
        <table class="std-table">
            <thead>
                <tr>
                    <th>Type</th><th>Name</th><th>Family</th><th>Action</th>
                    <th>Source</th><th>Destination / Target</th><th>Out Interface</th>
                    <th>Enabled</th><th>Packets</th><th>Bytes</th>
                </tr>
            </thead>
            <tbody id="nat-overview-rows"></tbody>
        </table>
    </div>
</template>

<template id="tmpl-nat-overview-row">
    <tr>
        <td class="ov-type"></td>
        <td class="ov-name"></td>
        <td class="ov-family"></td>
        <td class="ov-action"></td>
        <td class="ov-source"></td>
        <td class="ov-dest"></td>
        <td class="ov-outiface"></td>
        <td class="ov-enabled"></td>
        <td class="ov-packets"></td>
        <td class="ov-bytes"></td>
    </tr>
</template>


<template id="tmpl-nat-ob-form">
    <form id="nat-ob-form" class="std-form">
        <div class="std-flex-row">
            <label>Name <span class="fw-required-star">*</span>
                <input type="text" name="name" id="ob-name" required maxlength="64" placeholder="E.g.: LAN Masquerade">
            </label>
            <label>Family <span class="fw-required-star">*</span>
                <select id="ob-family" name="ob-family">
                    <option value="ip">IPv4</option>
                    <option value="ip6">IPv6</option>
                </select>
            </label>
        </div>
        <div class="std-flex-row">
            <label>Action <span class="fw-required-star">*</span>
                <select id="ob-action" name="ob-action">
                    <option value="masquerade">Masquerade</option>
                    <option value="snat">SNAT (fixed IP)</option>
                </select>
            </label>
            <label id="ob-to-set-label" style="display:none">
                SNAT — Fixed public IP (egress address) <span class="fw-required-star">*</span>
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="address" data-filter-scope="host">
                    <input type="hidden" id="ob-to_set" name="ob-to_set" value="">
                    <button type="button" class="set-picker-trigger js-set-picker-open"
                        data-placeholder="Select public IP…">
                        <span class="js-set-picker-label">Select public IP…</span>
                    </button>
                    <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
                <small>Public IP to use as source after NAT (egress address). Enter plain IP, no port.</small>
            </label>
        </div>
        <div class="std-flex-row">
            <label>Match source (internal hosts / subnets)
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="address" data-max-select="20">
                    <input type="hidden" id="ob-src_ips" name="ob-src_ips" value="">
                    <button type="button" class="set-picker-trigger js-set-picker-open"
                        data-placeholder="Any (select address sets…)">
                        <span class="js-set-picker-label">Any (select address sets…)</span>
                    </button>
                    <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
                <small>Internal IPs or subnets to translate (e.g. 192.168.1.0/24)</small>
            </label>
            <label>Outgoing interface (WAN)
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="interfaces" data-max-select="20">
                    <input type="hidden" id="ob-dst_ifaces" name="ob-dst_ifaces" value="">
                    <button type="button" class="set-picker-trigger js-set-picker-open"
                        data-placeholder="Any (select interface sets…)">
                        <span class="js-set-picker-label">Any (select interface sets…)</span>
                    </button>
                    <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
            </label>
            <label>Destination IP
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="address" data-max-select="20">
                    <input type="hidden" id="ob-dst_ips" name="ob-dst_ips" value="">
                    <button type="button" class="set-picker-trigger js-set-picker-open"
                        data-placeholder="Any (select address sets…)">
                        <span class="js-set-picker-label">Any (select address sets…)</span>
                    </button>
                    <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
            </label>
        </div>
        <div class="std-flex-row">
            <label>Protocol
                <select id="ob-protocol" name="ob-protocol">
                    <option value="">Any</option>
                    <option value="tcp">TCP</option>
                    <option value="udp">UDP</option>
                </select>
            </label>
            <label>Comment
                <input type="text" name="comment" id="ob-comment" maxlength="128">
            </label>
            <label class="inline-flex-center">
                <input type="checkbox" name="enabled" value="1" checked>
                &nbsp;Enabled
            </label>
        </div>
        <div class="std-flex-row">
            <button type="submit" class="std-btn js-submit-btn">Create</button>
            <button type="button" class="std-btn" data-js="nat-ob-cancel">Cancel</button>
        </div>
    </form>
</template>

<template id="tmpl-nat-sn-form">
    <form id="nat-sn-form" class="std-form">
        <div class="std-flex-row">
            <div class="std-note">Static NAT (1:1) maps one public IP to one private IP. This form separates the DNAT (prerouting) pair and the SNAT (postrouting) pair so you can set the match and the target explicitly.</div>
        </div>
        <div class="std-flex-row">
            <label>Name <span class="fw-required-star">*</span>
                <input type="text" name="name" id="sn-name" required maxlength="64" placeholder="E.g.: Server 1:1 NAT">
            </label>
            <label>Family <span class="fw-required-star">*</span>
                <select id="sn-family" name="sn-family">
                    <option value="ip">IPv4</option>
                    <option value="ip6">IPv6</option>
                </select>
            </label>
        </div>
        <fieldset class="std-fieldset"><legend>DNAT (Prerouting)</legend>
            <div class="std-flex-row">
                <label>Public IP (match destination) <span class="fw-required-star">*</span>
                    <div class="set-picker-field" data-js="set-picker-field"
                        data-set-type="address" data-filter-scope="host">
                        <input type="hidden" id="sn-dst_ips" name="sn-dst_ips" value="">
                        <button type="button" class="set-picker-trigger js-set-picker-open"
                            data-placeholder="Select public IP…">
                            <span class="js-set-picker-label">Select public IP…</span>
                        </button>
                        <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                    <small>Select the public host IP to match (used for DNAT).</small>
                </label>
                <label>Private IP (target) <span class="fw-required-star">*</span>
                    <div class="set-picker-field" data-js="set-picker-field"
                        data-set-type="address" data-filter-scope="host">
                        <input type="hidden" id="sn-to_private_set" name="sn-to_private_set" value="">
                        <button type="button" class="set-picker-trigger js-set-picker-open"
                            data-placeholder="Select private IP…">
                            <span class="js-set-picker-label">Select private IP…</span>
                        </button>
                        <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                    <small>Select the internal (private) host IP to DNAT to.</small>
                </label>
            </div>
        </fieldset>
        <fieldset class="std-fieldset"><legend>SNAT (Postrouting)</legend>
            <div class="std-flex-row">
                <label>Private IP (match source) <span class="fw-required-star">*</span>
                    <div class="set-picker-field" data-js="set-picker-field"
                        data-set-type="address" data-filter-scope="host">
                        <input type="hidden" id="sn-src_ips" name="sn-src_ips" value="">
                        <button type="button" class="set-picker-trigger js-set-picker-open"
                            data-placeholder="Select private IP…">
                            <span class="js-set-picker-label">Select private IP…</span>
                        </button>
                        <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                    <small>Select the internal (private) host IP to match (used for SNAT).</small>
                </label>
                <label>Public IP (egress target) <span class="fw-required-star">*</span>
                    <div class="set-picker-field" data-js="set-picker-field"
                        data-set-type="address" data-filter-scope="host">
                        <input type="hidden" id="sn-to_public_set" name="sn-to_public_set" value="">
                        <button type="button" class="set-picker-trigger js-set-picker-open"
                            data-placeholder="Select public IP…">
                            <span class="js-set-picker-label">Select public IP…</span>
                        </button>
                        <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                    <small>Select the public host IP to SNAT to.</small>
                </label>
            </div>
        </fieldset>
        <div class="std-flex-row">
            <label>Incoming interface (WAN)
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="interfaces">
                    <input type="hidden" id="sn-src_ifaces" name="sn-src_ifaces" value="">
                    <button type="button" class="set-picker-trigger js-set-picker-open"
                        data-placeholder="Any (select interface sets…)">
                        <span class="js-set-picker-label">Any (select interface sets…)</span>
                    </button>
                    <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
            </label>
            <label>Outgoing interface (LAN)
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="interfaces">
                    <input type="hidden" id="sn-dst_ifaces" name="sn-dst_ifaces" value="">
                    <button type="button" class="set-picker-trigger js-set-picker-open"
                        data-placeholder="Any (select interface sets…)">
                        <span class="js-set-picker-label">Any (select interface sets…)</span>
                    </button>
                    <button type="button" class="set-picker-clear js-set-picker-clear sets-hidden"
                        title="Clear selection">&#215;</button>
                </div>
            </label>
            <label>Protocol
                <select id="sn-protocol" name="sn-protocol">
                    <option value="">Any</option>
                    <option value="tcp">TCP</option>
                    <option value="udp">UDP</option>
                </select>
            </label>
        </div>
        <div class="std-flex-row">
            <label class="inline-flex-center">
                <input type="checkbox" name="enabled" value="1" checked>
                &nbsp;Enabled
            </label>
        </div>
        <div class="std-flex-row">
            <button type="submit" class="std-btn">Create</button>
            <button type="button" class="std-btn" data-js="nat-sn-cancel">Cancel</button>
        </div>
    </form>
</template>
