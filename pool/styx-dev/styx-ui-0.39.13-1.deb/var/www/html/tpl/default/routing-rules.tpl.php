<?php

/**
 * TemplateService->getTpl()
 *
 * @var array<mixed> $tdata
 * js: scripts/network/net-routing-rules.js
 *
 * Route rules come with _display fields already resolved by the gateway.
 * Form pickers (sets, labels, routing tables) fetch their own data on demand.
 */

// ─────────────────────────────────────────────────────────────────────────────
// PROTOCOLS (static lookup)
// ─────────────────────────────────────────────────────────────────────────────

$rules = $tdata['page_data']['rules'] ?? [];
$protocols = $tdata['page_data']['protocols'] ?? [];
$rules_count = $tdata['page_data']['rules_count'];

?>

<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <div class="rr-root">
        <h1>Network Route Rules</h1>
        <div class="content-box" style="display:flex; flex-direction:column; gap:1.5rem;">
            <!-- ══ Route Rules table ══ -->
            <div class="card rr-card">
                <div class="card-header">
                    <h2 class="card-heading">Route Rules</h2>
                        <span class="std-badge std-badge--chain"><?= $rules_count ?> rules</span>
                    </div>
                    <div class="card-body card-body--flush">
                        <table class="std-table rr-table">
                            <thead>
                                <tr>
                                    <th>Priority</th>
                                    <th>UUID</th>
                                    <th>Name</th>
                                    <th>NOT</th>
                                    <th>Mark</th>
                                    <th>Src IP</th>
                                    <th>Dst IP</th>
                                    <th>Interface</th>
                                    <th>Proto</th>
                                    <th>Src Port</th>
                                    <th>Dst Port</th>
                                    <th>Action</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rules ?? [] as $rule):
                                    $md = $rule['mark_display'] ?? null;
                                    $sd = $rule['src_display'] ?? null;
                                    $dd = $rule['dst_display'] ?? null;
                                    $id = $rule['iif_display'] ?? null;
                                    $sp = $rule['sport_display'] ?? null;
                                    $dp = $rule['dport_display'] ?? null;
                                    $td = $rule['table_display'] ?? null;
                                ?>
                                <tr>
                                    <td>
                                        <span class="std-badge std-badge--priority"><?= $rule['priority'] ?></span>
                                    </td>
                                    <td>
                                        <span title="Click to copy UUID" data-rr-copy="<?= $rule['uuid'] ?>">
                                            <span class="std-badge std-badge--uuid"><?= substr($rule['uuid'], 0, 8) ?></span>
                                        </span>
                                    </td>
                                    <td style="font-weight:600; color:var(--rr-bright);">
                                        <?= $rule['name'] ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($rule['invert'])): ?>
                                            <span class="std-badge std-badge--invert">NOT</span>
                                        <?php else: ?>
                                            <span class="rr-dim">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($md): ?>
                                            <span class="std-badge std-badge--mark" title="value: <?= $md['value'] ?>">
                                                <?= $md['name'] ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="rr-dim">any</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($sd): ?>
                                            <span class="rr-set-ref" title="<?= $sd['id'] ?>">
                                                <span class="rr-set-type"><?= $sd['category'] ?></span>
                                                <span><?= $sd['name'] ?> (<?= $sd['value'] ?>)</span>
                                            </span>
                                        <?php else: ?>
                                            <span class="rr-dim">any</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($dd): ?>
                                            <span class="rr-set-ref" title="<?= $dd['id'] ?>">
                                                <span class="rr-set-type"><?= $dd['category'] ?></span>
                                                <span><?= $dd['name'] ?> (<?= $dd['value'] ?>)</span>
                                            </span>
                                        <?php else: ?>
                                            <span class="rr-dim">any</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($id): ?>
                                            <span class="rr-set-ref" title="<?= $id['id'] ?>">
                                                <span class="rr-set-type">iface</span>
                                                <span><?= $id['value'] ?></span>
                                            </span>
                                        <?php else: ?>
                                            <span class="rr-dim">any</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($rule['proto']): ?>
                                            <span class="std-badge std-badge--proto"><?= strtoupper($rule['proto']) ?></span>
                                        <?php else: ?>
                                            <span class="rr-dim">any</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($sp): ?>
                                            <span class="rr-set-ref">
                                                <span class="rr-set-type">port</span>
                                                <span><?= $sp['name'] ?> (<?= $sp['value'] ?>)</span>
                                            </span>
                                        <?php else: ?>
                                            <span class="rr-dim">any</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($dp): ?>
                                            <span class="rr-set-ref">
                                                <span class="rr-set-type">port</span>
                                                <span><?= $dp['name'] ?> (<?= $dp['value'] ?>)</span>
                                            </span>
                                        <?php else: ?>
                                            <span class="rr-dim">any</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($rule['action'] === 'lookup' && $td): ?>
                                            <span class="std-badge std-badge--action-lookup">
                                                lookup <?= $td['name'] ?>
                                            </span>
                                        <?php elseif ($rule['action'] === 'lookup'): ?>
                                            <span class="std-badge std-badge--action-lookup">
                                                lookup <?= $rule['table'] ?? '?' ?>
                                            </span>
                                        <?php elseif ($rule['action'] === 'unreachable'): ?>
                                            <span class="std-badge std-badge--action-block">unreachable</span>
                                        <?php else: ?>
                                            <span class="std-badge std-badge--chain"><?= $rule['action'] ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($rule['active']): ?>
                                            <span class="std-badge std-badge--active">
                                                <span class="rr-dot on"></span>Active
                                            </span>
                                        <?php else: ?>
                                            <span class="std-badge std-badge--inactive">
                                                <span class="rr-dot off"></span>Inactive
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="rr-btn-group">
                                            <button class="rr-btn rr-btn-warning rr-btn-sm rr-edit std-btn"
                                                data-id="<?= $rule['uuid'] ?>">Edit</button>
                                            <button class="rr-btn rr-btn-danger rr-btn-sm rr-delete std-btn"
                                                data-id="<?= $rule['uuid'] ?>">Delete</button>
                                            <button class="rr-btn rr-btn-sm rr-toggle <?= $rule['active'] ? 'rr-btn-toggle-on' : 'rr-btn-toggle-off' ?> std-btn"
                                                data-id="<?= $rule['uuid'] ?>"
                                                data-active="<?= $rule['active'] ? '1' : '0' ?>">
                                            <?= $rule['active'] ? 'Deactivate' : 'Activate' ?>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <!-- ══ Add Rule Form ══ -->
            <div class="card rr-card">
                <div class="card-header">
                    <h2 class="card-heading">Add Route Rule</h2>
                </div>
                <div class="card-body std-form">

                        <!-- Row 1: name, priority, state -->
                        <div class="rr-form-row" style="margin-bottom:1.1rem;">
                            <div class="rr-col">
                                <label class="rr-label" for="rr_name">Rule name
                                    <span class="js-info-icon" data-info-modal="help-rr-rule-name"></span>
                                </label>
                                <input type="text" class="rr-input" id="rr_name"
                                       placeholder="e.g. LAN via Table 100" required>
                            </div>
                            <div class="rr-col" style="max-width:130px;">
                                <label class="rr-label">Priority
                                    <span class="js-info-icon" data-info-modal="help-rr-priority"></span>
                                </label>
                                <input type="number" class="rr-input" id="rr_priority"
                                       placeholder="auto" min="0" max="32767">
                            </div>
                            <div class="rr-col" style="max-width:150px;">
                                <label class="rr-label">Initial state
                                    <span class="js-info-icon" data-info-modal="help-rr-initial-state"></span>
                                </label>
                                <select class="rr-select" id="rr_active">
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                        </div>

                        <!-- Row 2: match conditions -->
                        <div class="rr-fieldset std-fieldset">
                            <div class="rr-fieldset-legend std-fieldset-legend">
                                Match conditions — sets only, single value per field
                            </div>
                            <div class="rr-form-row">
                                <!-- fwmark -->
                                <div class="rr-col" style="max-width:140px;">
                                    <label class="rr-label">fwmark
                                        <span class="js-info-icon" data-info-modal="help-rr-fwmark"></span>
                                    </label>
                                    <div class="set-picker-field" data-js="label-picker-field" data-set-type="packet_marking" data-max-select="1">
                                        <input type="hidden" id="rr_mark" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select fwmark">
                                            <span class="js-set-picker-label">Select fwmark</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear selection">&#215;</button>
                                    </div>
                                </div>

                                <!-- Interface (picker) -->
                                <div class="rr-col">
                                    <label class="rr-label">Interface (iif)
                                        <span class="js-info-icon" data-info-modal="help-rr-interface"></span>
                                    </label>
                                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="interfaces" data-max-select="1"
                                        data-filter-type="single">
                                        <input type="hidden" id="rr_iface" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                            data-placeholder="Select interface set">
                                            <span class="js-set-picker-label">Select interface</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                            title="Clear selection">&#215;</button>
                                    </div>
                                </div>

                                <!-- From — Src IP (picker, mutually exclusive with Dst IP) -->
                                <div class="rr-col">
                                    <label class="rr-label">From — Src IP
                                        <span class="js-info-icon" data-info-modal="help-rr-src-ip"></span>
                                    </label>
                                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-max-select="1"
                                        data-filter-scope="host,network" data-filter-type="single">
                                        <input type="hidden" id="rr_src_ip" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                            data-placeholder="Select source address set">
                                            <span class="js-set-picker-label">Select source address</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                            title="Clear selection">&#215;</button>
                                    </div>
                                </div>

                                <!-- To — Dst IP (picker, mutually exclusive with Src IP) -->
                                <div class="rr-col">
                                    <label class="rr-label">To — Dst IP
                                        <span class="js-info-icon" data-info-modal="help-rr-dst-ip"></span>
                                    </label>
                                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-max-select="1"
                                        data-filter-scope="host,network" data-filter-type="single">
                                        <input type="hidden" id="rr_dst_ip" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                            data-placeholder="Select destination address set">
                                            <span class="js-set-picker-label">Select destination address</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                            title="Clear selection">&#215;</button>
                                    </div>
                                </div>

                                <!-- Protocol -->
                                <div class="rr-col" style="max-width:130px;">
                                    <label class="rr-label">Protocol
                                        <span class="js-info-icon" data-info-modal="help-rr-protocol"></span>
                                    </label>
                                    <select class="rr-select" id="rr_proto" data-rr-handler="proto">
                                        <?php foreach ($protocols as $k => $v): ?>
                                            <option value="<?= $k ?>"><?= $v ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Src port — picker (requires tcp/udp) -->
                                <div class="rr-col" id="rr_src_port_wrap">
                                    <label class="rr-label">Src port
                                        <span class="js-info-icon" data-info-modal="help-rr-src-port"></span>
                                    </label>
                                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="ports" data-max-select="1"
                                        data-filter-type="single" data-filter-scope="single">
                                        <input type="hidden" id="rr_src_port" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                            data-placeholder="Select source port set">
                                            <span class="js-set-picker-label">Select source port</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                            title="Clear selection">&#215;</button>
                                    </div>
                                </div>

                                <!-- Dst port — picker (requires tcp/udp) -->
                                <div class="rr-col" id="rr_dst_port_wrap">
                                    <label class="rr-label">Dst port
                                        <span class="js-info-icon" data-info-modal="help-rr-dst-port"></span>
                                    </label>
                                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="ports" data-max-select="1"
                                        data-filter-type="single" data-filter-scope="single">
                                        <input type="hidden" id="rr_dst_port" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                            data-placeholder="Select destination port set">
                                            <span class="js-set-picker-label">Select destination port</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                            title="Clear selection">&#215;</button>
                                    </div>
                                </div>

                                <!-- Invert (NOT) moved from legend into the form row to avoid overlap -->
                                <div class="rr-col" style="max-width:160px; display:flex; align-items:center;">
                                    <label class="rr-invert-label" style="margin:0;">
                                        <input type="checkbox" id="rr_invert" data-rr-preview>
                                        <span style="margin-left:8px;">Invert (NOT)</span>
                                        <span class="js-info-icon" data-info-modal="help-rr-invert" style="margin-left:6px;"></span>
                                    </label>
                                </div>

                            </div>
                        </div>

                        <!-- Row 3: action -->
                        <div class="rr-fieldset std-fieldset" style="margin-top:.9rem;">
                            <div class="rr-fieldset-legend std-fieldset-legend">Action</div>
                            <div class="rr-form-row" style="align-items:flex-start;">
                                <div class="rr-col" style="max-width:180px;">
                                    <label class="rr-label">Action type
                                        <span class="js-info-icon" data-info-modal="help-rr-action-type"></span>
                                    </label>
                                    <select class="rr-select" id="rr_action" data-rr-handler="toggleLookup">
                                        <option value="lookup">lookup (table)</option>
                                        <option value="unreachable">unreachable</option>
                                        <option value="prohibit">prohibit</option>
                                        <option value="blackhole">blackhole</option>
                                    </select>
                                </div>
                                <div class="rr-col" style="max-width:200px;" id="rr_table_wrap">
                                    <label class="rr-label">Routing table
                                        <span class="js-info-icon-red" data-info-modal="help-rr-routing-table"></span>
                                    </label>

                                    <div class="set-picker-field" data-js="label-picker-field" data-set-type="routing_tables" data-max-select="1">
                                        <input type="hidden" id="rr_table" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select routing table">
                                            <span class="js-set-picker-label">Select routing table</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear selection">&#215;</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Expression preview -->
                        <div class="rr-preview" style="margin-top:1rem; padding:0.7rem; background:var(--bg-secondary); border-radius:4px; font-family:monospace; font-size:0.9rem;">
                            <strong style="display:block; margin-bottom:0.3rem; font-size:0.8rem; color:var(--text-muted);">ip rule preview</strong>
                            <code id="rr_preview" style="color:var(--rr-bright);"></code>
                        </div>

                        <div style="display:flex; justify-content:flex-end; margin-top:0.7rem;">
                            <button type="button" class="rr-btn rr-btn-success std-btn" data-rr-submit>
                                <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
                                    <path d="M3 8l4 4 6-6" stroke="currentColor" stroke-width="2"
                                          stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                Add Rule
                            </button>
                        </div>

                </div>
            </div>

        </div><!-- .content-box -->
        </div><!-- .rr-root -->
    </main>
</div>

<!-- Help blocks for Route Rules form (referenced by data-info-modal) -->
<div id="help-rr-rule-name" style="display:none">
    <p><strong>Rule name</strong>: Short descriptive name for the routing rule.</p>
</div>
<div id="help-rr-priority" style="display:none">
    <p><strong>Priority</strong>: Numeric priority for the rule (lower values match first).</p>
</div>
<div id="help-rr-initial-state" style="display:none">
    <p><strong>Initial state</strong>: Whether the rule is active after creation.</p>
</div>
<div id="help-rr-fwmark" style="display:none">
    <p><strong>fwmark</strong>: Match packets with this firewall mark (fwmark).</p>
</div>
<div id="help-rr-interface" style="display:none">
    <p><strong>Interface</strong>: Match packets arriving on (iif) the selected interface.</p>
</div>
<div id="help-rr-src-ip" style="display:none">
    <p><strong>From — Src IP</strong>: Match source IP (single value).</p>
</div>
<div id="help-rr-dst-ip" style="display:none">
    <p><strong>To — Dst IP</strong>: Match destination IP (single value).</p>
</div>
<div id="help-rr-protocol" style="display:none">
    <p><strong>Protocol</strong>: Protocol to match (TCP/UDP/ICMP) or Any.</p>
</div>
<div id="help-rr-src-port" style="display:none">
    <p><strong>Src port</strong>: Match source port (requires TCP/UDP).</p>
</div>
<div id="help-rr-dst-port" style="display:none">
    <p><strong>Dst port</strong>: Match destination port (requires TCP/UDP).</p>
</div>
<div id="help-rr-action-type" style="display:none">
    <p><strong>Action type</strong>: What action to perform (lookup table, unreachable, etc.).</p>
</div>
<div id="help-rr-routing-table" style="display:none">
    <p><strong>Routing table</strong>: Which routing table to lookup when action is <em>lookup</em>.</p>
</div>
<div id="help-rr-invert" style="display:none">
    <p><strong>Invert (NOT)</strong>: When enabled, the rule matches when the conditions are <strong>not</strong> met.</p>
    <p>Example: <code>not fwmark 10 from 192.168.1.0/24 lookup 100</code> matches all packets <em>except</em> those with fwmark 10 from 192.168.1.0/24.</p>
</div>
