<?php
$h_menu = $data['head_menu'] ?? ($tdata['tpl_data']['head_menu'] ?? []);
$pong = $data['pong_gateway'] ?? ($tdata['tpl_data']['pong_gateway'] ?? []);
$notifications = $data['notifications'] ?? ($tdata['tpl_data']['notifications'] ?? []);
$config_changed = (bool)($data['config_changed'] ?? ($tdata['tpl_data']['config_changed'] ?? false));
$restart_required = (bool)($data['restart_required'] ?? ($tdata['tpl_data']['restart_required'] ?? false));
$show_banner = $config_changed || $restart_required;
?>
<?php if ($show_banner): ?>
<div class="config-change-banner" id="config-change-banner"
     data-config-changed="<?= $config_changed ? '1' : '0' ?>"
     data-restart-required="<?= $restart_required ? '1' : '0' ?>">
<?php if ($config_changed): ?>
    <div class="banner-section" id="banner-section-config">
        <div class="banner-section-msg">
            <span class="config-change-icon">&#9888;</span>
            Unsaved configuration changes. Modifications are applied to the running system but have not been saved permanently.
        </div>
        <div class="banner-section-actions">
            <button class="config-change-diff-btn" id="config-change-diff" type="button">View Changes</button>
            <button class="config-change-save-btn" id="config-change-save" type="button">Save</button>
        </div>
    </div>
<?php endif; ?>
<?php if ($restart_required): ?>
    <div class="banner-section" id="banner-section-restart">
        <div class="banner-section-msg">
            <span class="config-change-icon">&#9888;</span>
            Gateway restart required. A software update has been applied — restart the service to apply changes.
        </div>
        <div class="banner-section-actions">
            <button class="config-change-restart-btn" id="config-change-restart" type="button">Restart Gateway</button>
        </div>
    </div>
<?php endif; ?>
</div>
<?php endif; ?>
<div class="header-simple">
    <div class="header-left">
        <div class="header-logo">
            <a href="?page=index">
                <img src="/img/logo.png" alt="Logo"/>
            </a>
            <div class="web-legend"><?= $h_menu['web_legend'] ?></div>
        </div>
        <!--
        <div class="header-title">
            <a href="?page=index"><?= $h_menu['web_name'] ?></a>
        </div>
        -->
    </div>
    <div class="header-right">
        <div class="notif-wrap">
            <span class="notif-icon" id="notif-bell" tabindex="0">
                <svg class="notif-bell-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="25" height="25" aria-hidden="true" focusable="false">
                    <path d="M12 3a7 7 0 0 1 7 7v4c0 .44.24.85.62 1.06l1.36.75a1 1 0 0 1-.58 1.87H3.6a1 1 0 0 1-.58-1.87l1.36-.75A1 1 0 0 0 5 14V10a7 7 0 0 1 7-7zm0 18a2.5 2.5 0 0 0 2.5-2.5h-5A2.5 2.5 0 0 0 12 21z" fill="#2a7ae2" stroke="#222" stroke-width="1.2"/>
                </svg>
                <!-- Badge rendered by JS -->
            </span>
            <div class="notif-dropdown" id="notif-dropdown">
                <div class="notif-dropdown-title">Notifications</div>
                <!-- Notifications rendered by JS -->
            </div>
        </div>
        <span id="cpu_status" class="led-load" title="load"></span>
        <span id="gateway_status" class="<?= $pong['status'] . ' ' . $pong['blink'] ?> led-gateway"
            title="Gw Version <?= $pong['version'] ?? '' ?> Latency: <?= $pong['latency'] ??'' ?>"></span>
    </div>
</div>
<div id="fixed-panel">
    <div id="panel-scroll">
        <table id="tasks-table">
            <thead>
                <tr>
                    <th>Func</th>
                    <th>Command</th>
                    <th>Status</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>ID</th>
                    <th>Message</th>
                </tr>
            </thead>
            <tbody id="tasks-tbody">
                <!-- Tasks (JS) -->
            </tbody>
        </table>
    </div>
</div>
<div id="top-panel-btn">TASKS</div>
