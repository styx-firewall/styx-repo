<?php
/**
 * eBPF fragment: module list (instances + available) and toolbar.
 *
 * @var array $tdata  — $tdata['tpl_data'] contains the full formatted page data
 */
$pd = $tdata['tpl_data'] ?? [];
?>

<!-- TOOLBAR -->
<div class="ebpf-toolbar">
    <input type="text" id="ebpf-search" class="ebpf-input ebpf-search-inline"
           placeholder="Search modules by name, tags, hook type...">
    <button id="ebpf-refresh-btn" class="std-btn" type="button">&#8635; Refresh</button>
    <button id="ebpf-rescan-btn" class="std-btn" type="button">🔍 Rescan</button>
    <span class="ebpf-counts">
        Styx: <b><?= (int)($pd['styx_count'] ?? 0) ?></b>
        &nbsp;|&nbsp; Kernel: <b><?= (int)($pd['kernel_count'] ?? 0) ?></b>
    </span>
</div>

<!-- LIST VIEW -->
<div id="ebpf-list-view">
    <div class="ebpf-section">
        <div class="ebpf-section-header">
            <span class="ebpf-section-title">Managed by Styx</span>
        </div>
        <table id="ebpf-module-list" class="ebpf-module-table">
            <thead>
                <tr>
                    <th>Module</th><th>Status</th><th>Type</th><th>Hook</th>
                    <th>Interface</th><th>Autoload</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pd['instances_rows'] ?? [] as $row): ?>
                <tr class="ebpf-module-row"
                    data-module="<?= htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') ?>"
                    data-instance-id="<?= htmlspecialchars((string)($row['instance_id'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                    data-status="<?= $row['status'] ?>"
                    data-attach-target="<?= $row['attach_target'] ?>"
                    data-version="<?= htmlspecialchars($row['version'], ENT_QUOTES, 'UTF-8') ?>"
                    data-hook-type="<?= htmlspecialchars($row['hook_type'], ENT_QUOTES, 'UTF-8') ?>"
                    data-interface="<?= htmlspecialchars($row['interface'], ENT_QUOTES, 'UTF-8') ?>"
                    data-mode="<?= htmlspecialchars($row['mode'], ENT_QUOTES, 'UTF-8') ?>"
                    data-pre-attach-params="<?= htmlspecialchars(json_encode($row['pre_attach_params'] ?? []), ENT_QUOTES, 'UTF-8') ?>">
                    <td>
                        <b><?= htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') ?></b>
                        <span class="ebpf-version-tag">v<?= htmlspecialchars($row['version'], ENT_QUOTES, 'UTF-8') ?></span>
                        <?= $row['uuid_html'] ?>
                    </td>
                    <td><?= $row['status_html'] ?></td>
                    <td><?= $row['type_html'] ?></td>
                    <td><span class="ebpf-info-tag"><?= htmlspecialchars($row['hook_type'], ENT_QUOTES, 'UTF-8') ?></span></td>
                    <td><?= htmlspecialchars($row['interface'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td>
                        <?php if ($row['has_autoload']): ?>
                        <input type="checkbox" class="ebpf-autoload-toggle"
                               data-uuid="<?= htmlspecialchars((string)$row['instance_id'], ENT_QUOTES, 'UTF-8') ?>"
                               <?= $row['autoload_attr'] ?>>
                        <?php else: ?>—<?php endif; ?>
                    </td>
                    <td>
                        <?php if ($row['status'] === 'inactive' || $row['status'] === 'suspended'): ?>
                        <button class="std-btn ebpf-btn-action ebpf-activate-btn-js"
                                data-uuid="<?= htmlspecialchars((string)$row['instance_id'], ENT_QUOTES, 'UTF-8') ?>">Activate</button>
                        <?php endif; ?>
                        <button class="std-btn ebpf-info-btn"
                                data-identifier="<?= htmlspecialchars($row['instance_id'] ?: $row['name'], ENT_QUOTES, 'UTF-8') ?>"
                                data-is-instance="<?= $row['instance_id'] ? '1' : '0' ?>">Info</button>
                    </td>
                </tr>
                <?php endforeach; ?>

                <?php if (!empty($pd['available_rows'])): ?>
                <tr class="ebpf-section-separator"><td colspan="7">Available to load</td></tr>
                <?php endif; ?>

                <?php foreach ($pd['available_rows'] ?? [] as $row): ?>
                <tr class="ebpf-module-row"
                    data-module="<?= htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') ?>"
                    data-instance-id=""
                    data-status="<?= $row['status'] ?>"
                    data-attach-target="<?= $row['attach_target'] ?>"
                    data-version="<?= htmlspecialchars($row['version'], ENT_QUOTES, 'UTF-8') ?>"
                    data-hook-type="<?= htmlspecialchars($row['hook_type'], ENT_QUOTES, 'UTF-8') ?>"
                    data-mode="<?= htmlspecialchars($row['mode'], ENT_QUOTES, 'UTF-8') ?>"
                    data-pre-attach-params="<?= htmlspecialchars(json_encode($row['pre_attach_params'] ?? []), ENT_QUOTES, 'UTF-8') ?>">
                    <td>
                        <b><?= htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') ?></b>
                        <span class="ebpf-version-tag">v<?= htmlspecialchars($row['version'], ENT_QUOTES, 'UTF-8') ?></span>
                    </td>
                    <td><?= $row['status_html'] ?></td>
                    <td><?= $row['type_html'] ?></td>
                    <td><span class="ebpf-info-tag"><?= htmlspecialchars($row['hook_type'], ENT_QUOTES, 'UTF-8') ?></span></td>
                    <td>—</td><td>—</td>
                    <td>
                        <button class="std-btn ebpf-info-btn"
                                data-identifier="<?= htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') ?>"
                                data-is-instance="0">Info</button>
                        <?php if ($row['status'] !== 'incompatible'): ?>
                        <button class="std-btn ebpf-btn-action ebpf-load-btn-js"
                                data-module="<?= htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') ?>">Load</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
