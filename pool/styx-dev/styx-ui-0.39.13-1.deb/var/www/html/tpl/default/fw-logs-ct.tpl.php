<?php
/**
 * Conntrack Flow Logs
 * @var array<mixed> $tdata
 * fw-logs-ct.js
 */
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Connection Logs (Conntrack)</h1>
        <div class="fw-logs-toolbar">
            <button id="ct-logs-toggle-autorefresh" class="std-btn btn-pad">Pause Auto-refresh</button>
            <label class="fw-logs-interval-label">
                Refresh interval (s):
                <input
                    type="number"
                    id="ct-logs-refresh-interval"
                    min="2"
                    step="1"
                    value="20"
                    class="fw-logs-interval-input"
                    size="4"
                    style="width:6ch;"
                >
            </label>
        </div>
        <div class="content-box">
            <form id="ct-logs-filters-form" class="log-filters-form">
                <label>
                    Limit:
                    <input
                        type="number"
                        id="ct-logs-limit"
                        min="10"
                        max="1000"
                        step="10"
                        value="20"
                        class="log-limit"
                    >
                </label>
                <input
                    type="text"
                    id="ct-logs-query"
                    class="fw-query-input"
                    placeholder='e.g. ct.event == "destroy" AND dest_port == 443'
                    autocomplete="off"
                >
                <button type="button" class="std-btn btn-pad js-ct-query-help">Keys &#9660;</button>
                <button type="submit" class="std-btn btn-pad">Apply</button>
            </form>
            <div id="ct-query-keys" class="fw-query-keys" hidden></div>
            <div id="column-controls-ct"></div>
            <table class="std-table" id="dynamic-table-ct"></table>
        </div>
    </main>
</div>

<!-- Flow detail modal template -->
<template id="ct-flow-modal-tpl">
    <h2 class="fwlog-modal-title">Flow Details</h2>

    <table class="fwlog-modal-table"><tbody>
    <tr>
        <td class="fwlog-key">timestamp_iso</td><td class="fwlog-value" data-field="timestamp_iso"></td>
        <td class="fwlog-key">event_type</td><td class="fwlog-value" data-field="event_type"></td>
        <td class="fwlog-key">protocol</td><td class="fwlog-value" data-field="protocol"></td>
        <td class="fwlog-key">protocol_num</td><td class="fwlog-value" data-field="protocol_num"></td>
        <td class="fwlog-key">flow_id</td><td class="fwlog-value" data-field="flow_id"></td>
    </tr>
    <tr>
        <td class="fwlog-key">ct.id</td><td class="fwlog-value" data-field="ct.id"></td>
        <td class="fwlog-key">ct.event</td><td class="fwlog-value" data-field="ct.event"></td>
        <td class="fwlog-key">ct.mark</td><td class="fwlog-value" data-field="ct.mark"></td>
    </tr>
    </tbody></table>

    <div class="ct-flow-cols">
        <div class="ct-flow-col">
            <h3 class="ct-flow-hdr">Orig (Initiator → Responder)</h3>
            <table class="fwlog-modal-table"><tbody>
            <tr><td class="fwlog-key">src_ip</td><td class="fwlog-value" data-field="orig.src_ip"></td></tr>
            <tr><td class="fwlog-key">src_hostname</td><td class="fwlog-value" data-field="orig.src_hostname"></td></tr>
            <tr><td class="fwlog-key">src_custom_name</td><td class="fwlog-value" data-field="orig.src_custom_name"></td></tr>
            <tr><td class="fwlog-key">dest_ip</td><td class="fwlog-value" data-field="orig.dest_ip"></td></tr>
            <tr><td class="fwlog-key">dest_hostname</td><td class="fwlog-value" data-field="orig.dest_hostname"></td></tr>
            <tr><td class="fwlog-key">dest_custom_name</td><td class="fwlog-value" data-field="orig.dest_custom_name"></td></tr>
            <tr><td class="fwlog-key">src_port</td><td class="fwlog-value" data-field="orig.src_port"></td></tr>
            <tr><td class="fwlog-key">dest_port</td><td class="fwlog-value" data-field="orig.dest_port"></td></tr>
            <tr><td class="fwlog-key">bytes</td><td class="fwlog-value" data-field="orig.bytes"></td></tr>
            <tr><td class="fwlog-key">packets</td><td class="fwlog-value" data-field="orig.packets"></td></tr>
            </tbody></table>
        </div>
        <div class="ct-flow-col">
            <h3 class="ct-flow-hdr">Reply (Responder → Initiator)</h3>
            <table class="fwlog-modal-table"><tbody>
            <tr><td class="fwlog-key">src_ip</td><td class="fwlog-value" data-field="reply.src_ip"></td></tr>
            <tr><td class="fwlog-key">src_hostname</td><td class="fwlog-value" data-field="reply.src_hostname"></td></tr>
            <tr><td class="fwlog-key">src_custom_name</td><td class="fwlog-value" data-field="reply.src_custom_name"></td></tr>
            <tr><td class="fwlog-key">dest_ip</td><td class="fwlog-value" data-field="reply.dest_ip"></td></tr>
            <tr><td class="fwlog-key">dest_hostname</td><td class="fwlog-value" data-field="reply.dest_hostname"></td></tr>
            <tr><td class="fwlog-key">dest_custom_name</td><td class="fwlog-value" data-field="reply.dest_custom_name"></td></tr>
            <tr><td class="fwlog-key">src_port</td><td class="fwlog-value" data-field="reply.src_port"></td></tr>
            <tr><td class="fwlog-key">dest_port</td><td class="fwlog-value" data-field="reply.dest_port"></td></tr>
            <tr><td class="fwlog-key">bytes</td><td class="fwlog-value" data-field="reply.bytes"></td></tr>
            <tr><td class="fwlog-key">packets</td><td class="fwlog-value" data-field="reply.packets"></td></tr>
            </tbody></table>
        </div>
    </div>

    <h3 class="ct-flow-hdr">Timing</h3>
    <table class="fwlog-modal-table"><tbody>
    <tr><td class="fwlog-key">start</td><td class="fwlog-value" data-field="flow.start"></td></tr>
    <tr><td class="fwlog-key">end</td><td class="fwlog-value" data-field="flow.end"></td></tr>
    <tr><td class="fwlog-key">duration</td><td class="fwlog-value" data-field="flow.duration"></td></tr>
    </tbody></table>

    <div data-section="icmp" hidden>
        <h3 class="ct-flow-hdr">ICMP</h3>
        <table class="fwlog-modal-table"><tbody>
        <tr><td class="fwlog-key">type</td><td class="fwlog-value" data-field="icmp.type"></td>
        <td class="fwlog-key">code</td><td class="fwlog-value" data-field="icmp.code"></td></tr>
        </tbody></table>
    </div>

    <div data-section="oob" hidden>
        <h3 class="ct-flow-hdr">OOB</h3>
        <table class="fwlog-modal-table"><tbody>
        <tr><td class="fwlog-key">family</td><td class="fwlog-value" data-field="oob.family"></td>
        <td class="fwlog-key">protocol</td><td class="fwlog-value" data-field="oob.protocol"></td></tr>
        </tbody></table>
    </div>
</template>

<script>
// Server-provided columns configuration
window.__ctLogsColumns = <?php
echo $tdata['page_data']['ct_logs_columns_json'];
?>;
</script>
