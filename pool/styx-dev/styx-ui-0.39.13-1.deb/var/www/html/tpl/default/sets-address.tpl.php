<?php
/**
 * Fragment: Address objects — unified panel.
 * mode=mgmt   : accordion panel on Objects page (headings + text filter)
 * mode=picker : selection modal — CRUD available + checkbox column + confirm button
 * Expects $tdata['tpl_data']['address_sets'], $tdata['tpl_data']['mode']
 */
$address_sets = $tdata['tpl_data']['address_sets'] ?? [];
$address_scopes = $tdata['tpl_data']['address_scopes'] ?? [];
$mode = $tdata['tpl_data']['mode'] ?? 'picker';
?>
<?php if ($mode === 'mgmt'): ?>
<h2>Address Objects</h2>
<?php endif; ?>
<form id="address-object-form" class="std-form" autocomplete="off">
    <input type="hidden" name="id" id="address_id" value="">
    <div class="std-flex-row">
        <label>Type*
            <span class="js-info-icon" data-info-modal="help-addr-type"></span>
            <select name="type" required>
                <option value="single">Single</option>
                <option value="range">Range</option>
                <option value="set">IP Set</option>
            </select>
        </label>
        <label>Family*
            <span class="js-info-icon" data-info-modal="help-addr-family"></span>
            <select name="set_family" required>
                <option value="ip">IPv4</option>
                <option value="ip6">IPv6</option>
            </select>
        </label>
        <label>Name*
            <span class="js-info-icon" data-info-modal="help-addr-name"></span>
            <input type="text" name="name" required maxlength="32" placeholder="Unique name">
        </label>
        <label>Description
            <span class="js-info-icon" data-info-modal="help-addr-description"></span>
            <input type="text" name="description" maxlength="64" placeholder="Optional">
        </label>
        <label>Tags
            <span class="js-info-icon" data-info-modal="help-addr-tags"></span>
            <input type="text" name="tags" placeholder="Tags separated by spaces or commas">
        </label>
    </div>

    <div class="std-flex-row value-row value-row-single">
        <label>IP or CIDR*
            <span class="js-info-icon" data-info-modal="help-addr-value-single"></span>
            <input type="text" name="value_single" placeholder="E.g.: 192.168.1.1 or 10.0.0.0/24">
        </label>
    </div>

    <div class="std-flex-row value-row value-row-range sets-hidden">
        <label>Range*
            <span class="js-info-icon" data-info-modal="help-addr-value-range"></span>
            <input type="text" name="value_range_start" placeholder="Start">
            <input type="text" name="value_range_end" placeholder="End">
        </label>
    </div>

    <div class="std-flex-row value-row value-row-set sets-hidden">
        <label>Set*
            <span class="js-info-icon" data-info-modal="help-addr-value-set"></span>
            <div class="set-list"></div>
            <button type="button" class="add-set-btn std-btn">Add</button>
        </label>
    </div>

    <div id="help-addr-type" style="display:none">
        <p><strong>Type</strong>: Single address, a range, or an IP set.</p>
    </div>
    <div id="help-addr-family" style="display:none">
        <p><strong>Family</strong>: IPv4 or IPv6 selection for the value.</p>
    </div>
    <div id="help-addr-name" style="display:none">
        <p><strong>Name</strong>: Unique identifier for this object.</p>
    </div>
    <div id="help-addr-description" style="display:none">
        <p><strong>Description</strong>: Optional human-readable description.</p>
    </div>
    <div id="help-addr-tags" style="display:none">
        <p><strong>Tags</strong>: Space or comma-separated tags for filtering.</p>
    </div>
    <div id="help-addr-value-single" style="display:none">
        <p><strong>IP or CIDR</strong>: Enter a single IP or CIDR range.</p>
    </div>
    <div id="help-addr-value-range" style="display:none">
        <p><strong>Range</strong>: Start and end addresses for a range.</p>
    </div>
    <div id="help-addr-value-set" style="display:none">
        <p><strong>Set</strong>: Build a set of addresses using the Add button.</p>
    </div>

    <div class="std-flex-row">
        <button type="submit" class="std-btn">Save</button>
        <button type="button" class="std-btn cancel-edit-btn sets-hidden">Cancel</button>
    </div>
</form>

<hr>
<?php if ($mode === 'mgmt'): ?>
<h3>Existing Objects</h3>
<?php endif; ?>
<?php if ($mode === 'mgmt' || $mode === 'picker'): ?>
<div class="std-flex-row filters-row">
    <label>Filter
        <input type="text" id="address-filter" class="set-filter-input" placeholder="Filter by name, value or tags">
    </label>
</div>
<?php endif; ?>
<div class="std-flex-row filters-row">
    <label>Filter Family
        <select id="filter-family" name="filter_family" class="std-select">
            <option value="">All</option>
            <option value="ip">IPv4</option>
            <option value="ip6">IPv6</option>
        </select>
    </label>
    <label>Filter Scope
        <select id="filter-scope" name="filter_scope" class="std-select"
            <?php if ($mode === 'picker'): ?>multiple size="4" style="height:auto;"<?php endif; ?>>
            <?php if ($mode !== 'picker'): ?>
                <option value="">All</option>
            <?php endif; ?>
            <?php foreach ($address_scopes as $sval => $slabel): ?>
                <option value="<?= $sval ?>"><?= $slabel ?></option>
            <?php endforeach; ?>
        </select>
    </label>
</div>
<table class="std-table" id="address-table">
    <thead>
        <tr>
            <?php if ($mode === 'picker'): ?><th>Select</th><?php endif; ?>
            <th>Name</th>
            <th>Type</th>
            <th>Scope</th>
            <th>Family</th>
            <th>Value</th>
            <th>Description</th>
            <th>Tags</th>
            <th>Refs</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($address_sets as $a): ?>
            <tr>
                <?php if ($mode === 'picker'): ?>
                <td>
                    <input type="checkbox" class="js-set-pick-row"
                        value="<?= $a['id'] ?? '' ?>"
                        data-name="<?= $a['name'] ?? '' ?>">
                </td>
                <?php endif; ?>
                <td class="col-name"><?= $a['name'] ?? '' ?></td>
                <td class="col-type"><?= $a['type_display'] ?? ($a['type'] ?? '') ?></td>
                <td class="col-scope"><?= $a['scope_display'] ?? '' ?></td>
                <td class="col-family"><?= $a['family_display'] ?? ($a['family'] ?? '') ?></td>
                <td class="col-value"><?= $a['value_display'] ?? '' ?></td>
                <td class="col-description"><?= $a['description'] ?? '' ?></td>
                <td class="tags-cell col-tags"><?= $a['tags_html'] ?? '' ?></td>
                <td class="col-refs"><?= $a['refs_count'] ?? 0 ?></td>
                <td>
                    <button class="std-btn std-btn-edit"
                        data-id="<?= $a['id'] ?? '' ?>"
                        aria-label="Edit" title="Edit"></button>
                    <?php if (($a['refs_count'] ?? 0) == 0): ?>
                        <button class="std-btn std-btn-delete"
                            data-id="<?= $a['id'] ?? '' ?>"
                            aria-label="Delete" title="Delete"></button>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php if ($mode === 'picker'): ?>
<div class="js-set-picker-actions sets-hidden">
    <button type="button" class="std-btn js-set-picker-confirm">Use selected</button>
</div>
<?php endif; ?>
