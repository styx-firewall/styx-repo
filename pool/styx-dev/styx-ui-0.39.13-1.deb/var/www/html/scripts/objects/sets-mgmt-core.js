// ============================================================
// Utilities
// ============================================================

function escapeHtml(s) {
    return String(s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function parseServerResponse(resp) {
    if (!resp || typeof resp !== 'object') {
        return { success: false, msg: '' };
    }
    return {
        success: resp.status === 'success' || resp.success === true,
        msg: resp.response_msg || resp.message || '',
    };
}

// ============================================================
// DOM / form helpers
// ============================================================

// Build a removable set-input row and append it to setListEl.
function appendSetInputRow(setListEl, name, val) {
    const div = document.createElement('div');
    div.classList.add('sets-flex');
    const input = document.createElement('input');
    input.type = 'text';
    input.name = name;
    input.value = val || '';
    input.classList.add('sets-input');
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'remove-set-btn sets-remove-btn';
    removeBtn.textContent = '×';
    removeBtn.onclick = () => div.remove();
    div.appendChild(input);
    div.appendChild(removeBtn);
    setListEl.appendChild(div);
}

// Populate the set-list in a form from an array of values.
function fillSetList(form, vals) {
    const setList = form.querySelector('.set-list');
    setList.innerHTML = '';
    vals.forEach(val => appendSetInputRow(setList, 'value_set[]', val));
}

// Read a cell's text content by semantic class.
function cellText(row, className) {
    if (!row) {
        return '';
    }
    const el = row.querySelector('td.' + className);
    return el ? el.textContent.trim() : '';
}

// Read tags from a row — prefer individual .tag-chip elements, fall back to cell text.
function parseTagsFromRow(row) {
    if (!row) {
        return '';
    }
    const tagsCell = row.querySelector('.tags-cell') || row.querySelector('td.col-tags');
    if (!tagsCell) {
        return '';
    }
    const chips = tagsCell.querySelectorAll('.tag-chip');
    if (chips.length) {
        return Array.from(chips).map(c => c.textContent.trim()).filter(Boolean).join(' ');
    }
    return tagsCell.textContent.trim();
}

// Read tags from a form's tags input as an array.
function readTagsFromForm(form) {
    const el = form.querySelector('[name="tags"]');
    const raw = el ? el.value.trim() : '';
    if (!raw) {
        return [];
    }
    return raw.split(/[\s,]+/).map(s => s.trim()).filter(Boolean);
}

// Fill a form's tags input from a table row.
function fillTagsFromRow(form, row) {
    const tagsVal = parseTagsFromRow(row);
    const el = form.querySelector('[name="tags"]');
    if (el) {
        el.value = tagsVal;
    }
}

// ============================================================
// Form state management
// ============================================================

// Reset a form back to 'create' state.
function resetForm(form, config) {
    form.id.value = '';
    form.name.value = '';
    form.description.value = '';

    if (form[config.typeField]) {
        const sel = form[config.typeField];
        sel.disabled = false;
        if (sel.options && sel.options.length) {
            sel.value = sel.options[0].value;
        }
        sel.dispatchEvent(new Event('change'));
    }

    if (config.familyField && form[config.familyField]) {
        const sel = form[config.familyField];
        sel.disabled = false;
        if (sel.options && sel.options.length) {
            sel.value = sel.options[0].value;
        }
    }

    if (config.valueSingle && form[config.valueSingle]) {
        form[config.valueSingle].value = '';
    }
    if (config.valueRangeStart && form[config.valueRangeStart]) {
        form[config.valueRangeStart].value = '';
    }
    if (config.valueRangeEnd && form[config.valueRangeEnd]) {
        form[config.valueRangeEnd].value = '';
    }

    const setList = form.querySelector('.' + (config.setListClass || 'set-list'));
    if (setList) {
        setList.innerHTML = '';
    }

    const ms = form.querySelector('[name="value_set[]"]');
    if (ms && ms.options) {
        Array.from(ms.options).forEach(o => { o.selected = false; });
    }

    const tagsEl = form.querySelector('[name="tags"]');
    if (tagsEl) {
        tagsEl.value = '';
    }

    const cancelBtn = form.querySelector('.cancel-edit-btn');
    if (cancelBtn) {
        cancelBtn.classList.add('sets-hidden');
    }
}

// ============================================================
// Edit / Submit value builders per set type
// ============================================================

// Populate form inputs from a table row when entering edit mode.
function populateFormFromRow(form, type, config, row) {
    if (type === 'address' || type === 'port') {
        const rawTypeText = cellText(row, 'col-type');
        const baseType = (rawTypeText.split('(')[0].split(/\s+/)[0] || '').trim();
        form[config.typeField].value = baseType || rawTypeText;
        form[config.typeField].dispatchEvent(new Event('change'));
        form[config.typeField].disabled = true;

        if (config.familyField && form[config.familyField]) {
            const famText = type === 'address' ? cellText(row, 'col-family') : '';
            let famVal;
            if (famText === 'IPv4') {
                famVal = 'ip';
            } else if (famText === 'IPv6') {
                famVal = 'ip6';
            } else {
                famVal = famText.toLowerCase();
            }
            form[config.familyField].value = famVal;
            form[config.familyField].disabled = true;
        }

        const val = cellText(row, 'col-value');
        const currentType = form[config.typeField].value;
        if (currentType === 'single') {
            form[config.valueSingle].value = val;
        } else if (currentType === 'range') {
            const [start, end] = val.split('-').map(s => s.trim());
            form[config.valueRangeStart].value = start || '';
            form[config.valueRangeEnd].value = end || '';
        } else if (currentType === 'set') {
            fillSetList(form, val.split(',').map(s => s.trim()).filter(Boolean));
        }
    } else if (type === 'iface_set') {
        const rowType = cellText(row, 'col-type');
        form[config.typeField].value = rowType;
        form[config.typeField].dispatchEvent(new Event('change'));
        form[config.typeField].disabled = true;

        const val = cellText(row, 'col-value') || '';
        if (rowType === 'single') {
            form[config.valueSingle].value = val;
        } else if (rowType === 'set') {
            const ms = form.querySelector('[name="value_set[]"]');
            if (ms && ms.options) {
                const ifaceVals = val.split(',').map(s => s.trim()).filter(Boolean);
                Array.from(ms.options)
                    .forEach(opt => { opt.selected = ifaceVals.includes(opt.value); });
            }
        }
    } else if (type === 'domain') {
        const rowType = cellText(row, 'col-type');
        form[config.typeField].value = rowType;
        form[config.typeField].dispatchEvent(new Event('change'));
        form[config.typeField].disabled = true;

        const val = cellText(row, 'col-value');
        if (rowType === 'single') {
            form[config.valueSingle].value = val;
        } else if (rowType === 'set') {
            fillSetList(form, val.split(',').map(s => s.trim()).filter(Boolean));
        }
    }
}

// Build submit payload from form inputs. Returns { payload } or { error: string }.
function buildSubmitPayload(form, type, config) {
    const payload = {
        name: form.name.value.trim(),
        description: form.description.value.trim(),
        type: form[config.typeField].value,
    };

    if (type === 'address' || type === 'port') {
        if (payload.type === 'single') {
            payload[config.valueSingle] = form[config.valueSingle].value;
            if (type === 'address' && /:\d+$/.test(payload[config.valueSingle])) {
                return {
                    error: 'IP:PORT format (host_port scope) is not supported.'
                        + ' Use a plain IP address and a separate port set.',
                };
            }
        } else if (payload.type === 'range') {
            payload[config.valueRangeStart] = form[config.valueRangeStart].value;
            payload[config.valueRangeEnd] = form[config.valueRangeEnd].value;
        } else if (payload.type === 'set') {
            payload.value_set = Array.from(
                form.querySelectorAll("input[name='" + config.valueSetName + "']")
            ).map(i => i.value.trim()).filter(Boolean);
        }
        if (config.familyField && form[config.familyField]) {
            payload.family = form[config.familyField].value;
        }
    } else if (type === 'iface_set') {
        if (payload.type === 'single') {
            payload.value_single = form[config.valueSingle].value;
        } else if (payload.type === 'set') {
            const ms = form.querySelector('[name="value_set[]"]');
            if (ms && ms.selectedOptions) {
                payload.value_set = Array.from(ms.selectedOptions).map(o => o.value);
            }
        }
    } else if (type === 'domain') {
        if (payload.type === 'single') {
            payload.value_single = form[config.valueSingle].value;
        } else if (payload.type === 'set') {
            payload.value_set = Array.from(
                form.querySelectorAll("input[name='" + config.valueSetName + "']")
            ).map(i => i.value.trim()).filter(Boolean);
        }
    }

    const tags = readTagsFromForm(form);
    if (tags.length) {
        payload.tags = tags;
    }

    return { payload };
}

// ============================================================
// CRUD form initialization
// ============================================================

function initSetTypeForms(container, opts) {
    opts = opts || {};

    function scope(id) {
        return container === document
            ? document.getElementById(id)
            : container.querySelector('#' + CSS.escape(id));
    }

    const forms = [
        {
            formId: 'address-object-form', tableId: 'address-table', type: 'address',
            config: {
                typeField: 'type', familyField: 'set_family', setListClass: 'set-list',
                addBtnClass: 'add-set-btn', valueSetName: 'value_set[]',
                valueSingle: 'value_single', valueRangeStart: 'value_range_start',
                valueRangeEnd: 'value_range_end',
                apiCreate: 'set_address', apiEdit: 'set_address',
            },
        },
        {
            formId: 'port-object-form', tableId: 'port-table', type: 'port',
            config: {
                typeField: 'type', setListClass: 'set-list',
                addBtnClass: 'add-set-btn', valueSetName: 'value_set[]',
                valueSingle: 'value_single', valueRangeStart: 'value_range_start',
                valueRangeEnd: 'value_range_end',
                apiCreate: 'set_port', apiEdit: 'set_port',
            },
        },
        {
            formId: 'iface-set-form', tableId: 'iface-set-table', type: 'iface_set',
            config: {
                typeField: 'type', valueSingle: 'value_single', valueSetName: 'value_set[]',
                apiCreate: 'set_interface_set', apiEdit: 'set_interface_set',
            },
        },
        {
            formId: 'domain-set-form', tableId: 'domain-set-table', type: 'domain',
            config: {
                typeField: 'type', setListClass: 'set-list',
                addBtnClass: 'add-set-btn', valueSetName: 'value_set[]',
                valueSingle: 'value_single',
                apiCreate: 'set_domain', apiEdit: 'set_domain',
            },
        },
    ];

    forms.forEach(function({ formId, tableId, type, config }) {
        const form = scope(formId);
        if (!form) {
            return;
        }

        // Guard against double initialization (page mode — picker gets fresh DOM).
        if (form.dataset.jsFormInit) {
            return;
        }
        form.dataset.jsFormInit = '1';

        // Show/hide value rows when the type select changes.
        if (form[config.typeField]) {
            form[config.typeField].addEventListener('change', function() {
                form.querySelectorAll('.value-row').forEach(r => r.classList.add('sets-hidden'));
                if (this.value === 'single') {
                    form.querySelectorAll('.value-row-single').forEach(r => r.classList.remove('sets-hidden'));
                } else if (this.value === 'range') {
                    form.querySelectorAll('.value-row-range').forEach(r => r.classList.remove('sets-hidden'));
                } else if (this.value === 'set') {
                    form.querySelectorAll('.value-row-set').forEach(r => r.classList.remove('sets-hidden'));
                }
            });
            form[config.typeField].dispatchEvent(new Event('change'));
        }

        // Add set-input rows.
        const addBtnEl = form.querySelector('.' + config.addBtnClass);
        const setListEl = form.querySelector('.' + config.setListClass);
        if (addBtnEl && setListEl) {
            addBtnEl.addEventListener('click', function(e) {
                e.preventDefault();
                appendSetInputRow(setListEl, config.valueSetName, '');
            });
        }

        // Table row: edit / delete.
        const table = scope(tableId);
        if (table) {
            table.addEventListener('click', function(e) {
                const editBtn = e.target.closest('.std-btn-edit');
                if (editBtn) {
                    const row = editBtn.closest('tr');
                    form.id.value = editBtn.dataset.id || '';
                    form.name.value = cellText(row, 'col-name');
                    form.description.value = cellText(row, 'col-description');
                    populateFormFromRow(form, type, config, row);
                    fillTagsFromRow(form, row);

                    const cancelBtn = form.querySelector('.cancel-edit-btn');
                    if (cancelBtn) {
                        cancelBtn.classList.remove('sets-hidden');
                        cancelBtn.onclick = () => resetForm(form, config);
                    }
                }

                const delBtn = e.target.closest('.std-btn-delete');
                if (delBtn) {
                    const id = delBtn.dataset.id;
                    if (!id) {
                        return;
                    }
                    const deleteCommands = {
                        address: 'delete_address',
                        port: 'delete_port',
                        iface_set: 'delete_interface_set',
                        domain: 'delete_domain',
                    };
                    const command = deleteCommands[type];
                    const doDelete = () => {
                        apiClient.submit(command, { id })
                            .then(data => {
                                const parsed = parseServerResponse(data);
                                if (parsed.success) {
                                    if (opts.onDelete) {
                                        opts.onDelete();
                                    } else {
                                        showModal(
                                            '<p>' + escapeHtml(parsed.msg || 'Object deleted successfully') + '</p>',
                                            { onClose: () => window.location.reload() }
                                        );
                                    }
                                } else {
                                    showModal('<p>' + escapeHtml(parsed.msg || 'Error deleting object') + '</p>');
                                }
                            })
                            .catch(() => showModal('<p>Network or server error while deleting.</p>'));
                    };
                    showModal('<p>Are you sure you want to delete this object?</p>', {
                        title: 'Confirm deletion', showConfirm: true, confirmText: 'Delete', closeText: 'Cancel',
                        onConfirm: doDelete,
                    });
                }
            });
        }

        // Form submit.
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const isCreate = !form.id.value;
            const result = buildSubmitPayload(form, type, config);
            if (result.error) {
                showModal('<p>' + escapeHtml(result.error) + '</p>');
                return;
            }
            const payload = result.payload;
            const submittedName = payload.name;
            const command = form.id.value ? config.apiEdit : config.apiCreate;
            if (form.id.value) {
                payload.id = form.id.value;
            }
            apiClient.submit(command, payload)
                .then(data => {
                    const parsed = parseServerResponse(data);
                    if (parsed.success) {
                        if (opts.onSuccess) {
                            const createdId = isCreate && data && data.result ? data.result.id : null;
                            opts.onSuccess(submittedName, isCreate, createdId);
                        } else {
                            showModal(
                                '<p>' + escapeHtml(parsed.msg || 'Operation successful') + '</p>',
                                { onClose: () => window.location.reload() }
                            );
                        }
                    } else {
                        showModal('<p>' + escapeHtml(parsed.msg || 'Operation failed') + '</p>');
                    }
                })
                .catch(() => showModal('<p>Network or server error.</p>'));
        });
    });
}

// ============================================================
// Filters — shared
// ============================================================

// Determine row visibility from the two independent filter attributes:
//   data-af-hide: set by attribute/scope filters (address family, port scope, iface type)
//   data-tf-hide: set by text filter
function updateRowVisibility(row) {
    const hiddenByAttr = row.getAttribute('data-af-hide') === 'true';
    const hiddenByText = row.getAttribute('data-tf-hide') === 'true';
    row.style.display = (hiddenByAttr || hiddenByText) ? 'none' : '';
}

function tableRows(table) {
    return Array.from(table.tBodies[0] ? table.tBodies[0].rows : table.querySelectorAll('tbody tr'));
}

// ============================================================
// Filters — address (family + scope)
// ============================================================

function applyAddressFilters(root) {
    const doc = root || document;
    const table = doc.querySelector('#address-table');
    if (!table) {
        return;
    }

    const familyVal = (doc.querySelector('#filter-family') || { value: '' }).value || '';

    const scopeEl = doc.querySelector('#filter-scope');
    let scopeVals = [];
    if (scopeEl) {
        if (scopeEl.multiple) {
            scopeVals = Array.from(scopeEl.selectedOptions).map(o => o.value).filter(Boolean);
        } else {
            const sv = (scopeEl.value || '').trim();
            if (sv) {
                scopeVals = [sv];
            }
        }
    }

    tableRows(table).forEach(row => {
        const familyText = cellText(row, 'col-family').toLowerCase();
        const scopeText = cellText(row, 'col-scope').toLowerCase();
        let show = true;

        if (familyVal) {
            const fv = familyVal.toLowerCase();
            let match;
            if (fv === 'ip') {
                match = familyText.includes('ipv4') || familyText === 'ip';
            } else if (fv === 'ip6') {
                match = familyText.includes('ipv6') || familyText === 'ip6';
            } else {
                match = familyText === fv;
            }
            if (!match) {
                show = false;
            }
        }

        if (show && scopeVals.length) {
            const scopeMatch = scopeVals.some(sv => scopeText === sv.toLowerCase());
            if (!scopeMatch) {
                show = false;
            }
        }

        row.setAttribute('data-af-hide', show ? 'false' : 'true');
        updateRowVisibility(row);
    });
}

// Persist filter state to the URL via history.replaceState (page/mgmt mode only).
function persistAddressFiltersToUrl(doc) {
    try {
        const params = new URLSearchParams(window.location.search);
        const familyEl = doc.querySelector('#filter-family');
        const scopeEl = doc.querySelector('#filter-scope');

        if (familyEl) {
            if (familyEl.value) {
                params.set('family', familyEl.value);
            } else {
                params.delete('family');
            }
        }

        if (scopeEl) {
            params.delete('scope');
            if (scopeEl.multiple) {
                Array.from(scopeEl.selectedOptions).forEach(opt => {
                    if (opt.value) {
                        params.append('scope', opt.value);
                    }
                });
            } else if (scopeEl.value) {
                params.set('scope', scopeEl.value);
            }
        }

        const newUrl = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
        history.replaceState(null, '', newUrl);
    } catch (e) {
        // history.replaceState can fail in some secure contexts; non-critical.
    }
}

// Initialize address filters for a given root element.
// When root is null/undefined (page/mgmt mode), filter state is persisted to the URL.
// When root is a DOM element (modal/picker mode), no URL changes are made.
function initAddressFilters(root) {
    const doc = root || document;
    const isPageMode = !root;
    const familyEl = doc.querySelector('#filter-family');
    const scopeEl = doc.querySelector('#filter-scope');
    if (!familyEl && !scopeEl) {
        return;
    }

    // Guard against double initialization (page mode only — picker mode gets fresh DOM each time).
    if (isPageMode && (familyEl && familyEl.dataset.afInitialized)) {
        return;
    }

    // Restore saved filter state from URL params (page mode only).
    if (isPageMode) {
        const params = new URLSearchParams(window.location.search);
        if (familyEl) {
            const p = params.get('family') || params.get('set_family') || '';
            if (p) {
                familyEl.value = p;
            }
        }
        if (scopeEl) {
            if (scopeEl.multiple) {
                const saved = params.getAll('scope');
                if (saved.length) {
                    Array.from(scopeEl.options).forEach(opt => {
                        opt.selected = saved.includes(opt.value);
                    });
                }
            } else {
                const p = params.get('scope') || '';
                if (p) {
                    scopeEl.value = p;
                }
            }
        }
    }

    const onChange = () => {
        applyAddressFilters(doc);
        if (isPageMode) {
            persistAddressFiltersToUrl(doc);
        }
    };

    if (familyEl) {
        familyEl.addEventListener('change', onChange);
        if (isPageMode) familyEl.dataset.afInitialized = '1';
    }
    if (scopeEl) {
        scopeEl.addEventListener('change', onChange);
    }

    applyAddressFilters(doc);
}

// ============================================================
// Filters — interface (type)
// ============================================================

function applyInterfaceFilters(root) {
    const doc = root || document;
    const table = doc.querySelector('#iface-set-table');
    if (!table) {
        return;
    }
    const typeEl = doc.querySelector('#iface-filter-type');
    if (!typeEl) {
        return;
    }
    const filterType = (typeEl.value || '').trim().toLowerCase();

    tableRows(table).forEach(row => {
        const rowType = cellText(row, 'col-type').toLowerCase();
        const show = !filterType || rowType === filterType;
        row.setAttribute('data-af-hide', show ? 'false' : 'true');
        updateRowVisibility(row);
    });
}

function initInterfaceFilters(root) {
    const doc = root || document;
    const typeEl = doc.querySelector('#iface-filter-type');
    if (!typeEl) {
        return;
    }
    // Guard against double initialization in page mode.
    if (!root && typeEl.dataset.ifInitialized) {
        return;
    }
    typeEl.addEventListener('change', () => applyInterfaceFilters(doc));
    if (!root) typeEl.dataset.ifInitialized = '1';
    applyInterfaceFilters(doc);
}

// ============================================================
// Filters — port (scope)
// ============================================================

function applyPortFilters(root) {
    const doc = root || document;
    const table = doc.querySelector('#port-table');
    if (!table) {
        return;
    }
    const scopeEl = doc.querySelector('#port-filter-scope');
    if (!scopeEl) {
        return;
    }

    let scopeVals = [];
    if (scopeEl.multiple) {
        scopeVals = Array.from(scopeEl.selectedOptions).map(o => o.value).filter(Boolean);
    } else {
        const sv = (scopeEl.value || '').trim();
        if (sv) {
            scopeVals = [sv];
        }
    }

    tableRows(table).forEach(row => {
        const scopeText = cellText(row, 'col-scope').toLowerCase();
        let show = true;
        if (scopeVals.length) {
            const match = scopeVals.some(sv => scopeText === sv.toLowerCase());
            if (!match) {
                show = false;
            }
        }
        row.setAttribute('data-af-hide', show ? 'false' : 'true');
        updateRowVisibility(row);
    });
}

function initPortFilters(root) {
    const doc = root || document;
    const scopeEl = doc.querySelector('#port-filter-scope');
    if (!scopeEl) {
        return;
    }
    // Guard against double initialization in page mode.
    if (!root && scopeEl.dataset.pfInitialized) {
        return;
    }
    scopeEl.addEventListener('change', () => applyPortFilters(doc));
    if (!root) scopeEl.dataset.pfInitialized = '1';
    applyPortFilters(doc);
}

// ============================================================
// Filters — text (name / value / tags)
// ============================================================

function initTableTextFilter(opts, root) {
    const doc = root || document;
    const table = doc.querySelector('#' + opts.tableId);
    const input = doc.querySelector('#' + opts.inputId);
    if (!table || !input) {
        return;
    }
    const tbody = table.tBodies[0] || table.querySelector('tbody');
    if (!tbody) {
        return;
    }
    const nameClass = opts.nameClass || 'col-name';
    const valueClass = opts.valueClass || 'col-value';

    const apply = () => {
        const q = (input.value || '').trim().toLowerCase();
        Array.from(tbody.rows || []).forEach(r => {
            const nameText = cellText(r, nameClass).toLowerCase();
            const valText = cellText(r, valueClass).toLowerCase();
            const tagsText = cellText(r, 'col-tags').toLowerCase();
            const match = !q || nameText.includes(q) || valText.includes(q) || tagsText.includes(q);
            r.setAttribute('data-tf-hide', match ? 'false' : 'true');
            updateRowVisibility(r);
        });
    };

    input.addEventListener('input', apply);
    apply();

    // Re-apply when rows are added/removed by CRUD.
    const tfMo = new MutationObserver(apply);
    tfMo.observe(tbody, { childList: true });

    // In picker/modal mode, watch the content container for removal so we can
    // disconnect the tbody observer. In page mode this is unnecessary — the
    // input and table are permanent.
    if (doc !== document) {
        const parentMo = new MutationObserver(() => {
            if (!doc.contains(input)) {
                tfMo.disconnect();
                parentMo.disconnect();
            }
        });
        parentMo.observe(doc, { childList: true, subtree: true });
    }
}

// ============================================================
// Picker — apply pre-set filters after modal content loads
// ============================================================

// Apply caller-supplied filters to the filter UI in a modal/picker content element.
// filters: { family, scope: string|string[], type: string|string[] }
function applyInitialFilters(contentEl, filters) {
    if (!filters) {
        return;
    }

    const toArray = v => (Array.isArray(v) ? v : [v]);

    const familyEl = contentEl.querySelector('#filter-family');
    const scopeEl = contentEl.querySelector('#filter-scope');
    const ifaceTypeEl = contentEl.querySelector('#iface-filter-type');
    const portScopeEl = contentEl.querySelector('#port-filter-scope');

    if (familyEl && filters.family) {
        familyEl.value = filters.family;
    }

    if (scopeEl && filters.scope) {
        const scopes = toArray(filters.scope);
        if (scopeEl.multiple) {
            Array.from(scopeEl.options).forEach(opt => {
                opt.selected = scopes.includes(opt.value);
            });
        } else {
            scopeEl.value = scopes[0] || '';
        }
    }

    if (filters.family || filters.scope) {
        applyAddressFilters(contentEl);
    }

    if (ifaceTypeEl && filters.type) {
        ifaceTypeEl.value = toArray(filters.type)[0] || '';
        applyInterfaceFilters(contentEl);
    }

    if (portScopeEl && filters.scope) {
        const pScopes = toArray(filters.scope);
        if (portScopeEl.multiple) {
            Array.from(portScopeEl.options).forEach(opt => {
                opt.selected = pScopes.includes(opt.value);
            });
        } else {
            portScopeEl.value = pScopes[0] || '';
        }
        applyPortFilters(contentEl);
    }
}

// ============================================================
// Modal — fetch and display
// ============================================================

// Fetch a sets fragment and display it in the picker modal.
// filterParams: optional { family, scope, type } passed as URL query params for server-side filtering.
function fetchAndShowSetsModal(type, attachFn, filterParams) {
    const titles = { address: 'Address', ports: 'Port', interfaces: 'Interface', domain: 'Domain' };
    const title = (titles[type] || type) + ' Sets';

    let url = '?page=objects&section=sets-' + type + '&mode=picker&ajax=1';

    if (filterParams) {
        const toArray = v => (Array.isArray(v) ? v : [v]);
        if (filterParams.family) {
            url += '&filter_family=' + encodeURIComponent(filterParams.family);
        }
        if (filterParams.scope) {
            toArray(filterParams.scope).forEach(s => {
                url += '&filter_scope[]=' + encodeURIComponent(s);
            });
        }
        if (filterParams.type) {
            toArray(filterParams.type).forEach(t => {
                url += '&filter_type[]=' + encodeURIComponent(t);
            });
        }
    }

    fetch(url, { cache: 'no-store' })
        .then(r => {
            if (!r.ok) {
                throw new Error('HTTP ' + r.status);
            }
            return r.text();
        })
        .then(html => {
            const frag = document.createRange().createContextualFragment(html);
            showModal(frag, {
                title,
                boxClass: 'sets-modal-wide',
                contentClass: 'sets-modal-content',
                closeText: 'Cancel',
            });
            const contentEl = document.getElementById('std-modal-content');
            if (contentEl && attachFn) {
                attachFn(contentEl);
            }
        })
        .catch(() => showModal('<p>Failed to load sets content.</p>'));
}

// ============================================================
// Picker modal
// ============================================================

// Normalize a filter value to a clean array; returns null when empty.
function normalizeFilterArray(val) {
    if (!val) {
        return null;
    }
    const arr = Array.isArray(val)
        ? val
        : String(val).split(',').map(s => s.trim()).filter(Boolean);
    return arr.length ? arr : null;
}

// Open a picker modal.
// opts: { maxSelect: number, selectedIds: string[], filters: object, onSelect: fn([{id, name}]) }
function openSetsPicker(type, opts) {
    opts = opts || {};
    const maxSelect = opts.maxSelect || 1;
    const onSelect = opts.onSelect || null;
    const selectedIds = opts.selectedIds || [];

    // Normalize filters once; reuse throughout the picker lifecycle.
    const rawFilters = opts.filters || null;
    let urlFilters = null;
    let normalizedFilters = null;

    if (rawFilters) {
        const family = rawFilters.family || null;
        const scope = normalizeFilterArray(rawFilters.scope);
        const filterType = normalizeFilterArray(rawFilters.type);
        normalizedFilters = { family, scope, type: filterType };
        urlFilters = {};
        if (family) { urlFilters.family = family; }
        if (scope) { urlFilters.scope = scope; }
        if (filterType) { urlFilters.type = filterType; }
        if (!Object.keys(urlFilters).length) {
            urlFilters = null;
        }
    }

    function attachHandlers(contentEl) {
        initSetTypeForms(contentEl, {
            onSuccess: function(name, isCreate, id) {
                fetchAndShowSetsModal(type, attachHandlers, urlFilters);
                if (isCreate && id) {
                    // After reload, auto-check the newly created set.
                    const modalContent = document.getElementById('std-modal-content');
                    if (modalContent) {
                        const pickMo = new MutationObserver(() => {
                            const cb = modalContent.querySelector('.js-set-pick-row[value="' + String(id) + '"]');
                            if (cb) {
                                pickMo.disconnect();
                                cb.checked = true;
                                cb.dispatchEvent(new Event('change', { bubbles: true }));
                            }
                        });
                        pickMo.observe(modalContent, { childList: true, subtree: true });
                        setTimeout(() => pickMo.disconnect(), 5000);
                    }
                }
            },
            onDelete: () => fetchAndShowSetsModal(type, attachHandlers, urlFilters),
        });

        // root = contentEl → picker mode, no URL persistence.
        initAddressFilters(contentEl);
        initInterfaceFilters(contentEl);
        initPortFilters(contentEl);

        // Apply pre-set filters from caller (e.g. show only IPv4 hosts).
        applyInitialFilters(contentEl, normalizedFilters);

        // Text filter (only rendered in picker mode for the current type).
        const textFilterMap = {
            address:    { tableId: 'address-table',    inputId: 'address-filter',  nameClass: 'col-name', valueClass: 'col-value' },
            ports:      { tableId: 'port-table',       inputId: 'port-filter',     nameClass: 'col-name', valueClass: 'col-value' },
            interfaces: { tableId: 'iface-set-table',  inputId: 'iface-filter',    nameClass: 'col-name', valueClass: 'col-value' },
            domain:     { tableId: 'domain-set-table', inputId: 'domain-filter',   nameClass: 'col-name', valueClass: 'col-value' },
        };
        if (textFilterMap[type]) {
            initTableTextFilter(textFilterMap[type], contentEl);
        }

        initPickerSelection(contentEl, maxSelect, onSelect, selectedIds);
    }

    fetchAndShowSetsModal(type, attachHandlers, urlFilters);
}

// ============================================================
// Picker — checkbox selection
// ============================================================

// Wire checkbox selection for picker mode. Uses the modal's fixed action bar.
// selectedIds: optional array of IDs to pre-check (restores previous selection).
function initPickerSelection(contentEl, maxSelect, onConfirm, selectedIds) {
    // The inline picker actions are redundant — we use the fixed modal actions bar.
    const inlineActions = contentEl.querySelector('.js-set-picker-actions');
    if (inlineActions) {
        inlineActions.classList.add('sets-hidden');
    }

    function getCheckboxes() {
        return Array.from(contentEl.querySelectorAll('.js-set-pick-row'));
    }

    function enforceLimit() {
        const boxes = getCheckboxes();
        const checkedCount = boxes.filter(cb => cb.checked).length;
        boxes.forEach(cb => {
            if (!cb.checked) {
                cb.disabled = checkedCount >= maxSelect;
            }
        });
    }

    // Remove previous handler to avoid listener accumulation when the modal re-renders.
    if (contentEl._pickerChangeHandler) {
        contentEl.removeEventListener('change', contentEl._pickerChangeHandler);
    }
    const handler = function(e) {
        if (e.target && e.target.classList.contains('js-set-pick-row')) {
            enforceLimit();
        }
    };
    contentEl._pickerChangeHandler = handler;
    contentEl.addEventListener('change', handler);

    // Restore previously selected items.
    if (selectedIds && selectedIds.length) {
        getCheckboxes().forEach(cb => {
            if (selectedIds.includes(cb.value)) {
                cb.checked = true;
            }
        });
        enforceLimit();
    }

    // Inject confirm / cancel into the modal's fixed actions bar.
    const actionsBar = document.getElementById('std-modal-actions');
    if (actionsBar) {
        actionsBar.innerHTML = '';

        const confirmBtn = document.createElement('button');
        confirmBtn.textContent = 'Use selected';
        confirmBtn.className = 'std-btn-picker';
        confirmBtn.addEventListener('click', () => {
            const selected = getCheckboxes()
                .filter(cb => cb.checked)
                .map(cb => ({
                    id: cb.value,
                    name: cb.dataset.name || '',
                    value: cb.dataset.value || ''
                }));
            if (onConfirm) {
                onConfirm(selected);
            }
            hideModal();
        });
        actionsBar.appendChild(confirmBtn);

        const cancelBtn = document.createElement('button');
        cancelBtn.textContent = 'Cancel';
        cancelBtn.className = 'std-btn-picker';
        cancelBtn.addEventListener('click', hideModal);
        actionsBar.appendChild(cancelBtn);

        actionsBar.classList.add('visible');
    }
}

// ============================================================
// Picker field widgets
// ============================================================

// Attach picker behaviour to all [data-js="set-picker-field"] elements in scope.
// Required field attributes:
//   data-set-type      — 'address' | 'ports' | 'interfaces' | 'domain'
// Optional field attributes:
//   data-max-select    — max selectable items; defaults to 1
//   data-filter-family — pre-set family filter
//   data-filter-scope  — pre-set scope filter
//   data-filter-type   — pre-set type filter
// Required children:
//   input[type="hidden"]       — receives selected set ID(s)
//   .js-set-picker-label       — displays selected name(s)
//   button.js-set-picker-open  — opens the picker
// Optional children:
//   button.js-set-picker-clear — resets the field (shown after selection)
function initSetPickerFields(scope) {
    (scope || document).querySelectorAll('[data-js="set-picker-field"]').forEach(field => {
        // Guard against double initialization.
        if (field.dataset.jsPickerInit) {
            return;
        }
        field.dataset.jsPickerInit = '1';

        const type = field.dataset.setType;
        const maxSelect = parseInt(field.dataset.maxSelect, 10) || 1;
        const hiddenInput = field.querySelector('input[type="hidden"]');
        const labelEl = field.querySelector('.js-set-picker-label');
        const openBtn = field.querySelector('.js-set-picker-open');
        const clearBtn = field.querySelector('.js-set-picker-clear');

        if (!type || !hiddenInput || !openBtn) {
            return;
        }

        const placeholder = openBtn.dataset.placeholder || ('Select ' + type + ' set\u2026');

        function applySelection(id, name) {
            hiddenInput.value = id;
            if (labelEl) {
                labelEl.innerHTML = '';
                if (name.includes('\n')) {
                    name.split('\n').forEach((part, idx) => {
                        if (idx > 0) {
                            labelEl.appendChild(document.createElement('br'));
                        }
                        labelEl.appendChild(document.createTextNode(part));
                    });
                } else {
                    labelEl.textContent = name;
                }
            }
            openBtn.classList.add('set-picker-trigger--has-value');
            if (clearBtn) {
                clearBtn.classList.remove('sets-hidden');
            }
            hiddenInput.dispatchEvent(new Event('input', { bubbles: true }));
        }

        function clearSelection() {
            hiddenInput.value = '';
            if (labelEl) {
                labelEl.textContent = placeholder;
            }
            openBtn.classList.remove('set-picker-trigger--has-value');
            if (clearBtn) {
                clearBtn.classList.add('sets-hidden');
            }
            hiddenInput.dispatchEvent(new Event('input', { bubbles: true }));
        }

        openBtn.addEventListener('click', () => {
            const filters = {};
            if (field.dataset.filterFamily) { filters.family = field.dataset.filterFamily; }
            if (field.dataset.filterScope) { filters.scope = field.dataset.filterScope.split(',').map(s => s.trim()); }
            if (field.dataset.filterType) { filters.type = field.dataset.filterType.split(',').map(s => s.trim()); }

            const currentIds = hiddenInput.value
                ? hiddenInput.value.split(',').map(s => s.trim()).filter(Boolean)
                : [];

            openSetsPicker(type, {
                maxSelect,
                selectedIds: currentIds,
                filters: Object.keys(filters).length ? filters : null,
                onSelect: function(selection) {
                    if (!selection.length) {
                        return;
                    }
                    if (maxSelect <= 1) {
                        applySelection(selection[0].id, selection[0].name);
                    } else {
                        applySelection(
                            selection.map(s => s.id).join(','),
                            selection.map(s => s.name).join('\n')
                        );
                    }
                },
            });
        });

        if (clearBtn) {
            clearBtn.addEventListener('click', clearSelection);
        }
    });
}

// ============================================================
// Page entry points
// ============================================================

// Objects → Sets page: initialize CRUD forms on the full page DOM.
function initUnifiedObjectForms() {
    initSetTypeForms(document, null);
}

function initSetsTabs() {
    const tabContainer = document.getElementById('sets-tabs');
    if (!tabContainer) {
        return;
    }
    const tabs = Array.from(tabContainer.querySelectorAll('.std-tab-btn'));
    const panels = document.querySelectorAll('.std-tab-panel');
    const storageKey = 'fwsets_active_tab';

    function activateTab(targetId) {
        tabs.forEach(btn => btn.classList.remove('active'));
        panels.forEach(p => p.classList.remove('active'));
        const activeBtn = tabContainer.querySelector('[data-target="' + CSS.escape(targetId) + '"]');
        const activePanel = document.getElementById(targetId);
        if (activeBtn) { activeBtn.classList.add('active'); }
        if (activePanel) { activePanel.classList.add('active'); }
    }

    const saved = sessionStorage.getItem(storageKey);
    if (saved && document.getElementById(saved)) {
        activateTab(saved);
    }

    tabContainer.addEventListener('click', function(e) {
        const btn = e.target.closest('.std-tab-btn');
        if (!btn) {
            return;
        }
        const targetId = btn.dataset.target;
        if (targetId) {
            activateTab(targetId);
            sessionStorage.setItem(storageKey, targetId);
        }
    });
}

// ============================================================
// Public API
// ============================================================

window.setsModal = {
    openPicker: openSetsPicker,
    initPickerFields: initSetPickerFields,
};
