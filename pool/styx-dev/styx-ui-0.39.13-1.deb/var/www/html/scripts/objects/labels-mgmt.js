// labels-mgmt.js
// Provides initLabelsMgmt(root) and openLabelsPicker(reqType, opts).
// Depends on sets-mgmt-core.js being loaded first (escapeHtml, parseServerResponse,
// initTableTextFilter, initPickerSelection, showModal, hideModal are all globals from it).

function initLabelsMgmt(root) {
    root = root || document;
    const qry = (sel) => (root.querySelector ? root.querySelector(sel) : null);
    const qAll = (sel) => Array.from(root.querySelectorAll ? root.querySelectorAll(sel) : []);

    // initLabelsMgmt called

    const form = qry('#form-create-label');
    const targetSel = qry('#label-type');
    const nameInput = qry('#label-name');
    const valueInput = qry('#label-value');
    const createBtn = qry('#label-create-btn');
    const commentInput = qry('#label-comment');
    const labelsResult = qry('#labels-result');
    const tableBody = qry('.std-table.labels-table tbody');
    const tableRows = tableBody ? Array.from(tableBody.querySelectorAll('tr')) : [];

    // remove or disable delete buttons when deletion is not allowed
    qAll('.std-table.labels-table tbody tr .std-btn-delete').forEach(b => {
        const tr = b.closest('tr');
        if (!tr) return;
        const refsCell = tr.querySelector('.col-refs');
        const refs = refsCell ? (parseInt((refsCell.textContent || '').trim(), 10) || 0) : 0;
        if (refs > 0) {
            b.remove();
            return;
        }
        if (!tr.getAttribute('data-id') && !b.getAttribute('data-id')) {
            b.disabled = true;
            b.title = 'Missing id — cannot delete';
        }
    });

    function setInputsEnabled(enabled){
        if (nameInput) nameInput.disabled = !enabled;
        if (valueInput) valueInput.disabled = !enabled;
        if (commentInput) commentInput.disabled = !enabled;
        if (createBtn) createBtn.disabled = !enabled;
    }

    function applyFilter(target){
        const rows = tableBody ? Array.from(tableBody.querySelectorAll('tr')) : [];
        rows.forEach(r => {
            const rt = (r.getAttribute('data-type') || '').trim();
            const hide = (target && target !== 'all') ? (rt !== target) : false;
            r.setAttribute('data-af-hide', hide ? 'true' : 'false');
            updateRowVisibility(r);
        });
    }

    // initial state
    setInputsEnabled(false);
    applyFilter('all');

    if (targetSel) {
        targetSel.addEventListener('change', function(){
            const v = this.value;
            // type changed -> v
            if (!v || v === 'all') {
                setInputsEnabled(false);
            } else {
                setInputsEnabled(true);
            }
            applyFilter(v);
        });
    }



    if (form) {
        form.addEventListener('submit', function(e){
            e.preventDefault();
            const target = targetSel ? targetSel.value : '';
            if (!target || target === 'all') return;
            const name = nameInput ? nameInput.value.trim() : '';
            const value = valueInput ? valueInput.value.trim() : '';
            const comment = commentInput ? commentInput.value.trim() : '';
            if (!name) return;

            if (target === 'vlans' || target === 'vni' || target === 'gre_ikey' || target === 'gre_okey' || target === 'xfrm_if_id') {
                if (!/^[0-9]+$/.test(value)) {
                    if (labelsResult) labelsResult.innerHTML = '<span style="color:#f88;">Value must be numeric for this label type.</span>';
                    return;
                }
            }

            const normValue = (value || '').toString();
            if (!normValue) {
                if (labelsResult) labelsResult.innerHTML = '<span style="color:#f88;">Value is required.</span>';
                return;
            }

            const payload = { type: target, name: name, value: normValue, comment: comment };
            apiClient.submit('sets-mgmt.set_label', payload)
                .then(resp => {
                    if (resp && resp.status === 'success') {
                        const id = resp.result && resp.result.id ? resp.result.id : null;
                        if (!id) {
                            const msg = (resp && (resp.response_msg || resp.message)) || 'No id returned from server';
                            if (labelsResult) labelsResult.innerHTML = '<span style="color:#f88;">Error: '+ msg +'</span>';
                            return;
                        }
                        if (labelsResult) labelsResult.innerHTML = '<b>Created label</b> ' + escapeHtml(name) + ' (id: '+escapeHtml(id)+')';
                        if (tableBody) {
                            const tr = document.createElement('tr');
                            tr.setAttribute('data-type', target);
                            tr.setAttribute('data-id', id);
                            tr.setAttribute('data-value', normValue || '');
                            tr.setAttribute('data-comment', comment || '');

                            var typeLabels = {
                                'vlans': 'VLANs',
                                'packet_marking': 'Packet Marking',
                                'routing_tables': 'Routing Tables',
                                'route_tag': 'Route Tag',
                                'community': 'Community',
                                'as_path_regex': 'AS Path Regex',
                                'as_path_prepend': 'AS Path Prepend',
                                'as_number': 'AS Number',
                                'router_id': 'Router ID',
                                'ospf_area': 'OSPF Area',
                                'vni': 'VNI',
                                'gre_ikey': 'GRE IKey',
                                'gre_okey': 'GRE OKey',
                                'xfrm_if_id': 'XFRM Interface ID'
                            };
                            var typeLabel = typeLabels[target] || target;
                            const td1 = document.createElement('td'); td1.textContent = typeLabel;
                            const td2 = document.createElement('td'); td2.textContent = name;
                            const tdScope = document.createElement('td'); tdScope.textContent = '';
                            const td3 = document.createElement('td'); td3.textContent = normValue || '';
                            const tdComment = document.createElement('td'); tdComment.textContent = comment || '';
                            const tdRefs = document.createElement('td'); tdRefs.className = 'col-refs'; tdRefs.textContent = '0';
                            const tdActions = document.createElement('td');
                            const delBtn = document.createElement('button'); delBtn.type = 'button'; delBtn.className = 'std-btn std-btn-delete'; delBtn.setAttribute('data-id', id); delBtn.setAttribute('aria-label', 'Delete'); delBtn.title = 'Delete';
                            tdActions.appendChild(delBtn);

                            tr.appendChild(td1); tr.appendChild(td2); tr.appendChild(tdScope); tr.appendChild(td3); tr.appendChild(tdComment); tr.appendChild(tdRefs); tr.appendChild(tdActions);
                            tableBody.appendChild(tr);
                        }
                        if (form) form.reset();
                        setInputsEnabled(false);
                        if (targetSel) targetSel.value = 'all';
                        applyFilter('all');
                    } else {
                        const msg = (resp && (resp.response_msg || resp.message)) || 'Unknown error';
                        if (labelsResult) labelsResult.innerHTML = '<span style="color:#f88;">Error: '+ escapeHtml(msg) +'</span>';
                    }
                })
                .catch(err => {
                    if (labelsResult) labelsResult.innerHTML = '<span style="color:#f88;">Network error</span>';
                });
        });
    }

    // Directly attach delete handler to each delete button
    function attachDeleteHandler(btn) {
        if (btn._labelDeleteAttached) return;
        btn._labelDeleteAttached = true;
        btn.addEventListener('click', function(ev) {
            ev.stopPropagation();
            const tr = btn.closest('tr');
            if (!tr) return;
            if (!confirm('Delete this label?')) return;
            // data-id puede estar en el botón (picker) o en la fila (management)
            var id = btn.getAttribute('data-id') || btn.dataset.id || tr.getAttribute('data-id') || tr.dataset.id;
            if (!id) {
                if (labelsResult) labelsResult.innerHTML = '<span style="color:#f88;">Cannot delete: missing id</span>';
                return;
            }
            const payload = { id: id };
            apiClient.submit('sets-mgmt.delete_label', payload)
                .then(resp => {
                    if (resp && resp.status === 'success') {
                        tr.remove();
                        if (labelsResult) labelsResult.innerHTML = '<b>Label deleted</b>';
                    } else {
                        const msg = (resp && (resp.response_msg || resp.message)) || 'Delete failed';
                        if (labelsResult) labelsResult.innerHTML = '<span style="color:#f88;">Error: '+escapeHtml(msg)+'</span>';
                    }
                })
                .catch(() => {
                    if (labelsResult) labelsResult.innerHTML = '<span style="color:#f88;">Network error</span>';
                });
        });
    }
    // Attach to existing delete buttons
    if (tableBody) {
        tableBody.querySelectorAll('.std-btn-delete').forEach(attachDeleteHandler);
    }
    // Also attach via MutationObserver for dynamically added rows
    try {
        var deleteObserver = new MutationObserver(function(mutations) {
            mutations.forEach(function(mut) {
                if (mut.addedNodes) {
                    mut.addedNodes.forEach(function(node) {
                        if (node.nodeType === 1) {
                            if (node.matches && node.matches('.std-btn-delete')) {
                                attachDeleteHandler(node);
                            }
                            if (node.querySelectorAll) {
                                node.querySelectorAll('.std-btn-delete').forEach(attachDeleteHandler);
                            }
                        }
                    });
                }
            });
        });
        if (tableBody) {
            deleteObserver.observe(tableBody, { childList: true, subtree: true });
        }
    } catch (e) { /* noop */ }
}

// Open the labels picker modal, pre-filtered by reqType.
// opts: { title, maxSelect, onSelect: fn([{id, name}]) }
function openLabelsPicker(reqType, opts) {
    opts = opts || {};
    var scopeFilter = opts.scope || null;
    const url = '?page=objects&section=objects-labels&mode=picker&ajax=1'
        + (reqType ? '&type=' + encodeURIComponent(reqType) : '');
    fetch(url, { cache: 'no-store' })
        .then(function(r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
        .then(function(html) {
            const frag = document.createRange().createContextualFragment(html);
            showModal(frag, { title: opts.title || 'Select label', boxClass: 'sets-modal-wide', contentClass: 'sets-modal-content' });
            const contentEl = document.getElementById('std-modal-content');
            if (!contentEl) return;
            initLabelsMgmt(contentEl);
            if (reqType) {
                const typeSel = contentEl.querySelector('#label-type');
                if (typeSel) {
                    typeSel.value = reqType;
                    typeSel.dispatchEvent(new Event('change'));
                }
            }
            initTableTextFilter({ tableId: 'label-table', inputId: 'label-filter', nameClass: 'col-name', valueClass: 'col-value' }, contentEl);
            if (scopeFilter) {
                var rows = contentEl.querySelectorAll('#label-table tbody tr');
                rows.forEach(function(r) {
                    var scopeCell = r.querySelector('.col-scope');
                    var rowScope = scopeCell ? (scopeCell.textContent || '').trim() : '';
                    if (rowScope !== scopeFilter) {
                        r.style.display = 'none';
                    }
                });
            }
            initPickerSelection(contentEl, opts.maxSelect || 1, opts.onSelect || null);
        })
        .catch(function() { showModal('<p>Failed to load labels.</p>'); });
}

// Attach label-picker behaviour to all [data-js="label-picker-field"] elements in scope.
// Required field attribute:
//   data-set-type   — label type string passed to openLabelsPicker (e.g. 'as_number', 'router_id')
// Optional field attributes:
//   data-max-select — max selectable items; defaults to 1
//   data-label-title — modal title override
// Required children:
//   input[type="hidden"]       — receives selected label UUID
//   .js-set-picker-label       — displays selected label name
//   button.js-set-picker-open  — opens the picker modal
//   button.js-set-picker-clear — (optional) clears the selection
function initLabelPickerFields(scope) {
    (scope || document).querySelectorAll('[data-js="label-picker-field"]').forEach(function(field) {
        const labelType = field.dataset.setType;
        const maxSelect = parseInt(field.dataset.maxSelect, 10) || 1;
        const titleOverride = field.dataset.labelTitle || null;
        const hiddenInput = field.querySelector('input[type="hidden"]');
        const labelEl = field.querySelector('.js-set-picker-label');
        const openBtn = field.querySelector('.js-set-picker-open');
        const clearBtn = field.querySelector('.js-set-picker-clear');

        if (!labelType || !hiddenInput || !openBtn) {
            return;
        }

        const placeholder = openBtn.dataset.placeholder || ('Select label\u2026');

        function applySelection(id, name, value) {
            console.log('[labels-picker] applySelection', { id: id, name: name, value: value });
            hiddenInput.value = id;
            hiddenInput.setAttribute('data-value', value || '');
            if (labelEl) {
                labelEl.textContent = name;
            }
            openBtn.classList.add('set-picker-trigger--has-value');
            if (clearBtn) {
                clearBtn.classList.remove('sets-hidden');
            }
            hiddenInput.dispatchEvent(new Event('input', { bubbles: true }));
        }

        function clearSelection() {
            hiddenInput.value = '';
            if (labelEl) {
                labelEl.textContent = placeholder;
            }
            openBtn.classList.remove('set-picker-trigger--has-value');
            if (clearBtn) {
                clearBtn.classList.add('sets-hidden');
            }
            hiddenInput.dispatchEvent(new Event('input', { bubbles: true }));
        }

        openBtn.addEventListener('click', function() {
            var filterScope = field.dataset.filterScope || null;
            openLabelsPicker(labelType, {
                title: titleOverride || ('Select ' + labelType),
                maxSelect: maxSelect,
                scope: filterScope,
                onSelect: function(selection) {
                    if (!selection || !selection.length) {
                        return;
                    }
                    if (maxSelect <= 1) {
                        applySelection(selection[0].id, selection[0].name || selection[0].id, selection[0].value || '');
                    } else {
                        applySelection(
                            selection.map(function(s) { return s.id; }).join(','),
                            selection.map(function(s) { return s.name || s.id; }).join(', '),
                            selection.map(function(s) { return s.value || ''; }).join(',')
                        );
                    }
                },
            });
        });

        if (clearBtn) {
            clearBtn.addEventListener('click', clearSelection);
        }
    });
}

// Auto-init on full page load
document.addEventListener('DOMContentLoaded', function(){ try { initLabelsMgmt(document); } catch (e) { /* noop */ } });

// Expose functions for external use
if (typeof window !== 'undefined') {
    window.labelsMgmt = window.labelsMgmt || {};
    window.labelsMgmt.init = initLabelsMgmt;
    window.labelsMgmt.openPicker = openLabelsPicker;
    window.labelsMgmt.initPickerFields = initLabelPickerFields;
}
