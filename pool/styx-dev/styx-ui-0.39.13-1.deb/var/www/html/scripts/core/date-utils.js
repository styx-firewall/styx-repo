/**
 * date-utils.js
 *
 * Centralized client-side date/time formatting.
 * Reads user timezone and locale from cookies set by intl.js (tz, tz_locale).
 * Warns via appLog.warn() when a date string carries an explicit non-UTC offset,
 * indicating a backend contract violation (backend should always send UTC).
 *
 * Exposed as window.dateUtils — available globally on every page.
 */
(function (window) {
    'use strict';

    function getCookie(name) {
        var parts = document.cookie.split(';');
        for (var i = 0; i < parts.length; i++) {
            var part = parts[i].trim();
            if (part.indexOf(name + '=') === 0) {
                return decodeURIComponent(part.substring(name.length + 1));
            }
        }
        return null;
    }

    function getUserTz() {
        var meta = document.querySelector('meta[name="app-tz"]');
        if (meta) {
            return meta.getAttribute('content') || 'UTC';
        }
        return getCookie('tz') || 'UTC';
    }

    function getUserLocale() {
        var meta = document.querySelector('meta[name="app-locale"]');
        if (meta) {
            return meta.getAttribute('content') || 'en-US';
        }
        return getCookie('tz_locale') || 'en-US';
    }

    /**
     * Returns true when the string carries an explicit non-UTC timezone offset.
     * Bare strings ("2024-01-01 12:00:00") and Z / +00:00 suffixes return false.
     */
    function isExplicitlyNonUtc(str) {
        if (typeof str !== 'string') return false;
        var trimmed = str.trim();
        if (/Z$|[+]00:00$/i.test(trimmed)) return false;
        return /[+\-]\d{2}:\d{2}$/.test(trimmed);
    }

    /**
     * Format a UNIX timestamp (seconds or milliseconds) in the user's timezone.
     *
     * Auto-detects unit:
     *  - > 1e13  → microseconds (journald __REALTIME_TIMESTAMP)
     *  - > 1e10  → milliseconds
     *  - otherwise → seconds
     *
     * @param {number|string} ts
     * @param {object} [opts]  Optional overrides: { tz, locale, dateStyle, timeStyle }
     * @returns {string}
     */
    function formatTimestamp(ts, opts) {
        var num = typeof ts === 'string' ? Number(ts) : ts;
        if (isNaN(num) || !num) return '';

        var ms;
        if (num > 1e13) {
            ms = Math.floor(num / 1000);   // microseconds → ms
        } else if (num > 1e10) {
            ms = num;                       // already ms
        } else {
            ms = num * 1000;               // seconds → ms
        }

        return _formatMs(ms, opts);
    }

    /**
     * Format a date string from the backend (expected UTC) in the user's timezone.
     * Fires appLog.warn() when the string carries a non-UTC offset.
     *
     * @param {string} str
     * @param {object} [opts]  Optional overrides: { tz, locale, dateStyle, timeStyle }
     * @returns {string}
     */
    function formatString(str, opts) {
        if (!str) return '';

        if (isExplicitlyNonUtc(str)) {
            if (typeof appLog !== 'undefined') {
                appLog.warn('[date-utils] Non-UTC date string from backend: ' + str);
            }
        }

        // Bare strings without a timezone indicator are treated as UTC per backend contract.
        var normalized = str.trim();
        if (/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}$/.test(normalized)) {
            normalized = normalized.replace(' ', 'T') + 'Z';
        }

        var d = new Date(normalized);
        if (isNaN(d.getTime())) return str;
        return _formatMs(d.getTime(), opts);
    }

    /**
     * Internal: format a millisecond epoch using Intl.DateTimeFormat.
     */
    function _formatMs(ms, opts) {
        opts = opts || {};
        var tz = opts.tz || getUserTz();
        var locale = opts.locale || getUserLocale();

        try {
            return new Intl.DateTimeFormat(locale, {
                timeZone: tz,
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            }).format(new Date(ms));
        } catch (e) {
            // Fallback: Intl not available or invalid tz/locale
            var d = new Date(ms);
            if (isNaN(d.getTime())) return '';
            var pad = function(n) { return String(n).padStart(2, '0'); };
            return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) +
                ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
        }
    }

    /**
     * Format a timestamp as a short time label (HH:MM or HH:MM:SS) in user's timezone.
     * opts: { includeSeconds: boolean, tz, locale }
     */
    function formatShortTime(ts, opts) {
        opts = opts || {};
        var num = typeof ts === 'string' ? Number(ts) : ts;
        var ms;
        if (isFinite(num)) {
            ms = num > 1e13 ? Math.floor(num / 1000) : (num > 1e10 ? num : num * 1000);
        } else {
            ms = Date.parse(String(ts));
        }
        if (!isFinite(ms) || isNaN(ms)) return '';

        var tz = opts.tz || getUserTz();
        var locale = opts.locale || getUserLocale();
        var fmtOpts = { timeZone: tz, hour: '2-digit', minute: '2-digit', hour12: false };
        if (opts.includeSeconds) fmtOpts.second = '2-digit';
        try {
            return new Intl.DateTimeFormat(locale, fmtOpts).format(new Date(ms));
        } catch (e) {
            var d = new Date(ms);
            if (isNaN(d.getTime())) return '';
            var pad = function(n) { return String(n).padStart(2, '0'); };
            var res = pad(d.getHours()) + ':' + pad(d.getMinutes());
            if (opts.includeSeconds) res += ':' + pad(d.getSeconds());
            return res;
        }
    }

    window.dateUtils = {
        formatTimestamp: formatTimestamp,
        formatString: formatString,
        isExplicitlyNonUtc: isExplicitlyNonUtc,
        getUserTz: getUserTz,
        getUserLocale: getUserLocale,
        formatShortTime: formatShortTime
    };

})(window);
