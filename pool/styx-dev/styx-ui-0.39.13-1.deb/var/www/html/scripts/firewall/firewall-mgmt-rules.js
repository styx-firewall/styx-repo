// Basic validation of required fields and format
function validateFirewallRule(payload) {
    if (!payload.name || payload.name.trim() === '') {
        alert('Rule name is required.');
        return false;
    }
    if (!payload.family || payload.family.trim() === '') {
        alert('Family is required.');
        return false;
    }
    if (!payload.action || payload.action.trim() === '') {
        alert('Action is required.');
        return false;
    }
    // For input/output (local), chain is required
    if (payload.chain !== undefined && (!payload.chain || payload.chain.trim() === '')) {
        alert('Direction (chain) is required.');
        return false;
    }
    // Validate arrays (interfaces, IPs, ports)
    const arrayFields = ['src_ifaces', 'dst_ifaces', 'src_ips', 'dst_ips', 'src_ports', 'dst_ports'];
    arrayFields.forEach(f => {
        if (payload[f] && Array.isArray(payload[f])) {
            payload[f] = payload[f].filter(v => v && v.trim() !== '');
        }
    });
    // Validate IPs (only sets by UUID)
    const ipFields = ['src_ips', 'dst_ips'];
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    ipFields.forEach(f => {
        if (payload[f]) {
            const arr = Array.isArray(payload[f]) ? payload[f] : [payload[f]];
            for (const ip of arr) {
                if (ip && !uuidRegex.test(ip)) {
                    alert('Only sets identified by UUID are accepted in ' + f + ': ' + ip);
                    return false;
                }
            }
        }
    });
    // Validate ports (only sets by UUID)
    const portFields = ['src_ports', 'dst_ports'];
    portFields.forEach(f => {
        if (payload[f]) {
            const arr = Array.isArray(payload[f]) ? payload[f] : [payload[f]];
            for (const p of arr) {
                if (p && !uuidRegex.test(p)) {
                    alert('Only sets identified by UUID are accepted in ' + f + ': ' + p);
                    return false;
                }
            }
        }
    });
    // Validate interface sets (only sets by UUID)
    const ifaceFields = ['src_ifaces', 'dst_ifaces'];
    ifaceFields.forEach(f => {
        if (payload[f]) {
            const arr = Array.isArray(payload[f]) ? payload[f] : [payload[f]];
            for (const v of arr) {
                if (v && !uuidRegex.test(v)) {
                    alert('Only sets identified by UUID are accepted in ' + f + ': ' + v);
                    return false;
                }
            }
        }
    });
    // At least one conditional field must be present
    const conditionalFields = [
        'src_ips', 'dst_ips', 'src_ports', 'dst_ports',
        'src_ifaces', 'dst_ifaces', 'protocol', 'icmp_type', 'time', 'fwmark'
    ];
    let hasCondition = false;
    for (const f of conditionalFields) {
        if (payload[f] && (
            (Array.isArray(payload[f]) && payload[f].length > 0) ||
            (
                !Array.isArray(payload[f]) &&
                payload[f] !== '' &&
                payload[f] !== null &&
                typeof payload[f] !== 'undefined'
            )
        )) {
            hasCondition = true;
            break;
        }
    }
    if (!hasCondition) {
        alert('You must specify at least one condition (IP, port, interface, protocol, ICMP, time, etc).');
        return false;
    }
    // Validate icmp_type when protocol is icmp or icmpv6
    if (payload.protocol === 'icmp' || payload.protocol === 'icmpv6') {
        if (payload.icmp_type !== undefined && payload.icmp_type !== null && payload.icmp_type !== '') {
            var typeVal = parseInt(payload.icmp_type, 10);
            if (isNaN(typeVal) || typeVal < 0 || typeVal > 255) {
                alert('ICMP type must be an integer between 0 and 255.');
                return false;
            }
        }
    }
    return true;
}

/**
 * Collect all firewall rule form fields into a flat payload object.
 * Shared by the submit handler and the debounced preview.
 */
function collectFirewallFormData(form) {
    const payload = {};

    // Collect all fields with data-field
    form.querySelectorAll('[data-field]').forEach(function(el) {
        const key = el.getAttribute('data-field');
        if (el.type === 'checkbox') {
            payload[key] = el.checked ? 1 : 0;
        } else if (el.multiple) {
            const vals = Array.from(el.selectedOptions).map(function(opt) { return opt.value; })
                .filter(function(v) { return v && v.trim() !== ''; });
            if (vals.length > 0) payload[key] = vals;
        } else if (el.dataset.pickerArray) {
            const arr = (el.value || '').split(',').map(function(v) { return v.trim(); })
                .filter(function(v) { return v !== ''; });
            if (arr.length > 0) payload[key] = arr;
        } else {
            if (el.value && el.value.trim() !== '') payload[key] = el.value;
        }
    });

    // TCP flags
    const protocol = form.querySelector('#rule-protocol');
    if (protocol && protocol.value === 'tcp') {
        const flagEls = form.querySelectorAll('input[type="checkbox"][name="tcp_flags[]"]');
        const flags = Array.from(flagEls).filter(function(el) { return el.checked; })
            .map(function(el) { return el.value; });
        if (flags.length > 0) payload['tcp_flags'] = flags;
    }

    // ICMP type
    if (protocol && (protocol.value === 'icmp' || protocol.value === 'icmpv6')) {
        const icmpTypeEl = form.querySelector('#rule-icmp-type');
        if (icmpTypeEl && icmpTypeEl.value !== '') {
            const parsed = parseInt(icmpTypeEl.value, 10);
            if (!isNaN(parsed) && parsed >= 0 && parsed <= 255) {
                payload['icmp_type'] = parsed;
            }
        }
    }

    // Chain for local rules
    if (!payload.chain) {
        const chainSelect = form.querySelector('select[name="chain_select"]');
        if (chainSelect && chainSelect.value) {
            payload.chain = chainSelect.value;
        }
    }

    // Map 'iface' (local form) to src_ifaces or dst_ifaces based on chain
    if (payload.iface) {
        if (payload.chain === 'input') {
            payload.src_ifaces = payload.iface;
        } else if (payload.chain === 'output') {
            payload.dst_ifaces = payload.iface;
        }
        delete payload.iface;
    }

    // Enabled / log / nat checkboxes
    form.querySelectorAll('input[type="checkbox"][name="enabled"]').forEach(function(el) {
        payload['enabled'] = el.checked ? 1 : 0;
    });
    form.querySelectorAll('input[type="checkbox"][name="log"]').forEach(function(el) {
        payload['log'] = el.checked ? 1 : 0;
    });
    form.querySelectorAll('input[type="checkbox"][name="enable_nat"]').forEach(function(el) {
        payload['nat'] = el.checked ? 1 : 0;
    });

    // Time restriction
    const timeStart = form.querySelector('input[name="time[start]"]');
    const timeStop = form.querySelector('input[name="time[stop]"]');
    const timeDays = form.querySelector('select[name="time[days][]"]');
    if (
        (timeStart && timeStart.value) ||
        (timeStop && timeStop.value) ||
        (timeDays && Array.from(timeDays.selectedOptions).some(function(opt) {
            return opt.value && opt.value.trim() !== '';
        }))
    ) {
        payload['time'] = {
            start: timeStart && timeStart.value ? timeStart.value : '',
            stop: timeStop && timeStop.value ? timeStop.value : '',
            days: timeDays ? Array.from(timeDays.selectedOptions)
                .map(function(opt) { return opt.value; })
                .filter(function(v) { return v && v.trim() !== ''; }) : []
        };
    }

    return payload;
}

/**
 * Handle a firewall form submission response.
 * Shows result via showApiResult, redirects on success, resets form if no redirect.
 */
function handleSubmitResponse(data, form) {
    if (Array.isArray(data)) data = data[0] || {};
    appLog('Response data:', data);
    const ok = data.success || data.status === 'success';
    let redirectUrl = null;
    if (ok) {
        try {
            const redirectSection = form && form.dataset.redirectSection || 'fw-rules-local';
            redirectUrl = '?page=firewall&section=' + redirectSection;
        } catch (e) { /* noop */ }
    }
    showApiResult(data, {
        title: ok ? 'Success' : 'Error',
        closeText: 'Close',
        onClose: ok && redirectUrl ? function() { window.location.href = redirectUrl; } : undefined
    });
    if (ok && !redirectUrl) { try { form.reset(); } catch (e) { /* noop */ } }
}

// Collects and sends firewall rule forms (forward/local)
document.addEventListener('DOMContentLoaded', function() {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }
    const forms = document.querySelectorAll('.std-form');
    forms.forEach(form => {
        // Capture which command button was clicked for browsers without event.submitter
        form.querySelectorAll('button[name="command"], input[type="submit"][name="command"]').forEach(btn => {
            btn.addEventListener('click', function() {
                try { form.dataset.lastCommand = btn.value; } catch (e) { /* noop */ }
            });
        });

        form.addEventListener('submit', function(e) {
            e.preventDefault();

            // Guard: pure system_rule rules cannot be edited at all
            if (form.dataset.systemRule && !form.dataset.endOfChain) {
                return;
            }

            let command = null;
            if (e.submitter && e.submitter.name === 'command') {
                command = e.submitter.value;
            } else if (form.dataset && form.dataset.lastCommand) {
                command = form.dataset.lastCommand;
            } else if (form.querySelector('[name="command"]')) {
                const el = form.querySelector('[name="command"]');
                command = el && el.value ? el.value : null;
            }
            // Send the id if it exists (for edit/delete)
            const idInput = form.querySelector('input[name="id"]');
            const idValue = idInput && idInput.value ? idInput.value : null;

            // Early path: end_of_chain system rule — only log and action may change
            if (form.dataset.systemRule && form.dataset.endOfChain) {
                const actionEl = form.querySelector('#rule-action');
                const logEl = form.querySelector('[name="log"]');
                const payload = {
                    command: 'update_firewall_rule',
                    id: idValue,
                    action: actionEl ? actionEl.value : null,
                    log: logEl ? (logEl.checked ? 1 : 0) : 0,
                };
                appLog('Submit payload (system end_of_chain):', payload);
                apiClient.submit(payload.command, payload)
                    .then(data => handleSubmitResponse(data, form))
                    .catch(() => showApiResult({ status: 'error', response_msg: 'Network or server error.' }, { title: 'Error', closeText: 'Close' }));
                return;
            }

            if (command === 'delete_firewall_rule') {
                // Only send id and command
                const payload = {
                    command: command,
                    id: idValue
                };
                appLog('Submit payload:', payload);
                apiClient.submit(payload.command || payload.cmd, payload)
                .then(data => handleSubmitResponse(data, form))
                .catch(() => showApiResult({ status: 'error', response_msg: 'Network or server error.' }, { title: 'Error', closeText: 'Close' }));
                return;
            }
            // If not delete, build the full payload
            const payload = collectFirewallFormData(form);
            if (command) {
                payload['command'] = command;
            }
            if (idValue) {
                payload['id'] = idValue;
            }
            // Basic validation via JS before sending (only if not delete)
            if (payload.command !== 'delete_firewall_rule') {
                if (!payload.command) {
                    alert('Error: required "command" field is missing in the form.');
                    return;
                }
                if (!validateFirewallRule(payload)) return;
                // If table is 'local', replace it with the value of chain or show an error
                if (payload.table === 'local') {
                    if (payload.chain && payload.chain.trim() !== '') {
                        payload.table = payload.chain;
                    } else {
                        alert('Error: No direction (chain) was specified for the local table.');
                        return;
                    }
                }
                // Before sending, for local form: set chain according to the selected chain
                if (form.id === 'firewall-rule-form') {
                    var chainSelect = form.querySelector('#rule-chain');
                    if (chainSelect && chainSelect.value) {
                        payload.chain = chainSelect.value;
                    }
                }
            }
            appLog('Submit payload:', payload);
            // Send
            apiClient.submit(payload.command || payload.cmd, payload)
            .then(data => handleSubmitResponse(data, form))
            .catch(() => showApiResult({ status: 'error', response_msg: 'Network or server error.' }, { title: 'Error', closeText: 'Close' }));
        });
    });

    document.querySelectorAll('.std-collapse-header').forEach(function(header){
        header.addEventListener('click',function(){
            header.parentElement.classList.toggle('open');
        });
    });

    // Apply system_rule restrictions to forms
    forms.forEach(function(form) {
        const isSystemRule = !!form.dataset.systemRule;
        const isEndOfChain = !!form.dataset.endOfChain;

        if (!isSystemRule) {
            return;
        }

        if (!isEndOfChain) {
            // Fully locked: disable all inputs and the save button
            form.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach(function(el) {
                el.disabled = true;
            });
            form.querySelectorAll('.js-set-picker-open, .js-set-picker-clear').forEach(function(btn) {
                btn.disabled = true;
            });
            form.querySelectorAll('button[type="submit"]').forEach(function(btn) {
                btn.disabled = true;
            });
            const notice = document.createElement('div');
            notice.className = 'std-msg-info';
            notice.textContent = 'This is a system rule and cannot be edited.';
            form.prepend(notice);
        } else {
            // end_of_chain: only action and log are editable
            form.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach(function(el) {
                if (el.id !== 'rule-action' && el.name !== 'log') {
                    el.disabled = true;
                }
            });
            form.querySelectorAll('.js-set-picker-open, .js-set-picker-clear').forEach(function(btn) {
                btn.disabled = true;
            });
            form.querySelectorAll('button[value="delete_firewall_rule"]').forEach(function(btn) {
                btn.disabled = true;
            });
            const notice = document.createElement('div');
            notice.className = 'std-msg-info';
            notice.textContent = 'This is a system rule. Only Action and Log can be modified.';
            form.prepend(notice);
        }
    });

    function updateTcpFlagsVisibility() {
        var protocol = document.getElementById('rule-protocol').value;
        var flagsRow = document.getElementById('tcp-flags-row');
        if (protocol === 'tcp') {
            flagsRow.style.display = '';
        } else {
            flagsRow.style.display = 'none';
        }
    }
    function updateIcmpTypeVisibility() {
        var protocol = document.getElementById('rule-protocol').value;
        var icmpRow = document.getElementById('icmp-type-row');
        if (icmpRow) {
            if (protocol === 'icmp' || protocol === 'icmpv6') {
                icmpRow.style.display = '';
            } else {
                icmpRow.style.display = 'none';
                var icmpTypeEl = document.getElementById('rule-icmp-type');
                if (icmpTypeEl) {
                    icmpTypeEl.value = '';
                }
            }
        }
    }
    document.getElementById('rule-protocol').addEventListener('change', function() {
        updateTcpFlagsVisibility();
        updateIcmpTypeVisibility();
    });
    updateTcpFlagsVisibility();
    updateIcmpTypeVisibility();

    // ─── Debounced firewall rule preview (backend) ────────────────────────────

    let _fwPreviewTimer = null;

    async function buildFirewallPreview(form) {
        const preview = form.querySelector('.fw-preview-code');
        if (!preview) return;

        const payload = collectFirewallFormData(form);

        // Client-side validation: name, family, action required
        if (!payload.name) {
            preview.textContent = 'Enter a rule name to preview';
            return;
        }
        if (!payload.family) {
            preview.textContent = '';
            return;
        }
        if (!payload.action) {
            preview.textContent = '';
            return;
        }

        // At least one condition is recommended
        const conditionalFields = [
            'src_ips', 'dst_ips', 'src_ports', 'dst_ports',
            'src_ifaces', 'dst_ifaces', 'protocol', 'icmp_type', 'time', 'fwmark'
        ];
        let hasCondition = false;
        for (const f of conditionalFields) {
            if (payload[f] && (
                (Array.isArray(payload[f]) && payload[f].length > 0) ||
                (!Array.isArray(payload[f]) && payload[f] !== '' && payload[f] !== null)
            )) {
                hasCondition = true;
                break;
            }
        }
        if (!hasCondition) {
            preview.textContent = 'Add at least one condition to preview';
            return;
        }

        preview.textContent = 'Fetching preview…';

        try {
            const res = await apiClient.submit('preview_firewall_rule', payload);
            const data = Array.isArray(res) ? res[0] : res;
            if (data && data.status === 'success' && data.result && data.result.nft_run) {
                preview.textContent = data.result.nft_run;
            } else if (data && data.response_msg) {
                preview.textContent = '\u26A0 ' + data.response_msg;
            } else {
                preview.textContent = '\u26A0 Preview error';
            }
        } catch (err) {
            preview.textContent = '\u26A0 ' + (err.message || 'Request failed');
        }
    }

    function debouncedFirewallPreview(form) {
        if (_fwPreviewTimer) clearTimeout(_fwPreviewTimer);
        _fwPreviewTimer = setTimeout(function() { buildFirewallPreview(form); }, 300);
    }

    // Attach preview listeners to firewall rule forms
    document.querySelectorAll('#firewall-rule-form, #firewall-rule-forward-form').forEach(function(form) {
        // Skip system rules (fully locked)
        if (form.dataset.systemRule && !form.dataset.endOfChain) return;

        form.querySelectorAll('input, select, textarea').forEach(function(el) {
            if (el.type === 'button' || el.type === 'submit') return;
            el.addEventListener('change', function() { debouncedFirewallPreview(form); });
            el.addEventListener('input', function() { debouncedFirewallPreview(form); });
        });

        // Initial preview on page load (for edit forms)
        buildFirewallPreview(form);
    });
});
