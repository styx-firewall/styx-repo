// routing-vrrp.js
// VRRPv3 — toggle + add/edit/submit + delete

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }

    // ── Save config ─────────────────────────────────────────────────────────
    const saveCfg = document.querySelector('[data-js="vrrp-save-config"]');
    if (saveCfg) {
        saveCfg.addEventListener('click', async () => {
            try {
                const r = await apiClient.submit('routing_save_vrrp_config', {
                    enabled: document.getElementById('vrrp_enabled').checked,
                    global_defaults: {
                        priority: parseInt(document.getElementById('vrrp_def_priority').value, 10) || 100,
                        advertisement_interval: parseInt(document.getElementById('vrrp_def_adv_interval').value, 10) || 1000,
                        preempt: document.getElementById('vrrp_def_preempt').checked,
                        checksum_with_ipv4_pseudoheader: document.getElementById('vrrp_def_checksum').checked,
                    },
                });
                showApiResult(r, { title: 'VRRP Config', closeText: 'Close', reloadOnOk: true });
            } catch (e) {
                showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // ── Toggle form ─────────────────────────────────────────────────────────
    document.querySelectorAll('[data-js="vrrp-toggle-form"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const t = document.getElementById(btn.dataset.target);
            if (!t) return;
            if (t.style.display === 'none') {
                // Opening via "+ Add" button
                resetForm();
                t.style.display = 'block';
                btn.style.display = 'none';
            } else {
                // Closing via Cancel or toggling off
                resetForm();
                t.style.display = 'none';
                const ab = document.querySelector('[data-js="vrrp-toggle-form"][data-target="' + btn.dataset.target + '"]');
                if (ab) ab.style.display = '';
            }
        });
    });

    function resetSetPicker(hiddenId) {
        const hidden = document.getElementById(hiddenId);
        if (!hidden) return;
        hidden.value = '';
        const field = hidden.closest('.set-picker-field');
        if (!field) return;
        const label = field.querySelector('.js-set-picker-label');
        const clearBtn = field.querySelector('.js-set-picker-clear');
        const trigger = field.querySelector('.js-set-picker-open');
        if (label && trigger) {
            label.textContent = trigger.dataset.placeholder || 'Select address set';
        }
        if (clearBtn) clearBtn.classList.add('sets-hidden');
    }

    function populateSetPicker(hiddenId, uuid, displayName) {
        const hidden = document.getElementById(hiddenId);
        if (!hidden) return;
        hidden.value = uuid || '';
        const field = hidden.closest('.set-picker-field');
        if (!field) return;
        const label = field.querySelector('.js-set-picker-label');
        const clearBtn = field.querySelector('.js-set-picker-clear');
        const trigger = field.querySelector('.js-set-picker-open');
        if (label) {
            label.textContent = displayName || (trigger && trigger.dataset.placeholder) || 'Select address set';
        }
        if (clearBtn) {
            if (uuid) { clearBtn.classList.remove('sets-hidden'); }
            else { clearBtn.classList.add('sets-hidden'); }
        }
    }

    function resetForm() {
        document.getElementById('vrrp_id').value = '';
        document.getElementById('vrrp_interface').value = '';
        document.getElementById('vrrp_vrid').value = '';
        document.getElementById('vrrp_priority').value = '';
        document.getElementById('vrrp_adv_interval').value = '';
        document.getElementById('vrrp_preempt').checked = true;
        document.getElementById('vrrp_shutdown').checked = false;
        document.getElementById('vrrp_checksum').checked = true;
        resetSetPicker('vrrp_ip_addresses_set');
        resetSetPicker('vrrp_ipv6_addresses_set');
        document.getElementById('vrrp-form-title').textContent = 'Add VRRP Instance';
    }

    // ── Edit ────────────────────────────────────────────────────────────────
    document.querySelectorAll('.js-vrrp-edit').forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('vrrp_id').value = btn.dataset.id;
            document.getElementById('vrrp_interface').value = btn.dataset.interface;
            document.getElementById('vrrp_vrid').value = btn.dataset.vrid;
            document.getElementById('vrrp_priority').value = btn.dataset.priority;
            document.getElementById('vrrp_adv_interval').value = btn.dataset.advInterval;
            document.getElementById('vrrp_preempt').checked = (btn.dataset.preempt === '1');
            document.getElementById('vrrp_shutdown').checked = (btn.dataset.shutdown === '1');
            document.getElementById('vrrp_checksum').checked = (btn.dataset.checksum === '1');
            populateSetPicker('vrrp_ip_addresses_set', btn.dataset.ipAddressesSet, btn.dataset.ipAddressesSetDisplay);
            populateSetPicker('vrrp_ipv6_addresses_set', btn.dataset.ipv6AddressesSet, btn.dataset.ipv6AddressesSetDisplay);
            document.getElementById('vrrp-form-title').textContent = 'Edit VRRP Instance';
            const f = document.getElementById('vrrp-add-form');
            f.style.display = 'block';
            const ab = document.querySelector('[data-js="vrrp-toggle-form"][data-target="vrrp-add-form"]');
            if (ab) ab.style.display = 'none';
        });
    });

    // ── Save instance ───────────────────────────────────────────────────────
    const saveInst = document.querySelector('[data-js="vrrp-instance-save"]');
    if (saveInst) {
        saveInst.addEventListener('click', async () => {
            const id = document.getElementById('vrrp_id').value.trim();
            const iface = document.getElementById('vrrp_interface').value.trim();
            const vrid = parseInt(document.getElementById('vrrp_vrid').value, 10);
            if (!iface) { showModal('<p>Interface is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }
            if (!vrid || vrid < 1 || vrid > 255) { showModal('<p>VRID must be between 1 and 255.</p>', { title: 'Validation', closeText: 'Close' }); return; }

            const ipSet = document.getElementById('vrrp_ip_addresses_set').value.trim();
            const ipv6Set = document.getElementById('vrrp_ipv6_addresses_set').value.trim();

            if (!ipSet && !ipv6Set) { showModal('<p>At least one address set (IPv4 or IPv6) is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }

            const data = {
                interface: iface,
                vrid: vrid,
                priority: parseInt(document.getElementById('vrrp_priority').value, 10) || undefined,
                advertisement_interval: parseInt(document.getElementById('vrrp_adv_interval').value, 10) || undefined,
                preempt: document.getElementById('vrrp_preempt').checked,
                shutdown: document.getElementById('vrrp_shutdown').checked,
                checksum_with_ipv4_pseudoheader: document.getElementById('vrrp_checksum').checked,
                ip_addresses_set: ipSet || undefined,
                ipv6_addresses_set: ipv6Set || undefined,
            };
            // Remove undefined keys for partial update
            if (id) { data.id = id; Object.keys(data).forEach(k => { if (data[k] === undefined) delete data[k]; }); }

            const cmd = id ? 'routing_update_vrrp_instance' : 'routing_add_vrrp_instance';
            const title = id ? 'Update VRRP Instance' : 'Add VRRP Instance';
            try {
                const r = await apiClient.submit(cmd, data);
                showApiResult(r, { title: title, closeText: 'Close', reloadOnOk: true });
            } catch (e) {
                showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // ── Delete ──────────────────────────────────────────────────────────────
    document.querySelectorAll('[data-js="vrrp-delete"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this VRRP instance?', {
                title: 'Confirm Delete', closeText: 'Cancel',
                showConfirm: true, confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const r = await apiClient.submit('routing_delete_vrrp_instance', { id });
                        showApiResult(r, { title: 'Delete Instance', closeText: 'Close', reloadOnOk: true });
                    } catch (e) {
                        showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });
});
