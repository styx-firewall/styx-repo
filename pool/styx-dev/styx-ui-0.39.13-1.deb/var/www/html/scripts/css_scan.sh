#!/bin/bash
# css_scan.sh — Búsqueda simple: extrae selectores CSS y verifica
# si el nombre aparece literalmente en el código (PHP, JS).
#
# Uso:
#   ./scripts/css_scan.sh                     → analiza todos los CSS
#   ./scripts/css_scan.sh nombre-clase        → busca ese término en el código
#   ./scripts/css_scan.sh archivo.css         → analiza un solo CSS

set -uo pipefail

CSS_DIR="tpl/default/css"
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# ── Buscar un término concreto en el código ─────────────────────────────
search_term() {
    local term="$1"
    echo -e "${YELLOW}Buscando \"${term}\" en *.php *.js...${NC}"
    local matches
    matches=$(grep -rnF "$term" . --include="*.php" --include="*.js" 2>/dev/null)
    if [ -z "$matches" ]; then
        echo -e "${RED}  No encontrado en ningún archivo.${NC}"
    else
        echo "$matches" | head -40
        local count; count=$(echo "$matches" | wc -l)
        [ "$count" -gt 40 ] && echo -e "  ... y $((count - 40)) coincidencias más."
        echo -e "  ${GREEN}Total: ${count} coincidencias.${NC}"
    fi
}

# ── Extraer selectores de un CSS (devuelve "tipo:nombre" por línea) ─────
# tipo: class o id
extract_selectors() {
    local css_file="$1"
    local tmp; tmp=$(mktemp)

    # Clases: .foo (empieza con letra → excluye .5rem)
    grep -h '\{' "$css_file" 2>/dev/null \
        | grep -ohP '\.([a-zA-Z][a-zA-Z0-9_-]+)' \
        | sed 's/^\./class:/' >> "$tmp"

    # IDs: #bar (empieza con letra, excluye colores hex puros)
    grep -h '\{' "$css_file" 2>/dev/null \
        | grep -ohP '#([a-zA-Z][a-zA-Z0-9_-]+)' \
        | grep -vP '^#[0-9a-fA-F]{3,8}$' \
        | sed 's/^#/id:/' >> "$tmp"

    sort -u "$tmp"
    rm -f "$tmp"
}

# ── Verdadero/falso: ¿existe el término en el código? ───────────────────
exists_in_code() {
    local term="$1"
    grep -rqF "$term" . --include="*.php" --include="*.js" 2>/dev/null
}

# ── Analizar un solo CSS (modo detallado) ───────────────────────────────
analyze_one() {
    local css_file="$1"
    local name; name=$(basename "$css_file")

    local selectors; selectors=$(extract_selectors "$css_file")
    local total; total=$(echo "$selectors" | grep -c . 2>/dev/null || echo 0)

    local found=0 unused_list=""

    while IFS= read -r line; do
        [ -z "$line" ] && continue
        local type="${line%%:*}"
        local term="${line#*:}"
        if exists_in_code "$term"; then
            ((found++)) || true
        else
            local prefix="."
            [ "$type" = "id" ] && prefix="#"
            unused_list="${unused_list}      ${prefix}${term}\n"
        fi
    done <<< "$selectors"

    local unused=$((total - found))

    if [ "$unused" -eq 0 ]; then
        echo -e "  ${GREEN}✓${NC} ${name}: ${total}/${total} usados"
    else
        echo -e "  ${RED}${unused}/${total}${NC} sin uso — ${name}:"
        echo -e "$unused_list"
    fi
}

# ── Main ─────────────────────────────────────────────────────────────────

echo -e "${YELLOW}═══ CSS Scan — búsqueda literal ═══${NC}"
echo -e "Ignorando: ${BLUE}default.css${NC} (auto-generado)"
echo ""

# ── Caso: argumento es un término de búsqueda (no es archivo) ──────────
if [ $# -ge 1 ]; then
    arg="$1"
    # Si es un archivo CSS existente, analizarlo
    if [ -f "$arg" ] && [[ "$arg" == *.css ]]; then
        analyze_one "$arg"
        exit 0
    elif [ -f "$CSS_DIR/$arg" ]; then
        analyze_one "$CSS_DIR/$arg"
        exit 0
    else
        # Tratarlo como término de búsqueda
        search_term "$arg"
        exit 0
    fi
fi

# ── Caso: sin argumentos → analizar todos ──────────────────────────────
total_files=0
total_sel=0
total_unused=0

for css in "$CSS_DIR"/*.css; do
    [ -f "$css" ] || continue
    [[ "$(basename "$css")" == "default.css" ]] && continue

    selectors=$(extract_selectors "$css")
    # Saltar archivos sin selectores (solo variables, comentarios, etc.)
    [ -z "$selectors" ] && continue
    sel_count=$(echo "$selectors" | grep -c . 2>/dev/null)
    [ "$sel_count" -eq 0 ] 2>/dev/null && continue
    found=0

    while IFS= read -r line; do
        [ -z "$line" ] && continue
        term="${line#*:}"
        if exists_in_code "$term"; then
            ((found++)) || true
        fi
    done <<< "$selectors"

    unused=$((sel_count - found))
    total_sel=$((total_sel + sel_count))
    total_unused=$((total_unused + unused))
    total_files=$((total_files + 1))

    if [ "$unused" -eq 0 ]; then
        echo -e "  ${GREEN}✓${NC} $(basename "$css"): ${sel_count} ok"
    else
        echo -e "  ${RED}${unused}/${sel_count}${NC} $(basename "$css")"
        while IFS= read -r line; do
            [ -z "$line" ] && continue
            type="${line%%:*}"
            term="${line#*:}"
            if ! exists_in_code "$term"; then
                prefix="."
                [ "$type" = "id" ] && prefix="#"
                echo -e "      ${prefix}${term}"
            fi
        done <<< "$selectors"
        echo ""
    fi
done

echo -e "${YELLOW}═══ Resumen ═══${NC}"
echo -e "Archivos CSS:       ${total_files}"
echo -e "Selectores totales: ${total_sel}"
echo -e "Sin uso aparente:   ${RED}${total_unused}${NC}"
if [ "$total_sel" -gt 0 ]; then
    echo -e "Tasa de uso:        ${GREEN}$((100 - total_unused * 100 / total_sel))%${NC}"
fi
echo ""
echo -e "${YELLOW}Uso rápido:${NC}"
echo -e "  ./scripts/css_scan.sh ${BLUE}nombre-clase${NC}    → buscar un término"
echo -e "  ./scripts/css_scan.sh ${BLUE}default-leds.css${NC} → analizar un solo CSS"
