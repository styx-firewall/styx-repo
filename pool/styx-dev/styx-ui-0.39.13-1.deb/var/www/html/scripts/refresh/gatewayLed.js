export function updateGatewayLed(cmd) {
    //console.log('System leds', cmd);
    const led = document.getElementById('gateway_status');
    if (!led) {
        console.error('LED element not found');
        return;
    }

    // Set default class
    led.className = 'led-gateway';

    // Default values (negative)
    let led_status = 'led-red-on';
    let blink_status = '';
    let gw_latency_recv = 'N/A';
    let gw_latency_response = 'N/A';
    let gw_version = 'N/A';
    let rtt = 'N/A';
    // Only process if ping is successful
    if (
        cmd &&
        cmd.status === 'success' &&
        cmd.method === 'gateway-daemon.ping' &&
        cmd.id === 'ping' &&
        cmd.result
    ) {
        // Wrap metric computation in try/catch: if any field is missing or
        // malformed, silently fall through to the red-LED defaults. This runs
        // on every refresh cycle so it must never produce alerts or modals.
        try {
            // The backend should return:
            // - cmd.result.client_timestamp (seconds with decimals)
            // - cmd.result.backend_proc_ms (or legacy backend_recv_ms) (ms, float)
            // RTT is computed client-side: Date.now() - client_timestamp * 1000
            // Network send+return = RTT - backend_proc_ms
            const nowMs = Date.now();
            const clientTimestampSec = parseFloat(cmd.result.client_timestamp);

            // Accept either `backend_proc_ms` (new) or `backend_recv_ms` (old).
            let backendRecvRaw = null;
            if (cmd.result.backend_proc_ms !== undefined) {
                backendRecvRaw = cmd.result.backend_proc_ms;
            } else if (cmd.result.backend_recv_ms !== undefined) {
                backendRecvRaw = cmd.result.backend_recv_ms;
            }
            const backendMs = backendRecvRaw !== null
                ? parseFloat(backendRecvRaw)
                : NaN;

            let clientTimestampMs = null;
            let latencyRecv = null;
            let latencyResponse = null;
            let totalLatency = null;

            if (!isNaN(clientTimestampSec)) {
                clientTimestampMs = clientTimestampSec * 1000;
            }

            // RTT observed by the browser
            let rttMs = null;
            if (typeof clientTimestampMs === 'number') {
                rttMs = nowMs - clientTimestampMs;
            }

            let backendProcessingMs = null;
            if (!isNaN(backendMs)) {
                backendProcessingMs = backendMs;
            }

            // Network send+return = RTT - backend processing
            let networkSendReturnMs = null;
            if (
                typeof rttMs === 'number' &&
                typeof backendProcessingMs === 'number'
            ) {
                const net = rttMs - backendProcessingMs;
                if (net >= 0) {
                    networkSendReturnMs = net;
                }
            }

            // Map derived values to display variables
            if (typeof rttMs === 'number') {
                totalLatency = rttMs;
            }

            latencyRecv = backendProcessingMs;
            latencyResponse = networkSendReturnMs;

            // RTT → LED colour + display string
            // Use conservative, medium-agnostic thresholds that indicate
            // potential overload regardless of link type. Prioritise backend
            // processing slowness as a critical condition.
            // - Backend processing >= 200ms -> RED
            // - Network portion >= 300ms -> RED
            // - RTT >= 300ms -> RED
            // - RTT 100-300ms -> ORANGE
            // - RTT < 100ms -> GREEN
            if (typeof totalLatency === 'number') {
                rtt = totalLatency.toFixed(2) + ' ms';

                const netMs = (typeof latencyResponse === 'number') ? latencyResponse : null;
                const backendMs = (typeof latencyRecv === 'number') ? latencyRecv : null;

                // Backend slow is critical
                if (typeof backendMs === 'number' && backendMs >= 200) {
                    led_status = 'led-red';
                } else if (typeof netMs === 'number' && netMs >= 300) {
                    // Network dominates and is very high
                    led_status = 'led-red';
                } else if (totalLatency >= 300) {
                    led_status = 'led-red';
                } else if (totalLatency >= 100) {
                    led_status = 'led-orange';
                } else {
                    led_status = 'led-green';
                }
            }
            // else: defaults already set to led-red-on / 'N/A'

            blink_status = 'blink2';

            if (typeof latencyRecv === 'number') {
                gw_latency_recv = latencyRecv.toFixed(2) + ' ms';
            }
            if (typeof latencyResponse === 'number') {
                gw_latency_response = latencyResponse.toFixed(2) + ' ms';
            }
            if (
                typeof cmd.result.version === 'string' &&
                cmd.result.version.trim().length > 0
            ) {
                gw_version = cmd.result.version;
            }
        } catch (e) {
            // Computation failed — keep red-LED defaults, show error in title
            console.warn('gatewayLed: metric computation failed', e);
            rtt = 'Error';
            gw_latency_recv = 'Error';
            gw_latency_response = 'Error';
        }
    }

    // Apply classes and the title
    led.classList.add(led_status);
    if (blink_status) {
        led.classList.add(blink_status);
    }

    const titleParts = [
        `Gw Version ${gw_version}`,
        `RTT: ${rtt}`,
        `Gw Latency (Proc | Network): ${gw_latency_recv} | ${gw_latency_response}`
    ];
    led.title = titleParts.join(' | ');
}
