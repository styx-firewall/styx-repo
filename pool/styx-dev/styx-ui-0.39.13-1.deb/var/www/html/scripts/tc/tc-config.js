// tc-config.js
// Handles TC config page: qdisc edit/delete, channel add/delete, child qdisc toggle.

document.addEventListener('DOMContentLoaded', () => {

    // ─── Child qdisc params toggle ──────────────────────────────────────

    const qdiscSelect = document.getElementById('child-qdisc-kind-select');
    const paramsInput = document.getElementById('child-qdisc-params-input');

    if (qdiscSelect && paramsInput) {
        function toggleParams() {
            if (qdiscSelect.value && qdiscSelect.value !== '') {
                paramsInput.style.display = '';
            } else {
                paramsInput.style.display = 'none';
                paramsInput.value = '';
            }
        }
        qdiscSelect.addEventListener('change', toggleParams);
        toggleParams();
    }
});
// Handling for TC configuration page (forms, modals, delete/edit handlers)

function createEditQdiscModal(ifaceUuid, kind, handle, params) {
    const qdiscOptions = [
        { value: 'pfifo_fast', label: 'PFIFO_FAST' },
        { value: 'noqueue', label: 'NOQUEUE' },
        { value: 'htb', label: 'HTB' },
        { value: 'tbf', label: 'TBF' },
        { value: 'fq_codel', label: 'FQ_CoDel' },
        { value: 'cake', label: 'CAKE' },
        { value: 'netem', label: 'NetEm' },
        { value: 'prio', label: 'PRIO' },
        { value: 'hfsc', label: 'HFSC' }
    ];

    const form = document.createElement('form');
    form.id = 'edit-qdisc-form';
    form.style.cssText = 'display:flex;flex-wrap:wrap;gap:1rem;min-width:350px;';

    const hiddenIfaceUuid = document.createElement('input');
    hiddenIfaceUuid.type = 'hidden';
    hiddenIfaceUuid.name = 'interface_uuid';
    hiddenIfaceUuid.value = ifaceUuid;
    form.appendChild(hiddenIfaceUuid);

    const hiddenHandle = document.createElement('input');
    hiddenHandle.type = 'hidden';
    hiddenHandle.name = 'handle';
    hiddenHandle.value = handle;
    form.appendChild(hiddenHandle);

    // Qdisc selector
    const qdiscDiv = document.createElement('div');
    qdiscDiv.style.flex = '1';

    const qdiscLabel = document.createElement('label');
    qdiscLabel.className = 'form-label';
    qdiscLabel.textContent = 'Qdisc:';
    qdiscDiv.appendChild(qdiscLabel);

    const qdiscSelect = document.createElement('select');
    qdiscSelect.className = 'form-select';
    qdiscSelect.name = 'kind';
    qdiscSelect.id = 'edit-qdisc-kind';

    qdiscOptions.forEach(q => {
        const option = document.createElement('option');
        option.value = q.value;
        option.textContent = q.label;
        if (kind === q.value) {
            option.selected = true;
        }
        qdiscSelect.appendChild(option);
    });

    qdiscDiv.appendChild(qdiscSelect);
    form.appendChild(qdiscDiv);

    // Parameters input
    const paramsDiv = document.createElement('div');
    paramsDiv.style.flex = '2';

    const paramsLabel = document.createElement('label');
    paramsLabel.className = 'form-label';
    paramsLabel.textContent = 'Parameters:';
    paramsDiv.appendChild(paramsLabel);

    const paramsInput = document.createElement('input');
    paramsInput.type = 'text';
    paramsInput.className = 'form-control';
    paramsInput.name = 'params';
    paramsInput.value = params;
    paramsDiv.appendChild(paramsInput);

    const helpDiv = document.createElement('div');
    helpDiv.style.cssText = 'font-size:0.9em;color:#888;margin-top:0.2em;';
    helpDiv.textContent = 'For TBF: ';

    const boldRate = document.createElement('b');
    boldRate.textContent = 'rate';
    helpDiv.appendChild(boldRate);

    helpDiv.appendChild(document.createTextNode(' and '));

    const boldBurst = document.createElement('b');
    boldBurst.textContent = 'burst';
    helpDiv.appendChild(boldBurst);

    helpDiv.appendChild(document.createTextNode(' are required, and '));

    const boldLatency = document.createElement('b');
    boldLatency.textContent = 'latency';
    helpDiv.appendChild(boldLatency);

    helpDiv.appendChild(document.createTextNode(' '));

    const uOr = document.createElement('u');
    uOr.textContent = 'or';
    helpDiv.appendChild(uOr);

    helpDiv.appendChild(document.createTextNode(' '));

    const boldLimit = document.createElement('b');
    boldLimit.textContent = 'limit';
    helpDiv.appendChild(boldLimit);

    helpDiv.appendChild(document.createTextNode(' (one of them). Example: '));

    const codeExample = document.createElement('code');
    codeExample.textContent = 'rate:100mbit, burst:1mbit, latency:20ms';
    helpDiv.appendChild(codeExample);

    paramsDiv.appendChild(helpDiv);
    form.appendChild(paramsDiv);

    // Submit button
    const btnDiv = document.createElement('div');
    btnDiv.style.cssText = 'flex:1;align-self:flex-end;';

    const submitBtn = document.createElement('button');
    submitBtn.type = 'submit';
    submitBtn.className = 'btn btn-success';
    submitBtn.textContent = 'Save changes';
    btnDiv.appendChild(submitBtn);

    form.appendChild(btnDiv);

    return form;
}

// TBF validation (strict)
function parseParamsString(str) {
    const out = {};
    if (!str) return out;
    str.split(',').forEach(part => {
        const p = part.trim();
        if (!p) return;
        const idx = p.indexOf(':');
        if (idx === -1) return;
        const k = p.slice(0, idx).trim();
        const v = p.slice(idx + 1).trim();
        if (k) out[k.toLowerCase()] = v;
    });
    return out;
}

function validateTbfParams(paramsStr) {
    const p = parseParamsString(paramsStr || '');
    if (!p.rate) throw new Error('TBF requires `rate` parameter');
    if (!p.burst) throw new Error('TBF requires `burst` parameter');
    if (!p.latency && !p.limit) throw new Error('TBF requires either `latency` or `limit` parameter');
    return true;
}

function attachEditQdiscHandlers() {
    const qdiscSelect = document.getElementById('edit-qdisc-kind');
    const paramsInput = document.querySelector('#edit-qdisc-form input[name="params"]');
    const originalQdisc = qdiscSelect.value;

    function updateParamsState() {
        if (qdiscSelect.value === 'pfifo_fast') {
            paramsInput.value = '';
            paramsInput.disabled = true;
            paramsInput.setAttribute('readonly', 'readonly');
        } else {
            paramsInput.disabled = false;
            paramsInput.removeAttribute('readonly');
        }
    }

    qdiscSelect.addEventListener('change', function() {
        if (qdiscSelect.value !== originalQdisc) {
            paramsInput.value = '';
        }
        updateParamsState();
    });

    updateParamsState();

    paramsInput.addEventListener('keydown', function(e) {
        if (qdiscSelect.value === 'pfifo_fast') {
            e.preventDefault();
        }
    });

    paramsInput.addEventListener('paste', function(e) {
        if (qdiscSelect.value === 'pfifo_fast') {
            e.preventDefault();
        }
    });
}


document.addEventListener('DOMContentLoaded', () => {
    // Delete Qdisc - event delegation
    document.addEventListener('click', async (e) => {
        const btn = e.target.closest('.js-delete-qdisc');
        if (!btn) return;

        e.preventDefault();
        const ifaceUuid = btn.dataset.ifaceUuid;

        if (!ifaceUuid) return;
        if (!confirm('Are you sure you want to delete this Qdisc?')) return;

        const data = { interface_uuid: ifaceUuid };

            try {
                const result = await apiClient.submit('delete_tc_qdisc', data);
                window.tcShowResult(result, { title: 'Delete Qdisc', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                window.tcShowResult({ ok: false, msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
    });

    // Edit Qdisc - event delegation with secure modal
    document.addEventListener('click', function(e) {
        const btn = e.target.closest('.js-edit-qdisc');
        if (!btn) return;

        e.preventDefault();
        const ifaceUuid = btn.dataset.ifaceUuid;
        const kind = btn.dataset.kind;
        const handle = btn.dataset.handle;
        const params = btn.dataset.params;

        const form = createEditQdiscModal(ifaceUuid, kind, handle, params);

        showModal(form, {
            title: 'Edit Qdisc',
            closeText: 'Close'
        });

        setTimeout(() => {
            attachEditQdiscHandlers();

            const editForm = document.getElementById('edit-qdisc-form');
            if (editForm) {
                editForm.addEventListener('submit', async function(ev) {
                    ev.preventDefault();
                    const formData = new FormData(editForm);
                    const data = {};

                    for (const [key, value] of formData.entries()) {
                        if (value !== '' && value !== null && value !== undefined) {
                            data[key] = value;
                        }
                    }

                    if (data.kind === 'tbf') {
                        try {
                            validateTbfParams(data.params);
                        } catch (err) {
                            window.tcShowResult({ ok: false, msg: err.message }, { title: 'Validation error', closeText: 'Close' });
                            return;
                        }
                    }

                    try {
                        const result = await apiClient.submit('edit_tc_qdisc', data);
                        window.tcShowResult(result, { title: 'Edit Qdisc', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        window.tcShowResult({ ok: false, msg: err.message }, { title: 'Error', closeText: 'Close' });
                    }
                });
            }
        }, 50);
    });
});
