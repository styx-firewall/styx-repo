// dr: 2025-12-01
document.addEventListener('DOMContentLoaded', function () {
	// Delegate click events for delete buttons
	document.body.addEventListener('click', function (ev) {
		const btn = ev.target.closest('.btn-delete');
		if (!btn) return;
		ev.preventDefault();

		const certId = btn.getAttribute('data-cert-id');
		if (!certId) return;

		if (!confirm('Delete certificate? This action cannot be undone.')) {
			return;
		}

		btn.disabled = true;
		const originalText = btn.textContent;
		btn.textContent = 'Deleting...';

		apiClient.submit('delete_certificate', { id: certId })
		.then(data => {
			if (data && data.status === 'success') {
				const row = btn.closest('tr');
				if (row) row.remove();
			} else {
				showApiResult(data, { title: 'Error', closeText: 'Close' });
				btn.disabled = false;
				btn.textContent = originalText;
			}
		})
		.catch(() => {
			showApiResult({ status: 'error', response_msg: 'Network error while deleting certificate' }, { title: 'Error', closeText: 'Close' });
			btn.disabled = false;
			btn.textContent = originalText;
		});
	});

	// Upload modal logic
	const uploadBtn = document.getElementById('btn-upload-cert');
	const modal = document.getElementById('upload-cert-modal');
	const cancelBtn = document.getElementById('btn-upload-cancel');
	const submitBtn = document.getElementById('btn-upload-submit');
	const singleBox = document.getElementById('upload-single');
	const pairBox = document.getElementById('upload-pair');
	const msgBox = document.getElementById('upload-cert-msg');

	if (uploadBtn && modal) {
		uploadBtn.addEventListener('click', function () {
			modal.style.display = 'flex';
			if (msgBox) msgBox.textContent = '';
			// Ensure visibility state is correct when opening modal
			if (typeof updateUploadVisibility === 'function') updateUploadVisibility();
		});
	}
	if (cancelBtn && modal) {
		cancelBtn.addEventListener('click', function () {
			modal.style.display = 'none';
		});
	}

	// Toggle single/pair inputs — use classList because CSS uses `.hidden { display: none !important; }`
	function updateUploadVisibility() {
		const typeEl = document.querySelector('input[name="upload-type"]:checked');
		const type = typeEl ? typeEl.value : 'single';
		if (type === 'single') {
			if (singleBox) {
				singleBox.classList.remove('hidden');
				singleBox.style.display = '';
			}
			if (pairBox) {
				pairBox.classList.add('hidden');
				pairBox.style.display = 'none';
			}
		} else {
			if (singleBox) {
				singleBox.classList.add('hidden');
				singleBox.style.display = 'none';
			}
			if (pairBox) {
				pairBox.classList.remove('hidden');
				pairBox.style.display = '';
			}
		}
	}

	document.querySelectorAll('input[name="upload-type"]').forEach(function (el) {
		el.addEventListener('change', updateUploadVisibility);
	});

	// Ensure initial visibility matches the selected radio on load
	try { updateUploadVisibility(); } catch (e) { /* ignore */ }

	// Helper to read file as base64 (without data: prefix)
	function fileToBase64(file) {
		return new Promise(function (resolve, reject) {
			if (!file) return reject(new Error('No file'));
			const reader = new FileReader();
			reader.onerror = () => reject(new Error('File read error'));
			reader.onload = () => {
				const result = reader.result || '';
				const idx = result.indexOf(',');
				const b64 = idx >= 0 ? result.substr(idx + 1) : result;
				resolve(b64);
			};
			reader.readAsDataURL(file);
		});
	}

	if (submitBtn) {
		submitBtn.addEventListener('click', async function () {
			if (msgBox) msgBox.textContent = '';
			submitBtn.disabled = true;
			const typeEl = document.querySelector('input[name="upload-type"]:checked');
			const type = typeEl ? typeEl.value : 'single';

			try {
				// read optional name and validate
				const nameInput = document.getElementById('cert_name');
				const certName = nameInput ? nameInput.value.trim() : '';
				if (certName) {
					const validNameRe = /^[A-Za-z0-9._\-\s]{1,64}$/;
					if (!validNameRe.test(certName)) {
						if (msgBox) {
							msgBox.style.color = '#e74c3c';
							msgBox.textContent = 'Invalid name: max 64 chars; letters, digits, dot, underscore,' +
																' dash and spaces allowed.';
						}
						submitBtn.disabled = false;
						return;
					}
				}

				if (type === 'single') {
					const input = document.querySelector('input[name="cert_file"]');
					if (!input || !input.files || !input.files[0]) {
						if (msgBox) {
							msgBox.style.color = '#e74c3c';
							msgBox.textContent = 'Please select a certificate file.';
						}
						submitBtn.disabled = false;
						return;
					}
					const certB64 = await fileToBase64(input.files[0]);
					const payload = {
						command: 'upload_certificate',
						type: 'single',
						cert_b64: certB64,
						file_name: input.files[0].name
					};
					if (certName) payload.name = certName;
					const data = await apiClient.submit('upload_certificate', payload);
					if (data && data.status === 'success') {
						if (msgBox) {
							msgBox.style.color = '#2ecc40';
							msgBox.textContent = data.response_msg || 'Certificate uploaded';
						}
						setTimeout(function () { location.reload(); }, 800);
					} else {
						if (msgBox) {
							msgBox.style.color = '#e74c3c';
							msgBox.textContent = data.response_msg || 'Upload failed';
						}
						submitBtn.disabled = false;
					}
				} else {
					const certInput = document.querySelector('input[name="cert_file_pair"]');
					const keyInput = document.querySelector('input[name="key_file_pair"]');
					if (!certInput || !certInput.files[0] || !keyInput || !keyInput.files[0]) {
						if (msgBox) {
							msgBox.style.color = '#e74c3c';
							msgBox.textContent = 'Please select both certificate and key files.';
						}
						submitBtn.disabled = false;
						return;
					}
					const certB64 = await fileToBase64(certInput.files[0]);
					const keyB64 = await fileToBase64(keyInput.files[0]);
					const payload = {
						command: 'upload_certificate',
						type: 'pair',
						cert_b64: certB64,
						key_b64: keyB64,
						file_name: certInput.files[0].name,
						key_file_name: keyInput.files[0].name
					};
					if (certName) payload.name = certName;
					const data = await apiClient.submit('upload_certificate', payload);
					if (data && data.status === 'success') {
						if (msgBox) {
							msgBox.style.color = '#2ecc40';
							msgBox.textContent = data.response_msg || 'Certificate and key uploaded';
						}
						setTimeout(function () { location.reload(); }, 800);
					} else {
						if (msgBox) {
							msgBox.style.color = '#e74c3c';
							msgBox.textContent = data.response_msg || 'Upload failed';
						}
						submitBtn.disabled = false;
					}
				}
			} catch (err) {
				if (msgBox) {
					msgBox.style.color = '#e74c3c';
					msgBox.textContent = (err && err.message) ? err.message : 'Network error';
				}
				submitBtn.disabled = false;
			}
		});
	}

});
