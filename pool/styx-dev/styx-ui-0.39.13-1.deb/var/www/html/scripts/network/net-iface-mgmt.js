document.addEventListener('DOMContentLoaded', function() {
    // Initialize set-picker fields for IPv4/IPv6 address selection
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    // Initialize label-picker fields for VLAN label selection
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }
    // VLAN: Autocomplete interface name from parent + label value
    function updateVlanIfaceName() {
        var parentSelect = document.getElementById('parent_iface_select');
        var vlanHidden = document.getElementById('vlan_id_input');
        var ifaceNameInput = document.getElementById('iface_name_input');
        console.log('[vlan] updateVlanIfaceName called', {
            parentSelect: !!parentSelect,
            vlanHidden: !!vlanHidden,
            vlanValue: vlanHidden ? vlanHidden.value : null,
            dataValue: vlanHidden ? vlanHidden.getAttribute('data-value') : null,
            ifaceNameInput: !!ifaceNameInput
        });
        if (parentSelect && vlanHidden && ifaceNameInput) {
            var parentLabel = '';
            try {
                parentLabel = (parentSelect.selectedOptions && parentSelect.selectedOptions[0])
                    ? parentSelect.selectedOptions[0].text.trim()
                    : parentSelect.options[parentSelect.selectedIndex].text.trim();
            } catch (e) {
                parentLabel = parentSelect.value.trim();
            }
            var vlanValue = vlanHidden.getAttribute('data-value') || '';
            if (parentLabel && vlanValue) {
                ifaceNameInput.value = parentLabel + '.' + vlanValue;
            } else {
                ifaceNameInput.value = '';
            }
            ifaceNameInput.disabled = true;
        }
    }
    var parentSelect = document.getElementById('parent_iface_select');
    var vlanHidden = document.getElementById('vlan_id_input');
    if (parentSelect && vlanHidden) {
        parentSelect.addEventListener('change', updateVlanIfaceName);
        vlanHidden.addEventListener('input', updateVlanIfaceName);
        updateVlanIfaceName();
    }
    // Bridge VLANs visibility: show only when vlan_filtering is enabled
    function updateBridgeVlanVisibility() {
        const cb = document.getElementById('vlan_filtering_checkbox');
        const section = document.getElementById('bridge-vlans-section');
        if (!section || !cb) return;
        if (cb.checked) {
            section.style.display = '';
        } else {
            section.style.display = 'none';
        }
    }
    document.getElementById('vlan_filtering_checkbox')?.addEventListener('change', updateBridgeVlanVisibility);
    updateBridgeVlanVisibility();

    // Enforce PVID constraints: only one pvid per port and native VLAN forced untagged
    function attachBridgeVlanRowListeners(row) {
        if (!row) return;
        const pvidEl = row.querySelector('.bv-pvid');
        const portEl = row.querySelector('.bv-port');
        const untagEl = row.querySelector('.bv-untagged');

        function enforceForRow() {
            // If this row has pvid, ensure untagged is true and disabled
            if (pvidEl && pvidEl.checked) {
                if (untagEl) {
                    untagEl.checked = true;
                    untagEl.disabled = true;
                }
            } else {
                if (untagEl) {
                    untagEl.disabled = false;
                }
            }
        }

        function clearOtherPvidsForPort(portVal) {
            if (!portVal) return;
            const rows = Array.from(document.querySelectorAll('.bridge-vlan-row'));
            for (const r of rows) {
                if (r === row) continue;
                const otherPort = r.querySelector('.bv-port');
                const otherPvid = r.querySelector('.bv-pvid');
                const otherUntag = r.querySelector('.bv-untagged');
                if (otherPort && otherPvid && otherPort.value === portVal && otherPvid.checked) {
                    otherPvid.checked = false;
                    if (otherUntag) otherUntag.disabled = false;
                }
            }
        }

        // When pvid toggled: if checked, clear other pvids on same port and force untagged
        if (pvidEl) {
            pvidEl.addEventListener('change', function() {
                const portVal = portEl ? portEl.value : '';
                if (pvidEl.checked) {
                    clearOtherPvidsForPort(portVal);
                }
                enforceForRow();
            });
        }

        // When port changes: if this row has pvid, ensure other rows for that port have pvid cleared
        if (portEl) {
            portEl.addEventListener('change', function() {
                if (pvidEl && pvidEl.checked) {
                    clearOtherPvidsForPort(portEl.value);
                }
            });
        }

        // Initialize state
        enforceForRow();
    }

    // Attach listeners to existing bridge-vlan rows on load
    document.querySelectorAll('.bridge-vlan-row').forEach(r => attachBridgeVlanRowListeners(r));
    // PPPoE: toggle required on user/pass if noauth is checked
    function togglePppoeRequired() {
        var noauth = document.getElementById('noauth_checkbox');
        var user = document.getElementById('pppoe_user_input');
        var pass = document.getElementById('pppoe_pass_input');
        var checked = noauth && noauth.checked;
        if (user) user.required = !checked;
        if (pass) pass.required = !checked;
    }
    document.getElementById('noauth_checkbox')?.addEventListener('change', togglePppoeRequired);
    togglePppoeRequired();

    // Format backend response for modal
    function formatResponse(result) {
        if (result && typeof result === 'object') {
            if (result.response_msg) return result.response_msg;
            if (result.message) return result.message;
            return '<pre>' + JSON.stringify(result, null, 2) + '</pre>';
        }
        return String(result);
    }
    // Main interface form submit handler
    const mainForm = document.getElementById('iface-form');
    if (mainForm) {
        mainForm.addEventListener('submit', function(e) {
            e.preventDefault();
            // Ensure derived fields are up-to-date (e.g. iface_name for VLAN)
            try { updateVlanIfaceName(); } catch (ignored) {}
            const config = {};
            // Simple fields, excluding the ipv4/ipv6 bracketed ones
            mainForm.querySelectorAll('input, select, textarea').forEach(el => {
                if (!el.name || el.type === 'button' || el.type === 'submit') return;
                // Skip disabled fields (only physical interfaces have disabled MAC)
                if (el.disabled) return;
                // Skip ipv4/ipv6 bracketed inputs here; handled later
                if (/^ipv4\[\d+\]\[(ip|netmask)\]$/.test(el.name)) return;
                if (/^ipv6\[\d+\]\[(ip|prefix)\]$/.test(el.name)) return;

                // Helper: set nested property into config for names like 'pppoe[key]'
                function setNested(name, value) {
                    var m = name.match(/^([^\[]+)\[([^\]]*)\]$/);
                    if (!m) {
                        config[name] = value;
                        return;
                    }
                    var parent = m[1];
                    var key = m[2];
                    // empty key => array push (name[] style)
                    if (key === '') {
                        if (!Array.isArray(config[parent])) config[parent] = [];
                        // If value is an array (from a multi-select), concat so we keep a flat array
                        if (Array.isArray(value)) {
                            config[parent] = config[parent].concat(value);
                        } else {
                            config[parent].push(value);
                        }
                        return;
                    }
                    if (typeof config[parent] !== 'object' || config[parent] === null) config[parent] = {};
                    config[parent][key] = value;
                }

                if (el.type === 'checkbox') {
                    if (el.name === 'status') {
                        config[el.name] = el.checked ? 'up' : 'down';
                    } else {
                        var val = el.checked ? (el.value || '1') : '0';
                        if (el.name.indexOf('[') !== -1) {
                            setNested(el.name, val);
                        } else {
                            config[el.name] = val;
                        }
                    }
                } else {
                    // handle multi-selects as arrays
                    if (el.tagName === 'SELECT' && el.multiple) {
                        var vals = Array.from(el.selectedOptions).map(o => o.value);
                        if (el.name.indexOf('[') !== -1) {
                            // name like 'ports[]'
                            setNested(el.name, vals);
                        } else {
                            config[el.name] = vals;
                        }
                    } else if (el.name.indexOf('[') !== -1) {
                        setNested(el.name, el.value);
                    } else {
                        config[el.name] = el.value;
                    }
                }
            });
            // Capture interface identifiers separately: `iface_name` (display name)
            // and `iface_id` (persistent id used for service bindings).
            const ifaceNameInput = mainForm.querySelector('input[name="iface_name"]');
            const ifaceIdInput = mainForm.querySelector('input[name="iface_id"]');
            if (ifaceNameInput) config.iface_name = ifaceNameInput.value;
            if (ifaceIdInput) config.iface_id = ifaceIdInput.value;

            // UUID validation regex, used by VLAN and other validators below
            const uuidRe = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
            function invalidUuid(v) { return (typeof v === 'string' && v !== '' && !uuidRe.test(v)); }

            // Basic client-side validation for VLAN creation
            // Use explicit iface_subtype provided by the formatter/template.
            if (config.action === 'create' && config.iface_subtype === 'vlan') {
                if (!config.parent_iface) {
                    showModal('Parent interface is required for VLAN creation.', { title: 'Validation error', closeText: 'Close' });
                    return;
                }
                if (!config.vlan_id || !uuidRe.test(config.vlan_id)) {
                    showModal('A VLAN label must be selected.', { title: 'Validation error', closeText: 'Close' });
                    return;
                }
                if (!config.iface_name || config.iface_name.trim() === '') {
                    // try to compute a sensible iface_name using the selected option's label
                    var parentLabel = '';
                    var parentSelectEl = document.querySelector('select[name="parent_iface"]');
                    if (parentSelectEl) {
                        try {
                            parentLabel = (parentSelectEl.selectedOptions && parentSelectEl.selectedOptions[0])
                                ? parentSelectEl.selectedOptions[0].text.trim()
                                : parentSelectEl.options[parentSelectEl.selectedIndex].text.trim();
                        } catch (e) {
                            parentLabel = config.parent_iface;
                        }
                    }
                    var vlanValue = vlanHidden ? (vlanHidden.getAttribute('data-value') || '') : '';
                    var base = parentLabel || config.parent_iface || '';
                    config.iface_name = (base.trim() + '.' + vlanValue).replace(/\.+/, '.');
                }
            }

            // Basic client-side validation for XFRM creation
            if (config.action === 'create' && config.iface_subtype === 'xfrm') {
                if (!config.parent_iface) {
                    showModal('Parent interface is required for XFRM creation.', { title: 'Validation error', closeText: 'Close' });
                    return;
                }
                if (!config.iface_name || config.iface_name.trim() === '') {
                    showModal('Interface name is required for XFRM creation.', { title: 'Validation error', closeText: 'Close' });
                    return;
                }
            }

            // If modifying an existing interface and service binding flags are present,
            // require an `iface_id` to be submitted — controller will reject otherwise.
            if (config.action !== 'create') {
                const hasBindingFlag = Object.prototype.hasOwnProperty.call(config, 'listen_ssh')
                    || Object.prototype.hasOwnProperty.call(config, 'listen_styx_ui');
                if (hasBindingFlag && !config.iface_id) {
                    showModal('Interface id (iface_id) is required to modify service bindings.', {
                        title: 'Error',
                        closeText: 'Close'
                    });
                    return;
                }
            }

            // IPv4: collect selected set IDs from picker hidden inputs named ipv4[]
            const ipv4Selects = Array.from(document.querySelectorAll('#ipv4-block input[type="hidden"][name="ipv4[]"]'));
            const ipv4List = ipv4Selects.map(s => s.value).filter(v => v && v !== '');
            config.ipv4 = ipv4List; // send array of set IDs (may be empty to clear)
            // IPv6: collect selected set IDs from picker hidden inputs named ipv6[]
            const ipv6Selects = Array.from(document.querySelectorAll('#ipv6-block input[type="hidden"][name="ipv6[]"]'));
            const ipv6List = ipv6Selects.map(s => s.value).filter(v => v && v !== '');
            config.ipv6 = ipv6List; // send array of set IDs

                    // Bridge VLANs: gather rows into array only if vlan_filtering is enabled
                    // Clean up any stray keys left by the general form serialization
                    // (e.g. 'bridge_vlans[][vlan_id]' from inputs whose name[] pattern
                    // the setNested helper cannot parse into a proper nested structure).
                    Object.keys(config).forEach(k => {
                        if (/^bridge_vlans\[/.test(k)) delete config[k];
                    });
                    const vlanFilterCb = document.getElementById('vlan_filtering_checkbox');
                    if (vlanFilterCb && vlanFilterCb.checked) {
                        const bridgeVlanRows = Array.from(document.querySelectorAll('.bridge-vlan-row'));
                        const bridgeVlanArr = [];
                        for (const row of bridgeVlanRows) {
                            // ensure per-row listeners enforce PVID constraints before collecting
                            attachBridgeVlanRowListeners(row);
                            const vlanEl = row.querySelector('.bv-vlan-id');
                            const pvidEl = row.querySelector('.bv-pvid');
                            const untagEl = row.querySelector('.bv-untagged');
                            const portEl = row.querySelector('.bv-port');
                            if (!vlanEl) continue;
                            const vlanVal = (vlanEl.value || '').trim();
                            // vlan_id must be a valid label UUID
                            if (vlanVal === '' || !uuidRe.test(vlanVal)) continue;
                            const bv = { vlan_id: vlanVal };
                            if (pvidEl) bv.pvid = !!pvidEl.checked;
                            if (untagEl) bv.untagged = !!untagEl.checked;
                            if (portEl && portEl.value) bv.port = portEl.value;
                            bridgeVlanArr.push(bv);
                        }
                        if (bridgeVlanArr.length > 0) {
                            // Validation: ensure only one pvid per port
                            const pvidMap = {};
                            for (const bv of bridgeVlanArr) {
                                if (bv.port && bv.pvid) {
                                    pvidMap[bv.port] = (pvidMap[bv.port] || 0) + 1;
                                    if (pvidMap[bv.port] > 1) {
                                        showModal('Only one PVID (native VLAN) is allowed per port. Review Bridge VLAN entries.', { title: 'Validation error', closeText: 'Close' });
                                        return;
                                    }
                                }
                            }
                            config.bridge_vlans = bridgeVlanArr;
                        } else {
                            // Explicitly set empty array so the backend clears all VLANs
                            config.bridge_vlans = [];
                        }
                    }

                    // refs are internal-only and not collected from the UI

            // If mode is 'static' but user provided no addresses, reject on client
            // side: backend requires at least one IP for static mode.
            const ipv4Empty = Array.isArray(config.ipv4) && config.ipv4.length === 0;
            const ipv6Empty = Array.isArray(config.ipv6) && config.ipv6.length === 0;
            if (config.ip_mode === 'static' && ipv4Empty && ipv6Empty) {
                showModal('Static IP mode requires at least one IPv4 or IPv6 address. Add an address or change IP mode.', {
                    title: 'Validation error',
                    closeText: 'Close'
                });
                return;
            }
            if (config.action === 'create') {
                config.command = 'create_virtual_interface';
            } else {
                config.command = 'set_iface_config';
            }

            // Enforce strict UUID-only IDs per API: block submit if any referenced
            // interface identifier is missing or not a UUID.

            if (config.parent_iface && invalidUuid(config.parent_iface)) {
                showModal('Parent interface must be a UUID. Please select a valid interface.', { title: 'Validation error', closeText: 'Close' });
                return;
            }
            if (Array.isArray(config.ports)) {
                for (const p of config.ports) {
                    if (typeof p !== 'string' || p === '' || invalidUuid(p)) {
                        showModal('Bridge port values must be UUIDs. Please re-select ports.', { title: 'Validation error', closeText: 'Close' });
                        return;
                    }
                }
            }
            if (Array.isArray(config.slaves)) {
                for (const s of config.slaves) {
                    if (typeof s !== 'string' || s === '' || invalidUuid(s)) {
                        showModal('Bond slave values must be UUIDs. Please re-select slaves.', { title: 'Validation error', closeText: 'Close' });
                        return;
                    }
                }
            }
            if (Array.isArray(config.refs)) {
                for (const r of config.refs) {
                    if (typeof r !== 'string' || r === '' || invalidUuid(r)) {
                        showModal('Refs must be UUIDs.', { title: 'Validation error', closeText: 'Close' });
                        return;
                    }
                }
            }
            if (Array.isArray(config.bridge_vlans)) {
                for (const bv of config.bridge_vlans) {
                    if (bv && bv.vlan_id && typeof bv.vlan_id === 'string' && invalidUuid(bv.vlan_id)) {
                        showModal('Bridge VLAN IDs must be UUIDs (select a VLAN label).', { title: 'Validation error', closeText: 'Close' });
                        return;
                    }
                    if (bv && bv.port && typeof bv.port === 'string' && bv.port !== '' && invalidUuid(bv.port)) {
                        showModal('Bridge VLAN port references must be UUIDs.', { title: 'Validation error', closeText: 'Close' });
                        return;
                    }
                }
            }

            appLog('Submitting config:', config);
            apiClient.submit(config.command || 'set_iface_config', config)
            .then(result => {
                appLog('Submit response:', result);
                if (result.status === 'success') {
                    var msgs = [];
                    if (result.result && typeof result.result === 'object') {
                        Object.values(result.result).forEach(function(cmd) {
                            if (cmd.response_msg) msgs.push(cmd.response_msg);
                        });
                    }
                    showModal(msgs.length ? msgs.join('<br>') : 'Success', {
                        title: 'Success',
                        closeText: 'Close',
                        onClose: () => window.location.reload()
                    });
                } else if (result.status === 'partial') {
                    var parts = [];
                    if (result.result && typeof result.result === 'object') {
                        Object.entries(result.result).forEach(function(_ref) {
                            var id = _ref[0], cmd = _ref[1];
                            var icon = cmd.status === 'success' ? '&#9989;' : '&#10060;';
                            parts.push(icon + ' ' + (cmd.response_msg || id));
                        });
                    }
                    showModal(parts.length ? parts.join('<br>') : 'Completed with warnings', {
                        title: 'Completed with warnings'
                    });
                } else {
                    showModal(formatResponse(result), {
                        title: 'Error',
                        closeText: 'Close'
                    });
                }
            })
            .catch(err => {
                showModal('Error: ' + err.message, {
                    title: 'Error',
                    closeText: 'Close'
                });
            });
        });
    }
    function showBlock(block) {
        if (!block) return;
        block.style.display = '';
        block.classList.remove('im-hide');
    }
    function hideBlock(block) {
        if (!block) return;
        block.style.display = 'none';
        block.classList.add('im-hide');
    }
    function updateIpModeFields() {
        var dhcpCheckbox = document.getElementById('dhcp_enabled');
        var mode = document.getElementById('ip_mode_select')?.value || 'static';
        var staticDiv = document.getElementById('ip_mode_static');
        var dhcpBlock = document.getElementById('dhcp-server-block');
        var dhcpOpts = document.getElementById('dhcp-options');
        if (staticDiv) {
            if (mode === 'static') {
                showBlock(staticDiv);
            } else {
                hideBlock(staticDiv);
            }
        }

        // Hide DHCP server block if mode is 'none'
        if (dhcpBlock) {
            if (mode === 'none') {
                hideBlock(dhcpBlock);
            } else {
                showBlock(dhcpBlock);
            }
        }
        if (dhcpOpts && dhcpBlock && dhcpBlock.style.display === 'none') {
            hideBlock(dhcpOpts);
        }
        // Disable DHCP checkbox if mode is 'static', enable otherwise
        if (dhcpCheckbox) {
            const disableDhcp = (mode === 'static');
            dhcpCheckbox.disabled = disableDhcp;
            if (disableDhcp) {
                dhcpCheckbox.checked = false;
                hideBlock(dhcpOpts);
            }
        }
    }
    document.getElementById('ip_mode_select')?.addEventListener('change', updateIpModeFields);
    updateIpModeFields();

    function updateDhcpOptions() {
        var dhcp = document.getElementById('dhcp_enabled');
        var dhcpOpts = document.getElementById('dhcp-options');
        if (dhcp && dhcpOpts) {
            if (dhcp.checked) {
                showBlock(dhcpOpts);
            } else {
                hideBlock(dhcpOpts);
            }
        }
    }
    document.getElementById('dhcp_enabled')?.addEventListener('change', updateDhcpOptions);
    updateDhcpOptions();

    window.addIpRow = function(type) {
        const block = document.getElementById(type + '-block');
        if (!block) return;
        const tpl = document.getElementById(type + '-picker-template');
        if (!tpl) return;
        const clone = tpl.content.firstElementChild.cloneNode(true);
        block.insertBefore(clone, block.querySelector('button[onclick^=addIpRow]'));
        if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
            window.setsModal.initPickerFields(clone);
        }
    };
    window.removeIpRow = function(btn, type) {
        const row = btn.closest('.' + type + '-row');
        if (row) row.remove();
    };

    // Bridge VLAN row helpers
    window.addBridgeSelfVlanRow = function() {
        const cb = document.getElementById('vlan_filtering_checkbox');
        if (cb && !cb.checked) {
            showModal('Enable VLAN filtering to add Bridge VLAN entries.', { title: 'Validation', closeText: 'Close' });
            return;
        }
        const tpl = document.getElementById('bridge-vlan-self-template');
        const container = document.getElementById('bridge-vlans-self-container');
        if (!tpl || !container) return;
        const clone = tpl.firstElementChild.cloneNode(true);
        clone.style.display = '';
        container.appendChild(clone);
        if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
            window.labelsMgmt.initPickerFields(clone);
        }
    }
    window.addBridgePortVlanRow = function() {
        const cb = document.getElementById('vlan_filtering_checkbox');
        if (cb && !cb.checked) {
            showModal('Enable VLAN filtering to add Bridge VLAN entries.', { title: 'Validation', closeText: 'Close' });
            return;
        }
        const tpl = document.getElementById('bridge-vlan-port-template');
        const container = document.getElementById('bridge-vlans-port-container');
        if (!tpl || !container) return;
        const clone = tpl.firstElementChild.cloneNode(true);
        clone.style.display = '';
        container.appendChild(clone);
        if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
            window.labelsMgmt.initPickerFields(clone);
        }
        attachBridgeVlanRowListeners(clone);
    }
    window.removeBridgeVlanRow = function(btn) {
        const row = btn.closest('.bridge-vlan-row');
        if (row) row.remove();
    }

    // refs UI removed: refs are internal-only

    // Sysctl form submit handler (only send changed values)
    const sysctlForm = document.querySelector('[data-js="iface-sysctl-form"]')?.closest('form');
    if (sysctlForm) {
        sysctlForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const changed = [];
            const sysctlKeys = [];
            sysctlForm.querySelectorAll('.js-sysctl-value').forEach(input => {
                let original = input.getAttribute('data-original');
                let value;
                if (input.type === 'checkbox') {
                    value = input.checked ? '1' : '0';
                } else {
                    value = input.value;
                }
                if (value !== original) {
                    changed.push(value);
                    sysctlKeys.push(input.getAttribute('data-sysctl-key'));
                }
            });
            if (changed.length === 0) {
                showModal('No changes detected.', {
                    title: 'Info',
                    closeText: 'Close'
                });
                return;
            }
            // Get the current interface id (preferred) and name (fallback/compat)
            let iface = '';
            let ifaceId = '';
            const ifaceInput = document.querySelector('input[name="iface_name"]');
            const ifaceIdInput = document.querySelector('input[name="iface_id"]');
            if (ifaceInput) iface = ifaceInput.value;
            if (ifaceIdInput) ifaceId = ifaceIdInput.value;
            const config = {
                command: 'set_iface_sysctl',
                iface_id: ifaceId,
                iface: iface,
                sysctl_keys: sysctlKeys,
                value: changed
            };
            apiClient.submit(config.command || 'set_iface_sysctl', config)
            .then(result => {
                appLog('Sysctl submit response:', result);
                if (result.status === 'success') {
                    showModal(result.response_msg || 'Sysctl updated', {
                        title: 'Success',
                        closeText: 'Close',
                        onClose: () => window.location.reload()
                    });
                } else {
                    showModal(formatResponse(result), {
                        title: 'Error',
                        closeText: 'Close'
                    });
                }
            })
            .catch(err => {
                showModal('Error: ' + err.message, {
                    title: 'Error',
                    closeText: 'Close'
                });
            });
        });
    }
});
