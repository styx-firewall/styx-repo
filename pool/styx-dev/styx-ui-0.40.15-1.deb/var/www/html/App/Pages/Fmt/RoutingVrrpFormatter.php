<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;
use App\Services\Filter;

class RoutingVrrpFormatter
{
    /**
     * @param array<string,mixed> $data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(array $data, array $userCaps = []): array
    {
        $canWrite  = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_save']   = $canWrite;
        $data['can_add']    = $canWrite;

        // Global config display flags
        $config = $data['vrrp_config'] ?? [];
        $config['enabled_checked'] = !empty($config['enabled']) ? 'checked' : '';
        $data['vrrp_config'] = $config;

        // Global defaults: pre-compute display flags; keep the raw JSON payload
        // for the JS __vrrpDefaults exactly as the backend sent it.
        $defaults = $data['vrrp_global_defaults'] ?? [];
        $data['vrrp_defaults_json'] = json_encode($defaults ?: []);
        $defaultsEmpty = empty($defaults);
        $defaults['priority'] = $defaults['priority'] ?? 100;
        $defaults['advertisement_interval'] = $defaults['advertisement_interval'] ?? 1000;
        $defaults['preempt_checked']  = ($defaultsEmpty || !empty($defaults['preempt'])) ? 'checked' : '';
        $defaults['shutdown_checked'] = !empty($defaults['shutdown']) ? 'checked' : '';
        $defaults['checksum_checked'] = ($defaultsEmpty || !empty($defaults['checksum_with_ipv4_pseudoheader'])) ? 'checked' : '';
        $data['vrrp_global_defaults'] = $defaults;

        $instances = $data['vrrp_instances'] ?? [];
        foreach ($instances as &$inst) {
            $inst['can_delete'] = $canDelete;
            // Display-only classification of the live v4/v6 FSM status, only
            // for address families that are actually active (have VIPs).
            $st = $inst['status'] ?? null;
            foreach (['v4', 'v6'] as $af) {
                $inst["{$af}_status"] = null;
                $inst["{$af}_bg_class"] = null;
                if ($st && isset($st[$af]['status']) && !empty($st[$af]['addresses'])) {
                    $inst["{$af}_status"] = $st[$af]['status'];
                    $inst["{$af}_bg_class"] = self::vrrpStateBgClass($st[$af]['status']);
                }
            }

            $inst['interface_label']    = (string)($inst['interface_display']['name'] ?? $inst['interface'] ?? '');
            $inst['vips_html']          = self::vipsHtml($inst);
            $inst['status_badge_html']  = self::statusBadgeHtml($inst);
            $inst['preempt_flag']       = empty($inst) || !empty($inst['preempt']) ? '1' : '0';
            $inst['shutdown_flag']      = !empty($inst['shutdown']) ? '1' : '0';
            $inst['checksum_flag']      = empty($inst) || !empty($inst['checksum_with_ipv4_pseudoheader']) ? '1' : '0';
            // Escaped for use inside a single-quoted data-detail attribute.
            $inst['detail_json']        = Filter::escHtml((string) json_encode($inst));
        }
        unset($inst);
        $data['vrrp_instances'] = $instances;

        return $data;
    }

    /**
     * Build the VIPs display cell: one line per address family, '-' when absent.
     *
     * @param array<string,mixed> $inst
     */
    private static function vipsHtml(array $inst): string
    {
        $groups = [];
        foreach (['ip_addresses_set_display', 'ipv6_addresses_set_display'] as $field) {
            $d = $inst[$field] ?? null;
            if (empty($d) || !is_array($d)) {
                continue;
            }
            $parts = [];
            if (!empty($d['family'])) {
                $parts[] = '<span class="set-type">' . Filter::escHtml((string)$d['family']) . '</span>';
            }
            if (!empty($d['name'])) {
                $parts[] = '<span class="set-name">' . Filter::escHtml((string)$d['name']) . '</span>';
            }
            if (!empty($d['value'])) {
                $parts[] = '<span class="set-type">' . Filter::escHtml((string)$d['value']) . '</span>';
            }
            $groups[] = $parts ? implode(' ', $parts) : '-';
        }
        return !empty($groups) ? implode('<br>', $groups) : '-';
    }

    /**
     * Build the status badge cell (shutdown / live v4-v6 FSM / dimmed '-').
     *
     * @param array<string,mixed> $inst
     */
    private static function statusBadgeHtml(array $inst): string
    {
        if (!empty($inst['shutdown'])) {
            return '<span class="std-badge std-badge--muted std-badge--dot">shutdown</span>';
        }
        if (!empty($inst['v4_bg_class']) || !empty($inst['v6_bg_class'])) {
            $html = '';
            if (!empty($inst['v4_bg_class'])) {
                $html .= '<span class="std-badge std-badge--' . $inst['v4_bg_class'] . ' std-badge--dot">v4 ' . $inst['v4_status'] . '</span>';
            }
            if (!empty($inst['v6_bg_class'])) {
                $html .= '<span class="std-badge std-badge--' . $inst['v6_bg_class'] . ' std-badge--dot">v6 ' . $inst['v6_status'] . '</span>';
            }
            return $html;
        }
        return '<span class="text-dim">-</span>';
    }

    /**
     * Background badge variant for a VRRP FSM state.
     *
     * Display-only classification of the real vrrpd state. Unknown values map
     * to 'warning' so a state we don't know is never shown green.
     */
    private static function vrrpStateBgClass(?string $state): string
    {
        switch (strtolower((string)($state ?? ''))) {
            case 'master':
                return 'success';
            case 'backup':
                return 'warning';
            case 'initialize':
                return 'danger';
            default:
                return 'warning';
        }
    }
}
