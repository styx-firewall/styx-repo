<?php

namespace App\Controllers\Submit;

use App\Services\AuthService;
use App\Services\Filter;
use App\Services\UserProfileService;
use App\Controllers\BaseController;

class UserSubmitController extends BaseController
{

    public function login(array $data)
    {
        $username = $data['username'] ?? '';
        $password = $data['password'] ?? '';
        $realm = $data['realm'] ?? 'pam';
        if (!$username || !$password) {
            return $this->baseError('Username and password required');
        }
        $commands = [
            [
                'method' => 'auth.user-login',
                'id' => 'user_login',
                'data' => [
                    'username' => $username,
                    'password' => $password,
                    'realm' => $realm,
                ],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));

        // Envelope-level error (gateway unreachable, invalid response): return it
        // as-is so result.msg and error_code (GATEWAY_UNREACHABLE) reach the client.
        // Per-command errors have a commands key and must fall through to the
        // FORBIDDEN handling below.
        if (($resp['status'] ?? null) === 'error' && empty($resp['commands'])) {
            return $resp;
        }

        $cmd_response = $resp['commands']['user_login'] ?? null;
        if ($cmd_response && ($cmd_response['status'] ?? 'error') === 'success') {
            $result = $cmd_response['result'] ?? [];
            $token = $result['token'] ?? null;
            if ($token) {
                $this->logService->info("User $username logged in successfully");
                $auth = $this->ctx->get(AuthService::class);
                $auth->setUserToken($token);
                $auth->setUsername($result['username'] ?? $username);

                // Profile is now included in the login response  -  no separate request needed.
                $profileData = $result['profile'] ?? [];
                if (!is_array($profileData)) {
                    $profileData = [];
                }
                UserProfileService::storeProfileInSession($result['username'] ?? $username, $profileData);

                // Role and capabilities from backend
                $role = $result['role'] ?? null;
                if ($role !== null && is_string($role) && $role !== '') {
                    $auth->setRole($role);
                }
                $capabilities = $result['capabilities'] ?? [];
                if (is_array($capabilities)) {
                    $auth->setCapabilities($capabilities);
                }

                return [
                    'status' => 'success',
                    'result' => ['msg' => $cmd_response['result']['msg'] ?? 'Login successful'],
                    'user' => $result['username'] ?? $username,
                    'token' => $token
                ];
            } else {
                $this->logService->error("Login failed for user $username: No token in response");
                return $this->baseError('No authentication token received from backend');
            }
        } else {
            $errorCode = $cmd_response['error_code'] ?? null;
            if ($errorCode === 'FORBIDDEN') {
                $this->logService->error(
                    "Login rejected for $username: no role assigned"
                );
                return $this->baseError(
                    $cmd_response['result']['msg'] ?? 'Access denied: no role assigned'
                );
            }
            $this->logService->error(
                "Login failed for user $username: " .
                ($cmd_response['result']['msg'] ?? 'Unknown error')
            );
            return $this->baseError($cmd_response['result']['msg'] ?? 'Incorrect login');
        }
    }

    public function lockUser(array $data)
    {
        $username = $data['username'] ?? null;
        if (!$username) {
            return $this->baseError('Username not provided');
        }
        $commands = [
            [
                'method' => 'user-mgmt.lock_user',
                'id' => 'lock_user',
                'data' => ['username' => $username],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'lock_user');
    }

    public function unlockUser(array $data)
    {
        $username = $data['username'] ?? null;
        if (!$username) {
            return $this->baseError('Username not provided');
        }
        $commands = [
            [
                'method' => 'user-mgmt.unlock_user',
                'id' => 'unlock_user',
                'data' => ['username' => $username],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'unlock_user');
    }

    public function addUser(array $data)
    {
        $commands = [
            [
                'method' => 'user-mgmt.create_user',
                'id' => 'create_user',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'create_user');
    }

    public function editUser(array $data)
    {
        $commands = [
            [
                'method' => 'user-mgmt.edit_user',
                'id' => 'edit_user',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'edit_user');
    }

    public function deleteUser(array $data)
    {
        $username = $data['username'] ?? null;
        if (!$username) {
            return $this->baseError('Username not provided');
        }
        $commands = [
            [
                'method' => 'user-mgmt.delete_user',
                'id' => 'delete_user',
                'data' => ['username' => $username],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'delete_user');
    }

    public function logout(array $data)
    {
        return ['status' => 'success', 'result' => ['msg' => 'Logged out']];
    }

    public function resetPassword(array $data)
    {
        $username = $data['username'] ?? null;
        $newPassword = $data['new_password'] ?? null;
        if (!$username || !$newPassword) {
            return $this->baseError('Username and new password required');
        }
        $commands = [
            [
                'method' => 'user-mgmt.reset_password',
                'id' => 'reset_password',
                'data' => [
                    'username' => $username,
                    'new_password' => $newPassword
                ],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'reset_password');
    }

    public function saveProfile(array $data): array
    {
        $auth = $this->ctx->get(AuthService::class);
        $username = $auth->getUsername();

        if ($username === null) {
            return $this->baseError('No authenticated user in session');
        }

        $profileData = [];

        if (array_key_exists('timezone', $data)) {
            $tz = trim((string)($data['timezone'] ?? ''));
            if ($tz !== '') {
                // Same validator the bootstrap uses when it reads the profile, so a
                // stored value can never be one the reader silently ignores.
                if (Filter::varTimezone($tz) === false) {
                    return $this->baseError("Invalid timezone: $tz");
                }
                $profileData['timezone'] = $tz;
            } else {
                $profileData['timezone'] = null;
            }
        }

        if (array_key_exists('locale', $data)) {
            $locale = trim((string)($data['locale'] ?? ''));
            if ($locale !== '') {
                // Catalogue check, not just shape: `xx-YY` has the right shape but
                // no catalogue has it, and the reader would drop it.
                if (Filter::varLocale($locale) === false) {
                    return $this->baseError("Invalid locale format: $locale");
                }
                $profileData['locale'] = $locale;
            } else {
                $profileData['locale'] = null;
            }
        }

        if (array_key_exists('debug', $data)) {
            $profileData['debug'] = (bool)$data['debug'];
        }

        if (empty($profileData)) {
            return $this->baseError('No valid profile fields provided');
        }

        $commands = [
            [
                'method' => 'user-mgmt.save_profile',
                'id' => 'save_user_profile',
                'data' => $profileData,
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));

        if (($resp['status'] ?? null) === 'error' && empty($resp['commands'])) {
            return $resp;
        }

        $cmdResp = $resp['commands']['save_user_profile'] ?? null;
        if (!$cmdResp || ($cmdResp['status'] ?? 'error') !== 'success') {
            $err = $this->baseError($cmdResp['result']['msg'] ?? 'Failed to save profile');
            if (!empty($cmdResp['error_code'])) {
                $err['error_code'] = $cmdResp['error_code'];
            }
            return $err;
        }

        // Update session cache so the change is visible immediately
        $current = UserProfileService::readProfile($username);
        $merged = array_merge($current, $profileData);
        if (array_key_exists('timezone', $profileData) && $profileData['timezone'] === null) {
            unset($merged['timezone']);
        }
        if (array_key_exists('locale', $profileData) && $profileData['locale'] === null) {
            unset($merged['locale']);
        }
        UserProfileService::storeProfileInSession($username, $merged);

        return ['status' => 'success', 'result' => ['msg' => 'Profile saved']];
    }

    public function setRole(array $data): array
    {
        $username = $data['username'] ?? null;
        $role = $data['role'] ?? null;
        if (!$username || !$role) {
            return $this->baseError('Username and role required');
        }
        $commands = [[
            'method' => 'user-mgmt.set_role',
            'id' => 'set_role',
            'data' => ['username' => $username, 'role' => $role],
        ]];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'set_role');
    }

    public function removeRole(array $data): array
    {
        $username = $data['username'] ?? null;
        if (!$username) {
            return $this->baseError('Username required');
        }
        $commands = [[
            'method' => 'user-mgmt.remove_role',
            'id' => 'remove_role',
            'data' => ['username' => $username],
        ]];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'remove_role');
    }
}
