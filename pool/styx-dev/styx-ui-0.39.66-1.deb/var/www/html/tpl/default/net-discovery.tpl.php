<?php
/**
 * Network Discovery main template.
 * Renders the outer structure - status bar, tabs, and placeholders for
 * per-tab fragment content (loaded via load_tpl).
 * JS: /scripts/network/net-discovery.js
 *
 * @var array<mixed> $tdata
 */

$status      = $tdata['page_data']['service_status'] ?? ['running' => false, 'paused' => false, 'packet_count' => 0];
$hosts_error = $tdata['page_data']['hosts_error'] ?? null;

$running      = (bool)($status['running'] ?? false);
$paused       = (bool)($status['paused'] ?? false);
$packet_count = (int)($status['packet_count'] ?? 0);
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Network Discovery</h1>

        <!-- STATUS BAR -->
        <div class="disc-status-bar">
            <span class="std-badge <?= $running ? ($paused ? 'std-badge--warning' : 'std-badge--success') : 'std-badge--danger' ?>"
                  data-js="disc-status-badge">
                <?php if (!$running): ?>Stopped
                <?php elseif ($paused): ?>Paused
                <?php else: ?>Running
                <?php endif; ?>
            </span>
            <span class="disc-packet-counter">
                Packets: <strong data-js="disc-packet-count"><?= number_format($packet_count) ?></strong>
            </span>
            <span class="disc-status-actions">
                <button type="button" class="std-btn" data-js="disc-btn-sweep" title="Trigger ARP sweep on all subnets">
                    Sweep All
                </button>
                <button type="button" class="std-btn" data-js="disc-btn-traceroute" title="Run traceroute to all hosts">
                    Traceroute All
                </button>
                <button type="button" class="std-btn disc-btn-danger" data-js="disc-btn-prune" title="Remove old hosts">
                    Prune
                </button>
                <input type="number" class="std-input disc-prune-days" id="disc-prune-days"
                       value="7" min="1" max="365"
                       title="Days to keep" />
                <label for="disc-prune-days" class="disc-prune-label">days</label>
                <button type="button" class="std-btn" onclick="window.location.reload()" title="Refresh data now">
                    Refresh
                </button>
            </span>
        </div>

        <?php if (!empty($hosts_error)): ?>
        <div class="notice-warn" data-js="disc-service-warning">
            <?= $hosts_error ?>
        </div>
        <?php endif; ?>

        <!-- TABS -->
        <div class="std-tabs">
            <button type="button" class="std-tab-btn active" data-tab="disc-overview">Overview</button>
            <button type="button" class="std-tab-btn" data-tab="disc-hosts">Hosts</button>
            <button type="button" class="std-tab-btn" data-tab="disc-topology">Topology</button>
            <button type="button" class="std-tab-btn" data-tab="disc-topology-3d">3D Topology</button>
            <button type="button" class="std-tab-btn" data-tab="disc-settings">Settings</button>
        </div>

        <!-- OVERVIEW TAB -->
        <div class="std-tab-panel active" data-tab="disc-overview">
            <?= $tdata['overview_tab'] ?? '' ?>
        </div><!-- /disc-overview -->

        <!-- HOSTS TAB -->
        <div class="std-tab-panel" data-tab="disc-hosts">
            <?= $tdata['hosts_tab'] ?? '' ?>
        </div><!-- /disc-hosts -->

        <!-- TOPOLOGY TAB -->
        <div class="std-tab-panel" data-tab="disc-topology">
            <?= $tdata['topology_tab'] ?? '' ?>
        </div><!-- /disc-topology -->

        <!-- 3D TOPOLOGY TAB -->
        <div class="std-tab-panel disc-topo-3d-panel" data-tab="disc-topology-3d">
            <?= $tdata['topology_3d_tab'] ?? '' ?>
        </div><!-- /disc-topology-3d -->

        <!-- SETTINGS TAB -->
        <div class="std-tab-panel" data-tab="disc-settings">
            <?= $tdata['settings_tab'] ?? '' ?>
        </div><!-- /disc-settings -->

    </main>
</div>

<!-- Host detail modal (populated by JS) -->
<div id="disc-host-modal">
    <div data-js="disc-modal-content"></div>
</div>
