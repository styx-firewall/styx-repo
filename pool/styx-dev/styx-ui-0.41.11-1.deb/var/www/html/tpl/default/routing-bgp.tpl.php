<?php
/**
 * @var array<mixed> $tdata
 * js: scripts/routing/routing-bgp.js
 */
$page_data  = $tdata['page_data'];
$bgp_config = $page_data['bgp_config'] ?? [];
$neighbors  = $page_data['neighbors'] ?? [];
$networks   = $page_data['networks'] ?? [];
$route_maps = $page_data['route_maps'] ?? [];
$prefix_lists = $page_data['prefix_lists'] ?? [];
$peer_groups = $page_data['peer_groups'] ?? [];
$ifaces      = $page_data['bgp_ifaces'] ?? [];
$bfd_profiles = $page_data['bfd_profiles'] ?? [];
$bgp_redistribute = $page_data['bgp_redistribute'] ?? [];
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>BGP</h1>

        <details class="nat-help">
            <summary>Help</summary>
            <div class="nat-help-content">
                <p><strong>BGP (Border Gateway Protocol)</strong> exchanges routing information between autonomous systems (AS). Essential for multi-homed networks, ISP peering, and datacenter fabrics.</p>
                <ul>
                    <li><strong>Configuration:</strong> Set the local AS number, Router ID, and timers. Enable <em>eBGP Requires Policy</em> for security (RFC 8212).</li>
                    <li><strong>Route Reflector:</strong> When acting as a route reflector, pick a <em>Cluster ID</em> label shared by every redundant reflector in the same cluster. Empty = the router-id is used as cluster-id.</li>
                    <li><strong>Multipath / ECMP:</strong> Balance traffic across multiple equal-cost paths with <em>Max Paths</em>. eBGP suits spines/WANs; iBGP suits an internal mesh/reflector. <em>Multipath Relax</em> is required for ECMP between eBGP peers whose AS paths differ in length.</li>
                    <li><strong>Convergence:</strong> <em>Update Delay</em> defers bestpath selection and announcements after a restart/clear until peers establish or the timer expires (reduces CPU spikes with many peers). <em>Network Import Check</em> set to <em>Off</em> advertises a network even before the prefix is present in the routing table.</li>
                    <li><strong>Neighbors:</strong> Each peer needs its IP (address set, host scope) and remote AS. Use route-map in/out to filter or modify routes per peer. Enable BFD for fast failure detection.</li>
                    <li><strong>Networks:</strong> Advertise prefixes into BGP from address sets (network scope). The prefix must exist in the routing table.</li>
                    <li><strong>Peer Groups:</strong> Share common settings (remote AS, route-maps, BFD) across multiple neighbors. Assign neighbors to a group instead of configuring each one individually.</li>
                    <li><strong>Redistribute:</strong> Inject routes from other protocols (connected, static, OSPF, RIP) into BGP, optionally filtered through a route-map.</li>
                </ul>
            </div>
        </details>

        <!-- Global BGP config -->
        <div class="content-box">
            <h2>BGP Configuration</h2>
            <form id="bgp-config-form" class="std-form form-compact" data-js="bgp-config-form">
                <div class="form-row">
                    <div class="form-col form-col--tight">
                        <label for="bgp_enabled">Enabled</label>
                        <label class="std-switch">
                            <input type="checkbox" id="bgp_enabled" name="enabled"
                                <?= !empty($bgp_config['enabled']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col">
                        <label>Router AS</label>
                        <div class="set-picker-field" data-js="label-picker-field" data-set-type="as_number"
                             data-max-select="1" data-label-title="Select AS number">
                            <input type="hidden" id="bgp_router_as" name="router_as"
                                value="<?= $bgp_config['router_as'] ?? '' ?>">
                            <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                data-placeholder="Select AS number">
                                <span class="js-set-picker-label"><?= $bgp_config['router_as_label'] ?></span>
                            </button>
                            <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear<?= $bgp_config['router_as_clear_hidden'] ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </div>
                    <div class="form-col">
                        <label>Router ID</label>
                        <div class="set-picker-field" data-js="label-picker-field" data-set-type="router_id"
                             data-max-select="1" data-label-title="Select Router ID">
                            <input type="hidden" id="bgp_router_id" name="router_id"
                                value="<?= $bgp_config['router_id'] ?? '' ?>">
                            <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                data-placeholder="Select Router ID">
                                <span class="js-set-picker-label"><?= $bgp_config['router_id_label'] ?></span>
                            </button>
                            <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear<?= $bgp_config['router_id_clear_hidden'] ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="bgp_keepalive">Keepalive (s)</label>
                        <input type="number" id="bgp_keepalive" name="keepalive" class="std-input"
                            min="1" max="65535" placeholder="60"
                            value="<?= $bgp_config['keepalive'] ?? '' ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="bgp_hold_time">Hold Time (s)</label>
                        <input type="number" id="bgp_hold_time" name="hold_time" class="std-input"
                            min="0" max="65535" placeholder="180"
                            value="<?= $bgp_config['hold_time'] ?? '' ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="bgp_default_local_pref">Default Local Preference</label>
                        <input type="number" id="bgp_default_local_pref" name="default_local_pref" class="std-input"
                            min="0" max="4294967295" placeholder="100"
                            value="<?= $bgp_config['default_local_pref'] ?? '' ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="bgp_log_neighbor_changes">Log Neighbor Changes</label>
                        <label class="std-switch">
                            <input type="checkbox" id="bgp_log_neighbor_changes" name="log_neighbor_changes"
                                <?= !empty($bgp_config['log_neighbor_changes']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="bgp_always_compare_med">Always Compare MED</label>
                        <label class="std-switch">
                            <input type="checkbox" id="bgp_always_compare_med" name="always_compare_med"
                                <?= !empty($bgp_config['always_compare_med']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="bgp_graceful_restart">Graceful Restart</label>
                        <label class="std-switch">
                            <input type="checkbox" id="bgp_graceful_restart" name="graceful_restart"
                                <?= !empty($bgp_config['graceful_restart']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="bgp_ebgp_requires_policy">eBGP Requires Policy</label>
                        <label class="std-switch">
                            <input type="checkbox" id="bgp_ebgp_requires_policy" name="ebgp_requires_policy"
                                <?= !empty($bgp_config['ebgp_requires_policy']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="bgp_disable_ebgp_connected_route_check">Disable eBGP Connected Check</label>
                        <label class="std-switch">
                            <input type="checkbox" id="bgp_disable_ebgp_connected_route_check" name="disable_ebgp_connected_route_check"
                                <?= !empty($bgp_config['disable_ebgp_connected_route_check']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="bgp_deterministic_med">Deterministic MED</label>
                        <label class="std-switch">
                            <input type="checkbox" id="bgp_deterministic_med" name="deterministic_med"
                                <?= !empty($bgp_config['deterministic_med']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="bgp_show_hostname">Show Hostname</label>
                        <label class="std-switch">
                            <input type="checkbox" id="bgp_show_hostname" name="show_hostname"
                                <?= !empty($bgp_config['show_hostname']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>

                <!-- Route Reflector -->
                <details class="form-section-collapse">
                    <summary>Route Reflector</summary>
                    <fieldset class="form-fieldset">
                        <div class="form-row">
                            <div class="form-col">
                                <label>Cluster ID</label>
                                <div class="set-picker-field" data-js="label-picker-field" data-set-type="cluster_id"
                                     data-max-select="1" data-label-title="Select Cluster ID">
                                    <input type="hidden" id="bgp_cluster_id" name="cluster_id"
                                        value="<?= $bgp_config['cluster_id'] ?? '' ?>">
                                    <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                        data-placeholder="Select Cluster ID">
                                        <span class="js-set-picker-label"><?= $bgp_config['cluster_id_label'] ?></span>
                                    </button>
                                    <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear<?= $bgp_config['cluster_id_clear_hidden'] ?>"
                                        title="Clear selection">&#215;</button>
                                </div>
                                <span class="text-dim">Route-reflector cluster identifier. Must be identical across all redundant route reflectors in the same cluster. Empty = uses the router-id.</span>
                            </div>
                        </div>
                    </fieldset>
                </details>

                <!-- Multipath / ECMP -->
                <details class="form-section-collapse">
                    <summary>Multipath / ECMP</summary>
                    <fieldset class="form-fieldset">
                        <div class="form-row">
                            <div class="form-col form-col--tight">
                                <label for="bgp_maximum_paths">Max Paths (eBGP)</label>
                                <input type="number" id="bgp_maximum_paths" name="maximum_paths" class="std-input"
                                    min="1" max="64" placeholder="1–64"
                                    value="<?= $bgp_config['maximum_paths'] ?? '' ?>">
                                <span class="text-dim">ECMP paths for eBGP (spines/WANs). Empty = FRR default (1).</span>
                            </div>
                            <div class="form-col form-col--tight">
                                <label for="bgp_maximum_paths_ibgp">Max Paths (iBGP)</label>
                                <input type="number" id="bgp_maximum_paths_ibgp" name="maximum_paths_ibgp" class="std-input"
                                    min="1" max="64" placeholder="1–64"
                                    value="<?= $bgp_config['maximum_paths_ibgp'] ?? '' ?>">
                                <span class="text-dim">ECMP paths for iBGP (internal mesh/reflector). Empty = FRR default (1).</span>
                            </div>
                            <div class="form-col form-col--tight">
                                <label for="bgp_multipath_relax">Multipath Relax</label>
                                <label class="std-switch">
                                    <input type="checkbox" id="bgp_multipath_relax" name="multipath_relax"
                                        <?= !empty($bgp_config['multipath_relax']) ? 'checked' : '' ?>>
                                    <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                                </label>
                                <span class="text-dim">Allow ECMP even when AS paths differ in length.</span>
                            </div>
                        </div>
                    </fieldset>
                </details>

                <!-- Convergence -->
                <details class="form-section-collapse">
                    <summary>Convergence</summary>
                    <fieldset class="form-fieldset">
                        <div class="form-row">
                            <div class="form-col form-col--tight">
                                <label for="bgp_update_delay">Update Delay (s)</label>
                                <input type="number" id="bgp_update_delay" name="update_delay" class="std-input"
                                    min="0" max="3600" placeholder="0 (off)"
                                    value="<?= $bgp_config['update_delay'] ?? '' ?>">
                                <span class="text-dim">Read-only after restart/clear until peers establish. Empty or 0 = off.</span>
                            </div>
                            <div class="form-col form-col--tight">
                                <label for="bgp_update_delay_establish_wait">Establish Wait (s)</label>
                                <input type="number" id="bgp_update_delay_establish_wait" name="update_delay_establish_wait" class="std-input"
                                    min="1" max="3600" placeholder="Optional"
                                    value="<?= $bgp_config['update_delay_establish_wait'] ?? '' ?>">
                                <span class="text-dim">Requires Update Delay; must be less than or equal to it.</span>
                            </div>
                            <div class="form-col form-col--tight">
                                <label for="bgp_network_import_check">Network Import Check</label>
                                <select id="bgp_network_import_check" name="network_import_check" class="std-input">
                                    <option value="" <?= $bgp_config['nic_selected_default'] ?>>Default (FRR)</option>
                                    <option value="1" <?= $bgp_config['nic_selected_on'] ?>>On (require route in RIB)</option>
                                    <option value="0" <?= $bgp_config['nic_selected_off'] ?>>Off (announce without RIB check)</option>
                                </select>
                                <span class="text-dim">When Off, announces networks before they appear in the RIB.</span>
                            </div>
                        </div>
                    </fieldset>
                </details>

                <!-- Redistribute -->
                <details class="form-section-collapse">
                    <summary>Redistribute into BGP</summary>
                    <fieldset class="form-fieldset">
                    <?php foreach ($bgp_redistribute as $rr): ?>
                        <div class="form-row">
                            <div class="form-col form-col--tight">
                                <label class="std-checkbox-label">
                                    <input type="checkbox" class="js-redist-proto" value="<?= $rr['proto'] ?>"
                                        <?= $rr['checked'] ?>>
                                    <?= $rr['label'] ?>
                                </label>
                            </div>
                            <div class="form-col">
                                <select class="std-input js-redist-route-map" data-proto="<?= $rr['proto'] ?>"
                                    style="width:auto; min-width:160px;">
                                    <option value="">- No route map -</option>
                                    <?php foreach ($rr['route_maps'] as $rm): ?>
                                    <option value="<?= $rm['id'] ?>"
                                        <?= $rm['selected'] ?>>
                                        <?= $rm['name'] ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-col form-col--tight">
                                <input type="number" class="std-input js-redist-metric" data-proto="<?= $rr['proto'] ?>"
                                    placeholder="Metric" min="0"
                                    value="<?= $rr['metric'] ?>"
                                    style="width:80px;">
                            </div>
                        </div>
                    <?php endforeach; ?>
                    </fieldset>
                </details>
                <div class="form-row">
                <?php if (!empty($page_data['can_save'])): ?>
                <button type="button" class="std-btn" data-js="bgp-save-config">Save Configuration</button>
                <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Neighbors table -->
        <div class="content-box">
            <div class="content-box-header">
                <h2>BGP Neighbors</h2>
                <?php if (!empty($page_data['can_add'])): ?>
                <button type="button" class="std-btn" data-js="bgp-add-neighbor-open">+ Add Neighbor</button>
                <button type="button" class="std-btn" data-js="bgp-resync">Force BGP Re-announcement</button>                
                <?php endif; ?>
            </div>

            <!-- Add neighbor form (hidden) -->
            <div class="content-box" id="bgp-add-neighbor-form" style="display:none;">
                <h2 id="bgp-neighbor-form-title">Add BGP Neighbor</h2>
                <form class="std-form form-compact" data-js="bgp-neighbor-form">
                    <input type="hidden" id="bgp_neighbor_id" value="">
                    <!-- Row 1: Identity + Connection -->
                    <div class="form-row">
                        <div class="form-col form-col--tight">
                            <label>Neighbor IP (address set)</label>
                            <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                                 data-max-select="1" data-filter-scope="host,host_prefix">
                                <input type="hidden" id="bgp_neighbor_ip_set" name="neighbor_ip_set" value="">
                                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select address set">
                                    <span class="js-set-picker-label">Select neighbor address</span>
                                </button>
                                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear selection">&#215;</button>
                            </div>
                        </div>
                        <div class="form-col form-col--tight">
                            <label>Remote AS</label>
                            <div class="set-picker-field" data-js="label-picker-field" data-set-type="as_number"
                                 data-max-select="1" data-label-title="Select AS number">
                                <input type="hidden" id="bgp_neighbor_as" name="remote_as" value="">
                                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select AS number">
                                    <span class="js-set-picker-label">Select AS number</span>
                                </button>
                                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear selection">&#215;</button>
                            </div>
                        </div>
                        <div class="form-col">
                            <label for="bgp_neighbor_desc">Description</label>
                            <input type="text" id="bgp_neighbor_desc" name="description" class="std-input"
                                placeholder="Optional">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bgp_neighbor_ebgp_multihop">EBGP Multihop TTL</label>
                            <input type="number" id="bgp_neighbor_ebgp_multihop" name="ebgp_multihop" class="std-input"
                                min="0" max="255" value="0">
                        </div>
                        <div class="form-col">
                            <label for="bgp_neighbor_update_source">Update Source</label>
                            <select id="bgp_neighbor_update_source" class="std-input">
                                <option value="">- Default -</option>
                                <?php foreach ($ifaces as $iface): ?>
                                <option value="<?= $iface['id'] ?>"><?= $iface['interface'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Row 2: Timers + Capabilities -->
                    <div class="form-row">
                        <div class="form-col form-col--tight">
                            <label for="bgp_neighbor_password">MD5 Password</label>
                            <input type="password" id="bgp_neighbor_password" name="password" class="std-input"
                                autocomplete="new-password" placeholder="Optional">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bgp_neighbor_keepalive">Keepalive (s)</label>
                            <input type="number" id="bgp_neighbor_keepalive" name="keepalive" class="std-input"
                                min="1" max="65535" placeholder="global">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bgp_neighbor_hold_time">Hold Time (s)</label>
                            <input type="number" id="bgp_neighbor_hold_time" name="hold_time" class="std-input"
                                min="0" max="65535" placeholder="global">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bgp_neighbor_next_hop_self">Next-hop Self</label>
                            <label class="std-switch">
                                <input type="checkbox" id="bgp_neighbor_next_hop_self" name="next_hop_self">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bgp_neighbor_soft_reconfig">Soft Reconfig Inbound</label>
                            <label class="std-switch">
                                <input type="checkbox" id="bgp_neighbor_soft_reconfig" name="soft_reconfiguration_inbound">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>

                    <!-- Row 3: BFD + Caps -->
                    <div class="form-row">
                        <div class="form-col form-col--tight">
                            <label for="bgp_neighbor_rr_client">Route Reflector Client</label>
                            <label class="std-switch">
                                <input type="checkbox" id="bgp_neighbor_rr_client" name="route_reflector_client">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <div class="form-col">
                            <label>Address Families</label>
                            <div class="form-row">
                                <label class="std-checkbox-label">
                                    <input type="checkbox" class="js-address-family" value="ipv4_unicast" checked>
                                    IPv4
                                </label>
                                <label class="std-checkbox-label">
                                    <input type="checkbox" class="js-address-family" value="ipv6_unicast">
                                    IPv6
                                </label>
                            </div>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bgp_neighbor_bfd">BFD</label>
                            <label class="std-switch">
                                <input type="checkbox" id="bgp_neighbor_bfd" name="bfd">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bgp_neighbor_bfd_cp_failure">BFD CP Failure</label>
                            <label class="std-switch">
                                <input type="checkbox" id="bgp_neighbor_bfd_cp_failure" name="bfd_check_control_plane_failure">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>

                    <!-- Row 4: BFD params + Policy (logical group: assignments) -->
                    <div class="form-row">
                        <div class="form-col">
                            <label for="bgp_neighbor_bfd_profile">BFD Profile</label>
                            <select id="bgp_neighbor_bfd_profile" class="std-input">
                                <option value="">- None -</option>
                                <?php foreach ($bfd_profiles as $bfp): ?>
                                <option value="<?= $bfp['id'] ?>"><?= $bfp['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="bgp_neighbor_peer_group">Peer Group</label>
                            <select id="bgp_neighbor_peer_group" class="std-input">
                                <option value="">- None -</option>
                                <?php foreach ($peer_groups as $pg): ?>
                                <option value="<?= $pg['id'] ?>"><?= $pg['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="bgp_neighbor_route_map_in">Route Map In</label>
                            <select id="bgp_neighbor_route_map_in" class="std-input">
                                <option value="">- None -</option>
                                <?php foreach ($route_maps as $rm): ?>
                                <option value="<?= $rm['id'] ?>"><?= $rm['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="bgp_neighbor_route_map_out">Route Map Out</label>
                            <select id="bgp_neighbor_route_map_out" class="std-input">
                                <option value="">- None -</option>
                                <?php foreach ($route_maps as $rm): ?>
                                <option value="<?= $rm['id'] ?>"><?= $rm['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="bgp_neighbor_prefix_list_in">Prefix List In</label>
                            <select id="bgp_neighbor_prefix_list_in" class="std-input">
                                <option value="">- None -</option>
                                <?php foreach ($prefix_lists as $pl): ?>
                                <option value="<?= $pl['id'] ?>"><?= $pl['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="bgp_neighbor_prefix_list_out">Prefix List Out</label>
                            <select id="bgp_neighbor_prefix_list_out" class="std-input">
                                <option value="">- None -</option>
                                <?php foreach ($prefix_lists as $pl): ?>
                                <option value="<?= $pl['id'] ?>"><?= $pl['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <button type="button" class="std-btn" data-js="bgp-neighbor-save">Save</button>
                        <button type="button" class="std-btn std-btn--secondary" data-js="bgp-add-neighbor-cancel">Cancel</button>
                    </div>
                </form>
            </div>

            <table class="std-table" id="bgp-neighbors-table">
                <thead>
                    <tr>
                        <th>Neighbor IP</th>
                        <th>Remote AS</th>
                        <th>Description</th>
                        <th>Address Families</th>
                        <th>Route Maps / Prefix Lists</th>
                        <th>State</th>
                        <th>Uptime</th>
                        <th>Prefixes Rx/Tx</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="bgp-neighbors-tbody">
                <?php if (empty($neighbors)): ?>
                    <tr class="std-table-empty"><td colspan="9">No neighbors configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($neighbors as $n): ?>
                    <tr data-neighbor-id="<?= $n['id'] ?>">
                        <td><?= $n['neighbor_ip_html'] ?></td>
                        <td><?= $n['remote_as_html'] ?></td>
                        <td><?= $n['description'] ?? '' ?></td>
                        <td><?= $n['address_families_html'] ?></td>
                        <td>
                            <span class="text-dim">Route Maps:</span> In: <?= $n['route_map_in_label'] ?> / Out: <?= $n['route_map_out_label'] ?>
                            <br>
                            <span class="text-dim">Prefix Lists:</span> In: <?= $n['prefix_list_in_label'] ?> / Out: <?= $n['prefix_list_out_label'] ?>
                        </td>
                        <td><?= $n['state_html'] ?></td>
                        <td><?= $n['uptime_label'] ?></td>
                        <td><?= $n['prefixes_label'] ?></td>
                        <td>
                            <button type="button" class="std-btn std-btn--sm" data-js="bgp-neighbor-details"
                                data-detail='<?= $n['peer_status_json'] ?>'>Details</button>
                            <?php if (!empty($n['can_delete'])): ?>
                            <button type="button" class="std-btn std-btn--sm" data-js="bgp-edit-neighbor"
                                data-id="<?= $n['id'] ?>"
                                data-ip-set="<?= $n['neighbor_ip_set'] ?>"
                                data-remote-as="<?= $n['remote_as'] ?>"
                                data-description="<?= $n['description'] ?? '' ?>"
                                data-ebgp-multihop="<?= $n['ebgp_multihop'] ?? 0 ?>"
                                data-update-source="<?= $n['update_source'] ?? '' ?>"
                                data-keepalive="<?= $n['keepalive'] ?? '' ?>"
                                data-hold-time="<?= $n['hold_time'] ?? '' ?>"
                                data-next-hop-self="<?= $n['next_hop_self_flag'] ?>"
                                data-soft-reconfig="<?= $n['soft_reconfig_flag'] ?>"
                                data-rr-client="<?= $n['rr_client_flag'] ?>"
                                data-bfd="<?= $n['bfd_flag'] ?>"
                                data-bfd-cp-failure="<?= $n['bfd_cp_failure_flag'] ?>"
                                data-bfd-profile="<?= $n['bfd_profile'] ?? '' ?>"
                                data-peer-group="<?= $n['peer_group'] ?? '' ?>"
                                data-route-map-in="<?= $n['route_map_in'] ?? '' ?>"
                                data-route-map-out="<?= $n['route_map_out'] ?? '' ?>"
                                data-prefix-list-in="<?= $n['prefix_list_in'] ?? '' ?>"
                                data-prefix-list-out="<?= $n['prefix_list_out'] ?? '' ?>"
                                data-address-families="<?= $n['address_families_csv'] ?>"
                            >Edit</button>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm" data-js="bgp-delete-neighbor" data-id="<?= $n['id'] ?>">Delete</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Networks -->
        <div class="content-box">
            <div class="content-box-header">
                <h2>BGP Networks</h2>
                <?php if (!empty($page_data['can_add'])): ?>
                <button type="button" class="std-btn" data-js="bgp-add-network-open">+ Add Network</button>
                <?php endif; ?>
            </div>

            <!-- Add network form (hidden) -->
            <div class="content-box" id="bgp-add-network-form" style="display:none;">
                <h3>Add BGP Network</h3>
                <form class="std-form form-compact" data-js="bgp-network-form">
                    <div class="form-row">
                        <div class="form-col">
                            <label>Network (address set)</label>
                            <div class="set-picker-field" data-js="set-picker-field"
                                 data-set-type="address" data-max-select="1"
                                 data-filter-scope="network,host_prefix">
                                <input type="hidden" id="bgp_network_set" name="network_set" value="">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select network prefix">
                                    <span class="js-set-picker-label">Select network prefix</span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear">&#215;</button>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <button type="button" class="std-btn" data-js="bgp-network-save">Save Network</button>
                        <button type="button" class="std-btn std-btn--secondary"
                            data-js="bgp-add-network-cancel">Cancel</button>
                    </div>
                </form>
            </div>

            <table class="std-table" id="bgp-networks-table">
                <thead>
                    <tr>
                        <th>Network</th>
                        <th>Family</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="bgp-networks-tbody">
                <?php if (empty($networks)): ?>
                    <tr class="std-table-empty"><td colspan="3">No networks configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($networks as $nw): ?>
                    <tr data-network-id="<?= $nw['id'] ?>">
                        <td><?= $nw['network_html'] ?></td>
                        <td><?= $nw['family_label'] ?></td>
                        <td>
                            <?php if (!empty($nw['can_delete'])): ?>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="bgp-delete-network" data-id="<?= $nw['id'] ?>">Delete</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Peer Groups -->
        <div class="content-box">
            <div class="content-box-header">
                <h2>Peer Groups</h2>
                <?php if (!empty($page_data['can_add'])): ?>
                <button type="button" class="std-btn" data-js="bgp-add-peergroup-open">+ Add Peer Group</button>
                <?php endif; ?>
            </div>

            <div class="content-box" id="bgp-add-peergroup-form" style="display:none;">
                <h3 id="bgp-peergroup-form-title">Add Peer Group</h3>
                <form class="std-form form-compact" data-js="bgp-peergroup-form">
                    <input type="hidden" id="bgp_peergroup_id" value="">
                    <div class="form-row">
                        <div class="form-col">
                            <label for="bgp_pg_name">Name</label>
                            <input type="text" id="bgp_pg_name" class="std-input" required placeholder="e.g. INTERNAL">
                        </div>
                        <div class="form-col form-col--tight">
                            <label>Remote AS</label>
                            <div class="set-picker-field" data-js="label-picker-field" data-set-type="as_number"
                                 data-max-select="1" data-label-title="Select AS number">
                                <input type="hidden" id="bgp_pg_remote_as" value="">
                                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select AS number">
                                    <span class="js-set-picker-label">Select AS number</span>
                                </button>
                                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear">&#215;</button>
                            </div>
                        </div>
                        <div class="form-col">
                            <label for="bgp_pg_desc">Description</label>
                            <input type="text" id="bgp_pg_desc" class="std-input" placeholder="Optional">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="bgp_pg_rm_in">Route Map In</label>
                            <select id="bgp_pg_rm_in" class="std-input">
                                <option value="">- None -</option>
                                <?php foreach ($route_maps as $rm): ?>
                                <option value="<?= $rm['id'] ?>"><?= $rm['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="bgp_pg_rm_out">Route Map Out</label>
                            <select id="bgp_pg_rm_out" class="std-input">
                                <option value="">- None -</option>
                                <?php foreach ($route_maps as $rm): ?>
                                <option value="<?= $rm['id'] ?>"><?= $rm['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="bgp_pg_pl_in">Prefix List In</label>
                            <select id="bgp_pg_pl_in" class="std-input">
                                <option value="">- None -</option>
                                <?php foreach ($prefix_lists as $pl): ?>
                                <option value="<?= $pl['id'] ?>"><?= $pl['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="bgp_pg_pl_out">Prefix List Out</label>
                            <select id="bgp_pg_pl_out" class="std-input">
                                <option value="">- None -</option>
                                <?php foreach ($prefix_lists as $pl): ?>
                                <option value="<?= $pl['id'] ?>"><?= $pl['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bgp_pg_next_hop_self">Next-hop Self</label>
                            <label class="std-switch">
                                <input type="checkbox" id="bgp_pg_next_hop_self">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bgp_pg_bfd">BFD</label>
                            <label class="std-switch">
                                <input type="checkbox" id="bgp_pg_bfd">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row">
                        <button type="button" class="std-btn" data-js="bgp-peergroup-save">Save</button>
                        <button type="button" class="std-btn std-btn--secondary"
                            data-js="bgp-add-peergroup-cancel">Cancel</button>
                    </div>
                </form>
            </div>

            <table class="std-table">
                <thead>
                    <tr><th>Name</th><th>Remote AS</th><th>Description</th><th>Route Maps / Prefix Lists</th><th>Actions</th></tr>
                </thead>
                <tbody>
                <?php if (empty($peer_groups)): ?>
                    <tr class="std-table-empty"><td colspan="5">No peer groups configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($peer_groups as $pg): ?>
                    <tr data-peergroup-id="<?= $pg['id'] ?>">
                        <td><strong><?= $pg['name'] ?></strong></td>
                        <td><?= $pg['remote_as_html'] ?></td>
                        <td><?= $pg['description'] ?? '-' ?></td>
                        <td>
                            <span class="text-dim">Route Maps:</span> In: <?= $pg['route_map_in_label'] ?> / Out: <?= $pg['route_map_out_label'] ?>
                            <br>
                            <span class="text-dim">Prefix Lists:</span> In: <?= $pg['prefix_list_in_label'] ?> / Out: <?= $pg['prefix_list_out_label'] ?>
                        </td>
                        <td>
                            <?php if (!empty($pg['can_delete'])): ?>
                            <button type="button" class="std-btn std-btn--sm js-bgp-edit-peergroup"
                                data-id="<?= $pg['id'] ?>"
                                data-name="<?= $pg['name'] ?>"
                                data-remote-as="<?= $pg['remote_as'] ?>"
                                data-desc="<?= $pg['description'] ?? '' ?>"
                                data-rm-in="<?= $pg['route_map_in'] ?? '' ?>"
                                data-rm-out="<?= $pg['route_map_out'] ?? '' ?>"
                                data-pl-in="<?= $pg['prefix_list_in'] ?? '' ?>"
                                data-pl-out="<?= $pg['prefix_list_out'] ?? '' ?>"
                                data-next-hop-self="<?= $pg['next_hop_self_flag'] ?>"
                                data-bfd="<?= $pg['bfd_flag'] ?>"
                            >Edit</button>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="bgp-delete-peergroup" data-id="<?= $pg['id'] ?>">Delete</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
