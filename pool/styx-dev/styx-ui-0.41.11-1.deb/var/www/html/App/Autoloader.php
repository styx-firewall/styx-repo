<?php

namespace App;

class Autoloader
{
    public static function register(): void
    {
        spl_autoload_register([__CLASS__, 'autoload']);
    }

    /**
     *
     * @param string $class
     * @return void
     */
    private static function autoload(string $class): void
    {
        $class = str_replace(__NAMESPACE__ . '\\', '', $class);
        $file = __DIR__ . '/' . str_replace('\\', '/', $class) . '.php';
        if (file_exists($file)) {
            require $file;
        }
    }
}
