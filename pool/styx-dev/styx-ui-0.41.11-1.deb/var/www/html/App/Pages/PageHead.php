<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Helpers\RoleHelper;
use App\Services\AuthService;
use App\Services\Filter;

class PageHead
{
    /**
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $cfg = $ctx->get(Config::class);

        $led_status = 'led-red-on';
        $blink_status = '';
        $gw_latency = 'N/A';
        $gw_version = 'N/A';


        $data = [
            'head_menu' => [
                'web_legend' => $cfg->get('web.legend'),
            ],
            'pong_gateway' => [
                'status' => $led_status,
                'blink' => $blink_status,
                'latency' => $gw_latency,
                'version' => $gw_version,
            ],
            'config_changed' => (bool)$cfg->get('config_changed', false),
            // Gateway marker (styx restart enough) and Debian's reboot marker.
            // Both feed the same banner section, which offers the action each
            // one needs.
            'restart_required' => (bool)$cfg->get('restart_required', false),
            'system_restart_required' => (bool)$cfg->get('system_restart_required', false),
            'can_reboot' => self::canReboot($ctx),
            'client_timezone' => $cfg->get('client.timezone', 'UTC'),
            'client_locale' => $cfg->get('client.locale', 'en-US'),
        ];
        return [
            'file' => 'head',
            'place' => 'page_head',
            'tpl_data' => $data,
        ];
    }

    /**
     * Whether the session may restart the system, same capability the system
     * reboot page checks. The banner hides the button instead of offering one
     * that the backend would reject.
     */
    private static function canReboot(AppContext $ctx): bool
    {
        $auth = $ctx->get(AuthService::class);
        if ($auth === null || !$auth->hasCapabilitiesLoaded()) {
            return false;
        }
        return RoleHelper::hasCapability($auth->getCapabilities(), 'system:admin');
    }
}
