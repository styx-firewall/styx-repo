<?php
/**
 * Pre-computes sidebar section visibility based on user capabilities and features.
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class SidebarFormatter
{
    /**
     * Map of sidebar sections to required capability and optional feature check.
     */
    private const SECTIONS = [
        'network'         => ['cap' => 'network:read'],
        'routing'         => ['cap' => 'routing:read',  'feature' => ['frrouting', 'igmp_proxy']],
        'firewall'        => ['cap' => 'firewall:read'],
        'packet_marking'  => ['cap' => 'packet_marking:read', 'feature' => ['packet_marking']],
        'content_filter'  => ['cap' => 'content_filter:read', 'feature' => ['web_filter', 'dns_filter']],
        'ebpf'            => ['cap' => 'ebpf:read',     'feature' => ['ebpf_core', 'ebpf_bcc']],
        'objects'         => ['cap' => 'objects:read'],
        'traffic_shaping' => ['cap' => 'traffic_shaping:read', 'feature' => ['tc']],
        'services'        => ['cap' => 'services:read'],
        'ha'              => ['cap' => 'ha:read', 'feature' => ['conntrackd']],
        'system'          => ['cap' => 'system:read'],
        // 'vpn' is a `provides` tag declared by both VPN options; 'ids' below is
        // suricata's. The enabled-features set is keyed by option keys and their
        // tags, never by section keys (sections are presentation only).
        'vpn'             => ['cap' => 'vpn:read',      'feature' => ['vpn']],
        'idsips'          => ['cap' => 'idsips:read',    'feature' => ['ids']],
        'styx'            => ['cap' => 'styx:read'],
        'styx_telemetry'  => ['cap' => 'telemetry:read'],
        'users'           => ['cap' => 'users:read'],
        'user_roles'      => ['cap' => 'users:admin'],
        'role_definitions' => ['cap' => 'users:admin'],
        'security'        => ['cap' => 'security:read'],
        'logs'            => ['cap' => 'logs:read'],
        'bearer_tokens'   => ['cap' => 'users:read',    'feature' => ['bearer_tokens']],
    ];

    /**
     * Compute visibility flags for all sidebar sections.
     *
     * @param string[] $userCaps
     * @param array<string,mixed> $features
     * @return array<string,bool>
     */
    public static function compute(array $userCaps, array $features): array
    {
        $visible = [];
        foreach (self::SECTIONS as $key => $config) {
            $hasCap = RoleHelper::hasCapability($userCaps, $config['cap']);
            if (!$hasCap) {
                $visible[$key] = false;
                continue;
            }
            if (!empty($config['feature'])) {
                $hasFeature = false;
                foreach ($config['feature'] as $f) {
                    if (!empty($features[$f])) {
                        $hasFeature = true;
                        break;
                    }
                }
                if (!$hasFeature) {
                    $visible[$key] = false;
                    continue;
                }
            }
            $visible[$key] = true;
        }
        return $visible;
    }
}
