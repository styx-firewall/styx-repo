#!/usr/bin/env python3
"""Health check for the ``cleanup_orphan_refs`` command.

Runs the orphan-refs cleanup in report mode (``commit=false``): asserts the
command succeeds and the response carries ``result.orphan_count``, then prints
the orphaned refs found. Does NOT modify state.

With ``--commit`` it also prunes the orphaned refs from running-config and
persists with ``save_config`` — a maintenance action, so it is opt-in.

Usage:
    python api_test/verify_orphan_refs.py               # report-only, no changes
    python api_test/verify_orphan_refs.py --commit      # prune + save_config
"""

from api_client import ApiError, get, require_ok
from verify_common import build_parser, build_client, finish


def run(client, commit):
    failures = 0
    try:
        resp = require_ok(client.submit("cleanup_orphan_refs", {"commit": commit}), "result.orphan_count")
        count = get(resp, "result.orphan_count")
        orphans = get(resp, "result.orphans") or []
        print(f"  OK   cleanup_orphan_refs: {count} orphaned ref(s)")
        msg = get(resp, "response_msg")
        if msg:
            print(f"  INFO {msg}")
        for o in orphans:
            print(f"       {o.get('key')}  entity={o.get('entity_id')}  ref={o.get('ref')}")
        if commit and count:
            print("  INFO persisting cleanup to startup-config")
            require_ok(client.submit("save_config"))
    except (ApiError, AssertionError) as e:
        print(f"  FAIL cleanup_orphan_refs: {e}")
        failures = 1
    return failures


def main():
    p = build_parser("Verify the cleanup_orphan_refs command (report-only by default)")
    p.add_argument(
        "--commit",
        action="store_true",
        help="Actually prune orphaned refs from running-config and persist with save_config",
    )
    args = p.parse_args()
    client = build_client(args)
    finish(run(client, args.commit))


if __name__ == "__main__":
    main()
