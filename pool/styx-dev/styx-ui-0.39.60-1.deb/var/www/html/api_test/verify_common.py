#!/usr/bin/env python3
"""Shared scaffolding for the verify_*.py scripts.

Avoids repeating the same argparse / client construction / cleanup pattern in
every lifecycle script. This is intentionally small — it is NOT a test runner;
each script keeps its own linear flow.
"""

import argparse
import sys

from api_client import ApiClient, ApiError, load_config, require_ok


def build_parser(description):
    p = argparse.ArgumentParser(description=description)
    p.add_argument("--config", default=None, help="Path to config.json (default: api_test/config.json)")
    return p


def build_client(args):
    """Build an ApiClient from --config (or the default config.json)."""
    cfg = load_config(args.config)
    return ApiClient(
        cfg["base_url"],
        cfg.get("bearer_token", ""),
        verify_tls=cfg.get("verify_tls", False),
        timeout=cfg.get("timeout", 10),
    )


def step_ok(resp, *keys, label=None):
    """require_ok() with an optional OK label; returns the response."""
    require_ok(resp, *keys)
    if label:
        print(f"  OK   {label}")
    return resp


def submit(client, command, data=None, dry_run=False):
    """submit() + require_ok(); returns the parsed response or raises."""
    return require_ok(client.submit(command, data, dry_run=dry_run))


def request(client, action, data=None):
    """request() + require_ok(); returns the parsed response or raises."""
    return require_ok(client.request(action, data))


def cleanup(client, created, label="cleanup"):
    """Best-effort deletion of resources created during a run.

    ``created`` is a list of (delete_command, delete_data) tuples, appended in
    creation order; deletion happens in reverse so dependencies (children before
    parents) are respected. Never raises: a leftover is reported as WARN.
    """
    for cmd, data in reversed(created):
        try:
            client.submit(cmd, data)
        except (ApiError, AssertionError) as e:
            print(f"  WARN {label} {cmd}: {e}")


def finish(failures):
    """Print a summary and exit with the right code."""
    print(f"Summary: {failures} failed")
    sys.exit(1 if failures else 0)
