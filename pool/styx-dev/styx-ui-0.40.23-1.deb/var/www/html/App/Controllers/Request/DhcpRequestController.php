<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;
use App\Services\GatewayService;

class DhcpRequestController extends BaseController
{
	/**
	 * Get all DHCP server configuration (all interfaces)
	 * @return array
	 */
	public function getPageData(): array
	{
		$commands = [
			[
				'method' => 'dhcp-server.get_all_dhcp_config',
				'id' => 'all_config',
			],			
			[
				'method' => 'dhcp-server.get_dhcp_global_config',
				'id' => 'global_config',
			],
			[
				'method' => 'dhcp-server.get_dhcp_leases',
				'id' => 'leases',
			],
			[
				'method' => 'network-config.get_interfaces_config',
				'id' => 'interfaces',
				'data' => (object)[],
			],

		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		if ($resp['status'] === 'error') {
			return $resp;
		}
		$cmds = $resp['commands'];
		return [
			'status'   => $resp['status'],
			'result'   => [
				'interfaces'         => $cmds['interfaces']['result']['interfaces'] ?? [],
				'dhcp_config'        => $cmds['all_config']['result'] ?? [],
				'dhcp_global_config' => $cmds['global_config']['result'] ?? [],
				'leases'             => $cmds['leases']['result'] ?? [],
			],
			'warnings' => $resp['warnings'],
		];
	}

	/**
	 * Get all stored per-interface DHCP configuration and reservations
	 * @return array
	 */
	public function getAllDhcpConfig(): array
	{
		$commands = [
			[
				'method' => 'dhcp-server.get_all_dhcp_config',
				'id' => 'all_config',
				'data' => (object)[],
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		if ($resp['status'] === 'error') {
			return $resp;
		}
		return [
			'status'   => $resp['status'],
			'result'   => $resp['commands']['all_config']['result'] ?? [],
			'warnings' => $resp['warnings'],
		];
	}

	/**
	 * Get the stored global DHCP configuration
	 * @return array
	 */
	public function getDhcpGlobalConfig(): array
	{
		$commands = [
			[
				'method' => 'dhcp-server.get_dhcp_global_config',
				'id' => 'global_config',
				'data' => (object)[],
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		if ($resp['status'] === 'error') {
			return $resp;
		}
		return [
			'status'   => $resp['status'],
			'result'   => $resp['commands']['global_config']['result'] ?? [],
			'warnings' => $resp['warnings'],
		];
	}

	/**
	 * Get DHCP server configuration for a specific interface
	 * @param string $interface_id
	 * @return array
	 */
	public function getDhcpConfigByInterface($interface_id)
	{
		$commands = [
			[
				'method' => 'dhcp-server.get_dhcp_config_by_interface',
				'id' => 'iface_config',
				'data' => [
					'interface_id' => $interface_id
				]
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		if ($resp['status'] === 'error') {
			return $resp;
		}
		return [
			'status'   => $resp['status'],
			'result'   => $resp['commands']['iface_config']['result'] ?? [],
			'warnings' => $resp['warnings'],
		];
	}

	/**
	 * Get current DHCP leases (optionally filtered by interface and ip_version)
	 * @param string $interface_id
	 * @param string $ip_version
	 * @return array
	 */
	public function getDhcpLeases($interface_id = null, $ip_version = null): array
	{
		$data = array_filter([
			'interface_id' => $interface_id,
			'ip_version'   => $ip_version,
		]);
		$commands = [
			[
				'method' => 'dhcp-server.get_dhcp_leases',
				'id' => 'leases',
				'data' => (object)$data,
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		if ($resp['status'] === 'error') {
			return $resp;
		}
		return [
			'status'   => $resp['status'],
			'result'   => $resp['commands']['leases']['result'] ?? [],
			'warnings' => $resp['warnings'],
		];
	}

}
