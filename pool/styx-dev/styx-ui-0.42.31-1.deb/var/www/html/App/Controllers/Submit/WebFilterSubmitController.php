<?php

namespace App\Controllers\Submit;

use App\Controllers\BaseController;

/**
 * Web filter write path.
 *
 * Registered commands (SubmitRegistry):
 *   web-filter.set_settings -> setSettings()
 *   web-filter.set_active   -> setActive()
 *
 * Responses are canonicalized through BaseController::singleCommand():
 * messages come from result.msg.
 * RBAC is enforced by the backend (content_filter:write).
 *
 * No `posture` here: the policy is the catalogue's (categories.set_posture),
 * because the DNS filter cuts first and a divergent web filter would only be
 * heard on the flows DNS did not see. `DATA_KEYS` is what keeps a posture out of
 * the call: this endpoint changes what this mechanism does with the policy, not
 * what the policy is.
 *
 * Saving **applies**: the gateway regenerates the nft rules and repoints the
 * running engine before responding. An error can therefore mean the settings
 * were stored but could not be put in force; result.msg says which, and the UI
 * must surface it rather than assume success.
 *
 * `set_active` is not a setting: it is the filter's own on/off, and being
 * ENABLED (the feature) is not being switched on. Switching the feature on gives
 * this pane and its settings; this is what arms the kernel and starts the pieces.
 */
class WebFilterSubmitController extends BaseController
{
    /** Top-level keys accepted by the partial settings payload. */
    private const DATA_KEYS = ['block_mode', 'dscp'];

    /** The on/off payload: one key, and it is not merged with the settings. */
    private const ACTIVE_KEYS = ['active'];

    /**
     * Save a (partial) set of this filter's settings. Omitted keys keep their
     * current value; `dscp` is replaced wholesale, so the backend always
     * receives the complete map.
     *
     * @param array<string,mixed> $data request body (command/metadata are ignored)
     * @return array<string,mixed>
     */
    public function setSettings(array $data = []): array
    {
        $unknown = $this->unknownFields($data, self::DATA_KEYS);
        if (!empty($unknown)) {
            return $this->baseError('unknown field(s): ' . implode(', ', $unknown));
        }
        $payload  = array_intersect_key($data, array_flip(self::DATA_KEYS));
        $commands = [
            [
                'method' => 'web-filter.set_settings',
                'id'     => 'set_settings',
                'data'   => $payload,
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'set_settings');
    }

    /**
     * Switch the filter on or off. The switch is persisted by the gateway, so a
     * filter left switched on comes back switched on after a restart.
     *
     * The gateway refuses a switch-on while the feature is off, and switching on
     * is atomic there: an error means nothing was armed and the filter is off, so
     * the UI reverts the switch and shows result.msg.
     *
     * @param array<string,mixed> $data request body (command/metadata are ignored)
     * @return array<string,mixed>
     */
    public function setActive(array $data = []): array
    {
        $unknown = $this->unknownFields($data, self::ACTIVE_KEYS);
        if (!empty($unknown)) {
            return $this->baseError('unknown field(s): ' . implode(', ', $unknown));
        }
        if (!is_bool($data['active'] ?? null)) {
            // Not coerced: `"false"` is a truthy string, and guessing which one the client
            // meant is how a switch ends up doing the opposite of what was asked.
            return $this->baseError('active must be true or false');
        }
        $commands = [
            [
                'method' => 'web-filter.set_active',
                'id'     => 'set_active',
                'data'   => ['active' => $data['active']],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'set_active');
    }
}
