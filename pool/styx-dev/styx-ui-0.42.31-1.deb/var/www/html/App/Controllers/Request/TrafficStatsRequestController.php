<?php
/**
 * Controller for handling Traffic Stats requests
 *
 * Communicates with the gateway backend to retrieve nftables-based
 * traffic statistics (in/out/forward per interface/IP/protocol).
 */
namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class TrafficStatsRequestController extends BaseController
{
    /**
     * Retrieve traffic statistics from the gateway.
     *
     * @param array<string, mixed> $params Optional parameters (e.g. summary_only)
     * @return array<string, mixed>
     */
    /**
     * @param array<string,mixed> $data wire key: `params` (optional nested array)
     */
    public function getStats(array $data): array
    {
        $params = $data['params'] ?? [];
        if (!is_array($params)) {
            return $this->baseError('params must be an array');
        }

        $gwData = [];
        if (!empty($params['summary_only'])) {
            $gwData['summary_only'] = true;
        }

        $commands = [[
            'method' => 'traffic-stats.get_stats',
            'id' => 'traffic_stats',
            'data' => $gwData,
        ]];

        $gw_response = $this->sendCommands($commands);
        $indexed = array_column($gw_response['commands'] ?? [], null, 'id');
        $cmd = $indexed['traffic_stats'] ?? [];

        if (($cmd['status'] ?? null) === 'success' && isset($cmd['result'])) {
            $result = is_array($cmd['result'] ?? null) ? $cmd['result'] : [];
            return [
                'status' => 'success',
                'result' => array_merge($result, ['msg' => $result['msg'] ?? 'Traffic statistics retrieved']),
            ];
        }

        return [
            'status' => 'error',
            'result' => ['msg' => $cmd['result']['msg'] ?? $gw_response['result']['msg'] ?? 'Failed to retrieve traffic stats'],
        ];
    }

    /**
     * Reset traffic statistics counters on the gateway.
     *
     * @return array<string, mixed>
     */
    public function resetStats(): array
    {
        $commands = [[
            'method' => 'traffic-stats.reset_stats',
            'id' => 'reset_traffic',
            'data' => (object)[],
        ]];

        $gw_response = $this->sendCommands($commands);
        $indexed = array_column($gw_response['commands'] ?? [], null, 'id');
        $cmd = $indexed['reset_traffic'] ?? [];

        if (($cmd['status'] ?? null) === 'success') {
            $result = is_array($cmd['result'] ?? null) ? $cmd['result'] : [];
            return [
                'status' => 'success',
                'result' => array_merge($result, ['msg' => $result['msg'] ?? 'Traffic statistics reset']),
            ];
        }

        return [
            'status' => 'error',
            'result' => ['msg' => $cmd['result']['msg'] ?? $gw_response['result']['msg'] ?? 'Failed to reset traffic stats'],
        ];
    }
}
