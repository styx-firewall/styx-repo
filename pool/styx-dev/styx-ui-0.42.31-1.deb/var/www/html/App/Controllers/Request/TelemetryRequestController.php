<?php
/**
 * Controller for generic telemetry read operations.
 *
 * Wraps the backend's generic telemetry handler (handlers/handler_telemetry.py),
 * which works for any Styx subsystem publishing to the TelemetryBus,not only
 * eBPF. The eBPF-scoped view stays in EbpfRequestController::getTelemetry().
 */
namespace App\Controllers\Request;

use App\Controllers\BaseController;

class TelemetryRequestController extends BaseController
{
    /**
     * Points-per-bucket ceiling, mirroring the handler's own MAX_QUERY_POINTS:
     * above it the backend refuses instead of clamping, because it materializes
     * every point as a dict in the API thread.
     */
    private const MAX_QUERY_POINTS = 10000;

    /** Return error response, preserving the actual message (canonical result.msg). */
    private function fallback(string $msg, array $resp = []): array
    {
        $out = $this->baseError($msg);
        if (!empty($resp['error_code'])) {
            $out['error_code'] = $resp['error_code'];
        }
        return $out;
    }

    /**
     * Send one telemetry.<command> and unwrap its result.
     *
     * @param string $command "query", "sources" or "stats"
     * @param mixed  $data    command payload (object)
     * @return array<string,mixed>
     */
    private function run(string $command, $data): array
    {
        $commands = [
            ['method' => 'telemetry.' . $command, 'id' => $command, 'data' => $data],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['result']['msg'] ?? $command . ' failed', $resp);
        }
        $cmd = $resp['commands'][$command] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            // The backend's refusal message is the useful part (invalid 'n',
            // storage not initialized, ...), so it is passed through as-is.
            return $this->fallback($cmd['result']['msg'] ?? $command . ': no response');
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }

    /**
     * Query stored telemetry points.
     *
     * Filters are optional; only the ones present are forwarded. The value
     * ranges (n > 0, n <= MAX_QUERY_POINTS) are the backend's call and its
     * message is surfaced unchanged,this only fixes the types, because the
     * handler type-checks and a form always yields strings.
     *
     * @param array<string,mixed> $inputData full request payload
     * @return array<string,mixed>
     */
    public function query(array $inputData): array
    {
        $data = [];

        // scope, source and instance are opaque strings the backend matches
        // itself (scope and source by prefix on a "/" boundary). Nothing to
        // validate here,an unknown value simply matches nothing.
        foreach (['scope', 'source', 'schema_type', 'instance'] as $key) {
            if (isset($inputData[$key]) && $inputData[$key] !== '') {
                $data[$key] = (string)$inputData[$key];
            }
        }

        if (isset($inputData['n']) && $inputData['n'] !== '') {
            $raw = $inputData['n'];
            if (!is_numeric($raw) || (float)$raw != (int)$raw) {
                return $this->fallback("Invalid 'n': expected a positive integer, got " . var_export($raw, true));
            }
            $n = (int)$raw;
            // These two are the backend's rules, restated here on purpose: they
            // are the documented contract, and a backend that does not enforce
            // them answers n=0 with an empty list and n=-1 with a shifted one
            // (points[-n:] reads forward), which reads as "the bus is empty"
            // rather than as an error. Checking the same range can never reject
            // a request a compliant backend would have accepted.
            if ($n <= 0) {
                return $this->fallback("Invalid 'n': expected a positive integer, got {$n}");
            }
            if ($n > self::MAX_QUERY_POINTS) {
                return $this->fallback(
                    "Invalid 'n': {$n} exceeds the maximum of " . self::MAX_QUERY_POINTS . " points per bucket"
                );
            }
            $data['n'] = $n;
        }

        foreach (['from_ts', 'to_ts'] as $key) {
            if (isset($inputData[$key]) && $inputData[$key] !== '') {
                if (!is_numeric($inputData[$key])) {
                    return $this->fallback("Invalid '{$key}': expected epoch seconds");
                }
                $data[$key] = (float)$inputData[$key];
            }
        }

        // The backend only does a range query when both bounds are present, and
        // silently falls back to "last N" when only one is. A half-set range is
        // a different query than the one asked for, so it is refused instead.
        if (array_key_exists('from_ts', $data) !== array_key_exists('to_ts', $data)) {
            return $this->fallback('from_ts and to_ts must be provided together');
        }

        // An inverted range is empty by construction, and "0 points" reads as
        // an idle bus rather than as the mistake it is.
        if (isset($data['from_ts'], $data['to_ts']) && $data['from_ts'] > $data['to_ts']) {
            return $this->fallback('from_ts must not be later than to_ts');
        }

        return $this->run('query', (object)$data);
    }

    /**
     * List every scope in the storage with its sources and schema types.
     *
     * @return array<string,mixed>
     */
    public function getSources(): array
    {
        return $this->run('sources', (object)[]);
    }

    /**
     * Storage growth caps and live counters, plus the bus queue counters.
     *
     * @return array<string,mixed>
     */
    public function getStats(): array
    {
        return $this->run('stats', (object)[]);
    }

    /**
     * List the instances of each producer species, each with the backend's
     * ready-to-display text (`instance_display`).
     *
     * @param array<string,mixed> $data wire key: `scope` (optional, default
     *                            `'*'`), a species filter using the same
     *                            prefix-on-"/" rule as query()
     * @return array<string,mixed>
     */
    public function getInstances(array $data): array
    {
        $scope = (string) ($data['scope'] ?? '*');

        return $this->run('instances', (object)['scope' => $scope]);
    }

    /**
     * Retention defaults, the per-producer budget and the OTLP export
     * configuration, as telemetry.get_settings returns them: the stored
     * `settings` object (complete, never partial) plus `export_available` /
     * `export_available_error`, which say whether this build can export at all.
     *
     * `export_headers` values arrive masked (`***`),the backend never returns
     * the real token. Read-only: it only asks the backend for the datastore key.
     *
     * @return array<string,mixed>
     */
    public function getSettings(): array
    {
        return $this->run('get_settings', (object)[]);
    }
}
