<?php

namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class LogsSubmitController extends BaseController
{
    /**
     * Update the log buffering settings (log_settings datastore key).
     *
     * @param array $data partial settings, e.g.
     *                    {"system_logs": {"buffer_size": 2000}} or
     *                    {"styx_logs": {"buffer_size": 2000, "min_level": 5}}
     * @return array
     */
    public function setLogSettings(array $data)
    {
        $commands = [
            [
                'method' => 'log-settings.set_log_settings',
                'id'     => 'set_log_settings',
                'data'   => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'set_log_settings');
    }
}
