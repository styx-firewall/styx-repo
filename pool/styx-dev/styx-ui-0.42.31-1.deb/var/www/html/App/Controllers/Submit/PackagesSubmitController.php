<?php
/**
 * Controller for handling package management submissions (install, uninstall, search, purge)
 * dp: 2024
 */
namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class PackagesSubmitController extends BaseController
{
    public function installPackage($data)
    {
        $commands = [
            [
                'method' => 'system-packages.install-package',
                'id' => 'install_package',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'install_package');
    }

    public function uninstallPackage($data)
    {
        $commands = [
            [
                'method' => 'system-packages.uninstall-package',
                'id' => 'uninstall_package',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'uninstall_package');
    }

    public function searchPackage($data)
    {
        $commands = [
            [
                'method' => 'system-packages.search-package',
                'id' => 'search_package',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'search_package');
    }

    public function purgePackage($data)
    {
        $commands = [
            [
                'method' => 'system-packages.purge-package',
                'id' => 'purge_package',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'purge_package');
    }

    public function handle(array $data)
    {
        $command = $data['command'] ?? '';
        if ($command === 'install-package') {
            return $this->installPackage($data);
        } elseif ($command === 'uninstall-package') {
            return $this->uninstallPackage($data);
        } elseif ($command === 'search-package') {
            return $this->searchPackage($data);
        } elseif ($command === 'purge-package') {
            return $this->purgePackage($data);
        } else {
            return ['status' => 'error', 'msg' => 'Unknown command: ' . $command];
        }
    }
}

