<?php
// dr: 2025-12-01
namespace App\Controllers\Submit;
use App\Controllers\BaseController;
use App\Services\DateFormatter;

class SystemSubmitController extends BaseController
{

    public function restartDaemon(array $data = [])
    {
        $commands = [
            [
                'method' => 'gateway-daemon.restart-daemon',
                'id' => 'restart_daemon',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'restart_daemon');
    }

    public function systemReboot(array $data = [])
    {
        $commands = [
            [
                'method' => 'system-mgmt.system-reboot',
                'id' => 'system_reboot',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'system_reboot');
    }

    public function updateSetting(array $data = [])
    {
        $key = $data['key'] ?? null;
        $value = $data['value'] ?? null;
        if (!$key || $value === null) {
            return $this->baseError('Missing key or value');
        }
        $allowed = ['hostname', 'hostname_domain', 'timezone', 'language'];
        if (!in_array($key, $allowed, true)) {
            return ['status' => 'error', 'result' => ['msg' => 'Setting not allowed']];
        }
        if ($key === 'hostname') {
            $command = 'set-hostname';
        } elseif ($key === 'hostname_domain') {
            $command = 'set-hostname-domain';
        } elseif ($key === 'timezone') {
            $command = 'set-timezone';
        } elseif ($key === 'language') {
            $command = 'set-language';
        } else {
            return $this->baseError('Invalid setting key');
        }

        // Backend canonical data keys when they differ from the setting name:
        // hostname_domain > domain, language > lang.
        $dataKey = ['hostname_domain' => 'domain', 'language' => 'lang'][$key] ?? $key;

        $commands = [
            [
                'method' => 'system-mgmt.' . ($command),
                'id' => 'update_setting',
                'data' => [$dataKey => $value]
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'update_setting');
    }

    public function getSystemLogs(array $payload)
    {
        $data = [];
        if (isset($payload['level']) && !empty($payload['level'])) {
            $data['level'] = $payload['level'];
        }
        if (isset($payload['limit'])) {
            $data['limit'] = (int)$payload['limit'];
        } else {
            $data['limit'] = 50;
        }
        if (isset($payload['last_id'])) {
            $data['last_id'] = (int)$payload['last_id'];
        }

        $commands = [
            [
                'method' => 'journal-watcher.get_system_logs',
                'id' => 'get_system_logs',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['get_system_logs'] ?? null;
        if (!$cmd) {
            return $this->singleCommand($resp, 'get_system_logs');
        }
        if (($cmd['status'] ?? null) === 'success' && isset($cmd['result'])) {
            $result = $cmd['result'];
            // Pre-format timestamps server-side using the user's timezone and locale.
            $logs = $result['system_logs'] ?? [];
            if (is_array($logs)) {
                foreach ($logs as $k => $log) {
                    $ts = $log['timestamp_iso'] ?? $log['date'] ?? null;
                    if ($ts !== null) {
                        $logs[$k]['date_fmt'] = DateFormatter::fromBackend($this->ctx, (string)$ts);
                    }
                }
                $result['system_logs'] = $logs;
            }
            return ['status' => 'success', 'result' => $result];
        }
        return $cmd;
    }

    public function setDns(array $data = [])
    {
        $nameservers = $data['nameservers'] ?? null;
        if ($nameservers === null || !is_array($nameservers) || empty($nameservers)) {
            return $this->baseError('Missing or invalid nameservers (non-empty list required)');
        }
        $payload = ['nameservers' => $nameservers];
        if (isset($data['search_domains']) && is_array($data['search_domains'])) {
            $payload['search_domains'] = $data['search_domains'];
        }

        $commands = [
            [
                'method' => 'system-mgmt.set-dns',
                'id' => 'set_dns',
                'data' => $payload,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['set_dns'] ?? null;
        if (!$cmd) {
            return $this->singleCommand($resp, 'set_dns');
        }
        $status = $cmd['status'] ?? 'error';
        $msg = $cmd['result']['msg'] ?? ($status === 'success' ? 'DNS configuration saved' : 'Failed to save DNS configuration');
        $out = ['status' => $status, 'result' => ['msg' => $msg]];
        if ($status === 'success' && is_array($cmd['result'] ?? null)) {
            $out['result'] = array_merge($cmd['result'], ['msg' => $msg]);
        }
        return $out;
    }

    public function removeDns(array $data = [])
    {
        $commands = [
            [
                'method' => 'system-mgmt.remove-dns',
                'id' => 'remove_dns',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['remove_dns'] ?? null;
        if (!$cmd) {
            return $this->singleCommand($resp, 'remove_dns');
        }
        $status = $cmd['status'] ?? 'error';
        $msg = $cmd['result']['msg'] ?? ($status === 'success' ? 'Styx DNS configuration removed' : 'Failed to remove DNS configuration');
        $out = ['status' => $status, 'result' => ['msg' => $msg]];
        if ($status === 'success' && is_array($cmd['result'] ?? null)) {
            $out['result'] = array_merge($cmd['result'], ['msg' => $msg]);
        }
        return $out;
    }

    public function deleteCertificate(array $data = [])
    {
        $id = $data['id'] ?? null;
        if (empty($id)) {
            return $this->baseError('Missing certificate id');
        }

        $commands = [
            [
                'method' => 'certs-mgmt.delete_certificate',
                'id' => 'delete_certificate',
                'data' => ['id' => $id]
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['delete_certificate'] ?? null;
        if (!$cmd) {
            return $this->singleCommand($resp, 'delete_certificate');
        }
        $status = $cmd['status'] ?? 'error';
        $msg = $cmd['result']['msg'] ?? ($status === 'success' ? 'Certificate deleted' : 'Delete failed');
        $out = ['status' => $status, 'result' => ['msg' => $msg]];
        if ($status === 'success' && is_array($cmd['result'] ?? null)) {
            $out['result'] = array_merge($cmd['result'], ['msg' => $msg]);
        }
        return $out;
    }

    public function uploadCertificate(array $data = [])
    {
        $type = $data['type'] ?? null;
        $certB64 = $data['cert_b64'] ?? null;
        $keyB64 = $data['key_b64'] ?? null;
        $name = $data['name'] ?? null;
        $fileName = $data['file_name'] ?? null;

        if (!$type || !$certB64) {
            return $this->baseError('Missing type or certificate data');
        }
        if (empty($fileName)) {
            return $this->baseError('Missing original certificate file name');
        }
        if ($type === 'pair') {
            if (!$keyB64) {
                return $this->baseError('Missing key data for pair upload');
            }
            if (empty($keyFileName)) {
                return $this->baseError('Missing original key file name for pair upload');
            }
        }

        $cmdData = ['type' => $type, 'cert_b64' => $certB64];
        if ($type === 'pair') {
            $cmdData['key_b64'] = $keyB64;
        }
        if (!empty($fileName)) {
            $cmdData['file_name'] = $fileName;
        }
        // No key_file_name: the gateway ignores it and stores the key under the
        // certificate's file_name (api_front/certificates.md documents that).
        if (!empty($name)) {
            $cmdData['name'] = $name;
        }

        $commands = [
            [
                'method' => 'certs-mgmt.upload_certificate',
                'id' => 'upload_certificate',
                'data' => $cmdData
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['upload_certificate'] ?? null;
        if (!$cmd) {
            return $this->singleCommand($resp, 'upload_certificate');
        }
        $status = $cmd['status'] ?? 'error';
        $msg = $cmd['result']['msg'] ?? ($status === 'success' ? 'Uploaded' : 'Upload failed');
        $out = ['status' => $status, 'result' => ['msg' => $msg]];
        if ($status === 'success' && is_array($cmd['result'] ?? null)) {
            // Forward the gateway result so callers can read the new ids
            // (certificate.id, and key.id for pair uploads) to later delete them.
            $out['result'] = array_merge($cmd['result'], ['msg' => $msg]);
        }
        return $out;
    }

    /**
     * Refresh the cached parsed metadata for all certificates.
     *
     * With `force` absent/false only entries with missing or stale metadata
     * (hash/version mismatch) are re-parsed; with `force: true` every entry is
     * re-parsed from its stored content. Persists running-config when any entry
     * was re-parsed; startup-config is NOT modified (call `save_config` to
     * persist across reboots).
     *
     * @param array<string,mixed> $data Optional `{ "force": bool }`.
     * @return array<string,mixed>
     */
    public function refreshCertMetadata(array $data = [])
    {
        // There is no dry-run: the gateway reads only `force` and always persists
        // when it re-parses an entry, which is what api_front/certificates.md
        // documents.
        $cmdData = ['force' => !empty($data['force'])];

        $commands = [
            [
                'method' => 'certs-mgmt.refresh_cert_metadata',
                'id' => 'refresh_cert_metadata',
                'data' => $cmdData,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['refresh_cert_metadata'] ?? null;
        if (!$cmd) {
            return $this->singleCommand($resp, 'refresh_cert_metadata');
        }
        $status = $cmd['status'] ?? 'error';
        $msg = $cmd['result']['msg'] ?? ($status === 'success' ? 'Parsed metadata refreshed' : 'Refresh failed');
        $out = ['status' => $status, 'result' => ['msg' => $msg]];
        if ($status === 'success' && is_array($cmd['result'] ?? null)) {
            $out['result'] = array_merge($cmd['result'], ['msg' => $msg]);
        }
        return $out;
    }

    /**
     * Trigger async package list update (apt update).
     */
    public function updatePackageLists(array $data = [])
    {
        $commands = [
            [
                'method' => 'system-mgmt.update-package-lists',
                'id' => 'update_package_lists',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['update_package_lists'] ?? null;
        if (!$cmd) {
            return $this->singleCommand($resp, 'update_package_lists');
        }
        $status = $cmd['status'] ?? 'error';
        $msg = $cmd['result']['msg'] ?? ($status === 'success' ? 'Package list update started' : 'Update failed');
        $out = ['status' => $status, 'result' => ['msg' => $msg]];
        if ($status === 'success' && is_array($cmd['result'] ?? null)) {
            $out['result'] = array_merge($cmd['result'], ['msg' => $msg]);
        }
        return $out;
    }

    /**
     * Trigger async package upgrade (apt dist-upgrade).
     */
    public function upgradePackages(array $data = [])
    {
        $runUpdateFirst = !empty($data['run_update_first']);
        $commands = [
            [
                'method' => 'system-mgmt.upgrade-packages',
                'id' => 'upgrade_packages',
                'data' => ['run_update_first' => $runUpdateFirst],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['upgrade_packages'] ?? null;
        if (!$cmd) {
            return $this->singleCommand($resp, 'upgrade_packages');
        }
        $status = $cmd['status'] ?? 'error';
        $msg = $cmd['result']['msg'] ?? ($status === 'success' ? 'Package upgrade started' : 'Upgrade failed');
        $out = ['status' => $status, 'result' => ['msg' => $msg]];
        if ($status === 'success' && is_array($cmd['result'] ?? null)) {
            $out['result'] = array_merge($cmd['result'], ['msg' => $msg]);
        }
        return $out;
    }

    public function systemServices(array $data = [])
    {
        $service = $data['service'] ?? null;
        $action = $data['action'] ?? null;
        if (empty($service) || empty($action)) {
            return ['status' => 'error', 'result' => ['msg' => 'Missing service or action']];
        }
        $allowed = ['start', 'stop', 'restart', 'enable', 'disable'];
        if (!in_array($action, $allowed, true)) {
            return ['status' => 'error', 'result' => ['msg' => 'Invalid action']];
        }

        if ($action === 'restart') {
            $commands = [
                [
                    'method' => 'system-services.reload-or-restart',
                    'id' => 'service_action',
                    'data' => ['service_name' => $service],
                ]
            ];
        } else {
            $cmdName = $action . '-service';
            $commands = [
                [
                    'method' => 'system-services.' . ($cmdName),
                    'id' => 'service_action',
                    'data' => ['service_name' => $service],
                ]
            ];
        }
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'service_action');
    }
}
