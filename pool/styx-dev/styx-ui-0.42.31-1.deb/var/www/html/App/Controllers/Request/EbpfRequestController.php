<?php
/**
 * Controller for eBPF read operations.
 *
 * Sends commands to the gateway using the ebpf.<command> protocol.
 * Each loaded module has a UUID (instance_id) - operations reference it.
 */
namespace App\Controllers\Request;

use App\Controllers\BaseController;

class EbpfRequestController extends BaseController
{
    /** Return error response, preserving the actual message */
    private function fallback(string $msg, array $resp = []): array
    {
        $this->logService->warning('eBPF request failed: ' . $msg);
        $out = ['status' => 'error', 'result' => ['msg' => $msg]];
        if (!empty($resp['error_code'])) {
            $out['error_code'] = $resp['error_code'];
        }
        return $out;
    }

    // ebpf.module-list

    /**
     * List all eBPF modules (Styx-managed + foreign + conflicts).
     */
    public function getModuleList(): array
    {
        $commands = [
            ['method' => 'ebpf.module-list', 'id' => 'module_list', 'data' => []],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['result']['msg'] ?? 'module-list failed', $resp);
        }
        $cmd = $resp['commands']['module_list'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('module-list: ' . ($cmd['result']['msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }

    // ebpf.module-info

    /**
     * Get full descriptor for a module (by UUID or name).
     *
     * @param array<string,mixed> $data wire key: `module`
     */
    public function getModuleInfo(array $data): array
    {
        $module = (string) ($data['module'] ?? '');
        if ($module === '') {
            return $this->baseError('module is required');
        }

        $commands = [
            ['method' => 'ebpf.module-info', 'id' => 'module_info', 'data' => ['module' => $module]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['result']['msg'] ?? 'module-info failed', $resp);
        }
        $cmd = $resp['commands']['module_info'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('module-info: ' . ($cmd['result']['msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }

    // ebpf.telemetry-get

    /**
     * Get current telemetry values for a module.
     *
     * @param array<string,mixed> $data wire key: `module`
     */
    public function getTelemetry(array $data): array
    {
        $module = (string) ($data['module'] ?? '');
        if ($module === '') {
            return $this->baseError('module is required');
        }

        $commands = [
            ['method' => 'ebpf.telemetry-get', 'id' => 'telemetry', 'data' => ['module' => $module]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['result']['msg'] ?? 'telemetry-get failed', $resp);
        }
        $cmd = $resp['commands']['telemetry'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('telemetry-get: ' . ($cmd['result']['msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }

    // ebpf.map-get

    /**
     * Read current content of a control map from the kernel.
     *
     * @param array<string,mixed> $data wire keys: `module`, `map`
     */
    public function getControlMap(array $data): array
    {
        $module = (string) ($data['module'] ?? '');
        $map = (string) ($data['map'] ?? '');
        if ($module === '' || $map === '') {
            return $this->baseError('module and map are required');
        }

        $commands = [
            ['method' => 'ebpf.map-get', 'id' => 'map_get', 'data' => ['module' => $module, 'map' => $map]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['result']['msg'] ?? 'map-get failed', $resp);
        }
        $cmd = $resp['commands']['map_get'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('map-get: ' . ($cmd['result']['msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }

    // ebpf.autoload-get

    /**
     * Get the list of UUIDs configured for autoload.
     */
    public function getAutoload(): array
    {
        $commands = [
            ['method' => 'ebpf.autoload-get', 'id' => 'autoload', 'data' => []],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['result']['msg'] ?? 'autoload-get failed', $resp);
        }
        $cmd = $resp['commands']['autoload'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('autoload-get: ' . ($cmd['result']['msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }

    // ebpf.map-source (get)

    /**
     * Get the data source config for a control map.
     *
     * @param array<string,mixed> $data wire keys: `module`, `map`
     */
    public function getMapSource(array $data): array
    {
        $module = (string) ($data['module'] ?? '');
        $map = (string) ($data['map'] ?? '');
        if ($module === '' || $map === '') {
            return $this->baseError('module and map are required');
        }

        $commands = [
            ['method' => 'ebpf.map-source', 'id' => 'map_source', 'data' => ['module' => $module, 'map' => $map]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $this->fallback($resp['result']['msg'] ?? 'map-source failed', $resp);
        }
        $cmd = $resp['commands']['map_source'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->fallback('map-source: ' . ($cmd['result']['msg'] ?? 'no response'));
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }
}
