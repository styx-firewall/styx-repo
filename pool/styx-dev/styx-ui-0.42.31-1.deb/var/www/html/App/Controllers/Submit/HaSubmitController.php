<?php
// dr: 2025-12-01
namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class HaSubmitController extends BaseController
{

    public function saveConntrackdConfig(array $data = [])
    {
        $commands = [
            [
                'method' => 'conntrackd.save_conntrackd_config',
                'id' => 'save_conntrackd_config',
                'data' => $data,
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'save_conntrackd_config');
    }

    public function resetConntrackdConfig(array $data = [])
    {
        $commands = [
            [
                'method' => 'conntrackd.reset_conntrackd_config',
                'id' => 'reset_conntrackd_config',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'reset_conntrackd_config');
    }
}
