<?php

namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class SecuritySubmitController extends BaseController
{
    /**
     * Run a security audit on demand (background task).
     * @param array $data
     * @return array
     */
    public function runAudit(array $data)
    {
        $commands = [
            [
                'method' => 'security.run_audit',
                'id' => 'run_audit',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'run_audit');
    }
}
