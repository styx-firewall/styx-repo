<?php
/**
 * Controller for eBPF write operations (load, unload, reload, control-push,
 * autoload-set, map-source).
 */
namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class EbpfSubmitController extends BaseController
{
    // ebpf.module-load

    /**
     * Load an eBPF module into the kernel.
     *
     * Expected $data keys:
     *  - module (string): module name or UUID
     *  - interface (string|array): Styx interface UUID(s) - depends on attach_target
     *
     * Mode is auto-detected by the backend (core>libbpf, bcc>BCC).
     */
    public function loadModule(array $data): array
    {
        $module = $data['module'] ?? '';

        if (empty($module)) {
            return $this->baseError('Module name not provided');
        }

        $gwData = ['module' => $module];
        if (!empty($data['interface'])) {
            $gwData['interface'] = $data['interface'];
        }
        if (!empty($data['params']) && is_array($data['params'])) {
            $gwData['params'] = $data['params'];
        }

        $commands = [
            ['method' => 'ebpf.module-load', 'id' => 'load_module', 'data' => $gwData],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'load_module');
    }

    // ebpf.module-unload

    /**
     * Unload (or suspend) an eBPF module instance by UUID.
     *
     * Expected $data keys:
     *  - module (string): instance UUID  -  required
     *  - preserve (bool): if true, suspend instead of full unload
     */
    public function unloadModule(array $data): array
    {
        $module = $data['module'] ?? '';
        if (empty($module)) {
            return $this->baseError('Module UUID not provided');
        }

        $gwData = ['module' => $module];
        if (!empty($data['preserve'])) {
            $gwData['preserve'] = true;
        }

        $commands = [
            ['method' => 'ebpf.module-unload', 'id' => 'unload_module', 'data' => $gwData],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'unload_module');
    }

    // ebpf.module-activate

    /**
     * Activate an inactive/suspended eBPF module instance by UUID.
     *
     * Only accepts UUIDs of existing datastore instances.
     * Does NOT generate a new ID  -  reuses the existing UUID.
     *
     * Expected $data keys:
     *  - module (string): instance UUID  -  required
     */
    public function activateModule(array $data): array
    {
        $module = $data['module'] ?? '';
        if (empty($module)) {
            return $this->baseError('Module UUID not provided');
        }

        $commands = [
            ['method' => 'ebpf.module-activate', 'id' => 'activate_module', 'data' => ['module' => $module]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'activate_module');
    }

    // ebpf.module-deactivate

    /**
     * Deactivate (suspend) a loaded eBPF module instance by UUID.
     *
     * Preserves data on disk and the datastore entry.
     * Only accepts UUIDs.
     *
     * Expected $data keys:
     *  - module (string): instance UUID  -  required
     */
    public function deactivateModule(array $data): array
    {
        $module = $data['module'] ?? '';
        if (empty($module)) {
            return $this->baseError('Module UUID not provided');
        }

        $commands = [
            ['method' => 'ebpf.module-deactivate', 'id' => 'deactivate_module', 'data' => ['module' => $module]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'deactivate_module');
    }

    // ebpf.module-reload

    /**
     * Hot-reload an eBPF module instance (by UUID or name).
     */
    public function reloadModule(array $data): array
    {
        $module = $data['module'] ?? '';
        if (empty($module)) {
            return $this->baseError('Module identifier not provided');
        }

        $commands = [
            ['method' => 'ebpf.module-reload', 'id' => 'reload_module', 'data' => ['module' => $module]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'reload_module');
    }

    // ebpf.control-push

    /**
     * Push data to a control map.
     *
     * Expected $data keys:
     *  - module (string): UUID or module name
     *  - map (string): map name
     *  - items (array): items to push (format depends on data_type)
     *  - op (string): 'replace_all', 'upsert', or 'delete'
     */
    public function controlPush(array $data): array
    {
        $module = $data['module'] ?? '';
        $map = $data['map'] ?? '';
        $items = $data['items'] ?? [];
        $op = $data['op'] ?? 'upsert';

        if (empty($module)) return $this->baseError('Module identifier not provided');
        if (empty($map)) return $this->baseError('Map name not provided');

        $commands = [
            [
                'method' => 'ebpf.control-push',
                'id' => 'control_push',
                'data' => [
                    'module' => $module,
                    'map' => $map,
                    'items' => $items,
                    'op' => $op,
                ],
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'control_push');
    }

    // ebpf.autoload-set

    /**
     * Set the list of UUIDs for autoload on boot.
     */
    public function setAutoload(array $data): array
    {
        $autoload = $data['autoload'] ?? [];
        if (!is_array($autoload)) {
            return $this->baseError('autoload must be an array of UUIDs');
        }

        $commands = [
            ['method' => 'ebpf.autoload-set', 'id' => 'autoload_set', 'data' => ['autoload' => $autoload]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'autoload_set');
    }

    // ebpf.module-rescan

    /**
     * Rescan the module directory (discovery only  -  does not load anything).
     */
    public function moduleRescan(array $data): array
    {
        $commands = [
            ['method' => 'ebpf.module-rescan', 'id' => 'module_rescan', 'data' => []],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'module_rescan');
    }

    // ebpf.baseline-ack

    /**
     * Acknowledge all new foreign programs  -  mark them as known baseline.
     *
     * No data parameters needed. Sends ebpf.baseline-ack to the gateway.
     */
    public function baselineAck(array $data): array
    {
        $commands = [
            ['method' => 'ebpf.baseline-ack', 'id' => 'baseline_ack', 'data' => []],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'baseline_ack');
    }

    // ebpf.program-detach

    /**
     * Detach a foreign BPF program from the kernel.
     *
     * Expected $data keys:
     *  - program_id (int): kernel BPF program ID
     */
    public function detachProgram(array $data): array
    {
        $programId = $data['program_id'] ?? 0;
        if (empty($programId)) {
            return $this->baseError('Program ID not provided');
        }

        $commands = [
            ['method' => 'ebpf.program-detach', 'id' => 'program_detach', 'data' => ['program_id' => (int)$programId]],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'program_detach');
    }

    // ebpf.map-source (set)

    /**
     * Configure where a control map gets its data.
     *
     * Expected $data keys:
     *  - module (string): UUID
     *  - map (string): map name
     *  - source (string): 'file' or 'set'
     *  - set_name (string): required when source='set'
     */
    public function setMapSource(array $data): array
    {
        $module = $data['module'] ?? '';
        $map = $data['map'] ?? '';
        $source = $data['source'] ?? 'file';

        if (empty($module)) return $this->baseError('Module identifier not provided');
        if (empty($map)) return $this->baseError('Map name not provided');

        $gwData = [
            'module' => $module,
            'map' => $map,
            'source' => $source,
        ];
        if ($source === 'set' && !empty($data['set_name'])) {
            $gwData['set_name'] = $data['set_name'];
        }

        $commands = [
            ['method' => 'ebpf.map-source', 'id' => 'map_source_set', 'data' => $gwData],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'map_source_set');
    }
}
