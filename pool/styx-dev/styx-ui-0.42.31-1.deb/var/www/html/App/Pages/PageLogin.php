<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Services\LogSystemService;
use App\Controllers\Request\StyxRequestController;

class PageLogin
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $page['web_main']['footer_script'][] = '/scripts/core/login-banner.js';
        $page['web_main']['footer_script'][] = '/scripts/core/login.js';
        $page['page'] = 'login';

        // The notice is rendered server-side so it blocks the form on the
        // first paint. The gateway command is public; a failure must not take
        // the login page down, so it fails open (no banner).
        $banner = ['enabled' => false, 'message' => ''];
        try {
            $styxController = new StyxRequestController($ctx);
            $response = $styxController->getPreLoginBanner();
            if (($response['status'] ?? '') === 'success') {
                $result = is_array($response['result'] ?? null) ? $response['result'] : [];
                $banner = [
                    'enabled' => (bool)($result['enabled'] ?? false),
                    'message' => is_string($result['message'] ?? null) ? $result['message'] : '',
                ];
            } else {
                $ctx->get(LogSystemService::class)->warning(
                    'Pre-login banner unavailable: ' . ($response['result']['msg'] ?? 'unknown error')
                );
            }
        } catch (\Throwable $e) {
            $ctx->get(LogSystemService::class)->warning(
                'Pre-login banner unavailable: ' . $e->getMessage()
            );
        }

        // Never render an empty blocking dialog.
        if (trim($banner['message']) === '') {
            $banner['enabled'] = false;
        }
        $page['page_data'] = ['pre_login_banner' => $banner];

        return $page;
    }
}
