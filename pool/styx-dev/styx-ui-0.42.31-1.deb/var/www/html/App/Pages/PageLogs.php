<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Services\AuthService;
use App\Helpers\RoleHelper;
use App\Controllers\Request\LogsRequestController;
use App\Pages\Fmt\LogsSettingsFormatter;

class PageLogs
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'logs-settings',
        ];
        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'logs-settings';
        }

        $fmt_data = [];

        // Section scripts: the settings form is edited client-side.
        // api-client.js is already loaded globally (PageDefaults).
        $page['web_main']['footer_script'][] = ['src' => '/scripts/core/settings-form.js'];
        $page['web_main']['footer_script'][] = ['src' => '/scripts/logs/logs-settings.js'];

        // Fetch the current settings from the gateway.
        $logsController = new LogsRequestController($ctx);
        $response = $logsController->getLogSettings();
        $settings_ok = ($response['status'] ?? '') === 'success';
        $fmt_data['settings'] = $settings_ok ? ($response['result']['settings'] ?? []) : [];
        $fmt_data['bounds'] = $settings_ok ? ($response['result']['bounds'] ?? []) : [];
        // Signal a failed load so the template renders the controls disabled
        // instead of an optimistic state.
        $fmt_data['settings_error'] = $settings_ok ? false : ($response['result']['msg'] ?? true);

        $auth = $ctx->get(AuthService::class);
        $fmt_data['can_write'] = RoleHelper::hasCapability($auth->getCapabilities(), 'logs:write');

        $fmt_data['section'] = $section;

        // Presentation logic: prepare template-ready form data (echo-only template).
        $fmt_data = LogsSettingsFormatter::format($fmt_data);

        $page['page'] = $section;
        $page['page_data'] = $fmt_data;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }
}
