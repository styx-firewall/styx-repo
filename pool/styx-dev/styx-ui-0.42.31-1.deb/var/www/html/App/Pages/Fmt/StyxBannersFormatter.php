<?php
/**
 * Formatter for the Styx banners administration section.
 *
 * get_banners returns the effective message of a configurable banner, not the
 * stored custom one. When `custom` is false that text is the gateway default:
 * it must NOT be placed in the textarea, or a toggle-only save would store the
 * default as a custom message. It is exposed as `default_preview` instead.
 */
namespace App\Pages\Fmt;

class StyxBannersFormatter
{
    private const MAX_MESSAGE_LENGTH = 4096;

    /**
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $raw = is_array($fmt_data['banners'] ?? null) ? $fmt_data['banners'] : [];

        return [
            'can_admin' => !empty($fmt_data['can_admin']),
            'error' => is_string($fmt_data['error'] ?? null) ? $fmt_data['error'] : '',
            'warnings' => is_array($fmt_data['warnings'] ?? null) ? $fmt_data['warnings'] : [],
            'max_message_length' => self::MAX_MESSAGE_LENGTH,
            'pre_login' => self::formatConfigurable($raw['pre_login'] ?? []),
            'post_login' => self::formatConfigurable($raw['post_login'] ?? []),
            'welcome' => self::formatWelcome($raw['welcome'] ?? []),
        ];
    }

    /**
     * @param mixed $section
     * @return array<string,mixed>
     */
    private static function formatConfigurable($section): array
    {
        $section = is_array($section) ? $section : [];
        $enabled = !empty($section['enabled']);
        $custom = !empty($section['custom']);
        $message = is_string($section['message'] ?? null) ? $section['message'] : '';

        return [
            'enabled' => $enabled,
            'custom' => $custom,
            'custom_message' => $custom ? $message : '',
            'default_preview' => $custom ? '' : $message,
            'checked_attr' => $enabled ? 'checked' : '',
        ];
    }

    /**
     * @param mixed $section
     * @return array<string,mixed>
     */
    private static function formatWelcome($section): array
    {
        $section = is_array($section) ? $section : [];
        $enabled = !empty($section['enabled']);

        return [
            'enabled' => $enabled,
            'message' => is_string($section['message'] ?? null) ? $section['message'] : '',
            'editable' => false,
            'checked_attr' => $enabled ? 'checked' : '',
        ];
    }
}
