<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */

$pre = $tdata['page_data']['pre_login_banner'] ?? ['enabled' => false, 'message' => ''];
$show_pre = !empty($pre['enabled']) && trim((string)($pre['message'] ?? '')) !== '';
?>
<script>try { if (window.localStorage) localStorage.removeItem('app:current_user'); } catch(e) {}</script>

<div class="login-wrap<?= $show_pre ? ' banner-blocked' : '' ?>"<?= $show_pre ? ' inert' : '' ?>>
    <div>
        <form id="login-form" class="std-form" method="post" autocomplete="off">
            <img src="/img/logo.png" alt="Logo" class="login-logo">
            <label>
                User:
                <input type="text" name="username" required<?= $show_pre ? '' : ' autofocus' ?> autocomplete="username" />
            </label>
            <label>
                Password:
                <input type="password" name="password" required autocomplete="current-password" />
            </label>
            <label>
                Realm:
                <select name="realm">
                    <option value="pam" selected>Linux PAM</option>
                </select>
            </label>
            <button type="submit">Login</button>
        </form>
        <div id="login-message" class="login-message"></div>
    </div>
</div>
<?php if ($show_pre): ?>
    <div id="prelogin-banner-message" hidden><?= htmlspecialchars($pre['message'], ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>
