<?php

/**
 * TemplateService->getTpl()
 *
 * Included: styx-banners.js
 *
 * @var array<mixed> $tdata
 */
// Presentation data prepared by StyxBannersFormatter (echo-only template).
$banners = $tdata['page_data'] ?? [];
$pre = $banners['pre_login'] ?? [];
$post = $banners['post_login'] ?? [];
$welcome = $banners['welcome'] ?? [];
$can_admin = !empty($banners['can_admin']);
$error = (string)($banners['error'] ?? '');
$warnings = $banners['warnings'] ?? [];
$max_message_length = (int)($banners['max_message_length'] ?? 4096);
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Banners</h1>

        <?php if ($error !== ''): ?>
            <div class="std-error-box">
                <strong>Error:</strong> <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($warnings)): ?>
            <div class="std-error-box std-warning-box">
                <strong>Warning:</strong> some data may be incomplete.
                <ul>
                    <?php foreach ($warnings as $warning): ?>
                        <li><?= htmlspecialchars((string)$warning, ENT_QUOTES, 'UTF-8') ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ($can_admin && $error === ''): ?>
        <form id="styx-banners-form" class="std-form banner-admin-form">

            <section class="content-box banner-admin-section">
                <h2>Pre-login notice</h2>
                <div class="setting-row">
                    <div>
                        <strong>Show before authentication</strong>
                        <div class="fw-setting-hint">
                            Blocks the login form until the user accepts the notice.
                        </div>
                    </div>
                    <div class="setting-toggle">
                        <label class="std-switch">
                            <input type="checkbox" id="pre-login-enabled" <?= $pre['checked_attr'] ?? '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <label for="pre-login-message">Custom message</label>
                <textarea
                    id="pre-login-message"
                    class="banner-admin-textarea"
                    rows="5"
                    maxlength="<?= $max_message_length ?>"
                    placeholder="Leave empty to use the built-in default."><?= htmlspecialchars($pre['custom_message'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
                <?php if (!empty($pre['default_preview'])): ?>
                    <div class="banner-admin-hint">Built-in default (read-only):</div>
                    <pre class="banner-default-preview"><?= htmlspecialchars($pre['default_preview'], ENT_QUOTES, 'UTF-8') ?></pre>
                <?php endif; ?>
            </section>

            <section class="content-box banner-admin-section">
                <h2>Post-login notice</h2>
                <div class="setting-row">
                    <div>
                        <strong>Show after authentication</strong>
                        <div class="fw-setting-hint">
                            Shown once per login session; the user must continue past it.
                        </div>
                    </div>
                    <div class="setting-toggle">
                        <label class="std-switch">
                            <input type="checkbox" id="post-login-enabled" <?= $post['checked_attr'] ?? '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <label for="post-login-message">Custom message</label>
                <textarea
                    id="post-login-message"
                    class="banner-admin-textarea"
                    rows="5"
                    maxlength="<?= $max_message_length ?>"
                    placeholder="Leave empty to use the built-in default."><?= htmlspecialchars($post['custom_message'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
                <?php if (!empty($post['default_preview'])): ?>
                    <div class="banner-admin-hint">Built-in default (read-only):</div>
                    <pre class="banner-default-preview"><?= htmlspecialchars($post['default_preview'], ENT_QUOTES, 'UTF-8') ?></pre>
                <?php endif; ?>
            </section>

            <section class="content-box banner-admin-section">
                <h2>Welcome</h2>
                <div class="setting-row">
                    <div>
                        <strong>Show the Welcome banner</strong>
                        <div class="fw-setting-hint">
                            Each user can dismiss it for themselves; this switch controls it globally.
                        </div>
                    </div>
                    <div class="setting-toggle">
                        <label class="std-switch">
                            <input type="checkbox" id="welcome-enabled" <?= $welcome['checked_attr'] ?? '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <div class="banner-admin-hint">
                    The Welcome message is fixed by the gateway and cannot be edited.
                </div>
                <pre class="banner-readonly-message"><?= htmlspecialchars($welcome['message'] ?? '', ENT_QUOTES, 'UTF-8') ?></pre>
            </section>

            <div class="banner-admin-actions">
                <button type="submit" class="std-btn">Save banners</button>
                <span id="styx-banners-feedback" class="banner-admin-feedback"></span>
            </div>

            <p class="banner-admin-hint">
                Changes are applied to the running configuration. Use the global Save banner to
                persist them across reboots.
            </p>
        </form>
        <?php endif; ?>
    </main>
</div>
