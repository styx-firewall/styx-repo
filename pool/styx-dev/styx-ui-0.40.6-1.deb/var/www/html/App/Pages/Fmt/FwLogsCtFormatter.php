<?php
namespace App\Pages\Fmt;

class FwLogsCtFormatter
{
    /**
     * Prepare columns configuration for the conntrack flow logs page.
     * @param array $fmt_data
     * @return array
     */
    public static function format(array $fmt_data): array
    {
        $columns = [
            ['key' => 'timestamp',     'label' => 'Timestamp'],
            ['key' => 'src_ip',        'label' => 'Source IP'],
            ['key' => 'src_port',      'label' => 'Source Port'],
            ['key' => 'dest_ip',       'label' => 'Destination IP'],
            ['key' => 'dest_port',     'label' => 'Destination Port'],
            ['key' => 'reply_src_ip',  'label' => 'Reply Src IP'],
            ['key' => 'reply_dest_ip', 'label' => 'Reply Dst IP'],
            ['key' => 'protocol',      'label' => 'Proto'],
            ['key' => 'orig_bytes',    'label' => 'Bytes ↑'],
            ['key' => 'reply_bytes',   'label' => 'Bytes ↓'],
            ['key' => 'flow.duration', 'label' => 'Duration'],
            // ct verdict / reset / nat are optional: they depend on the
            // ct_verdict_mark setting, so cells stay quiet when absent.
            ['key' => 'ct.verdict',    'label' => 'Verdict'],
            ['key' => 'ct.reset',      'label' => 'RST'],
            ['key' => 'ct.nat',        'label' => 'NAT'],
        ];

        $fmt_data['ct_logs_columns'] = $columns;

        $fmt_data['ct_logs_columns_json'] = json_encode(
            $columns,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
        );

        return $fmt_data;
    }
}
