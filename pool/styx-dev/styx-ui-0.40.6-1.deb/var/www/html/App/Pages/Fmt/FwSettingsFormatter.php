<?php
/**
 * Formatter for the firewall settings page (fw-settings section).
 *
 * Presentation logic only: normalizes the raw settings object from the gateway
 * into template-ready values under $fmt_data['settings_ui']. Echo-only
 * templates consume the precomputed keys instead of validating or defaulting
 * themselves.
 */
namespace App\Pages\Fmt;

class FwSettingsFormatter
{
    /**
     * @param array<string,mixed> $fmt_data expects 'settings', 'settings_error', 'can_create'
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $settings = $fmt_data['settings'] ?? [];
        $settings_error = $fmt_data['settings_error'] ?? false;

        // The gateway always returns the full normalized settings object. A
        // missing or incomplete object is treated as an error: no frontend
        // defaults are substituted here, otherwise a backend default change
        // would silently drift from the values shown in the UI.
        $valid = is_array($settings)
            && is_array($settings['conntrack_bypass'] ?? null)
            && is_array($settings['drop_invalid'] ?? null)
            && is_array($settings['ct_state_log'] ?? null)
            && is_bool($settings['conntrack_bypass']['input'] ?? null)
            && is_bool($settings['conntrack_bypass']['forward'] ?? null)
            && is_bool($settings['drop_invalid']['input'] ?? null)
            && is_bool($settings['drop_invalid']['forward'] ?? null)
            && is_array($settings['ct_state_log']['input'] ?? null)
            && is_array($settings['ct_state_log']['forward'] ?? null)
            && is_array($settings['ct_state_log']['output'] ?? null)
            && is_int($settings['fw_logs_max'] ?? null)
            && is_int($settings['ct_logs_max'] ?? null)
            && is_bool($settings['ct_logs_filter_loopback'] ?? null)
            && is_bool($settings['ct_logs_filter_multicast'] ?? null)
            && is_bool($settings['ct_logs_filter_broadcast'] ?? null);

        if (!$valid && $settings_error === false) {
            $settings_error = 'Firewall settings are missing or incomplete';
        }

        // Render OFF / empty (and disabled) when the data is invalid.
        $cb  = $valid ? $settings['conntrack_bypass'] : [];
        $di  = $valid ? $settings['drop_invalid'] : [];
        $ctl = $valid ? $settings['ct_state_log'] : [];

        // Ct-state logging: per-chain, per-state checked booleans.
        $ctl_checked = [
            'established' => [],
            'related'     => [],
        ];
        foreach (['input', 'forward', 'output'] as $chain) {
            $chain_states = $ctl[$chain] ?? [];
            $ctl_checked['established'][$chain] = in_array('established', $chain_states, true);
            $ctl_checked['related'][$chain]     = in_array('related', $chain_states, true);
        }

        $fmt_data['settings_ui'] = [
            'error'                    => $settings_error,
            'disabled_attr'            => (!empty($fmt_data['can_create']) && $settings_error === false) ? '' : 'disabled',
            'cb_forward'               => $cb['forward'] ?? false,
            'cb_input'                 => $cb['input'] ?? false,
            'di_forward'               => $di['forward'] ?? false,
            'di_input'                 => $di['input'] ?? false,
            'fw_logs_max'              => $valid ? $settings['fw_logs_max'] : '',
            'ct_logs_max'              => $valid ? $settings['ct_logs_max'] : '',
            'ct_logs_filter_loopback'  => $valid ? $settings['ct_logs_filter_loopback'] : false,
            'ct_logs_filter_multicast' => $valid ? $settings['ct_logs_filter_multicast'] : false,
            'ct_logs_filter_broadcast' => $valid ? $settings['ct_logs_filter_broadcast'] : false,
            // Optional: verdict/RST marking is off when the key is missing
            // (feature not enabled or older gateway), never a settings error.
            'ct_verdict_mark'          => is_bool($settings['ct_verdict_mark'] ?? null) ? $settings['ct_verdict_mark'] : false,
            'ctl_checked'              => $ctl_checked,
        ];

        return $fmt_data;
    }
}
