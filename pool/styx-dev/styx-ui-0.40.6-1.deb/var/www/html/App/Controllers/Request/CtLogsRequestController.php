<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class CtLogsRequestController extends BaseController
{
    public function __construct(AppContext $ctx)
    {
        parent::__construct($ctx);
    }

    public function handle(array $inputData): array
    {
        $query = isset($inputData['query']) ? trim((string) $inputData['query']) : '';
        $mark  = $inputData['mark'] ?? null;
        $limit = $inputData['limit'] ?? 50;
        $start = $inputData['start'] ?? null;
        $end   = $inputData['end'] ?? null;

        $data = [];
        if ($query !== '') {
            $data['query'] = $query;
        }

        $this->logService->debug([
            'ct_logs_request' => [
                'query'   => $query,
                'mark_in' => $mark,
                'limit'   => $limit,
            ]
        ]);

        if ($start !== null && $end !== null) {
            $data['start'] = $start;
            $data['end']   = $end;
        } elseif ($mark !== null) {
            $data['mark']  = $mark;
            $data['limit'] = $limit;
        } else {
            $data['limit'] = $limit;
        }

        $command = [
            'method' => 'ct-logs.get_ct_logs',
            'id'     => 'ct_logs',
            'data'   => $data,
        ];

        $resp = $this->processGwResp($this->sendCommands([$command], null, ['timeout_read' => 10]));

        if ($resp['status'] === 'error') {
            return array_merge($resp, ['logs' => [], 'mark' => null]);
        }

        $cmd = $resp['commands']['ct_logs'] ?? [];

        if (($cmd['status'] ?? null) === 'success' && isset($cmd['result']['logs'])) {
            $logs = $cmd['result']['logs'];
            foreach ($logs as &$log) {
                $log = $this->parseLogEntry($log);
            }

            $this->logService->debug([
                'ct_logs_response' => [
                    'mark_out'   => $cmd['result']['mark'] ?? null,
                    'logs_count' => is_array($logs) ? count($logs) : 0,
                ]
            ]);

            return [
                'status'       => 'success',
                'response_msg' => 'CT logs retrieved successfully',
                'mark'         => $cmd['result']['mark'] ?? null,
                'logs'         => $logs,
            ];
        }

        $this->logService->warning(['ct_logs_error' => $cmd]);

        return [
            'status'       => 'error',
            'response_msg' => $cmd['response_msg'] ?? 'No data from backend',
            'logs'         => [],
            'mark'         => null,
        ];
    }

    /**
     * Flatten nested CT log objects into top-level keys so the frontend
     * can access them directly via log[col.key] (e.g. log['ct.event']).
     */
    private function parseLogEntry(array $log): array
    {
        // Flatten ct.*
        if (isset($log['ct']) && is_array($log['ct'])) {
            $log['ct.event']   = $log['ct']['event'] ?? null;
            $log['ct.id']      = $log['ct']['id'] ?? null;
            $log['ct.mark']    = $log['ct']['mark'] ?? null;
            $log['ct.verdict'] = $log['ct']['verdict'] ?? null;
            $log['ct.reset']   = $log['ct']['reset'] ?? false;
            $log['ct.nat']     = $log['ct']['nat'] ?? 'none';
        }

        // Flatten orig.*
        if (isset($log['orig']) && is_array($log['orig'])) {
            $log['orig_bytes']          = $log['orig']['bytes'] ?? null;
            $log['orig_packets']        = $log['orig']['packets'] ?? null;
            $log['orig_src_hostname']   = $log['orig']['src_hostname'] ?? null;
            $log['orig_src_custom_name'] = $log['orig']['src_custom_name'] ?? null;
            $log['orig_dest_hostname']   = $log['orig']['dest_hostname'] ?? null;
            $log['orig_dest_custom_name'] = $log['orig']['dest_custom_name'] ?? null;
        }

        // Flatten reply.*
        if (isset($log['reply']) && is_array($log['reply'])) {
            $log['reply_bytes']          = $log['reply']['bytes'] ?? null;
            $log['reply_packets']        = $log['reply']['packets'] ?? null;
            $log['reply_src_ip']         = $log['reply']['src_ip'] ?? null;
            $log['reply_dest_ip']        = $log['reply']['dest_ip'] ?? null;
            $log['reply_src_hostname']   = $log['reply']['src_hostname'] ?? null;
            $log['reply_src_custom_name'] = $log['reply']['src_custom_name'] ?? null;
            $log['reply_dest_hostname']   = $log['reply']['dest_hostname'] ?? null;
            $log['reply_dest_custom_name'] = $log['reply']['dest_custom_name'] ?? null;
        }

        // Flatten flow.*
        if (isset($log['flow']) && is_array($log['flow'])) {
            $log['flow.duration'] = $log['flow']['duration'] ?? null;
            $log['flow.start']    = $log['flow']['start'] ?? null;
            $log['flow.end']      = $log['flow']['end'] ?? null;
        }

        // Prefer ISO timestamp
        if (!empty($log['timestamp_iso'])) {
            $log['timestamp'] = $log['timestamp_iso'];
        }

        return $log;
    }
}
