"""
Migration script: -> 0.44.9

- Loads nf_conntrack at runtime so the conntrack sysctl keys already
  deployed by migrate_0.44.3 can be applied immediately.
  On future boots SystemModules.load_required_modules() (called from
  StyxConfigure.configure() on every boot) handles this.
"""

from core.app_context import AppContext
from services.system_modules import SystemModules

TAG = "[MIGRATE 0.44.9]"


def run(ctx: AppContext) -> bool:
    """Load nf_conntrack now so pending sysctls take effect."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    try:
        SystemModules.load_required_modules(ctx)
        logger.notice(f"{TAG} Required modules loaded.")
    except Exception as e:
        logger.error(f"{TAG} Failed to load required modules: {e}")
        return False

    logger.notice(f"{TAG} Migration completed successfully.")
    return True
