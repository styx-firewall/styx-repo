"""
Migration script: -> 0.43.7

Force-deploys logrotate configuration templates so existing installations
receive updated logrotate configs without requiring a factory reset.
"""

import os
import shutil

from core.app_context import AppContext

TAG = "[MIGRATE 0.43.7]"

TEMPLATES = {
    "logrotate.conf": ("/etc/logrotate.conf", 0o644),
    "lr-styx": ("/etc/logrotate.d/styx", 0o644),
    "lr-styx-ui": ("/etc/logrotate.d/styx-ui", 0o644),
    "lr-suricata": ("/etc/logrotate.d/suricata", 0o644),
    "lr-ulogd2": ("/etc/logrotate.d/ulogd2", 0o644),
    "lr-apt": ("/etc/logrotate.d/apt", 0o644),
    "lr-wtmp": ("/etc/logrotate.d/wtmp", 0o644),
    "lr-wtmpdb": ("/etc/logrotate.d/wtmpdb", 0o644),
}


def run(ctx: AppContext) -> bool:
    """Deploy logrotate config templates from cfg-tpl to /etc."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    src_dir = "/opt/styx-gateway/files/cfg-tpl"
    ok = True

    for filename, (dest, mode) in TEMPLATES.items():
        src = os.path.join(src_dir, filename)
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            os.chmod(dest, mode)
            logger.notice(f"{TAG} Deployed {filename} -> {dest} (mode {oct(mode)})")
        except Exception as e:
            logger.error(f"{TAG} Failed to deploy {filename} -> {dest}: {e}")
            ok = False

    if ok:
        logger.notice(f"{TAG} Migration completed successfully.")
    else:
        logger.notice(f"{TAG} Migration completed with errors (check logs).")
    return ok
