"""
Migration script: -> 0.46.2

Adds the DNS keys to ``system_config`` for installations created before the
DNS management feature existed.

Before this migration, ``system_config`` only carried hostname/timezone/domain/
language, so ``desired_config.dns_servers`` reported ``null`` (never
configured) even though the feature was available.

The keys are seeded from the current DNS state, preferring the Styx-managed
configuration:

  1. ``/etc/resolvconf.conf`` -- ``name_servers="..."`` / ``search_domains="..."``
     (the variables DNSService writes; last assignment wins).
  2. ``/etc/resolv.conf`` as fallback when resolvconf.conf has no active
     variables -- the nameservers and search domains currently in effect
     (e.g. the ones offered by DHCP on the WAN) become the seeded values so
     the datastore always ends up with an explicit, non-null DNS configuration.
  3. Empty (``[]``) if nothing can be read.

Note: seeding from resolv.conf pins those nameservers as Styx-managed (they
get prepended on the next boot via ``apply_from_datastore()``). This matches
the intent for stable network DNS, but values offered by DHCP may go stale if
the network changes -- the admin can edit them via the API at any time.
"""

import os

from constants.datastore_keys import (
    DS_KEY_SYSTEM_CONFIG,
)
from core.app_context import AppContext

TAG = "[MIGRATE 0.46.2]"
STORE = "startup-config"
RESOLVCONF_CONF_PATH = "/etc/resolvconf.conf"
RESOLV_CONF_PATH = "/etc/resolv.conf"


def _read_active_resolvconf_values() -> dict:
    """
    Read ``name_servers`` / ``search_domains`` from /etc/resolvconf.conf.

    Returns ``{"name_servers": [...], "search_domains": "..."}`` where lists
    contain the parsed values, or empty defaults when the file is missing or
    the variables are not set.  Shell semantics: the last assignment wins.
    """
    result = {"name_servers": [], "search_domains": ""}
    try:
        if not os.path.exists(RESOLVCONF_CONF_PATH):
            return result
        with open(RESOLVCONF_CONF_PATH, "r") as f:
            for line in f:
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                if stripped.startswith("name_servers="):
                    value = stripped[len("name_servers=") :].strip().strip('"').strip("'")
                    result["name_servers"] = value.split() if value else []
                elif stripped.startswith("search_domains="):
                    value = stripped[len("search_domains=") :].strip().strip('"').strip("'")
                    result["search_domains"] = value.split() if value else []
    except Exception:
        # Best-effort: if resolvconf.conf cannot be read, seed empty values
        pass
    return result


def _read_resolv_conf_values() -> dict:
    """
    Read ``nameserver`` / ``search`` / ``domain`` lines from /etc/resolv.conf.

    Fallback used when resolvconf.conf has no Styx-managed variables: the
    nameservers currently in effect (e.g. provided by DHCP on the WAN) become
    the seeded ``dns_servers`` so the datastore always has an explicit,
    non-null DNS configuration.
    """
    result = {"name_servers": [], "search_domains": []}
    try:
        with open(RESOLV_CONF_PATH, "r") as f:
            for line in f:
                stripped = line.strip()
                parts = stripped.split()
                if not parts:
                    continue
                if parts[0] == "nameserver" and len(parts) >= 2:
                    result["name_servers"].append(parts[1])
                elif parts[0] in ("search", "domain") and len(parts) >= 2:
                    # search takes one or more domains; domain takes one
                    result["search_domains"] = parts[1:]
    except Exception:
        # Best-effort: if resolv.conf cannot be read, seed empty values
        pass
    return result


def run(ctx: AppContext) -> bool:
    """Seed dns_servers/dns_search into system_config if missing."""
    logger = ctx.get_logger()
    ds = ctx.get_datastore()
    logger.notice(f"{TAG} Migration started.")

    system_config = ds.get_data(DS_KEY_SYSTEM_CONFIG, store=STORE)
    if not isinstance(system_config, dict):
        logger.info(f"{TAG} No system_config found -- nothing to migrate.")
        return True

    changed = False
    missing_servers = "dns_servers" not in system_config
    missing_search = "dns_search" not in system_config
    if missing_servers or missing_search:
        # Prefer the Styx-managed variables in resolvconf.conf; fall back to
        # the nameservers currently in effect (resolv.conf) when not present.
        active = _read_active_resolvconf_values()
        fallback = None
        if not active["name_servers"] and not active["search_domains"]:
            fallback = _read_resolv_conf_values()

    if missing_servers:
        servers = active["name_servers"]
        source = "resolvconf.conf"
        if not servers and fallback:
            servers = fallback["name_servers"]
            source = "/etc/resolv.conf"
        system_config["dns_servers"] = servers
        changed = True
        logger.info(f"{TAG} Added dns_servers to system_config (from {source}): {servers}")
    if missing_search:
        search = active["search_domains"]
        source = "resolvconf.conf"
        if not search and fallback:
            search = fallback["search_domains"]
            source = "/etc/resolv.conf"
        system_config["dns_search"] = search
        changed = True
        logger.info(f"{TAG} Added dns_search to system_config (from {source}): '{search}'")

    if not changed:
        logger.info(f"{TAG} DNS keys already present -- nothing to migrate.")
        return True

    if not ds.replace_data(DS_KEY_SYSTEM_CONFIG, system_config, store=STORE):
        logger.error(f"{TAG} Failed to persist system_config.")
        return False

    logger.notice(f"{TAG} Migration completed successfully.")
    return True
