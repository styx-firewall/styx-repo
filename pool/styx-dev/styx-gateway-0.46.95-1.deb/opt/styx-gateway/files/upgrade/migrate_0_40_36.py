"""
Migration script: -> 0.40.36

Sanitises legacy Traffic Control entries that were poisoned by older code
paths which recorded failed/empty qdisc reads as real state:

  1. Physical interfaces recorded with kind 'noqueue' -- an impossible state
     (the kernel always reinstalls its default qdisc on a physical NIC), which
     used to trigger an unreconcilable re-apply loop on every boot. Rewritten
     to DEFAULT_PHYSICAL_QDISC (handle 1:, default params). This replaces the
     boot-time override that configure/tc_config.py used to run on every boot,
     removed in this version.

  2. Non-noqueue qdiscs stored with handle '0:' (the kernel's "unnamed"
     handle) -- replace_qdisc() forces 1: on apply, so a stored '0:' caused a
     spurious difference on every comparison. Normalised to '1:' once,
     replacing the per-boot in-memory normalisation removed in this version.

Interfaces that no longer exist on the system cannot be classified as
physical/virtual, so their 'noqueue' entries are left untouched: the reconcile
skips absent interfaces, and if the interface re-appears the honest del_qdisc
read-back self-heals the entry.
"""

from constants.datastore_keys import DS_KEY_TC_CONFIG
from core.app_context import AppContext
from services.traffic_control.tc_service_constants import (
    DEFAULT_PHYSICAL_QDISC,
    DEFAULT_PHYSICAL_QDISC_PARAMS,
    is_physical_interface,
)

TAG = "[MIGRATE 0.40.36]"


def run(ctx: AppContext) -> bool:
    """Sanitise noqueue-on-physical and handle-0: entries in the saved TC config."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    ds = ctx.get_datastore()
    STORE = "startup-config"

    tc_conf = ds.get_data(DS_KEY_TC_CONFIG, store=STORE)
    if not tc_conf or not isinstance(tc_conf, dict):
        logger.info(f"{TAG} No TC config found -- nothing to migrate.")
        return True

    changed = 0
    for iface_uuid, entry in (tc_conf.get("interfaces") or {}).items():
        if not isinstance(entry, dict):
            continue
        iface_name = entry.get("interface_name")
        for qdisc in entry.get("qdiscs") or []:
            if not isinstance(qdisc, dict):
                continue
            kind = qdisc.get("kind")
            if kind == "noqueue":
                # Impossible state on a physical NIC; leave untouched if the
                # interface is absent and cannot be classified.
                if iface_name and is_physical_interface(iface_name):
                    qdisc["kind"] = DEFAULT_PHYSICAL_QDISC
                    qdisc["handle"] = "1:"
                    qdisc.setdefault("options", {})
                    qdisc["options"].update(DEFAULT_PHYSICAL_QDISC_PARAMS)
                    changed += 1
                    logger.info(
                        f"{TAG} {iface_name} ({iface_uuid}): 'noqueue' on physical NIC "
                        f"rewritten to '{DEFAULT_PHYSICAL_QDISC}' (handle 1:)."
                    )
            elif qdisc.get("handle") == "0:":
                qdisc["handle"] = "1:"
                changed += 1
                logger.info(f"{TAG} {iface_name} ({iface_uuid}): qdisc '{kind}' handle '0:' normalised to '1:'.")

    if changed:
        if not ds.replace_data(DS_KEY_TC_CONFIG, tc_conf, store=STORE):
            logger.error(f"{TAG} Failed to persist migrated TC config.")
            return False

    logger.notice(f"{TAG} Migration completed. Qdisc entries updated: {changed}.")
    return True
