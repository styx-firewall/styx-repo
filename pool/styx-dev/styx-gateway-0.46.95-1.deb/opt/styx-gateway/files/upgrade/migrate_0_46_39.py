"""
Migration script: -> 0.46.39

Backfills config_interfaces refs for the SSH and Lighttpd SSL singleton
configs (ssh_config.listen / lighttpd_ssl.addresses).

Before this migration those singletons never registered their UUID ``id``
as a ref on the config_interfaces entries they listen on.  From 0.46.39 on,
SSHService / LighttpdConfigEditor keep refs in sync with the stored
listen/addresses lists, so InterfaceLifecycleService's delete guard is
consistent for pre-existing configs.

Steps performed:
  1. Ensure both singletons have a UUID ``id`` field, generating one if missing.
  2. Register that id as a ref on every config_interfaces entry whose UUID
     appears in the singleton's listen/addresses list.
"""

import uuid

from constants.datastore_keys import (
    DS_KEY_CONFIG_INTERFACES,
    DS_KEY_LIGHTTPD_SSL,
    DS_KEY_SSH_CONFIG,
)
from core.app_context import AppContext

TAG = "[MIGRATE 0.46.39]"
STORE = "startup-config"

_SINGLETON_LIST_KEYS = (
    (DS_KEY_SSH_CONFIG, "listen"),
    (DS_KEY_LIGHTTPD_SSL, "addresses"),
)


def run(ctx: AppContext) -> bool:
    """Backfill config_interfaces refs for the SSH and Lighttpd singletons."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    ds = ctx.get_datastore()

    # 1. Ensure every singleton has a UUID id
    for key, _list_field in _SINGLETON_LIST_KEYS:
        entry = ds.get_data(key, store=STORE)
        if entry is None:
            logger.info(f"{TAG} No {key} config found -- nothing to migrate for it.")
            continue
        if not isinstance(entry, dict):
            logger.warning(f"{TAG} {key} is not a dict ({type(entry).__name__}) -- skipping id/ref backfill.")
            continue
        if not entry.get("id") or not isinstance(entry.get("id"), str):
            entry["id"] = str(uuid.uuid4())
            if not ds.replace_data(key, entry, store=STORE):
                logger.error(f"{TAG} Failed to persist {key} with new UUID id.")
                return False
            logger.info(f"{TAG} Added id={entry['id']} to {key}")

    # 2. Backfill refs on config_interfaces entries that still exist
    config_ifaces = ds.get_data(DS_KEY_CONFIG_INTERFACES, store=STORE) or []
    if not isinstance(config_ifaces, list) or not config_ifaces:
        logger.info(f"{TAG} No config_interfaces found -- nothing to migrate.")
        return True

    by_id = {item.get("id"): item for item in config_ifaces if isinstance(item, dict)}
    iface_modified = False
    for key, list_field in _SINGLETON_LIST_KEYS:
        entry = ds.get_data(key, store=STORE)
        if not isinstance(entry, dict):
            continue
        iid = entry.get("id")
        if not iid:
            continue
        tokens = entry.get(list_field)
        if not isinstance(tokens, list):
            continue
        for tok in tokens:
            if not isinstance(tok, str):
                continue
            item = by_id.get(tok)
            if item is None:
                # Interface deleted: nothing to anchor a ref on.
                continue
            refs = item.get("refs") if isinstance(item.get("refs"), list) else []
            if iid not in refs:
                refs.append(iid)
                item["refs"] = refs
                iface_modified = True
                logger.info(f"{TAG} Registered ref {iid} on interface '{tok}' ({key})")

    if iface_modified:
        if not ds.replace_data(DS_KEY_CONFIG_INTERFACES, config_ifaces, store=STORE):
            logger.error(f"{TAG} Failed to persist config_interfaces with backfilled refs.")
            return False
        logger.info(f"{TAG} Persisted config_interfaces with backfilled refs.")

    logger.notice(f"{TAG} Migration completed successfully.")
    return True
