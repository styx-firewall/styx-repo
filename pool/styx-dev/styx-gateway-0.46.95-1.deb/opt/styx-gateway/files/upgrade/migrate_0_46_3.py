"""
Migration script: -> 0.46.3

Renames the system domain key in ``system_config`` from ``domain`` to
``hostname_domain`` to match the new naming (the value is the FQDN suffix of
the hostname, set via ``set-hostname-domain``; it is unrelated to the DNS
search domain managed via set-dns).

The main code reads/writes ``hostname_domain`` from 0.46.3 on, so the data
must be moved before the new code can see it:

  - ``system_config.domain``          (old key)  ->  ``hostname_domain``
  - if both exist, ``hostname_domain`` wins and ``domain`` is dropped.
"""

from core.app_context import AppContext

TAG = "[MIGRATE 0.46.3]"
STORE = "startup-config"
SYSTEM_CONFIG_KEY = "system_config"
LEGACY_DOMAIN_KEY = "domain"
HOSTNAME_DOMAIN_KEY = "hostname_domain"


def run(ctx: AppContext) -> bool:
    """Rename system_config.domain -> system_config.hostname_domain."""
    logger = ctx.get_logger()
    ds = ctx.get_datastore()
    logger.notice(f"{TAG} Migration started.")

    system_config = ds.get_data(SYSTEM_CONFIG_KEY, store=STORE)
    if not isinstance(system_config, dict):
        logger.info(f"{TAG} No system_config found -- nothing to migrate.")
        return True

    legacy = system_config.get(LEGACY_DOMAIN_KEY)
    if legacy is None:
        logger.info(f"{TAG} No legacy 'domain' key -- nothing to migrate.")
        return True

    # hostname_domain wins if both are present
    if HOSTNAME_DOMAIN_KEY not in system_config:
        system_config[HOSTNAME_DOMAIN_KEY] = legacy
        logger.info(f"{TAG} Moved 'domain' -> '{HOSTNAME_DOMAIN_KEY}': {legacy!r}")
    else:
        logger.info(f"{TAG} '{HOSTNAME_DOMAIN_KEY}' already present; dropping legacy 'domain'.")
    del system_config[LEGACY_DOMAIN_KEY]

    if not ds.replace_data(SYSTEM_CONFIG_KEY, system_config, store=STORE):
        logger.error(f"{TAG} Failed to persist system_config.")
        return False

    logger.notice(f"{TAG} Migration completed successfully.")
    return True
