"""
Migration script: -> 0.43.12

Combined re-run of 0.43.7 + 0.43.8 for systems where the original
migrations were skipped due to missing PyInstaller bundle data.

- 0.43.7: Deploys logrotate config templates
- 0.43.8: Deploys rsyslog.conf (FileCreateMode fix) + igmpproxy.service
"""

import os
import shutil

from core.app_context import AppContext
from services.system_services import SystemServices

TAG = "[MIGRATE 0.43.12]"

# --- 0.43.7: logrotate ---
LOGROTATE_TEMPLATES = {
    "logrotate.conf": ("/etc/logrotate.conf", 0o644),
    "lr-styx": ("/etc/logrotate.d/styx", 0o644),
    "lr-styx-ui": ("/etc/logrotate.d/styx-ui", 0o644),
    "lr-suricata": ("/etc/logrotate.d/suricata", 0o644),
    "lr-ulogd2": ("/etc/logrotate.d/ulogd2", 0o644),
    "lr-apt": ("/etc/logrotate.d/apt", 0o644),
    "lr-wtmp": ("/etc/logrotate.d/wtmp", 0o644),
    "lr-wtmpdb": ("/etc/logrotate.d/wtmpdb", 0o644),
}

# --- 0.43.8: rsyslog (FileCreateMode) + igmpproxy ---
TEMPLATES = {
    "rsyslog.conf": ("/etc/rsyslog.conf", 0o644),
    "igmpproxy.service": ("/etc/systemd/system/igmpproxy.service", 0o644),
}


def run(ctx: AppContext) -> bool:
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")
    ok = True

    src_dir = "/opt/styx-gateway/files/cfg-tpl"

    # -- 0.43.7: logrotate --
    for filename, (dest, mode) in LOGROTATE_TEMPLATES.items():
        src = os.path.join(src_dir, filename)
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            os.chmod(dest, mode)
            logger.notice(f"{TAG} [0.43.7] Deployed {filename} -> {dest} (mode {oct(mode)})")
        except Exception as e:
            logger.error(f"{TAG} [0.43.7] Failed to deploy {filename}: {e}")
            ok = False

    # -- 0.43.8: rsyslog (FileCreateMode fix) + igmpproxy --
    for filename, (dest, mode) in TEMPLATES.items():
        src = os.path.join(src_dir, filename)
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            os.chmod(dest, mode)
            logger.notice(f"{TAG} [0.43.8] Deployed {filename} -> {dest} (mode {oct(mode)})")
        except Exception as e:
            logger.error(f"{TAG} [0.43.8] Failed to deploy {filename}: {e}")
            ok = False

    result = SystemServices.reload_or_restart(ctx, "rsyslog", skip_reload=True, non_blocking=True)
    if result.ok:
        logger.notice(f"{TAG} [0.43.8] rsyslog restart requested.")
    else:
        logger.error(f"{TAG} [0.43.8] Failed to restart rsyslog: {result.msg}")
        ok = False

    if ok:
        logger.notice(f"{TAG} Migration completed successfully.")
    else:
        logger.notice(f"{TAG} Migration completed with errors (check logs).")
    return ok
