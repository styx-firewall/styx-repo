"""
Migration script: -> 0.43.6

Updates systemd-journald and rsyslog configuration files and restarts
both services to apply the changes.

- journald.conf: enables persistent storage, caps disk usage at 500M,
  limits retention to 1month, disables ForwardToWall (headless gateway),
  raises MaxLevelConsole to warning.
- rsyslog.conf: narrows kernel logging from kern.* to kern.warning.
"""

import os
import shutil

from core.app_context import AppContext
from services.system_services import SystemServices

TAG = "[MIGRATE 0.43.6]"

TEMPLATES = {
    "journald.conf": "/etc/systemd/journald.conf",
    "rsyslog.conf": "/etc/rsyslog.conf",
}

SERVICES = ["systemd-journald", "rsyslog"]


def run(ctx: AppContext) -> bool:
    """Deploy updated journald and rsyslog configs, then restart services."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    src_dir = "/opt/styx-gateway/files/cfg-tpl"
    ok = True

    # 1. Copy config files
    for filename, dest in TEMPLATES.items():
        src = os.path.join(src_dir, filename)
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            logger.notice(f"{TAG} Deployed {filename} -> {dest}")
        except Exception as e:
            logger.error(f"{TAG} Failed to deploy {filename} -> {dest}: {e}")
            ok = False

    # 2. Restart services
    for svc in SERVICES:
        result = SystemServices.reload_or_restart(ctx, svc, skip_reload=True, non_blocking=True)
        if result.ok:
            logger.notice(f"{TAG} Service {svc} restart requested.")
        else:
            logger.error(f"{TAG} Failed to restart {svc}: {result.msg}")
            ok = False

    if ok:
        logger.notice(f"{TAG} Migration completed successfully.")
    else:
        logger.notice(f"{TAG} Migration completed with errors (check logs).")
    return ok
