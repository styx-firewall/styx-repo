"""
Migration script: -> 0.43.8

- Updates rsyslog.conf to include explicit FileCreateMode for the imjournal
  module, silencing a warning introduced in rsyslog v8.2504.0.
- Deploys igmpproxy.service systemd unit.
"""

import os
import shutil

from core.app_context import AppContext
from services.system_services import SystemServices

TAG = "[MIGRATE 0.43.8]"

TEMPLATES = {
    "rsyslog.conf": ("/etc/rsyslog.conf", 0o644),
    "igmpproxy.service": ("/etc/systemd/system/igmpproxy.service", 0o644),
}


def run(ctx: AppContext) -> bool:
    """Deploy updated config templates and restart rsyslog."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    src_dir = "/opt/styx-gateway/files/cfg-tpl"
    ok = True

    for filename, (dest, mode) in TEMPLATES.items():
        src = os.path.join(src_dir, filename)
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            os.chmod(dest, mode)
            logger.notice(f"{TAG} Deployed {filename} -> {dest} (mode {oct(mode)})")
        except Exception as e:
            logger.error(f"{TAG} Failed to deploy {filename} -> {dest}: {e}")
            ok = False

    result = SystemServices.reload_or_restart(ctx, "rsyslog", skip_reload=True, non_blocking=True)
    if result.ok:
        logger.notice(f"{TAG} rsyslog restart requested.")
    else:
        logger.error(f"{TAG} Failed to restart rsyslog: {result.msg}")
        ok = False

    if ok:
        logger.notice(f"{TAG} Migration completed successfully.")
    else:
        logger.notice(f"{TAG} Migration completed with errors (check logs).")
    return ok
