"""
Migration script: -> 0.46.37

Backfills per-interface DHCP refs on config_interfaces.

Before this migration, DHCP per-interface entries in dhcp_server.interfaces
did not register refs on the config_interfaces entry of the interface they
configure. From 0.46.37 on, DHCPServerService registers the entry's UUID id
as a ref whenever config/reservations/binding exist for an interface, and
delete_dhcp_config removes it. This migration backfills refs for entries
created before 0.46.37 so the InterfaceLifecycleService delete guard is
consistent for pre-existing configs.

Steps performed:
  1. Ensure every per-interface DHCP entry has a UUID ``id`` field,
     generating one if missing.
  2. Register that id as a ref on the config_interfaces entry of the
     interface, when the interface still exists.
"""

import uuid

from constants.datastore_keys import DS_KEY_CONFIG_INTERFACES, DS_KEY_DHCP_SERVER
from core.app_context import AppContext

TAG = "[MIGRATE 0.46.37]"
STORE = "startup-config"


def run(ctx: AppContext) -> bool:
    """Backfill per-interface DHCP refs on config_interfaces."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    ds = ctx.get_datastore()

    # 1. Load DHCP config
    dhcp_top = ds.get_data(DS_KEY_DHCP_SERVER, store=STORE)
    if not dhcp_top or not isinstance(dhcp_top, dict):
        logger.info(f"{TAG} No DHCP config found -- nothing to migrate.")
        return True

    interfaces = dhcp_top.get("interfaces")
    if not isinstance(interfaces, dict) or not interfaces:
        logger.info(f"{TAG} No per-interface DHCP entries found -- nothing to migrate.")
        return True

    # 2. Ensure every per-interface entry has a UUID id
    dhcp_modified = False
    for iface_key, entry in interfaces.items():
        if not isinstance(entry, dict):
            continue
        if not entry.get("id"):
            entry["id"] = str(uuid.uuid4())
            dhcp_modified = True
            logger.info(f"{TAG} Added id={entry['id']} to interface entry '{iface_key}'")

    if dhcp_modified:
        if not ds.replace_data(DS_KEY_DHCP_SERVER, dhcp_top, store=STORE):
            logger.error(f"{TAG} Failed to persist DHCP config with new UUID ids.")
            return False
        logger.info(f"{TAG} Persisted DHCP config with new UUID ids.")

    # 3. Backfill refs on config_interfaces entries that still exist
    config_ifaces = ds.get_data(DS_KEY_CONFIG_INTERFACES, store=STORE) or []
    if not isinstance(config_ifaces, list):
        config_ifaces = []

    by_id = {item.get("id"): item for item in config_ifaces if isinstance(item, dict)}
    iface_modified = False
    for iface_key, entry in interfaces.items():
        if not isinstance(entry, dict):
            continue
        item = by_id.get(iface_key)
        if item is None:
            # Interface deleted: nothing to anchor a ref on.
            continue
        iid = entry.get("id")
        if not iid:
            continue
        refs = item.get("refs") if isinstance(item.get("refs"), list) else []
        if iid not in refs:
            refs.append(iid)
            item["refs"] = refs
            iface_modified = True
            logger.info(f"{TAG} Registered ref {iid} on interface '{iface_key}'")

    if iface_modified:
        if not ds.replace_data(DS_KEY_CONFIG_INTERFACES, config_ifaces, store=STORE):
            logger.error(f"{TAG} Failed to persist config_interfaces with backfilled refs.")
            return False
        logger.info(f"{TAG} Persisted config_interfaces with backfilled refs.")

    logger.notice(f"{TAG} Migration completed successfully.")
    return True
