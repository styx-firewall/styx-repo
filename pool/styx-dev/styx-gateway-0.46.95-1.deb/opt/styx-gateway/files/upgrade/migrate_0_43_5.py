"""
Migration script: -> 0.43.5

Installs smartmontools (smartctl / smartd) on the system.
smartmontools provides S.M.A.R.T. monitoring and diagnostics for ATA, SCSI,
and NVMe storage devices.

Uses the SystemPackages service for installation, which handles apt-get
locking, non-interactive mode, and proper error reporting.
The smartd daemon is automatically enabled and started by the package's
postinst script.
"""

from core.app_context import AppContext
from services.system_packages import SystemPackages

TAG = "[MIGRATE 0.43.5]"
PACKAGE = "smartmontools"


def run(ctx: AppContext) -> bool:
    """Ensure smartmontools is installed via the SystemPackages service."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started -- ensuring {PACKAGE} is installed.")

    # refresh_cache=False: el MemoryDataStore aún no existe durante el upgrade
    result = SystemPackages.install_package(ctx, PACKAGE, refresh_cache=False)

    if result.get("status") == "success":
        logger.notice(f"{TAG} Migration completed -- {PACKAGE} installed successfully.")
        return True

    logger.error(f"{TAG} Migration failed -- could not install {PACKAGE}: " f"{result.get('message', 'unknown error')}")
    return False
