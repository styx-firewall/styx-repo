"""
Migration script: -> 0.40.30

Migrates DHCP server reference IDs from composite strings to standard UUIDs.

Before this migration, DHCP registered refs on address/domain sets using:
  - "dhcp_global_config"           for global config references
  - "dhcp_iface_<interface_id>"    for per-interface references

After this migration, refs use the UUID stored in each DHCP sub-entity's ``id``
field (which was already being generated on write since an earlier version but
never used as the actual ref identifier).

Steps performed:
  1. Ensure every DHCP sub-entity (global config + each interface entry) has
     a UUID ``id`` field, generating one if missing.
  2. Build a mapping of old-style ref → new UUID.
  3. Walk all address sets and domain sets, replacing old composite-string refs
     with their corresponding UUIDs.
"""

import uuid

from constants.datastore_keys import DS_KEY_DHCP_SERVER, DS_KEY_SET_ADDRESS, DS_KEY_SET_DOMAIN
from core.app_context import AppContext

TAG = "[MIGRATE 0.40.30]"

# Legacy ref markers
_LEGACY_GLOBAL = "dhcp_global_config"
_LEGACY_IFACE_PREFIX = "dhcp_iface_"


def _build_ref_map(dhcp_top: dict, logger) -> dict:
    """Build a map old_ref_string → new_UUID from the DHCP datastore entry.

    Also ensures every sub-entity has a UUID ``id``, generating one on the fly
    if missing (legacy entries from before the id field was introduced).
    """
    ref_map = {}
    modified = False

    # Global config
    global_cfg = dhcp_top.get("global_config")
    if isinstance(global_cfg, dict):
        gid = global_cfg.get("id") or str(uuid.uuid4())
        if not global_cfg.get("id"):
            global_cfg["id"] = gid
            modified = True
            logger.info(f"{TAG} Added id={gid} to global_config")
        ref_map[_LEGACY_GLOBAL] = gid

    # Per-interface entries
    interfaces = dhcp_top.get("interfaces")
    if isinstance(interfaces, dict):
        for iface_name, entry in interfaces.items():
            if not isinstance(entry, dict):
                continue
            iid = entry.get("id") or str(uuid.uuid4())
            if not entry.get("id"):
                entry["id"] = iid
                modified = True
                logger.info(f"{TAG} Added id={iid} to interface entry '{iface_name}'")
            old_ref = f"{_LEGACY_IFACE_PREFIX}{iface_name}"
            ref_map[old_ref] = iid

    return ref_map, modified


def _migrate_set_refs(datastore, set_key: str, ref_map: dict, logger, store: str) -> int:
    """Replace legacy ref strings with UUIDs in a set type (address or domain).

    Returns the number of sets that were modified.
    """
    entries = datastore.get_data(set_key, store=store) or []
    if not isinstance(entries, list):
        return 0

    changed = 0
    for entry in entries:
        refs = entry.get("refs") or []
        if not isinstance(refs, list):
            continue
        new_refs = []
        entry_changed = False
        for r in refs:
            r_str = str(r)
            if r_str in ref_map:
                new_ref = ref_map[r_str]
                if new_ref not in new_refs:
                    new_refs.append(new_ref)
                entry_changed = True
                logger.debug(f"{TAG} {set_key}[{entry.get('name', entry.get('id'))}]: '{r_str}' → '{new_ref}'")
            else:
                if r_str not in new_refs:
                    new_refs.append(r_str)
        if entry_changed:
            entry["refs"] = new_refs
            changed += 1

    if changed:
        datastore.replace_data(set_key, entries, store=store)

    return changed


def run(ctx: AppContext) -> bool:
    """Migrate DHCP refs from composite strings to standard UUIDs."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    ds = ctx.get_datastore()
    STORE = "startup-config"

    # 1. Load DHCP config
    dhcp_top = ds.get_data(DS_KEY_DHCP_SERVER, store=STORE)
    if not dhcp_top or not isinstance(dhcp_top, dict):
        logger.info(f"{TAG} No DHCP config found -- nothing to migrate.")
        return True

    # 2. Build ref map and ensure UUID ids exist
    ref_map, dhcp_modified = _build_ref_map(dhcp_top, logger)

    if not ref_map:
        logger.info(f"{TAG} No DHCP sub-entities found -- nothing to migrate.")
        return True

    logger.info(f"{TAG} Built ref map with {len(ref_map)} entries: {list(ref_map.keys())}")

    # 3. Persist DHCP if we added any missing ids
    if dhcp_modified:
        if not ds.replace_data(DS_KEY_DHCP_SERVER, dhcp_top, store=STORE):
            logger.error(f"{TAG} Failed to persist DHCP config with new UUID ids.")
            return False
        logger.info(f"{TAG} Persisted DHCP config with new UUID ids.")

    # 4. Migrate refs on address and domain sets
    addr_changed = _migrate_set_refs(ds, DS_KEY_SET_ADDRESS, ref_map, logger, STORE)
    dom_changed = _migrate_set_refs(ds, DS_KEY_SET_DOMAIN, ref_map, logger, STORE)

    logger.notice(
        f"{TAG} Migration completed. " f"Address sets updated: {addr_changed}, domain sets updated: {dom_changed}."
    )
    return True
