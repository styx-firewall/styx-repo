"""
Migration script: -> 0.44.3

- Deploys updated ulogd.conf with:
  - HWHDR plugin replacing PRINTPKT for structured MAC fields
  - Second stack (NFCT → IP2STR → JSON) for conntrack flow logs
  - Removes unused plugins (UNIXSOCK, PRINTPKT, PRINTFLOW, MARK, NFACCT)
- Enables nf_conntrack_acct sysctl so NFCT flow logs include byte/packet counters.
- Restarts ulogd2 to apply the new configuration.
"""

import os
import shutil

from core.app_context import AppContext
from services.system_services import SystemServices

TAG = "[MIGRATE 0.44.3]"

TEMPLATES = {
    "ulogd.conf": ("/etc/ulogd.conf", 0o644),
}


def run(ctx: AppContext) -> bool:
    """Deploy updated ulogd.conf and restart ulogd2."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    src_dir = "/opt/styx-gateway/files/cfg-tpl"
    ok = True

    for filename, (dest, mode) in TEMPLATES.items():
        src = os.path.join(src_dir, filename)
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            os.chmod(dest, mode)
            logger.notice(f"{TAG} Deployed {filename} -> {dest} (mode {oct(mode)})")
        except Exception as e:
            logger.error(f"{TAG} Failed to deploy {filename} -> {dest}: {e}")
            ok = False

    # Enable conntrack accounting and tune timeouts for flow logs
    try:
        import subprocess

        sysctls = {
            "kernel.unprivileged_bpf_disabled": "1",
            "net.netfilter.nf_conntrack_acct": "1",
            "net.netfilter.nf_conntrack_tcp_timeout_established": "7200",
            "net.netfilter.nf_conntrack_tcp_timeout_time_wait": "60",
            "net.netfilter.nf_conntrack_udp_timeout_stream": "60",
            "net.netfilter.nf_conntrack_generic_timeout": "300",
        }
        for key, val in sysctls.items():
            subprocess.run(["sysctl", "-w", f"{key}={val}"], capture_output=True, text=True)

        # Persist across reboots via sysctl.d drop-in
        dropin = "/etc/sysctl.d/30-styx-conntrack.conf"
        os.makedirs(os.path.dirname(dropin), exist_ok=True)
        with open(dropin, "w") as f:
            f.write("# Styx Gateway -- conntrack tuning for flow logs\n")
            for key, val in sysctls.items():
                f.write(f"{key} = {val}\n")
        os.chmod(dropin, 0o644)
        logger.notice(f"{TAG} Applied conntrack sysctls and wrote {dropin}.")
    except Exception as e:
        logger.error(f"{TAG} Failed to apply conntrack sysctls: {e}")
        ok = False

    result = SystemServices.reload_or_restart(ctx, "ulogd2", skip_reload=True, non_blocking=False)
    if result.ok:
        logger.notice(f"{TAG} ulogd2 restarted with new configuration.")
    else:
        logger.error(f"{TAG} Failed to restart ulogd2: {result.msg}")
        ok = False

    if ok:
        logger.notice(f"{TAG} Migration completed successfully.")
    else:
        logger.notice(f"{TAG} Migration completed with errors (check logs).")
    return ok
