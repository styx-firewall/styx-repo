"""
Migration script: -> 0.43.11

Combined re-run of 0.43.5 + 0.43.6 for systems where the original
migrations were skipped due to missing PyInstaller bundle data.

- 0.43.5: Installs smartmontools (S.M.A.R.T. monitoring)
- 0.43.6: Deploys journald.conf + rsyslog.conf, restarts services
"""

import os
import shutil

from core.app_context import AppContext
from services.system_packages import SystemPackages
from services.system_services import SystemServices

TAG = "[MIGRATE 0.43.11]"

# --- 0.43.5: smartmontools ---
PACKAGE = "smartmontools"

# --- 0.43.6: journald + rsyslog ---
TEMPLATES = {
    "journald.conf": "/etc/systemd/journald.conf",
    "rsyslog.conf": "/etc/rsyslog.conf",
}
SERVICES = ["systemd-journald", "rsyslog"]


def run(ctx: AppContext) -> bool:
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")
    ok = True

    # -- 0.43.5: smartmontools --
    logger.notice(f"{TAG} [0.43.5] Ensuring {PACKAGE} is installed.")
    result = SystemPackages.install_package(ctx, PACKAGE, refresh_cache=False)
    if result.get("status") == "success":
        logger.notice(f"{TAG} [0.43.5] {PACKAGE} installed.")
    else:
        logger.error(f"{TAG} [0.43.5] Failed to install {PACKAGE}: {result.get('message', '?')}")
        ok = False

    # -- 0.43.6: journald.conf + rsyslog.conf + restart --
    src_dir = "/opt/styx-gateway/files/cfg-tpl"
    for filename, dest in TEMPLATES.items():
        src = os.path.join(src_dir, filename)
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            logger.notice(f"{TAG} [0.43.6] Deployed {filename} -> {dest}")
        except Exception as e:
            logger.error(f"{TAG} [0.43.6] Failed to deploy {filename}: {e}")
            ok = False

    for svc in SERVICES:
        result = SystemServices.reload_or_restart(ctx, svc, skip_reload=True, non_blocking=True)
        if result.ok:
            logger.notice(f"{TAG} [0.43.6] {svc} restart requested.")
        else:
            logger.error(f"{TAG} [0.43.6] Failed to restart {svc}: {result.msg}")
            ok = False

    if ok:
        logger.notice(f"{TAG} Migration completed successfully.")
    else:
        logger.notice(f"{TAG} Migration completed with errors (check logs).")
    return ok
