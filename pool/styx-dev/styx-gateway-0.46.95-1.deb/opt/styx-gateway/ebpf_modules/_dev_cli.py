#!/usr/bin/env python3
"""CLI to load an eBPF module and print formatted map data.

Usage:
    python3 ebpf_modules/_dev_cli.py ping_monitor --interface eth0
    python3 ebpf_modules/_dev_cli.py net_block --interface eth0 --push blocklist 10.0.0.1
    python3 ebpf_modules/_dev_cli.py net_block --interface eth0 --map blocklist
"""

import argparse
import json
import pathlib
import sys

EBPF_MODULES = pathlib.Path("/opt/styx-gateway/ebpf_modules")
STYX_ROOT = pathlib.Path("/opt/styx-gateway")
sys.path.insert(0, str(STYX_ROOT))
sys.path.insert(0, str(EBPF_MODULES))


def load_module(module_name: str, interface: str | None = None):
    """Load a module into the kernel using ModuleManager."""
    from services.ebpf.ebpf_module_loader import load_package
    from services.ebpf.module_manager import ModuleManager

    pkg_dir = EBPF_MODULES / module_name
    desc = load_package(pkg_dir)

    # Dummy ctx for ModuleManager
    class Ctx:
        def get_logger(self):
            import logging

            return logging.getLogger("dev")

    mm = ModuleManager(Ctx(), modules_dir=str(EBPF_MODULES))

    if interface:
        desc.interface = interface
    mod = mm.load(desc)
    return mm, mod


def read_maps(mod, companion, map_name: str | None = None):
    """Read entries from BPF maps and run through format_map_entry."""
    fmt = getattr(companion, "format_map_entry", None) if companion else None

    for cm in mod.descriptor.control_maps:
        if map_name and cm.name != map_name:
            continue

        bpf_map = mod.control_maps[cm.name]
        keys = bpf_map.keys()
        print(f"\n-- {cm.name} (dir={cm.direction}, entries={len(keys)})")

        for k in keys[:100]:
            try:
                v = bpf_map[k]
            except Exception:
                v = None

            if fmt:
                try:
                    key_repr, val_repr = fmt(k, v, cm.name)
                except Exception:
                    key_repr, val_repr = _raw(k), _raw(v)
            else:
                key_repr, val_repr = _raw(k), _raw(v)

            print(f"  {json.dumps(key_repr, default=str)} → {json.dumps(val_repr, default=str)}")


def push_data(mm, mod, companion, map_name: str, items: list):
    """Push data to a control map via companion.serialize_entry."""
    ser = getattr(companion, "serialize_entry", None) if companion else None
    if not ser:
        raise SystemExit(f"No serialize_entry in companion for '{mod.descriptor.name}'")

    entries = ser(items, map_name, "upsert")
    bpf_map = mod.control_maps[map_name]

    for (k, v), item in zip(entries, items):
        bpf_map[k] = v
        print(f"  pushed: {json.dumps(item)}")


def _raw(obj):
    if obj is None:
        return None
    if isinstance(obj, bytes):
        return list(obj)
    if isinstance(obj, (int, float, str, bool)):
        return obj
    try:
        return obj.value
    except AttributeError:
        pass
    return str(obj)


def main():
    parser = argparse.ArgumentParser(description="Load an eBPF module and print map data")
    parser.add_argument("module", help="Module directory name")
    parser.add_argument("--interface", "-i", help="Interface to attach to")
    parser.add_argument("--map", "-m", help="Only show this map")
    parser.add_argument(
        "--push",
        "-p",
        nargs="+",
        metavar="ITEM",
        help="Push data then read. Usage: --push <map_name> <item1> [item2...]",
    )
    parser.add_argument(
        "--watch",
        "-w",
        type=float,
        nargs="?",
        const=1.0,
        metavar="SEC",
        help="Keep polling every SEC seconds (default 1s). Ctrl+C to stop.",
    )
    args = parser.parse_args()

    print(f"Loading {args.module}...")
    mm, mod = load_module(args.module, args.interface)
    companion = getattr(mod, "_companion_module", None)
    print(f"Loaded: {mod.instance_id}  companion: {'yes' if companion else 'no'}")

    if args.push:
        map_name = args.push[0]
        items = args.push[1:] if len(args.push) > 1 else []
        if not items:
            raise SystemExit("--push requires items after map name")
        push_data(mm, mod, companion, map_name, items)

    try:
        if args.watch:
            interval = args.watch if isinstance(args.watch, (int, float)) else 1.0
            print(f"\nWatching (Ctrl+C to stop, interval={interval}s)...")
            import time

            while True:
                _clear_screen()
                print(f"-- {mod.descriptor.name} ({mod.instance_id[:8]}) -- {time.strftime('%H:%M:%S')}")
                read_maps(mod, companion, args.map)
                time.sleep(interval)
        else:
            print("\n═══ Map entries ═══")
            read_maps(mod, companion, args.map)
    except KeyboardInterrupt:
        pass

    print(f"\nUnloading {mod.instance_id}...")
    mm.unload(mod.instance_id)


def _clear_screen():
    print("\033[2J\033[H", end="")


if __name__ == "__main__":
    main()
