# eBPF Module Reference

## Overview

An **eBPF module** is a self-contained directory that packages a BPF program
(kernel-side) together with its configuration, telemetry definitions, and a
Python companion (userspace-side).  The gateway loads, attaches, monitors, and
manages these modules at runtime — no manual `tc` or `bpftool` commands needed.

### Anatomy of a module

Every module has three required files plus a BPF program.  What the BPF program
looks like depends on `module_type`:

**`core` module (production):**

```
my_module/
├── my_module.o              ← pre-compiled bytecode (required at runtime)
├── my_module_companion.py   ← userspace glue
├── module.toml              ← manifest
├── my_module.c              ← BPF program source (build-time)
├── vmlinux.h                ← kernel types (build-time, CO-RE)
└── Makefile                 ← build rules
```

**`bcc` module (dev):**

```
my_module/
├── my_module.c              ← BPF program (compiled at load time by BCC)
├── my_module_companion.py   ← userspace glue
├── module.toml              ← manifest
└── Makefile                 ← build rules
```

In both cases there are two halves:

| Side | Runs in | Responsibility |
|---|---|---|
| **BPF program** (`.c`) | Kernel | Inspects packets, updates maps, drops traffic, emits events. |
| **Companion** (`.py`) | Userspace | Serializes admin input for control maps, deserializes telemetry output for the UI, formats entries. |

The `module.toml` is the bridge: it declares which maps exist, what direction
data flows, how often to poll, and which companion to load.

### Three kinds of maps

Every BPF map belongs to one of three roles.  Choose based on *how* the data
is consumed:

| | Control maps | Telemetry maps | Events |
|---|---|---|---|
| **Purpose** | Configuration (push rules in) or on-demand state (pull tables out) | Real-time gauges and counters — polled automatically | Discrete occurrences that need a permanent record |
| **Trigger** | Admin action (`map-push` / `map-get`) | Timer (every N ms) | Kernel pushes; drained each poll cycle |
| **Direction** | `"input"` (admin→kernel), `"output"` (kernel→admin), or both | Kernel → admin | Kernel → admin |
| **Data shape** | Key-value pairs (any BPF map type) | A single value or a table of time-series points | Individual events with timestamp, severity, tags |
| **History** | No — each read returns the current state | Short-term (~100 points in memory, lost on restart) | Yes — persisted to `events.jsonl` on disk |
| **Examples** | Blocklist of IPs, per-IP stats table, MAC→IP table | Packet counters, drop counters, new-hosts-per-interval | "Flood detected", "packet dropped", "certificate expired" |
| **Companion hook** | `serialize_entry` (input), `format_map_entry` (output) | `@register_deserializer` (`from_map`) | `@register_deserializer` (`from_event`) |

A module can have zero or more of each.  `mac_sniffer` is a good example of
mixing roles: one control output map (the MAC→IP table) plus one telemetry
map (new-MACs-per-interval counter).

### Hook types at a glance

The `hook_type` decides *where* in the network stack the program runs:

| Hook | Runs at… | Interface |
|---|---|---|
| `xdp` | NIC driver (before kernel stack) | Required |
| `tc_egress` / `tc_ingress` | Traffic control (after stack) | Required |
| `socket_filter` | Raw socket (passive sniff) | Optional (`"*"` = all) |
| `kprobe/<fn>` | Kernel function entry | None |
| `tracepoint/<cat>/<event>` | Static tracepoint | None |

### Module types: `core` vs `bcc`

The `module_type` field tells Styx *how* to turn source into a running BPF program:

| | `module_type = "core"` | `module_type = "bcc"` |
|---|---|---|
| **Source** | `.c` compiled once with `clang` → `.o` bytecode | `.c` compiled at load time by BCC |
| **`object_file`** | `"my_module.o"` (pre-built) | `"my_module.c"` (source) |
| **Loader** | libbpf (CO-RE, portable across kernels) | python3-bpfcc (needs kernel headers) |
| **Feature flag** | `ebpf_core` | `ebpf_bcc` (dev mode) |
| **Use** | **Production** | **Development / testing** |

### Lifecycle

1. **Discover** — `module.toml` is parsed, companion is imported.
2. **Configure** — admin sets pre-attach params and interface.
3. **Load** — BPF bytecode is verified and loaded into the kernel.
4. **Attach** — program is attached to the declared hook (XDP dispatcher, TC filter, socket, kprobe, …).
5. **Operate** — admin pushes control data, telemetry collector polls maps, events are drained from ring buffers.
6. **Unload** — program is detached, maps are destroyed.

### Where to start

- Read this reference for the full `module.toml` schema.
- Look at `ip_drop/` for a minimal production module (XDP, 1 control map, 1 telemetry map).
- Look at `ping_monitor/` for a module with events (ring buffer alerts).
- Look at `mac_sniffer/` for a non-XDP hook (`socket_filter`).
- Use `_helpers.py` in your companion for common serialization tasks.

---

## `[module]` — required

| Key | Type | Required | Default | Description |
|---|---|---|---|---|
| `name` | string | **yes** | — | Unique module identifier. Must match the directory name. |
| `version` | string | **yes** | — | Semver, e.g. `"0.1.0"`. |
| `object_file` | string | **yes** | — | Path relative to the module directory. `.o` for core, `.c` for bcc. |
| `hook_type` | string | **yes** | — | `xdp`, `tc_egress`, `tc_ingress`, `socket_filter`, `kprobe/<fn>`, `tracepoint/<cat>/<event>`. |
| `module_type` | string | no | `"core"` | `"core"` = CO-RE (libbpf, pre-compiled `.o`), `"bcc"` = dev-mode (BCC, `.c` compiled at runtime). |
| `requires_kernel` | string | no | `"5.10"` | Minimum kernel version, e.g. `"5.15"`. |
| `author` | string | no | `""` | |
| `description` | string | no | `""` | One-line summary shown in the admin UI. |
| `usage` | string | no | `""` | Extended help (markdown). Shown in the UI on module detail. |
| `tags` | string[] | no | `[]` | Free-form tags, e.g. `["security", "xdp"]`. |
| `interface` | string | no | `""` | Default interface name or `"*"` (all). Resolved at load time from a Styx interface UUID. |
| `bpf_fn_name` | string | no | `""` | BPF C function name. Required for BCC; for core it is used in kernel-state matching. |
| `companion` | string | no | — | Python module name (without `.py`) in the same directory. Loaded at descriptor-parse time. |
| `priority` | int | no | `50` | Execution priority for libxdp dispatcher / TC. Higher = runs first. |
| `init_hook` | string | no | `""` | Companion function name called after BPF load+attach to populate maps programmatically (e.g. CPUMAP, DEVMAP). See [Init hook](#init-hook-populate_init_maps). |
| `enabled` | bool | no | `true` | `false` = module appears as incompatible in module-list and cannot be loaded. Use for modules with known incompatibilities (e.g. CPUMAP + libxdp dispatcher). |

### `attach_target` (inferred)

Never set manually. Derived automatically from `hook_type`:

| `hook_type` | `attach_target` | Meaning |
|---|---|---|
| `xdp`, `tc_egress`, `tc_ingress` | `"interface"` | Requires a network interface. |
| `socket_filter` | `"interface_optional"` | Accepts an interface or `"*"`. |
| `kprobe/…`, `tracepoint/…` | `"none"` | No interface needed. |

---

## `[[pre_attach_param]]` — optional, repeatable

Parameters the admin sets **before** the module is attached. Cannot be changed
without a reload.

| Key | Type | Required | Default | Description |
|---|---|---|---|---|
| `name` | string | **yes** | — | Attribute name set on the descriptor. |
| `type` | string | **yes** | — | `"int"`, `"string"`, or `"bool"`. |
| `label` | string | no | `name` | Human-readable label for the UI. |
| `description` | string | no | `""` | Help text. |
| `default` | int/string/bool | no | — | Applied at parse time if the admin doesn't override. |
| `required` | bool | no | `false` | |
| `min` | int | no | — | Only for `type="int"`. |
| `max` | int | no | — | Only for `type="int"`. |
| `choices` | string[] | no | — | Only for `type="string"`. |

Example:

```toml
[[pre_attach_param]]
name        = "priority"
type        = "int"
label       = "XDP Priority"
description = "Execution order (0-100, higher = runs first)"
default     = 50
min         = 0
max         = 100
required    = false
```

---

## `[[control_map]]` — optional, repeatable

BPF maps the admin interacts with on demand via `ebpf.map-get` / `ebpf.map-push`.
Can be **input** (admin writes config, kernel reads it), **output** (kernel writes
data, admin reads it), or both. Output control maps are read explicitly — they are
not polled automatically.

Companion hooks: `serialize_entry` (push), `format_map_entry` (get).

| Key | Type | Required | Default | Description |
|---|---|---|---|---|
| `name` | string | **yes** | — | Must match the C variable name (with `SEC(".maps")`). |
| `key_schema` | string | **yes** | — | BPF key type, e.g. `"u32"`, `"struct lpm_key"`. |
| `value_schema` | string | **yes** | — | BPF value type, e.g. `"u8"`, `"struct icmp_stats_t"`. |
| `max_entries` | int | no | `65536` | Map capacity. |
| `supported_ops` | string[] | no | `[]` | `"replace_all"`, `"upsert"`, `"delete"`. Empty = output-only. |
| `batch_supported` | bool | no | `true` | Whether `replace_all` uses the batch syscall (faster). |
| `direction` | string | no | `"input"` | `"input"` (admin→kernel) or `"output"` (kernel→admin, read-only). |
| `editor` | string | no | `""` | UI hint: `"table"`, `"chip"`, `"single"`, `"keyvalue"`. |
| `key_label` | string | no | `""` | Column header for the key in the UI. |
| `value_label` | string | no | `""` | Column header for the value in the UI. |

### `[[control_map.entry]]` — optional, repeatable

Default entries seeded at load time. Only meaningful for `direction="input"`.

| Key | Type | Required | Description |
|---|---|---|---|
| `key` | int/string | **yes** | |
| `value` | int/string | **yes** | |
| `label` | string | no | Human-readable label for the UI. |

Example:

```toml
[[control_map]]
name             = "blocklist"
key_schema       = "u32"
value_schema     = "u8"
max_entries      = 1024
supported_ops    = ["replace_all", "upsert", "delete"]
batch_supported  = false
direction        = "input"
editor           = "chip"
key_label        = "IP address"

[[control_map.entry]]
key   = 0
value = 1
label = "Default entry"
```

---

## `[[telemetry_map]]` — optional, repeatable

BPF maps polled automatically on a timer by the telemetry collector. Each poll
reads all entries, aggregates per-CPU values, runs the companion deserializer,
and publishes time-series points to subscribers.  Results are exposed via
`ebpf.telemetry-get`.

Supports `"snapshot"` (absolute values) and `"delta"` (rate since last poll)
semantics.  Hash maps produce one time-series per key; array maps produce a
single time-series.  The response includes `telemetry_maps` metadata so the
frontend knows whether to render a single KPI or a table.

Companion hook: `@register_deserializer`.

| Key | Type | Required | Default | Description |
|---|---|---|---|---|
| `name` | string | **yes** | — | Must match the C variable name. |
| `value_type` | string | **yes** | — | C struct/type name, e.g. `"struct stats_t"`, `"struct host_entry"`. |
| `poll_interval_ms` | int | no | `1000` | How often the map is read. |
| `semantics` | string | no | `"snapshot"` | `"snapshot"` = absolute values, `"delta"` = rate since last poll. |
| `reset_on_read` | bool | no | `false` | If `true`, the map is cleared after each successful poll. |
| `max_keys_per_poll` | int | no | `0` | Pagination limit. `0` = read all keys at once. |

Example:

```toml
[[telemetry_map]]
name             = "hosts"
value_type       = "struct host_entry"
poll_interval_ms = 5000
semantics        = "snapshot"
```

---

## `[[event]]` — optional, repeatable

Ring-buffer or perf-buffer maps where the kernel *pushes* discrete events in real
time (alerts, drops, discoveries).  Events are drained on every telemetry poll
cycle and either persisted to disk or forwarded to subscribers immediately.  Each
event carries a timestamp, severity, and tags.

Unlike telemetry (periodic snapshot of state), events represent individual
occurrences: "a packet was dropped", "a flood was detected".  They are not
cumulative counters.

Companion hook: `@register_deserializer` (implements `from_event`).

| Key | Type | Required | Default | Description |
|---|---|---|---|---|
| `name` | string | **yes** | — | Must match the C variable name. |
| `buffer_type` | string | no | `"ring_buffer"` | `"ring_buffer"` (kernel ≥5.8) or `"perf_buffer"`. |
| `tags` | string[] | no | `[]` | e.g. `["alert", "ddos"]`. |
| `severity` | string | no | `"info"` | `"debug"`, `"info"`, `"warn"`, `"crit"`. |
| `drop_policy` | string | no | `"drop"` | `"drop"` = lose events if buffer full, `"sample"` = keep latest. |
| `schema_type` | string | no | `"event"` | `"event"` or `"security_event"` (for security-audit routing). |

Example:

```toml
[[event]]
name         = "drop_events"
buffer_type  = "ring_buffer"
tags         = ["alert", "ddos"]
severity     = "warn"
drop_policy  = "sample"
schema_type  = "security_event"
```

---

## Companion module contract (`.py`)

Declared via `companion = "name"` in `[module]`.  The companion **must** live
in the same directory as `module.toml` and exposes these optional hooks:

### `serialize_entry(items, map_name, op)`

Called when the admin pushes data to a control map.  Must return a list of
`(key_ctypes, value_ctypes)` tuples ready for `bpf_map_update_elem`.

Use `from _helpers import serialize_ipv4, serialize_cidr, serialize_uint32` for
common types.

### `format_map_entry(key, value, map_name)`

Called when the admin reads a control map.  Must return `(key_repr, value_repr)`
as JSON-safe Python objects, or `(None, None)` if the companion does not handle
this map.

Use `from _helpers import format_ipv4, format_cidr, format_uint32` for common types.

### `@register_deserializer(module_name, map_name)`

Class decorator that registers a `FeedbackDeserializer` subclass for a telemetry
or event map.  Must implement:

- `from_map(self, raw, spec, key=None) -> dict` — parse a BPF map value.
- `from_event(self, data, size, spec) -> dict` — parse a ring-buffer event.

`raw` is either `bytes` (single value) or `list[bytes]` (per-CPU slices).
Use `from _helpers import aggregate_percpu` to sum fields across CPUs.

### Init hook (`populate_init_maps`)

Declared via `init_hook = "function_name"` in `[module]`.  The named function
is called by `EbpfService.load_module()` **after** the BPF backend loads and
attaches the program, and after static `[[control_map.entry]]` seeding, but
before the instance is persisted to the datastore.

```python
def populate_init_maps(mod, descriptor):
    """Populate maps that need programmatic initialisation at load time.

    Args:
        mod: LoadedModule — mod.control_maps dict of live _BpfMap objects
        descriptor: ModuleDescriptor — pre_attach_params already applied
    """
    cpu_list = descriptor.cpu_list
    for cpu in parse_cpu_list(cpu_list):
        mod.control_maps["cpu_map"][key] = val
```

**Why not `[[control_map.entry]]`?**  Some BPF map types need values that
cannot be hardcoded in TOML — they depend on host hardware (CPUMAP, DEVMAP,
XSKMAP), open file descriptors, or runtime topology.  The init hook receives
the live maps and the parsed descriptor so it can compute entries dynamically.

**Contract:**
- Runs once per instance inside `module-load` / `module-reload`.
- `ValueError` raised by the hook **propagates** and triggers rollback
  (module is unloaded, instance is not persisted).
- Other exceptions are logged as warnings; the module loads anyway.
- Modules without `init_hook` are unaffected.

---

## Full minimal example

```toml
# my_module/module.toml
[module]
name            = "my_module"
version         = "0.1.0"
author          = "acme"
description     = "What this module does"
usage           = """
## Control maps
- blocklist: IPv4 addresses to act on.
## Telemetry
- stats: packet counters polled every 2 s.
"""
object_file     = "my_module.o"
hook_type       = "xdp"
requires_kernel = "5.15"
tags            = ["example"]
module_type     = "core"
bpf_fn_name     = "my_module_prog"
companion       = "my_module_companion"

[[control_map]]
name             = "blocklist"
key_schema       = "u32"
value_schema     = "u8"
supported_ops    = ["replace_all", "upsert", "delete"]
editor           = "chip"
key_label        = "IP address"

[[telemetry_map]]
name             = "stats"
value_type       = "struct stats_t"
poll_interval_ms = 2000
semantics        = "snapshot"
```
