// bcc_counter.c — BCC XDP packet counter by source IP
//
// Uses BCC map syntax (BPF_HASH, BPF_PERCPU_ARRAY).  Loaded by BccBackend
// in DEV mode (ebpf_test feature).  Not compatible with CO-RE/libbpf.

#include <uapi/linux/bpf.h>
#include <uapi/linux/if_ether.h>
#include <uapi/linux/ip.h>

// Per-IP counter (hash map, key=IP, value=packet count)
BPF_HASH(counters, u32, u64, 65536);

// Aggregated stats (per-CPU, avoids contention)
BPF_PERCPU_ARRAY(stats, u64, 1);

int count_packets(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;
    void *data = (void *)(long)ctx->data;

    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end)
        return XDP_PASS;

    if (eth->h_proto != __constant_htons(ETH_P_IP))
        return XDP_PASS;

    struct iphdr *ip = data + sizeof(*eth);
    if ((void *)(ip + 1) > data_end)
        return XDP_PASS;

    u32 src_ip = ip->saddr;
    if (src_ip == 0)
        return XDP_PASS;

    // Increment per-IP counter
    u64 *val = counters.lookup(&src_ip);
    if (val) {
        lock_xadd(val, 1);
    } else {
        u64 one = 1;
        counters.update(&src_ip, &one);
    }

    // Increment global stats
    u32 idx = 0;
    u64 *s = stats.lookup(&idx);
    if (s) lock_xadd(s, 1);

    return XDP_PASS;
}
