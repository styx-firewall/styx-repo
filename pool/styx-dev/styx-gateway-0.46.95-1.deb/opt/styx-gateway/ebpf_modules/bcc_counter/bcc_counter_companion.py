# bcc_counter_companion.py

import ctypes

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import serialize_ipv4, format_ipv4

# Companion API

_SERIALIZERS = {"counters": serialize_ipv4}
_FORMATTERS = {"counters": format_ipv4}


def serialize_entry(items, map_name, op):
    try:
        handler = _SERIALIZERS[map_name]
    except KeyError:
        raise ValueError(f"Map '{map_name}' does not support push")
    return [handler(item) for item in items]


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# Telemetry deserializer


@register_deserializer("bcc_counter", "stats")
class StatsDeserializer(FeedbackDeserializer):
    def from_map(self, raw, spec, key=None) -> dict:
        val = int(ctypes.c_uint64.from_buffer_copy(bytes(raw)).value)
        return {"packets": val}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("counters is a telemetry map, not an event buffer")
