# ip_drop/ip_drop_companion.py
#
# Companion for ip_drop.  Registers serializers for the blocklist control map
# and a deserializer for the stats telemetry map.

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import serialize_ipv4, format_ipv4, aggregate_percpu

# Control map serializers

_SERIALIZERS = {"blocklist": serialize_ipv4}


def serialize_entry(items, map_name, op):
    try:
        handler = _SERIALIZERS[map_name]
    except KeyError:
        raise ValueError(f"Map '{map_name}' does not support push")
    return [handler(item) for item in items]


# Map entry formatters

_FORMATTERS = {"blocklist": format_ipv4}


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# Telemetry deserializer


@register_deserializer("ip_drop", "stats")
class StatsDeserializer(FeedbackDeserializer):
    """Aggregates per-CPU stats array: dropped counter."""

    def from_map(self, raw, spec, key=None) -> dict:
        totals = aggregate_percpu(raw, ["dropped"], ["<Q"])
        return {"EBPF IP Packets dropped": totals["dropped"]}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")
