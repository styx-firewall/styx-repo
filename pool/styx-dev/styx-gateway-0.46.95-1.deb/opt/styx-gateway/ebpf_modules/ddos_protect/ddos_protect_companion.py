# modules/ddos_protect/ddos_protect_companion.py

import ctypes
import ipaddress

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import serialize_uint32, format_uint32, ktime_to_epoch

# Companion API

_PROTO_LABELS = {1: "ICMP", 6: "TCP", 17: "UDP"}

_SERIALIZERS = {"cfg_map": serialize_uint32}
_FORMATTERS = {"cfg_map": format_uint32}


def serialize_entry(items, map_name, op):
    try:
        handler = _SERIALIZERS[map_name]
    except KeyError:
        raise ValueError(f"Map '{map_name}' does not support push")
    return [handler(item) for item in items]


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# C struct mirrors


class StatsT(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("drops", ctypes.c_uint64),
        ("last_drop_ns", ctypes.c_uint64),
    ]


class DropEventT(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("ts_ns", ctypes.c_uint64),
        ("src_ip", ctypes.c_uint32),
        ("packet_count", ctypes.c_uint32),
        ("proto", ctypes.c_uint8),
    ]


# Telemetry / Event deserializers


@register_deserializer("ddos_protect", "stats")
class StatsDeserializer(FeedbackDeserializer):
    def from_map(self, raw, spec, key=None) -> dict:
        s = StatsT.from_buffer_copy(bytes(raw))
        return {"drops": s.drops, "last_drop": ktime_to_epoch(s.last_drop_ns)}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")


@register_deserializer("ddos_protect", "drop_events")
class DropEventDeserializer(FeedbackDeserializer):
    def from_map(self, raw, spec, key=None) -> dict:
        raise NotImplementedError("drop_events is an event buffer, not a telemetry map")

    def from_event(self, data: bytes, size: int, spec) -> dict:
        e = DropEventT.from_buffer_copy(data[:size])
        return {
            "ts_ns": e.ts_ns,
            "src_ip": str(ipaddress.IPv4Address(e.src_ip)),
            "packet_count": e.packet_count,
            "proto": _PROTO_LABELS.get(e.proto, str(e.proto)),
        }
