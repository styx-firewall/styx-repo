// SPDX-License-Identifier: GPL-2.0
// ddos_protect.c - per-IP, per-protocol rate limiting via XDP
//
// Drops packets when a source IP exceeds the per-protocol threshold
// within a configurable time window.  Designed to stack with net_block
// (static blocking) on the same interface via libxdp dispatcher.

#ifndef BCC_COMPILE
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_endian.h>
#include <xdp/xdp_helpers.h>

#ifndef ETH_P_IP
#define ETH_P_IP 0x0800
#endif
#endif

#define DEFAULT_TCP_THRESHOLD   5000
#define DEFAULT_UDP_THRESHOLD   20000
#define DEFAULT_ICMP_THRESHOLD  100
#define DEFAULT_WINDOW_NS       5000000000ULL  // 5 seconds
#define DEFAULT_COOLDOWN_NS     10000000000ULL // 10 seconds between events per IP+proto

// Structs

struct rate_key {
    __u32 src_ip;
    __u8  proto;   // 6=TCP, 17=UDP, 1=ICMP
} __attribute__((packed));

struct rate_entry {
    __u64 last_update;
    __u64 last_event_ns;   // cooldown — suppress duplicate events
    __u32 packet_count;
} __attribute__((packed));

struct drop_event_t {
    __u64 ts_ns;
    __u32 src_ip;
    __u32 packet_count;
    __u8  proto;
} __attribute__((packed));

struct stats_t {
    __u64 drops;
    __u64 last_drop_ns;
} __attribute__((packed));

// Maps

// Runtime config (adjustable without reload via control-push)
// Key 0: tcp_threshold, 1: udp_threshold, 2: icmp_threshold, 3: window_ns
struct {
    __uint(type,        BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 8);
    __type(key,         __u32);
    __type(value,       __u32);
} cfg_map SEC(".maps");

// Internal rate-limit tracker (per IP + protocol)
struct {
    __uint(type,        BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, 65536);
    __type(key,         struct rate_key);
    __type(value,       struct rate_entry);
} rate_map SEC(".maps");

// Telemetry
struct {
    __uint(type,        BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key,         __u32);
    __type(value,       struct stats_t);
} stats SEC(".maps");

// Events
struct {
    __uint(type,        BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);
} drop_events SEC(".maps");

// Helpers

static __always_inline __u32 read_config(__u32 key, __u32 default_val) {
    __u32 *val = bpf_map_lookup_elem(&cfg_map, &key);
    return val ? *val : default_val;
}

static __always_inline __u32 get_threshold(__u8 proto) {
    switch (proto) {
    case 6:   // TCP
        return read_config(0, DEFAULT_TCP_THRESHOLD);
    case 17:  // UDP
        return read_config(1, DEFAULT_UDP_THRESHOLD);
    case 1:   // ICMP
        return read_config(2, DEFAULT_ICMP_THRESHOLD);
    default:
        return read_config(0, DEFAULT_TCP_THRESHOLD);  // fallback to TCP
    }
}

static __always_inline void record_drop(__u64 now) {
    __u32 idx = 0;
    struct stats_t *s = bpf_map_lookup_elem(&stats, &idx);
    if (!s) return;
    __sync_fetch_and_add(&s->drops, 1);
    s->last_drop_ns = now;
}

// Program

// XDP dispatcher metadata: active filter — run early, chain on both PASS and DROP
// so monitoring programs later in the chain still see interface activity.
// Runtime priority is set from [[pre_attach_param]] (default 30).
struct {
    __uint(priority, 30);
    __uint(XDP_PASS, 1);
    __uint(XDP_DROP, 1);
} XDP_RUN_CONFIG(ddos_protect);

SEC("xdp")
int ddos_protect(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;
    void *data     = (void *)(long)ctx->data;

    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end)
        return XDP_PASS;

    if (eth->h_proto != __builtin_bswap16(ETH_P_IP))
        return XDP_PASS;

    struct iphdr *iph = (void *)(eth + 1);
    if ((void *)(iph + 1) > data_end)
        return XDP_PASS;

    __u32 src_ip = iph->saddr;
    __u8  proto  = iph->protocol;
    __u64 now    = bpf_ktime_get_ns();

    __u32 threshold = get_threshold(proto);
    __u64 window_ns = (__u64)read_config(3, (__u32)(DEFAULT_WINDOW_NS & 0xFFFFFFFF));

    struct rate_key key = {.src_ip = src_ip, .proto = proto};
    struct rate_entry *entry = bpf_map_lookup_elem(&rate_map, &key);

    if (entry) {
        if (now - entry->last_update < window_ns) {
            entry->packet_count++;
            if (entry->packet_count > threshold) {
                record_drop(now);

                // Cooldown: at most one event per IP+proto per cooldown_ns
                __u64 cooldown_ns = (__u64)read_config(4, (__u32)(DEFAULT_COOLDOWN_NS & 0xFFFFFFFF));
                if (now - entry->last_event_ns >= cooldown_ns) {
                    entry->last_event_ns = now;
                    struct drop_event_t *ev = bpf_ringbuf_reserve(&drop_events, sizeof(struct drop_event_t), 0);
                    if (ev) {
                        ev->ts_ns        = now;
                        ev->src_ip       = src_ip;
                        ev->packet_count = entry->packet_count;
                        ev->proto        = proto;
                        bpf_ringbuf_submit(ev, 0);
                    }
                }
                return XDP_DROP;
            }
        } else {
            // Window expired — reset counter
            entry->last_update  = now;
            entry->packet_count = 1;
        }
    } else {
        struct rate_entry new_entry = {.last_update = now, .packet_count = 1};
        bpf_map_update_elem(&rate_map, &key, &new_entry, BPF_ANY);
    }

    return XDP_PASS;
}

char _license[] SEC("license") = "GPL";
