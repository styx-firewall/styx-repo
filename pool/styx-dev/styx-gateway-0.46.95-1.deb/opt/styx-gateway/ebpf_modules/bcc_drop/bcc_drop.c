// bcc_drop.c — BCC XDP packet dropper
//
// Uses BCC map syntax (BPF_HASH).  Loaded by BccBackend in DEV mode
// (ebpf_test feature).  Not compatible with CO-RE/libbpf.

#include <uapi/linux/bpf.h>
#include <uapi/linux/if_ether.h>
#include <uapi/linux/ip.h>

// Blocklist: IP -> 1 (drop) or 0 (pass)
BPF_HASH(blocklist, u32, u8, 1024);

// Stats
BPF_PERCPU_ARRAY(stats, u64, 2);  // [0] = passed, [1] = dropped

int xdp_drop_ip(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;
    void *data = (void *)(long)ctx->data;

    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end)
        return XDP_PASS;

    if (eth->h_proto != __constant_htons(ETH_P_IP))
        return XDP_PASS;

    struct iphdr *ip = data + sizeof(*eth);
    if ((void *)(ip + 1) > data_end)
        return XDP_PASS;

    u32 src_ip = ip->saddr;
    u8 *action = blocklist.lookup(&src_ip);

    u32 idx;
    u64 *s;

    if (action && *action) {
        idx = 1;
        s = stats.lookup(&idx);
        if (s) lock_xadd(s, 1);
        return XDP_DROP;
    }

    idx = 0;
    s = stats.lookup(&idx);
    if (s) lock_xadd(s, 1);
    return XDP_PASS;
}
