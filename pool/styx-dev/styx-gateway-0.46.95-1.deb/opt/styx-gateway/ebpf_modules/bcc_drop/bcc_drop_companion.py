# bcc_drop_companion.py

import ctypes

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import serialize_ipv4, format_ipv4, bytes_to_int

# Companion API

_SERIALIZERS = {"blocklist": serialize_ipv4}
_FORMATTERS = {"blocklist": format_ipv4}


def serialize_entry(items, map_name, op):
    try:
        handler = _SERIALIZERS[map_name]
    except KeyError:
        raise ValueError(f"Map '{map_name}' does not support push")
    return [handler(item) for item in items]


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# Stats deserializer


def _u32_key(key) -> int:
    if isinstance(key, int):
        return key
    if isinstance(key, bytes):
        return bytes_to_int(key[:4].ljust(4, b"\x00"))
    return 0


@register_deserializer("bcc_drop", "stats")
class StatsDeserializer(FeedbackDeserializer):
    def from_map(self, raw, spec, key=None) -> dict:
        idx = _u32_key(key)
        label = "passed" if idx == 0 else "dropped"
        val = int(ctypes.c_uint64.from_buffer_copy(bytes(raw)).value)
        return {f"{label}_count": val}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")
