"""
Migration script: -> 0.49.9

Replaces the placeholder `kern.warning -/var/log/kern.log` rule in
/etc/rsyslog.conf with a null action to /dev/null.

rsyslog refuses to start with zero actions ("there are no active actions
configured", error -2103), so a base config that only loads inputs needs at
least one action. The kern.warning rule filled that role but had a side effect:
it wrote /var/log/kern.log. The null action keeps rsyslog startable without
producing any file, and does not stop processing, so forwarding drop-ins
included later still receive every message.

The edit is targeted (one line), idempotent, and leaves the rest of the file
(such as the imjournal Ratelimit.Interval setting) untouched.
"""

import os
import re
import shutil
import time

from core.app_context import AppContext
from services.system_services import SystemServices

TAG = "[MIGRATE 0.49.9]"

CONF_PATH = "/etc/rsyslog.conf"
NULL_ACTION = '*.* action(type="omfile" file="/dev/null")'
_OLD_RULE = re.compile(r"^kern\.warning\s+-/var/log/kern\.log\s*$", re.MULTILINE)


def run(ctx: AppContext) -> bool:
    """Swap the kern.warning placeholder for a /dev/null action and reload rsyslog."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    if not os.path.isfile(CONF_PATH):
        logger.info(f"{TAG} {CONF_PATH} not present, nothing to do.")
        return True

    try:
        with open(CONF_PATH, "r", encoding="utf-8") as handle:
            content = handle.read()
    except OSError as exc:
        logger.error(f"{TAG} Cannot read {CONF_PATH}: {exc}")
        return False

    if NULL_ACTION in content:
        logger.info(f"{TAG} Null action already present, nothing to do.")
        return True

    new_content, replacements = _OLD_RULE.subn(NULL_ACTION, content)
    if replacements == 0:
        logger.warning(f"{TAG} expected kern.warning rule not found in {CONF_PATH}; leaving it untouched.")
        return True

    backup = f"{CONF_PATH}.bak-{time.strftime('%Y%m%d%H%M%S')}"
    try:
        shutil.copy2(CONF_PATH, backup)
        logger.notice(f"{TAG} Backed up {CONF_PATH} -> {backup}")
    except OSError as exc:
        logger.warning(f"{TAG} Could not back up {CONF_PATH}: {exc}")

    try:
        tmp_path = f"{CONF_PATH}.tmp"
        with open(tmp_path, "w", encoding="utf-8") as handle:
            handle.write(new_content)
        os.chmod(tmp_path, 0o644)
        os.replace(tmp_path, CONF_PATH)
    except OSError as exc:
        logger.error(f"{TAG} Failed to update {CONF_PATH}: {exc}")
        return False

    logger.notice(f"{TAG} Replaced kern.warning rule with a /dev/null action in {CONF_PATH}.")

    result = SystemServices.reload_or_restart(ctx, "rsyslog", non_blocking=True)
    if result.ok:
        logger.notice(f"{TAG} rsyslog reload/restart requested.")
    else:
        logger.warning(f"{TAG} rsyslog reload/restart failed: {result.msg}")

    logger.notice(f"{TAG} Migration completed successfully.")
    return True
