<?php
# DP 20260211
# TESTED: 0

namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class RoutesFormatter
{
    public static function format(array $fmt_data, array $response, array $userCaps = []): array
    {
        # Action capabilities for the routes tables (disable/enable = write,
        # delete = delete). Mirrors the capability gating used across routing pages.
        $fmt_data['can_write']  = RoleHelper::hasCapability($userCaps, 'routing:write');
        $fmt_data['can_delete'] = RoleHelper::hasCapability($userCaps, 'routing:delete');

        # Sorting function: first by metric (numeric), then by destination, then by interface
        $cmp = function($a, $b) {
            $ma = is_numeric($a['metric'] ?? null) ? (int)$a['metric'] : 0;
            $mb = is_numeric($b['metric'] ?? null) ? (int)$b['metric'] : 0;
            if ($ma === $mb) {
                $d = strcmp($a['dst'] ?? $a['destination'] ?? '', $b['dst'] ?? $b['destination'] ?? '');
                return $d === 0 ? strcmp($a['iface'] ?? '', $b['iface'] ?? '') : $d;
            }
            return $ma <=> $mb;
        };

        $fmt_data['routes_ipv4'] = $response['routes_ipv4'] ?? [];
        $fmt_data['routes_ipv6'] = $response['routes_ipv6'] ?? [];

        // Build id -> iface-name map (ifaces_names is [{interface, id}, ...])
        $ifaceById = [];
        foreach ($response['ifaces_names'] ?? [] as $iface) {
            if (!empty($iface['id'])) {
                $ifaceById[$iface['id']] = $iface['interface'];
            }
        }

        if (is_array($fmt_data['routes_ipv4'])) {
            usort($fmt_data['routes_ipv4'], $cmp);
            $fmt_data['routes_ipv4'] = array_map(fn($r) => self::formatRoute($r, $ifaceById), $fmt_data['routes_ipv4']);
        }
        if (is_array($fmt_data['routes_ipv6'])) {
            usort($fmt_data['routes_ipv6'], $cmp);
            $fmt_data['routes_ipv6'] = array_map(fn($r) => self::formatRoute($r, $ifaceById), $fmt_data['routes_ipv6']);
        }

        $keys = ['ifaces_names', 'routing_tables', 'routing_protocols', 'routing_scopes', 'routing_types'];
        foreach ($keys as $k) {
            $fmt_data[$k] = $response[$k] ?? [];
        }

        return $fmt_data;
    }

    private static function formatRoute(array $route, array $ifaceById): array
    {
        $out = $route;

        $dstRaw = $route['dst'] ?? '';
        $out['dst_display'] = $route['dst_value'] ?? $dstRaw;
        $out['dst_tooltip']  = '';

        $gwRaw = $route['gateway'] ?? '';
        $out['gateway']         = $route['gateway_value'] ?? $gwRaw;
        $out['gateway_tooltip'] = '';

        // device: prefer dev_name, then iface id lookup, then raw
        $devRaw = $route['dev'] ?? '';
        $out['dev'] = $route['dev_name'] ?? $ifaceById[$devRaw] ?? $devRaw;

        // warning as string
        if (!empty($route['warning'])) {
            $out['warning_text'] = is_array($route['warning']) ? ($route['warning']['msg'] ?? '') : (string)$route['warning'];
        } else {
            $out['warning_text'] = '';
        }

        // nexthops as simple display strings
        $out['nexthops_list'] = [];
        foreach ($route['nexthops'] ?? [] as $nh) {
            $parts = [];
            $nhGw = $nh['gateway'] ?? '';
            if (!empty($nh['gateway_value'])) {
                $parts[] = 'nexthop via ' . $nh['gateway_value'];
            } elseif (!empty($nhGw)) {
                $parts[] = 'nexthop via ' . $nhGw;
            }
            $nhDevRaw = $nh['dev'] ?? '';
            $nhDev = $nh['dev_name'] ?? $ifaceById[$nhDevRaw] ?? $nhDevRaw;
            if ($nhDev !== '') {
                $parts[] = 'dev ' . $nhDev;
            }
            if (isset($nh['weight'])) {
                $parts[] = 'weight ' . $nh['weight'];
            }
            $out['nexthops_list'][] = implode(' ', $parts);
        }

        // flags
        $out['flags_text'] = !empty($route['flags']) && is_array($route['flags']) ? implode(', ', $route['flags']) : '';

        // MTU from metrics
        $out['mtu'] = 1500;
        foreach ($route['metrics'] ?? [] as $m) {
            if (isset($m['mtu']) && (int)$m['mtu'] > 0) {
                $out['mtu'] = (int)$m['mtu'];
                break;
            }
        }

        $out['has_id'] = !empty($route['id']);
        // Missing 'enabled' means enabled (backwards compatibility); only an
        // explicit false marks a route as disabled (routing-service.disable_route).
        $out['is_enabled'] = !array_key_exists('enabled', $route) || $route['enabled'] !== false;
        $out['metric'] = is_numeric($route['metric'] ?? null) ? (int)$route['metric'] : 0;

        // prefsrc: raw value as-is (no address ID lookup available)
        $prefsrcRaw = $route['prefsrc'] ?? '';
        if ($prefsrcRaw !== '') {
            $out['prefsrc'] = $prefsrcRaw;
        }

        return $out;
    }
}
