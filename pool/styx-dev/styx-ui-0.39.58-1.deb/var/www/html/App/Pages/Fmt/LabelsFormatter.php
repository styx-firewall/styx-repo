<?php
namespace App\Pages\Fmt;

class LabelsFormatter
{
    /**
     * Human-friendly display names for label types. UI-only: the authoritative
     * list of valid types comes from the backend (sets-mgmt.get_allowed_labels);
     * an unknown type falls back to its raw key.
     */
    private const TYPE_DISPLAY = [
        'vlans' => 'VLANs',
        'packet_marking' => 'Packet Marking',
        'routing_tables' => 'Routing Tables',
        'route_tag' => 'Route Tag',
        'community' => 'Community',
        'as_path_regex' => 'AS Path Regex',
        'as_path_prepend' => 'AS Path Prepend',
        'as_number' => 'AS Number',
        'router_id' => 'Router ID',
        'cluster_id' => 'Cluster ID',
        'ospf_area' => 'OSPF Area',
        'vni' => 'VNI',
        'gre_ikey' => 'GRE IKey',
        'gre_okey' => 'GRE OKey',
        'xfrm_if_id' => 'XFRM Interface ID',
    ];

    /**
     * Prepare a labels-specific view of formatted sets.
     *
     * @param array $fmt_data
     * @return array
     */
    public static function format(array $fmt_data): array
    {
        $labels = $fmt_data['labels'] ?? [];
        // Support backend shapes where labels are nested under ['labels']['labels']
        if (isset($labels['labels']) && is_array($labels['labels'])) {
            $labels = $labels['labels'];
        }

        $labels_list = [];
        if (is_array($labels)) {
            foreach ($labels as $l) {
                $labels_list[] = [
                    'id' => $l['id'] ?? null,
                    'type' => $l['type'] ?? '',
                    'name' => $l['name'] ?? ($l['label'] ?? ''),
                    'value' => $l['value'] ?? '',
                    'scope' => $l['scope'] ?? '',
                    'comment' => $l['comment'] ?? ($l['desc'] ?? ''),
                    'refs_count' => (isset($l['refs']) && is_array($l['refs'])) ? count($l['refs']) : 0,
                ];
            }
        }

        // Target-type dropdown options, built from the backend's authoritative
        // label_types list. 'all' stays first as the default filter option.
        $label_types = $fmt_data['label_types'] ?? [];
        $labels_target_opts = ['all' => 'All (disabled)'];
        if (is_array($label_types)) {
            foreach ($label_types as $t) {
                if (is_string($t)) {
                    $labels_target_opts[$t] = self::TYPE_DISPLAY[$t] ?? $t;
                }
            }
        }

        $fmt_data['labels_list'] = $labels_list;
        $fmt_data['labels_target_opts'] = $labels_target_opts;

        return $fmt_data;
    }
    }
