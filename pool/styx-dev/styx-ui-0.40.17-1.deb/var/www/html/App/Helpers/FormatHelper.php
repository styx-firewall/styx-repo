<?php

/**
 * FormatHelper
 *
 * Utility methods for formatting values for display in templates.
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */

namespace App\Helpers;

use App\Services\Filter;

class FormatHelper
{
    /**
     * Format bytes to human-readable string.
     *
     * @param int $bytes
     * @return string
     */
    public static function formatBytes(int $bytes): string
    {
        if ($bytes === 0) {
            return '0 B';
        }
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = floor(log($bytes, 1024));
        $i = min((int)$i, count($units) - 1);
        $val = $bytes / pow(1024, $i);
        return number_format($val, $i > 0 ? 1 : 0) . ' ' . $units[$i];
    }

    /**
     * Render a firewall verdict (accept/drop/reject) as a semantic status badge.
     *
     * Reuses the `.std-badge` chips from default-badge.css with the same
     * accept=success / drop=danger / reject=warning mapping used by the
     * firewall log rows (fw-logs-firewall.js). Returns a `<span>` fragment for
     * known verdicts (the rules tables render it as HTML via `cellHtml`);
     * unknown values are returned unchanged so they render as plain text.
     *
     * @param mixed $action
     * @return string
     */
    public static function verdictBadge(mixed $action): string
    {
        $raw = is_scalar($action) ? (string)$action : '';
        $key = strtolower(trim($raw));
        return match ($key) {
            'accept' => '<span class="std-badge std-badge--success">ACCEPT</span>',
            'drop'   => '<span class="std-badge std-badge--danger">DROP</span>',
            'reject' => '<span class="std-badge std-badge--warning">REJECT</span>',
            default  => $raw,
        };
    }

    /**
     * Render a firewall match protocol as a chip ("TCP", "UDP", ...).
     *
     * Reuses the `.std-badge--proto` chip from default-badge.css (same style
     * the route-rules and packet-marking tables use). An unset or "any"
     * protocol renders as an "ANY" chip so every row shows the same design.
     * Returns a `<span>` fragment; the firewall rules tables render it as HTML
     * via `cellHtml`.
     *
     * @param mixed $protocol
     * @return string
     */
    public static function protocolBadge(mixed $protocol): string
    {
        $raw = is_scalar($protocol) ? strtolower(trim((string)$protocol)) : '';
        if ($raw === '' || $raw === 'any') {
            return '<span class="std-badge std-badge--proto">ANY</span>';
        }
        $labels = [
            'tcp'    => 'TCP',
            'udp'    => 'UDP',
            'icmp'   => 'ICMP',
            'icmpv6' => 'ICMPv6',
            'esp'    => 'ESP',
            'ah'     => 'AH',
        ];
        $label = $labels[$raw] ?? strtoupper($raw);
        return '<span class="std-badge std-badge--proto">'
            . Filter::escHtml($label) . '</span>';
    }

    /**
     * Render a list of resolved set display objects (IPs, ports, interfaces)
     * as a stackable set cell for the firewall rules tables.
     *
     * The gateway resolves each matched set to `{id, name, type, values}`; the
     * table keeps the compact set *name* visible and carries the actual matched
     * values in the `title` tooltip, so real data is one hover away without
     * widening the row. Each set is one line (`<br>`-joined).
     *
     * @param mixed $sets  resolved set display objects, or empty
     * @return string
     */
    public static function setListHtml(mixed $sets): string
    {
        if (!is_array($sets) || $sets === []) {
            return '';
        }
        $lines = [];
        foreach ($sets as $set) {
            if (!is_array($set)) {
                $lines[] = Filter::escHtml((string)$set);
                continue;
            }
            $name = (string)($set['name'] ?? '');
            $values = $set['values'] ?? [];
            $valueText = is_array($values)
                ? implode(', ', array_map('strval', $values))
                : (string)$values;
            if ($name === '' && $valueText === '') {
                continue;
            }
            // Fall back to the values as the visible label if a name is absent.
            $label = $name !== '' ? $name : $valueText;
            $safeLabel = Filter::escHtml($label);
            if ($valueText === '') {
                $lines[] = $safeLabel;
                continue;
            }
            $safeValue = Filter::escHtml($valueText);
            $lines[] = '<span title="' . $safeValue . '">' . $safeLabel . '</span>';
        }
        return implode('<br>', $lines);
    }
}
