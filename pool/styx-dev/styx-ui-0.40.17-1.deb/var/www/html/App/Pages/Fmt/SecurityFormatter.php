<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages\Fmt;

class SecurityFormatter
{
    /**
     * Prepare security page data for template consumption.
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(string $section, array $fmt_data = []): array
    {
        // Preserve original data: for sec-audit this may be a checks list
        $orig_pageData = $fmt_data;

        if ($section === 'sec-overview' || $section === 'sec-audit') {
            $out = [];
            $audit = $fmt_data['audit_summary'] ?? [];
            // normalize numeric values and compute helpful percents
            $total_checks = isset($audit['total_checks']) ? (int)$audit['total_checks'] : 0;
            $passed = isset($audit['passed']) ? (int)$audit['passed'] : 0;
            $failed = isset($audit['failed']) ? (int)$audit['failed'] : 0;
            $max_score = isset($audit['max_score']) ? (int)$audit['max_score'] : 0;
            $achieved_score = isset($audit['achieved_score']) ? (int)$audit['achieved_score'] : 0;
            $coverage_pct = isset($audit['coverage_pct']) ? (float)$audit['coverage_pct'] : 0.0;
            $coverage_pct = max(0.0, min(100.0, $coverage_pct));
            $coverage_by_tag = $audit['coverage_by_tag'] ?? [];
            $rating = $audit['rating'] ?? '';

            $pass_pct = $total_checks > 0 ? round($passed * 100.0 / $total_checks, 1) : 0.0;
            $fail_pct = $total_checks > 0 ? round($failed * 100.0 / $total_checks, 1) : 0.0;
            $score_pct = $max_score > 0 ? round($achieved_score * 100.0 / $max_score, 1) : 0.0;

            // Coverage per benchmark → normalized rows (grade colour lives in CSS).
            $coverage_rows = [];
            foreach ($coverage_by_tag as $tag => $pct) {
                $pct = max(0.0, min(100.0, (float)$pct));
                $coverage_rows[] = [
                    'tag' => (string)$tag,
                    'pct' => round($pct, 1),
                    'grade' => self::coverageGrade($pct),
                ];
            }

            $out = [
                'audit' => [
                    'total_checks' => $total_checks,
                    'passed' => $passed,
                    'failed' => $failed,
                    'pass_pct' => $pass_pct,
                    'fail_pct' => $fail_pct,
                    'max_score' => $max_score,
                    'achieved_score' => $achieved_score,
                    'score_pct' => $score_pct,
                    'coverage_pct' => $coverage_pct,
                    'coverage_grade' => self::coverageGrade($coverage_pct),
                    'coverage_by_tag' => $coverage_rows,
                    'rating' => $rating,
                    'msg' => $fmt_data['msg'] ?? '',
                ]
            ];

            // preserve original raw data for debugging or extended views
            $fmt_data = $out;
        }
        if ($section === 'sec-audit') {
            // If original data is an indexed list, it's a checks array
            if (array_is_list($orig_pageData) && !empty($orig_pageData)) {
                $checks_formatted = self::formatAuditChecks($orig_pageData);
                $fmt_data = array_merge($fmt_data, $checks_formatted);
            }
        }
        if ($section === 'sec-auditd') {
        }

        return $fmt_data;
    }

    /**
     * Map a coverage/score percentage (0–100) to its grade tier.
     * The colour for each tier lives in CSS (default-security.css,
     * .grade-* classes applied to both the bars and the donut ring).
     */
    private static function coverageGrade(float $pct): string
    {
        if ($pct < 50) return 'poor';
        if ($pct < 75) return 'fair';
        if ($pct < 90) return 'good';
        return 'excellent';
    }

    /**
     * Format a list of audit check items into template-friendly structure.
     *
     * @param array<int, array<string,mixed>> $checks
     * @return array<string,mixed>
     */
    /** Map an audit check status to a std-badge chip (+dot lamp). */
    private static function auditBadgeClass(string $status): string
    {
        return match (strtoupper(trim($status))) {
            'PASS' => 'std-badge--success std-badge--dot',
            'FAIL' => 'std-badge--danger std-badge--dot',
            default => 'std-badge--muted std-badge--dot',
        };
    }

    private static function formatAuditChecks(array $checks): array
    {
        $passed_count = 0;
        $failed_count = 0;
        $all_tags = [];

        // Sort by penalty ascending (most negative first)
        usort($checks, fn($a, $b) => ($a['penalty'] ?? 0) <=> ($b['penalty'] ?? 0));

        $groups = [
            'critical' => ['label' => 'Critical', 'rows' => []],
            'high' => ['label' => 'High', 'rows' => []],
            'medium' => ['label' => 'Medium', 'rows' => []],
            'low' => ['label' => 'Low', 'rows' => []],
        ];

        foreach ($checks as $check) {
            $status = $check['status'] ?? 'UNKNOWN';
            $status === 'PASS' ? $passed_count++ : $failed_count++;

            $severity = $check['severity'] ?? 'low';
            $tags = $check['tags'] ?? [];
            $all_tags = array_merge($all_tags, $tags);

            $row = [
                'rule' => $check['rule'] ?? '',
                'title' => $check['title'] ?? '',
                'status' => $status,
                'status_class' => strtolower($status),
                'badge_class'  => self::auditBadgeClass($status),
                'severity' => $severity,
                'severity_label' => ucfirst($severity),
                'penalty' => isset($check['penalty']) ? (int)$check['penalty'] : 0,
                'detail' => $check['detail'] ?? '',
                'tags' => $tags,
                'data_tags' => json_encode($tags),
            ];

            if (isset($groups[$severity])) {
                $groups[$severity]['rows'][] = $row;
            }
        }

        // Remove empty groups
        $groups = array_filter($groups, fn($g) => !empty($g['rows']));

        // Unique tags sorted alphabetically
        $all_tags = array_unique($all_tags);
        sort($all_tags);

        return [
            'sec_audit_groups' => $groups,
            'all_tags' => $all_tags,
            'totals' => [
                'total' => count($checks),
                'passed' => $passed_count,
                'failed' => $failed_count,
            ],
        ];
    }
}
