<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Controllers\Request\NetworkRequestController;
use App\Controllers\Request\SLARequestController;
use App\Controllers\Request\IperfRequestController;
use App\Controllers\Request\TrafficStatsRequestController;
use App\Controllers\Request\DiscoveryRequestController;
use App\Controllers\Request\EthtoolRequestController;
use App\Services\Filter;
use App\Services\AuthService;
use App\Helpers\RoleHelper;
use App\Pages\Fmt\NetIfaceFormatter;
use App\Pages\Fmt\NetIfaceEthtoolFormatter;
use App\Pages\Fmt\NetPerfFormatter;
use App\Pages\Fmt\NetTunningFormatter;
use App\Pages\Fmt\NetSlaFormatter;
use App\Pages\Fmt\NetInterfacesFormatter;
use App\Pages\Fmt\NetTrafficStatsFormatter;
use App\Pages\Fmt\NetDiscoveryFormatter;


class PageNetwork
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'net-iface-mgmt',
            'net-perf',
            'net-tunning',
            'net-sla',
            'net-interfaces',
            'net-traffic-stats',
            'net-discovery',
        ];
        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'net-interfaces';
        }

        if ($section === 'net-perf' || $section === 'net-sla' || $section === 'net-traffic-stats') {
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/thirdparty/chart.js'];
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/charts-core/reusable-charts.js'];
        }

        if ($section === 'net-perf') {
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/network/net-perf.js'];
        } elseif ($section === 'net-tunning') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/network/net-tunning.js'];
        } elseif ($section === 'net-iface-mgmt') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/network/net-iface-mgmt.js'];
        } else if ($section === 'net-interfaces') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/network/net-interfaces.js'];
        } elseif ($section === 'net-sla') {            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];            $page['web_main']['footer_script'][] = ['src' => '/scripts/network/net-sla.js'];
        } elseif ($section === 'net-traffic-stats') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/network/net-traffic-stats.js'];
        } elseif ($section === 'net-discovery') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/network/net-discovery.js'];
        }


        $fmt_data = [];

        // Allow dot and hyphen so UUID-style ids (xxxxxxxx-xxxx-...) are accepted
        $iface_id = Filter::getCustomString('modify', '.-');

        if (!empty($section) && $section === 'net-tunning') {
            $networkController = new NetworkRequestController($ctx);
            $response  = $networkController->getSysctlKeys();
            if (is_array($response) && ($response['status'] ?? '') === 'success') {
                $fmt_data = NetTunningFormatter::format($fmt_data, $response['result']);
            }
        } elseif (!empty($section) && $section === 'net-interfaces') {
            $networkController = new NetworkRequestController($ctx);
            $response = $networkController->getInterfaces();
            if (is_array($response)) {
                $fmt_data = NetInterfacesFormatter::format($fmt_data, $response);
                // Inject physical and virtual table fragments.
                // Fragments receive their data via tpl_data, not page_data.
                $page['load_tpl'][] = [
                    'file' => 'net-interfaces-physical',
                    'place' => 'physical_table',
                    'weight' => 5,
                    'tpl_data' => [
                        'physical_interfaces' => $fmt_data['physical_interfaces'] ?? [],
                    ],
                ];
                $page['load_tpl'][] = [
                    'file' => 'net-interfaces-virtual',
                    'place' => 'virtual_table',
                    'weight' => 6,
                    'tpl_data' => [
                        'virtual_interfaces' => $fmt_data['virtual_interfaces'] ?? [],
                    ],
                ];
            }
        } elseif (!empty($section) && $section === 'net-sla') {
            $slaController = new SLARequestController($ctx);
            $response = $slaController->getSLAPageData();
            if (is_array($response)) {
                $fmt_data = NetSlaFormatter::format($fmt_data, $response);
            }
        } else if (!empty($section) && $section === 'net-iface-mgmt') {
            // Shared editor stylesheet (responsive two-column layout + ethtool panel)
            $page['web_main']['cssfile'][] = 'default-ethtool';
            // Create via explicit params: ?create=1&type=virtual&subtype=$subtype
            $create_flag = Filter::getInt('create');
            $iface_type = Filter::getString('type');
            $iface_subtype = Filter::getString('subtype');
            // Subtypes created without a parent interface: the create form has no
            // parent selector, so there is no need to query valid parents.
            $no_parent_types = ['dummy'];
            // Only create when an explicit subtype is provided  -  no fallbacks.
            if (!empty($create_flag) && !empty($iface_subtype)) {
                $networkController = new NetworkRequestController($ctx);
                if (in_array($iface_subtype, $no_parent_types, true)) {
                    // Loopback (dummy): no parents required, just fetch the role list.
                    $rolesResp = $networkController->getValidRoles();
                    $fmt_data = [
                        'action' => 'create',
                        // Broad type is 'virtual' for subtype-based creates
                        'iface_type' => 'virtual',
                        'iface_subtype' => $iface_subtype,
                        'iface_roles' => ($rolesResp['status'] ?? '') === 'success'
                            ? ($rolesResp['result']['roles'] ?? [])
                            : [],
                    ];
                } else {
                    // Creating a new interface  -  require gateway-provided valid parents
                    $parentsResp = $networkController->getValidParents($iface_subtype);
                    if (!is_array($parentsResp) || ($parentsResp['status'] ?? '') !== 'success') {
                        $fmt_data = [
                            'action' => 'create',
                            // Broad type is 'virtual' for subtype-based creates
                            'iface_type' => 'virtual',
                            'iface_subtype' => $iface_subtype,
                            'error_msg' => $parentsResp['response_msg'] ?? 'Error getting valid parents'
                        ];
                    } else {
                        $fmt_data = [
                            'action' => 'create',
                            'interfaces' => $parentsResp['result']['interfaces'] ?? [],
                            'iface_type' => 'virtual',
                            'iface_subtype' => $iface_subtype,
                            'iface_roles' => $parentsResp['result']['roles'] ?? [],
                        ];
                    }
                }
            }

            if (isset($_GET['modify'])) {
                // Modifying an existing interface  -  iface_id is mandatory.
                $networkController = new NetworkRequestController($ctx);
                $iface_info = $networkController->getInterfaceConfig($iface_id, $iface_subtype ?? '');

                // If gateway returned an error (for example missing iface_id), expose it to the template
                if (!is_array($iface_info) || (($iface_info['status'] ?? null) === 'error')) {
                    $fmt_data = $fmt_data ?? [];
                    $fmt_data['error_msg'] = $iface_info['response_msg'] ?? 'Interface id (iface_id) is required for modify';
                    $fmt_data['action'] = 'modify';
                } else {
                    $iface_result = $iface_info['result'];
                    // Determine interface type and fetch appropriate interface list
                    $iface_config = $iface_result['interface_config'] ?? [];
                    // Allow optional override via GET: ?type=...&subtype=...
                    if (!empty($iface_type)) {
                        if ($iface_type === 'virtual' && !empty($iface_subtype)) {
                            $detected_type = $iface_subtype;
                        } else {
                            $detected_type = $iface_type;
                        }
                    } else {
                        // If interface type is virtual, prefer the explicit subtype (vlan, veth, macvlan, etc.)
                        if (($iface_config['type'] ?? '') === 'virtual' && !empty($iface_config['subtype'])) {
                            $detected_type = $iface_config['subtype'];
                        } else {
                            $detected_type = $iface_config['type'] ?? '';
                        }
                    }

                    // For virtual types that require a parent, gateway now returns valid parents
                    // as part of `getInterfaceConfig` result. Use that list instead of making
                    // an extra request to `getValidParents`.
                    $types_requiring_parents = ['vlan', 'bridge', 'bond', 'macvlan', 'veth', 'pppoe', 'xfrm'];
                    if (in_array($detected_type, $types_requiring_parents, true)) {
                        // Controller now normalizes `parents` -> `interfaces`, so prefer
                        // `interfaces` for a single consistent shape.
                        $ifaces_list = $iface_result['interfaces'] ?? [];
                    } else {
                        // Physical or other types: no parent list required.
                        $ifaces_list = [];
                    }
                    // Extract SSH and Styx UI interface lists (if provided by gateway)
                    $ssh_list = [];
                    $styx_ui_list = [];
                    if (!empty($iface_result['ssh_config']) && is_array($iface_result['ssh_config'])) {
                        $ssh_list = $iface_result['ssh_config']['listen'] ?? $iface_result['ssh_config']['interfaces'] ?? [];
                    }
                    if (!empty($iface_result['lighttpd_config']) && is_array($iface_result['lighttpd_config'])) {
                        $styx_ui_list = $iface_result['lighttpd_config']['addresses'] ?? $iface_result['lighttpd_config']['interfaces'] ?? [];
                    }

                    // Provide normalized iface_config and sysctl keys directly
                    $fmt_data = [
                        'action' => 'modify',
                        'interfaces' => $ifaces_list,
                        'iface_config' => $iface_result['interface_config'] ?? [],
                        'iface_sysctl_keys' => $iface_result['iface_sysctl_keys'] ?? [],
                        'ssh_list' => $ssh_list,
                        'styx_ui_list' => $styx_ui_list,
                        'iface_roles' => $iface_result['roles'] ?? [],
                    ];
                }
            }

            $fmt_data = NetIfaceFormatter::format($fmt_data);
            // Inject sysctl fragment into the right column via load_tpl
            $page['load_tpl'][] = [
                'file' => 'net-iface-mgmt-sysctl',
                'place' => 'right_column',
                'weight' => 5,
                'tpl_data' => $fmt_data,
            ];
            // Inject virtual-specific fragment (veth)
            $page['load_tpl'][] = [
                'file' => 'net-iface-mgmt-virtual',
                'place' => 'virtual_section',
                'weight' => 5,
                'tpl_data' => $fmt_data,
            ];
            // Inject advanced options fragment
            $page['load_tpl'][] = [
                'file' => 'net-iface-mgmt-advanced',
                'place' => 'advanced_section',
                'weight' => 6,
                'tpl_data' => $fmt_data,
            ];

            // NIC tuning (ethtool): only while editing a physical interface, and only
            // for admins (ethtool-config.* requires system:admin on the gateway). The
            // panel renders in the right column under "Interface Sysctl" (weight 6).
            $ethtool_visible = ($fmt_data['action'] ?? '') === 'modify'
                && in_array($fmt_data['iface_config']['type'] ?? '', ['physical', 'physical_ethernet'], true);
            if ($ethtool_visible) {
                $auth = $ctx->get(AuthService::class);
                $isAdmin = RoleHelper::hasCapability($auth->getCapabilities(), 'system:admin');
                if ($isAdmin) {
                    $page['web_main']['footer_script'][] = ['src' => '/scripts/network/net-iface-mgmt-ethtool.js'];
                    $etResp = (new EthtoolRequestController($ctx))->getIfaceSettings($iface_id);
                    if (is_array($etResp) && ($etResp['status'] ?? '') === 'success') {
                        $et_data = NetIfaceEthtoolFormatter::format($etResp['result'] ?? [], true);
                    } else {
                        $et_data = NetIfaceEthtoolFormatter::formatError(
                            is_array($etResp) ? ($etResp['response_msg'] ?? 'Error loading ethtool settings') : 'Error loading ethtool settings',
                            true
                        );
                    }
                    // Fragment under the sysctl one (weight 5 stays on top)
                    $page['load_tpl'][] = [
                        'file' => 'net-iface-mgmt-ethtool',
                        'place' => 'right_column',
                        'weight' => 6,
                        'tpl_data' => $et_data,
                    ];
                }
            }
        } elseif (!empty($section) && $section === 'net-perf') {
            $iperfController = new IperfRequestController($ctx);
            $response = $iperfController->getIperfPageData();
            if (is_array($response) && ($response['status'] ?? '') !== 'error') {
                $fmt_data = NetPerfFormatter::format($fmt_data, $response['result'] ?? []);
            }
        } elseif (!empty($section) && $section === 'net-traffic-stats') {
            $tsController = new TrafficStatsRequestController($ctx);
            $response = $tsController->getStats();
            if (is_array($response) && ($response['status'] ?? '') === 'success') {
                $fmt_data = NetTrafficStatsFormatter::format($fmt_data, $response);
            }
        } elseif (!empty($section) && $section === 'net-discovery') {
            $discoveryController = new DiscoveryRequestController($ctx);
            $response = $discoveryController->getOverviewData();
            if (is_array($response) && ($response['status'] ?? '') === 'success') {
                $fmt_data = NetDiscoveryFormatter::format($ctx, $fmt_data, $response['result'] ?? []);
                // Format settings from the batched overview response
                $rawSettings = $response['result']['settings'] ?? [];
                $fmt_settings = NetDiscoveryFormatter::formatSettings($rawSettings);
            } else {
                $fmt_settings = [];
            }
            // Inject tab fragments via load_tpl
            $page['load_tpl'][] = [
                'file' => 'net-discovery-overview',
                'place' => 'overview_tab',
                'weight' => 5,
                'tpl_data' => [
                    'stats' => $fmt_data['stats'] ?? [],
                    'source_labels' => $fmt_data['source_labels'] ?? [],
                ],
            ];
            $page['load_tpl'][] = [
                'file' => 'net-discovery-hosts',
                'place' => 'hosts_tab',
                'weight' => 6,
                'tpl_data' => [
                    'hosts_tab' => $fmt_data['hosts_tab'] ?? [],
                ],
            ];
            $page['load_tpl'][] = [
                'file' => 'net-discovery-topology',
                'place' => 'topology_tab',
                'weight' => 7,
                'tpl_data' => [
                    'topology_tab' => $fmt_data['topology_tab'] ?? [],
                ],
            ];
            $page['load_tpl'][] = [
                'file' => 'net-discovery-topology-3d',
                'place' => 'topology_3d_tab',
                'weight' => 8,
                'tpl_data' => [
                    'topology_tab' => $fmt_data['topology_tab'] ?? [],
                ],
            ];
            $page['load_tpl'][] = [
                'file' => 'net-discovery-settings',
                'place' => 'settings_tab',
                'weight' => 9,
                'tpl_data' => [
                    'settings' => $fmt_settings,
                ],
            ];
        }
        $page['page'] = $section;
        $page['page_data'] = $fmt_data;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }
}
