<?php
/**
 * Formatter for system services page.
 * Prepares service rows, status styles, and action HTML for the template.
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class SysServicesFormatter
{
    private const array STATUS_BADGE = [
        'running'  => 'std-badge--success std-badge--dot',
        'inactive' => 'std-badge--danger std-badge--dot',
        'exited'   => 'std-badge--warning std-badge--dot',
        'dead'     => 'std-badge--danger std-badge--dot',
    ];

    private const array NON_MANAGEABLE_ENABLED = ['static', 'alias', 'masked', 'indirect', 'bad'];


    /**
     * Normalize services array into presentation-ready rows.
     *
     * Priority groups:
     * 1. services_running               -  active === 'running' (all, including static/alias)
     * 2. services_enabled_not_running   -  enabled === 'enabled' | 'generated' and active !== 'running'
     * 3. services_disabled              -  enabled === 'disabled'
     * 4. services_static                -  enabled === 'static'
     * 5. services_masked                -  enabled === 'masked'
     * 6. services_other                 -  everything else (alias, indirect, bad, etc.)
     *
     * @param array<string,mixed> $fmt_data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data, array $userCaps = []): array
    {
        $canManage = RoleHelper::hasCapability($userCaps, 'system:admin');
        $services = $fmt_data['services'] ?? [];
        $running = [];
        $enabledNotRunning = [];
        $disabled = [];
        $static = [];
        $masked = [];
        $other = [];

        foreach ($services as $svc) {
            $row = [
                'service'       => $svc['service'] ?? '',
                'description'   => $svc['description'] ?? '',
                'active'        => $svc['active'] ?? '',
                'enabled'       => $svc['enabled'] ?? '',
            ];

            $row['status_badge'] = self::STATUS_BADGE[$row['active']] ?? '';

            $isManageable = !in_array($row['enabled'], self::NON_MANAGEABLE_ENABLED, true);
            $row['actions_html'] = ($isManageable && $canManage)
                ? self::buildActions($row['enabled'], $row['active'], $row['service'])
                : '';

            if ($row['active'] === 'running') {
                $running[] = $row;
            } elseif ($row['enabled'] === 'enabled' || $row['enabled'] === 'generated') {
                $enabledNotRunning[] = $row;
            } elseif ($row['enabled'] === 'disabled') {
                $disabled[] = $row;
            } elseif ($row['enabled'] === 'static') {
                $static[] = $row;
            } elseif ($row['enabled'] === 'masked') {
                $masked[] = $row;
            } else {
                $other[] = $row;
            }
        }

        $fmt_data['services_groups'] = [
            ['label' => 'Running',                 'rows' => $running,            'show_actions' => true],
            ['label' => 'Enabled &amp; not running', 'rows' => $enabledNotRunning, 'show_actions' => true],
            ['label' => 'Disabled',                 'rows' => $disabled,           'show_actions' => true],
            ['label' => 'Static',                   'rows' => $static,             'show_actions' => false],
            ['label' => 'Masked',                   'rows' => $masked,             'show_actions' => false],
            ['label' => 'Others (alias / indirect / bad)', 'rows' => $other,       'show_actions' => false],
        ];
        return $fmt_data;
    }

    /**
     * Build action buttons HTML for a manageable service.
     */
    private static function buildActions(string $enabled, string $active, string $serviceName): string
    {
        $enableBtn = '';
        if ($enabled === 'enabled') {
            $enableBtn = '<button class="btn-service-disable" '
                . 'data-service="' . $serviceName . '">Disable</button>';
        } elseif ($enabled === 'disabled') {
            $enableBtn = '<button class="btn-service-enable" '
                . 'data-service="' . $serviceName . '">Enable</button>';
        }

        if ($active === 'dead' || $active === 'inactive' || $active === 'exited') {
            return '<button class="btn-service-start" '
                . 'data-service="' . $serviceName . '">Start</button> ' . $enableBtn;
        }

        // running or other active state
        return '<button class="btn-service-restart" '
            . 'data-service="' . $serviceName . '">Restart</button> '
            . '<button class="btn-service-stop" '
            . 'data-service="' . $serviceName . '">Stop</button> ' . $enableBtn;
    }
}
