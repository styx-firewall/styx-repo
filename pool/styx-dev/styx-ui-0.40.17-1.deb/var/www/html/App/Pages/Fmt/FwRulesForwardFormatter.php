<?php
/**
 * Formatter for forward firewall rules presentation.
 */
namespace App\Pages\Fmt;

use App\Helpers\FormatHelper;

class FwRulesForwardFormatter
{
    /**
     * Prepare rules for presentation in templates.
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        if (!isset($fmt_data['rules']) || !is_array($fmt_data['rules'])) {
            return $fmt_data;
        }

        foreach ($fmt_data['rules'] as &$rule) {
            // Each resolved set keeps its compact name visible; the actual
            // matched values ride in the title tooltip (see FormatHelper).
            $rule['src_ifaces'] = FormatHelper::setListHtml($rule['src_ifaces'] ?? []);
            $rule['dst_ifaces'] = FormatHelper::setListHtml($rule['dst_ifaces'] ?? []);
            $rule['src_ips'] = FormatHelper::setListHtml($rule['src_ips'] ?? []);
            $rule['dst_ips'] = FormatHelper::setListHtml($rule['dst_ips'] ?? []);
            $rule['src_ports'] = FormatHelper::setListHtml($rule['src_ports'] ?? []);
            $rule['dst_ports'] = FormatHelper::setListHtml($rule['dst_ports'] ?? []);

            if (isset($rule['nat'])) {
                $rule['nat'] = $rule['nat'] ? '<span class="fw-status-ok">✔️</span>' : '<span class="fw-status-ko">✖️</span>';
            }
            if (isset($rule['log'])) {
                $rule['log'] = $rule['log'] ? '<span class="fw-log-icon">📝</span>' : '<span class="fw-muted">-</span>';
            }
            // Pre-format bytes for display
            $rule['bytes_formatted'] = isset($rule['bytes']) ? FormatHelper::formatBytes((int)$rule['bytes']) : '';

            if (isset($rule['enabled'])) {
                $enabledIcon = $rule['enabled'] ? '<span class="fw-enabled-on">🟢</span>' : '<span class="fw-enabled-off">🔴</span>';
                // Append warning icon if discrepancies exist
                if (!empty($rule['warnings']) && is_array($rule['warnings'])) {
                    $msgs = array_column($rule['warnings'], 'msg');
                    $title = implode("\n", $msgs);
                    $enabledIcon .= ' <span class="fw-warning-icon" title="' . $title . '">⚠️</span>';
                }
                $rule['enabled'] = $enabledIcon;
            }
        }
        unset($rule);

        // Prepare JSON-encoded payloads for the template presentation layer.
        $thead = [
            'enabled'    => 'Enbl',
            'name'       => 'Name',
            'protocol'   => 'Proto',
            'family'     => 'Family',
            'chain'      => 'Chain',
            'src_ifaces' => 'In Interface',
            'dst_ifaces' => 'Out Interface',
            'src_ips'    => 'Src IPs',
            'src_ports'  => 'Src Ports',
            'dst_ips'    => 'Dst IPs',
            'dst_ports'  => 'Dst Ports',
            'action'     => 'Action',
            'nat'        => 'NAT',
            'log'        => 'Log',
            'packets'    => 'Packets',
            'bytes'      => 'Bytes',
            'handle'     => 'Handle',
            'id'         => 'ID',
            'comment'    => 'Comment',
        ];

        // Columns whose selector checkbox is unchecked by default. The forward
        // view is already scoped to a single chain/family per tab, so those
        // (plus the raw handle/id) are redundant; they stay available togglable.
        $columnsConfig = [
            'family' => false,
            'chain'  => false,
            'handle' => false,
            'id'     => false,
        ];

        $rows = array_map(function($r) {
            return [
                'name'       => $r['name'] ?? '',
                'protocol'   => FormatHelper::protocolBadge($r['protocol'] ?? ''),
                'family'     => $r['family'] ?? '',
                'chain'      => $r['chain'] ?? '',
                'src_ifaces' => $r['src_ifaces'] ?? '',
                'dst_ifaces' => $r['dst_ifaces'] ?? '',
                'src_ips'    => $r['src_ips'] ?? '',
                'src_ports'  => $r['src_ports'] ?? '',
                'dst_ips'    => $r['dst_ips'] ?? '',
                'dst_ports'  => $r['dst_ports'] ?? '',
                'action'     => FormatHelper::verdictBadge($r['action'] ?? ''),
                'nat'        => $r['nat'] ?? '',
                'log'        => $r['log'] ?? '',
                'enabled'    => $r['enabled'] ?? '',
                'comment'    => $r['comment'] ?? '',
                'packets'    => $r['packets'] ?? '',
                'bytes'      => $r['bytes_formatted'] ?? ($r['bytes'] ?? ''),
                'id'          => $r['id'] ?? '',
                'handle'      => $r['handle'] ?? '',
                // Flags consumed by the frontend to block moves relative to
                // system rules (move_firewall_rule rejects crossing them).
                'system_rule'  => $r['system_rule'] ?? 0,
                'end_of_chain' => $r['end_of_chain'] ?? 0,
            ];
        }, $fmt_data['rules']);

        // Safe JSON encoding for embedding into HTML/JS
        $fmt_data['fw_thead_json'] = json_encode($thead, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
        $fmt_data['fw_rows_json'] = json_encode($rows, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
        $fmt_data['fw_columns_config_json'] = json_encode($columnsConfig);

        return $fmt_data;
    }
}
