<?php
/**
 * Formatter for the per-interface ethtool panel (net-iface-mgmt-ethtool fragment).
 * Turns the raw `iface` object of ethtool-config.get_iface_settings into an
 * echo-only presentation structure consumed by the template.
 *
 * RBAC: ethtool-config.* requires system:admin. The formatter receives $isAdmin;
 * nothing that lets a non-admin mutate (editability, NIC action buttons) is emitted
 * when $isAdmin is false.
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class NetIfaceEthtoolFormatter
{
    /** @var string[] Family keys in canonical display order. */
    private const FAMILY_ORDER = ['features', 'ring', 'coalesce'];

    /** @var array<string,string> Group bucket labels. */
    private const GROUP_LABELS = [
        'common' => 'Common',
        'extra'  => 'Enterprise (extra)',
        'driver' => 'Driver-specific',
    ];

    /**
     * Format an ethtool iface report for the template.
     *
     * @param array $iface raw `iface` object (families + managed/enabled/seeded + warnings)
     * @param bool  $isAdmin whether the user holds system:admin
     * @return array presentation data
     */
    public static function format(array $iface, bool $isAdmin = false): array
    {
        $managed = !empty($iface['managed']);
        $enabled = !empty($iface['enabled']);
        $seeded  = !empty($iface['seeded']);
        $profile = is_string($iface['profile'] ?? null) ? $iface['profile'] : '';

        $t = [
            'et_iface_id'      => is_scalar($iface['iface_id'] ?? null) ? (string)$iface['iface_id'] : '',
            'et_iface_name'    => self::esc($iface['iface_name'] ?? ''),
            'et_managed'       => $managed,
            'et_enabled'       => $enabled,
            'et_seeded'        => $seeded,
            'et_profile'       => $profile,
            'et_profile_esc'   => self::esc($profile),
            'et_can_edit'      => $isAdmin,
            'et_families'      => [],
            'et_sync_warnings' => [],
        ];

        // counts drive the "no operator settings" note and the clear button
        $operatorCount = 0;
        $profileCount = 0;
        $storedTotal = 0;

        $families = [];
        $rawFamilies = is_array($iface['families'] ?? null) ? $iface['families'] : [];
        $presentKeys = array_keys($rawFamilies);
        // canonical order first, then any extra family key the NIC reports
        foreach (self::FAMILY_ORDER as $key) {
            if (array_key_exists($key, $rawFamilies)) {
                $families[$key] = $rawFamilies[$key];
            }
        }
        foreach ($presentKeys as $key) {
            if (!array_key_exists($key, $families)) {
                $families[$key] = $rawFamilies[$key];
            }
        }

        foreach ($families as $key => $fam) {
            if (!is_array($fam)) {
                continue;
            }
            $built = self::buildFamily($key, $fam, $isAdmin);
            $operatorCount += $built['etf_operator_count'];
            $profileCount += $built['etf_profile_count'];
            $storedTotal += $built['etf_stored_count'];
            unset($built['etf_operator_count'], $built['etf_profile_count'], $built['etf_stored_count']);
            $t['et_families'][] = $built;
        }

        // Sync warnings (stored != live / family unreadable / setting gone). If the
        // gateway reports them nested in the iface, expose their messages verbatim.
        $sync = $iface['warnings'] ?? [];
        if (is_array($sync)) {
            foreach ($sync as $w) {
                if (!is_array($w)) {
                    continue;
                }
                $msg = $w['msg'] ?? '';
                if ($msg !== '') {
                    $t['et_sync_warnings'][] = self::esc($msg);
                }
            }
        }

        $t['et_operator_count'] = $operatorCount;
        $t['et_profile_count'] = $profileCount;
        $t['et_stored_count'] = $storedTotal;
        $t['et_no_operator_note_esc'] = self::noOperatorNote($managed, $seeded, $operatorCount, $profileCount, $storedTotal);
        $t['et_state_html'] = self::stateHtml($managed, $enabled, $seeded, $profile, $operatorCount, $profileCount);
        $t['et_actions_html'] = self::actionsHtml($managed, $enabled, $storedTotal, $isAdmin);

        return $t;
    }

    /**
     * Presentation data for a load error: render the collapsible box with a message.
     *
     * @param string $msg
     * @param bool   $isAdmin
     * @return array
     */
    public static function formatError(string $msg, bool $isAdmin = false): array
    {
        return [
            'et_iface_id'          => '',
            'et_iface_name'        => '',
            'et_managed'           => false,
            'et_enabled'           => false,
            'et_seeded'            => false,
            'et_profile'           => '',
            'et_profile_esc'       => '',
            'et_can_edit'          => $isAdmin,
            'et_families'          => [],
            'et_sync_warnings'     => [],
            'et_operator_count'    => 0,
            'et_profile_count'     => 0,
            'et_stored_count'      => 0,
            'et_no_operator_note_esc' => '',
            'et_state_html'        => '',
            'et_actions_html'      => '',
            'et_load_error_esc'    => self::esc($msg),
        ];
    }

    /**
     * Build one family block (supported flag, read error, grouped rows).
     */
    private static function buildFamily(string $key, array $fam, bool $isAdmin): array
    {
        $supported = !empty($fam['supported']);
        $readError = is_string($fam['read_error'] ?? null) ? $fam['read_error'] : '';
        $rows = [];
        $operatorCount = 0;
        $profileCount = 0;
        $storedCount = 0;

        $entries = is_array($fam['entries'] ?? null) ? $fam['entries'] : [];
        foreach ($entries as $e) {
            if (!is_array($e)) {
                continue;
            }
            $row = self::buildRow($e, $isAdmin);
            if (!empty($row['has_stored'])) {
                $storedCount++;
                if ($row['source'] === 'operator') {
                    $operatorCount++;
                } elseif ($row['source'] === 'profile') {
                    $profileCount++;
                }
            }
            $rows[] = $row;
        }

        // group rows: common / extra_common / driver-specific, preserving order
        $groups = [];
        foreach (['common', 'extra', 'driver'] as $bucket) {
            $items = array_values(array_filter($rows, function ($r) use ($bucket) {
                return $r['group'] === $bucket;
            }));
            if (!empty($items)) {
                $groups[] = [
                    'etg_label_esc' => self::esc(self::GROUP_LABELS[$bucket]),
                    'etg_rows'      => $items,
                ];
            }
        }

        return [
            'etf_key'              => $key,
            'etf_title_esc'        => self::esc(ucfirst($key)),
            'etf_supported'        => $supported,
            'etf_read_error_esc'   => $readError !== '' ? self::esc($readError) : '',
            'etf_groups'           => $groups,
            'etf_operator_count'   => $operatorCount,
            'etf_profile_count'    => $profileCount,
            'etf_stored_count'     => $storedCount,
        ];
    }

    /**
     * Normalize a single ethtool entry to its presentation row.
     */
    private static function buildRow(array $e, bool $isAdmin): array
    {
        $setting = is_string($e['setting'] ?? null) ? $e['setting'] : '';
        $documented = !empty($e['documented']);
        $present = !empty($e['present']);
        $settable = !empty($e['settable']);
        $typeRaw = is_string($e['type'] ?? null) ? $e['type'] : '';
        $type = ($typeRaw === 'bool' || $typeRaw === 'int') ? $typeRaw : 'none';
        $fixed = $e['fixed'] ?? null;

        // Stored override: the report exposes `stored_value` (+ original/source);
        // `value` is the internal datastore key used by some backend versions.
        $hasStoredRaw = array_key_exists('stored_value', $e);
        $stored = $e['stored_value'] ?? $e['value'] ?? null;
        $hasStored = $stored !== null;
        // treat explicit null / absent as "not stored"
        if ($hasStoredRaw && $stored === null) {
            $hasStored = false;
        }
        $source = is_string($e['source'] ?? null) ? $e['source'] : '';
        $liveValue = $e['live_value'] ?? null;
        $editable = $isAdmin && $present && $settable && $type !== 'none';

        // control baseline = stored override, otherwise what the NIC currently reports
        $baseline = $hasStored ? $stored : $liveValue;
        $liveNorm = self::normScalar($liveValue);
        $storedNorm = $hasStored ? self::normScalar($stored) : null;

        $row = [
            'setting'          => $setting,
            'setting_esc'      => self::esc($setting),
            'group'            => self::bucketOf($documented, $e['category'] ?? null),
            'label_esc'        => self::esc(self::labelOf($e, $setting, $documented)),
            'desc_esc'         => self::esc(is_string($e['description'] ?? null) ? $e['description'] : ''),
            'documented'       => $documented,
            'present'          => $present,
            'settable'         => $settable,
            'fixed'            => $fixed,
            'type'             => $type,                       // bool | int | none
            'editable'         => $editable,
            'disabled_attr'    => $editable ? '' : 'disabled',
            'live_esc'         => self::esc(self::scalarStr($liveValue)),
            'has_stored'       => $hasStored,
            'stored_esc'       => $hasStored ? self::esc(self::scalarStr($stored)) : '',
            'stored_val_esc'   => $hasStored ? self::esc((string)$stored) : '',
            'source'           => $source,
            'source_esc'       => self::esc($source === 'operator' ? 'Operator' : ($source === 'profile' ? 'Profile' : '')),
            'differs'          => $hasStored && $liveNorm !== $storedNorm,
        ];

        // control-specific helpers (bool switch vs int number input)
        if ($type === 'bool') {
            $checked = self::asBool($baseline);
            $row['is_bool'] = true;
            $row['is_int'] = false;
            $row['checked_attr'] = $checked ? 'checked' : '';
            $row['ctl_original'] = $checked ? '1' : '0';
        } elseif ($type === 'int') {
            $num = self::asInt($baseline);
            $row['is_bool'] = false;
            $row['is_int'] = true;
            $row['num_val'] = $num === null ? '' : (string)$num;
            $row['ctl_original'] = $num === null ? '' : (string)$num;
        } else {
            $row['is_bool'] = false;
            $row['is_int'] = false;
            $row['ctl_original'] = '';
        }

        return $row;
    }

    /**
     * Note shown when styx watches the NIC but the operator has not overridden anything.
     */
    private static function noOperatorNote(bool $managed, bool $seeded, int $opCount, int $profileCount, int $storedTotal): string
    {
        if (!$managed || $opCount > 0) {
            return '';
        }
        if ($storedTotal === 0) {
            return 'No settings applied yet — nothing is persisted for this NIC until you change a value.';
        }
        if ($profileCount > 0) {
            return 'No operator settings yet (only the curated profile).';
        }
        return 'No operator settings yet.';
    }

    /**
     * Collapsible header / state caption (HTML pre-built, all dynamic parts escaped).
     */
    private static function stateHtml(bool $managed, bool $enabled, bool $seeded, string $profile, int $opCount, int $profileCount): string
    {
        if (!$managed) {
            return '<span class="std-badge std-badge--unmanaged">Not managed</span> '
                . 'styx does not manage ethtool for this NIC; enable it or edit a value to start.';
        }
        $badge = $enabled
            ? '<span class="std-badge std-badge--success">Managed</span>'
            : '<span class="std-badge std-badge--warning">Management disabled</span>';
        $parts = [];
        if ($profile !== '') {
            $parts[] = 'profile: ' . self::esc($profile);
        } elseif (!$seeded) {
            $parts[] = 'profile not seeded yet';
        }
        if ($opCount > 0) {
            $parts[] = $opCount . ' operator setting' . ($opCount === 1 ? '' : 's');
        } elseif ($profileCount > 0) {
            $parts[] = $profileCount . ' from profile';
        }
        $suffix = !empty($parts) ? ' — ' . implode(', ', $parts) : '';
        $tail = $enabled ? '' : ' — stored settings are kept but not applied.';
        return $badge . ' styx is watching this NIC' . $suffix . $tail;
    }

    /**
     * NIC-level action buttons (pre-built HTML). Only for admins; behaviour driven by data-js.
     */
    private static function actionsHtml(bool $managed, bool $enabled, int $storedTotal, bool $isAdmin): string
    {
        if (!$isAdmin) {
            return '';
        }
        $h = '';
        if (!$enabled) {
            $h .= self::btn('et-enable', 'Enable ethtool management');
            return '<div class="et-actions">' . $h . '</div>';
        }
        $h .= self::btn('et-apply-defaults', 'Apply defaults');
        $h .= self::btn('et-disable', 'Disable ethtool management', 'et-danger');
        if ($storedTotal > 0) {
            $h .= self::btn('et-clear', 'Clear all settings', 'et-danger');
        }
        return '<div class="et-actions">' . $h . '</div>';
    }

    private static function btn(string $dataJs, string $label, string $extra = ''): string
    {
        $cls = 'std-btn et-action' . ($extra !== '' ? ' ' . $extra : '');
        return '<button type="button" class="' . $cls . '" data-js="' . $dataJs . '">'
            . self::esc($label) . '</button> ';
    }

    private static function labelOf(array $e, string $setting, bool $documented): string
    {
        if (!$documented) {
            return $setting; // driver-specific keys show their raw name
        }
        $label = is_string($e['label'] ?? null) ? $e['label'] : '';
        return $label !== '' ? $label : $setting;
    }

    private static function bucketOf(bool $documented, $category): string
    {
        if (!$documented || $category === null) {
            return 'driver';
        }
        if ($category === 'common') {
            return 'common';
        }
        if ($category === 'extra_common') {
            return 'extra';
        }
        return 'driver';
    }

    private static function esc($value): string
    {
        if (is_bool($value)) {
            $value = $value ? 'true' : 'false';
        } elseif (!is_scalar($value)) {
            $value = '';
        }
        return Filter::escHtml((string)$value);
    }

    private static function scalarStr($value): string
    {
        if (is_bool($value)) {
            return $value ? 'On' : 'Off';
        }
        if ($value === null) {
            return 'n/a';
        }
        return (string)$value;
    }

    private static function asBool($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value)) {
            return $value != 0;
        }
        if (is_string($value)) {
            return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true);
        }
        return false;
    }

    private static function asInt($value): ?int
    {
        if (is_int($value)) {
            return $value;
        }
        if (is_numeric($value)) {
            return (int)$value;
        }
        if (is_string($value)) {
            $trimmed = trim($value);
            if ($trimmed !== '' && is_numeric($trimmed)) {
                return (int)$trimmed;
            }
        }
        return null;
    }

    /**
     * Value comparison token: numbers/booleans reduced so 1 == true == "1".
     */
    private static function normScalar($value)
    {
        if (is_bool($value)) {
            return $value ? 1 : 0;
        }
        if (is_int($value) || is_float($value)) {
            return $value;
        }
        if (is_string($value)) {
            $t = strtolower(trim($value));
            if ($t === '' ) {
                return null;
            }
            if (in_array($t, ['1', 'true', 'yes', 'on'], true)) {
                return 1;
            }
            if (in_array($t, ['0', 'false', 'no', 'off'], true)) {
                return 0;
            }
            return is_numeric($t) ? (int)$t : $t;
        }
        return $value;
    }
}
