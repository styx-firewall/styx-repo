<?php
/**
 * ServNtpFormatter - presentation helpers for the NTP (chrony) service pane.
 *
 * Templates are echo-only: every derived text, badge class, selected/checked
 * token, attribute value and the Save/Reset button HTML is computed here.
 *
 * Input (from PageServices):
 *   - config       raw ntp configuration model (msg already stripped)
 *   - status       raw ntp runtime status
 *   - config_error string|null   load error of ntp.get_config
 *   - status_error string|null   load error of ntp.get_status
 *
 * @see App\Controllers\PageServices
 * @see api/handlers/ntp.md
 */
namespace App\Pages\Fmt;

class ServNtpFormatter
{
    /** chrony status letter -> badge variant (std-badge--*) */
    private const SOURCE_BADGES = [
        '*' => 'std-badge--success std-badge--dot',
        '+' => 'std-badge--success std-badge--dot',
        '-' => 'std-badge--warning std-badge--dot',
        '?' => 'std-badge--danger std-badge--dot',
        'x' => 'std-badge--danger std-badge--dot',
        '~' => 'std-badge--info std-badge--dot',
    ];

    /** tracking fields shown in the Estado tab, in order. */
    private const TRACKING_LABELS = [
        'refid'             => 'Ref ID',
        'ref_name'          => 'Reference',
        'stratum'           => 'Stratum',
        'leap_status'       => 'Leap status',
        'ref_time'          => 'Ref time',
        'system_time'       => 'System time',
        'last_offset'       => 'Last offset',
        'rms_offset'        => 'RMS offset',
        'frequency'         => 'Frequency',
        'root_delay'        => 'Root delay',
        'root_dispersion'   => 'Root dispersion',
        'update_interval'   => 'Update interval',
    ];

    /** clients table columns (backend field => header). */
    private const CLIENT_COLUMNS = [
        'host' => 'Host',
        'ntp'  => 'NTP',
        'int'  => 'Int',
        'ins'  => 'Ins',
        'del'  => 'Del',
        'res'  => 'Res',
        'ret'  => 'Ret',
        'nreq' => 'NReq',
        'rreq' => 'RReq',
        'hreq' => 'HReq',
    ];

    /**
     * @param array<string,mixed> $fmt_data
     * @param bool $isAdmin has system:admin capability
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data, bool $isAdmin = false): array
    {
        $config = is_array($fmt_data['config'] ?? null) ? $fmt_data['config'] : [];
        $status = is_array($fmt_data['status'] ?? null) ? $fmt_data['status'] : [];
        $cfgError = $fmt_data['config_error'] ?? null;
        $stLoadError = $fmt_data['status_error'] ?? null;

        $cfgError = is_string($cfgError) && $cfgError !== '' ? $cfgError : null;
        $stLoadError = is_string($stLoadError) && $stLoadError !== '' ? $stLoadError : null;

        $fmt = [];
        $fmt['config'] = $config;
        // Display values are pre-escaped here; templates only echo them.
        $fmt['cfg_error'] = $cfgError === null ? null : self::esc($cfgError);
        $fmt['can_edit'] = $isAdmin && $cfgError === null;
        $fmt['can_save'] = $fmt['can_edit'];
        $fmt['can_reset'] = $fmt['can_edit'];
        $fmt['disabled_attr'] = $fmt['can_edit'] ? '' : 'disabled';

        // ---------------- Configuration fragment (cfg_*) ----------------
        $fmt['cfg_provider_label'] = self::esc(is_string($config['provider'] ?? null) ? $config['provider'] : 'chrony');

        $sources = is_array($config['sources'] ?? null) ? $config['sources'] : [];
        $fmt['cfg_sources_empty'] = count($sources) === 0;
        $fmt['cfg_sources_empty_note'] = $fmt['cfg_sources_empty']
            ? self::esc('No managed NTP sources; chrony will use sources.d/conf.d sources only.')
            : null;

        $rows = [];
        foreach ($sources as $src) {
            if (!is_array($src)) {
                continue;
            }
            $type = ($src['type'] ?? null) === 'pool' ? 'pool' : 'server';
            $rows[] = [
                'type'               => $type,
                'type_pool_sel'      => $type === 'pool' ? ' selected' : '',
                'type_server_sel'    => $type === 'server' ? ' selected' : '',
                'address_esc'        => self::esc($src['address'] ?? ''),
                'iburst_checked'     => !empty($src['iburst']) ? 'checked' : '',
                'prefer_checked'     => !empty($src['prefer']) ? 'checked' : '',
                'is_pool'            => $type === 'pool',
                'minpoll_val'        => self::numOrEmpty($src['minpoll'] ?? null),
                'maxpoll_val'        => self::numOrEmpty($src['maxpoll'] ?? null),
                'maxsources_val'     => self::numOrEmpty($src['maxsources'] ?? null),
            ];
        }
        $fmt['cfg_sources_rows'] = $rows;

        // server role
        $server = is_array($config['server'] ?? null) ? $config['server'] : [];
        $allow = is_array($server['allow'] ?? null) ? $server['allow'] : [];
        $fmt['cfg_server_enabled_checked'] = !empty($server['enabled']) ? 'checked' : '';
        $fmt['cfg_server_allow_esc'] = self::esc(implode("\n", array_map('strval', $allow)));

        $local = is_array($server['local'] ?? null) ? $server['local'] : [];
        $fmt['cfg_server_local_enabled_checked'] = !empty($local['enabled']) ? 'checked' : '';
        $fmt['cfg_server_local_stratum_val'] = self::numOrEmpty($local['stratum'] ?? null);
        $fmt['cfg_server_local_orphan_checked'] = !empty($local['orphan']) ? 'checked' : '';

        $serverEnabled = !empty($server['enabled']);
        $fmt['cfg_server_role_note_firewall'] = $serverEnabled
            ? self::esc('The NTP server role does not open UDP 123 in the firewall; add the matching allow rule yourself.')
            : null;
        $fmt['cfg_server_role_note_require'] = $serverEnabled
            ? self::esc('Enabling the server role requires a non-zero port (global) and at least one entry in allow.')
            : null;

        // global
        $global = is_array($config['global'] ?? null) ? $config['global'] : [];
        $fmt['cfg_global_port_val'] = self::numOrEmpty($global['port'] ?? null);
        $fmt['cfg_global_threshold_val'] = self::numOrEmpty($global['makestep_threshold'] ?? null);
        $fmt['cfg_global_limit_val'] = self::numOrEmpty($global['makestep_limit'] ?? null);
        $fmt['cfg_global_skew_val'] = self::numOrEmpty($global['maxupdateskew'] ?? null);
        $fmt['cfg_global_rtcsync_checked'] = !empty($global['rtcsync']) ? 'checked' : '';

        // bounds for number inputs
        $fmt['cfg_minpoll_min'] = -7;
        $fmt['cfg_minpoll_max'] = 24;
        $fmt['cfg_maxpoll_min'] = -7;
        $fmt['cfg_maxpoll_max'] = 24;
        $fmt['cfg_maxsources_min'] = 1;
        $fmt['cfg_maxsources_max'] = 16;
        $fmt['cfg_port_min'] = 0;
        $fmt['cfg_port_max'] = 65535;
        $fmt['cfg_stratum_min'] = 1;
        $fmt['cfg_stratum_max'] = 15;

        // Save / Reset (admin only). HTML is assembled here, not in the template.
        $fmt['cfg_buttons_html'] = '';
        if ($fmt['can_edit']) {
            $fmt['cfg_buttons_html'] =
                '<button type="button" class="std-btn" data-js="ntp-save-config">Save Configuration</button> '
                . '<button type="button" class="std-btn std-btn--secondary" data-js="ntp-reset-config">Reset Defaults</button>';
        }

        // ---------------- Status fragment (st_*) ----------------
        $fmt['st_load_error'] = $stLoadError === null ? null : self::esc($stLoadError);

        $service = is_array($status['service'] ?? null) ? $status['service'] : [];
        $fmt['st_provider'] = self::esc(is_string($service['provider'] ?? null) ? $service['provider'] : 'chrony');
        $stInstalled = !empty($service['installed']);
        $fmt['st_installed'] = $stInstalled;
        $fmt['st_not_installed_note'] = $stInstalled
            ? null
            : self::esc('(chrony not installed - configuration is stored only)');
        $stActive = !empty($service['active']);
        $fmt['st_active_text'] = $stActive ? 'Active' : 'Stopped';
        $fmt['st_active_badge'] = $stActive ? 'std-badge--success std-badge--dot' : 'std-badge--danger std-badge--dot';
        $fmt['st_enabled_text'] = !empty($service['enabled']) ? 'Enabled' : 'Disabled';

        // runtime error (status.error) is NOT a transport failure: the call was success.
        $stError = self::strOrNull($status['error'] ?? null);
        $fmt['st_error'] = $stError === null ? null : self::esc($stError);

        $notes = is_array($status['notes'] ?? null) ? array_values($status['notes']) : [];
        $fmt['st_notes'] = array_map([self::class, 'esc'], $notes);
        $fmt['st_has_notes'] = count($notes) > 0;

        $srcCount = $status['source_count'] ?? (is_array($status['sources'] ?? null) ? count($status['sources']) : 0);
        $fmt['st_source_count'] = is_numeric($srcCount) ? (int)$srcCount : 0;

        // tracking
        $tracking = is_array($status['tracking'] ?? null) ? $status['tracking'] : null;
        $fmt['st_tracking_has'] = $tracking !== null && count($tracking) > 0;
        $trackingRows = [];
        if ($fmt['st_tracking_has']) {
            foreach (self::TRACKING_LABELS as $key => $label) {
                $trackingRows[] = [
                    'label' => $label,
                    'value' => self::dash($tracking[$key] ?? null),
                ];
            }
        }
        $fmt['st_tracking_rows'] = $trackingRows;
        $fmt['st_tracking_absent_note'] = (!$fmt['st_tracking_has'] && $fmt['st_error'] === null)
            ? self::esc('No tracking information yet (not synchronised).')
            : null;

        // sources table
        $liveSources = is_array($status['sources'] ?? null) ? $status['sources'] : [];
        $hasLive = count($liveSources) > 0;
        $fmt['st_sources_has'] = $hasLive;
        $srcRows = [];
        foreach ($liveSources as $s) {
            if (!is_array($s)) {
                continue;
            }
            $state = (string)($s['state'] ?? '');
            $srcRows[] = [
                'ms'                   => self::dash($s['ms'] ?? null),
                'state_display'        => self::esc($state !== '' ? $state : '-'),
                'state_badge'          => self::SOURCE_BADGES[$state] ?? '',
                'name'                 => self::dash($s['name'] ?? null),
                'stratum'              => self::dash($s['stratum'] ?? null),
                'poll'                 => self::dash($s['poll'] ?? null),
                'reach'                => self::dash($s['reach'] ?? null),
                'last_rx'              => self::dash($s['last_rx'] ?? null),
                'last_sample_offset'   => self::dash($s['last_sample_offset'] ?? null),
                'last_sample_drift'    => self::dash($s['last_sample_drift'] ?? null),
                'last_sample_rms'      => self::dash($s['last_sample_rms'] ?? null),
            ];
        }
        $fmt['st_sources_rows'] = $srcRows;
        $fmt['st_sources_empty_note'] = (!$hasLive && $fmt['st_error'] === null)
            ? self::esc('No NTP sources reported by chrony.')
            : null;

        // server role + clients
        $role = is_array($status['server_role'] ?? null) ? $status['server_role'] : [];
        $roleEnabled = !empty($role['enabled']);
        $roleServing = !empty($role['serving']);
        $fmt['st_server_role_enabled'] = $roleEnabled;
        $fmt['st_server_role_serving'] = $roleServing;
        if ($roleServing) {
            $fmt['st_server_role_text'] = self::esc('Serving');
            $fmt['st_server_role_badge'] = 'std-badge--success std-badge--dot';
        } elseif ($roleEnabled) {
            $fmt['st_server_role_text'] = self::esc('Enabled (not serving)');
            $fmt['st_server_role_badge'] = 'std-badge--warning std-badge--dot';
        } else {
            $fmt['st_server_role_text'] = self::esc('Disabled');
            $fmt['st_server_role_badge'] = 'std-badge--info std-badge--dot';
        }

        $clients = is_array($status['clients'] ?? null) ? $status['clients'] : [];
        $fmt['st_clients_cols'] = self::CLIENT_COLUMNS;
        $clientRows = [];
        foreach ($clients as $c) {
            if (!is_array($c)) {
                continue;
            }
            $row = [];
            foreach (array_keys(self::CLIENT_COLUMNS) as $key) {
                $row[$key] = self::dash($c[$key] ?? null);
            }
            $clientRows[] = $row;
        }
        $fmt['st_clients_rows'] = $clientRows;
        $fmt['st_clients_has'] = count($clientRows) > 0;
        if ($fmt['st_clients_has']) {
            $fmt['st_clients_note'] = null;
        } elseif ($roleEnabled) {
            $fmt['st_clients_note'] = self::esc('No clients currently connected.');
        } else {
            $fmt['st_clients_note'] = self::esc('Server role is off - no clients tracked.');
        }

        return $fmt;
    }

    /**
     * htmlspecialchars for attribute/textarea values.
     */
    private static function esc(mixed $v): string
    {
        return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    }

    /**
     * nullable number -> empty string (for optional numeric inputs). '' means
     * "chrony default" for minpoll/maxpoll/maxsources and is sent as null.
     */
    private static function numOrEmpty(mixed $v): string
    {
        return ($v === null || $v === '') ? '' : (string)$v;
    }

    /**
     * value -> '-' when empty/null, HTML-escaped (table cells are echoed raw).
     */
    private static function dash(mixed $v): string
    {
        return ($v === null || $v === '') ? '-' : self::esc($v);
    }

    private static function strOrNull(mixed $v): ?string
    {
        return (is_string($v) && $v !== '') ? $v : null;
    }
}
