<?php
/**
 * Formatter for strongSwan VPN page presentation.
 *
 * Moves data transformation, secret stripping, and display-string
 * generation out of the template so the .tpl.php file only echoes
 * pre-computed values.
 *
 * Fallback / default-value policy
 * --------------------------------
 * - Configuration-meaningful fields (type, ike_version, auth, etc.)
 *   are NEVER silently defaulted. Missing means missing - the template
 *   will show an empty cell or a "-" placeholder so the operator notices.
 * - Pure display / cosmetic fields (status labels, counters) use safe
 *   conservative defaults (e.g. status → "Down", count → 0).
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class StrongswanFormatter
{
    private const JSON_FLAGS = JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP;

    /**
     * @param array<string,mixed> $fmt_data Raw page data from the controller.
     * @param string[] $userCaps
     * @return array<string,mixed> Enriched page data ready for the template.
     */
    public static function format(array $fmt_data, array $userCaps = []): array
    {
        $canWrite  = RoleHelper::hasCapability($userCaps, 'vpn:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'vpn:delete');
        $canApply  = RoleHelper::hasCapability($userCaps, 'vpn:apply');

        $connections = $fmt_data['connections'] ?? [];
        $pools       = $fmt_data['pools'] ?? [];
        $secrets     = $fmt_data['secrets'] ?? [];
        $certs       = $fmt_data['certificates'] ?? [];
        $statusList  = $fmt_data['status'] ?? [];
        $globalCfg   = $fmt_data['global_config'] ?? [];
        $interfaces  = $fmt_data['interfaces'] ?? [];

        // Strip secret values (and any generated defaults) before exposing to JS (write-only policy)
        $secretsSafe = array_map(function ($s) {
            unset($s['value'], $s['generated_value']);
            return $s;
        }, $secrets);

        // Formatted rows for server-side HTML rendering
        $fmt_data['conn_rows']   = self::formatConnections($connections, $canWrite, $canApply, $canDelete);
        $fmt_data['pool_rows']   = self::formatPools($pools, $canWrite, $canDelete);
        $fmt_data['secret_rows'] = self::formatSecrets($secrets, $canWrite, $canDelete);
        $fmt_data['cert_rows']   = self::formatCerts($certs);
        $fmt_data['status_rows'] = self::formatStatus($statusList);
        $fmt_data['global']      = self::formatGlobalConfig($globalCfg);

        // Capability flags for the template
        $fmt_data['can_create'] = $canWrite;
        $fmt_data['can_apply']  = $canApply;

        // Server-rendered <select> option arrays for the connection form partial
        $fmt_data['interface_options'] = self::formatInterfaceOptions($interfaces);
        $fmt_data['cert_options']      = self::formatCertOptions($certs);
        $fmt_data['pool_options']      = self::formatPoolOptions($pools);
        $fmt_data['proposal_options']  = self::formatProposalOptions();

        // JSON payloads for window.swan* client-side variables
        // Only data needed by JS for edit-mode population and dynamic refresh
        $fmt_data['json_connections']  = self::safeJsonEncode($connections);
        $fmt_data['json_secrets']      = self::safeJsonEncode($secretsSafe);
        $fmt_data['json_pools']        = self::safeJsonEncode($pools);

        return $fmt_data;
    }

    /**
     * Encode to JSON with error handling. Returns '[]' on failure so JS
     * always receives valid syntax.
     */
    private static function safeJsonEncode(mixed $data): string
    {
        $json = json_encode($data, self::JSON_FLAGS);
        if ($json === false) {
            error_log('StrongswanFormatter: json_encode failed: ' . json_last_error_msg());
            return '[]';
        }
        return $json;
    }

    //
    // Row formatters - one per tab
    //

    /**
     * Connections tab rows.
     *
     * Config-meaningful fields (type, ike_version, local_auth) are passed
     * through as-is; if the backend omits them the cell will be empty,
     * which is preferable to silently assuming a wrong value.
     *
     * @param array<int,array<string,mixed>> $connections
     * @return array<int,array<string,mixed>>
     */
    private static function formatConnections(array $connections, bool $canWrite, bool $canApply, bool $canDelete): array
    {
        $rows = [];
        foreach ($connections as $conn) {
            // A connection without a name is malformed - skip it
            if (empty($conn['name'])) {
                continue;
            }

            // Status is display-only; "down" is the safe conservative assumption.
            // Backend supplies: "Up" | "Down" | "Connecting".
            $status      = $conn['status'] ?? 'down';
            $statusLower = strtolower($status);

            // tunnel_ready indicates whether the data tunnel (CHILD_SA) is established.
            // Only meaningful when status is "Up" (IKE_SA is active).
            $tunnelReady = !empty($conn['tunnel_ready']);

            // DPD active if dpd_delay > 0
            if (isset($conn['dpd_delay'])) {
                $dpdText = (int)$conn['dpd_delay'] > 0 ? 'On' : 'Off';
            } else {
                $dpdText = '-';
            }

            // Determine whether the frontend should allow initiating this connection
            $remoteAccess = !empty($conn['remote_access']);
            $startAction  = strtolower(trim($conn['start_action'] ?? ''));
            $initiateAllowed = true;
            $initiateTitle   = '';

            // Road-warrior (remote-access) handling: respect explicit role when present.
            // If role === 'client' the local endpoint acts as a client and may initiate.
            // If role === 'server' (or role missing) the local endpoint should not initiate.
            if ($remoteAccess) {
                if (isset($conn['role']) && $conn['role'] === 'client') {
                    $initiateAllowed = true;
                } else {
                    $initiateAllowed = false;
                    $initiateTitle   = 'Road-warrior connections must be initiated by the remote client';
                }
            // Explicit 'trap' means do not initiate locally
            } elseif ($startAction === 'trap') {
                $initiateAllowed = false;
                $initiateTitle   = 'This connection is not configured to be initiated locally';
            // Otherwise allow manual initiation: start/none/null mean allowed
            }

            $rows[] = [
                'id'                      => $conn['id'] ?? '',
                'name'                    => $conn['name'],
                'type'                    => $conn['type'] ?? '',
                'ike_version'             => $conn['ike_version'] ?? '',
                'local_id'                => $conn['local_id'] ?? '',
                'remote_id'               => $conn['remote_id'] ?? '',
                'local_ts'                => self::renderDisplayNames($conn['local_ts_display'] ?? []),
                'remote_ts'               => self::renderDisplayNames($conn['remote_ts_display'] ?? []),
                'local_auth'              => $conn['local_auth'] ?? '',
                'dpd_text'                => $dpdText,
                'status_text'             => ucfirst($statusLower),
                'status_class'            => self::badgeVariant($statusLower),
                'tunnel_ready'            => $tunnelReady,
                'tunnel_class'            => ($statusLower === 'up')
                    ? ($tunnelReady ? 'std-badge--success std-badge--dot' : 'std-badge--warning std-badge--dot')
                    : '',
                'tunnel_text'             => ($statusLower === 'up')
                    ? ($tunnelReady ? 'Tunnel Up' : 'No Tunnel')
                    : '-',
                'initiate_allowed'        => $initiateAllowed,
                'initiate_disabled_title' => $initiateTitle,
                'can_edit'                => $canWrite,
                'can_delete'              => $canDelete,
                'can_up'                  => $canApply,
                'can_down'                => $canApply,
            ];
        }
        return $rows;
    }

    /**
     * Address pools tab rows.
     *
     * @param array<int,array<string,mixed>> $pools
     * @return array<int,array<string,mixed>>
     */
    private static function formatPools(array $pools, bool $canWrite, bool $canDelete): array
    {
        $rows = [];
        foreach ($pools as $pool) {
            if (empty($pool['name'])) {
                continue;
            }
            $rows[] = [
                'id'            => $pool['id'] ?? '',
                'name'          => $pool['name'],
                'addrs'         => $pool['addrs_display']['name'] ?? $pool['addrs'] ?? '',
                'dns'           => $pool['dns_display']['name'] ?? $pool['dns'] ?? '',
                'split_include' => self::renderDisplayNames($pool['split_include_display'] ?? []),
                'online'        => $pool['online'] ?? 0,
                'size'          => $pool['size'] ?? 0,
                'can_edit'      => $canWrite,
                'can_delete'    => $canDelete,
            ];
        }
        return $rows;
    }

    /**
     * Secrets tab rows.
     *
     * Secret type is config-meaningful - no fake default. If the backend
     * did not send the type, the cell will be empty.
     *
     * @param array<int,array<string,mixed>> $secrets
     * @return array<int,array<string,mixed>>
     */
    private static function formatSecrets(array $secrets, bool $canWrite, bool $canDelete): array
    {
        $rows = [];
        foreach ($secrets as $sec) {
            if (empty($sec['id'])) {
                continue;
            }
            $rows[] = [
                'id'        => $sec['id'],
                'label'     => $sec['label'] ?? $sec['id'],
                'type_text' => isset($sec['type']) ? strtoupper($sec['type']) : '',
                'username'  => $sec['username'] ?? '',
                'local_id'  => $sec['local_id'] ?? '',
                'remote_id' => $sec['remote_id'] ?? '',
                'can_edit'  => $canWrite,
                'can_delete'=> $canDelete,
            ];
        }
        return $rows;
    }

    /**
     * Certificates tab rows.
     *
     * @param array<int,array<string,mixed>> $certs
     * @return array<int,array<string,mixed>>
     */
    private static function formatCerts(array $certs): array
    {
        $rows = [];
        foreach ($certs as $cert) {
            $status = $cert['status'] ?? '';
            $statusLower = strtolower($status);

            $rows[] = [
                'name'         => $cert['name'] ?? $cert['subject'] ?? '',
                'type'         => $cert['type'] ?? '',
                'issuer'       => $cert['issuer'] ?? '',
                'expiration'   => $cert['expiration'] ?? '',
                'status_text'  => $status ? ucfirst($statusLower) : '-',
                'status_class' => $status ? self::badgeVariant($statusLower) : '',
                'used_by'      => $cert['used_by'] ?? '-',
            ];
        }
        return $rows;
    }

    /**
     * Status (active SAs) tab rows.
     *
     * @param array<int,array<string,mixed>> $statusList
     * @return array<int,array<string,mixed>>
     */
    private static function formatStatus(array $statusList): array
    {
        $rows = [];
        foreach ($statusList as $sa) {
            $state      = $sa['state'] ?? 'down';
            $stateLower = strtolower($state);

            // Build composite IKE proposal string from individual algo fields
            $encr = $sa['encr-alg'] ?? '';
            if ($encr && !empty($sa['encr-keysize'])) {
                $encr .= $sa['encr-keysize'];
            }
            $integ = $sa['integ-alg'] ?? '';
            $prf   = $sa['prf-alg'] ?? '';
            $dh    = $sa['dh-group'] ?? '';

            $proposalParts = array_filter([$encr, $integ, $prf, $dh]);
            $proposal = !empty($proposalParts) ? implode('-', $proposalParts) : ' - ';

            // Process children (CHILD_SAs)
            $children = [];
            $totalBytesIn  = 0;
            $totalBytesOut = 0;
            foreach (($sa['children'] ?? []) as $child) {
                $childState      = $child['state'] ?? 'down';
                $childStateLower = strtolower($childState);

                $bytesIn  = (int) ($child['bytes-in'] ?? 0);
                $bytesOut = (int) ($child['bytes-out'] ?? 0);
                $totalBytesIn  += $bytesIn;
                $totalBytesOut += $bytesOut;

                $localTs  = $child['local-ts'] ?? [];
                $remoteTs = $child['remote-ts'] ?? [];

                $children[] = [
                    'name'            => $child['name'] ?? '',
                    'uniqueid'        => $child['uniqueid'] ?? '',
                    'state_text'      => ucfirst($childStateLower),
                    'state_class'     => self::badgeVariant($childStateLower),
                    'mode'            => $child['mode'] ?? '',
                    'protocol'        => $child['protocol'] ?? '',
                    'bytes_in'        => $bytesIn,
                    'bytes_out'       => $bytesOut,
                    'bytes_in_fmt'    => self::formatBytes($bytesIn),
                    'bytes_out_fmt'   => self::formatBytes($bytesOut),
                    'packets_in'      => (int) ($child['packets-in'] ?? 0),
                    'packets_out'     => (int) ($child['packets-out'] ?? 0),
                    'local_ts'        => is_array($localTs) ? implode(', ', $localTs) : (string) $localTs,
                    'remote_ts'       => is_array($remoteTs) ? implode(', ', $remoteTs) : (string) $remoteTs,
                    'rekey_time'      => $child['rekey-time'] ?? '',
                    'life_time'       => $child['life-time'] ?? '',
                    'install_time'    => $child['install-time'] ?? '',
                ];
            }

            $rows[] = [
                'name'            => $sa['name'] ?? '',
                'uniqueid'        => $sa['uniqueid'] ?? '',
                'version'         => $sa['version'] ?? '',
                'state_text'      => ucfirst($stateLower),
                'state_class'     => self::badgeVariant($stateLower),
                'local_host'      => $sa['local-host'] ?? '',
                'local_id'        => $sa['local-id'] ?? '',
                'remote_host'     => $sa['remote-host'] ?? '',
                'remote_id'       => $sa['remote-id'] ?? '',
                'proposal'        => $proposal,
                'established'     => $sa['established'] ?? '',
                'rekey_time'      => $sa['rekey-time'] ?? '',
                'children'        => $children,
                'child_count'     => count($children),
                'bytes_in'        => $totalBytesIn,
                'bytes_out'       => $totalBytesOut,
                'bytes_in_fmt'    => self::formatBytes($totalBytesIn),
                'bytes_out_fmt'   => self::formatBytes($totalBytesOut),
                'initiator'       => !empty($sa['initiator']),
            ];
        }
        return $rows;
    }

    /**
     * Format byte count to human-readable string.
     */
    private static function formatBytes(int $bytes): string
    {
        if ($bytes === 0) {
            return '0 B';
        }
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = (int) floor(log($bytes, 1024));
        $i = min($i, count($units) - 1);
        return round($bytes / (1024 ** $i), 1) . ' ' . $units[$i];
    }

    /**
     * Global configuration form values.
     *
     * These values feed form controls. If a field is not set in the
     * backend response, its value is left empty/null so the template can
     * render a "- Select -" prompt rather than silently pre-selecting
     * a wrong default.
     *
     * @param array<string,mixed> $cfg
     * @return array<string,mixed>
     */

    private static function formatGlobalConfig(array $cfg): array
    {
        // Do not silently default config-meaningful values.
        // Missing means missing - the template decides how to render absence.
        $uniqueids            = $cfg['uniqueids'] ?? null;
        $charon_syslog        = $cfg['charon_syslog'] ?? '';
        $fragmentation        = $cfg['fragmentation'] ?? null;
        $install_routes       = $cfg['install_routes'] ?? null;
        $install_virtual_ip   = $cfg['install_virtual_ip'] ?? null;
        $install_virtual_ip_on = $cfg['install_virtual_ip_on'] ?? null;
        $listen_mode          = $cfg['listen_mode'] ?? null;
        $interfaces_use       = $cfg['interfaces_use'] ?? [];

        $threads    = $cfg['threads'] ?? null;
        $port       = $cfg['port'] ?? null;
        $port_nat_t = $cfg['port_nat_t'] ?? null;
        $keep_alive = $cfg['keep_alive'] ?? '';

        // TLS sub-section
        $tls = $cfg['tls'] ?? [];
        $tls_version_min = $tls['version_min'] ?? null;
        $tls_version_max = $tls['version_max'] ?? null;
        $tls_cipher      = $tls['cipher'] ?? null;
        $tls_ke_group    = $tls['ke_group'] ?? null;
        $tls_key_exchange = $tls['key_exchange'] ?? null;
        $tls_mac         = $tls['mac'] ?? null;
        $tls_send_certreq_authorities = $tls['send_certreq_authorities'] ?? null;
        $tls_signature   = $tls['signature'] ?? null;
        $tls_suites      = $tls['suites'] ?? null;

        // X.509 sub-section
        $x509 = $cfg['x509'] ?? [];
        $x509_enforce_critical = $x509['enforce_critical'] ?? null;

        return [
            'uniqueids'              => $uniqueids,
            'charon_syslog'          => $charon_syslog,
            'fragmentation'          => $fragmentation,
            'install_routes'         => $install_routes,
            'install_virtual_ip'     => $install_virtual_ip,
            'install_virtual_ip_on'  => $install_virtual_ip_on,
            'listen_mode'            => $listen_mode,
            'interfaces_use'         => $interfaces_use,
            'threads'                => $threads,
            'port'                   => $port,
            'port_nat_t'             => $port_nat_t,
            'keep_alive'             => $keep_alive,
            'tls_version_min'        => $tls_version_min,
            'tls_version_max'        => $tls_version_max,
            'tls_cipher'             => $tls_cipher,
            'tls_ke_group'           => $tls_ke_group,
            'tls_key_exchange'       => $tls_key_exchange,
            'tls_mac'                => $tls_mac,
            'tls_send_certreq_authorities' => $tls_send_certreq_authorities,
            'tls_signature'          => $tls_signature,
            'tls_suites'             => $tls_suites,
            'x509_enforce_critical'  => $x509_enforce_critical,
        ];
    }

    //
    // Server-rendered <select> option formatters for the connection form
    //

    /**
     * Render display names from _display objects into a comma-joined string.
     *
     * @param array<int,array<string,mixed>> $displayObjs
     * @return string
     */
    private static function renderDisplayNames(array $displayObjs): string
    {
        $names = [];
        foreach ($displayObjs as $d) {
            if (!empty($d['name'])) {
                $names[] = $d['name'];
            }
        }
        return implode(', ', $names);
    }

    /**
     * Interface options for the Local Interface <select>.
     *
     * Interfaces without an IPv4 address are marked as disabled so the
     * operator sees them but cannot select them.
     *
     * @param array<int,array<string,mixed>> $interfaces
     * @return array<int,array<string,mixed>>
     */
    private static function formatInterfaceOptions(array $interfaces): array
    {
        $opts = [];
        foreach ($interfaces as $iface) {
            $name = $iface['name'] ?? '';
            $ip   = $iface['addrs'][0]['values'][0] ?? '';

            if ($ip !== '') {
                $label = $name . ' - ' . $ip;
                $disabled = false;
            } else {
                $label = $name . ' (no IP)';
                $disabled = true;
            }

            $opts[] = [
                'value'    => $iface['id'] ?? '',
                'label'    => $label,
                'disabled' => $disabled,
            ];
        }
        return $opts;
    }

    /**
     * Certificate options for Local/Remote Certificate <select>.
     *
     * @param array<int,array<string,mixed>> $certs
     * @return array<int,array<string,mixed>>
     */
    private static function formatCertOptions(array $certs): array
    {
        $opts = [];
        foreach ($certs as $cert) {
            $name       = $cert['name'] ?? $cert['subject'] ?? '';
            $expiration = $cert['expiration'] ?? '';
            $status     = $cert['status'] ?? '';

            $label = $name;
            if ($expiration !== '') {
                $label .= ' - ' . $expiration;
            }
            if ($status !== '') {
                $label .= ' (' . $status . ')';
            }

            $opts[] = [
                'value' => $cert['id'] ?? '',
                'label' => $label,
            ];
        }
        return $opts;
    }

    /**
     * Pool options for the Pool <select> in the connection form.
     *
     * @param array<int,array<string,mixed>> $pools
     * @return array<int,array<string,mixed>>
     */
    private static function formatPoolOptions(array $pools): array
    {
        $opts = [];
        foreach ($pools as $pool) {
            if (empty($pool['name'])) {
                continue;
            }
            $opts[] = [
                'value' => $pool['name'],
                'label' => $pool['name'],
            ];
        }
        return $opts;
    }

    /**
     * Proposal builder options - static crypto algorithm lists for
     * IKE/ESP proposal <select> dropdowns rendered server-side.
     *
     * @return array<string,string[]>
     */
    private static function formatProposalOptions(): array
    {
        return [
            'encryption' => [
                'aes128', 'aes192', 'aes256',
                'aes128gcm16', 'aes256gcm16',
                'chacha20poly1305',
            ],
            'integrity'  => ['sha256', 'sha384', 'sha512'],
            'dh_groups'  => [
                'modp2048', 'modp3072', 'modp4096',
                'ecp256', 'ecp384', 'ecp521', 'curve25519',
            ],
            'prf'        => ['prfsha256', 'prfsha384', 'prfsha512'],
        ];
    }

    /** Map IKE state to std-badge variant suffix. */
    private static function badgeVariant(string $state): string
    {
        return match (strtolower($state)) {
            'up', 'established', 'installed' => 'std-badge--success std-badge--dot',
            'down'                           => 'std-badge--danger std-badge--dot',
            'connecting', 'created'          => 'std-badge--info std-badge--dot',
            'passive'                        => 'std-badge--muted std-badge--dot',
            'rekeyed', 'rekeying', 'warning' => 'std-badge--warning std-badge--dot',
            default                          => '',
        };
    }
}
