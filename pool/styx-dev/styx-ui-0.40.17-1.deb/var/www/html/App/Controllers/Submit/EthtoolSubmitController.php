<?php
/**
 * Submit controller for ethtool-config mutations (per-physical-interface NIC settings).
 * RBAC: all ethtool-config.* commands require system:admin; the gateway enforces it
 * (FORBIDDEN), the UI gates the panel to admins.
 *
 * NOTE: set_iface_settings_bulk returns `status: partial` (with result.results: [bool])
 * at the COMMAND level when some item fails. BaseController::processGwResp collapses a
 * single non-success command into `status: error`, so mutations bypass it and inspect
 * the command directly (execCommand) to preserve `partial` + per-item results.
 */
namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class EthtoolSubmitController extends BaseController
{
    /**
     * Create/update one or more ethtool settings and apply them live.
     * @param array $data {iface_id, settings:[{family,setting,value}]}
     * @return array
     */
    public function setIfaceSettingsBulk($data)
    {
        $iface_id = $data['iface_id'] ?? '';
        $settings = $data['settings'] ?? [];
        if ($iface_id === '' || !is_array($settings) || empty($settings)) {
            return $this->baseError('iface_id and a non-empty settings list are required');
        }
        foreach ($settings as $i => $item) {
            if (
                !is_array($item)
                || ($item['family'] ?? '') === ''
                || ($item['setting'] ?? '') === ''
                || !array_key_exists('value', $item)
            ) {
                return $this->baseError('Every settings item needs family, setting and value (index ' . $i . ')');
            }
        }
        return $this->execCommand(
            'ethtool-config.set_iface_settings_bulk',
            'set_bulk',
            ['iface_id' => $iface_id, 'settings' => $settings]
        );
    }

    /**
     * Delete one stored setting, restoring the NIC original best-effort.
     * @param array $data {iface_id, family, setting}
     * @return array
     */
    public function deleteIfaceSetting($data)
    {
        $iface_id = $data['iface_id'] ?? '';
        $family = $data['family'] ?? '';
        $setting = $data['setting'] ?? '';
        if ($iface_id === '' || $family === '' || $setting === '') {
            return $this->baseError('iface_id, family and setting are required');
        }
        return $this->execCommand(
            'ethtool-config.delete_iface_setting',
            'del_setting',
            ['iface_id' => $iface_id, 'family' => $family, 'setting' => $setting]
        );
    }

    /**
     * Restore every stored original and empty the settings (keeps the NIC managed).
     * @param array $data {iface_id}
     * @return array
     */
    public function clearIfaceSettings($data)
    {
        return $this->execIface($data, 'ethtool-config.clear_iface_settings', 'clear');
    }

    /**
     * Stop styx from managing ethtool for an interface (keeps stored settings).
     * @param array $data {iface_id}
     * @return array
     */
    public function disableIface($data)
    {
        return $this->execIface($data, 'ethtool-config.disable_iface', 'disable');
    }

    /**
     * Re-enable ethtool management (seeds the profile if never seeded).
     * @param array $data {iface_id}
     * @return array
     */
    public function enableIface($data)
    {
        return $this->execIface($data, 'ethtool-config.enable_iface', 'enable');
    }

    /**
     * Seed the curated default profile, merging only missing keys.
     * @param array $data {iface_id}
     * @return array
     */
    public function applyDefaults($data)
    {
        $iface_id = $data['iface_id'] ?? '';
        if ($iface_id === '') {
            return $this->baseError('iface_id is required');
        }
        $resp = $this->execCommand(
            'ethtool-config.apply_defaults',
            'apply_defaults',
            ['iface_id' => $iface_id]
        );
        // The handler reports error status itself when ok === false; guard anyway.
        if (($resp['status'] ?? '') !== 'error' && is_array($resp['result'] ?? null) && empty($resp['result']['ok'])) {
            $resp = $this->baseError('apply_defaults reported failure');
        }
        return $resp;
    }

    /**
     * Simple iface_id-only mutation (clear/disable/enable).
     * @param array $data
     * @param string $method
     * @param string $id
     * @return array
     */
    private function execIface(array $data, string $method, string $id): array
    {
        $iface_id = $data['iface_id'] ?? '';
        if ($iface_id === '') {
            return $this->baseError('iface_id is required');
        }
        return $this->execCommand($method, $id, ['iface_id' => $iface_id]);
    }

    /**
     * Send a single gateway command and return its command-shape, preserving a
     * command-level `partial` status and its `result.results` array (bypasses the
     * processGwResp collapse for single commands).
     *
     * @param string $method
     * @param string $id
     * @param array $data
     * @return array
     */
    private function execCommand(string $method, string $id, array $data): array
    {
        $raw = $this->sendCommands([['method' => $method, 'id' => $id, 'data' => $data]]);
        if (($raw['status'] ?? '') !== 'success') {
            $resp = $this->baseError($raw['response_msg'] ?? 'Gateway response error');
            if (!empty($raw['error_code'])) {
                $resp['error_code'] = $raw['error_code'];
            }
            return $resp;
        }
        $cmd = $raw['commands'][0] ?? null;
        if (!$cmd || !is_array($cmd)) {
            return $this->baseError('No command in gateway response');
        }
        $errorCode = $cmd['error_code'] ?? null;
        if ($errorCode === self::ERROR_UNAUTHORIZED || $errorCode === self::ERROR_FORBIDDEN) {
            return [
                'status'       => 'error',
                'error_code'   => $errorCode,
                'response_msg' => $errorCode === self::ERROR_UNAUTHORIZED ? 'Session expired' : 'Access denied',
                'warnings'     => [],
            ];
        }
        $status = $cmd['status'] ?? 'error';
        if ($status === 'success' || $status === 'partial') {
            return [
                'status'       => $status,
                'response_msg' => $cmd['response_msg'] ?? '',
                'result'       => $cmd['result'] ?? [],
                'warnings'     => $status === 'partial' ? [($cmd['response_msg'] ?? 'Partial failure')] : [],
            ];
        }
        // Command-level failure: prefer explicit result.msg, then response_msg.
        $msg = '';
        if (is_array($cmd['result'] ?? null)) {
            $msg = $cmd['result']['msg'] ?? $cmd['result']['message'] ?? '';
        }
        if ($msg === '') {
            $msg = $cmd['response_msg'] ?? 'Gateway command failed';
        }
        return $this->baseError($msg);
    }
}
