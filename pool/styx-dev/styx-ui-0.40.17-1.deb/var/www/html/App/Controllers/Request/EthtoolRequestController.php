<?php
/**
 * Controller for ethtool-config reads (per-physical-interface NIC settings).
 * RBAC: all ethtool-config.* commands require system:admin on the gateway;
 * the UI gates the ethtool panel to admins (see PageNetwork + NetIfaceEthtoolFormatter).
 */
namespace App\Controllers\Request;

use App\Controllers\BaseController;

class EthtoolRequestController extends BaseController
{
    /**
     * Get informative ethtool settings report for one interface.
     * Returns the `iface` object (managed/enabled/seeded/profile/families) plus
     * any sync warnings (desired-vs-real) merged into `warnings`.
     *
     * @param string $iface_id
     * @return array{status: string, result: array, warnings: array}
     */
    public function getIfaceSettings(string $iface_id): array
    {
        if ($iface_id === '') {
            return $this->baseError('iface_id is required');
        }
        $commands[] = [
            'method' => 'ethtool-config.get_iface_settings',
            'id'     => 'iface',
            'data'   => ['iface_id' => $iface_id],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] !== 'success') {
            return $resp;
        }
        $cmd = $resp['commands']['iface'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'ethtool get_iface_settings failed');
        }
        $iface = $cmd['result']['iface'] ?? [];
        if (!is_array($iface)) {
            $iface = [];
        }
        // Sync warnings (stored != live / family unreadable / setting gone) are
        // nested inside the iface report; surface them alongside transport warnings.
        $warnings = $resp['warnings'] ?? [];
        $sync = $iface['warnings'] ?? [];
        if (is_array($sync)) {
            $warnings = array_merge($warnings, $sync);
        }
        return [
            'status'   => 'success',
            'result'   => $iface,
            'warnings' => $warnings,
        ];
    }

    /**
     * Get the documented ethtool catalog (metadata only). Not consumed by the
     * editor UI (get_iface_settings already annotates entries with the catalog);
     * registered for API completeness.
     *
     * @param string|null $family Optional family filter (features|ring|coalesce).
     * @return array{status: string, result: array, warnings: array}
     */
    public function getCatalog(?string $family = null): array
    {
        $data = (object)[];
        if ($family !== null && in_array($family, ['features', 'ring', 'coalesce'], true)) {
            $data = ['family' => $family];
        }
        $commands[] = [
            'method' => 'ethtool-config.get_catalog',
            'id'     => 'catalog',
            'data'   => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] !== 'success') {
            return $resp;
        }
        $cmd = $resp['commands']['catalog'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'ethtool get_catalog failed');
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }
}
