// routing-bfd.js
// BFD sessions + profiles management

document.addEventListener('DOMContentLoaded', () => {
    // Profile: toggle form 
    document.querySelectorAll('[data-js="bfd-profile-toggle-form"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const t = document.getElementById(btn.dataset.target);
            if (!t) return;
            if (t.style.display === 'none') {
                // Opening via "+ Add" button
                resetProfileForm();
                t.style.display = 'block';
                btn.style.display = 'none';
            } else {
                // Closing via Cancel or toggling off
                resetProfileForm();
                t.style.display = 'none';
                const ab = document.querySelector(
                    '[data-js="bfd-profile-toggle-form"][data-target="' + btn.dataset.target + '"]');
                if (ab) ab.style.display = '';
            }
        });
    });

    function resetProfileForm() {
        document.getElementById('bfd_profile_id').value = '';
        document.getElementById('bfd_profile_name').value = '';
        document.getElementById('bfd_profile_detect_mult').value = '3';
        document.getElementById('bfd_profile_rx').value = '300';
        document.getElementById('bfd_profile_tx').value = '300';
        document.getElementById('bfd_profile_echo').checked = false;
        document.getElementById('bfd_profile_echo_rx').value = '';
        document.getElementById('bfd_profile_echo_tx').value = '';
        document.getElementById('bfd_profile_passive').checked = false;
        document.getElementById('bfd_profile_min_ttl').value = '';
        document.getElementById('bfd-profile-form-title').textContent = 'Add BFD Profile';
    }

    // Profile: edit 
    document.querySelectorAll('.js-bfd-profile-edit').forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('bfd_profile_id').value = btn.dataset.id;
            document.getElementById('bfd_profile_name').value = btn.dataset.name;
            document.getElementById('bfd_profile_detect_mult').value = btn.dataset.detectMult;
            document.getElementById('bfd_profile_rx').value = btn.dataset.rx;
            document.getElementById('bfd_profile_tx').value = btn.dataset.tx;
            document.getElementById('bfd_profile_echo').checked = (btn.dataset.echo === '1');
            document.getElementById('bfd_profile_echo_rx').value = btn.dataset.echoRx;
            document.getElementById('bfd_profile_echo_tx').value = btn.dataset.echoTx;
            document.getElementById('bfd_profile_passive').checked = (btn.dataset.passive === '1');
            document.getElementById('bfd_profile_min_ttl').value = btn.dataset.minTtl;
            document.getElementById('bfd-profile-form-title').textContent = 'Edit BFD Profile';
            const f = document.getElementById('bfd-profile-add-form');
            f.style.display = 'block';
            const ab = document.querySelector(
                '[data-js="bfd-profile-toggle-form"][data-target="bfd-profile-add-form"]');
            if (ab) ab.style.display = 'none';
        });
    });

    // Profile: save 
    const saveBtn = document.querySelector('[data-js="bfd-profile-save"]');
    if (saveBtn) {
        saveBtn.addEventListener('click', async () => {
            const id = document.getElementById('bfd_profile_id').value.trim();
            const name = document.getElementById('bfd_profile_name').value.trim();
            if (!name) {
                showModal('<p>Name is required.</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }
            const echoRx = document.getElementById('bfd_profile_echo_rx').value.trim();
            const echoTx = document.getElementById('bfd_profile_echo_tx').value.trim();
            const minTtl = document.getElementById('bfd_profile_min_ttl').value.trim();
            const data = {
                name: name,
                detect_multiplier: parseInt(document.getElementById('bfd_profile_detect_mult').value, 10) || 3,
                receive_interval: parseInt(document.getElementById('bfd_profile_rx').value, 10) || 300,
                transmit_interval: parseInt(document.getElementById('bfd_profile_tx').value, 10) || 300,
                echo_mode: document.getElementById('bfd_profile_echo').checked,
                echo_receive_interval: echoRx ? parseInt(echoRx, 10) : null,
                echo_transmit_interval: echoTx ? parseInt(echoTx, 10) : null,
                passive_mode: document.getElementById('bfd_profile_passive').checked,
                minimum_ttl: minTtl ? parseInt(minTtl, 10) : null,
            };
            if (id) data.id = id;
            const cmd = id ? 'routing_update_bfd_profile' : 'routing_add_bfd_profile';
            const title = id ? 'Update BFD Profile' : 'Add BFD Profile';
            try {
                const r = await apiClient.submit(cmd, data);
                showApiResult(r, { title: title, closeText: 'Close', reloadOnOk: true });
            } catch (e) {
                showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Profile: delete 
    document.querySelectorAll('[data-js="bfd-profile-delete"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this BFD profile?', {
                title: 'Confirm Delete', closeText: 'Cancel',
                showConfirm: true, confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const r = await apiClient.submit('routing_delete_bfd_profile', { id });
                        showApiResult(r, { title: 'Delete Profile', closeText: 'Close', reloadOnOk: true });
                    } catch (e) {
                        showApiResult({ status: 'error', response_msg: e.message },
                            { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });

    // Sessions (read-only) 
    async function loadBfdSessions() {
        try {
            const result = await apiClient.request('routing_get_bfd', {});
            if (result.status !== 'success') {
                return;
            }
            renderSessions(result.result.sessions ?? []);
        } catch (err) {
            // Silently ignore-sessions are auxiliary
        }
    }

    function renderSessions(sessions) {
        const tbody = document.getElementById('bfd-sessions-tbody');
        if (!tbody) return;
        if (sessions.length === 0) {
            tbody.innerHTML = '<tr class="std-table-empty"><td colspan="8">No active BFD sessions.</td></tr>';
            return;
        }
        tbody.innerHTML = '';
        sessions.forEach(s => {
            const badgeClass = s.status === 'up' ? 'std-badge--success std-badge--dot' : 'std-badge--muted std-badge--dot';
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${s.peer}</td>
                <td>${s.local ?? '-'}</td>
                <td>${s.interface ?? '-'}</td>
                <td><span class="std-badge ${badgeClass}">${s.status}</span></td>
                <td>${s.tx_interval ?? 0}</td>
                <td>${s.rx_interval ?? 0}</td>
                <td>${s.multiplier ?? 0}</td>
                <td>${s.uptime ?? '-'}</td>
            `;
            tbody.appendChild(tr);
        });
    }

    loadBfdSessions();
});
