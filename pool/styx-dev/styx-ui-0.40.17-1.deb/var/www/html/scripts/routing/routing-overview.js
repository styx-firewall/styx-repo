// routing-overview.js
// Routing overview: system stats + FRR/IGMP daemons (read-only, polling)

document.addEventListener('DOMContentLoaded', () => {
    const POLL_INTERVAL_MS = 10000;
    let _isLoading = false;

    const DAEMON_LABELS = {
        'bgpd':      'BGP daemon',
        'ospfd':     'OSPF daemon',
        'ripd':      'RIP daemon',
        'bfdd':      'BFD daemon',
        'igmpproxy': 'IGMP Proxy'
    };

    function normalizeDaemonLabel(d) {
        if (!d || typeof d.name !== 'string') return '';
        if (DAEMON_LABELS[d.name]) return DAEMON_LABELS[d.name];
        return d.name.charAt(0).toUpperCase() + d.name.slice(1);
    }

    function renderDaemonRow(daemon) {
        const tr = document.createElement('tr');
        const labelCell = document.createElement('td');
        labelCell.textContent = normalizeDaemonLabel(daemon);
        const statusCell = document.createElement('td');
        const span = document.createElement('span');
        const isRunning = daemon.status === 'running';
        span.className = 'std-badge ' + (isRunning ? 'std-badge--success std-badge--dot' : 'std-badge--danger std-badge--dot');
        span.appendChild(document.createTextNode(daemon.status || ''));
        statusCell.appendChild(span);
        tr.appendChild(labelCell);
        tr.appendChild(statusCell);
        return tr;
    }

    function renderDaemons(daemons) {
        const tbody = document.querySelector('#routing-daemons-table tbody');
        if (!tbody) return;
        tbody.innerHTML = '';
        daemons.forEach(d => tbody.appendChild(renderDaemonRow(d)));
    }

    function renderIgmpDaemon(daemon) {
        const tbody = document.querySelector('#routing-igmp-table tbody');
        if (!tbody || !daemon) return;
        tbody.innerHTML = '';
        tbody.appendChild(renderDaemonRow(daemon));
    }

    function renderFrrSummary(frrRoutes) {
        const keys = ['bgp', 'ospf', 'rip'];
        ['ipv4', 'ipv6'].forEach(family => {
            keys.forEach(proto => {
                const el = document.getElementById('frr-' + proto + '-' + family);
                if (el) el.textContent = frrRoutes?.[family]?.[proto] ?? 0;
            });
        });
    }

    function updateStatCards(routeSummary, numTables, numPolicyRules) {
        const cards = document.querySelectorAll('.overview-stat-card');
        if (cards.length < 4) return;
        cards[0].querySelector('.overview-stat-value').textContent = routeSummary?.ipv4?.total ?? 0;
        cards[1].querySelector('.overview-stat-value').textContent = routeSummary?.ipv6?.total ?? 0;
        cards[2].querySelector('.overview-stat-value').textContent = numTables ?? 0;
        cards[3].querySelector('.overview-stat-value').textContent = numPolicyRules ?? 0;
    }

    function updateDefaultGateways(gw4, gw6) {
        const row = document.querySelector('.overview-inline-row');
        if (!row) return;
        const values = row.querySelectorAll('.overview-inline-value');
        if (values.length >= 2) {
            values[0].textContent = gw4 || '-';
            values[1].textContent = gw6 || '-';
        }
    }

    async function loadOverview() {
        if (_isLoading) return;
        _isLoading = true;
        try {
            const result = await apiClient.request('routing_get_overview', {});
            if (result.status !== 'success') {
                appLog.warn('routing-overview: failed to load overview', result);
                return;
            }
            const r = result.result;
            updateStatCards(r.route_summary, r.num_tables, r.num_policy_rules);
            updateDefaultGateways(r.default_gateway_v4, r.default_gateway_v6);

            if (r.frr?.enabled) {
                renderDaemons(r.frr.daemons ?? []);
                renderFrrSummary(r.frr_routes ?? {});
            }
            if (r.igmp_proxy?.enabled) {
                renderIgmpDaemon(r.igmp_proxy.daemon);
            }
        } catch (err) {
            appLog.warn('routing-overview: error', err);
        } finally {
            _isLoading = false;
        }
    }

    // Server renders initial state; poll for live updates only
    setInterval(loadOverview, POLL_INTERVAL_MS);
});
