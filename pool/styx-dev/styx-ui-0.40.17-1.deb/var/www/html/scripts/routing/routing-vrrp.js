// routing-vrrp.js
// VRRPv3-toggle + add/edit/submit + delete

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }

    // Carrier macvlans the instance selector offers (from the formatter). A VRRP
    // instance references a carrier (bridge macvlan with frr_vrrp_vrid) and runs
    // on its base (parent) interface.
    const carriers = Array.isArray(window.__vrrpCarriers) ? window.__vrrpCarriers : [];
    function findCarrier(id) {
        for (let i = 0; i < carriers.length; i++) {
            if (carriers[i].id === id) return carriers[i];
        }
        return null;
    }
    function carrierFamilyLabel(fam) { return fam === 'ip6' ? 'IPv6' : 'IPv4'; }
    // True when a carrier with the given family exists under the same base and
    // VRID as the anchor carrier (required for dual-stack VIPs).
    function hasCarrierForFamily(anchor, family) {
        if (!anchor) return false;
        for (let i = 0; i < carriers.length; i++) {
            const c = carriers[i];
            if (c.frr_vrrp_vrid !== anchor.frr_vrrp_vrid) continue;
            if (c.frr_vrrp_family !== family) continue;
            if (anchor.base_id && c.base_id === anchor.base_id) return true;
            if (!anchor.base_id && anchor.base_name && c.base_name === anchor.base_name) return true;
        }
        return false;
    }
    function escapeHtml(s) {
        return String(s).replace(/[&<>"']/g,
            (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }
    // Enable/disable each VIP family picker according to whether a carrier of that
    // family exists under the selected base + VRID (dual-stack needs one `ip` and
    // one `ip6` carrier). With no carrier selected both stay enabled; a picker
    // that becomes unavailable is cleared so a stale set is never submitted.
    function applyVipPickerAvailability(hiddenId, family, carrier) {
        const hidden = document.getElementById(hiddenId);
        if (!hidden) return;
        const field = hidden.closest('.set-picker-field');
        if (!field) return;
        const available = carrier ? hasCarrierForFamily(carrier, family) : true;
        field.querySelectorAll('button').forEach(b => { b.disabled = !available; });
        if (!available && hidden.value) resetSetPicker(hiddenId);
    }
    function updateVipPickers() {
        const sel = document.getElementById('vrrp_interface');
        const carrier = findCarrier(sel ? sel.value : '');
        applyVipPickerAvailability('vrrp_ip_addresses_set', 'ip', carrier);
        applyVipPickerAvailability('vrrp_ipv6_addresses_set', 'ip6', carrier);
    }
    // When a carrier is picked, lock the instance VRID to the carrier's
    // frr_vrrp_vrid (the backend requires them to match) and describe where VRRP
    // actually runs (base) plus the carrier's family / VMAC. If the opposite
    // family's carrier is missing under the same base+VRID its picker is disabled
    // and the note below explains how to enable it (dual-stack).
    function updateCarrierField() {
        const sel = document.getElementById('vrrp_interface');
        const vridInput = document.getElementById('vrrp_vrid');
        const info = document.getElementById('vrrp_carrier_info');
        if (!sel) return;
        const carrier = findCarrier(sel.value);
        if (vridInput) vridInput.value = carrier ? String(carrier.frr_vrrp_vrid) : '';
        updateVipPickers();
        if (!info) return;
        if (!carrier) {
            info.innerHTML = '';
            return;
        }
        const base = carrier.base_name || '(unknown base)';
        let html = 'VRRP runs on ' + escapeHtml(base)
            + ' · ' + carrierFamilyLabel(carrier.frr_vrrp_family)
            + ' · VMAC ' + escapeHtml(carrier.mac || 'auto');
        if (!carrier.base_name) html += ' <span class="text-dim">— carrier has no resolvable base interface</span>';
        const notes = [];
        if (!hasCarrierForFamily(carrier, 'ip')) {
            notes.push("IPv4 VIPs (dual-stack) require a carrier 'ip' under " + escapeHtml(base) + ' (VRID ' + carrier.frr_vrrp_vrid + ') — create it with frr_vrrp_family \'ip\' first');
        }
        if (!hasCarrierForFamily(carrier, 'ip6')) {
            notes.push("IPv6 VIPs (dual-stack) require a carrier 'ip6' under " + escapeHtml(base) + ' (VRID ' + carrier.frr_vrrp_vrid + ') — create it with frr_vrrp_family \'ip6\' first');
        }
        if (notes.length) {
            html += '<br><span class="text-dim">' + notes.join('<br>') + '</span>';
        }
        info.innerHTML = html;
    }
    const vrrpIfaceSelect = document.getElementById('vrrp_interface');
    if (vrrpIfaceSelect) vrrpIfaceSelect.addEventListener('change', updateCarrierField);

    // Save config
    const saveCfg = document.querySelector('[data-js="vrrp-save-config"]');
    if (saveCfg) {
        saveCfg.addEventListener('click', async () => {
            try {
                const r = await apiClient.submit('routing_save_vrrp_config', {
                    enabled: document.getElementById('vrrp_enabled').checked,
                    global_defaults: {
                        priority: parseInt(document.getElementById('vrrp_def_priority').value, 10) || 100,
                        advertisement_interval: parseInt(document.getElementById('vrrp_def_adv_interval').value, 10) || 1000,
                        preempt: document.getElementById('vrrp_def_preempt').checked,
                        shutdown: document.getElementById('vrrp_def_shutdown').checked,
                        checksum_with_ipv4_pseudoheader: document.getElementById('vrrp_def_checksum').checked,
                    },
                });
                showApiResult(r, { title: 'VRRP Config', closeText: 'Close', reloadOnOk: true });
            } catch (e) {
                showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Toggle form 
    document.querySelectorAll('[data-js="vrrp-toggle-form"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const t = document.getElementById(btn.dataset.target);
            if (!t) return;
            if (t.style.display === 'none') {
                // Opening via "+ Add" button
                resetForm();
                t.style.display = 'block';
                btn.style.display = 'none';
            } else {
                // Closing via Cancel or toggling off
                resetForm();
                t.style.display = 'none';
                const ab = document.querySelector('[data-js="vrrp-toggle-form"][data-target="' + btn.dataset.target + '"]');
                if (ab) ab.style.display = '';
            }
        });
    });

    function resetSetPicker(hiddenId) {
        const hidden = document.getElementById(hiddenId);
        if (!hidden) return;
        hidden.value = '';
        const field = hidden.closest('.set-picker-field');
        if (!field) return;
        const label = field.querySelector('.js-set-picker-label');
        const clearBtn = field.querySelector('.js-set-picker-clear');
        const trigger = field.querySelector('.js-set-picker-open');
        if (label && trigger) {
            label.textContent = trigger.dataset.placeholder || 'Select address set';
        }
        if (clearBtn) clearBtn.classList.add('sets-hidden');
    }

    function populateSetPicker(hiddenId, uuid, displayName) {
        const hidden = document.getElementById(hiddenId);
        if (!hidden) return;
        hidden.value = uuid || '';
        const field = hidden.closest('.set-picker-field');
        if (!field) return;
        const label = field.querySelector('.js-set-picker-label');
        const clearBtn = field.querySelector('.js-set-picker-clear');
        const trigger = field.querySelector('.js-set-picker-open');
        if (label) {
            label.textContent = displayName || (trigger && trigger.dataset.placeholder) || 'Select address set';
        }
        if (clearBtn) {
            if (uuid) { clearBtn.classList.remove('sets-hidden'); }
            else { clearBtn.classList.add('sets-hidden'); }
        }
    }

    function resetForm() {
        const ifaceEl = document.getElementById('vrrp_interface');
        if (!ifaceEl) return; // no carrier selector rendered (no carriers)
        const d = window.__vrrpDefaults || {};
        document.getElementById('vrrp_id').value = '';
        ifaceEl.value = '';
        document.getElementById('vrrp_vrid').value = '';
        document.getElementById('vrrp_priority').value = (d.priority !== undefined) ? d.priority : '';
        document.getElementById('vrrp_adv_interval').value = (d.advertisement_interval !== undefined) ? d.advertisement_interval : '';
        document.getElementById('vrrp_preempt').checked = (d.preempt !== undefined) ? !!d.preempt : true;
        document.getElementById('vrrp_shutdown').checked = (d.shutdown !== undefined) ? !!d.shutdown : false;
        document.getElementById('vrrp_checksum').checked = (d.checksum_with_ipv4_pseudoheader !== undefined) ? !!d.checksum_with_ipv4_pseudoheader : true;
        resetSetPicker('vrrp_ip_addresses_set');
        resetSetPicker('vrrp_ipv6_addresses_set');
        document.getElementById('vrrp-form-title').textContent = 'Add VRRP Instance';
        updateCarrierField();
    }

    // Edit 
    document.querySelectorAll('.js-vrrp-edit').forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('vrrp_id').value = btn.dataset.id;
            document.getElementById('vrrp_interface').value = btn.dataset.interface;
            document.getElementById('vrrp_vrid').value = btn.dataset.vrid;
            document.getElementById('vrrp_priority').value = btn.dataset.priority;
            document.getElementById('vrrp_adv_interval').value = btn.dataset.advInterval;
            document.getElementById('vrrp_preempt').checked = (btn.dataset.preempt === '1');
            document.getElementById('vrrp_shutdown').checked = (btn.dataset.shutdown === '1');
            document.getElementById('vrrp_checksum').checked = (btn.dataset.checksum === '1');
            populateSetPicker('vrrp_ip_addresses_set', btn.dataset.ipAddressesSet, btn.dataset.ipAddressesSetDisplay);
            populateSetPicker('vrrp_ipv6_addresses_set', btn.dataset.ipv6AddressesSet, btn.dataset.ipv6AddressesSetDisplay);
            document.getElementById('vrrp-form-title').textContent = 'Edit VRRP Instance';
            updateCarrierField();
            const f = document.getElementById('vrrp-add-form');
            f.style.display = 'block';
            const ab = document.querySelector('[data-js="vrrp-toggle-form"][data-target="vrrp-add-form"]');
            if (ab) ab.style.display = 'none';
        });
    });

    // Save instance 
    const saveInst = document.querySelector('[data-js="vrrp-instance-save"]');
    if (saveInst) {
        saveInst.addEventListener('click', async () => {
            const id = document.getElementById('vrrp_id').value.trim();
            const iface = document.getElementById('vrrp_interface').value.trim();
            const vrid = parseInt(document.getElementById('vrrp_vrid').value, 10);
            if (!iface) { showModal('<p>A carrier interface is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }
            const carrier = findCarrier(iface);
            if (!carrier) {
                showModal('<p>VRRP interface not found in config_interfaces.</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }
            if (!vrid || vrid < 1 || vrid > 255) { showModal('<p>VRID must be between 1 and 255.</p>', { title: 'Validation', closeText: 'Close' }); return; }
            // The instance VRID must equal the carrier's frr_vrrp_vrid.
            if (vrid !== carrier.frr_vrrp_vrid) {
                showModal('<p>VRRP carrier \'' + escapeHtml(carrier.interface || iface) + '\' is for VRID ' + carrier.frr_vrrp_vrid + ', not ' + vrid + '</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }
            if (!carrier.base_name) {
                showModal('<p>VRRP carrier has no resolvable base interface (parent_iface).</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }

            const ipSet = document.getElementById('vrrp_ip_addresses_set').value.trim();
            const ipv6Set = document.getElementById('vrrp_ipv6_addresses_set').value.trim();

            if (!ipSet && !ipv6Set) { showModal('<p>At least one address set (IPv4 or IPv6) is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }

            // Family placement: for each address family with VIPs there must be a
            // carrier of that family under the same base and VRID (dual-stack).
            const baseLabel = escapeHtml(carrier.base_name);
            if (ipSet && !hasCarrierForFamily(carrier, 'ip')) {
                showModal('<p>No VRRP carrier for family \'ip\' (VRID ' + vrid + ') under base \'' + baseLabel + '\': create the matching carrier macvlan (frr_vrrp_family \'ip\') on that base</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }
            if (ipv6Set && !hasCarrierForFamily(carrier, 'ip6')) {
                showModal('<p>No VRRP carrier for family \'ip6\' (VRID ' + vrid + ') under base \'' + baseLabel + '\': create the matching carrier macvlan (frr_vrrp_family \'ip6\') on that base</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }

            const data = {
                interface: iface,
                vrid: vrid,
                priority: parseInt(document.getElementById('vrrp_priority').value, 10) || undefined,
                advertisement_interval: parseInt(document.getElementById('vrrp_adv_interval').value, 10) || undefined,
                preempt: document.getElementById('vrrp_preempt').checked,
                shutdown: document.getElementById('vrrp_shutdown').checked,
                checksum_with_ipv4_pseudoheader: document.getElementById('vrrp_checksum').checked,
                ip_addresses_set: ipSet || undefined,
                ipv6_addresses_set: ipv6Set || undefined,
            };
            // Remove undefined keys for partial update
            if (id) { data.id = id; Object.keys(data).forEach(k => { if (data[k] === undefined) delete data[k]; }); }

            const cmd = id ? 'routing_update_vrrp_instance' : 'routing_add_vrrp_instance';
            const title = id ? 'Update VRRP Instance' : 'Add VRRP Instance';
            try {
                const r = await apiClient.submit(cmd, data);
                showApiResult(r, { title: title, closeText: 'Close', reloadOnOk: true });
            } catch (e) {
                showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Delete
    document.querySelectorAll('[data-js="vrrp-delete"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this VRRP instance?', {
                title: 'Confirm Delete', closeText: 'Cancel',
                showConfirm: true, confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const r = await apiClient.submit('routing_delete_vrrp_instance', { id });
                        showApiResult(r, { title: 'Delete Instance', closeText: 'Close', reloadOnOk: true });
                    } catch (e) {
                        showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });

    // Instance details: show the live vrrpd status (full real object)
    document.querySelectorAll('[data-js="vrrp-details"]').forEach(btn => {
        btn.addEventListener('click', () => {
            let status;
            try {
                status = JSON.parse(btn.dataset.detail || 'null');
            } catch (e) {
                status = null;
            }
            const detail = status && typeof status === 'object' ? (status.status || status) : null;
            if (!detail || typeof detail !== 'object' || Array.isArray(detail)) {
                showModal('<p>No runtime status available for this instance.</p>',
                    { title: 'VRRP Instance Details', closeText: 'Close' });
                return;
            }
            const esc = (s) => String(s).replace(/[&<>"']/g,
                (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
            const rows = Object.entries(detail)
                .map(([k, v]) => {
                    const val = (v === null || v === undefined) ? '-' :
                        (typeof v === 'object' ? JSON.stringify(v) : v);
                    return '<tr><td><strong>' + esc(k) + '</strong></td><td>' + esc(val) + '</td></tr>';
                })
                .join('');
            showModal('<table class="std-table"><tbody>' + rows + '</tbody></table>',
                { title: 'VRRP Instance Details', closeText: 'Close' });
        });
    });
});
