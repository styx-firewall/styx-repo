// iPerf3 UI - Async server/client management

let serverPollingInterval = null;
let activeTaskPollers = new Map();
// Track which task results we've already rendered to avoid duplicates
let renderedTaskResults = new Set();
// Pending chart creators per result suffix (deferred when panel is collapsed)
let pendingChartCreators = new Map();
// Timer for the auto-dismissing iperf-response-msg alert
let iperfMessageTimer = null;

// Helpers: provide safe fallbacks for response parsing and error message building
function parseHandlerResponse(resp) {
    if (!resp) return null;
    try {
        // If response is a JSON string, parse it
        if (typeof resp === 'string') {
            resp = JSON.parse(resp);
        }

        // If server returned an array of responses, pick the first
        if (Array.isArray(resp) && resp.length > 0) {
            resp = resp[0];
        }

        // If nested under a `response` or `result` envelope, normalize
        if (resp.response && typeof resp.response === 'object') {
            return resp.response;
        }

        return resp;
    } catch (e) {
        console.error('Failed to parse handler response:', e, resp);
        return null;
    }
}

function buildHandlerErrorMessage(r) {
    if (!r) return 'Unknown error';
    if (r.response_msg) return r.response_msg;
    if (r.message) return r.message;
    if (r.error) return typeof r.error === 'string' ? r.error : JSON.stringify(r.error);
    if (r.result && r.result.msg) return r.result.msg;
    return 'Handler error: ' + (typeof r === 'string' ? r : JSON.stringify(r).slice(0, 200));
}

// UI message helper for this page.
// The alert is anchored to the section that triggered it (anchorEl), so it shows
// in context (e.g. under the Client form heading) instead of at the top of the
// page. Without an anchor it falls back to just under the page heading.
function showIperfMessage(msg, isError = false, timeout = 4000, anchorEl = null) {
    try {
        // Resolve where the alert belongs: inside the triggering content-box,
        // right after its heading.
        let host = null;
        let refNode = null;
        let section = null;
        if (anchorEl && typeof anchorEl.closest === 'function') {
            section = anchorEl.closest('section.content-box');
        }
        if (section) {
            host = section;
            const heading = section.querySelector(':scope > h1, :scope > h2, :scope > h3');
            refNode = heading ? heading.nextSibling : section.firstChild;
        } else {
            // Fallback: inside the page content, under its heading (never above it)
            host = document.querySelector('main.page-content') || document.body;
            const heading = host.querySelector(':scope > h1, :scope > h2');
            refNode = heading ? heading.nextSibling : host.firstChild;
        }

        let el = document.getElementById('iperf-response-msg');
        if (!el) {
            el = document.createElement('div');
            el.id = 'iperf-response-msg';
        }
        const cls = isError ? 'page-alert alert-error' : 'page-alert alert-info';
        el.className = cls;
        el.textContent = String(msg);

        // Move it into the right host (re-insert once; keep position on repeats)
        if (el.parentNode !== host) {
            if (el.parentNode) el.parentNode.removeChild(el);
            host.insertBefore(el, refNode);
        }

        if (iperfMessageTimer) {
            clearTimeout(iperfMessageTimer);
            iperfMessageTimer = null;
        }
        if (timeout && timeout > 0) {
            iperfMessageTimer = setTimeout(() => {
                if (el && el.parentNode) el.parentNode.removeChild(el);
                iperfMessageTimer = null;
            }, timeout);
        }
    } catch (e) {
        console.error('showIperfMessage error:', e, msg);
    }
}

// Collect form fields into a plain object (skips empty strings, handles checkboxes)
function collectFormData(form) {
    var data = {};
    new FormData(form).forEach(function (value, key) {
        var input = form.querySelector('[name="' + key + '"]');
        if (input && input.type === 'checkbox') {
            data[key] = input.checked;
        } else if (value.trim() !== '') {
            data[key] = value;
        }
    });
    return data;
}

// Parse API response and dispatch success/error uniformly.
// Calls onSuccess(r) when r.status === 'success', shows error otherwise.
// contextEl anchors the alert to the section that triggered the request.
function handleSubmitResponse(resp, onSuccess, contextEl) {
    var r = parseHandlerResponse(resp);
    if (!r) {
        showIperfMessage('Invalid response from server', true, 4000, contextEl);
        return;
    }
    if (r.status === 'success') {
        onSuccess(r);
    } else {
        showIperfMessage(buildHandlerErrorMessage(r), true, 4000, contextEl);
    }
}

// Update server status UI
// Markup lives in the <template> blocks in net-perf.tpl.php; values are
// assigned via textContent, so there is no escaping/HTML-injection concern.
function updateServerStatus(status) {
    const running = status?.running ?? false;
    const pid = status?.pid ?? null;
    const port = status?.port ?? null;
    const started_at = status?.started_at ?? null;

    const indicator = document.querySelector('#server-status .status-indicator');

    if (indicator) {
        const tpl = document.getElementById(running ? 'iperf-server-status-running' : 'iperf-server-status-stopped');
        if (tpl) {
            const frag = tpl.content.cloneNode(true);
            if (running) {
                const fill = (sel, val) => {
                    const el = frag.querySelector(sel);
                    if (el) el.textContent = val ?? '';
                };
                fill('.status-pid', pid);
                fill('.status-port', port);
                fill('.status-started', started_at);
            }
            indicator.replaceChildren(frag);
        }
    }

    const btnStart = document.getElementById('btn-start-server');
    const btnStop = document.getElementById('btn-stop-server');
    if (btnStart) btnStart.disabled = running;
    if (btnStop) btnStop.disabled = !running;
}

// Poll server status
function pollServerStatus() {
    // Combined status+tasks request
    const statusPanel = document.querySelector('#server-status');
    apiClient.request('iperf_status_and_tasks', {})
        .then(resp => {
            const r = parseHandlerResponse(resp);
            if (!r) {
                showIperfMessage('Invalid response from server', true, 5000, statusPanel);
                return;
            }
            if (r.status === 'success') {
                const server = r.result?.server_status || {};
                const tasks = r.result?.tasks || [];
                updateServerStatus(server);
                updateTasksList(tasks);
            } else {
                showIperfMessage(buildHandlerErrorMessage(r), true, 5000, statusPanel);
            }
        })
        .catch(err => {
            console.error('Failed to poll status and tasks:', err);
            showIperfMessage('Error polling status/tasks: ' + (err.message || err), true, 5000, statusPanel);
        });
}

// Start server polling (every 5 seconds)
function startServerPolling() {
    if (serverPollingInterval) return;
    pollServerStatus();
    // Use 3s for combined status+tasks polling
    serverPollingInterval = setInterval(pollServerStatus, 3000);
}

// Start iperf server
function startServer() {
    var form = document.querySelector('[data-js="server-form"]');
    if (!form) return;
    var data = collectFormData(form);

    apiClient.submit('iperf_start_server', data)
        .then(function (resp) {
            console.debug('iperf_start_server raw response:', resp);
            var r = parseHandlerResponse(resp);
            console.debug('iperf_start_server parsed response:', r);
            handleSubmitResponse(resp, function (r) {
                appLog.info('Server started successfully');
                showIperfMessage(r.response_msg || 'Server started', false, 4000, form);
                updateServerStatus(r.result || {});
                if (r.result && r.result.stderr_head) {
                    appLog.info('Server diagnostics: ' + r.result.stderr_head);
                }
            }, form);
        })
        .catch(function (err) {
            appLog.error('Error starting server: ' + err.message);
            showIperfMessage('Error starting server: ' + (err.message || err), true, 4000, form);
        });
}

// Stop iperf server
function stopServer() {
    const form = document.querySelector('[data-js="server-form"]');
    apiClient.submit('iperf_stop_server', {})
        .then(function (resp) {
            handleSubmitResponse(resp, function (r) {
                appLog.info('Server stopped successfully');
                showIperfMessage(r.response_msg || 'Server stopped', false, 4000, form);
                pollServerStatus();
            }, form);
        })
        .catch(function (err) {
            appLog.error('Error stopping server: ' + err.message);
            showIperfMessage('Error stopping server: ' + (err.message || err), true, 4000, form);
        });
}

// Start client test
function startClientTest() {
    var form = document.querySelector('[data-js="client-form"]');
    if (!form) return;

    var data = collectFormData(form);

    if (!data.server_ip || data.server_ip.trim() === '') {
        appLog.warn('Server IP is required');
        return;
    }

    appLog.info('Starting client test...');

    apiClient.submit('iperf_start_client_test', data)
        .then(function (resp) {
            handleSubmitResponse(resp, function (r) {
                if (r.result && r.result.task_id) {
                    var taskId = r.result.task_id;
                    appLog.info('Client test started, task ID: ' + taskId);
                    showIperfMessage(r.response_msg || 'Client test started', false, 4000, form);
                    startTaskPolling(taskId);
                } else {
                    showIperfMessage(r.response_msg || 'Client test started', false, 4000, form);
                }
            }, form);
        })
        .catch(function (err) {
            appLog.error('Error starting client test: ' + err.message);
            showIperfMessage('Error starting client test: ' + (err.message || err), true, 4000, form);
        });
}

// Poll a specific task result
function startTaskPolling(taskId) {
    if (activeTaskPollers.has(taskId)) return;

    const pollTaskResult = () => {
        apiClient.request('iperf_get_task_result', { task_id: taskId })
            .then(resp => {
                if (resp.status === 'success' && resp.result) {
                    const taskData = resp.result;
                    // Accept different gateway shapes: `state` or `status` (e.g. 'done')
                    let state = taskData.state || taskData.status || 'unknown';
                    if (state === 'done') state = 'completed';

                    if (state === 'completed' || state === 'error' || state === 'failed') {
                        clearInterval(activeTaskPollers.get(taskId));
                        activeTaskPollers.delete(taskId);

                        if (state === 'completed') {
                            // Extract actual test result from possible nested envelopes
                            let resultPayload = null;
                            if (taskData.result) {
                                // gateway may return { result: { ok: true, data: { ... } } }
                                if (taskData.result.data) {
                                    resultPayload = taskData.result.data;
                                } else if (taskData.result.result) {
                                    resultPayload = taskData.result.result;
                                } else {
                                    resultPayload = taskData.result;
                                }
                            } else if (taskData.result_data) {
                                resultPayload = taskData.result_data;
                            } else {
                                resultPayload = taskData;
                            }

                            if (resultPayload) renderIperfResult(resultPayload, { taskId });
                        } else {
                            appLog.error('Task failed: ' + (taskData.error || taskData.response_msg || 'Unknown error'));
                        }
                    }
                }
            })
            .catch(err => {
                console.error('Error polling task result:', err);
                clearInterval(activeTaskPollers.get(taskId));
                activeTaskPollers.delete(taskId);
            });
    };

    pollTaskResult();
    const intervalId = setInterval(pollTaskResult, 2000);
    activeTaskPollers.set(taskId, intervalId);
}

// Update tasks list UI
// Items are cloned from the #iperf-task-item <template> (net-perf.tpl.php)
// and filled via textContent, so there is no string-built innerHTML.
function updateTasksList(tasks) {
    const container = document.querySelector('[data-js="tasks-list"]');
    if (!container) return;

    const taskEntries = Object.entries(tasks);
    container.replaceChildren();

    if (taskEntries.length === 0) {
        const emptyMsg = document.createElement('p');
        emptyMsg.textContent = 'No active tasks';
        container.appendChild(emptyMsg);
        return;
    }

    const list = document.createElement('ul');
    list.className = 'tasks-list';
    const itemTpl = document.getElementById('iperf-task-item');

    taskEntries.forEach(([taskId, task]) => {
        // normalize state/status naming
        const stateRaw = task.state || task.status || 'unknown';
        const state = stateRaw === 'done' ? 'completed' : stateRaw;
        // If no explicit progress provided, map completed=>100, running=>0
        let progress = typeof task.progress === 'number' ? task.progress : 0;
        if ((state === 'completed' || state === 'done') && progress === 0) progress = 100;

        const item = itemTpl ? itemTpl.content.firstElementChild.cloneNode(true) : document.createElement('li');
        item.classList.add('task-state-' + state);
        const fill = (sel, txt) => {
            const el = item.querySelector(sel);
            if (el) el.textContent = txt;
        };
        fill('.task-id', taskId);
        fill('.task-state', state);
        fill('.task-progress', progress + '%');
        list.appendChild(item);
    });

    container.appendChild(list);

    // If any task completed and includes a result payload, render it immediately
    taskEntries.forEach(([taskId, task]) => {
        const stateRaw = task.state || task.status || 'unknown';
        const state = stateRaw === 'done' ? 'completed' : stateRaw;
        const hasResult = task.result && (task.result.data || task.result.result || task.result);
        if (state === 'completed' && hasResult && !renderedTaskResults.has(taskId)) {
            // extract payload similarly to startTaskPolling
            let resultPayload = null;
            if (task.result) {
                if (task.result.data) {
                    resultPayload = task.result.data;
                } else if (task.result.result) {
                    resultPayload = task.result.result;
                } else {
                    resultPayload = task.result;
                }
            }
            if (resultPayload) {
                try { renderIperfResult(resultPayload, { taskId }); } catch (e) { console.error('renderIperfResult failed:', e); }
                renderedTaskResults.add(taskId);
            }

            // Clear any poller for this task if present
            if (activeTaskPollers.has(taskId)) {
                clearInterval(activeTaskPollers.get(taskId));
                activeTaskPollers.delete(taskId);
            }
        }
    });
}

// Render iperf3 results into tables and charts
//
// Static markup (result panel shell + per-graph item) is cloned from <template>
// blocks in net-perf.tpl.php. Rows/cells are created as DOM nodes and filled via
// textContent, so no gateway value is ever injected through innerHTML.

// Build a <thead> holding one colspan=2 header row (label/value tables).
function netPerfHeadRow(headText) {
    const thead = document.createElement('thead');
    const tr = document.createElement('tr');
    const th = document.createElement('th');
    th.colSpan = 2;
    th.textContent = headText;
    tr.appendChild(th);
    thead.appendChild(tr);
    return thead;
}

// Append a <tr> to <tbody>, writing each cell via textContent.
function netPerfAddRow(tbody, cells) {
    const tr = document.createElement('tr');
    cells.forEach((text) => {
        const td = document.createElement('td');
        td.textContent = text;
        tr.appendChild(td);
    });
    tbody.appendChild(tr);
    return tr;
}

function renderIperfResult(result, meta = {}) {
    if (!result) return;
    const taskId = meta.taskId || null;
    const suffix = taskId ? '-' + String(taskId).replace(/[^a-z0-9]/gi, '').slice(0, 8) : '-latest';

    const protocol = result?.start?.test_start?.protocol?.toUpperCase?.() || 'TCP';
    const intervals = result.intervals || [];
    const speeds = intervals.map(iv => iv.sum?.bits_per_second || 0);
    const cwnd = protocol === 'TCP' ? intervals.map(iv => iv.streams?.[0]?.snd_cwnd ?? null) : [];
    const rtt = protocol === 'TCP' ? intervals.map(iv => iv.streams?.[0]?.rtt ?? null) : [];
    const labels = intervals.map((iv, i) => `${Math.round(iv.sum?.end || (i + 1))}s`);

    let jitter = [];
    let lostPackets = [];
    if (protocol === 'UDP') {
        jitter = intervals.map(iv => iv.sum?.jitter_ms ?? iv.sum?.jitter ?? null);
        lostPackets = intervals.map(iv => iv.sum?.lost_packets ?? null);
    }

    const end = result.end || {};
    const sum_sent = end.sum_sent || {};
    const sum_received = end.sum_received || {};
    const cpu = end.cpu_utilization_percent || {};

    const resultsContainer = document.querySelector('[data-js="results-container"]');
    const panelTpl = document.getElementById('iperf-result-panel');
    const graphItemTpl = document.getElementById('iperf-graph-item');
    if (!resultsContainer || !panelTpl) return;

    const panel = panelTpl.content.firstElementChild.cloneNode(true);
    const titleEl = panel.querySelector('.iperf-result-title');
    const metaEl = panel.querySelector('.iperf-result-meta');
    const bodyEl = panel.querySelector('.iperf-result-body');
    const graphsEl = panel.querySelector('.iperf-result-graphs');
    graphsEl.id = `iperf-graphs${suffix}`;

    panel.dataset.taskId = taskId || '';
    if (titleEl) titleEl.textContent = taskId ? `Test ${taskId}` : `Test ${new Date().toISOString()}`;
    if (metaEl) metaEl.textContent = result?.start?.timestamp?.time || '';

    // Summary table
    const summaryTable = document.createElement('table');
    summaryTable.className = 'std-table';
    summaryTable.appendChild(netPerfHeadRow(`Summary (${protocol})`));
    const summaryBody = document.createElement('tbody');
    netPerfAddRow(summaryBody, ['Duration', `${(sum_sent.seconds || 0).toFixed(2)} s`]);
    netPerfAddRow(summaryBody, ['Bytes sent', window.formatBytes(sum_sent.bytes ?? 0)]);
    netPerfAddRow(summaryBody, ['Average throughput', `${(sum_sent.bits_per_second / 1e6).toFixed(2)} Mbps`]);
    if (protocol === 'TCP') netPerfAddRow(summaryBody, ['Retransmissions', sum_sent.retransmits ?? '-']);
    netPerfAddRow(summaryBody, ['Bytes received', window.formatBytes(sum_received.bytes ?? 0)]);
    netPerfAddRow(summaryBody, ['Average throughput received', `${(sum_received.bits_per_second / 1e6).toFixed(2)} Mbps`]);
    if (protocol === 'UDP' && typeof sum_received.lost_packets !== 'undefined') netPerfAddRow(summaryBody, ['Lost packets', sum_received.lost_packets]);
    if (protocol === 'UDP' && typeof sum_received.lost_percent !== 'undefined') netPerfAddRow(summaryBody, ['Loss (%)', `${sum_received.lost_percent.toFixed(2)}%`]);
    summaryTable.appendChild(summaryBody);

    // Summary + CPU go side by side on wide screens and stack on narrow ones
    // (layout provided by .iperf-stat-grid in default-iperf.css).
    const statGrid = document.createElement('div');
    statGrid.className = 'iperf-stat-grid';
    statGrid.appendChild(summaryTable);

    // CPU utilization table (a std-progress bar under each value)
    if (cpu && Object.keys(cpu).length) {
        const cpuTable = document.createElement('table');
        cpuTable.className = 'std-table';
        cpuTable.appendChild(netPerfHeadRow('CPU Utilization (%)'));
        const cpuBody = document.createElement('tbody');
        const cpuFields = [
            ['Host total', cpu.host_total],
            ['Host user', cpu.host_user],
            ['Host system', cpu.host_system],
            ['Remote total', cpu.remote_total],
            ['Remote user', cpu.remote_user],
            ['Remote system', cpu.remote_system],
        ];
        cpuFields.forEach(([label, value]) => {
            const num = (typeof value === 'number' && isFinite(value)) ? value : null;
            const tr = document.createElement('tr');
            const tdLabel = document.createElement('td');
            tdLabel.textContent = label;
            tr.appendChild(tdLabel);
            const tdValue = document.createElement('td');
            tdValue.className = 'iperf-cpu-cell';
            const valSpan = document.createElement('span');
            valSpan.className = 'iperf-cpu-val';
            if (num !== null) {
                valSpan.textContent = num.toFixed(1);
                tdValue.appendChild(valSpan);
                const bar = document.createElement('div');
                bar.className = 'std-progress std-progress--sm';
                const fill = document.createElement('div');
                fill.className = 'std-progress-fill';
                fill.style.width = `${Math.min(100, num)}%`;
                bar.appendChild(fill);
                tdValue.appendChild(bar);
            } else {
                valSpan.classList.add('muted');
                valSpan.textContent = '-';
                tdValue.appendChild(valSpan);
            }
            tr.appendChild(tdValue);
            cpuBody.appendChild(tr);
        });
        cpuTable.appendChild(cpuBody);
        statGrid.appendChild(cpuTable);
    }

    // Append the summary/CPU grid to the body, then the full-width intervals table
    bodyEl.appendChild(statGrid);

    // Intervals table (only if not too many)
    if (intervals.length && intervals.length <= 20) {
        const firstSum = intervals[0]?.sum || {};
        const showUdpLost = protocol === 'UDP' && typeof firstSum.lost_packets !== 'undefined';
        const showUdpLoss = protocol === 'UDP' && typeof firstSum.lost_percent !== 'undefined';

        const ivTable = document.createElement('table');
        ivTable.className = 'std-table';
        const thead = document.createElement('thead');
        const headTr = document.createElement('tr');
        const headCells = ['Interval', 'Seconds', 'Bytes', 'Mbps'];
        if (protocol === 'TCP') headCells.push('Retrans.');
        if (showUdpLost) headCells.push('Lost');
        if (showUdpLoss) headCells.push('Loss (%)');
        headCells.forEach((txt) => {
            const th = document.createElement('th');
            th.textContent = txt;
            headTr.appendChild(th);
        });
        thead.appendChild(headTr);
        ivTable.appendChild(thead);

        const tbody = document.createElement('tbody');
        intervals.forEach((iv, i) => {
            const s = iv.sum || {};
            const cells = [
                String(i + 1),
                s.seconds !== undefined && s.seconds !== null ? s.seconds.toFixed(2) : '-',
                window.formatBytes(s.bytes ?? 0),
                `${(s.bits_per_second / 1e6).toFixed(2)}`,
            ];
            if (protocol === 'TCP') cells.push(s.retransmits ?? '-');
            if (showUdpLost) cells.push(typeof s.lost_packets !== 'undefined' ? s.lost_packets : '-');
            if (showUdpLoss) cells.push(typeof s.lost_percent !== 'undefined' ? s.lost_percent.toFixed(2) : '-');
            netPerfAddRow(tbody, cells);
        });
        ivTable.appendChild(tbody);
        bodyEl.appendChild(ivTable);
    }

    // Append so multiple tests appear one after another
    resultsContainer.appendChild(panel);

    // Collapse behavior: if more than one panel exists, collapse the new one by default
    const toggleBtn = panel.querySelector('.iperf-toggle-btn');
    const setCollapsed = (collapsed) => {
        if (collapsed) {
            bodyEl.style.display = 'none';
            graphsEl.style.display = 'none';
            toggleBtn.textContent = '▸';
            toggleBtn.setAttribute('aria-expanded', 'false');
        } else {
            bodyEl.style.display = '';
            graphsEl.style.display = '';
            toggleBtn.textContent = '▾';
            toggleBtn.setAttribute('aria-expanded', 'true');
        }
    };

    const panelCount = resultsContainer.querySelectorAll('.iperf-result-panel').length;
    if (panelCount > 1) {
        setCollapsed(true);
    } else {
        setCollapsed(false);
    }

    // Toggle handler (also trigger pending chart creation when expanding)
    toggleBtn.addEventListener('click', () => {
        const isExpanded = toggleBtn.getAttribute('aria-expanded') === 'true';
        const willBeExpanded = !isExpanded;
        setCollapsed(isExpanded);
        if (willBeExpanded) {
            const pending = pendingChartCreators.get(suffix);
            if (typeof pending === 'function') {
                try { pending(); } catch (e) { console.error('deferred chart creation failed', e); }
                pendingChartCreators.delete(suffix);
            }
        }
    });

    // Graphs: clone one #iperf-graph-item template per applicable chart
    const graphDefs = [];
    if (speeds.length) {
        graphDefs.push({
            wrapperId: `iperf-graph-speed${suffix}`,
            canvasId: `iperf-speed-chart${suffix}`,
            title: 'Speed (Mbps)',
            yLabel: 'Mbps',
            data: speeds.map(bps => bps / 1e6),
            color: 'rgba(42,122,226,1)',
            height: 180,
        });
    }
    if (protocol === 'TCP' && cwnd.some(v => v !== null)) {
        graphDefs.push({
            wrapperId: `iperf-graph-cwnd${suffix}`,
            canvasId: `iperf-cwnd-chart${suffix}`,
            title: 'Congestion window (bytes)',
            yLabel: 'snd_cwnd (bytes)',
            data: cwnd,
            color: 'rgba(255,193,7,1)',
            height: 120,
        });
    }
    if (protocol === 'TCP' && rtt.some(v => v !== null)) {
        graphDefs.push({
            wrapperId: `iperf-graph-rtt${suffix}`,
            canvasId: `iperf-rtt-chart${suffix}`,
            title: 'RTT (ms)',
            yLabel: 'RTT (ms)',
            data: rtt,
            color: 'rgba(220,53,69,1)',
            height: 120,
        });
    }
    if (protocol === 'UDP' && jitter.some(v => v !== null)) {
        graphDefs.push({
            wrapperId: `iperf-graph-jitter${suffix}`,
            canvasId: `iperf-jitter-chart${suffix}`,
            title: 'Jitter (ms)',
            yLabel: 'Jitter (ms)',
            data: jitter,
            color: 'rgba(255,87,34,1)',
            height: 120,
        });
    }
    if (protocol === 'UDP' && lostPackets.some(v => v !== null)) {
        graphDefs.push({
            wrapperId: `iperf-graph-lost${suffix}`,
            canvasId: `iperf-lost-chart${suffix}`,
            title: 'Lost packets',
            yLabel: 'Lost packets',
            data: lostPackets,
            color: 'rgba(220,53,69,1)',
            height: 120,
        });
    }

    graphDefs.forEach((gd) => {
        let item;
        if (graphItemTpl) {
            item = graphItemTpl.content.firstElementChild.cloneNode(true);
        } else {
            item = document.createElement('div');
            item.className = 'iperf-graph-item';
        }
        item.id = gd.wrapperId;
        let gTitle = item.querySelector('.iperf-graph-title');
        let gWrap = item.querySelector('.iperf-chart-wrap');
        if (!gTitle) {
            gTitle = document.createElement('div');
            gTitle.className = 'iperf-graph-title';
            item.appendChild(gTitle);
        }
        if (!gWrap) {
            gWrap = document.createElement('div');
            gWrap.className = 'iperf-chart-wrap';
            item.appendChild(gWrap);
        }
        let gCanvas = gWrap.querySelector('canvas');
        if (!gCanvas) {
            gCanvas = document.createElement('canvas');
            gWrap.appendChild(gCanvas);
        }
        gTitle.textContent = gd.title;
        // Fixed height wrapper (like .sla-chart-wrap) lets the responsive
        // Chart.js keep a stable height while the width reflows with the panel.
        gWrap.style.height = `${gd.height}px`;
        gCanvas.id = gd.canvasId;
        graphsEl.appendChild(item);
    });

    // If the graphs container is hidden (panel collapsed), defer chart creation
    // until the user expands the panel.
    const createCharts = () => {
        if (typeof makeSingleChart !== 'function') return;
        graphDefs.forEach((gd) => {
            // Responsive width with the fixed height given by the wrapper:
            // maintainAspectRatio:false fills the box instead of stretching it.
            makeSingleChart(gd.canvasId, gd.yLabel, gd.data, gd.color, { beginAtZero: true }, labels, {
                responsive: true,
                maintainAspectRatio: false,
            });
        });
    };

    const compStyle = window.getComputedStyle(graphsEl);
    if (compStyle && compStyle.display === 'none') {
        pendingChartCreators.set(suffix, createCharts);
    } else {
        try { createCharts(); } catch (e) { console.error('createCharts failed', e); }
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function () {
    // Start polling server status and tasks
    startServerPolling();

    // Server controls
    const btnStartServer = document.querySelector('[data-js="start-server"]');
    if (btnStartServer) {
        btnStartServer.addEventListener('click', startServer);
    }

    const btnStopServer = document.querySelector('[data-js="stop-server"]');
    if (btnStopServer) {
        btnStopServer.addEventListener('click', stopServer);
    }

    // Client form
    const clientForm = document.querySelector('[data-js="client-form"]');
    if (clientForm) {
        clientForm.addEventListener('submit', function (e) {
            e.preventDefault();
            startClientTest();
        });
    }
});
