/**
 * NIC tuning (ethtool) panel inside the interface editor (net-iface-mgmt).
 * Loaded only for physical interface edits by an admin (see PageNetwork).
 *
 * Model: sysctl-style single "Save changes" form. Only the changed rows are sent
 * as one ethtool-config.set_iface_settings_bulk; on success/partial the page reloads
 * so live_value / stored_value come from the gateway again.
 *
 * set_iface_settings_bulk returns `partial` (command-level) with result.results:[bool]
 * in the same order as the sent settings; we map failed indexes back to rows.
 */
document.addEventListener('DOMContentLoaded', function () {
    const panel = document.querySelector('[data-js="ethtool-panel"]');
    const form = document.querySelector('[data-js="iface-ethtool-form"]');
    if (!panel || !form) return;

    const ifaceId = (panel.getAttribute('data-iface-id') || '').trim();
    if (ifaceId === '') return;

    /**
     * Collect the changed settings: rows whose control differs from its data-original
     * baseline (stored override, otherwise the live NIC value at page load).
     */
    function collectChanges() {
        const changes = [];
        const invalid = [];
        panel.querySelectorAll('.et-row').forEach(function (row) {
            const ctl = row.querySelector('.js-et-value');
            if (!ctl || ctl.disabled) return;
            const family = row.getAttribute('data-family') || '';
            const setting = row.getAttribute('data-setting') || '';
            const type = row.getAttribute('data-type') || '';
            const original = ctl.getAttribute('data-original') || '';
            if (type === 'bool') {
                const cur = ctl.checked ? '1' : '0';
                if (cur !== original) {
                    changes.push({ family: family, setting: setting, value: ctl.checked });
                }
            } else if (type === 'int') {
                const cur = ctl.value.trim();
                if (cur === original) return;
                if (cur === '' || !/^-?\d+$/.test(cur)) {
                    invalid.push(setting);
                    return;
                }
                changes.push({ family: family, setting: setting, value: parseInt(cur, 10) });
            }
        });
        return { changes: changes, invalid: invalid };
    }

    function reloadSoon() {
        window.location.reload();
    }

    function showApiError(result) {
        if (result && result.error_code === 'FORBIDDEN') {
            showModal('This action requires the system:admin role.', { title: 'Access denied', closeText: 'Close' });
            return;
        }
        showModal(formatResponse(result), { title: 'Error', closeText: 'Close' });
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        const collected = collectChanges();
        if (collected.invalid.length) {
            showModal('Invalid numeric value on: ' + collected.invalid.join(', '), {
                title: 'Validation error',
                closeText: 'Close'
            });
            return;
        }
        if (!collected.changes.length) {
            showModal('No ethtool changes to save.', { title: 'Info', closeText: 'Close' });
            return;
        }
        apiClient.submit('ethtool-config.set_iface_settings_bulk', {
            iface_id: ifaceId,
            settings: collected.changes
        }).then(function (result) {
            appLog('Ethtool bulk submit response:', result);
            if (result.status === 'success') {
                reloadSoon();
                return;
            }
            if (result.status === 'error') {
                showApiError(result);
                return;
            }
            // partial: some settings were rejected by the NIC. Flag the failed rows,
            // summarise, then reload so the gateway state is shown truthfully.
            const results = result.result && Array.isArray(result.result.results) ? result.result.results : null;
            const failed = [];
            if (results && results.length === collected.changes.length) {
                collected.changes.forEach(function (item, i) {
                    if (!results[i]) failed.push(item);
                });
            }
            failed.forEach(function (item) {
                const row = panel.querySelector(
                    '.et-row[data-family="' + CSS.escape(item.family) + '"][data-setting="' + CSS.escape(item.setting) + '"]'
                );
                if (row) row.classList.add('et-err');
            });
            const msg = failed.length
                ? 'Some settings were rejected by the NIC:<br>' +
                  failed.map(function (item) { return item.family + '.' + item.setting; }).join('<br>')
                : (result.response_msg || 'Some settings could not be applied.');
            showModal(msg, {
                title: 'Partial',
                closeText: 'Close',
                onClose: reloadSoon
            });
        }).catch(function (err) {
            showModal('Error: ' + err.message, { title: 'Error', closeText: 'Close' });
        });
    });

    // Per-row "Restore" (delete the override; the NIC reverts to its original value)
    panel.addEventListener('click', function (e) {
        const btn = e.target.closest('.js-et-delete');
        if (!btn) return;
        e.preventDefault();
        const row = btn.closest('.et-row');
        if (!row) return;
        const family = row.getAttribute('data-family') || '';
        const setting = row.getAttribute('data-setting') || '';
        apiClient.submit('ethtool-config.delete_iface_setting', {
            iface_id: ifaceId,
            family: family,
            setting: setting
        }).then(function (result) {
            appLog('Ethtool delete response:', result);
            if (result.status === 'success') {
                reloadSoon();
            } else {
                showApiError(result);
            }
        }).catch(function (err) {
            showModal('Error: ' + err.message, { title: 'Error', closeText: 'Close' });
        });
    });

    // NIC-level actions generated by the formatter (enable/disable/apply-defaults/clear)
    const ACTIONS = {
        'et-enable':         { cmd: 'ethtool-config.enable_iface',          confirmText: '' },
        'et-disable':        { cmd: 'ethtool-config.disable_iface',         confirmText: 'This stops styx from managing ethtool on this NIC. Stored settings are kept but no longer applied.' },
        'et-apply-defaults': { cmd: 'ethtool-config.apply_defaults',        confirmText: '' },
        'et-clear':          { cmd: 'ethtool-config.clear_iface_settings',  confirmText: 'This removes every stored ethtool setting for this NIC (operator and profile) and restores the NIC originals.' }
    };
    panel.querySelectorAll('.et-actions [data-js]').forEach(function (btn) {
        const action = ACTIONS[btn.getAttribute('data-js')];
        if (!action) return;
        btn.addEventListener('click', function () {
            if (action.confirmText && !window.confirm(action.confirmText)) return;
            apiClient.submit(action.cmd, { iface_id: ifaceId }).then(function (result) {
                appLog('Ethtool action response:', result);
                if (result.status === 'success') {
                    reloadSoon();
                } else {
                    showApiError(result);
                }
            }).catch(function (err) {
                showModal('Error: ' + err.message, { title: 'Error', closeText: 'Close' });
            });
        });
    });
});
