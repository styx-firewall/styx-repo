<?php
/**
 * HA fragment: daemon status.
 *
 * @var array<mixed> $tdata - $tdata['tpl_data'] contains the full formatted HA data
 */
$pd = $tdata['tpl_data'] ?? [];
$local_ip = $pd['local_ip'] ?? null;
$installed = !empty($pd['installed']);
$active = !empty($pd['service_active']);
$conntrack = $pd['conntrack'] ?? [];
$hint = $pd['firewall_hint'] ?? [];
?>
<div class="content-box">
    <h2>Status</h2>
    <div class="std-form form-compact">
    <div class="form-row">
        <div class="form-col">
            <label>Daemon</label>
            <span class="std-badge <?= $active ? 'std-badge--success std-badge--dot' : 'std-badge--danger std-badge--dot' ?>">
                <?= $active ? 'Active' : 'Stopped' ?>
            </span>
            <?php if (!$installed): ?>
            <span class="text-muted">(conntrackd not installed)</span>
            <?php endif; ?>
        </div>
        <div class="form-col">
            <label>Conntrack table</label>
            <span><?= isset($conntrack['count']) ? $conntrack['count'] : '-' ?> / <?= isset($conntrack['max']) ? $conntrack['max'] : '-' ?></span>
        </div>
        <?php if ($local_ip): ?>
        <div class="form-col">
            <label>Local sync address</label>
            <span><?= htmlspecialchars((string)$local_ip) ?> <span class="text-muted">(from interface)</span></span>
        </div>
        <?php endif; ?>
        <?php if (!empty($hint['needed']) && !empty($hint['rule'])): ?>
        <div class="form-col">
            <label>Firewall hint</label>
            <span class="text-muted"><code><?= htmlspecialchars((string)$hint['rule']) ?></code></span>
        </div>
        <?php endif; ?>
    </div>
    </div>
</div>
