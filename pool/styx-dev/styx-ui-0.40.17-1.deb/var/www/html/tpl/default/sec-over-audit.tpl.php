<?php
/**
 * Reusable fragment: Security Overview / Audit card set.
 * To be rendered via TemplateService->load_tpl or included directly.
 * @var array<mixed> $tdata
 */


//var_dump($tdata['tpl_data']);
$audit_overview = $tdata['tpl_data']['audit'] ?? null;
//var_dump($audit_overview);
//$audit = $tdata['tpl_data']['audit'] ?? null;
?>

<?php if ($audit_overview): ?>
<section class="sec-grid">
    <div class="card summary-card">
        <div class="card-header">
            <h2 class="card-heading">Audit Summary</h2>
        </div>
        <div class="donut-wrap">
            <svg viewBox="0 0 36 36" class="donut" aria-hidden="true">
                <path class="donut-bg" d="M18 2.0845
                    a 15.9155 15.9155 0 0 1 0 31.831
                    a 15.9155 15.9155 0 0 1 0 -31.831"/>
                <path class="donut-fg grade-<?php echo $audit_overview['coverage_grade'] ?? 'poor' ?>" stroke-dasharray="<?php echo $audit_overview['coverage_pct'] ?? 0 ?>,100" d="M18 2.0845
                    a 15.9155 15.9155 0 0 1 0 31.831
                    a 15.9155 15.9155 0 0 1 0 -31.831"/>
                <text x="18" y="20" class="donut-text"><?php echo $audit_overview['coverage_pct'] ?? 0 ?>%</text>
            </svg>
        </div>
        <div class="rating">Rating: <strong><?php echo $audit_overview['rating'] ?? 'N/A' ?></strong></div>
        <div class="msg small muted"><?php echo $audit_overview['msg'] ?? '' ?></div>
    </div>

    <div class="card stats-card">
        <div class="card-header">
            <h2 class="card-heading">Checks & Score</h2>
        </div>
        <div class="stat-row">
            <div class="stat-label">Total checks</div>
            <div class="stat-number"><?php echo $audit_overview['total_checks'] ?? 0 ?></div>
        </div>
        <div class="stat-row">
            <div class="stat-label">Passed</div>
            <div class="std-progress std-progress--grow">
                <div class="std-progress-fill passed" style="width:<?php echo $audit_overview['pass_pct'] ?? 0 ?>%"></div>
            </div>
            <div class="stat-number small"><?php echo $audit_overview['passed'] ?? 0 ?> <span class="muted">(<?php echo $audit_overview['pass_pct'] ?? 0 ?>%)</span></div>
        </div>
        <div class="stat-row">
            <div class="stat-label">Failed</div>
            <div class="std-progress std-progress--grow">
                <div class="std-progress-fill failed" style="width:<?php echo $audit_overview['fail_pct'] ?? 0 ?>%"></div>
            </div>
            <div class="stat-number small"><?php echo $audit_overview['failed'] ?? 0 ?> <span class="muted">(<?php echo $audit_overview['fail_pct'] ?? 0 ?>%)</span></div>
        </div>
        <div class="stat-row">
            <div class="stat-label">Score</div>
            <div class="std-progress std-progress--grow">
                <div class="std-progress-fill grade-<?php echo $audit_overview['coverage_grade'] ?? 'poor' ?>" style="width:<?php echo $audit_overview['score_pct'] ?? 0 ?>%"></div>
            </div>
            <div class="stat-number small"><?php echo $audit_overview['achieved_score'] ?? 0 ?> / <?php echo $audit_overview['max_score'] ?? 0 ?> <span class="muted">(<?php echo $audit_overview['score_pct'] ?? 0 ?>%)</span></div>
        </div>
    </div>

    <?php if (!empty($audit_overview['coverage_by_tag'])): ?>
    <div class="card">
        <div class="card-header">
            <h2 class="card-heading">Coverage by Benchmark</h2>
        </div>
        <?php foreach ($audit_overview['coverage_by_tag'] as $row): ?>
        <div class="stat-row">
            <div class="stat-label"><?= $row['tag'] ?></div>
            <div class="std-progress std-progress--grow">
                <div class="std-progress-fill grade-<?= $row['grade'] ?>" style="width:<?= $row['pct'] ?>%"></div>
            </div>
            <div class="stat-number small"><?= $row['pct'] ?>%</div>
        </div>
        <?php endforeach ?>
    </div>
    <?php endif ?>
</section>

<?php else: ?>
    <div class="empty">No audit data available.</div>
<?php endif; ?>
