<?php
/**
 * TemplateService->getTpl()
 *
 * Structure of $tdata['page_data']['events']:
 * array<array{
 *   id: string, // Event UUID
 *   timestamp: float|int, // UNIX timestamp
 *   event_type: int, // Integer code for the event type
 *   event_name: string, // Event name (eg: EVENT_FIREWALL_RULE_ADDED)
 *   message: string, // Descriptive message
 *   data: array, // Additional data (may be empty)
 *   level: int, // Numeric level (eg: 6)
 *   level_name: string, // Level name (eg: INFO)
 *   ack: int // 0 or 1, whether it is acknowledged
 * }>
 *
 * Included JS:
 * - styxEvents.js
 *
 * @var array<mixed> $tdata
 */
$levels = $tdata['page_data']['levels_options'];
$limits = $tdata['page_data']['limit_options'];
$events = $tdata['page_data']['events_rows'];
$filters = $tdata['page_data']['filters'];
/**
 * Map a level name to a std-badge variant (default-badge.css).
 * Severity chips render WITHOUT the status dot.
 */
function level_badge($name) {
    $l = strtoupper((string)($name ?? ''));
    if (in_array($l, ['EMERG', 'EMERGENCY', 'ALERT', 'CRIT', 'CRITICAL', 'ERR', 'ERROR'], true)) {
        return 'std-badge--danger';
    }
    if ($l === 'WARN' || $l === 'WARNING') return 'std-badge--warning';
    if ($l === 'NOTICE') return 'std-badge--info';
    if ($l === 'INFO') return 'std-badge--log-info';
    if ($l === 'DEBUG') return 'std-badge--muted';
    return '';
}
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
    <h1>System Events</h1>
        <div class="content-box">
            <form
                method="get"
                action=""
                class="std-form max-width-600"
                style="max-width:600px;"
            >
                <input type="hidden" name="page" value="styx">
                <input type="hidden" name="section" value="styx-events">
                <div class="form-row">
                    <div class="form-col">
                        <label>Level
                            <select name="level" class="std-select">
                                <?php foreach ($levels as $opt): ?>
                                    <option
                                        value="<?= $opt['value'] ?>"
                                        <?php if (!empty($opt['selected'])): ?>selected<?php endif; ?>
                                    >
                                        <?= $opt['name'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    </div>
                    <div class="form-col">
                        <label>Count
                            <select name="limit" class="std-select">
                                <?php foreach ($limits as $lopt): ?>
                                    <option
                                        value="<?= $lopt['value'] ?>"
                                        <?php if (!empty($lopt['selected'])): ?>selected<?php endif; ?>
                                    >
                                        <?= $lopt['value'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    </div>
                    <div class="form-col">
                        <label>
                            Search
                            <input
                                type="text"
                                name="search"
                                placeholder="Search..."
                                value="<?= $filters['search'] ?>"
                            >
                        </label>
                    </div>
                    <div class="form-col align-self-end">
                        <button type="submit" class="std-btn">Filter</button>
                    </div>
                </div>
            </form>
            <div id="ack-msg" class="ack-msg"></div>
            <?php if (!empty($tdata['page_data']['error'])): ?>
                <div class="std-error-box">
                    <strong>Error:</strong>
                    <div><?= $tdata['page_data']['error'] ?></div>
                </div>
            <?php endif; ?>
            <table class="std-table">
                <thead>
                    <tr>
                        <th>Date/Time</th>
                        <th>Level</th>
                        <th>Type</th>
                        <th>Message</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($events)): ?>
                    <tr>
                        <td colspan="5" class="text-center">No events to display.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($events as $row): ?>
                        <tr>
                            <td><?= $row['datetime'] ?></td>
                            <td>
                                <span class="std-badge <?= level_badge($row['level_name']) ?>">
                                    <?= $row['level_name'] ?? '' ?>
                                </span>
                            </td>
                            <td><?= $row['event_name'] ?></td>
                            <td><?= $row['message'] ?></td>
                            <td>
                                <button
                                    type="button"
                                    class="std-btn ack-btn"
                                    data-id="<?= $row['id'] ?>"
                                >
                                    ACK
                                </button>
                                <?php if (!empty($row['has_data'])): ?>
                                    <button
                                        type="button"
                                        class="raw-btn"
                                        data-raw="<?= $row['raw_b64'] ?>"
                                        data-raw-enc="b64"
                                    >
                                        Raw Data
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
