<?php
/**
 * TemplateService->getTpl()
 *
 * @var array<mixed> $tdata
 * js: scripts/objects/sets-mgmt-core.js, scripts/objects/labels-mgmt.js, scripts/tc/tc-common.js, scripts/tc/tc-rules.js
 */
$tdata['tc_config'] = $tdata['page_data']['tc_config'] ?? [];

$tc_parents = $tdata['page_data']['tc_parents'] ?? [];
$interfaceOptions = $tdata['page_data']['interface_options'] ?? [];

?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>QoS / Traffic Control - Rules</h1>
        <div class="content-box">
            <!-- Row: TC rules table -->
            <h2>Current QoS / TC Rules</h2>
            <table class="std-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Interface</th>
                        <th>Qdisc</th>
                        <th>Parent</th>
                        <th>Direction</th>
                        <th>Protocol</th>
                        <th>Priority</th>
                        <th>Classifier</th>
                        <th>Filter / Extra</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($tdata['tc_config'] as $iface_uuid => $qconf) {
                        if (empty($qconf['filters']) || !is_array($qconf['filters'])) {
                            continue;
                        }
                        $iface_name = $qconf['interface_name'] ?? $iface_uuid;
                        foreach ($qconf['filters'] as $filter) {
                    ?>
                    <tr>
                        <td><?= $filter['name'] ?? '-' ?></td>
                        <td><?= $filter['interface'] ?? $iface_name ?></td>
                        <td><?= $filter['_qdisc_label'] ?? '-' ?></td>
                        <td><?= $filter['_parent_display'] ?? '-' ?></td>
                        <td><?= $filter['direction'] ?? '-' ?></td>
                        <td><?= $filter['protocol'] ?? '-' ?></td>
                        <td><?= $filter['prio'] ?? '-' ?></td>
                        <td><?= $filter['classifier'] ?? '-' ?></td>
                        <td><?= $filter['_filter_summary'] ?? '-' ?></td>
                        <td>
                            <span class="std-badge <?= $filter['_active_badge_class'] ?? 'std-badge--muted std-badge--dot' ?>">
                                <?= $filter['_active_badge_text'] ?? 'Inactive' ?>
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-danger btn-sm delete-rule"
                                data-id="<?= $filter['id'] ?? '' ?>">
                                Delete
                            </button>
                            <button class="btn btn-secondary btn-sm toggle-rule"
                                data-id="<?= $filter['id'] ?? '' ?>"
                                data-iface-uuid="<?= $iface_uuid ?>"
                                data-active="<?= $filter['_toggle_active'] ?? '1' ?>">
                                <?= $filter['_toggle_text'] ?? 'Toggle' ?>
                            </button>
                        </td>
                    </tr>
                    <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Add TC Rule Form -->

        <div class="content-box">
            <h2>Add TC Rule</h2>
            <form id="tc-rule-form" class="std-form form-compact">
                        <div class="tc-section-label">Basic</div>
                        <!-- Row: Name       Direction   Protocol   Classifier       [Custom mode] -->
                        <div class="form-row">
                            <div class="form-col tc-col--lg">
                                <label for="tc-name">Name <span class="js-info-icon" data-info-modal="help-tc-name"></span></label>
                                <input type="text" name="name" id="tc-name" required placeholder="e.g. Limit HTTP">
                            </div>
                            <div class="form-col tc-col--md">
                                <label for="tc-direction">Direction <span class="js-info-icon" data-info-modal="help-tc-direction"></span></label>
                                <select name="direction" id="tc-direction" required>
                                    <option value="egress" selected>Egress</option>
                                    <option value="ingress">Ingress</option>
                                </select>
                            </div>
                            <div class="form-col tc-col--sm">
                                <label>Protocol <span class="js-info-icon" data-info-modal="help-tc-protocol"></span></label>
                                <select name="protocol" id="tc-protocol">
                                    <option value="ip" selected>ip</option>
                                    <option value="ipv6">ipv6</option>
                                    <option value="arp">arp</option>
                                    <option value="all">all</option>
                                </select>
                            </div>
                            <div class="form-col tc-col--md">
                                <label for="tc-classifier">Classifier <span class="js-info-icon" data-info-modal="help-tc-classifier"></span></label>
                                <select name="classifier" id="tc-classifier" required>
                                    <option value="u32" selected>u32</option>
                                    <option value="flower">flower</option>
                                    <option value="fw">fw</option>
                                    <option value="matchall">matchall</option>
                                </select>
                                <input type="text" name="classifier" id="tc-classifier-input"
                                    placeholder="e.g. basic" style="display:none;">
                            </div>
                            <div class="form-col tc-col--fit">
                                <label class="tc-custom-label">
                                    <input type="checkbox" id="tc-custom-mode" name="custom_mode">
                                    <span>Custom mode</span>
                                    <span class="js-info-icon" data-info-modal="help-tc-custom-mode"></span>
                                </label>
                            </div>
                        </div>

                        <!-- Row: Interface                     Parent (egress)       Priority   Active -->
                        <div class="form-row">
                            <div class="form-col tc-col--lg">
                                <label for="tc-iface">Interface <span class="js-info-icon" data-info-modal="help-tc-interface"></span></label>
                                <select name="interface_uuid" id="tc-iface" required>
                                    <option value="">-- select --</option>
                                    <?php foreach ($interfaceOptions as $opt): ?>
                                        <option value="<?= $opt['value'] ?>"><?= $opt['label'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-col tc-col--lg" id="tc-egress-row">
                                <label>Parent <span class="js-info-icon" data-info-modal="help-tc-parent"></span></label>
                                <select name="parent" id="tc-parent">
                                    <?php foreach ($tc_parents as $key => $entry): ?>
                                        <option value="<?= $key ?>" data-iface="<?= $entry[1] ?>"><?= $entry[0] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-col tc-col--sm">
                                <label>Priority <span class="js-info-icon" data-info-modal="help-tc-prio"></span></label>
                                <input type="number" name="prio" id="tc-prio" min="0" value="1">
                            </div>
                            <div class="form-col tc-col--sm">
                                <label>Active <span class="js-info-icon" data-info-modal="help-tc-active"></span></label>
                                <select name="active" id="tc-active">
                                    <option value="1" selected>Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                        </div>

                        <!-- Structured fields -->

                        <div id="tc-structured-fields">

                            <!-- flowid (egress: u32, flower, fw) -->
                            <div class="form-row tc-field tc-egress-only tc-cls-u32 tc-cls-flower tc-cls-fw">
                                <div class="form-col tc-col--md">
                                    <label>FlowID <span class="js-info-icon" data-info-modal="help-tc-flowid"></span></label>
                                    <input type="text" name="flowid" id="tc-flowid" placeholder="e.g. 1:10">
                                </div>
                            </div>

                            <div class="tc-section-label tc-cls-u32 tc-cls-flower tc-cls-fw">Match</div>

                            <!-- Src IP  |  Dst IP  |  Src Port  |  Dst Port  (u32, flower) -->
                            <div class="form-row tc-field tc-cls-u32 tc-cls-flower">
                                <div class="form-col tc-col--lg">
                                    <label>Source IP <span class="js-info-icon" data-info-modal="help-tc-src-ip"></span></label>
                                    <div class="set-picker-field" data-js="set-picker-field"
                                         data-set-type="address" data-max-select="1" data-filter-family="ip">
                                        <input type="hidden" name="src_ip" id="tc-src-ip" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Any">
                                            <span class="js-set-picker-label">Any</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear">&#215;</button>
                                    </div>
                                </div>
                                <div class="form-col tc-col--lg">
                                    <label>Dest IP <span class="js-info-icon" data-info-modal="help-tc-dst-ip"></span></label>
                                    <div class="set-picker-field" data-js="set-picker-field"
                                         data-set-type="address" data-max-select="1" data-filter-family="ip">
                                        <input type="hidden" name="dst_ip" id="tc-dst-ip" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Any">
                                            <span class="js-set-picker-label">Any</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear">&#215;</button>
                                    </div>
                                </div>
                                <div class="form-col tc-col--lg">
                                    <label>Src Port <span class="js-info-icon" data-info-modal="help-tc-src-port"></span></label>
                                    <div class="set-picker-field" data-js="set-picker-field"
                                         data-set-type="ports" data-max-select="1" data-filter-type="single" data-filter-scope="single">
                                        <input type="hidden" name="src_port" id="tc-src-port" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Any">
                                            <span class="js-set-picker-label">Any</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear">&#215;</button>
                                    </div>
                                </div>
                                <div class="form-col tc-col--lg">
                                    <label>Dst Port <span class="js-info-icon" data-info-modal="help-tc-dst-port"></span></label>
                                    <div class="set-picker-field" data-js="set-picker-field"
                                         data-set-type="ports" data-max-select="1" data-filter-type="single" data-filter-scope="single">
                                        <input type="hidden" name="dst_port" id="tc-dst-port" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Any">
                                            <span class="js-set-picker-label">Any</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear">&#215;</button>
                                    </div>
                                </div>
                            </div>

                            <div class="tc-section-label tc-cls-u32 tc-cls-flower">L4 / Flags</div>

                            <!-- IP Proto | TOS | TCP Flags(fl) | VLAN ID(fl) | CT State(fl) | Connmark(fl) -->
                            <div class="form-row tc-field tc-cls-u32 tc-cls-flower">
                                <div class="form-col tc-col--sm">
                                    <label>IP Proto <span class="js-info-icon" data-info-modal="help-tc-ip-proto"></span></label>
                                    <select name="ip_proto" id="tc-ip-proto">
                                        <option value="">any</option>
                                        <option value="tcp">tcp</option>
                                        <option value="udp">udp</option>
                                        <option value="icmp">icmp</option>
                                    </select>
                                </div>
                                <div class="form-col tc-col--sm">
                                    <label>TOS <span class="js-info-icon" data-info-modal="help-tc-tos"></span></label>
                                    <input type="text" name="tos" id="tc-tos" placeholder="0x10">
                                </div>
                                <div class="form-col tc-field tc-cls-flower tc-col--md">
                                    <label>TCP Flags <span class="js-info-icon" data-info-modal="help-tc-tcp-flags"></span></label>
                                    <input type="text" name="tcp_flags" id="tc-tcp-flags" placeholder="syn">
                                </div>
                                <div class="form-col tc-field tc-cls-flower tc-col--md">
                                    <label>VLAN ID <span class="js-info-icon" data-info-modal="help-tc-vlan-id"></span></label>
                                    <div class="set-picker-field" data-js="label-picker-field"
                                         data-set-type="vlans" data-max-select="1">
                                        <input type="hidden" name="vlan_id" id="tc-vlan-id" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select VLAN...">
                                            <span class="js-set-picker-label">Select...</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear">&#215;</button>
                                    </div>
                                </div>
                                <div class="form-col tc-field tc-cls-flower tc-col--md">
                                    <label>CT State <span class="js-info-icon" data-info-modal="help-tc-ct-state"></span></label>
                                    <input type="text" name="ct_state" id="tc-ct-state" placeholder="new,est">
                                </div>
                                <div class="form-col tc-field tc-cls-flower tc-col--lg">
                                    <label>Connmark <span class="js-info-icon" data-info-modal="help-tc-connmark"></span></label>
                                    <div class="set-picker-field" data-js="label-picker-field"
                                         data-set-type="packet_marking" data-max-select="1">
                                        <input type="hidden" name="connmark" id="tc-connmark" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select connmark...">
                                            <span class="js-set-picker-label">Select...</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear">&#215;</button>
                                    </div>
                                </div>
                            </div>

                            <!-- fwmark (fw, required) -->
                            <div class="form-row tc-field tc-cls-fw">
                                <div class="form-col tc-col--xl">
                                    <label>fwmark <span class="js-info-icon-red" data-info-modal="help-tc-fwmark"></span> <span style="color:#b00;">*</span></label>
                                    <div class="set-picker-field" data-js="label-picker-field"
                                         data-set-type="packet_marking" data-max-select="1">
                                        <input type="hidden" name="fwmark" id="tc-fwmark" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select fwmark...">
                                            <span class="js-set-picker-label">Select...</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear">&#215;</button>
                                    </div>
                                </div>
                            </div>

                            <div class="tc-section-label tc-cls-u32 tc-cls-flower tc-cls-fw tc-cls-matchall">Action</div>

                            <!-- mark skbedit (egress only, all classifiers) -->
                            <div class="form-row tc-field tc-egress-only tc-cls-u32 tc-cls-flower tc-cls-fw tc-cls-matchall">
                                <div class="form-col tc-col--lg">
                                    <label>Mark (skbedit) <span class="js-info-icon" data-info-modal="help-tc-mark"></span></label>
                                    <div class="set-picker-field" data-js="label-picker-field"
                                         data-set-type="packet_marking" data-max-select="1">
                                        <input type="hidden" name="mark" id="tc-mark" value="">
                                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select mark...">
                                            <span class="js-set-picker-label">Select...</span>
                                        </button>
                                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear">&#215;</button>
                                    </div>
                                </div>
                            </div>

                            <!-- Action | Rate | Mirror Dev (both directions, all classifiers) -->
                            <div class="form-row tc-field tc-cls-u32 tc-cls-flower tc-cls-fw tc-cls-matchall">
                                <div class="form-col tc-col--md">
                                    <label>Action <span class="js-info-icon" data-info-modal="help-tc-action"></span></label>
                                    <select name="action" id="tc-action">
                                        <option value="">none</option>
                                        <option value="drop">drop</option>
                                        <option value="ok">ok</option>
                                        <option value="pass">pass</option>
                                        <option value="mirror">mirror</option>
                                    </select>
                                </div>
                                <div class="form-col tc-col--md">
                                    <label>Rate <span class="js-info-icon" data-info-modal="help-tc-rate"></span></label>
                                    <input type="text" name="rate" id="tc-rate" placeholder="10mbit">
                                </div>
                                <div class="form-col tc-col--md" id="tc-mirror-dev-col" style="display:none;">
                                    <label>Mirror Dev <span class="js-info-icon" data-info-modal="help-tc-mirror-dev"></span></label>
                                    <input type="text" name="mirror_dev" id="tc-mirror-dev" placeholder="eth1">
                                </div>
                            </div>

                        </div><!-- #tc-structured-fields -->

                        <!-- Custom mode fields-->

                        <div id="tc-custom-fields" style="display:none;">
                            <div class="form-row">
                                <div class="form-col tc-col--full">
                                    <label>Filter (raw) <span class="js-info-icon" data-info-modal="help-tc-custom-filter"></span></label>
                                    <input type="text" name="filter" id="tc-filter"
                                        placeholder="e.g. match ip src 192.168.1.0/24 flowid 1:10">
                                </div>
                            </div>
                        </div>

                        <!-- Submit -->
                        <div class="form-row" style="margin-top:0.5rem;">
                            <div class="form-col tc-col--fit">
                                <button type="submit" class="std-btn">Add Rule</button>
                            </div>
                        </div>

                    </form>
        </div>

        <!-- Help blocks -->
            <div id="help-tc-name" style="display:none"><p><strong>Name</strong>: Unique internal name for this TC rule.</p></div>
            <div id="help-tc-direction" style="display:none"><p><strong>Direction</strong>: Egress (outgoing) or Ingress (incoming).</p></div>
            <div id="help-tc-interface" style="display:none"><p><strong>Interface</strong>: Network interface to attach this rule to.</p></div>
            <div id="help-tc-protocol" style="display:none"><p><strong>Protocol</strong>: EtherType / protocol to match.</p></div>
            <div id="help-tc-classifier" style="display:none"><p><strong>Classifier</strong>: Match engine - u32, flower, fw, or matchall.</p></div>
            <div id="help-tc-custom-mode" style="display:none"><p><strong>Custom mode</strong>: Bypass structured fields and supply a raw filter.</p></div>
            <div id="help-tc-parent" style="display:none"><p><strong>Parent</strong>: Parent qdisc/class handle (egress only).</p></div>
            <div id="help-tc-prio" style="display:none"><p><strong>Priority</strong>: Numeric filter priority. Lower = higher.</p></div>
            <div id="help-tc-active" style="display:none"><p><strong>Active</strong>: Apply rule to OS immediately.</p></div>
            <div id="help-tc-flowid" style="display:none"><p><strong>FlowID</strong>: Target class handle (egress only).</p></div>
            <div id="help-tc-src-ip" style="display:none"><p><strong>Source IP</strong>: Match source IP via address set picker.</p></div>
            <div id="help-tc-dst-ip" style="display:none"><p><strong>Destination IP</strong>: Match destination IP via address set picker.</p></div>
            <div id="help-tc-src-port" style="display:none"><p><strong>Source Port</strong>: Match source port via port set picker.</p></div>
            <div id="help-tc-dst-port" style="display:none"><p><strong>Destination Port</strong>: Match destination port via port set picker.</p></div>
            <div id="help-tc-ip-proto" style="display:none"><p><strong>IP Protocol</strong>: Match L4 protocol (tcp, udp, icmp...).</p></div>
            <div id="help-tc-tos" style="display:none"><p><strong>TOS</strong>: Match Type of Service field (hex).</p></div>
            <div id="help-tc-tcp-flags" style="display:none"><p><strong>TCP Flags</strong>: Match TCP flags (flower only). E.g. syn, ack.</p></div>
            <div id="help-tc-vlan-id" style="display:none"><p><strong>VLAN ID</strong>: Match 802.1Q VLAN ID (flower only).</p></div>
            <div id="help-tc-ct-state" style="display:none"><p><strong>Conntrack State</strong>: Match ct_state (flower only). E.g. new, est.</p></div>
            <div id="help-tc-connmark" style="display:none"><p><strong>Connmark</strong>: Match ct_mark via label picker (flower only).</p></div>
            <div id="help-tc-fwmark" style="display:none"><p><strong>fwmark</strong>: Match firewall mark (fw classifier only, required).</p></div>
            <div id="help-tc-mark" style="display:none"><p><strong>Mark</strong>: Set fwmark (skbedit) on matched packets.</p></div>
            <div id="help-tc-action" style="display:none"><p><strong>Action</strong>: drop, ok, pass, or mirror.</p></div>
            <div id="help-tc-rate" style="display:none"><p><strong>Rate</strong>: Policing rate for the action.</p></div>
            <div id="help-tc-mirror-dev" style="display:none"><p><strong>Mirror Dev</strong>: Target device for mirror action.</p></div>
            <div id="help-tc-custom-filter" style="display:none"><p><strong>Filter</strong>: Raw tc filter expression.</p></div>
    </main>
</div>
