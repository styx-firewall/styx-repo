<?php
/**
 * Sidebar template - renders the main navigation menu
 * scripts: menu.js
 * css: default-menu.css, default-sidebar-icons.css
 */
$features = $tdata['tpl_data']['features'] ?? [];
$vis = $tdata['tpl_data']['sidebar_visible'] ?? [];
?>
<nav class="sidebar-menu">
    <div class="menu-section-wrap">
        <a href="?page=dashboard" class="menu-section" data-toggle="sec_dashboard" data-force-loader>
            <span class="icon-left icon-dashboard" aria-label="Home"></span>
            Dashboard
        </a>
        <div class="submenu" id="sec_dashboard">
            <a href="?page=dashboard" class="submenu-link" data-force-loader>Overview</a>
            <a href="?page=dashboard&section=dash-charts" class="submenu-link" data-force-loader>Chart Junkies</a>
        </div>
    </div>
    <?php if (!empty($vis['network'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=network" class="menu-section" data-toggle="sec_network" data-force-loader>
            <span class="icon-left icon-network" aria-label="Network"></span>
            Network
        </a>
        <div class="submenu" id="sec_network">
            <a href="?page=network&section=net-interfaces" class="submenu-link" data-force-loader>Interfaces</a>
            <?php if (!empty($features['sla_monitor'])): ?>
                <a href="?page=network&section=net-sla" class="submenu-link" data-force-loader>SLA Monitor</a>
            <?php endif; ?>
            <?php if (!empty($features['iperf3'])): ?>
                <a href="?page=network&section=net-perf" class="submenu-link" data-force-loader>Performance</a>
            <?php endif; ?>
            <?php if (!empty($features['network_tunning'])): ?>
                <a href="?page=network&section=net-tunning" class="submenu-link" data-force-loader>Tunning</a>
            <?php endif; ?>
            <?php if (!empty($features['traffic_stats'])): ?>
                <a href="?page=network&section=net-traffic-stats" class="submenu-link" data-force-loader>Traffic Stats</a>
            <?php endif; ?>
            <?php if (!empty($features['network_discovery'])): ?>
                <a href="?page=network&section=net-discovery" class="submenu-link" data-force-loader>Discovery</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    <div class="menu-section-wrap">
        <a href="?page=routing&section=routing-overview" class="menu-section" data-toggle="sec_routing" data-force-loader>
            <span class="icon-left icon-routing" aria-label="Routing"></span>
            Routing
        </a>
        <div class="submenu" id="sec_routing">
            <a href="?page=routing&section=routing-overview" class="submenu-link" data-force-loader>Overview</a>
            <a href="?page=routing&section=routing-routes" class="submenu-link" data-force-loader>System Routes</a>
            <a href="?page=routing&section=routing-rules" class="submenu-link" data-force-loader>Route Rules</a>
            <?php if (!empty($features['frrouting'])): ?>
            <div class="submenu-separator"></div>
            <a href="?page=routing&section=routing-frr" class="submenu-link" data-force-loader>FRR Global</a>
            <a href="?page=routing&section=routing-bgp" class="submenu-link" data-force-loader>BGP</a>
            <a href="?page=routing&section=routing-ospf" class="submenu-link" data-force-loader>OSPF (dev)</a>
            <a href="?page=routing&section=routing-rip" class="submenu-link" data-force-loader>RIP (dev)</a>
            <a href="?page=routing&section=routing-bfd" class="submenu-link" data-force-loader>BFD</a>
            <a href="?page=routing&section=routing-policies" class="submenu-link" data-force-loader>Policies</a>
            <a href="?page=routing&section=routing-frr-static" class="submenu-link" data-force-loader>Static Routes</a>
            <a href="?page=routing&section=routing-vrrp" class="submenu-link" data-force-loader>VRRP</a>
            <a href="?page=routing&section=routing-zebra" class="submenu-link" data-force-loader>Zebra (dev)</a>
            <a href="?page=routing&section=routing-evpn" class="submenu-link" data-force-loader>EVPN (dev)</a>
            <?php endif; ?>
            <?php if (!empty($features['igmp_proxy'])): ?>
            <div class="submenu-separator"></div>
            <a href="?page=routing&section=routing-igmp-proxy" class="submenu-link" data-force-loader>IGMP Proxy</a>
            <?php endif; ?>
        </div>
    </div>
    <?php if (!empty($vis['firewall'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=firewall" class="menu-section" data-toggle="sec_firewall" data-force-loader>
            <span class="icon-left icon-firewall" aria-label="Firewall"></span>
            Firewall
        </a>
        <div class="submenu" id="sec_firewall">
            <a href="?page=firewall&section=fw-rules-forward" class="submenu-link" data-force-loader>Rules Forward</a>
            <a href="?page=firewall&section=fw-rules-local" class="submenu-link" data-force-loader>Rules Local</a>
            <a href="?page=firewall&section=fw-nat" class="submenu-link" data-force-loader>NAT Rules</a>
            <a href="?page=firewall&section=fw-logs-firewall" class="submenu-link" data-force-loader>Firewalls Logs</a>
            <a href="?page=firewall&section=fw-logs-ct" class="submenu-link" data-force-loader>Connection Logs</a>
            <a href="?page=firewall&section=fw-settings" class="submenu-link" data-force-loader>Settings</a>
        </div>
    </div>
    <?php endif; ?>
<?php
// Traffic Control default href: prefer TC Overview, fallback to Packet Marking
if (!empty($vis['traffic_shaping'])) {
    $tc_default_href = '?page=traffic_shaping&section=ts-tc-overview';
} elseif (!empty($vis['packet_marking'])) {
    $tc_default_href = '?page=packet_marking';
} else {
    $tc_default_href = '#';
}
?>
<?php if (!empty($vis['packet_marking']) || !empty($vis['traffic_shaping'])): ?>
    <div class="menu-section-wrap">
        <a href="<?= $tc_default_href ?>" class="menu-section" data-toggle="sec_traffic_control" data-force-loader>
            <span class="icon-left icon-traffic-shaping" aria-label="Traffic Control"></span>
            Traffic Control
        </a>
        <div class="submenu" id="sec_traffic_control">
            <?php if (!empty($vis['packet_marking'])): ?>
                <a href="?page=packet_marking" class="submenu-link" data-force-loader>Packet Marking</a>
            <?php endif; ?>
            <?php if (!empty($vis['traffic_shaping'])): ?>
                <a href="?page=traffic_shaping&section=ts-tc-overview" class="submenu-link" data-force-loader>TC Overview</a>
                <a href="?page=traffic_shaping&section=ts-tc-config" class="submenu-link" data-force-loader>TC Config</a>
                <a href="?page=traffic_shaping&section=ts-tc-rules" class="submenu-link" data-force-loader>TC Rules</a>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>
    <?php if (!empty($vis['objects'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=objects&section=sets-mgmt" class="menu-section" data-toggle="sec_objects" data-force-loader>
            <span class="icon-left icon-objects" aria-label="Objects"></span>
            Objects
        </a>
        <div class="submenu" id="sec_objects">
            <a href="?page=objects&section=sets-mgmt" class="submenu-link" data-force-loader>Sets</a>
            <a href="?page=objects&section=objects-labels" class="submenu-link" data-force-loader>Labels</a>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty($vis['ebpf'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=ebpf&section=ebpf" class="menu-section" data-force-loader>
            <span class="icon-left icon-ebpf" aria-label="eBPF"></span>
            eBPF
        </a>
    </div>
    <?php endif; ?>
    <div class="menu-section-wrap">
        <a href="?page=services" class="menu-section" data-toggle="sec_services" data-force-loader>
            <span class="icon-left icon-services" aria-label="Services"></span>
            Services
        </a>
        <div class="submenu" id="sec_services">
            <a href="?page=services&section=serv-ntp" class="submenu-link" data-force-loader>NTP</a>
            <?php if (!empty($features['kea_dhcp4'])): ?>
            <a href="?page=services&section=serv-dhcp" class="submenu-link" data-force-loader>DHCP Server</a>
            <?php endif; ?>
        </div>
    </div>
    <?php if (!empty($vis['ha'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=ha" class="menu-section" data-toggle="sec_ha" data-force-loader>
            <span class="icon-left icon-services" aria-label="HA"></span>
            HA
        </a>
        <div class="submenu" id="sec_ha">
            <a href="?page=ha" class="submenu-link" data-force-loader>conntrackd</a>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty($vis['system'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=system" class="menu-section" data-toggle="sec_system" data-force-loader>
            <span class="icon-left icon-system" aria-label="System"></span>
            System
        </a>
        <div class="submenu" id="sec_system">
            <a href="?page=system&section=sys-settings" class="submenu-link" data-force-loader>Settings</a>
            <a href="?page=system&section=sys-apps" class="submenu-link" data-force-loader>Upgrade/Apps</a>
            <a href="?page=system&section=sys-services" class="submenu-link" data-force-loader>Services</a>
            <a href="?page=system&section=sys-certs" class="submenu-link" data-force-loader>Certificates</a>
            <a href="?page=system&section=sys-logs" class="submenu-link" data-force-loader>System Logs</a>
            <a href="?page=system&section=sys-reboot" class="submenu-link" data-force-loader>Reboot</a>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty($vis['vpn'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=vpn" class="menu-section" data-toggle="sec_vpn" data-force-loader>
            <span class="icon-left icon-vpn" aria-label="VPN"></span>
            VPN
        </a>
        <div class="submenu" id="sec_vpn">
            <?php if (!empty($features['strongswan'])): ?>
            <a href="?page=vpn&section=vpn-strongswan" class="submenu-link" data-force-loader>IPSec</a>
            <?php endif; ?>
            <?php if (!empty($features['wireguard'])): ?>
            <a href="?page=vpn&section=vpn-wireguard" class="submenu-link" data-force-loader>WireGuard</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty($vis['idsips'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=idsips" class="menu-section" data-toggle="sec_idsips" data-force-loader>
            <span class="icon-left icon-ids-ips" aria-label="IDS/IPS"></span>
            IDS/IPS
        </a>
        <div class="submenu" id="sec_idsips">
            <a href="?page=idsips&section=ids-overview" class="submenu-link" data-force-loader>Overview</a>
            <a href="?page=idsips&section=ids-rules" class="submenu-link" data-force-loader>Rules</a>
            <a href="?page=idsips&section=ids-alerts" class="submenu-link" data-force-loader>Alerts</a>
            <a href="?page=idsips&section=ids-config" class="submenu-link" data-force-loader>Configuration</a>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty($vis['styx'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=styx" class="menu-section" data-toggle="sec_styx" data-force-loader>
            <span class="icon-left icon-styx" aria-label="Styx"></span>
            Styx
        </a>
        <div class="submenu" id="sec_styx">
            <a href="?page=styx&section=styx-settings" class="submenu-link" data-force-loader>Settings</a>
            <a href="?page=styx&section=styx-features" class="submenu-link" data-force-loader>Features</a>
            <a href="?page=styx&section=styx-events" class="submenu-link" data-force-loader>Events</a>
            <a href="?page=styx&section=styx-logs" class="submenu-link" data-force-loader>Styx Logs</a>
            <a href="?page=styx&section=styx-backups" class="submenu-link" data-force-loader>Styx Backups</a>
            <a href="?page=styx&section=styx-restart" class="submenu-link" data-force-loader>Restart Gateway</a>
            <a href="?page=styx&section=styx-licence" class="submenu-link" data-force-loader>Styx Licence</a>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty($vis['users'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=users" class="menu-section" data-toggle="sec_users" data-force-loader>
            <span class="icon-left icon-users" aria-label="Users"></span>
            Users
        </a>
        <div class="submenu" id="sec_users">
            <a href="?page=users&section=users" class="submenu-link" data-force-loader>Local Users</a>
                    <?php if (!empty($features['bearer_tokens'])): ?>
            <a href="?page=users&section=user-api-tokens" class="submenu-link" data-force-loader>API Tokens</a>
                    <?php endif; ?>
            <a href="?page=users&section=user-profile" class="submenu-link" data-force-loader>Profile</a>
            <?php if (!empty($vis['user_roles'])): ?>
            <a href="?page=users&section=user-roles" class="submenu-link" data-force-loader>User Roles</a>
            <?php endif; ?>
            <?php if (!empty($vis['role_definitions'])): ?>
            <a href="?page=users&section=role-definitions" class="submenu-link" data-force-loader>Role Definitions</a>
            <?php endif; ?>
            <!--
            <a href="?page=users&section=ldap-servers" class="submenu-link">LDAP Servers</a>
            <a href="?page=users&section=radius-servers" class="submenu-link">Radius Servers</a>
            <a href="?page=users&section=sso" class="submenu-link">Single Sign-On</a>
            -->
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty($vis['security'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=security" class="menu-section" data-toggle="sec_security" data-force-loader>
            <span class="icon-left icon-security" aria-label="Security"></span>
            Security
        </a>
        <div class="submenu" id="sec_security">
            <a href="?page=security&section=sec-overview" class="submenu-link" data-force-loader>Overview</a>
            <a href="?page=security&section=sec-audit" class="submenu-link" data-force-loader>Audit</a>
            <?php if (!empty($features['auditd'])): ?>
            <a href="?page=security&section=sec-auditd" class="submenu-link" data-force-loader>Auditd</a>
            <?php endif; ?>
            <?php if (!empty($features['aide'])): ?>
            <a href="?page=security&section=sec-aide" class="submenu-link" data-force-loader>AIDE</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty($vis['logs'])): ?>
    <div class="menu-section-wrap">
        <a href="?page=logs" class="menu-section" data-toggle="sec_logs" data-force-loader>
            <span class="icon-left icon-logs" aria-label="Logs"></span>
            Logs
        </a>
        <div class="submenu" id="sec_logs">
            <a href="?page=logs&section=logs-settings" class="submenu-link" data-force-loader>Log Settings</a>
            <a href="?page=firewall&section=fw-logs-firewall" class="submenu-link" data-force-loader>Firewall Logs</a>
            <a href="?page=firewall&section=fw-logs-ct" class="submenu-link" data-force-loader>Connection Logs</a>
            <a href="?page=system&section=sys-logs" class="submenu-link" data-force-loader>System Logs</a>
            <a href="?page=styx&section=styx-logs" class="submenu-link" data-force-loader>Styx Logs</a>
            <a href="?page=styx&section=styx-events" class="submenu-link" data-force-loader>Events</a>
        </div>
    </div>
    <?php endif; ?>
    <div class="menu-section-wrap">
        <a href="?page=logout" class="menu-section" data-force-loader>
            <span class="icon-left icon-logout" aria-label="Logout"></span>
            Logout
        </a>
    </div>
</nav>
