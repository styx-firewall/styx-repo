<?php
/**
 * Fragment: NIC tuning (ethtool) for net-iface-mgmt, rendered in the right column
 * below "Interface Sysctl". Presentation data prepared by NetIfaceEthtoolFormatter
 * (all dynamic text is pre-escaped; this template only echoes).
 */
$t = $tdata['tpl_data'] ?? [];
?>
<div id="ethtool-collapse-box" class="std-collapse-box im-margin-top0">
    <div class="std-collapse-header" onclick="this.parentNode.classList.toggle('open')">
        NIC tuning (ethtool)
    </div>
    <div class="std-collapse-content">
        <div id="ethtool-panel" data-js="ethtool-panel" data-iface-id="<?= $t['et_iface_id'] ?? '' ?>">
            <?php if (!empty($t['et_state_html'])): ?>
            <div class="et-state"><?= $t['et_state_html'] ?></div>
            <?php endif; ?>

            <?php foreach (($t['et_sync_warnings'] ?? []) as $warning): ?>
            <div class="et-warning"><span class="std-badge std-badge--warning">Sync issue</span> <?= $warning ?></div>
            <?php endforeach; ?>

            <?php if (!empty($t['et_load_error_esc'])): ?>
            <div class="et-error"><?= $t['et_load_error_esc'] ?></div>
            <?php else: ?>

            <?= $t['et_actions_html'] ?? '' ?>

            <?php if (!empty($t['et_no_operator_note_esc'])): ?>
            <div class="et-note"><?= $t['et_no_operator_note_esc'] ?></div>
            <?php endif; ?>

            <form id="iface-ethtool-form" data-js="iface-ethtool-form" method="post" autocomplete="off">
                <?php foreach (($t['et_families'] ?? []) as $family): ?>
                <div class="et-family">
                    <div class="et-family-title">
                        <?= $family['etf_title_esc'] ?>
                        <?php if (!$family['etf_supported'] && $family['etf_read_error_esc'] !== ''): ?>
                        <span class="std-badge std-badge--warning">not readable</span>
                        <?php endif; ?>
                    </div>

                    <?php if ($family['etf_supported']): ?>
                        <?php foreach (($family['etf_groups'] ?? []) as $group): ?>
                        <div class="et-group">
                            <div class="et-group-title"><?= $group['etg_label_esc'] ?></div>
                            <div class="et-grid">
                            <?php foreach (($group['etg_rows'] ?? []) as $row): ?>
                            <?php
                            $row_class = 'et-row' . ($row['differs'] ? ' et-differs' : '') . ($row['editable'] ? '' : ' et-fixed');
                            $stored_attr = !empty($row['has_stored']) ? ' data-source="' . $row['source'] . '"' : '';
                            ?>
                            <div class="<?= $row_class ?>"
                                data-family="<?= $family['etf_key'] ?>"
                                data-setting="<?= $row['setting_esc'] ?>"
                                data-type="<?= $row['type'] ?>"
                                data-has-stored="<?= !empty($row['has_stored']) ? '1' : '0' ?>"<?= $stored_attr ?>>
                                <div class="et-row-label">
                                    <span class="et-label"><?= $row['label_esc'] ?></span>
                                    <?php if (!$row['documented']): ?>
                                    <span class="std-badge std-badge--muted et-driver-badge">driver</span>
                                    <?php endif; ?>
                                    <?php if ($row['desc_esc'] !== ''): ?>
                                    <span class="et-desc" title="<?= $row['desc_esc'] ?>">ⓘ</span>
                                    <?php endif; ?>
                                </div>
                                <div class="et-row-ctl">
                                    <?php if ($row['type'] === 'bool'): ?>
                                    <label class="std-switch">
                                        <input type="checkbox" class="js-et-value" value="1"
                                            data-original="<?= $row['ctl_original'] ?>" <?= $row['checked_attr'] ?> <?= $row['disabled_attr'] ?>>
                                        <span class="std-switch-slider" data-off="Off" data-on="On"></span>
                                    </label>
                                    <?php elseif ($row['type'] === 'int'): ?>
                                    <input type="number" class="std-grid-input js-et-value et-num"
                                        value="<?= $row['num_val'] ?>" data-original="<?= $row['num_val'] ?>" <?= $row['disabled_attr'] ?>>
                                    <?php else: ?>
                                    <span class="et-raw"><?= $row['live_esc'] ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="et-row-meta">
                                    <span class="et-live">NIC: <?= $row['live_esc'] ?></span>
                                    <?php if (!empty($row['has_stored'])): ?>
                                    <span class="et-stored">Configured: <?= $row['stored_esc'] ?><?= $row['source_esc'] !== '' ? ' (' . $row['source_esc'] . ')' : '' ?></span>
                                    <?php endif; ?>
                                    <?php if (!$row['present']): ?>
                                    <span class="et-absent">not exposed by NIC</span>
                                    <?php endif; ?>
                                    <?php if ($row['type'] !== 'none' && !$row['editable'] && $row['present']): ?>
                                    <span class="et-absent">fixed by NIC</span>
                                    <?php endif; ?>
                                    <?php if (!empty($row['editable']) && !empty($row['has_stored'])): ?>
                                    <button type="button" class="std-btn et-action et-restore js-et-delete" title="Delete this override (the NIC reverts to its original value)">Restore</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php if (empty($family['etf_groups'])): ?>
                        <div class="et-empty">No settings in this family.</div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="et-unsupported"><?= $family['etf_read_error_esc'] !== '' ? $family['etf_read_error_esc'] : 'This family is not supported on this NIC.' ?></div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>

                <button type="submit" id="iface-ethtool-submit" <?= empty($t['et_can_edit']) ? 'disabled' : '' ?>>
                    Save changes
                </button>
            </form>

            <?php endif; ?>
        </div>
    </div>
</div>
