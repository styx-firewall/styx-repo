<?php
/**
 * Network Discovery - Settings tab fragment.
 * Loaded via load_tpl into the net-discovery main template.
 * Expects $tdata['tpl_data'] with key: settings.
 *
 * @var array<mixed> $tdata
 */

$settings = $tdata['tpl_data']['settings'] ?? [];
$features = $settings['features'] ?? [];
$maxWanHops = (int)($settings['max_wan_hops'] ?? 0);
$sweepDelay = (float)($settings['sweep_delay'] ?? 0);
?>
<div class="disc-settings-container">
    <h3>Discovery Settings</h3>

    <!-- Status readout -->
    <div class="disc-settings-status">
        <span class="disc-settings-label">Service:</span>
        <span class="disc-settings-value">
            <?php if (($settings['running'] ?? false) && !($settings['paused'] ?? false)): ?>
                <span class="std-badge std-badge--success std-badge--dot">Running</span>
            <?php elseif (($settings['running'] ?? false) && ($settings['paused'] ?? false)): ?>
                <span class="std-badge std-badge--warning std-badge--dot">Paused</span>
            <?php else: ?>
                <span class="std-badge std-badge--danger std-badge--dot">Stopped</span>
            <?php endif; ?>
        </span>
    </div>
    <div class="disc-settings-status">
        <span class="disc-settings-label">Sweep delay:</span>
        <span class="disc-settings-value"><?= number_format($sweepDelay, 1) ?> s</span>
    </div>

    <!-- Settings form -->
    <form id="disc-settings-form" data-js="disc-settings-form" class="disc-settings-form">
        <!-- Max WAN hops -->
        <fieldset class="disc-settings-fieldset">
            <legend>Max WAN Hops</legend>
            <div class="disc-settings-row">
                <label for="disc-max-wan-hops" class="disc-settings-label">
                    Max WAN hops to trace:
                </label>
                <input type="number" id="disc-max-wan-hops" name="max_wan_hops"
                       class="std-input disc-settings-input-num"
                       value="<?= (int)$maxWanHops ?>"
                       min="1" max="10" />
                <span class="disc-settings-hint">Applied immediately.</span>
            </div>
        </fieldset>

        <!-- Feature toggles -->
        <fieldset class="disc-settings-fieldset">
            <legend>Feature Toggles</legend>
            <div class="disc-settings-features">
                <?php foreach ($features as $key => $f): ?>
                <div class="disc-settings-feature-row">
                    <label class="std-switch">
                        <input type="checkbox"
                               name="features[<?= $key ?>]"
                               value="1"
                               <?= $f['enabled'] ? 'checked' : '' ?>
                               data-js="disc-feature-toggle"
                               data-feature="<?= $key ?>"
                               data-runtime="<?= $f['runtime'] ? '1' : '0' ?>" />
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                    <span class="disc-feature-text">
                        <strong><?= $f['label'] ?></strong>
                        <small><?= $f['desc'] ?></small>
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
        </fieldset>

        <div class="disc-settings-actions">
            <button type="submit" class="std-btn" data-js="disc-settings-save">Save Settings</button>
            <span class="disc-settings-feedback" data-js="disc-settings-feedback"></span>
        </div>
    </form>
</div>
