<?php
/**
 * Fragment: Advanced Options for interface management
 * Expects $tdata with tpl_data
 */

$iface_subtype = $tdata['tpl_data']['iface_subtype'] ?? '';
$iface_config = $tdata['tpl_data']['iface_config'] ?? [];
$mtu_value = $tdata['tpl_data']['mtu_value'] ?? '';
$mac_disabled = $tdata['tpl_data']['mac_disabled'] ?? false;
$show_mac = $tdata['tpl_data']['show_mac'] ?? false;
$pppoe = $tdata['tpl_data']['pppoe'] ?? [];
// System loopback `lo`: MTU and MAC are kernel-managed and must not be edited.
$is_loopback = !empty($tdata['tpl_data']['is_system_loopback']);

?>
<div id="advanced-collapse-box" class="std-collapse-box im-margin-top0">
    <div class="std-collapse-header" onclick="this.parentNode.classList.toggle('open')">
        Advanced Options
    </div>
    <div class="std-collapse-content">
        <?php if ($is_loopback): ?>
            <label>
                MTU
                <span class="im-note"><?= $mtu_value ?: '65536' ?> (kernel-managed)</span>
            </label>
        <?php else: ?>
            <label>
                MTU
                <input type="number"
                    name="mtu"
                    value="<?= $mtu_value ?>"
                    min="576"
                    max="9000"
                    step="1">
            </label>
        <?php endif; ?>
        <?php if ($show_mac && !$is_loopback): ?>
            <label id="mac_address_field">
                MAC address
                <input type="text" name="mac" value="<?= $iface_config['mac'] ?>" <?= $mac_disabled ? 'disabled' : '' ?>>
            </label>
        <?php endif; ?>

        <?php if ($iface_subtype === 'bridge'): ?>
            <label>
                STP enable
                <input
                    type="checkbox"
                    name="stp"
                    value="1"
                    <?= !empty($iface_config['stp']) ? 'checked' : '' ?>
                >
            </label>
            <label>
                Forward delay
                <input
                    type="number"
                    name="forward_delay"
                    value="<?= $iface_config['forward_delay'] ?>"
                    min="0"
                    max="30"
                >
            </label>
        <?php endif; ?>

        <?php if ($iface_subtype === 'bond'): ?>
            <label>
                Primary slave
                <input
                    type="text"
                    name="primary_slave"
                    value="<?= $iface_config['primary_slave'] ?>"
                >
            </label>
            <label>
                LACP rate
                <select name="lacp_rate">
                    <option value="">Default</option>
                    <option
                        value="fast"
                        <?= $iface_config['lacp_rate'] === 'fast' ? 'selected' : '' ?>
                    >Fast</option>
                    <option
                        value="slow"
                        <?= $iface_config['lacp_rate'] === 'slow' ? 'selected' : '' ?>
                    >Slow</option>
                </select>
            </label>
            <label>
                MIIMON
                <input
                    type="number"
                    name="miimon"
                    value="<?= $iface_config['miimon'] ?>"
                    min="0"
                >
            </label>
            <label>
                Updelay
                <input
                    type="number"
                    name="updelay"
                    value="<?= $iface_config['updelay'] ?>"
                    min="0"
                >
            </label>
            <label>
                Downdelay
                <input
                    type="number"
                    name="downdelay"
                    value="<?= $iface_config['downdelay'] ?>"
                    min="0"
                >
            </label>
        <?php endif; ?>

        <?php if ($iface_subtype === 'pppoe'): ?>
            <label>
                MRU
                <input
                    type="number"
                    name="pppoe[mru]"
                    value="<?= $pppoe['mru'] ?? '' ?>"
                    min="576"
                    max="1492"
                >
            </label>
            <label>
                Service name
                <input
                    type="text"
                    name="pppoe[service_name]"
                    value="<?= $pppoe['service_name'] ?? '' ?>"
                >
            </label>
            <label>
                AC name
                <input type="text" name="pppoe[ac_name]" value="<?= $pppoe['ac_name'] ?? '' ?>">
            </label>
            <label>
                <input
                    type="checkbox"
                    name="pppoe[persist]"
                    value="1"
                    <?= !empty($pppoe['persist']) ? 'checked' : '' ?>
                >
                Persist (auto-reconnect)
            </label>
            <label>
            <input
                type="checkbox"
                name="pppoe[defaultroute]"
                value="1"
                <?= !empty($pppoe['defaultroute']) ? 'checked' : '' ?>
            >
                Default route
            </label>
            <label>
            <input
                type="checkbox"
                name="pppoe[usepeerdns]"
                value="1"
                <?= !empty($pppoe['usepeerdns']) ? 'checked' : '' ?>
            >
                Use peer DNS
            </label>
            <label>
            <input
                type="checkbox"
                name="pppoe[noauth]"
                value="1"
                <?= !empty($pppoe['noauth']) ? 'checked' : '' ?>
                id="noauth_checkbox"
            >
                No authentication (peer)
            </label>
            <label>
                LCP echo interval
                <input
                    type="number"
                    name="pppoe[lcp_echo_interval]"
                    value="<?= $pppoe['lcp_echo_interval'] ?? '' ?>"
                    min="0"
                >
            </label>
            <label>
                LCP echo failure
                <input
                    type="number"
                    name="pppoe[lcp_echo_failure]"
                    value="<?= $pppoe['lcp_echo_failure'] ?? '' ?>"
                    min="0"
                >
            </label>
            <label>
                Idle timeout (sec)
                <input type="number" name="pppoe[idle]" value="<?= $pppoe['idle'] ?? '' ?>" min="0">
            </label>
            <label>
                Holdoff (sec)
                <input
                    type="number"
                    name="pppoe[holdoff]"
                    value="<?= $pppoe['holdoff'] ?? '' ?>"
                    min="0"
                >
            </label>
            <label>
                Max fail
                <input
                    type="number"
                    name="pppoe[maxfail]"
                    value="<?= $pppoe['maxfail'] ?? '' ?>"
                    min="0"
                >
            </label>
            <label>
                IP param
                <input type="text" name="pppoe[ipparam]" value="<?= $pppoe['ipparam'] ?? '' ?>">
            </label>
        <?php endif; ?>
    </div>
</div>
