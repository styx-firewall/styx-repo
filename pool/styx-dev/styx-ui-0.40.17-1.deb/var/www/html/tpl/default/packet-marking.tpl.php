<?php

/**
 * TemplateService->getTpl()
 *
 * @var array<mixed> $tdata
 * js: tpl/default/packet-marking.js
 * css: tpl/default/packet-marking.css
 */
$page_data   = $tdata['page_data'];
$chains      = $page_data['chains'];
$protocols   = $page_data['protocols'];
$rules       = $page_data['rules'];

?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <!-- Sidebar placeholder -->
    <div><?= $tdata['sidebar'] ?? '' ?></div>

    <main class="page-content pm-theme">
        <h1>Packet Marking</h1>

        <!-- Row 1: Active rules -->
        <div class="section-full">
            <div class="card">
                    <div class="card-header">
                    <h2 class="card-heading">Active Rules</h2>
                    <span class="std-badge std-badge--chain"><?= count($rules) ?> rules</span>
                </div>
                <div class="card-body card-body--flush">
                    <table class="std-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Chain</th>
                                <th>Protocol</th>
                                <th>Interfaces (set)</th>
                                <th>Source IP (set)</th>
                                <th>Dst IP (set)</th>
                                <th>Ports (set)</th>
                                <th>Mark</th>
                                <th>Mark Target</th>
                                <th>Priority</th>
                                <th>Family</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rules as $rule):
                                $ifaceSetDisplay   = $rule['iface_set_display']   ?? null;
                                $srcAddrDisplay    = $rule['src_addr_display']    ?? null;
                                $dstAddrDisplay    = $rule['dst_addr_display']    ?? null;
                                $dstPortDisplay    = $rule['dst_port_display']    ?? null;
                                $srcPortDisplay    = $rule['src_port_display']    ?? null;
                                $markDisplay       = $rule['mark_display']        ?? null;
                            ?>
                            <tr>
                                <!-- ID -->
                                <td>
                                    <span class="pm-uuid-copy" title="Click to copy" onclick="copyText('<?= $rule['id'] ?>', this)">
                                        <span class="std-badge std-badge--uuid"><?= substr($rule['id'], 0, 8) ?>...</span>
                                    </span>
                                </td>
                                <!-- Name -->
                                <td style="font-weight:600; color:var(--text-bright);"><?= $rule['name'] ?></td>
                                <!-- Chain -->
                                <td><span class="std-badge std-badge--chain"><?= $chains[$rule['chain']] ?? $rule['chain'] ?></span></td>
                                <!-- Protocol -->
                                <td><span class="std-badge std-badge--proto"><?= strtoupper($rule['protocol']) ?></span></td>
                                <!-- Interface set -->
                                <td>
                                    <?php if ($ifaceSetDisplay): ?>
                                        <span class="set-ref" title="ID: <?= $ifaceSetDisplay['id'] ?>">
                                            <?php if (!empty($rule['iface_dir'])): ?>
                                                <span class="set-type"><?= $rule['iface_dir'] ?></span>
                                            <?php endif; ?>
                                            <span class="set-name"><?= $ifaceSetDisplay['name'] ?></span>
                                        </span>
                                    <?php elseif (!empty($rule['iface_dir'])): ?>
                                        <span class="text-dim"><?= $rule['iface_dir'] ?></span>
                                    <?php else: ?>
                                        <span class="text-dim">-</span>
                                    <?php endif; ?>
                                </td>
                                <!-- Source IP set -->
                                <td>
                                    <?php if ($srcAddrDisplay): ?>
                                        <span class="set-ref" title="ID: <?= $srcAddrDisplay['id'] ?>">
                                            <span class="set-type"><?= $srcAddrDisplay['family'] ?? '' ?></span>
                                            <span class="set-name"><?= $srcAddrDisplay['name'] ?></span>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-dim">-</span>
                                    <?php endif; ?>
                                </td>
                                <!-- Dst IP set -->
                                <td>
                                    <?php if ($dstAddrDisplay): ?>
                                        <span class="set-ref" title="ID: <?= $dstAddrDisplay['id'] ?>">
                                            <span class="set-type"><?= $dstAddrDisplay['family'] ?? '' ?></span>
                                            <span class="set-name"><?= $dstAddrDisplay['name'] ?></span>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-dim">-</span>
                                    <?php endif; ?>
                                </td>
                                <!-- Port set -->
                                <td>
                                    <?php if ($dstPortDisplay): ?>
                                        <span class="set-ref" title="ID: <?= $dstPortDisplay['id'] ?>">
                                            <span class="set-type">port</span>
                                            <span class="set-name"><?= $dstPortDisplay['name'] ?></span>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-dim">-</span>
                                    <?php endif; ?>
                                </td>
                                <!-- Mark -->
                                <td>
                                    <?php if ($markDisplay): ?>
                                        <span class="std-badge std-badge--mark" title="<?= $markDisplay['value'] ?>">
                                            <?= $markDisplay['name'] ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-dim"><?= $rule['mark'] ?></span>
                                    <?php endif; ?>
                                </td>
                                <!-- Mark target -->
                                <td>
                                    <span class="std-badge std-badge--muted"><?= $rule['mark_target'] ?></span>
                                </td>
                                <!-- Priority -->
                                <td>
                                    <?php if (isset($rule['priority']) && $rule['priority'] !== null): ?>
                                        <span class="std-badge std-badge--priority"><?= $rule['priority'] ?></span>
                                    <?php else: ?>
                                        <span class="text-dim">-</span>
                                    <?php endif; ?>
                                </td>
                                <!-- Family -->
                                <td>
                                    <span class="std-badge std-badge--family"><?= $rule['family'] ?></span>
                                </td>
                                <!-- Status -->
                                <td>
                                    <?php if ($rule['active']): ?>
                                        <span class="std-badge std-badge--success std-badge--dot">Active</span>
                                    <?php else: ?>
                                        <span class="std-badge std-badge--muted std-badge--dot">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <!-- Actions -->
                                <td>
                                    <div class="btn-group">
                                        <button class="std-btn std-btn-edit" data-id="<?= $rule['id'] ?>" data-action="edit-rule" aria-label="Edit" title="Edit"></button>
                                        <button class="std-btn std-btn-delete" data-id="<?= $rule['id'] ?>" data-action="delete-rule" aria-label="Delete" title="Delete"></button>
                                        <button class="std-btn <?= $rule['active'] ? 'std-btn-play' : 'std-btn-pause' ?>" data-id="<?= $rule['id'] ?>" data-action="toggle-rule" aria-label="<?= $rule['active'] ? 'Deactivate' : 'Activate' ?>" title="<?= $rule['active'] ? 'Deactivate' : 'Activate' ?>"></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Row 2: Add new rule (condition builder) -->
        <div class="section-full">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-heading">Add New Rule</h2>
                </div>
                <div class="card-body">

                    <!-- Top row: name, chain, proto, mark, state -->
                    <div class="std-form">
                    <div class="form-row" style="margin-bottom:1.2rem;">
                        <div class="form-col">
                            <label class="form-label" for="rule_name">Rule name
                                <span class="js-info-icon" data-info-modal="help-pm-rule-name"></span>
                            </label>
                            <input type="text" class="form-control" id="rule_name" placeholder="e.g. SSH from LAN" required>
                        </div>
                        <div class="form-col">
                            <label class="form-label" for="rule_chain">Chain
                                <span class="js-info-icon" data-info-modal="help-pm-chain"></span>
                            </label>
                            <select class="form-select" id="rule_chain" required>
                                <?php foreach ($chains as $k => $v): ?>
                                    <option value="<?= $k ?>"><?= $v ?></option>
                                <?php endforeach; ?>
                            </select>
                            <span id="h_chain" class="hint"></span>
                        </div>
                        <div class="form-col">
                            <label class="form-label">Protocol
                                <span class="js-info-icon" data-info-modal="help-pm-protocol"></span>
                            </label>
                            <select class="form-select" id="rule_proto">
                                <?php
                                // Protocol-family binding: some protocols are family-specific
                                $proto_family_bind = ['icmp' => 'ip', 'icmpv6' => 'ip6'];
                                foreach ($protocols as $k => $v):
                                    $pf = $proto_family_bind[$k] ?? 'both';
                                ?>
                                    <option value="<?= $k ?>" data-family="<?= $pf ?>"><?= $v ?></option>
                                <?php endforeach; ?>
                            </select>
                            <span id="h_proto" class="hint"></span>
                        </div>
                        <div class="form-col">
                            <label class="form-label" for="rule_family">IP family
                                <span class="js-info-icon" data-info-modal="help-pm-family"></span>
                            </label>
                            <select class="form-select" id="rule_family" required>
                                <option value="ip">IPv4</option>
                                <option value="ip6">IPv6</option>
                            </select>
                        </div>
                        <div class="form-col">
                            <label class="form-label" for="rule_mark_target">Mark target
                                <span class="js-info-icon" data-info-modal="help-pm-mark-target"></span>
                            </label>
                            <select class="form-select" id="rule_mark_target" required>
                                <option value="meta" selected>meta</option>
                                <option value="ct">ct</option>
                            </select>
                            <span id="h_mark_target" class="hint"></span>
                        </div>
                        <div class="form-col">
                            <label class="form-label">Mark value
                                <span class="js-info-icon-red" data-info-modal="help-pm-mark"></span>
                            </label>
                            <div class="set-picker-field"
                                 data-js="label-picker-field"
                                 data-set-type="packet_marking"
                                 data-max-select="1"
                                 data-label-title="Select mark value">
                                <input type="hidden" id="rule_mark" value="">
                                <button type="button"
                                        class="std-btn-picker set-picker-trigger js-set-picker-open"
                                        data-placeholder="- select mark -">
                                    <span class="js-set-picker-label">- select mark -</span>
                                </button>
                                <button type="button"
                                        class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                        title="Clear selection">&#215;</button>
                            </div>
                        </div>
                        <div class="form-col">
                            <label class="form-label">Priority
                                <span class="js-info-icon" data-info-modal="help-pm-priority"></span>
                            </label>
                            <input type="number" class="form-control" id="rule_priority"
                                   placeholder="e.g. 10" min="0" max="99999" step="1">
                        </div>
                        <div class="form-col">
                            <label class="form-label">Initial state
                                <span class="js-info-icon" data-info-modal="help-pm-initial-state"></span>
                            </label>
                            <select class="form-select" id="rule_active">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                    </div>

                    <!-- Condition builder fields (tabs removed) -->
                    <div style="margin-bottom:.75rem;">
                        <label class="form-label">Condition</label>

                        <div class="form-row" style="margin-bottom:.8rem;">
                            <!-- Interface direction -->
                            <div class="form-col">
                                <label class="form-label">Interface direction
                                    <span class="js-info-icon" data-info-modal="help-pm-iface-dir"></span>
                                </label>
                                <select class="form-select" id="f_iface_dir">
                                    <option value="">- none -</option>
                                    <option value="iifname">iifname (input)</option>
                                    <option value="oifname">oifname (output)</option>
                                </select>
                                <span id="h_iface_dir" class="hint"></span>
                            </div>
                            <!-- Interface set -->
                            <div class="form-col">
                                <label class="form-label">Interface set
                                    <span class="js-info-icon" data-info-modal="help-pm-iface-set"></span>
                                </label>
                                <div class="set-picker-field"
                                     data-js="set-picker-field"
                                     data-set-type="interfaces"
                                     data-max-select="1">
                                    <input type="hidden" id="f_iface_set" name="f_iface_set" value="">
                                    <button type="button"
                                            class="std-btn-picker set-picker-trigger js-set-picker-open"
                                            data-placeholder="- none -">
                                        <span class="js-set-picker-label"> -  none  - </span>
                                    </button>
                                    <button type="button"
                                            class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                            title="Clear selection">&#215;</button>
                                </div>
                                <span id="h_iface_set" class="hint"></span>
                            </div>
                            <!-- Source IP set -->
                            <div class="form-col">
                                <label class="form-label">Source IP set
                                    <span class="js-info-icon" data-info-modal="help-pm-src-addr"></span>
                                </label>
                                <div class="set-picker-field"
                                     data-js="set-picker-field"
                                     data-set-type="address"
                                     data-filter-family="ip"
                                     data-max-select="1">
                                    <input type="hidden" id="f_src_addr" name="f_src_addr" value="">
                                    <button type="button"
                                            class="std-btn-picker set-picker-trigger js-set-picker-open"
                                            data-placeholder="- any -">
                                        <span class="js-set-picker-label">- any -</span>
                                    </button>
                                    <button type="button"
                                            class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                            title="Clear selection">&#215;</button>
                                </div>
                                <span id="h_src_addr" class="hint"></span>
                            </div>
                            <!-- Dst IP set -->
                            <div class="form-col">
                                <label class="form-label">Dst IP set
                                    <span class="js-info-icon" data-info-modal="help-pm-dst-addr"></span>
                                </label>
                                <div class="set-picker-field"
                                     data-js="set-picker-field"
                                     data-set-type="address"
                                     data-filter-family="ip"
                                     data-max-select="1">
                                    <input type="hidden" id="f_dst_addr" name="f_dst_addr" value="">
                                    <button type="button"
                                            class="std-btn-picker set-picker-trigger js-set-picker-open"
                                            data-placeholder="- any -">
                                        <span class="js-set-picker-label">- any -</span>
                                    </button>
                                    <button type="button"
                                            class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                            title="Clear selection">&#215;</button>
                                </div>
                                <span id="h_dst_addr" class="hint"></span>
                            </div>
                            <!-- Src port set -->
                            <div class="form-col">
                                <label class="form-label">Src port set
                                    <span class="js-info-icon" data-info-modal="help-pm-src-port"></span>
                                </label>
                                <div class="set-picker-field"
                                     data-js="set-picker-field"
                                     data-set-type="ports"
                                     data-max-select="1">
                                    <input type="hidden" id="f_src_port" name="f_src_port" value="">
                                    <button type="button"
                                            class="std-btn-picker set-picker-trigger js-set-picker-open"
                                            data-placeholder=" -  none  - ">
                                        <span class="js-set-picker-label"> -  none  - </span>
                                    </button>
                                    <button type="button"
                                            class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                            title="Clear selection">&#215;</button>
                                </div>
                                <span id="h_src_port" class="hint"></span>
                            </div>
                            <!-- Dst port set -->
                            <div class="form-col">
                                <label class="form-label">Dst port set
                                    <span class="js-info-icon" data-info-modal="help-pm-dst-port"></span>
                                </label>
                                <div class="set-picker-field"
                                     data-js="set-picker-field"
                                     data-set-type="ports"
                                     data-max-select="1">
                                    <input type="hidden" id="f_dst_port" name="f_dst_port" value="">
                                    <button type="button"
                                            class="std-btn-picker set-picker-trigger js-set-picker-open"
                                            data-placeholder="- none -">
                                        <span class="js-set-picker-label">- none -</span>
                                    </button>
                                    <button type="button"
                                            class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                            title="Clear selection">&#215;</button>
                                </div>
                                <span id="h_dst_port" class="hint"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Preview -->
                    <div style="margin-top:1rem; margin-bottom:1.2rem;">
                        <label class="form-label">Generated condition preview</label>
                        <div class="condition-preview" id="condition_preview"></div>
                    </div>

                    </div> <!-- .std-form -->

                    <div style="display:flex; justify-content:flex-end;">
                        <button type="button" class="std-btn" onclick="submitRule()">
                            <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M3 8l4 4 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            Add Rule
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Help content for Packet Marking form (referenced by data-info-modal) -->
<div id="help-pm-rule-name" style="display:none">
    <p><strong>Rule name</strong>: Short descriptive name for the rule (shown in lists).</p>
</div>
<div id="help-pm-chain" style="display:none">
    <p><strong>Chain</strong>: Select where the rule is evaluated. Common options:</p>
    <ul>
        <li><strong>Input</strong>: Packets destined to the local system (ingress to host).</li>
        <li><strong>Output</strong>: Packets originating from the local system (egress from host).</li>
        <li><strong>Forward</strong>: Packets being routed through the system (transit).</li>
        <li><strong>Prerouting</strong>: Early hook for packets before routing decisions (useful for DNAT/marking before route lookup).</li>
        <li><strong>Postrouting</strong>: Late hook for packets after routing decisions (useful for SNAT/cleanup).</li>
        <li><strong>Ingress</strong>: Interface-level ingress hook (match incoming interface-specific traffic).</li>
        <li><strong>Egress</strong>: Interface-level egress hook (match outgoing interface-specific traffic).</li>
    </ul>
    <p>Choose the chain that best matches where you need the packet marking to occur.</p>
</div>
<div id="help-pm-protocol" style="display:none">
    <p><strong>Protocol</strong>: Protocol to match (TCP, UDP, ICMP) or choose Any.</p>
</div>
<div id="help-pm-mark" style="display:none">
    <p><strong>Mark value</strong>: Numeric mark assigned to matching packets.</p>
</div>
<div id="help-pm-priority" style="display:none">
    <p><strong>Priority</strong>: Rule evaluation priority within the chain.</p>
    <p>Lower values are evaluated first. If not set, the rule uses the chain default.</p>
    <p>Useful for ordering rules that match overlapping traffic (e.g. a specific exception before a broad catch-all).</p>
</div>
<div id="help-pm-initial-state" style="display:none">
    <p><strong>Initial state</strong>: Whether the rule is active immediately after creation.</p>
</div>
<div id="help-pm-iface-dir" style="display:none">
    <p><strong>Interface direction</strong>: Choose whether to match incoming (iifname) or outgoing (oifname) interfaces.</p>
</div>
<div id="help-pm-iface-set" style="display:none">
    <p><strong>Interface set</strong>: Pick an interface set to match traffic on specific interfaces.</p>
</div>
<div id="help-pm-src-addr" style="display:none">
    <p><strong>Source IP set</strong>: Select an IP set to match packet sources.</p>
</div>
<div id="help-pm-dst-addr" style="display:none">
    <p><strong>Dst IP set</strong>: Select an IP set to match packet destinations.</p>
</div>
<div id="help-pm-src-port" style="display:none">
    <p><strong>Src port set</strong>: Choose a port set to match source ports.</p>
</div>
<div id="help-pm-dst-port" style="display:none">
    <p><strong>Dst port set</strong>: Choose a port set to match destination ports.</p>
</div>
<div id="help-pm-condition" style="display:none">
    <p><strong>Condition</strong>: The generated nftables expression used to mark matching packets.</p>
</div>
