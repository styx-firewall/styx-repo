<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */

$audit_groups = $tdata['page_data']['audit']['sec_audit_groups'] ?? [];
$totals = $tdata['page_data']['audit']['totals'] ?? [];
$all_tags = $tdata['page_data']['audit']['all_tags'] ?? [];

?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Security Audit</h1>
        <div class="content-box">
            <?php
            echo $tdata['sec_overview_audit_frag'] ?? '<div class="empty">No audit data available.</div>';
            ?>
        </div>

        <?php if (!empty($audit_groups)) : ?>
        <div class="sec-audit-toolbar">
            <span class="sec-audit-count">
                <?= $totals['total'] ?? 0 ?> checks -
                <span class="pass-text"><?= $totals['passed'] ?? 0 ?> passed</span>,
                <span class="fail-text"><?= $totals['failed'] ?? 0 ?> failed</span>
            </span>
        </div>

        <div class="sec-tag-filter" id="secTagFilter">
            <button type="button" class="std-btn sec-run-audit" id="btn-run-audit">Run Audit</button>
            <?php if (!empty($all_tags)) : ?>
            <span class="sec-tag-filter-label">Filter:</span>
            <button class="sec-tag-btn sec-tag-active" data-tag="">All</button>
            <?php foreach ($all_tags as $tag) : ?>
            <button class="sec-tag-btn" data-tag="<?= $tag ?>"><?= $tag ?></button>
            <?php endforeach ?>
            <?php endif ?>
        </div>

        <?php foreach ($audit_groups as $severity => $group) : ?>
        <div class="content-box sec-audit-group">
            <div class="sec-audit-group-header sec-group-<?= $severity ?>">
                <span class="sec-group-label"><?= $group['label'] ?> Severity</span>
                <span class="sec-group-count"><?= count($group['rows']) ?> checks</span>
            </div>
            <table class="sec-audit-table">
                <thead>
                    <tr>
                        <th class="col-status">Status</th>
                        <th class="col-title">Check</th>
                        <th class="col-detail">Detail</th>
                        <th class="col-tags">Tags</th>
                        <th class="col-penalty">Penalty</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($group['rows'] as $row) : ?>
                    <tr class="sec-row-<?= $row['status_class'] ?>" data-tags='<?= $row['data_tags'] ?>'>
                        <td>
                            <span class="std-badge <?= $row['badge_class'] ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td class="sec-title">
                            <span class="sec-rule-label" title="<?= $row['rule'] ?>">
                                <?= $row['title'] ?>
                            </span>
                        </td>
                        <td class="sec-detail" title="<?= $row['detail'] ?>"><?= $row['detail'] ?></td>
                        <td class="sec-tags">
                            <?php if (!empty($row['tags'])) : ?>
                            <?php foreach ($row['tags'] as $tag) : ?>
                            <span class="sec-tag"><?= $tag ?></span>
                            <?php endforeach ?>
                            <?php endif ?>
                        </td>
                        <td class="sec-penalty">
                            <?php if ($row['penalty'] < 0) : ?>
                            <span class="penalty-neg"><?= $row['penalty'] ?></span>
                            <?php else : ?>
                            <span class="penalty-zero"><?= $row['penalty'] ?></span>
                            <?php endif ?>
                        </td>
                    </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
        <?php endforeach ?>

        <?php else : ?>
        <div class="content-box">
            <div class="empty">No check results available.</div>
        </div>
        <?php endif ?>
    </main>
</div>

<script>
(function() {
    var filter = document.getElementById('secTagFilter');
    if (!filter) return;

    var btns = filter.querySelectorAll('.sec-tag-btn');
    var rows = document.querySelectorAll('.sec-audit-table tbody tr');

    btns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var tag = this.getAttribute('data-tag');

            btns.forEach(function(b) { b.classList.remove('sec-tag-active'); });
            this.classList.add('sec-tag-active');

            rows.forEach(function(row) {
                if (!tag) {
                    row.classList.remove('sec-tag-hidden');
                    return;
                }
                var rowTags = row.getAttribute('data-tags');
                if (!rowTags) {
                    row.classList.add('sec-tag-hidden');
                    return;
                }
                try {
                    var tagsArr = JSON.parse(rowTags);
                    if (tagsArr.indexOf(tag) !== -1) {
                        row.classList.remove('sec-tag-hidden');
                    } else {
                        row.classList.add('sec-tag-hidden');
                    }
                } catch(e) {
                    row.classList.add('sec-tag-hidden');
                }
            });
        });
    });
})();
</script>

<script>
// Run Audit: force a fresh security audit (async background task on the gateway).
// The task shows up in the global TASKS panel; refresh to see updated results.
(function() {
    var btn = document.getElementById('btn-run-audit');
    if (!btn || typeof window.apiClient === 'undefined') return;

    function escHtml(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    function showRunAuditMsg(msg, isError) {
        var html = isError ? '<span style="color:#b00">' + escHtml(msg) + '</span>'
                           : '<span>' + escHtml(msg) + '</span>';
        if (typeof window.showModal === 'function') {
            window.showModal('<div style="margin-bottom:6px">' + html + '</div>', {
                title: 'Run Audit',
                closeText: 'OK'
            });
        } else {
            alert(msg);
        }
    }

    btn.addEventListener('click', function() {
        btn.disabled = true;
        window.apiClient.submit('run_sec_audit', {})
            .then(function(resp) {
                var r = resp && resp.response ? resp.response : resp;
                if (r && r.status === 'success') {
                    showRunAuditMsg('Audit started in background. Track progress in the TASKS panel and refresh when finished.');
                } else {
                    showRunAuditMsg((r && r.response_msg) ? r.response_msg : 'Run audit failed', true);
                }
            })
            .catch(function(err) {
                showRunAuditMsg((err && err.message) ? err.message : 'Run audit request failed', true);
            })
            .then(function() {
                btn.disabled = false;
            });
    });
})();
</script>
