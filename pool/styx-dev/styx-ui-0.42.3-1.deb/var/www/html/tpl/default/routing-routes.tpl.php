<?php
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div>
        <?= $tdata['sidebar'] ?>
    </div>
    <main class="page-content">
        <h1>System Routes</h1>
        <h2>Routes Content</h2>
        <div class="content-box">
        <!-- Tabs for navigation -->
        <div class="routes-tabs-container">
            <div id="routes-tabs" class="std-tabs">
                <button type="button"
                        id="routes-tab-view"
                        data-tab="view"
                        onclick="showTab('view')"
                        class="std-tab-btn tab-btn active">
                    Routes View
                </button>
                <button type="button"
                        id="routes-tab-add"
                        data-tab="add"
                        onclick="showTab('add')"
                        class="std-tab-btn tab-btn">
                    Add Route
                </button>
            </div>
            <div id="tab-content-view" data-tab="view" class="tab-content-view std-tab-panel active">
                <?= $tdata['routes_view'] ?? '' ?>
            </div>
            <div id="tab-content-add" data-tab="add" class="std-tab-panel tab-content-add">
                <?= $tdata['routes_add'] ?? '' ?>
            </div>
        </div>
    </main>
</div>
