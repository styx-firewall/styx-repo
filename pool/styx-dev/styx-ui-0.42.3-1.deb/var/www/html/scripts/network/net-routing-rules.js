/**
 * net-routing-rules.js
 * Client logic for Route Rules (ip rule) management.
 * Handles form preview, add/submit, delete, toggle, and edit operations.
 *
 * Dependencies:
 *   - api-client.js   (apiClient.submit)
 *   - common.js       (showApiResult, showModal)
 *   - labels-mgmt.js  (labelsMgmt.initPickerFields)
 */
(function (window) {
    'use strict';

    // Field helpers

    /** Returns trimmed string value of an input/select, or '' if missing. */
    function rrVal(id) {
        const el = document.getElementById(id);
        return el ? (el.value || '').trim() : '';
    }

    /** Returns checked state of a checkbox. */
    function rrChecked(id) {
        const el = document.getElementById(id);
        return el ? el.checked : false;
    }

    /**
     * Enables or disables a field (input/select) and its picker wrapper.
     * For hidden inputs inside a set-picker-field, also toggles the
     * picker buttons and clears the label.
     */
    function rrSetDisabled(id, disabled) {
        const el = document.getElementById(id);
        if (!el) return;
        el.disabled = disabled;
        if (disabled && el.value) el.value = '';

        rrSyncPickerState(el, disabled);

        const col = el.closest('.rr-col');
        if (col) col.classList.toggle('rr-disabled', disabled);
    }

    /** Keeps the picker wrapper buttons/label in sync with the field state. */
    function rrSyncPickerState(fieldEl, disabled) {
        if (fieldEl.type !== 'hidden') return;
        const wrapper = fieldEl.closest('[data-js="set-picker-field"], [data-js="label-picker-field"]');
        if (!wrapper) return;
        const openBtn  = wrapper.querySelector('.js-set-picker-open');
        const clearBtn = wrapper.querySelector('.js-set-picker-clear');
        const labelEl  = wrapper.querySelector('.js-set-picker-label');
        if (openBtn) {
            openBtn.disabled = disabled;
            if (disabled) openBtn.classList.remove('set-picker-trigger--has-value');
        }
        if (disabled) {
            if (clearBtn) clearBtn.classList.add('sets-hidden');
            if (labelEl) labelEl.textContent = openBtn?.dataset.placeholder || 'Select...';
        }
    }

    // Field dependency handlers

    /**
     * src and dst IPs are mutually exclusive: a value in one disables
     * (and clears) the other, and triggers its input handler.
     */
    function rrOnIpExclusive(selfId, otherId) {
        const hasVal = !!document.getElementById(selfId).value;
        rrSetDisabled(otherId, hasVal);
        if (hasVal) {
            document.getElementById(otherId).dispatchEvent(new Event('input', { bubbles: true }));
        }
        rrDebouncedBuild();
    }

    function rrOnSrcIp() {
        rrOnIpExclusive('rr_src_ip', 'rr_dst_ip');
    }

    function rrOnDstIp() {
        rrOnIpExclusive('rr_dst_ip', 'rr_src_ip');
    }

    /** sport / dport require an explicit proto (tcp or udp). */
    function rrOnProto() {
        const proto = rrVal('rr_proto');
        const needsProto = proto === 'tcp' || proto === 'udp';
        rrSetDisabled('rr_src_port', !needsProto);
        rrSetDisabled('rr_dst_port', !needsProto);
        rrDebouncedBuild();
    }

    /** Shows the routing table select only when action is 'lookup'. */
    function rrToggleLookup() {
        const action = rrVal('rr_action');
        const wrap = document.getElementById('rr_table_wrap');
        if (wrap) wrap.style.display = action === 'lookup' ? '' : 'none';
        rrDebouncedBuild();
    }

    // Debounced preview fetch (backend)

    let _rrPreviewTimer = null;

    /**
     * Fetches the ``ip rule`` preview from the backend without persisting.
     * Uses the same payload as ``rrCollectFormData``.
     */
    async function rrBuild() {
        const preview = document.getElementById('rr_preview');
        if (!preview) return;

        const payload = rrCollectFormData();
        const problem = rrValidatePayload(payload);
        if (problem) {
            preview.textContent = problem;
            return;
        }

        preview.textContent = 'Fetching preview...';

        try {
            const res = await apiClient.submit('preview_routing_rule', payload);
            const data = Array.isArray(res) ? res[0] : res;
            if (data && data.status === 'success' && data.result && data.result.ip_run) {
                preview.textContent = data.result.ip_run;
            } else if (data && data.response_msg) {
                preview.textContent = '⚠ ' + data.response_msg;
            } else {
                preview.textContent = '⚠ Preview error';
            }
        } catch (err) {
            preview.textContent = '⚠ ' + (err.message || 'Request failed');
        }
    }

    function rrDebouncedBuild() {
        if (_rrPreviewTimer) clearTimeout(_rrPreviewTimer);
        _rrPreviewTimer = setTimeout(rrBuild, 300);
    }

    // Collect form data

    /**
     * Gathers all form field values into a flat object
     * ready to send to submit.php.
     * Reads directly from hidden inputs (no intermediate selects).
     */
    function rrCollectFormData() {
        const data = {};

        data.name     = rrVal('rr_name');
        data.priority = rrVal('rr_priority');
        data.active   = rrVal('rr_active') === '1';
        data.invert   = rrChecked('rr_invert');

        // Match conditions
        data.mark     = rrVal('rr_mark')     || null;
        data.src      = rrVal('rr_src_ip')   || null;
        data.dst      = rrVal('rr_dst_ip')   || null;
        data.iif      = rrVal('rr_iface')    || null;
        data.proto    = rrVal('rr_proto')    || null;
        data.sport    = rrVal('rr_src_port') || null;
        data.dport    = rrVal('rr_dst_port') || null;

        // Action
        data.action   = rrVal('rr_action')   || 'lookup';
        data.table    = rrVal('rr_table')    || null;

        return data;
    }

    /**
     * Validates the collected payload.
     * Returns the first problem as a message, or null when valid.
     */
    function rrValidatePayload(data) {
        if (!data.name) return 'Please enter a rule name.';
        const hasMatcher = data.mark || data.src || data.dst
                          || data.iif || data.sport || data.dport;
        if (!hasMatcher) return 'Add at least one match condition.';
        if (data.action === 'lookup' && !data.table) {
            return 'A routing table is required for the lookup action.';
        }
        return null;
    }

    // Submit

    /**
     * Runs a mutating apiClient call and shows the result modal.
     * Reloads the list on success; shows the error modal on failure.
     */
    async function rrApiAction(action, payload, title) {
        try {
            const result = await apiClient.submit(action, payload);
            showApiResult(result, {
                title: title,
                closeText: 'Close',
                reloadOnOk: true,
                boxStyle: { maxWidth: '50vw', maxHeight: '50vh' }
            });
        } catch (err) {
            showApiResult({ ok: false, msg: err.message }, {
                title: 'Error',
                closeText: 'Close'
            });
        }
    }

    /** Add a new route rule via apiClient.submit(). */
    function rrSubmit() {
        const data = rrCollectFormData();
        const problem = rrValidatePayload(data);
        if (problem) {
            alert(problem);
            return;
        }
        rrApiAction('set_routing_rule', data, 'Add Route Rule');
    }

    /** Delete a route rule by UUID. */
    function rrDelete(id) {
        if (!id) return;
        if (!confirm('Are you sure you want to delete rule ' + id.substr(0, 8) + '\u2026 ?')) return;
        rrApiAction('delete_routing_rule', { id: id }, 'Delete Route Rule');
    }

    /** Toggle a route rule active/inactive. */
    function rrToggle(id, currentlyActive) {
        if (!id) return;
        rrApiAction('toggle_routing_rule', {
            id: id,
            active: !currentlyActive
        }, 'Toggle Route Rule');
    }

    /** Edit a route rule-opens a pre-filled form (stub). */
    function rrEdit(id) {
        // TODO: Implement inline edit or modal with pre-populated fields
        alert('Edit mode for rule ' + id.substr(0, 8) + '\u2026 is not yet implemented.');
    }

    // UUID copy

    function rrCopy(text, el) {
        if (!navigator.clipboard) {
            alert('Clipboard API not available.');
            return;
        }
        navigator.clipboard.writeText(text).then(() => {
            const orig = el.innerHTML;
            el.innerHTML = '<span class="std-badge std-badge--uuid">Copied!</span>';
            setTimeout(() => { el.innerHTML = orig; }, 1200);
        }).catch(() => {
            alert('Failed to copy to clipboard.');
        });
    }

    // Init

    document.addEventListener('DOMContentLoaded', function () {
        // Initial UI state
        rrToggleLookup();
        rrOnProto();

        // Preview rebuild on every form change
        ['rr_name', 'rr_priority', 'rr_invert', 'rr_mark', 'rr_iface',
            'rr_src_ip', 'rr_dst_ip', 'rr_src_port', 'rr_dst_port', 'rr_table'].forEach(function (id) {
                document.getElementById(id)?.addEventListener('input', rrDebouncedBuild);
        });
        ['rr_proto', 'rr_action', 'rr_active'].forEach(function (id) {
            document.getElementById(id)?.addEventListener('change', rrDebouncedBuild);
        });

        // Field dependencies
        document.getElementById('rr_src_ip')?.addEventListener('input', rrOnSrcIp);
        document.getElementById('rr_dst_ip')?.addEventListener('input', rrOnDstIp);
        document.getElementById('rr_proto')?.addEventListener('change', rrOnProto);
        document.getElementById('rr_action')?.addEventListener('change', rrToggleLookup);

        // Submit button
        document.querySelector('[data-rr-submit]')?.addEventListener('click', rrSubmit);

        // UUID copy
        document.querySelectorAll('[data-rr-copy]').forEach(function (el) {
            el.addEventListener('click', function () {
                const uuid = el.getAttribute('data-rr-copy');
                if (uuid) rrCopy(uuid, el);
            });
        });

        // Row action buttons via delegation (works with dynamic rows)
        document.querySelector('.rr-root')?.addEventListener('click', function (e) {
            const btn = e.target.closest('button');
            if (!btn) return;

            const id = btn.dataset.id;

            if (btn.classList.contains('rr-delete')) {
                e.preventDefault();
                rrDelete(id);
            } else if (btn.classList.contains('rr-toggle')) {
                e.preventDefault();
                rrToggle(id, btn.dataset.active === '1');
            } else if (btn.classList.contains('rr-edit')) {
                e.preventDefault();
                rrEdit(id);
            }
        });

        // Pickers (set pickers + label pickers, both used in the form)
        if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
            try {
                window.setsModal.initPickerFields(document);
            } catch (e) {
                console.error('setsModal init failed', e);
            }
        }
        if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
            window.labelsMgmt.initPickerFields(document);
        }
    });

})(window);
