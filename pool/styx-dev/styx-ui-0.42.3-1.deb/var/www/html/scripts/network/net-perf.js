// iPerf3 UI - Async server/client management

let serverPollingInterval = null;
let activeTaskPollers = new Map();
// Track which task results we've already rendered to avoid duplicates
let renderedTaskResults = new Set();
// Pending chart creators per result suffix (deferred when panel is collapsed)
let pendingChartCreators = new Map();
// Timer for the auto-dismissing iperf-response-msg alert
let iperfMessageTimer = null;

// Parse an API response: unwrap JSON strings, pick the first item when the
// server returned an array of responses, and normalize the `response`
// envelope.
function parseHandlerResponse(resp) {
    if (!resp) return null;
    try {
        if (typeof resp === 'string') {
            resp = JSON.parse(resp);
        }

        if (Array.isArray(resp) && resp.length > 0) {
            resp = resp[0];
        }

        // If nested under a `response` envelope, normalize
        if (resp.response && typeof resp.response === 'object') {
            return resp.response;
        }

        return resp;
    } catch (e) {
        console.error('Failed to parse handler response:', e, resp);
        return null;
    }
}

// Best-effort human message out of an error response
function buildHandlerErrorMessage(r) {
    if (!r) return 'Unknown error';
    if (r.response_msg) return r.response_msg;
    if (r.message) return r.message;
    if (r.error) return typeof r.error === 'string' ? r.error : JSON.stringify(r.error);
    if (r.result && r.result.msg) return r.result.msg;
    return 'Handler error: ' + (typeof r === 'string' ? r : JSON.stringify(r).slice(0, 200));
}

// UI message helper for this page.
// The alert is anchored to the section that triggered it (anchorEl), so it shows
// in context (e.g. under the Client form heading) instead of at the top of the
// page. Without an anchor it falls back to just under the page heading.
function showIperfMessage(msg, isError = false, timeout = 4000, anchorEl = null) {
    try {
        // Resolve where the alert belongs: inside the triggering content-box,
        // right after its heading.
        let host = null;
        let refNode = null;
        let section = null;
        if (anchorEl && typeof anchorEl.closest === 'function') {
            section = anchorEl.closest('section.content-box');
        }
        if (section) {
            host = section;
            const heading = section.querySelector(':scope > h1, :scope > h2, :scope > h3');
            refNode = heading ? heading.nextSibling : section.firstChild;
        } else {
            // Fallback: inside the page content, under its heading (never above it)
            host = document.querySelector('main.page-content') || document.body;
            const heading = host.querySelector(':scope > h1, :scope > h2');
            refNode = heading ? heading.nextSibling : host.firstChild;
        }

        let el = document.getElementById('iperf-response-msg');
        if (!el) {
            el = document.createElement('div');
            el.id = 'iperf-response-msg';
        }
        el.className = isError ? 'page-alert alert-error' : 'page-alert alert-info';
        el.textContent = String(msg);

        // Move it into the right host (re-insert once; keep position on repeats)
        if (el.parentNode !== host) {
            if (el.parentNode) el.parentNode.removeChild(el);
            host.insertBefore(el, refNode);
        }

        if (iperfMessageTimer) {
            clearTimeout(iperfMessageTimer);
            iperfMessageTimer = null;
        }
        if (timeout && timeout > 0) {
            iperfMessageTimer = setTimeout(() => {
                if (el && el.parentNode) el.parentNode.removeChild(el);
                iperfMessageTimer = null;
            }, timeout);
        }
    } catch (e) {
        console.error('showIperfMessage error:', e, msg);
    }
}

// Collect form fields into a plain object (skips empty strings, handles checkboxes)
function collectFormData(form) {
    const data = {};
    new FormData(form).forEach((value, key) => {
        const input = form.querySelector(`[name="${key}"]`);
        if (input && input.type === 'checkbox') {
            data[key] = input.checked;
        } else if (value.trim() !== '') {
            data[key] = value;
        }
    });
    return data;
}

// Parse API response and dispatch success/error uniformly.
// Calls onSuccess(r) when r.status === 'success', shows error otherwise.
// contextEl anchors the alert to the section that triggered the request.
function handleSubmitResponse(resp, onSuccess, contextEl) {
    const r = parseHandlerResponse(resp);
    if (!r) {
        showIperfMessage('Invalid response from server', true, 4000, contextEl);
        return;
    }
    if (r.status === 'success') {
        onSuccess(r);
    } else {
        showIperfMessage(buildHandlerErrorMessage(r), true, 4000, contextEl);
    }
}

// Submit a gateway action and route the outcome uniformly:
// success goes through handleSubmitResponse; failures are logged and shown
// as an alert anchored to the form that triggered the request.
// `failText` opens the failure message, e.g. 'Error starting server'.
function submitGatewayAction(action, failText, data, onSuccess, form) {
    apiClient.submit(action, data)
        .then(resp => handleSubmitResponse(resp, onSuccess, form))
        .catch(err => {
            appLog.error(failText + ': ' + err.message);
            showIperfMessage(failText + ': ' + (err.message || err), true, 4000, form);
        });
}

// Update server status UI
// Markup lives in the <template> blocks in net-perf.tpl.php; values are
// assigned via textContent, so there is no escaping/HTML-injection concern.
function updateServerStatus(status) {
    const running = status?.running ?? false;
    const pid = status?.pid ?? null;
    const port = status?.port ?? null;
    const startedAt = status?.started_at ?? null;

    const indicator = document.querySelector('#server-status .status-indicator');

    if (indicator) {
        const tpl = document.getElementById(running ? 'iperf-server-status-running' : 'iperf-server-status-stopped');
        if (tpl) {
            const frag = tpl.content.cloneNode(true);
            if (running) {
                const fill = (sel, val) => {
                    const el = frag.querySelector(sel);
                    if (el) el.textContent = val ?? '';
                };
                fill('.status-pid', pid);
                fill('.status-port', port);
                fill('.status-started', startedAt);
            }
            indicator.replaceChildren(frag);
        }
    }

    const btnStart = document.getElementById('btn-start-server');
    const btnStop = document.getElementById('btn-stop-server');
    if (btnStart) btnStart.disabled = running;
    if (btnStop) btnStop.disabled = !running;
}

// Poll server status
function pollServerStatus() {
    // Combined status+tasks request
    const statusPanel = document.querySelector('#server-status');
    apiClient.request('iperf_status_and_tasks', {})
        .then(resp => {
            const r = parseHandlerResponse(resp);
            if (!r) {
                showIperfMessage('Invalid response from server', true, 5000, statusPanel);
                return;
            }
            if (r.status === 'success') {
                updateServerStatus(r.result?.server_status || {});
                updateTasksList(r.result?.tasks || []);
            } else {
                showIperfMessage(buildHandlerErrorMessage(r), true, 5000, statusPanel);
            }
        })
        .catch(err => {
            console.error('Failed to poll status and tasks:', err);
            showIperfMessage('Error polling status/tasks: ' + (err.message || err), true, 5000, statusPanel);
        });
}

// Start server polling (every 3 seconds)
function startServerPolling() {
    if (serverPollingInterval) return;
    pollServerStatus();
    // 3s for the combined status+tasks request
    serverPollingInterval = setInterval(pollServerStatus, 3000);
}

// Start iperf server
function startServer() {
    const form = document.querySelector('[data-js="server-form"]');
    if (!form) return;
    const data = collectFormData(form);

    submitGatewayAction('iperf_start_server', 'Error starting server', data, r => {
        appLog.info('Server started successfully');
        showIperfMessage(r.response_msg || 'Server started', false, 4000, form);
        updateServerStatus(r.result || {});
        if (r.result?.stderr_head) {
            appLog.info('Server diagnostics: ' + r.result.stderr_head);
        }
    }, form);
}

// Stop iperf server
function stopServer() {
    const form = document.querySelector('[data-js="server-form"]');
    if (!form) return;

    submitGatewayAction('iperf_stop_server', 'Error stopping server', {}, r => {
        appLog.info('Server stopped successfully');
        showIperfMessage(r.response_msg || 'Server stopped', false, 4000, form);
        pollServerStatus();
    }, form);
}

// Start client test
function startClientTest() {
    const form = document.querySelector('[data-js="client-form"]');
    if (!form) return;
    const data = collectFormData(form);

    if (!data.server_ip || !data.server_ip.trim()) {
        appLog.warn('Server IP is required');
        return;
    }

    appLog.info('Starting client test...');

    submitGatewayAction('iperf_start_client_test', 'Error starting client test', data, r => {
        const taskId = r.result?.task_id;
        showIperfMessage(r.response_msg || 'Client test started', false, 4000, form);
        if (taskId) {
            appLog.info('Client test started, task ID: ' + taskId);
            startTaskPolling(taskId);
        }
    }, form);
}

// The gateway may report the same field under different names.
// Normalize the task state, mapping 'done' to 'completed'.
function normalizeTaskState(task) {
    const state = task.state || task.status || 'unknown';
    return state === 'done' ? 'completed' : state;
}

// Unwrap the result payload from the possible nested envelopes
// the gateway may wrap it in.
function extractTaskResultPayload(taskData) {
    if (taskData.result) {
        return taskData.result.data || taskData.result.result || taskData.result;
    }
    return taskData.result_data || taskData;
}

// A failed iperf3 run is stored as a *finished* task: the gateway keeps the
// service envelope returned by the runner, which flags the failure in `ok`
// while iperf3's own diagnostics sit in `data` (as JSON on stdout). Returns the
// message to show, or null when the task really succeeded.
function iperfFailureMessage(taskData) {
    const envelope = taskData?.result;
    if (!envelope || envelope.ok !== false) return null;
    const data = envelope.data || {};
    let message = data.stderr || '';
    try {
        const output = JSON.parse(data.stdout || '');
        message = output.error || message;
    } catch (e) {
        // stdout was not JSON: stderr is all we have
    }
    return message || envelope.msg || 'iperf test failed';
}

// Stop (and forget) the poller for a task, if any
function stopTaskPolling(taskId) {
    const intervalId = activeTaskPollers.get(taskId);
    if (intervalId !== undefined) {
        clearInterval(intervalId);
        activeTaskPollers.delete(taskId);
    }
}

// Poll a specific task result
function startTaskPolling(taskId) {
    if (activeTaskPollers.has(taskId)) return;

    const pollTaskResult = () => {
        apiClient.request('iperf_get_task_result', { task_id: taskId })
            .then(resp => {
                if (resp.status !== 'success' || !resp.result) return;
                const taskData = resp.result;
                const state = normalizeTaskState(taskData);

                if (state === 'completed' || state === 'error' || state === 'failed') {
                    stopTaskPolling(taskId);
                    const failure = iperfFailureMessage(taskData);
                    if (state === 'completed' && !failure) {
                        renderIperfResult(extractTaskResultPayload(taskData), { taskId });
                    } else {
                        const message = failure || taskData.error || taskData.response_msg || 'Unknown error';
                        appLog.error('Task failed: ' + message);
                        // Modal rather than the inline alert: the test dies long
                        // after the click, when the page may be scrolled away
                        showApiResult(
                            { status: 'error', response_msg: message },
                            { title: 'Test failed', closeText: 'Close' }
                        );
                    }
                }
            })
            .catch(err => {
                console.error('Error polling task result:', err);
                stopTaskPolling(taskId);
            });
    };

    pollTaskResult();
    const intervalId = setInterval(pollTaskResult, 2000);
    activeTaskPollers.set(taskId, intervalId);
}

// Update tasks list UI
// Items are cloned from the #iperf-task-item <template> (net-perf.tpl.php)
// and filled via textContent, so there is no string-built innerHTML.
function updateTasksList(tasks) {
    const container = document.querySelector('[data-js="tasks-list"]');
    if (!container) return;

    const taskEntries = Object.entries(tasks);
    container.replaceChildren();

    if (!taskEntries.length) {
        const emptyMsg = document.createElement('p');
        emptyMsg.textContent = 'No active tasks';
        container.appendChild(emptyMsg);
        return;
    }

    const list = document.createElement('ul');
    list.className = 'tasks-list';
    const itemTpl = document.getElementById('iperf-task-item');

    taskEntries.forEach(([taskId, task]) => {
        const state = normalizeTaskState(task);
        // If no explicit progress provided, map completed => 100
        let progress = typeof task.progress === 'number' ? task.progress : 0;
        if (state === 'completed' && progress === 0) progress = 100;

        const item = itemTpl
            ? itemTpl.content.firstElementChild.cloneNode(true)
            : document.createElement('li');
        item.classList.add('task-state-' + state);
        const fill = (sel, txt) => {
            const el = item.querySelector(sel);
            if (el) el.textContent = txt;
        };
        fill('.task-id', taskId);
        fill('.task-state', state);
        fill('.task-progress', progress + '%');
        list.appendChild(item);
    });

    container.appendChild(list);

    // Tasks that completed with a result payload are rendered immediately
    taskEntries.forEach(([taskId, task]) => {
        const state = normalizeTaskState(task);
        if (state === 'completed' && task.result && !renderedTaskResults.has(taskId)) {
            const payload = extractTaskResultPayload(task);
            if (payload) {
                try {
                    renderIperfResult(payload, { taskId });
                } catch (e) {
                    console.error('renderIperfResult failed:', e);
                }
                renderedTaskResults.add(taskId);
            }
            stopTaskPolling(taskId);
        }
    });
}

// Render iperf3 results into tables and charts.
//
// Static markup (result panel shell + per-graph item) is cloned from <template>
// blocks in net-perf.tpl.php. Rows/cells are created as DOM nodes and filled
// via textContent, so no gateway value is ever injected through innerHTML.

// Build a <thead> holding one colspan=2 header row (label/value tables)
function netPerfHeadRow(headText) {
    const thead = document.createElement('thead');
    const tr = document.createElement('tr');
    const th = document.createElement('th');
    th.colSpan = 2;
    th.textContent = headText;
    tr.appendChild(th);
    thead.appendChild(tr);
    return thead;
}

// Append a <tr> to <tbody>, writing each cell via textContent
function netPerfAddRow(tbody, cells) {
    const tr = document.createElement('tr');
    cells.forEach((text) => {
        const td = document.createElement('td');
        td.textContent = text;
        tr.appendChild(td);
    });
    tbody.appendChild(tr);
    return tr;
}

// Per-interval series for the graphs (labels are the chart x-axis)
function netPerfBuildSeries(intervals, protocol) {
    const tcp = protocol === 'TCP';
    const udp = protocol === 'UDP';
    return {
        labels: intervals.map((iv, i) => `${Math.round(iv.sum?.end || (i + 1))}s`),
        speeds: intervals.map(iv => iv.sum?.bits_per_second || 0),
        cwnd: tcp ? intervals.map(iv => iv.streams?.[0]?.snd_cwnd ?? null) : [],
        rtt: tcp ? intervals.map(iv => iv.streams?.[0]?.rtt ?? null) : [],
        jitter: udp ? intervals.map(iv => iv.sum?.jitter_ms ?? iv.sum?.jitter ?? null) : [],
        lostPackets: udp ? intervals.map(iv => iv.sum?.lost_packets ?? null) : [],
    };
}

// Summary table (label/value) for the sent/received totals
function netPerfBuildSummaryTable(protocol, end) {
    const sumSent = end.sum_sent || {};
    const sumReceived = end.sum_received || {};

    const table = document.createElement('table');
    table.className = 'std-table';
    table.appendChild(netPerfHeadRow(`Summary (${protocol})`));
    const tbody = document.createElement('tbody');
    netPerfAddRow(tbody, ['Duration', `${(sumSent.seconds || 0).toFixed(2)} s`]);
    netPerfAddRow(tbody, ['Bytes sent', window.formatBytes(sumSent.bytes ?? 0)]);
    netPerfAddRow(tbody, ['Average throughput', `${(sumSent.bits_per_second / 1e6).toFixed(2)} Mbps`]);
    if (protocol === 'TCP') netPerfAddRow(tbody, ['Retransmissions', sumSent.retransmits ?? '-']);
    netPerfAddRow(tbody, ['Bytes received', window.formatBytes(sumReceived.bytes ?? 0)]);
    netPerfAddRow(tbody, ['Average throughput received', `${(sumReceived.bits_per_second / 1e6).toFixed(2)} Mbps`]);
    if (protocol === 'UDP' && typeof sumReceived.lost_packets !== 'undefined') {
        netPerfAddRow(tbody, ['Lost packets', sumReceived.lost_packets]);
    }
    if (protocol === 'UDP' && typeof sumReceived.lost_percent !== 'undefined') {
        netPerfAddRow(tbody, ['Loss (%)', `${sumReceived.lost_percent.toFixed(2)}%`]);
    }
    table.appendChild(tbody);
    return table;
}

// CPU utilization table (a std-progress bar under each value);
// returns null when there is no CPU data
function netPerfBuildCpuTable(cpu) {
    if (!cpu || !Object.keys(cpu).length) return null;

    const table = document.createElement('table');
    table.className = 'std-table';
    table.appendChild(netPerfHeadRow('CPU Utilization (%)'));
    const tbody = document.createElement('tbody');

    const fields = [
        ['Host total', cpu.host_total],
        ['Host user', cpu.host_user],
        ['Host system', cpu.host_system],
        ['Remote total', cpu.remote_total],
        ['Remote user', cpu.remote_user],
        ['Remote system', cpu.remote_system],
    ];

    fields.forEach(([label, value]) => {
        const num = (typeof value === 'number' && isFinite(value)) ? value : null;
        const tr = document.createElement('tr');
        const tdLabel = document.createElement('td');
        tdLabel.textContent = label;
        tr.appendChild(tdLabel);
        const tdValue = document.createElement('td');
        tdValue.className = 'iperf-cpu-cell';
        const valSpan = document.createElement('span');
        valSpan.className = 'iperf-cpu-val';
        if (num !== null) {
            valSpan.textContent = num.toFixed(1);
            tdValue.appendChild(valSpan);
            const bar = document.createElement('div');
            bar.className = 'std-progress std-progress--sm';
            const fill = document.createElement('div');
            fill.className = 'std-progress-fill';
            fill.style.width = `${Math.min(100, num)}%`;
            bar.appendChild(fill);
            tdValue.appendChild(bar);
        } else {
            valSpan.classList.add('muted');
            valSpan.textContent = '-';
            tdValue.appendChild(valSpan);
        }
        tr.appendChild(tdValue);
        tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    return table;
}

// Full-width intervals table; returns null when empty or too many rows
function netPerfBuildIntervalsTable(intervals, protocol) {
    if (!intervals.length || intervals.length > 20) return null;

    const firstSum = intervals[0]?.sum || {};
    const showUdpLost = protocol === 'UDP' && typeof firstSum.lost_packets !== 'undefined';
    const showUdpLoss = protocol === 'UDP' && typeof firstSum.lost_percent !== 'undefined';

    const table = document.createElement('table');
    table.className = 'std-table';
    const thead = document.createElement('thead');
    const headTr = document.createElement('tr');
    const headCells = ['Interval', 'Seconds', 'Bytes', 'Mbps'];
    if (protocol === 'TCP') headCells.push('Retrans.');
    if (showUdpLost) headCells.push('Lost');
    if (showUdpLoss) headCells.push('Loss (%)');
    headCells.forEach((txt) => {
        const th = document.createElement('th');
        th.textContent = txt;
        headTr.appendChild(th);
    });
    thead.appendChild(headTr);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');
    intervals.forEach((iv, i) => {
        const s = iv.sum || {};
        const cells = [
            String(i + 1),
            s.seconds !== undefined && s.seconds !== null ? s.seconds.toFixed(2) : '-',
            window.formatBytes(s.bytes ?? 0),
            `${(s.bits_per_second / 1e6).toFixed(2)}`,
        ];
        if (protocol === 'TCP') cells.push(s.retransmits ?? '-');
        if (showUdpLost) cells.push(typeof s.lost_packets !== 'undefined' ? s.lost_packets : '-');
        if (showUdpLoss) cells.push(typeof s.lost_percent !== 'undefined' ? s.lost_percent.toFixed(2) : '-');
        netPerfAddRow(tbody, cells);
    });
    table.appendChild(tbody);
    return table;
}

// Chart definitions (presentation + data) for the applicable graphs
function netPerfBuildGraphDefs(series, protocol, suffix) {
    const defs = [];
    const { speeds, cwnd, rtt, jitter, lostPackets } = series;

    if (speeds.length) {
        defs.push({
            canvasId: `iperf-speed-chart${suffix}`,
            title: 'Speed (Mbps)',
            yLabel: 'Mbps',
            data: speeds.map(bps => bps / 1e6),
            color: 'rgba(42,122,226,1)',
            height: 180,
        });
    }
    if (protocol === 'TCP' && cwnd.some(v => v !== null)) {
        defs.push({
            canvasId: `iperf-cwnd-chart${suffix}`,
            title: 'Congestion window (bytes)',
            yLabel: 'snd_cwnd (bytes)',
            data: cwnd,
            color: 'rgba(255,193,7,1)',
            height: 120,
        });
    }
    if (protocol === 'TCP' && rtt.some(v => v !== null)) {
        defs.push({
            canvasId: `iperf-rtt-chart${suffix}`,
            title: 'RTT (ms)',
            yLabel: 'RTT (ms)',
            data: rtt,
            color: 'rgba(220,53,69,1)',
            height: 120,
        });
    }
    if (protocol === 'UDP' && jitter.some(v => v !== null)) {
        defs.push({
            canvasId: `iperf-jitter-chart${suffix}`,
            title: 'Jitter (ms)',
            yLabel: 'Jitter (ms)',
            data: jitter,
            color: 'rgba(255,87,34,1)',
            height: 120,
        });
    }
    if (protocol === 'UDP' && lostPackets.some(v => v !== null)) {
        defs.push({
            canvasId: `iperf-lost-chart${suffix}`,
            title: 'Lost packets',
            yLabel: 'Lost packets',
            data: lostPackets,
            color: 'rgba(220,53,69,1)',
            height: 120,
        });
    }
    return defs;
}

// Clone one #iperf-graph-item template (or build the same shape) and fill it
function netPerfBuildGraphItem(gd, graphItemTpl) {
    let item;
    if (graphItemTpl) {
        item = graphItemTpl.content.firstElementChild.cloneNode(true);
    } else {
        item = document.createElement('div');
        item.className = 'iperf-graph-item';
    }

    let gTitle = item.querySelector('.iperf-graph-title');
    let gWrap = item.querySelector('.iperf-chart-wrap');
    if (!gTitle) {
        gTitle = document.createElement('div');
        gTitle.className = 'iperf-graph-title';
        item.appendChild(gTitle);
    }
    if (!gWrap) {
        gWrap = document.createElement('div');
        gWrap.className = 'iperf-chart-wrap';
        item.appendChild(gWrap);
    }
    let gCanvas = gWrap.querySelector('canvas');
    if (!gCanvas) {
        gCanvas = document.createElement('canvas');
        gWrap.appendChild(gCanvas);
    }

    gTitle.textContent = gd.title;
    // Fixed height wrapper (like .sla-chart-wrap) lets the responsive
    // Chart.js keep a stable height while the width reflows with the panel.
    gWrap.style.height = `${gd.height}px`;
    gCanvas.id = gd.canvasId;
    return item;
}

function renderIperfResult(result, meta = {}) {
    if (!result) return;
    const taskId = meta.taskId || null;
    const suffix = taskId
        ? '-' + String(taskId).replace(/[^a-z0-9]/gi, '').slice(0, 8)
        : '-latest';
    const protocol = result?.start?.test_start?.protocol?.toUpperCase?.() || 'TCP';
    const intervals = result.intervals || [];
    const series = netPerfBuildSeries(intervals, protocol);
    const end = result.end || {};

    const resultsContainer = document.querySelector('[data-js="results-container"]');
    const panelTpl = document.getElementById('iperf-result-panel');
    const graphItemTpl = document.getElementById('iperf-graph-item');
    if (!resultsContainer || !panelTpl) return;

    const panel = panelTpl.content.firstElementChild.cloneNode(true);
    const titleEl = panel.querySelector('.iperf-result-title');
    const metaEl = panel.querySelector('.iperf-result-meta');
    const bodyEl = panel.querySelector('.iperf-result-body');
    const graphsEl = panel.querySelector('.iperf-result-graphs');
    graphsEl.id = `iperf-graphs${suffix}`;

    panel.dataset.taskId = taskId || '';
    if (titleEl) titleEl.textContent = taskId ? `Test ${taskId}` : `Test ${new Date().toISOString()}`;
    if (metaEl) metaEl.textContent = result?.start?.timestamp?.time || '';

    // Summary + CPU go side by side on wide screens and stack on narrow ones
    // (layout provided by .iperf-stat-grid in default-iperf.css)
    const statGrid = document.createElement('div');
    statGrid.className = 'iperf-stat-grid';
    statGrid.appendChild(netPerfBuildSummaryTable(protocol, end));
    const cpuTable = netPerfBuildCpuTable(end.cpu_utilization_percent);
    if (cpuTable) statGrid.appendChild(cpuTable);
    bodyEl.appendChild(statGrid);

    const ivTable = netPerfBuildIntervalsTable(intervals, protocol);
    if (ivTable) bodyEl.appendChild(ivTable);

    // Append so multiple tests appear one after another
    resultsContainer.appendChild(panel);

    // Collapse behavior: if more than one panel exists, collapse the new one by default
    const toggleBtn = panel.querySelector('.iperf-toggle-btn');
    const setCollapsed = (collapsed) => {
        if (collapsed) {
            bodyEl.style.display = 'none';
            graphsEl.style.display = 'none';
            toggleBtn.textContent = '▸';
            toggleBtn.setAttribute('aria-expanded', 'false');
        } else {
            bodyEl.style.display = '';
            graphsEl.style.display = '';
            toggleBtn.textContent = '▾';
            toggleBtn.setAttribute('aria-expanded', 'true');
        }
    };
    const panelCount = resultsContainer.querySelectorAll('.iperf-result-panel').length;
    setCollapsed(panelCount > 1);

    // Toggle handler (also trigger pending chart creation when expanding)
    toggleBtn.addEventListener('click', () => {
        const willBeExpanded = toggleBtn.getAttribute('aria-expanded') !== 'true';
        setCollapsed(!willBeExpanded);
        if (willBeExpanded) {
            const pending = pendingChartCreators.get(suffix);
            if (typeof pending === 'function') {
                try { pending(); } catch (e) { console.error('deferred chart creation failed', e); }
                pendingChartCreators.delete(suffix);
            }
        }
    });

    const graphDefs = netPerfBuildGraphDefs(series, protocol, suffix);
    graphDefs.forEach(gd => {
        graphsEl.appendChild(netPerfBuildGraphItem(gd, graphItemTpl));
    });

    // If the graphs container is hidden (panel collapsed), defer chart
    // creation until the user expands the panel.
    const createCharts = () => {
        if (typeof makeSingleChart !== 'function') return;
        graphDefs.forEach(gd => {
            // Responsive width with the fixed height given by the wrapper:
            // maintainAspectRatio:false fills the box instead of stretching it.
            makeSingleChart(gd.canvasId, gd.yLabel, gd.data, gd.color, { beginAtZero: true }, series.labels, {
                responsive: true,
                maintainAspectRatio: false,
            });
        });
    };

    const compStyle = window.getComputedStyle(graphsEl);
    if (compStyle && compStyle.display === 'none') {
        pendingChartCreators.set(suffix, createCharts);
    } else {
        try { createCharts(); } catch (e) { console.error('createCharts failed', e); }
    }
}

// Restore the tests run before this page load.
//
// The gateway keeps every test as a task for the daemon's lifetime, but
// `iperf_status_and_tasks` only returns the lightweight view (no `result`), so
// each payload has to be pulled with `iperf_get_task_result` -- the same call
// the live poll uses. The list only holds what the daemon still remembers, so
// it stays short and all of it is restored.
//
// Task ids with their state normalized, oldest first
function orderedTaskStates(tasks) {
    return Object.entries(tasks || {})
        .sort(([, a], [, b]) => String(a.started_at || '').localeCompare(String(b.started_at || '')))
        .map(([taskId, task]) => [taskId, normalizeTaskState(task)]);
}

// A task the gateway will still report a newer state for
function isOpenState(state) {
    return state !== 'completed' && state !== 'error' && state !== 'failed';
}

// Fetch and render each task one request at a time: parallel requests resolve
// out of order and would scatter the panels.
async function restoreResults(taskIds) {
    for (const taskId of taskIds) {
        if (renderedTaskResults.has(taskId)) continue;
        try {
            const resp = await apiClient.request('iperf_get_task_result', { task_id: taskId });
            const r = parseHandlerResponse(resp);
            if (!r || r.status !== 'success' || !r.result) continue;
            // Failed runs have no result to show; they stay in the task list
            const failure = iperfFailureMessage(r.result);
            if (failure) {
                appLog.error('Previous test failed: ' + failure);
                continue;
            }
            renderIperfResult(extractTaskResultPayload(r.result), { taskId });
            renderedTaskResults.add(taskId);
        } catch (err) {
            console.error('Failed to restore result ' + taskId + ':', err);
        }
    }
}

async function recoverPreviousResults() {
    try {
        const resp = await apiClient.request('iperf_status_and_tasks', {});
        const r = parseHandlerResponse(resp);
        if (!r || r.status !== 'success') return;
        const states = orderedTaskStates(r.result?.tasks);
        // Oldest first, so the panels keep the order they had while live
        await restoreResults(states.filter(([, s]) => s === 'completed').map(([id]) => id));
        // A test running across the reload keeps polling until it finishes
        states.filter(([, s]) => isOpenState(s)).forEach(([id]) => startTaskPolling(id));
    } catch (err) {
        console.error('Failed to list previous results:', err);
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    // Start polling server status and tasks
    startServerPolling();

    // Server controls
    const startBtn = document.querySelector('[data-js="start-server"]');
    if (startBtn) startBtn.addEventListener('click', startServer);

    const stopBtn = document.querySelector('[data-js="stop-server"]');
    if (stopBtn) stopBtn.addEventListener('click', stopServer);

    // Client form
    const clientForm = document.querySelector('[data-js="client-form"]');
    if (clientForm) {
        clientForm.addEventListener('submit', e => {
            e.preventDefault();
            startClientTest();
        });
    }

    // Bring back the tests the gateway still holds in memory
    recoverPreviousResults();
});
