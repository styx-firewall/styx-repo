// routes.js
// JS for the routing-routes page (tpl/default/routing-routes*.tpl.php):
// route actions, table filters, tabs, advanced options, and the add-route form.

document.addEventListener('DOMContentLoaded', () => {
    // Init pickers (set pickers + label pickers, both are used in the add-route form)
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }

    // Submit a route command and show the outcome. All route operations share
    // this flow: submit -> reload on success, error modal on failure.
    async function submitRouteCommand(command, payload, title) {
        try {
            const result = await apiClient.submit(command, payload);
            showApiResult(result, { title, closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    // Route actions (delete / disable / enable)
    function wireRouteAction(selector, command, opts) {
        document.querySelectorAll(selector).forEach(btn => {
            btn.addEventListener('click', () => {
                const routeId = btn.getAttribute('data-route-id');
                if (!routeId) return;
                const isV6 = btn.getAttribute('data-ipv6') === '1';
                showModal(opts.question, {
                    title: opts.confirmTitle,
                    closeText: 'Cancel',
                    showConfirm: true,
                    confirmText: opts.confirmText,
                    onConfirm: () => submitRouteCommand(command, { route_id: routeId, ipv6: isV6 }, opts.actionTitle)
                });
            });
        });
    }
    wireRouteAction('.delete-route-btn', 'delete_route_by_id', {
        question: 'Are you sure you want to delete this route?',
        confirmTitle: 'Confirm Delete',
        confirmText: 'Delete',
        actionTitle: 'Delete Route',
    });
    wireRouteAction('.disable-route-btn', 'disable_route', {
        question: 'Are you sure you want to disable this route?',
        confirmTitle: 'Confirm Disable',
        confirmText: 'Disable',
        actionTitle: 'Disable Route',
    });
    wireRouteAction('.enable-route-btn', 'enable_route', {
        question: 'Are you sure you want to enable this route?',
        confirmTitle: 'Confirm Enable',
        confirmText: 'Enable',
        actionTitle: 'Enable Route',
    });

    // Route filters (applied to both tables)
    // Column layout of routing-routes-view.tpl.php:
    // 0: warning, 1: dst, 2: gateway, 3: dev, 4: table, 5: protocol,
    // 6: scope, 7: prefsrc, 8: type, 9: flags, 10: metric, 11: mtu, 12: actions
    const FILTERS = [
        { id: 'filter-table-select', cell: 4 },
        { id: 'filter-scope-select', cell: 6 },
        { id: 'filter-type-select', cell: 8 },
    ];
    function filterRoutesTables() {
        const criteria = FILTERS.map(f => ({
            cell: f.cell,
            value: document.getElementById(f.id)?.value || '',
        }));
        ['ipv4-routes-table', 'ipv6-routes-table'].forEach(tableId => {
            const table = document.getElementById(tableId);
            if (!table) return;
            Array.from(table.tBodies[0].rows).forEach(row => {
                const visible = criteria.every(c => !c.value || row.cells[c.cell]?.textContent.trim() === c.value);
                row.style.display = visible ? '' : 'none';
            });
        });
    }
    FILTERS.forEach(f => {
        const el = document.getElementById(f.id);
        if (el) el.addEventListener('change', filterRoutesTables);
    });
    // Run filter on load
    filterRoutesTables();

    // Tabs (view / add)
    // The tab buttons in routing-routes.tpl.php call showTab() via inline onclick.
    window.showTab = function(tab) {
        const tabView = document.getElementById('tab-content-view');
        const tabAdd = document.getElementById('tab-content-add');
        const btnView = document.getElementById('routes-tab-view');
        const btnAdd = document.getElementById('routes-tab-add');
        if (!tabView || !tabAdd || !btnView || !btnAdd) return;
        tabView.classList.toggle('im-hide', tab !== 'view');
        tabView.classList.toggle('active', tab === 'view');
        tabAdd.classList.toggle('im-hide', tab !== 'add');
        tabAdd.classList.toggle('active', tab === 'add');
        // route-tab-active is legacy CSS kept for backward compatibility
        btnView.classList.toggle('route-tab-active', tab === 'view');
        btnView.classList.toggle('active', tab === 'view');
        btnAdd.classList.toggle('route-tab-active', tab === 'add');
        btnAdd.classList.toggle('active', tab === 'add');
    };
    // Initialize with the routes view
    showTab('view');

    // Advanced options & multipath visibility
    // Note: CSS sets both #advanced-options and #multipath-nexthops to
    // im-hide by default; showing them requires removing the class.
    const pathModeCheckbox = document.getElementById('path-mode-checkbox');
    const multipathDiv = document.getElementById('multipath-nexthops');
    const advancedOptionsDiv = document.getElementById('advanced-options');
    const toggleAdvancedBtn = document.getElementById('toggle-advanced-btn');
    const setMultipathVisible = visible => {
        if (multipathDiv) multipathDiv.classList.toggle('im-hide', !visible);
    };
    const setAdvancedVisible = visible => {
        if (!advancedOptionsDiv || !toggleAdvancedBtn) return;
        advancedOptionsDiv.classList.toggle('im-hide', !visible);
        toggleAdvancedBtn.textContent = visible ? 'Hide advanced options' : 'Show advanced options';
    };
    if (pathModeCheckbox) {
        pathModeCheckbox.addEventListener('change', () => {
            setMultipathVisible(pathModeCheckbox.checked);
            if (pathModeCheckbox.checked) setAdvancedVisible(true);
        });
        // Sync the initial state with the checkbox
        setMultipathVisible(pathModeCheckbox.checked);
        if (pathModeCheckbox.checked) setAdvancedVisible(true);
    }
    if (toggleAdvancedBtn) {
        toggleAdvancedBtn.addEventListener('click', () => {
            setAdvancedVisible(advancedOptionsDiv?.classList.contains('im-hide'));
        });
    }

    // Add nexthop rows (multipath)
    const nexthopList = document.getElementById('nexthop-list');
    const addNexthopBtn = document.getElementById('add-nexthop-btn');
    const mainIfaceSelect = document.querySelector('select[name="iface"]');
    function createNexthopRow(idx) {
        const row = document.createElement('div');
        row.className = 'nexthop-row';
        // Gateway set-picker, mirroring the add-route form markup
        const gatewayPicker = document.createElement('div');
        gatewayPicker.className = 'nexthop-gateway-picker';
        gatewayPicker.innerHTML = `<div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-filter-scope="host" data-required>
<input type="hidden" name="nexthops[${idx}][gateway]" value="">
<button type="button" class="std-btn set-picker-trigger js-set-picker-open" data-placeholder="Select gateway&hellip;">
<span class="js-set-picker-label">Select gateway&hellip;</span>
</button>
<button type="button" class="std-btn set-picker-clear js-set-picker-clear sets-hidden" title="Clear selection">&#215;</button>
</div>`;
        row.appendChild(gatewayPicker);
        // Iface select cloned from the main form, only if it has options
        if (mainIfaceSelect && mainIfaceSelect.options.length > 0) {
            const ifaceField = document.createElement('select');
            ifaceField.name = `nexthops[${idx}][iface]`;
            ifaceField.className = 'nexthop-input nexthop-iface input-select';
            Array.from(mainIfaceSelect.options).forEach(opt => {
                const o = document.createElement('option');
                o.value = opt.value;
                o.textContent = opt.textContent;
                ifaceField.appendChild(o);
            });
            row.appendChild(ifaceField);
        }
        const weightInput = document.createElement('input');
        weightInput.type = 'number';
        weightInput.name = `nexthops[${idx}][weight]`;
        weightInput.min = '1';
        weightInput.value = '1';
        weightInput.placeholder = 'Weight';
        weightInput.className = 'nexthop-input nexthop-weight';
        row.appendChild(weightInput);
        const removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'remove-nexthop-btn';
        removeBtn.textContent = 'Remove';
        removeBtn.addEventListener('click', () => row.remove());
        row.appendChild(removeBtn);
        return row;
    }
    if (addNexthopBtn && nexthopList) {
        // Monotonic counter, not children.length: after removing a row a
        // reused index would collide with a surviving nexthops[i][...] group
        // and the two rows would merge in the payload (last one wins).
        let nextNexthopIdx = 0;
        addNexthopBtn.addEventListener('click', () => {
            const idx = nextNexthopIdx++;
            const row = createNexthopRow(idx);
            nexthopList.appendChild(row);
            // Initialize the gateway picker inside the new row
            window.setsModal.initPickerFields(row);
        });
    }

    // Add route form
    // Collect the form fields into the add_route payload.
    function buildRoutePayload(form) {
        const route = {};
        let route_type = '';
        const formData = new FormData(form);
        for (const [key, value] of formData.entries()) {
            if (key === 'route_type') {
                route_type = value;
            } else if (key === 'iface') {
                // The API expects dev, not iface
                route.dev = value;
            } else if (key.endsWith('[]')) {
                const arrKey = key.replace('[]', '');
                if (!route[arrKey]) route[arrKey] = [];
                route[arrKey].push(value);
            } else if (key.match(/^nexthops\[[0-9]+\]\[[a-zA-Z0-9_]+\]$/)) {
                // Multipath nexthop fields: nexthops[<idx>][<field>]
                const match = key.match(/^nexthops\[([0-9]+)\]\[([a-zA-Z0-9_]+)\]$/);
                if (match) {
                    const idx = match[1];
                    const field = match[2];
                    if (!route.nexthops) route.nexthops = [];
                    if (!route.nexthops[idx]) route.nexthops[idx] = {};
                    // In nexthops, iface is also renamed to dev
                    if (field === 'iface') {
                        route.nexthops[idx].dev = value;
                    } else {
                        route.nexthops[idx][field] = value;
                    }
                }
            } else {
                route[key] = value;
            }
        }
        // Drop empty fields
        Object.keys(route).forEach(k => {
            if (!route[k]) delete route[k];
        });
        // Compact nexthops: drop empty/sparse entries
        if (route.nexthops) {
            route.nexthops = route.nexthops.filter(nh => nh && Object.keys(nh).length > 0);
            if (!route.nexthops.length) delete route.nexthops;
        }
        // The command travels as submitRouteCommand's first argument; apiClient
        // sets payload.command itself, so it must not be duplicated here.
        return { route_type, route };
    }
    const addRouteForm = document.querySelector('.js-add-route-form');
    if (addRouteForm) {
        addRouteForm.addEventListener('submit', async e => {
            e.preventDefault();
            const data = buildRoutePayload(addRouteForm);
            // Validate required fields
            if (!data.route.dst) {
                showModal('<p>Please select a destination address set.</p>', { title: 'Validation error', closeText: 'Close' });
                return;
            }
            // A gateway is only required for single-path routes
            if (data.route.path_mode !== 'multipath' && !data.route.gateway) {
                showModal('<p>Please select a gateway address set.</p>', { title: 'Validation error', closeText: 'Close' });
                return;
            }
            submitRouteCommand('add_route', data, 'Add Route');
        });
    }

});
