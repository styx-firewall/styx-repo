document.addEventListener('DOMContentLoaded', function() {
    // Initialize set-picker fields for IPv4/IPv6 address selection
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    // Initialize label-picker fields for VLAN label selection
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }

    // Returns the text of the option currently selected in `select`, or
    // `fallback` when the selection cannot be read.
    function selectedOptionLabel(select, fallback) {
        try {
            return (select.selectedOptions && select.selectedOptions[0])
                ? select.selectedOptions[0].text.trim()
                : select.options[select.selectedIndex].text.trim();
        } catch (e) {
            return fallback;
        }
    }

    // VLAN: Autocomplete interface name from parent + label value
    function updateVlanIfaceName() {
        const parentSelect = document.getElementById('parent_iface_select');
        const vlanHidden = document.getElementById('vlan_id_input');
        const ifaceNameInput = document.getElementById('iface_name_input');
        if (!parentSelect || !vlanHidden || !ifaceNameInput) return;
        const parentLabel = selectedOptionLabel(parentSelect, parentSelect.value.trim());
        const vlanValue = vlanHidden.getAttribute('data-value') || '';
        if (parentLabel && vlanValue) {
            ifaceNameInput.value = parentLabel + '.' + vlanValue;
        } else {
            ifaceNameInput.value = '';
        }
        ifaceNameInput.disabled = true;
    }
    const parentSelect = document.getElementById('parent_iface_select');
    const vlanHidden = document.getElementById('vlan_id_input');
    if (parentSelect && vlanHidden) {
        parentSelect.addEventListener('change', updateVlanIfaceName);
        vlanHidden.addEventListener('input', updateVlanIfaceName);
        updateVlanIfaceName();
    }

    // Bridge VLANs visibility: show only when vlan_filtering is enabled
    function updateBridgeVlanVisibility() {
        const cb = document.getElementById('vlan_filtering_checkbox');
        const section = document.getElementById('bridge-vlans-section');
        if (!section || !cb) return;
        section.style.display = cb.checked ? '' : 'none';
    }
    document.getElementById('vlan_filtering_checkbox')?.addEventListener('change', updateBridgeVlanVisibility);
    updateBridgeVlanVisibility();

    // Enforce PVID constraints: only one PVID per port, and the row that has
    // the PVID (native VLAN) is always forced untagged.
    function attachBridgeVlanRowListeners(row) {
        if (!row) return;
        const pvidEl = row.querySelector('.bv-pvid');
        const portEl = row.querySelector('.bv-port');
        const untagEl = row.querySelector('.bv-untagged');

        // If this row has PVID, force untagged and lock the checkbox.
        function enforceForRow() {
            if (!untagEl) return;
            if (pvidEl && pvidEl.checked) {
                untagEl.checked = true;
                untagEl.disabled = true;
            } else {
                untagEl.disabled = false;
            }
        }

        function clearOtherPvidsForPort(portVal) {
            if (!portVal) return;
            for (const r of document.querySelectorAll('.bridge-vlan-row')) {
                if (r === row) continue;
                const otherPort = r.querySelector('.bv-port');
                const otherPvid = r.querySelector('.bv-pvid');
                const otherUntag = r.querySelector('.bv-untagged');
                if (otherPort && otherPvid && otherPort.value === portVal && otherPvid.checked) {
                    otherPvid.checked = false;
                    if (otherUntag) otherUntag.disabled = false;
                }
            }
        }

        // When PVID is toggled: if checked, clear other PVIDs on the same
        // port and force untagged.
        if (pvidEl) {
            pvidEl.addEventListener('change', function() {
                const portVal = portEl ? portEl.value : '';
                if (pvidEl.checked) {
                    clearOtherPvidsForPort(portVal);
                }
                enforceForRow();
            });
        }

        // When the port changes: if this row has PVID, make sure other rows
        // targeting the same port have their PVID cleared.
        if (portEl) {
            portEl.addEventListener('change', function() {
                if (pvidEl && pvidEl.checked) {
                    clearOtherPvidsForPort(portEl.value);
                }
            });
        }

        // Initialize state
        enforceForRow();
    }
    // Attach listeners to existing bridge-vlan rows on load
    document.querySelectorAll('.bridge-vlan-row').forEach(r => attachBridgeVlanRowListeners(r));

    // PPPoE: toggle required on user/pass if noauth is checked
    function togglePppoeRequired() {
        const noauth = document.getElementById('noauth_checkbox');
        const user = document.getElementById('pppoe_user_input');
        const pass = document.getElementById('pppoe_pass_input');
        const checked = noauth && noauth.checked;
        if (user) user.required = !checked;
        if (pass) pass.required = !checked;
    }
    document.getElementById('noauth_checkbox')?.addEventListener('change', togglePppoeRequired);
    togglePppoeRequired();

    // Format a backend response for display in a modal
    function formatResponse(result) {
        if (result && typeof result === 'object') {
            if (result.response_msg) return result.response_msg;
            if (result.message) return result.message;
            return '<pre>' + JSON.stringify(result, null, 2) + '</pre>';
        }
        return String(result);
    }

    // ----------------------------------------------------------------------
    // Main interface form
    // ----------------------------------------------------------------------

    // UUID validation regex, used by the bridge VLAN and reference validators
    const uuidRe = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
    function invalidUuid(v) {
        return typeof v === 'string' && v !== '' && !uuidRe.test(v);
    }

    // Serialize the form into a nested config object. `setNested` handles
    // names like 'pppoe[key]' (nested object) and 'name[]' (array push).
    function serializeIfaceForm(form) {
        const config = {};

        function setNested(name, value) {
            const m = name.match(/^([^\[]+)\[([^\]]*)\]$/);
            if (!m) {
                config[name] = value;
                return;
            }
            const parent = m[1];
            const key = m[2];
            if (key === '') {
                // Empty key => array push (name[] style); concat keeps any
                // multi-select array flat.
                if (!Array.isArray(config[parent])) config[parent] = [];
                config[parent] = config[parent].concat(value);
            } else {
                if (typeof config[parent] !== 'object' || config[parent] === null) config[parent] = {};
                config[parent][key] = value;
            }
        }

        form.querySelectorAll('input, select, textarea').forEach(el => {
            if (!el.name || el.type === 'button' || el.type === 'submit') return;
            // Skip disabled fields (only physical interfaces have a disabled MAC)
            if (el.disabled) return;
            // Skip ipv4/ipv6 bracketed inputs here; handled later
            if (/^ipv4\[\d+\]\[(ip|netmask)\]$/.test(el.name)) return;
            if (/^ipv6\[\d+\]\[(ip|prefix)\]$/.test(el.name)) return;

            if (el.type === 'checkbox') {
                if (el.name === 'status') {
                    config[el.name] = el.checked ? 'up' : 'down';
                } else {
                    const val = el.checked ? (el.value || '1') : '0';
                    if (el.name.indexOf('[') !== -1) {
                        setNested(el.name, val);
                    } else {
                        config[el.name] = val;
                    }
                }
            } else if (el.tagName === 'SELECT' && el.multiple) {
                // Handle multi-selects as arrays
                const vals = Array.from(el.selectedOptions).map(o => o.value);
                if (el.name.indexOf('[') !== -1) {
                    setNested(el.name, vals);
                } else {
                    config[el.name] = vals;
                }
            } else if (el.name.indexOf('[') !== -1) {
                setNested(el.name, el.value);
            } else {
                config[el.name] = el.value;
            }
        });

        // Capture the interface identifiers separately: `iface_name` (display
        // name) and `iface_id` (persistent id used for service bindings).
        const ifaceNameInput = form.querySelector('input[name="iface_name"]');
        const ifaceIdInput = form.querySelector('input[name="iface_id"]');
        if (ifaceNameInput) config.iface_name = ifaceNameInput.value;
        if (ifaceIdInput) config.iface_id = ifaceIdInput.value;
        return config;
    }

    // Apply the macvlan FRR VRRP carrier rules to the serialized config.
    // Carrier attributes are create-only: the backend rejects frr_* keys on
    // edits, so they are never resubmitted. Returns an error message to show,
    // or null if the config is valid.
    function applyMacvlanCarrier(config) {
        if (config.iface_subtype !== 'macvlan') return null;
        const carrierSw = document.getElementById('frr_vrrp_carrier_switch');
        const carrierOn = !!(carrierSw && carrierSw.checked);
        if (config.action === 'create') {
            if (carrierOn) {
                // Mode locked to bridge and no manual MAC: the backend
                // computes the RFC 5798 virtual MAC from VRID + family.
                config.macvlan_mode = 'bridge';
                delete config.mac;
                const vridRaw = config.frr_vrrp_vrid;
                const vridStr = (vridRaw === undefined || vridRaw === null) ? '' : String(vridRaw).trim();
                if (vridStr === '') {
                    return "'frr_vrrp_vrid' (1-255) is required to create a VRRP carrier macvlan.";
                }
                if (!/^-?\d+$/.test(vridStr)) {
                    return 'frr_vrrp_vrid must be an integer.';
                }
                const vrid = parseInt(vridStr, 10);
                if (vrid < 1 || vrid > 255) {
                    return 'frr_vrrp_vrid must be between 1 and 255.';
                }
                config.frr_vrrp_vrid = vrid; // schema requires an integer
                if (config.frr_vrrp_family !== 'ip' && config.frr_vrrp_family !== 'ip6') {
                    config.frr_vrrp_family = 'ip'; // backend default
                }
            } else {
                // Plain macvlan: never send stale carrier keys.
                delete config.frr_vrrp_vrid;
                delete config.frr_vrrp_family;
            }
            return null;
        }
        // Editing an existing interface: never resubmit frr_* keys, and never
        // submit the computed VMAC as a manual MAC while it remains a carrier.
        delete config.frr_vrrp_vrid;
        delete config.frr_vrrp_family;
        if (carrierOn) delete config.mac;
        return null;
    }

    // Gather the Bridge VLAN rows into config.bridge_vlans. Returns an error
    // message to show, or null if the config is valid.
    function collectBridgeVlans(config) {
        // Clean up any stray keys left by the general form serialization
        // (e.g. 'bridge_vlans[][vlan_id]' from inputs whose name[] pattern
        // setNested cannot parse into a proper nested structure).
        Object.keys(config).forEach(k => {
            if (/^bridge_vlans\[/.test(k)) delete config[k];
        });
        const cb = document.getElementById('vlan_filtering_checkbox');
        if (!cb || !cb.checked) return null;
        const arr = [];
        for (const row of document.querySelectorAll('.bridge-vlan-row')) {
            const vlanEl = row.querySelector('.bv-vlan-id');
            const pvidEl = row.querySelector('.bv-pvid');
            const untagEl = row.querySelector('.bv-untagged');
            const portEl = row.querySelector('.bv-port');
            if (!vlanEl) continue;
            const vlanVal = (vlanEl.value || '').trim();
            // vlan_id must be a valid label UUID
            if (vlanVal === '' || !uuidRe.test(vlanVal)) continue;
            const bv = { vlan_id: vlanVal };
            if (pvidEl) bv.pvid = !!pvidEl.checked;
            if (untagEl) bv.untagged = !!untagEl.checked;
            if (portEl && portEl.value) bv.port = portEl.value;
            arr.push(bv);
        }
        // Validation: only one PVID (native VLAN) per port
        const pvidMap = {};
        for (const bv of arr) {
            if (bv.port && bv.pvid) {
                pvidMap[bv.port] = (pvidMap[bv.port] || 0) + 1;
                if (pvidMap[bv.port] > 1) {
                    return 'Only one PVID (native VLAN) is allowed per port. Review Bridge VLAN entries.';
                }
            }
        }
        // An empty array clears all VLANs on the backend
        config.bridge_vlans = arr;
        return null;
    }

    // A command's non-fatal warnings (what the gateway could not finish, e.g.
    // the `children` cascade notice) live under cmd.result.warnings, not in
    // response_msg, and each carries its own human-readable `msg`.
    function cmdWarningMsgs(cmd) {
        const w = cmd && cmd.result && cmd.result.warnings;
        if (!Array.isArray(w)) return [];
        return w.map(x => x && x.msg).filter(m => typeof m === 'string' && m !== '');
    }

    // Show the backend response of the main submit in a modal
    function handleMainSubmitResult(result) {
        appLog('Submit response:', result);
        if (result.status === 'success') {
            const msgs = [];
            if (result.result && typeof result.result === 'object') {
                Object.values(result.result).forEach(cmd => {
                    if (cmd.response_msg) msgs.push(cmd.response_msg);
                    msgs.push(...cmdWarningMsgs(cmd));
                });
            }
            showModal(msgs.length ? msgs.join('<br>') : 'Success', {
                title: 'Success',
                closeText: 'Close',
                onClose: () => window.location.reload()
            });
        } else if (result.status === 'partial') {
            const parts = [];
            if (result.result && typeof result.result === 'object') {
                Object.entries(result.result).forEach(([id, cmd]) => {
                    const icon = cmd.status === 'success' ? '&#9989;' : '&#10060;';
                    parts.push(icon + ' ' + (cmd.response_msg || id));
                    cmdWarningMsgs(cmd).forEach(m => parts.push('&#9888;&#65039; ' + m));
                });
            }
            showModal(parts.length ? parts.join('<br>') : 'Completed with warnings', {
                title: 'Completed with warnings'
            });
        } else {
            showModal(formatResponse(result), {
                title: 'Error',
                closeText: 'Close'
            });
        }
    }

    const mainForm = document.getElementById('iface-form');
    if (mainForm) {
        mainForm.addEventListener('submit', function(e) {
            e.preventDefault();
            // Ensure derived fields are up-to-date before serializing
            // (e.g. iface_name for VLAN).
            try { updateVlanIfaceName(); } catch (ignored) {}
            const config = serializeIfaceForm(mainForm);

            // Basic client-side validation for VLAN creation. Use the
            // explicit iface_subtype provided by the formatter/template.
            if (config.action === 'create' && config.iface_subtype === 'vlan') {
                if (!config.parent_iface) {
                    showModal('Parent interface is required for VLAN creation.', { title: 'Validation error', closeText: 'Close' });
                    return;
                }
                if (!config.vlan_id || !uuidRe.test(config.vlan_id)) {
                    showModal('A VLAN label must be selected.', { title: 'Validation error', closeText: 'Close' });
                    return;
                }
                if (!config.iface_name || config.iface_name.trim() === '') {
                    // Try to compute a sensible iface_name using the selected
                    // option's label.
                    let parentLabel = '';
                    const parentSelectEl = document.querySelector('select[name="parent_iface"]');
                    if (parentSelectEl) parentLabel = selectedOptionLabel(parentSelectEl, '');
                    const vlanValue = vlanHidden ? (vlanHidden.getAttribute('data-value') || '') : '';
                    const base = parentLabel || config.parent_iface || '';
                    config.iface_name = (base.trim() + '.' + vlanValue).replace(/\.+/, '.');
                }
            }

            // Basic client-side validation for XFRM creation
            if (config.action === 'create' && config.iface_subtype === 'xfrm') {
                if (!config.parent_iface) {
                    showModal('Parent interface is required for XFRM creation.', { title: 'Validation error', closeText: 'Close' });
                    return;
                }
                if (!config.iface_name || config.iface_name.trim() === '') {
                    showModal('Interface name is required for XFRM creation.', { title: 'Validation error', closeText: 'Close' });
                    return;
                }
            }

            // macvlan FRR VRRP carrier
            const macvlanCarrierError = applyMacvlanCarrier(config);
            if (macvlanCarrierError) {
                showModal(macvlanCarrierError, { title: 'Validation error', closeText: 'Close' });
                return;
            }

            // If modifying an existing interface and service binding flags are
            // present, require an iface_id: the controller rejects otherwise.
            if (config.action !== 'create') {
                const hasBindingFlag = Object.prototype.hasOwnProperty.call(config, 'listen_ssh')
                    || Object.prototype.hasOwnProperty.call(config, 'listen_styx_ui');
                if (hasBindingFlag && !config.iface_id) {
                    showModal('Interface id (iface_id) is required to modify service bindings.', {
                        title: 'Error',
                        closeText: 'Close'
                    });
                    return;
                }
            }

            // IPv4/IPv6: collect the selected set IDs from the picker hidden
            // inputs; an empty array clears the current selection.
            config.ipv4 = Array.from(document.querySelectorAll('#ipv4-block input[type="hidden"][name="ipv4[]"]'))
                .map(s => s.value)
                .filter(v => v && v !== '');
            config.ipv6 = Array.from(document.querySelectorAll('#ipv6-block input[type="hidden"][name="ipv6[]"]'))
                .map(s => s.value)
                .filter(v => v && v !== '');

            // System loopback (lo): set_iface_config only accepts ip_mode,
            // ipv4, ipv6 and role. Drop the other fields the form collected.
            if (mainForm.dataset.systemLoopback === '1' && config.action !== 'create') {
                ['status', 'mtu', 'mac', 'iface_name', 'listen_ssh', 'listen_styx_ui'].forEach(k => {
                    delete config[k];
                });
            }

            const bridgeVlanError = collectBridgeVlans(config);
            if (bridgeVlanError) {
                showModal(bridgeVlanError, { title: 'Validation error', closeText: 'Close' });
                return;
            }

            // If mode is 'static' but no addresses were provided, reject on
            // the client side: the backend requires at least one IP in
            // static mode.
            if (config.ip_mode === 'static') {
                const ipv4Empty = Array.isArray(config.ipv4) && config.ipv4.length === 0;
                const ipv6Empty = Array.isArray(config.ipv6) && config.ipv6.length === 0;
                if (ipv4Empty && ipv6Empty) {
                    showModal('Static IP mode requires at least one IPv4 or IPv6 address. Add an address or change IP mode.', {
                        title: 'Validation error',
                        closeText: 'Close'
                    });
                    return;
                }
            }

            config.command = config.action === 'create' ? 'create_virtual_interface' : 'set_iface_config';

            // Enforce strict UUID-only IDs per API: block submit if any
            // referenced interface identifier is missing or not a UUID.
            const notAUuid = v => typeof v !== 'string' || v === '' || invalidUuid(v);
            if (config.parent_iface && invalidUuid(config.parent_iface)) {
                showModal('Parent interface must be a UUID. Please select a valid interface.', { title: 'Validation error', closeText: 'Close' });
                return;
            }
            if (Array.isArray(config.ports) && config.ports.some(notAUuid)) {
                showModal('Bridge port values must be UUIDs. Please re-select ports.', { title: 'Validation error', closeText: 'Close' });
                return;
            }
            if (Array.isArray(config.slaves) && config.slaves.some(notAUuid)) {
                showModal('Bond slave values must be UUIDs. Please re-select slaves.', { title: 'Validation error', closeText: 'Close' });
                return;
            }
            if (Array.isArray(config.refs) && config.refs.some(notAUuid)) {
                showModal('Refs must be UUIDs.', { title: 'Validation error', closeText: 'Close' });
                return;
            }
            if (Array.isArray(config.bridge_vlans)) {
                for (const bv of config.bridge_vlans) {
                    if (bv && bv.vlan_id && typeof bv.vlan_id === 'string' && invalidUuid(bv.vlan_id)) {
                        showModal('Bridge VLAN IDs must be UUIDs (select a VLAN label).', { title: 'Validation error', closeText: 'Close' });
                        return;
                    }
                    if (bv && bv.port && typeof bv.port === 'string' && bv.port !== '' && invalidUuid(bv.port)) {
                        showModal('Bridge VLAN port references must be UUIDs.', { title: 'Validation error', closeText: 'Close' });
                        return;
                    }
                }
            }

            appLog('Submitting config:', config);
            apiClient.submit(config.command, config)
                .then(handleMainSubmitResult)
                .catch(err => {
                    showModal('Error: ' + err.message, {
                        title: 'Error',
                        closeText: 'Close'
                    });
                });
        });
    }

    function showBlock(block) {
        if (!block) return;
        block.style.display = '';
        block.classList.remove('im-hide');
    }
    function hideBlock(block) {
        if (!block) return;
        block.style.display = 'none';
        block.classList.add('im-hide');
    }
    function updateIpModeFields() {
        const mode = document.getElementById('ip_mode_select')?.value || 'static';
        const staticDiv = document.getElementById('ip_mode_static');
        if (!staticDiv) return;
        if (mode === 'static') showBlock(staticDiv);
        else hideBlock(staticDiv);
    }
    document.getElementById('ip_mode_select')?.addEventListener('change', updateIpModeFields);
    updateIpModeFields();

    // macvlan FRR VRRP carrier: VRID + family are only settable at creation
    // time and the MAC is the computed RFC 5798 virtual MAC, so while the
    // carrier switch is ON the macvlan mode is locked to `bridge`, the MAC
    // field is hidden/disabled and a VMAC preview is shown. The switch itself
    // has no `name` and is never serialized.
    function macvlanCarrierElements() {
        return {
            sw: document.getElementById('frr_vrrp_carrier_switch'),
            fields: document.getElementById('frr_vrrp_carrier_fields'),
            vridInput: document.getElementById('frr_vrrp_vrid_input'),
            familySelect: document.getElementById('frr_vrrp_family_select'),
            preview: document.getElementById('frr_vrrp_vmac_preview'),
            modeSelect: document.getElementById('macvlan_mode_select'),
            macInput: document.querySelector('#iface-form input[name="mac"]'),
            macField: document.getElementById('mac_address_field')
        };
    }
    function macvlanIsCreate() {
        const el = document.querySelector('#iface-form input[name="action"]');
        return !!el && el.value === 'create';
    }
    // Remembers the macvlan mode chosen before the carrier switch forced it
    // to `bridge`, so disabling the carrier restores the previous selection
    // (including the empty one).
    let savedMacvlanMode = null;
    function updateMacvlanVmacPreview() {
        const els = macvlanCarrierElements();
        if (!els.preview || !els.vridInput || !els.familySelect) return;
        const vridRaw = els.vridInput.value;
        const vrid = parseInt(vridRaw, 10);
        if (!vridRaw || vrid < 1 || vrid > 255) {
            els.preview.textContent = '';
            return;
        }
        const family = els.familySelect.value === 'ip6' ? 'ip6' : 'ip';
        const prefix = family === 'ip6' ? '00:00:5e:00:02' : '00:00:5e:00:01';
        const hex = ('0' + (vrid & 0xff).toString(16)).slice(-2);
        els.preview.textContent = 'Virtual MAC (RFC 5798): ' + prefix + ':' + hex;
    }
    function updateMacvlanCarrierState() {
        const els = macvlanCarrierElements();
        if (!els.sw) return; // not a macvlan carrier form
        const on = els.sw.checked;
        const isCreate = macvlanIsCreate();

        if (on) {
            // Lock macvlan mode to bridge, keeping the previous value to restore later
            if (els.modeSelect && !els.modeSelect.disabled) {
                savedMacvlanMode = els.modeSelect.value;
            }
            if (els.modeSelect) {
                els.modeSelect.value = 'bridge';
                els.modeSelect.disabled = true;
            }
            // A carrier never carries a manual MAC: disable (the serializer
            // skips disabled fields) and hide the input.
            if (els.macInput) els.macInput.disabled = true;
            if (els.macField) els.macField.style.display = 'none';
            // VRID/family are editable only when creating a new carrier; on
            // an existing carrier (modify) they are read-only.
            if (isCreate) {
                if (els.vridInput) els.vridInput.disabled = false;
                if (els.familySelect) els.familySelect.disabled = false;
            }
            if (els.fields) showBlock(els.fields);
        } else {
            if (els.modeSelect) {
                els.modeSelect.disabled = false;
                if (savedMacvlanMode !== null) {
                    els.modeSelect.value = savedMacvlanMode;
                    savedMacvlanMode = null;
                }
            }
            if (els.macInput) els.macInput.disabled = false;
            if (els.macField) els.macField.style.display = '';
            if (els.vridInput) els.vridInput.disabled = true;
            if (els.familySelect) els.familySelect.disabled = true;
            if (els.fields) hideBlock(els.fields);
        }
        updateMacvlanVmacPreview();
    }
    const mvCarrierSwitch = document.getElementById('frr_vrrp_carrier_switch');
    if (mvCarrierSwitch) {
        mvCarrierSwitch.addEventListener('change', updateMacvlanCarrierState);
        const mvVrid = document.getElementById('frr_vrrp_vrid_input');
        const mvFamily = document.getElementById('frr_vrrp_family_select');
        if (mvVrid) mvVrid.addEventListener('input', updateMacvlanVmacPreview);
        if (mvFamily) mvFamily.addEventListener('change', updateMacvlanVmacPreview);
        updateMacvlanCarrierState();
    }

    // IPv4/IPv6 picker rows
    window.addIpRow = function(type) {
        const block = document.getElementById(type + '-block');
        const tpl = document.getElementById(type + '-picker-template');
        if (!block || !tpl) return;
        const clone = tpl.content.firstElementChild.cloneNode(true);
        block.insertBefore(clone, block.querySelector('button[onclick^=addIpRow]'));
        if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
            window.setsModal.initPickerFields(clone);
        }
    };
    window.removeIpRow = function(btn, type) {
        const row = btn.closest('.' + type + '-row');
        if (row) row.remove();
    };

    // Bridge VLAN row helpers
    function addBridgeVlanRow(templateId, containerId) {
        const cb = document.getElementById('vlan_filtering_checkbox');
        if (cb && !cb.checked) {
            showModal('Enable VLAN filtering to add Bridge VLAN entries.', { title: 'Validation', closeText: 'Close' });
            return null;
        }
        const tpl = document.getElementById(templateId);
        const container = document.getElementById(containerId);
        if (!tpl || !container) return null;
        const clone = tpl.firstElementChild.cloneNode(true);
        clone.style.display = '';
        container.appendChild(clone);
        if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
            window.labelsMgmt.initPickerFields(clone);
        }
        return clone;
    }
    window.addBridgeSelfVlanRow = function() {
        addBridgeVlanRow('bridge-vlan-self-template', 'bridge-vlans-self-container');
    }
    window.addBridgePortVlanRow = function() {
        const clone = addBridgeVlanRow('bridge-vlan-port-template', 'bridge-vlans-port-container');
        if (clone) attachBridgeVlanRowListeners(clone);
    }
    window.removeBridgeVlanRow = function(btn) {
        const row = btn.closest('.bridge-vlan-row');
        if (row) row.remove();
    }

    // refs are internal-only and not collected from the UI

    // Sysctl form submit handler (only send changed values)
    const sysctlForm = document.querySelector('[data-js="iface-sysctl-form"]')?.closest('form');
    if (sysctlForm) {
        sysctlForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const changedValues = [];
            const sysctlKeys = [];
            sysctlForm.querySelectorAll('.js-sysctl-value').forEach(input => {
                const original = input.getAttribute('data-original');
                const value = input.type === 'checkbox'
                    ? (input.checked ? '1' : '0')
                    : input.value;
                if (value !== original) {
                    changedValues.push(value);
                    sysctlKeys.push(input.getAttribute('data-sysctl-key'));
                }
            });
            if (changedValues.length === 0) {
                showModal('No changes detected.', {
                    title: 'Info',
                    closeText: 'Close'
                });
                return;
            }
            // Get the current interface id (preferred) and name (fallback/compat)
            const ifaceInput = document.querySelector('input[name="iface_name"]');
            const ifaceIdInput = document.querySelector('input[name="iface_id"]');
            const config = {
                command: 'set_iface_sysctl',
                iface_id: ifaceIdInput ? ifaceIdInput.value : '',
                iface: ifaceInput ? ifaceInput.value : '',
                sysctl_keys: sysctlKeys,
                value: changedValues
            };
            apiClient.submit(config.command, config)
                .then(result => {
                    appLog('Sysctl submit response:', result);
                    if (result.status === 'success') {
                        showModal(result.response_msg || 'Sysctl updated', {
                            title: 'Success',
                            closeText: 'Close',
                            onClose: () => window.location.reload()
                        });
                    } else {
                        showModal(formatResponse(result), {
                            title: 'Error',
                            closeText: 'Close'
                        });
                    }
                })
                .catch(err => {
                    showModal('Error: ' + err.message, {
                        title: 'Error',
                        closeText: 'Close'
                    });
                });
        });
    }
});
