/**
 * Firewall rule form management (forward/local).
 *
 * Collects, validates and submits the rule forms, plus the protocol-dependent
 * UI and the debounced backend preview.
 *
 * Field conventions:
 * - Sets (IPs, ports, interfaces) are always referenced by UUID.
 * - Cleared fields are sent as empty arrays/strings/null so the backend merge
 *   (update_firewall_rule only merges present keys) overrides stored values.
 */

// UUIDs of the picker fields (IP/ports/interface sets)
const FW_SET_UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// A rule always needs at least one of these condition fields
const FW_CONDITION_FIELDS = [
    'src_ips', 'dst_ips', 'src_ports', 'dst_ports',
    'src_ifaces', 'dst_ifaces', 'protocol', 'icmp_type', 'time', 'fwmark'
];

function hasFirewallCondition(payload) {
    return FW_CONDITION_FIELDS.some(f => payload[f] && (
        (Array.isArray(payload[f]) && payload[f].length > 0) ||
        (!Array.isArray(payload[f]) && payload[f] !== '' && payload[f] !== null)
    ));
}

/**
 * Collect all firewall rule form fields into a flat payload object.
 * Shared by the submit handler and the debounced preview.
 */
function collectFirewallFormData(form) {
    const payload = {};

    // Collect all fields with data-field
    form.querySelectorAll('[data-field]').forEach(el => {
        const key = el.getAttribute('data-field');
        if (el.type === 'checkbox') {
            payload[key] = el.checked ? 1 : 0;
        } else if (el.multiple) {
            const vals = Array.from(el.selectedOptions).map(opt => opt.value)
                .filter(v => v && v.trim() !== '');
            if (vals.length > 0) payload[key] = vals;
        } else if (el.dataset.pickerArray) {
            // Always include picker fields -- an empty selection is a cleared
            // field, not an absent one. update_firewall_rule merges partial
            // payloads onto the stored rule, so omitting the key would keep
            // the old value (e.g. removing src_ifaces left the iifname).
            payload[key] = (el.value || '').split(',').map(v => v.trim())
                .filter(v => v !== '');
        } else {
            // Same for scalar fields: send cleared inputs as empty strings so
            // they override (clear) the stored value on update.
            payload[key] = (el.value || '').trim();
        }
    });

    // TCP flags
    const protocolEl = form.querySelector('#rule-protocol');
    if (protocolEl && protocolEl.value === 'tcp') {
        const flags = Array.from(form.querySelectorAll('input[type="checkbox"][name="tcp_flags[]"]'))
            .filter(el => el.checked)
            .map(el => el.value);
        // Always include so clearing all flags overrides the stored value on update.
        payload.tcp_flags = flags;
    }

    // ICMP type(s): a single value or a comma-separated list (e.g. "0,1,4,5")
    // is sent as a numeric array. Always include the key so clearing the field
    // overrides a stored value on update (same convention as picker fields).
    if (protocolEl && (protocolEl.value === 'icmp' || protocolEl.value === 'icmpv6')) {
        const icmpTypeEl = form.querySelector('#rule-icmp-type');
        if (icmpTypeEl) {
            const values = (icmpTypeEl.value || '').split(',')
                .map(v => v.trim())
                .filter(v => v !== '');
            const types = [];
            for (const v of values) {
                const parsed = parseInt(v, 10);
                if (!isNaN(parsed) && parsed >= 0 && parsed <= 255) {
                    types.push(parsed);
                }
            }
            payload.icmp_type = types;
        }
    }

    // Chain for local rules
    if (!payload.chain) {
        const chainSelect = form.querySelector('select[name="chain_select"]');
        if (chainSelect && chainSelect.value) {
            payload.chain = chainSelect.value;
        }
    }

    // Map 'iface' (local form) to src_ifaces or dst_ifaces based on chain
    if (payload.iface) {
        if (payload.chain === 'input') {
            payload.src_ifaces = payload.iface;
        } else if (payload.chain === 'output') {
            payload.dst_ifaces = payload.iface;
        }
        delete payload.iface;
    }

    // Enabled / log / nat checkboxes
    form.querySelectorAll('input[type="checkbox"][name="enabled"]').forEach(el => {
        payload.enabled = el.checked ? 1 : 0;
    });
    form.querySelectorAll('input[type="checkbox"][name="log"]').forEach(el => {
        payload.log = el.checked ? 1 : 0;
    });
    form.querySelectorAll('input[type="checkbox"][name="enable_nat"]').forEach(el => {
        payload.nat = el.checked ? 1 : 0;
    });

    // Time restriction. Always include the key (null when cleared) so an update
    // overrides/removes a previously stored schedule -- update_rule merges only
    // the fields present in the payload. A null value is treated as "no time"
    // by the backend validation and nft builder.
    const timeStart = form.querySelector('input[name="time[start]"]');
    const timeStop = form.querySelector('input[name="time[stop]"]');
    const timeDays = form.querySelector('select[name="time[days][]"]');
    if (timeStart || timeStop || timeDays) {
        const timeValue = {
            start: timeStart && timeStart.value ? timeStart.value : '',
            stop: timeStop && timeStop.value ? timeStop.value : '',
            days: timeDays ? Array.from(timeDays.selectedOptions)
                .map(opt => opt.value)
                .filter(v => v && v.trim() !== '') : []
        };
        const hasTime = timeValue.start || timeValue.stop || timeValue.days.length > 0;
        payload.time = hasTime ? timeValue : null;
    }

    return payload;
}

/**
 * Validate a collected payload client-side before sending.
 * Returns false (and alerts) on the first problem found.
 */
function validateFirewallRule(payload) {
    // Required scalars
    const required = [['name', 'Rule name'], ['family', 'Family'], ['action', 'Action']];
    for (const [key, label] of required) {
        if (!payload[key] || payload[key].trim() === '') {
            alert(label + ' is required.');
            return false;
        }
    }
    // For input/output (local), chain is required
    if (payload.chain !== undefined && (!payload.chain || payload.chain.trim() === '')) {
        alert('Direction (chain) is required.');
        return false;
    }
    // Drop empty entries from the picker/multi fields
    const arrayFields = ['src_ifaces', 'dst_ifaces', 'src_ips', 'dst_ips', 'src_ports', 'dst_ports'];
    arrayFields.forEach(f => {
        if (payload[f] && Array.isArray(payload[f])) {
            payload[f] = payload[f].filter(v => v && v.trim() !== '');
        }
    });
    // Sets (IPs, ports, interfaces) are always referenced by UUID.
    // Returning here aborts the submit. The previous per-field forEach version
    // alerted but carried on (return only left the callback) and sent the
    // payload anyway -- don't "restore" that behaviour.
    const setFields = ['src_ips', 'dst_ips', 'src_ports', 'dst_ports', 'src_ifaces', 'dst_ifaces'];
    for (const f of setFields) {
        const values = payload[f] ? (Array.isArray(payload[f]) ? payload[f] : [payload[f]]) : [];
        for (const v of values) {
            if (v && !FW_SET_UUID_REGEX.test(v)) {
                alert('Only sets identified by UUID are accepted in ' + f + ': ' + v);
                return false;
            }
        }
    }
    // At least one condition field must be present
    if (!hasFirewallCondition(payload)) {
        alert('You must specify at least one condition (IP, port, interface, protocol, ICMP, time, etc).');
        return false;
    }
    // Validate icmp_type when protocol is icmp or icmpv6.
    // It is a numeric list (array of ints) sent by collectFirewallFormData.
    if (payload.protocol === 'icmp' || payload.protocol === 'icmpv6') {
        if (Array.isArray(payload.icmp_type) && payload.icmp_type.length > 0) {
            for (const typeVal of payload.icmp_type) {
                if (!Number.isInteger(typeVal) || typeVal < 0 || typeVal > 255) {
                    alert('ICMP type must be integers between 0 and 255 (comma separated).');
                    return false;
                }
            }
        }
    }
    return true;
}

/**
 * Handle a firewall form submission response.
 * Shows result via showApiResult, redirects on success, resets form if no redirect.
 */
function handleSubmitResponse(data, form) {
    if (Array.isArray(data)) data = data[0] || {};
    appLog('Response data:', data);
    const ok = data.success || data.status === 'success';
    const redirectUrl = ok ? '?page=firewall&section=' + (form.dataset.redirectSection || 'fw-rules-local') : null;
    showApiResult(data, {
        title: ok ? 'Success' : 'Error',
        closeText: 'Close',
        onClose: redirectUrl ? function() { window.location.href = redirectUrl; } : undefined
    });
    if (ok && !redirectUrl) form.reset();
}

// Submit a payload and route its response through handleSubmitResponse
function submitFirewallPayload(payload, form) {
    apiClient.submit(payload.command, payload)
        .then(data => handleSubmitResponse(data, form))
        .catch(() => showApiResult(
            { status: 'error', response_msg: 'Network or server error.' },
            { title: 'Error', closeText: 'Close' }
        ));
}

/**
 * Submit handler for a rule form: resolves the command, picks the
 * end_of_chain / delete / full-create-update path and sends the payload.
 */
function submitFirewallForm(form, e) {
    // Guard: pure system_rule rules cannot be edited at all
    if (form.dataset.systemRule && !form.dataset.endOfChain) return;

    // Resolve the command from the clicked button; the click capture in
    // form.dataset.lastCommand covers browsers without event.submitter.
    let command = null;
    if (e.submitter && e.submitter.name === 'command') {
        command = e.submitter.value;
    } else if (form.dataset && form.dataset.lastCommand) {
        command = form.dataset.lastCommand;
    } else {
        const el = form.querySelector('[name="command"]');
        command = el && el.value ? el.value : null;
    }

    // Send the id if it exists (for edit/delete)
    const idInput = form.querySelector('input[name="id"]');
    const idValue = idInput && idInput.value ? idInput.value : null;

    // System end_of_chain rule: only action and log may change
    if (form.dataset.systemRule && form.dataset.endOfChain) {
        const actionEl = form.querySelector('#rule-action');
        const logEl = form.querySelector('[name="log"]');
        const payload = {
            command: 'update_firewall_rule',
            id: idValue,
            action: actionEl ? actionEl.value : null,
            log: logEl ? (logEl.checked ? 1 : 0) : 0
        };
        appLog('Submit payload (system end_of_chain):', payload);
        submitFirewallPayload(payload, form);
        return;
    }

    if (command === 'delete_firewall_rule') {
        // Only send id and command
        const payload = { command, id: idValue };
        appLog('Submit payload:', payload);
        submitFirewallPayload(payload, form);
        return;
    }

    // Full create/update payload
    const payload = collectFirewallFormData(form);
    payload.command = command;
    if (idValue) payload.id = idValue;

    if (!command) {
        alert('Error: required "command" field is missing in the form.');
        return;
    }
    if (!validateFirewallRule(payload)) return;

    // If table is 'local', replace it with the value of chain or show an error
    if (payload.table === 'local') {
        if (payload.chain && payload.chain.trim() !== '') {
            payload.table = payload.chain;
        } else {
            alert('Error: No direction (chain) was specified for the local table.');
            return;
        }
    }

    appLog('Submit payload:', payload);
    submitFirewallPayload(payload, form);
}

/**
 * System rules are locked: picker buttons are always disabled; for fully
 * locked rules every field and button is disabled, for end_of_chain rules
 * only Action and Log stay editable.
 */
function applySystemRuleRestrictions() {
    document.querySelectorAll('.std-form').forEach(form => {
        if (!form.dataset.systemRule) return;
        const isEndOfChain = !!form.dataset.endOfChain;

        // Picker buttons are never editable
        form.querySelectorAll('.js-set-picker-open, .js-set-picker-clear').forEach(btn => {
            btn.disabled = true;
        });

        const notice = document.createElement('div');
        notice.className = 'std-msg-info';
        if (!isEndOfChain) {
            // Fully locked: disable all inputs and the save button
            form.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach(el => {
                el.disabled = true;
            });
            form.querySelectorAll('button[type="submit"]').forEach(btn => {
                btn.disabled = true;
            });
            notice.textContent = 'This is a system rule and cannot be edited.';
        } else {
            // end_of_chain: only action and log are editable
            form.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach(el => {
                if (el.id !== 'rule-action' && el.name !== 'log') {
                    el.disabled = true;
                }
            });
            form.querySelectorAll('button[value="delete_firewall_rule"]').forEach(btn => {
                btn.disabled = true;
            });
            notice.textContent = 'This is a system rule. Only Action and Log can be modified.';
        }
        form.prepend(notice);
    });
}

/**
 * Show/hide the protocol-dependent rows (TCP flags, ICMP type, ports)
 * according to the selected protocol.
 */
function syncProtocolDependentFields() {
    const protocolEl = document.getElementById('rule-protocol');
    if (!protocolEl) return;
    const protocol = protocolEl.value;

    // TCP flags row: shown only for TCP
    document.getElementById('tcp-flags-row').style.display = protocol === 'tcp' ? '' : 'none';

    // ICMP type row: shown only for ICMP/ICMPv6, cleared when hidden
    const icmpRow = document.getElementById('icmp-type-row');
    if (icmpRow) {
        if (protocol === 'icmp' || protocol === 'icmpv6') {
            icmpRow.style.display = '';
        } else {
            icmpRow.style.display = 'none';
            const icmpTypeEl = document.getElementById('rule-icmp-type');
            if (icmpTypeEl) {
                icmpTypeEl.value = '';
            }
            document.querySelectorAll('input[name="icmp_common[]"]').forEach(box => {
                box.checked = false;
            });
        }
    }

    // ESP/AH have no ports: hide the port rows and clear the stale selection
    const isIpsec = protocol === 'esp' || protocol === 'ah';
    for (const id of ['src-ports-field', 'dst-ports-field']) {
        const row = document.getElementById(id);
        if (row) {
            row.style.display = isIpsec ? 'none' : '';
        }
    }
    if (isIpsec) {
        document.querySelectorAll('[data-js="set-picker-field"]').forEach(field => {
            const pickerInput = field.querySelector('[data-field="src_ports"], [data-field="dst_ports"]');
            if (!pickerInput) return;
            const clearBtn = field.querySelector('.js-set-picker-clear');
            if (clearBtn) {
                clearBtn.click();
            }
        });
    }
}

/**
 * ICMP common-type multi-select: the checkboxes below the text input fill
 * the comma-separated field (e.g. checking 0 and 1 produces "0,1"). Manual
 * edits to the field are reflected back into the checkboxes.
 */
function initIcmpCommonSelect() {
    const input = document.getElementById('rule-icmp-type');
    if (!input) return;

    function reflectIcmpCommonCheckboxes() {
        const current = input.value.split(',').map(s => s.trim());
        document.querySelectorAll('input[name="icmp_common[]"]').forEach(box => {
            box.checked = current.indexOf(box.value) !== -1;
        });
    }
    function syncIcmpCommonInput() {
        const current = (input.value || '').split(',').map(s => s.trim())
            .filter(s => s !== '');
        document.querySelectorAll('input[name="icmp_common[]"]').forEach(box => {
            if (box.checked) {
                if (current.indexOf(box.value) === -1) current.push(box.value);
            } else {
                current = current.filter(v => v !== box.value);
            }
        });
        input.value = current.join(',');
    }

    input.addEventListener('input', reflectIcmpCommonCheckboxes);
    document.querySelectorAll('input[name="icmp_common[]"]').forEach(box => {
        box.addEventListener('change', syncIcmpCommonInput);
    });
    // Reflect the pre-filled value (from the stored rule) on load
    reflectIcmpCommonCheckboxes();
}

// Debounced firewall rule preview (backend)
let _fwPreviewTimer = null;

async function buildFirewallPreview(form) {
    const preview = form.querySelector('.fw-preview-code');
    if (!preview) return;

    const payload = collectFirewallFormData(form);

    // Client-side validation: name, family, action required
    if (!payload.name) {
        preview.textContent = 'Enter a rule name to preview';
        return;
    }
    if (!payload.family) {
        preview.textContent = '';
        return;
    }
    if (!payload.action) {
        preview.textContent = '';
        return;
    }
    // At least one condition is recommended
    if (!hasFirewallCondition(payload)) {
        preview.textContent = 'Add at least one condition to preview';
        return;
    }

    preview.textContent = 'Fetching preview...';
    try {
        const res = await apiClient.submit('preview_firewall_rule', payload);
        const data = Array.isArray(res) ? res[0] : res;
        if (data && data.status === 'success' && data.result && data.result.nft_run) {
            preview.textContent = data.result.nft_run;
        } else if (data && data.response_msg) {
            preview.textContent = '\u26A0 ' + data.response_msg;
        } else {
            preview.textContent = '\u26A0 Preview error';
        }
    } catch (err) {
        preview.textContent = '\u26A0 ' + (err.message || 'Request failed');
    }
}

function debouncedFirewallPreview(form) {
    if (_fwPreviewTimer) clearTimeout(_fwPreviewTimer);
    _fwPreviewTimer = setTimeout(function() { buildFirewallPreview(form); }, 300);
}

// Collects and sends firewall rule forms (forward/local)
document.addEventListener('DOMContentLoaded', function() {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }
    const forms = document.querySelectorAll('.std-form');
    forms.forEach(form => {
        // Capture which command button was clicked for browsers without event.submitter
        form.querySelectorAll('button[name="command"], input[type="submit"][name="command"]').forEach(btn => {
            btn.addEventListener('click', function() {
                try { form.dataset.lastCommand = btn.value; } catch (e) { /* noop */ }
            });
        });
    });
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            submitFirewallForm(form, e);
        });
    });

    document.querySelectorAll('.std-collapse-header').forEach(header => {
        header.addEventListener('click', function() {
            header.parentElement.classList.toggle('open');
        });
    });

    // Apply system_rule restrictions to forms
    applySystemRuleRestrictions();

    // Protocol-dependent rows (TCP flags / ICMP type / ports)
    const protocolEl = document.getElementById('rule-protocol');
    if (protocolEl) {
        protocolEl.addEventListener('change', syncProtocolDependentFields);
    }
    syncProtocolDependentFields();

    initIcmpCommonSelect();

    // Attach preview listeners to firewall rule forms
    document.querySelectorAll('#firewall-rule-form, #firewall-rule-forward-form').forEach(form => {
        // Skip system rules (fully locked)
        if (form.dataset.systemRule && !form.dataset.endOfChain) return;

        form.querySelectorAll('input, select, textarea').forEach(el => {
            if (el.type === 'button' || el.type === 'submit') return;
            el.addEventListener('change', function() { debouncedFirewallPreview(form); });
            el.addEventListener('input', function() { debouncedFirewallPreview(form); });
        });

        // Initial preview on page load (for edit forms)
        buildFirewallPreview(form);
    });
});
