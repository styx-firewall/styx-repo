/**
 * strongSwan VPN page-single orchestrator script.
 *
 * Handles: tab switching, inline editors for connections / pools / secrets,
 * conditional form visibility, IKE/ESP proposal builder, auto-presets,
 * PSK generation, data collection, CRUD operations, status refresh,
 * and global config form.
 *
 * No sub-modules, no cloning, no fallbacks for config-meaningful fields.
 */
(function () {
    'use strict';

    // Proposal builder helpers (selects now rendered server-side)
    function isAead(enc) {
        return /gcm|chacha20poly1305/.test(enc);
    }

    // Auto-presets
    const PRESETS = {
        'site-to-site': {
            label: 'Site-to-Site',
            values: {
                type: 'tunnel', ike_version: '2', start_action: 'start',
                remote_access: false,
                local_auth: 'pubkey', remote_auth: 'pubkey',
                mobike: false, compress: false, forceudp: false,
                dpd_action: 'clear', close_action: 'start',
                ike_rekey: '14400', child_rekey: '3600', dpd_delay: '30',
                keyingtries: '0',
            },
            ike_proposals: ['aes256gcm16-prfsha256-ecp256'],
            esp_proposals: ['aes256gcm16-ecp256'],
        },
        'roadwarrior-server': {
            label: 'Roadwarrior Server',
            values: {
                type: 'tunnel', ike_version: '2', start_action: 'trap',
                remote_access: true,
                role: 'server',
                local_auth: 'pubkey', remote_auth: 'eap-mschapv2',
                mobike: true, compress: false, forceudp: true,
                dpd_action: 'clear', close_action: 'none',
                ike_rekey: '14400', child_rekey: '3600', dpd_delay: '30',
                keyingtries: '0',
            },
            ike_proposals: [
                'aes256gcm16-prfsha256-ecp256',
                'aes256gcm16-prfsha256-modp1024',
            ],
            esp_proposals: [
                'aes256gcm16-ecp256',
                'aes256-sha1',
            ],
        },
        'roadwarrior-client': {
            label: 'Roadwarrior Client',
            values: {
                type: 'tunnel', ike_version: '2', start_action: 'start',
                remote_access: false,
                local_auth: 'eap-mschapv2', remote_auth: 'pubkey',
                mobike: true, compress: false, forceudp: true,
                dpd_action: 'clear', close_action: 'start',
                ike_rekey: '14400', child_rekey: '3600', dpd_delay: '30',
                vips: '',
                keyingtries: '0',
            },
            ike_proposals: ['aes256gcm16-prfsha256-ecp256'],
            esp_proposals: ['aes256gcm16-ecp256'],
        },
    };

    // Picker helpers

    // Set the value and display state of a picker field programmatically.
    // idOrIds: a UUID string, an array of UUID strings, or a comma-separated UUID string.
    // displayNames: optional display name(s) from backend _display enrichment.
    function setPickerValue(form, fieldName, idOrIds, displayNames) {
        const hiddenInput = form.querySelector('[data-js="set-picker-field"] input[name="' + fieldName + '"]');
        if (!hiddenInput) {
            return;
        }
        const wrapper = hiddenInput.closest('[data-js="set-picker-field"]');
        const labelEl = wrapper.querySelector('.js-set-picker-label');
        const openBtn = wrapper.querySelector('.js-set-picker-open');
        const clearBtn = wrapper.querySelector('.js-set-picker-clear');

        let ids;
        if (Array.isArray(idOrIds)) {
            ids = idOrIds.map(String).filter(Boolean);
        } else {
            ids = String(idOrIds || '').split(',').map(s => s.trim()).filter(Boolean);
        }

        const idStr = ids.join(',');
        hiddenInput.value = idStr;

        if (idStr) {
            let names;
            if (displayNames !== undefined) {
                names = Array.isArray(displayNames) ? displayNames : [displayNames];
            } else {
                names = ids;
            }
            if (labelEl) {
                labelEl.textContent = names.join(', ');
            }
            if (openBtn) {
                openBtn.classList.add('set-picker-trigger--has-value');
            }
            if (clearBtn) {
                clearBtn.classList.remove('sets-hidden');
            }
        } else {
            const placeholder = openBtn?.dataset.placeholder || 'Select...';
            if (labelEl) {
                labelEl.textContent = placeholder;
            }
            if (openBtn) {
                openBtn.classList.remove('set-picker-trigger--has-value');
            }
            if (clearBtn) {
                clearBtn.classList.add('sets-hidden');
            }
        }

        hiddenInput.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // Reset all picker fields inside a form to empty/placeholder state.
    function resetPickerFields(form) {
        form.querySelectorAll('[data-js="set-picker-field"], [data-js="label-picker-field"]').forEach(wrapper => {
            const hiddenInput = wrapper.querySelector('input[type="hidden"]');
            const labelEl = wrapper.querySelector('.js-set-picker-label');
            const openBtn = wrapper.querySelector('.js-set-picker-open');
            const clearBtn = wrapper.querySelector('.js-set-picker-clear');
            if (hiddenInput) {
                hiddenInput.value = '';
            }
            if (labelEl && openBtn) {
                labelEl.textContent = openBtn.dataset.placeholder || 'Select...';
            }
            if (openBtn) {
                openBtn.classList.remove('set-picker-trigger--has-value');
            }
            if (clearBtn) {
                clearBtn.classList.add('sets-hidden');
            }
        });
    }

    // Send a command and show its result (or the error) in a modal.
    async function runCommand(command, payload, okOpts) {
        try {
            const result = await apiClient.submit(command, payload);
            showApiResult(result, okOpts);
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    // Tabs: switching and the URL fragment that keeps the active tab across a
    // reload are both handled by the global .std-tabs handler in
    // scripts/core/common.js.

    // Collapsible section toggles (used by Advanced in connection form)
    function initCollapsible() {
        document.querySelectorAll('.section-head--collapsible').forEach(heading => {
            heading.addEventListener('click', () => {
                const body = heading.nextElementSibling;
                if (!body || !body.matches('.swan-advanced-body, .swan-timers-body, .swan-tls-body')) {
                    return;
                }
                const isOpen = body.style.display !== 'none';
                body.style.display = isOpen ? 'none' : '';
                const indicator = heading.querySelector('.collapse-indicator');
                if (indicator) {
                    indicator.innerHTML = isOpen ? '&#9654;' : '&#9660;';
                }
            });
        });
    }

    // Inline editor helpers (generic show / hide / reset)
    function showEditor(containerId, titleText, saveText) {
        const container = document.getElementById(containerId);
        if (!container) {
            return;
        }
        const titleEl = container.querySelector('[data-js="inline-title"]');
        const saveBtn = container.querySelector('[data-js="inline-save"]');
        if (titleEl) {
            titleEl.textContent = titleText;
        }
        if (saveBtn) {
            saveBtn.textContent = saveText;
        }
        container.style.display = 'block';
        container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function hideEditor(containerId) {
        const container = document.getElementById(containerId);
        if (container) {
            container.style.display = 'none';
        }
    }

    function resetForm(form) {
        if (!form) {
            return;
        }
        form.reset();
        // Reset proposal lists
        form.querySelectorAll('.proposal-list').forEach(list => {
            list.innerHTML = '<em>No proposals yet</em>';
        });
        form.querySelectorAll('input[name="ike_proposals"], input[name="esp_proposals"]').forEach(inp => {
            inp.value = '[]';
        });
        // Reset picker fields
        resetPickerFields(form);
    }

    // Set a form field value (handles selects, checkboxes, text inputs)
    function setFieldValue(form, name, value) {
        const el = form.querySelector('[name="' + name + '"]');
        if (!el) {
            return;
        }
        if (el.type === 'checkbox') {
            el.checked = !!value;
        } else {
            el.value = value;
        }
        el.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Connection form-show / hide / populate
    let editingConnId = null;

    function showConnectionForm(conn) {
        const form = document.querySelector('[data-js="swan-conn-form"]');
        if (!form) {
            return;
        }
        resetForm(form);
        const isEdit = conn && conn.id;
        editingConnId = isEdit ? conn.id : null;

        if (isEdit) {
            // Populate plain form fields (non-picker)
            const plainFields = [
                'name', 'type', 'ike_version', 'start_action', 'local_id',
                'local_auth', 'local_cert', 'eap_id',
                'remote_id', 'remote_auth', 'remote_cert',
                'role',
                'ike_rekey', 'reauth_time', 'child_rekey', 'dpd_delay', 'dpd_timeout', 'dpd_action',
                'close_action', 'pool',
                'keyingtries', 'unique', 'fragmentation',
            ];
            plainFields.forEach(f => {
                if (conn[f] !== undefined && conn[f] !== null) {
                    setFieldValue(form, f, conn[f]);
                }
            });
            // Checkboxes (send_certreq defaults to on, so it is set separately)
            ['remote_access', 'mobike', 'compress', 'forceudp', 'auto_fw_rules', 'auto_fw_rules_natt'].forEach(f => {
                setFieldValue(form, f, !!conn[f]);
            });
            setFieldValue(form, 'send_certreq', conn.send_certreq !== false);

            // interface_id uses a server-rendered <select>
            if (conn.interface_id !== undefined) {
                setFieldValue(form, 'interface_id', conn.interface_id);
            }
            // Local address-picker, mutually exclusive with interface_id
            if (conn.local_addrs) {
                setPickerValue(form, 'local_addrs', conn.local_addrs, conn.local_addrs_display?.name);
            }
            // Picker fields-UUIDs
            if (conn.remote_addrs) {
                setPickerValue(form, 'remote_addrs', conn.remote_addrs, conn.remote_addrs_display?.name);
            }
            if (conn.local_ts) {
                setPickerValue(form, 'local_ts', conn.local_ts, conn.local_ts_display?.map(d => d.name));
            }
            if (conn.remote_ts) {
                setPickerValue(form, 'remote_ts', conn.remote_ts, conn.remote_ts_display?.map(d => d.name));
            }
            // XFRM interface ID label pickers (UUID strings, optional)
            if (conn.if_id_in !== undefined && conn.if_id_in !== null) {
                setPickerValue(form, 'if_id_in', conn.if_id_in);
            }
            if (conn.if_id_out !== undefined && conn.if_id_out !== null) {
                setPickerValue(form, 'if_id_out', conn.if_id_out);
            }
            // Virtual IPs (remote-access client)
            if (conn.vips) {
                setPickerValue(form, 'vips', conn.vips, conn.vips_display?.name);
            }

            // Remote CACerts-multi-select; populate from array
            if (conn.remote_cacerts !== undefined && conn.remote_cacerts !== null) {
                const cacertsArr = Array.isArray(conn.remote_cacerts)
                    ? conn.remote_cacerts
                    : [conn.remote_cacerts];
                const cacertSelect = form.querySelector('select[name="remote_cacerts[]"]');
                if (cacertSelect) {
                    Array.from(cacertSelect.options).forEach(opt => {
                        opt.selected = cacertsArr.includes(opt.value);
                    });
                }
            }

            // Proposals
            if (Array.isArray(conn.ike_proposals)) {
                setProposals(form, 'ike', conn.ike_proposals);
            }
            if (Array.isArray(conn.esp_proposals)) {
                setProposals(form, 'esp', conn.esp_proposals);
            }
        }

        // Apply conditional visibility after populating
        applyConnectionConditions(form);
        showEditor('swan-conn-inline', isEdit ? 'Edit Connection' : 'Add Connection', isEdit ? 'Save' : 'Create');
    }

    function hideConnectionForm() {
        editingConnId = null;
        hideEditor('swan-conn-inline');
    }

    // Pool form-show / hide / populate
    let editingPoolId = null;

    function showPoolForm(pool) {
        const form = document.querySelector('[data-js="swan-pool-form"]');
        if (!form) {
            return;
        }
        resetForm(form);
        const isEdit = pool && pool.id;
        editingPoolId = isEdit ? pool.id : null;

        if (isEdit) {
            if (pool.name !== undefined) {
                setFieldValue(form, 'name', pool.name);
            }
            // Picker fields
            if (pool.addrs) {
                setPickerValue(form, 'addrs', pool.addrs, pool.addrs_display?.name);
            }
            if (pool.dns) {
                setPickerValue(form, 'dns', pool.dns, pool.dns_display?.name);
            }
            if (pool.split_include) {
                setPickerValue(form, 'split_include', pool.split_include, pool.split_include_display?.map(d => d.name));
            }
            if (pool.split_exclude) {
                setPickerValue(form, 'split_exclude', pool.split_exclude, pool.split_exclude_display?.map(d => d.name));
            }
        }

        showEditor('swan-pool-inline', isEdit ? 'Edit Address Pool' : 'Add Address Pool', isEdit ? 'Save' : 'Create');
    }

    function hidePoolForm() {
        editingPoolId = null;
        hideEditor('swan-pool-inline');
    }

    // Secret form-show / hide / populate
    let editingSecretId = null;

    function showSecretForm(sec) {
        const form = document.querySelector('[data-js="swan-secret-form"]');
        if (!form) {
            return;
        }
        resetForm(form);
        const isEdit = sec && sec.id;
        editingSecretId = isEdit ? sec.id : null;

        // Value is required on add, optional on edit (write-only policy)
        const valueInput = form.querySelector('[data-js="swan-secret-value"]');
        if (valueInput) {
            if (isEdit) {
                valueInput.removeAttribute('required');
            } else {
                valueInput.setAttribute('required', '');
            }
        }

        if (isEdit) {
            ['label', 'type', 'username', 'local_id', 'remote_id'].forEach(f => {
                if (sec[f] !== undefined) {
                    setFieldValue(form, f, sec[f]);
                }
            });
            // Value is write-only-never populated on edit
        }

        applySecretConditions(form);
        showEditor('swan-secret-inline', isEdit ? 'Edit Secret' : 'Add Secret', isEdit ? 'Save' : 'Add');
    }

    function hideSecretForm() {
        editingSecretId = null;
        hideEditor('swan-secret-inline');
    }

    // Connection form-conditional visibility
    function applyConnectionConditions(form) {
        if (!form) {
            return;
        }

        const ikeVersion = form.querySelector('[name="ike_version"]')?.value;
        const localAuth = form.querySelector('[name="local_auth"]')?.value;
        const remoteAuth = form.querySelector('[name="remote_auth"]')?.value;
        const remoteAccess = form.querySelector('[name="remote_access"]')?.checked;
        const dpdDelay = parseInt(form.querySelector('[name="dpd_delay"]')?.value, 10);

        // Filter auth options by IKE version and by remote-access mode
        filterAuthOptions(form, ikeVersion, remoteAccess);

        // Certificate rows-visible when auth is pubkey or eap-tls
        const certAuths = ['pubkey', 'eap-tls'];
        toggleCond(form, 'local-cert', certAuths.includes(localAuth));
        toggleCond(form, 'remote-cert', certAuths.includes(remoteAuth));

        // IKEv2-only fields. reauth_time is not one of them: it schedules an IKE
        // reauthentication, which is what IKEv1 does instead of rekeying, so its
        // row stays visible for every version (mobike is IKEv2-only, and the
        // dpd_timeout row below is the IKEv1-only one).
        const isV2 = ikeVersion === '2';
        toggleCond(form, 'mobike', isV2);

        const role = form.querySelector('[name="role"]')?.value;

        // Remote TS-hidden in remote-access mode, but only a road-warrior server
        // loses the field for good (its peer's traffic comes from the pool); a
        // client keeps its value (split tunnel), so the picker is left alone
        // there instead of being blanked on open.
        toggleCond(form, 'remote-ts', !remoteAccess);
        if (remoteAccess && role === 'server') {
            setPickerValue(form, 'remote_ts', '');
        }

        // Virtual IPs-shown for remote-access clients
        toggleCond(form, 'vips', remoteAccess && role === 'client');

        // Pool-shown only in remote-access mode
        toggleCond(form, 'pool', remoteAccess);

        // Role-only relevant for remote-access (roadwarrior) setups
        toggleCond(form, 'role', remoteAccess);
        const roleEl = form.querySelector('[name="role"]');

        // NAT-T sub-option visible only when the master auto-fw toggle is on
        const autoFw = form.querySelector('[name="auto_fw_rules"]')?.checked;
        toggleCond(form, 'auto-fw-natt', !!autoFw);
        if (roleEl) {
            roleEl.required = !!remoteAccess;
        }

        // DPD action-shown only when dpd_delay > 0
        toggleCond(form, 'dpd-action', dpdDelay > 0);

        // DPD timeout-IKEv1 only
        toggleCond(form, 'dpd-timeout', ikeVersion === '1');

        // EAP identity-shown when local_auth is an EAP method
        const eapAuths = ['eap-mschapv2', 'eap-tls', 'eap-radius'];
        toggleCond(form, 'eap-id', eapAuths.includes(localAuth));

        // local_addrs / interface_id mutual exclusion
        // local_addrs (address-set picker) is the standard method;
        // interface_id (<select>) is a convenience override.
        // Selecting one clears the other.
        const localAddrsInput = form.querySelector('input[name="local_addrs"]');
        const ifaceIdSel = form.querySelector('[name="interface_id"]');
        const localAddrsVal = localAddrsInput?.value || '';
        const ifaceIdVal = ifaceIdSel?.value || '';

        if (localAddrsVal && ifaceIdVal) {
            // Both have values-local_addrs wins, clear interface_id
            ifaceIdSel.value = '';
            ifaceIdSel.dispatchEvent(new Event('change', { bubbles: true }));
        }

        // Interface warning-show if no selectable interfaces (check interface_id select)
        const ifaceWarning = form.querySelector('[data-js="iface-warning-row"]');
        if (ifaceIdSel && ifaceWarning) {
            const hasSelectable = Array.from(ifaceIdSel.options).some(o => o.value && !o.disabled);
            ifaceWarning.style.display = hasSelectable ? 'none' : '';
        }

    }

    function toggleCond(form, condName, show) {
        form.querySelectorAll('[data-cond="' + condName + '"]').forEach(el => {
            el.style.display = show ? '' : 'none';
        });
    }

    function filterAuthOptions(form, ikeVersion, remoteAccess) {
        form.querySelectorAll('select[name="local_auth"], select[name="remote_auth"]').forEach(sel => {
            const current = sel.value;
            let firstVisible = null;
            let currentStillValid = false;

            Array.from(sel.options).forEach(opt => {
                const versions = (opt.dataset.versions || '').split(',');
                const allowedByVersion = versions.includes(ikeVersion);
                const isLocalSelect = sel.name === 'local_auth';
                // In remote-access mode, restrict local_auth to pubkey/psk only
                // (the gateway authenticates itself with a cert or PSK, not EAP).
                // remote_auth is intentionally left unrestricted: remote peers
                // may use any method (EAP, pubkey, psk).
                const allowedByRemoteAccess = !remoteAccess || !isLocalSelect
                    || ['pubkey', 'psk'].includes(opt.value);
                const allowed = allowedByVersion && allowedByRemoteAccess;
                opt.hidden = !allowed;
                opt.disabled = !allowed;
                if (allowed && !firstVisible) {
                    firstVisible = opt.value;
                }
                if (allowed && opt.value === current) {
                    currentStillValid = true;
                }
            });

            if (!currentStillValid && firstVisible) {
                sel.value = firstVisible;
                sel.dispatchEvent(new Event('change', { bubbles: true }));
            }
        });
    }

    function attachConnectionListeners(form) {
        if (!form) {
            return;
        }
        const condFields = ['ike_version', 'local_auth', 'remote_auth', 'remote_access', 'dpd_delay', 'pool', 'role', 'local_addrs', 'interface_id', 'auto_fw_rules'];
        condFields.forEach(name => {
            const el = form.querySelector('[name="' + name + '"]');
            if (el) {
                el.addEventListener('change', () => applyConnectionConditions(form));
                if (el.type === 'number' || el.type === 'text' || el.type === 'hidden') {
                    el.addEventListener('input', () => applyConnectionConditions(form));
                }
            }
        });

        // Clear the auto-preset highlight when the user fills in a highlighted field
        const clearHighlight = (e) => {
            const col = e.target.closest('.auto-missing');
            if (col && e.target.value) {
                col.classList.remove('auto-missing');
                col.querySelector('.auto-missing-note')?.remove();
            }
        };
        ['input', 'change'].forEach(evt => form.addEventListener(evt, clearHighlight));
    }

    // Secret form-conditional visibility
    function applySecretConditions(form) {
        if (!form) {
            return;
        }
        const secretType = form.querySelector('[name="type"]')?.value;
        // Username row-only for EAP types
        toggleCond(form, 'secret-username', secretType === 'eap-mschapv2');
        // IDs row-shown for IKE (PSK) type
        toggleCond(form, 'secret-ids', secretType === 'ike');
    }

    function attachSecretListeners(form) {
        if (!form) {
            return;
        }
        const typeSelect = form.querySelector('[name="type"]');
        if (typeSelect) {
            typeSelect.addEventListener('change', () => applySecretConditions(form));
        }
    }

    // PSK generator and clipboard
    function generatePSK() {
        const arr = new Uint8Array(32);
        crypto.getRandomValues(arr);
        return Array.from(arr, b => b.toString(16).padStart(2, '0')).join('');
    }

    function attachPSKHandlers(container) {
        const generateBtn = container.querySelector('[data-js="generate-psk"]');
        const copyBtn = container.querySelector('[data-js="copy-secret"]');
        const valueInput = container.querySelector('[data-js="swan-secret-value"]');

        if (generateBtn && valueInput) {
            generateBtn.addEventListener('click', () => {
                valueInput.value = generatePSK();
            });
        }

        if (copyBtn && valueInput) {
            copyBtn.addEventListener('click', async () => {
                try {
                    await navigator.clipboard.writeText(valueInput.value);
                    const orig = copyBtn.textContent;
                    copyBtn.textContent = 'Copied';
                    setTimeout(() => { copyBtn.textContent = orig; }, 1500);
                } catch (err) {
                    showModal('<p>Failed to copy to clipboard: ' + err.message + '</p>');
                }
            });
        }
    }

    // Proposal builder (selects rendered server-side; only JS logic remains)
    function addProposal(builder) {
        const prefix = builder.dataset.prefix;
        const encSel = builder.querySelector('[data-role="encryption"]');
        const intSel = builder.querySelector('[data-role="integrity"]');
        const dhSel = builder.querySelector('[data-role="dh"]');
        const prfSel = builder.querySelector('[data-role="prf"]');

        if (!encSel || !dhSel) {
            return;
        }

        const parts = [encSel.value];
        if (!isAead(encSel.value) && intSel) {
            parts.push(intSel.value);
        }
        if (prfSel) {
            parts.push(prfSel.value);
        }
        parts.push(dhSel.value);

        const proposal = parts.join('-');
        const hiddenInput = builder.querySelector('input[name="' + prefix + '_proposals"]');
        const current = getProposals(hiddenInput);

        if (current.includes(proposal)) {
            return;
        }
        current.push(proposal);
        hiddenInput.value = JSON.stringify(current);
        renderProposalList(builder, prefix, current);
    }

    function removeProposal(builder, index) {
        const prefix = builder.dataset.prefix;
        const hiddenInput = builder.querySelector('input[name="' + prefix + '_proposals"]');
        const current = getProposals(hiddenInput);
        current.splice(index, 1);
        hiddenInput.value = JSON.stringify(current);
        renderProposalList(builder, prefix, current);
    }

    function getProposals(hiddenInput) {
        try {
            return JSON.parse(hiddenInput.value);
        } catch {
            return [];
        }
    }

    function setProposals(form, prefix, list) {
        const builder = form.querySelector('.proposal-builder[data-prefix="' + prefix + '"]');
        if (!builder) {
            return;
        }
        const hiddenInput = builder.querySelector('input[name="' + prefix + '_proposals"]');
        hiddenInput.value = JSON.stringify(list);
        renderProposalList(builder, prefix, list);
    }

    function renderProposalList(builder, prefix, list) {
        const listEl = builder.querySelector('[data-js="' + prefix + '-proposal-list"]');
        if (!listEl) {
            return;
        }
        if (list.length === 0) {
            listEl.innerHTML = '<em>No proposals yet</em>';
            return;
        }
        listEl.innerHTML = list.map((p, i) =>
            '<div class="proposal-entry">' +
                '<span>' + p + '</span>' +
                ' <button type="button" class="std-btn btn-sm proposal-remove" data-index="' + i + '">&times;</button>' +
            '</div>'
        ).join('');
    }

    // Auto-preset application + field highlighting
    // The .auto-missing / .auto-missing-note rules live in default-vpn.css;
    // they used to be injected here as a runtime <style>.
    function clearHighlights(form) {
        if (!form) {
            return;
        }
        form.querySelectorAll('.auto-missing').forEach(el => el.classList.remove('auto-missing'));
        form.querySelectorAll('.auto-missing-note').forEach(n => n.remove());
    }

    function highlightField(el, message) {
        if (!el) {
            return;
        }
        const col = el.closest('.form-col') || el;
        col.classList.add('auto-missing');
        if (!col.querySelector('.auto-missing-note')) {
            const note = document.createElement('div');
            note.className = 'auto-missing-note';
            note.textContent = message || 'Please provide a value for this field.';
            col.appendChild(note);
        }
    }

    function highlightMissingFields(form) {
        clearHighlights(form);
        const missing = [];
        // An element is usable only if its conditional row is shown
        const visible = el => el && (!el.closest('[data-cond]') || el.closest('[data-cond]').style.display !== 'none');

        const nameEl = form.querySelector('[name="name"]');
        if (nameEl && !nameEl.value) {
            highlightField(nameEl, 'Provide a connection name for this VPN');
            missing.push(nameEl);
        }

        const iface = form.querySelector('input[name="local_addrs"]');
        if (iface && !iface.value) {
            highlightField(iface, 'Select a local address set for IKE endpoint');
            missing.push(iface);
        }

        const remoteAccess = form.querySelector('[name="remote_access"]')?.checked;
        const pool = form.querySelector('[name="pool"]');
        if (remoteAccess && pool && !pool.value) {
            highlightField(pool, 'Select or create a pool for remote clients');
            missing.push(pool);
        }

        // Role is required for remote-access connections
        const roleEl = form.querySelector('[name="role"]');
        if (remoteAccess && roleEl && !roleEl.value) {
            highlightField(roleEl, 'Select role: client or server');
            missing.push(roleEl);
        }

        // Remote address is required when start_action is start or trap
        // (except in roadwarrior mode where %any is acceptable)
        const startAction = form.querySelector('[name="start_action"]')?.value;
        const needsRemoteAddr = (startAction === 'start' || startAction === 'trap') && !remoteAccess;
        const remoteAddrs = form.querySelector('[name="remote_addrs"]');
        if (needsRemoteAddr && remoteAddrs && !remoteAddrs.value) {
            highlightField(remoteAddrs, 'Remote address is required for start/trap mode (or use Remote Access)');
            missing.push(remoteAddrs);
        }

        // Tunnel connections require traffic selectors, a pool, or XFRM interface IDs
        const connType = form.querySelector('[name="type"]')?.value;
        if (connType === 'tunnel') {
            const localTs = form.querySelector('[name="local_ts"]');
            const remoteTs = form.querySelector('[name="remote_ts"]');
            const ifIdIn = parseInt(form.querySelector('[name="if_id_in"]')?.value, 10) || 0;
            const ifIdOut = parseInt(form.querySelector('[name="if_id_out"]')?.value, 10) || 0;
            const hasXfrm = ifIdIn > 0 || ifIdOut > 0;

            if (!(localTs && localTs.value) && !(remoteTs && remoteTs.value && visible(remoteTs))
                && !(pool && pool.value && visible(pool)) && !hasXfrm) {
                const msg = 'Tunnel needs traffic selectors, a pool, or XFRM interface IDs';
                if (localTs) {
                    highlightField(localTs, msg);
                    missing.push(localTs);
                }
                if (remoteTs && visible(remoteTs)) {
                    highlightField(remoteTs, msg);
                    missing.push(remoteTs);
                }
                if (pool && visible(pool)) {
                    highlightField(pool, msg);
                    missing.push(pool);
                }
                const ifIdInEl = form.querySelector('[name="if_id_in"]');
                if (ifIdInEl) {
                    highlightField(ifIdInEl, msg);
                    missing.push(ifIdInEl);
                }
            }
        }

        const localAuth = form.querySelector('[name="local_auth"]')?.value;
        const remoteAuth = form.querySelector('[name="remote_auth"]')?.value;
        const certAuths = ['pubkey', 'eap-tls'];

        const localCert = form.querySelector('[name="local_cert"]');
        if (certAuths.includes(localAuth) && localCert && !localCert.value) {
            highlightField(localCert, 'Select a local certificate');
            missing.push(localCert);
        }

        const remoteCert = form.querySelector('[name="remote_cert"]');
        if (certAuths.includes(remoteAuth) && remoteCert && !remoteCert.value) {
            highlightField(remoteCert, 'Select a remote certificate to validate peer');
            missing.push(remoteCert);
        }

        if (missing.length > 0) {
            try { missing[0].focus(); } catch (e) { /* noop */ }
        }
        return missing.length === 0;
    }

    function applyPreset(form, preset) {
        resetForm(form);
        Object.entries(preset.values).forEach(([key, val]) => {
            setFieldValue(form, key, val);
        });
        if (preset.ike_proposals) {
            setProposals(form, 'ike', preset.ike_proposals);
        }
        if (preset.esp_proposals) {
            setProposals(form, 'esp', preset.esp_proposals);
        }
        applyConnectionConditions(form);
        highlightMissingFields(form);
        showModal('<p>Applied <strong>' + preset.label + '</strong> preset. Fill in the highlighted fields.</p>');
    }

    // Data collection from forms

    // Fields that must be sent as integers to the backend
    const NUMERIC_FIELDS = ['ike_version', 'ike_rekey', 'reauth_time', 'child_rekey', 'dpd_delay', 'dpd_timeout', 'keyingtries'];

    // Picker inputs per form: comma-separated UUIDs in hidden inputs (single
    // or array), or all selected options for multi-selects (name="field[]").
    const PICKER_FIELDS = {
        connection: {
            single: ['local_addrs', 'remote_addrs', 'if_id_in', 'if_id_out', 'vips'],
            array: ['local_ts', 'remote_ts'],
            multi: ['remote_cacerts'],
        },
        pool: {
            single: ['addrs', 'dns'],
            array: ['split_include', 'split_exclude'],
        },
    };

    // Collect a form's input, select and textarea fields into a plain object.
    // Hidden inputs are included only when includeHidden is set; fields inside
    // hidden [data-cond] rows are skipped when skipHiddenCond is set.
    function collectFormFields(form, { includeHidden = false, skipHiddenCond = false, numericFields = [] } = {}) {
        const data = {};
        form.querySelectorAll('input, select, textarea').forEach(el => {
            if (!el.name || el.type === 'button' || el.type === 'submit') {
                return;
            }
            if (el.type === 'hidden' && !includeHidden) {
                return;
            }
            const condParent = el.closest('[data-cond]');
            if (skipHiddenCond && condParent && condParent.style.display === 'none') {
                return;
            }
            if (el.type === 'checkbox') {
                data[el.name] = el.checked;
            } else if (numericFields.includes(el.name)) {
                data[el.name] = parseInt(el.value, 10) || 0;
            } else {
                data[el.name] = el.value;
            }
        });
        return data;
    }

    // Read a form's picker inputs into `data`: hidden inputs are empty strings
    // (single) or split UUID arrays.
    // On a hidden conditional row the key is left OUT of the payload (absent,
    // not empty). With the backend's current defaults-merge that clears the
    // stored value of the array fields, whose default is an empty list; once
    // edits merge the stored config instead, absent will mean "keep" and these
    // paths will need to send an explicit empty value to clear.
    function readPickerFields(form, groups, data, skipHiddenCond) {
        groups.single.forEach(name => {
            const input = form.querySelector('input[name="' + name + '"]');
            if (input) {
                data[name] = input.value || '';
            }
        });
        groups.array.forEach(name => {
            const input = form.querySelector('input[name="' + name + '"]');
            if (!input) {
                return;
            }
            const condParent = input.closest('[data-cond]');
            if (skipHiddenCond && condParent && condParent.style.display === 'none') {
                return;
            }
            data[name] = input.value ? input.value.split(',').map(s => s.trim()).filter(Boolean) : [];
        });
        groups.multi?.forEach(name => {
            const select = form.querySelector('select[name="' + name + '[]"]');
            if (!select) {
                return;
            }
            // Remove the bracketed key set by the main loop (data pollution)
            delete data[name + '[]'];
            const condParent = select.closest('[data-cond]');
            if (skipHiddenCond && condParent && condParent.style.display === 'none') {
                return;
            }
            data[name] = Array.from(select.selectedOptions).map(o => o.value).filter(Boolean);
        });
    }

    function getConnectionData(form) {
        const data = collectFormFields(form, { skipHiddenCond: true, numericFields: NUMERIC_FIELDS });

        // Skip hidden auth options (filtered by IKE version)
        form.querySelectorAll('select').forEach(sel => {
            if (sel.selectedOptions[0]?.hidden) {
                delete data[sel.name];
            }
        });

        // Parse proposal JSON arrays
        const ikeInput = form.querySelector('input[name="ike_proposals"]');
        const espInput = form.querySelector('input[name="esp_proposals"]');
        if (ikeInput) {
            data.ike_proposals = getProposals(ikeInput);
        }
        if (espInput) {
            data.esp_proposals = getProposals(espInput);
        }

        readPickerFields(form, PICKER_FIELDS.connection, data, true);

        // A road-warrior server has no remote traffic selector: the row is
        // hidden for it, and since an omitted key keeps the stored value on an
        // edit (the backend merges), it is sent explicitly empty so the store
        // matches what the form shows. For every other hidden row the backend
        // no longer writes the field, so omitting it is enough.
        const role = form.querySelector('[name="role"]')?.value;
        const remoteAccess = form.querySelector('[name="remote_access"]')?.checked;
        if (remoteAccess && role === 'server') {
            data.remote_ts = [];
        }

        return data;
    }

    function getPoolData(form) {
        const data = collectFormFields(form);
        readPickerFields(form, PICKER_FIELDS.pool, data);
        return data;
    }

    function getSecretData(form) {
        return collectFormFields(form, { skipHiddenCond: true });
    }

    // CRUD operations
    async function saveConnection() {
        const form = document.querySelector('[data-js="swan-conn-form"]');
        if (!form || !form.checkValidity()) {
            form?.reportValidity();
            return;
        }
        if (!highlightMissingFields(form)) {
            return;
        }
        const data = getConnectionData(form);
        if (editingConnId) {
            data.id = editingConnId;
        }
        await runCommand(editingConnId ? 'swan_edit_connection' : 'swan_add_connection', { connection: data }, { closeText: 'Close', reloadOnOk: true });
    }

    async function deleteConnection(id) {
        if (!confirm('Delete this connection?')) {
            return;
        }
        await runCommand('swan_delete_connection', { id }, { closeText: 'Close', reloadOnOk: true });
    }

    async function initiateConnection(id) {
        try {
            const result = await apiClient.submit('swan_conn_up', { id });
            const data = result.result || {};

            if (data.already_up || data.already_connecting) {
                showApiResult(
                    { status: 'success', response_msg: data.msg || result.response_msg },
                    { closeText: 'Cerrar' }
                );
            } else {
                showApiResult(result, { closeText: 'Cerrar', reloadOnOk: true });
            }
        } catch (err) {
            showApiResult(
                { status: 'error', response_msg: err.message },
                { title: 'Error', closeText: 'Cerrar' }
            );
        }
    }

    async function teardownConnection(id) {
        await runCommand('swan_conn_down', { id }, { closeText: 'Close', reloadOnOk: true });
    }

    async function savePool() {
        const form = document.querySelector('[data-js="swan-pool-form"]');
        if (!form || !form.checkValidity()) {
            form?.reportValidity();
            return;
        }
        const data = getPoolData(form);
        if (editingPoolId) {
            data.id = editingPoolId;
        }
        await runCommand(editingPoolId ? 'swan_edit_pool' : 'swan_add_pool', { pool: data }, { closeText: 'Close', reloadOnOk: true });
    }

    async function deletePool(id) {
        if (!confirm('Delete this pool?')) {
            return;
        }
        await runCommand('swan_delete_pool', { id }, { closeText: 'Close', reloadOnOk: true });
    }

    async function saveSecret() {
        const form = document.querySelector('[data-js="swan-secret-form"]');
        if (!form || !form.checkValidity()) {
            form?.reportValidity();
            return;
        }
        const data = getSecretData(form);
        if (editingSecretId) {
            data.id = editingSecretId;
        }
        await runCommand(editingSecretId ? 'swan_edit_secret' : 'swan_add_secret', { secret: data }, { closeText: 'Close', reloadOnOk: true });
    }

    async function deleteSecret(id) {
        if (!confirm('Delete this secret?')) {
            return;
        }
        await runCommand('swan_delete_secret', { id }, { closeText: 'Close', reloadOnOk: true });
    }

    async function saveGlobalConfig(form) {
        const data = collectFormFields(form, { includeHidden: true });

        // Nest tls_* fields under a tls object
        const tlsFlatFields = [
            'tls_version_min', 'tls_version_max',
            'tls_cipher', 'tls_ke_group', 'tls_key_exchange', 'tls_mac',
            'tls_signature', 'tls_suites',
        ];
        const tlsCheckboxFields = ['tls_send_certreq_authorities'];

        const tlsData = {};
        let hasTls = false;

        tlsFlatFields.forEach(f => {
            if (data[f]) {
                // Strip tls_ prefix for the nested key
                const nestedKey = f.replace(/^tls_/, '');
                tlsData[nestedKey] = data[f];
                hasTls = true;
            }
            delete data[f];
        });

        tlsCheckboxFields.forEach(f => {
            if (data[f] !== undefined) {
                const nestedKey = f.replace(/^tls_/, '');
                tlsData[nestedKey] = data[f];
                hasTls = true;
            }
            delete data[f];
        });

        if (hasTls) {
            data.tls = tlsData;
        }

        // Nest x509_enforce_critical under a x509 object
        if (data.x509_enforce_critical !== undefined) {
            data.x509 = { enforce_critical: data.x509_enforce_critical };
        }
        delete data.x509_enforce_critical;

        // Collect interfaces_use multi-select as array of UUIDs
        const ifaceUseSelect = form.querySelector('select[name="interfaces_use[]"]');
        if (ifaceUseSelect) {
            const selected = Array.from(ifaceUseSelect.selectedOptions)
                .map(o => o.value)
                .filter(Boolean);
            data.interfaces_use = selected;
            delete data['interfaces_use[]'];
        }

        await runCommand('swan_set_global_config', { config: data }, { closeText: 'Close', reloadOnOk: true });
    }

    async function reloadAll() {
        await runCommand('swan_reload_all', {}, { closeText: 'Close', reloadOnOk: true });
    }

    // Refresh buttons. Both tables are rendered server-side from the page data
    // (which now carries what the formatter decided, e.g. the initiate
    // buttons), so a refresh means reloading the page. Re-rendering the status
    // table here was a second implementation of it and had drifted from the
    // server's: badges without their dot and road-warrior rows collapsed.
    function reloadPageAfterConfirm() {
        const openEditors = ['swan-conn-inline', 'swan-pool-inline', 'swan-secret-inline']
            .filter(id => {
                const el = document.getElementById(id);
                return el && el.style.display !== 'none';
            });
        if (openEditors.length > 0 && !confirm('You have unsaved changes in an open editor. Discard and refresh?')) {
            return;
        }
        location.reload();
    }

    // Apply the initiate (bring-up) decision the server computed: which
    // connections may be initiated and why not is decided in
    // StrongswanFormatter (role, trap, admin_state) and shipped in
    // initiate_allowed / initiate_title / initiate_disabled_title. Do not
    // re-derive that policy here: recomputing it is how the two layers
    // drifted apart, with the client enabling buttons the server disabled.
    function updateInitiateButtonStates() {
        try {
            if (!Array.isArray(window.swanConnections)) {
                return;
            }
            window.swanConnections.forEach(conn => {
                const id = String(conn.id);
                const btn = document.querySelector('#swan-connections-table button.swan-conn-up[data-id="' + id + '"]');
                if (!btn) return;
                if (conn.initiate_allowed === false) {
                    btn.disabled = true;
                    btn.title = conn.initiate_disabled_title || '';
                } else {
                    btn.disabled = false;
                    btn.title = conn.initiate_title || 'Bring Up';
                }
            });
        } catch (e) {
            /* noop */
        }
    }

    // Status tab: expand/collapse an IKE_SA row to reveal its CHILD_SAs, and
    // auto-expand roadwarrior connections (2+ CHILD_SAs) on page load.
    function initStatusTable() {
        document.addEventListener('click', (e) => {
            const expandBtn = e.target.closest('[data-js="swan-expand-ike"]');
            if (!expandBtn) {
                return;
            }
            const ikeRow = expandBtn.closest('.swan-ike-row');
            if (!ikeRow) {
                return;
            }
            const ikeId = ikeRow.dataset.ikeId;
            const childRows = document.querySelectorAll('.swan-child-row[data-ike-parent="' + ikeId + '"]');
            const isExpanded = expandBtn.textContent.trim() === '▼';
            childRows.forEach(row => {
                row.style.display = isExpanded ? 'none' : '';
            });
            expandBtn.textContent = isExpanded ? '▶' : '▼';
        });

        document.querySelectorAll('.swan-ike-row').forEach(row => {
            const ikeId = row.dataset.ikeId;
            const childRows = document.querySelectorAll('.swan-child-row[data-ike-parent="' + ikeId + '"]');
            if (childRows.length >= 2) {
                const btn = row.querySelector('[data-js="swan-expand-ike"]');
                childRows.forEach(r => { r.style.display = ''; });
                if (btn) {
                    btn.textContent = '▼';
                }
            }
        });

        updateInitiateButtonStates();
    }

    // Button clicks from the status tables and inline editors dispatch to
    // their actions (add/edit/delete, bring-up/teardown, inline save/cancel,
    // proposal-builder add/remove, auto-preset).
    function initClickHandlers() {
        const connForm = document.querySelector('[data-js="swan-conn-form"]');
        document.addEventListener('click', (e) => {
            const target = e.target;
            const btn = target.closest('button');
            if (!btn) {
                return;
            }

            // Add / toggle buttons
            if (btn.id === 'btn-add-connection') {
                const container = document.getElementById('swan-conn-inline');
                if (container && container.style.display !== 'none') {
                    hideConnectionForm();
                } else {
                    showConnectionForm(null);
                }
                return;
            }
            if (btn.id === 'btn-add-pool') {
                const container = document.getElementById('swan-pool-inline');
                if (container && container.style.display !== 'none') {
                    hidePoolForm();
                } else {
                    showPoolForm(null);
                }
                return;
            }
            if (btn.id === 'btn-add-secret') {
                const container = document.getElementById('swan-secret-inline');
                if (container && container.style.display !== 'none') {
                    hideSecretForm();
                } else {
                    showSecretForm(null);
                }
                return;
            }

            // Refresh / reload buttons
            if (btn.id === 'btn-refresh-status' || btn.id === 'btn-refresh-connections') {
                reloadPageAfterConfirm();
                return;
            }
            if (btn.id === 'btn-reload-all') {
                reloadAll();
                return;
            }

            // Connection table actions (delegated via CSS class)
            const id = btn.dataset.id;

            if (btn.classList.contains('swan-conn-edit')) {
                const conn = window.swanConnections.find(c => String(c.id) === String(id));
                if (conn) {
                    showConnectionForm(conn);
                }
                return;
            }
            if (btn.classList.contains('swan-conn-delete')) {
                deleteConnection(id);
                return;
            }
            if (btn.classList.contains('swan-conn-up')) {
                initiateConnection(id);
                return;
            }
            if (btn.classList.contains('swan-conn-down')) {
                teardownConnection(id);
                return;
            }

            // Pool table actions
            if (btn.classList.contains('swan-pool-edit')) {
                const pool = window.swanPools.find(p => String(p.id) === String(id));
                if (pool) {
                    showPoolForm(pool);
                }
                return;
            }
            if (btn.classList.contains('swan-pool-delete')) {
                deletePool(id);
                return;
            }

            // Secret table actions
            if (btn.classList.contains('swan-secret-edit')) {
                const sec = window.swanSecrets.find(s => String(s.id) === String(id));
                if (sec) {
                    showSecretForm(sec);
                }
                return;
            }
            if (btn.classList.contains('swan-secret-delete')) {
                deleteSecret(id);
                return;
            }

            // Inline editor save / cancel (data-js attributes)
            const jsAction = btn.dataset.js;
            if (jsAction === 'inline-save') {
                const editor = btn.closest('.inline-editor');
                const entity = editor?.dataset.entity;
                if (entity === 'connection') {
                    saveConnection();
                } else if (entity === 'pool') {
                    savePool();
                } else if (entity === 'secret') {
                    saveSecret();
                }
                return;
            }
            if (jsAction === 'inline-cancel') {
                const editor = btn.closest('.inline-editor');
                const entity = editor?.dataset.entity;
                if (entity === 'connection') {
                    hideConnectionForm();
                } else if (entity === 'pool') {
                    hidePoolForm();
                } else if (entity === 'secret') {
                    hideSecretForm();
                }
                return;
            }

            // Proposal builder-add
            if (btn.classList.contains('proposal-add')) {
                const builder = btn.closest('.proposal-builder');
                if (builder) {
                    addProposal(builder);
                }
                return;
            }

            // Proposal builder-remove
            if (btn.classList.contains('proposal-remove')) {
                const builder = btn.closest('.proposal-builder');
                const index = parseInt(btn.dataset.index, 10);
                if (builder && !isNaN(index)) {
                    removeProposal(builder, index);
                }
                return;
            }

            // Auto-preset buttons
            if (jsAction === 'auto-site-to-site') {
                applyPreset(connForm, PRESETS['site-to-site']);
                return;
            }
            if (jsAction === 'auto-roadwarrior-server') {
                applyPreset(connForm, PRESETS['roadwarrior-server']);
                return;
            }
            if (jsAction === 'auto-roadwarrior-client') {
                applyPreset(connForm, PRESETS['roadwarrior-client']);
                return;
            }
        });
    }

    // Event delegation and initialisation
    document.addEventListener('DOMContentLoaded', () => {
        initCollapsible();

        // Initialise all picker fields on the page
        if (window.setsModal) {
            window.setsModal.initPickerFields(document);
        }
        if (window.labelsMgmt) {
            window.labelsMgmt.initPickerFields(document);
        }

        // Connection form listeners
        const connForm = document.querySelector('[data-js="swan-conn-form"]');
        attachConnectionListeners(connForm);

        // Remote CA Certs multi-select: clear button
        document.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-js="swan-cacerts-clear"]');
            if (!btn) {
                return;
            }
            const select = document.querySelector('select[data-js="swan-remote-cacerts"]');
            if (select) {
                Array.from(select.options).forEach(opt => { opt.selected = false; });
                select.dispatchEvent(new Event('change', { bubbles: true }));
            }
        });

        // Bind IKE Sockets multi-select: the "None" option deselects all interfaces
        const ifaceUseSelect = document.getElementById('swan-interfaces-use');
        if (ifaceUseSelect) {
            ifaceUseSelect.addEventListener('change', () => {
                const noneOpt = ifaceUseSelect.querySelector('option[value=""]');
                if (!noneOpt) return;
                if (noneOpt.selected) {
                    // "None" selected: clear every real interface option
                    Array.from(ifaceUseSelect.options).forEach(opt => {
                        if (opt.value !== '') opt.selected = false;
                    });
                } else if (ifaceUseSelect.selectedOptions.length > 0) {
                    // A real interface selected: drop the "None" option
                    noneOpt.selected = false;
                }
            });
        }

        // AEAD toggle: hide integrity when AEAD cipher selected (selects rendered server-side)
        if (connForm) {
            connForm.addEventListener('change', (e) => {
                if (e.target.dataset.role === 'encryption') {
                    const builder = e.target.closest('.proposal-builder');
                    if (!builder) {
                        return;
                    }
                    const intCol = builder.querySelector('[data-role="integrity-col"]');
                    if (intCol) {
                        intCol.style.display = isAead(e.target.value) ? 'none' : '';
                    }
                }
            });
        }

        // Secret form listeners
        const secretForm = document.querySelector('[data-js="swan-secret-form"]');
        attachSecretListeners(secretForm);
        const secretContainer = document.getElementById('swan-secret-inline');
        if (secretContainer) {
            attachPSKHandlers(secretContainer);
        }

        // Apply initial conditions
        if (connForm) {
            applyConnectionConditions(connForm);
        }
        if (secretForm) {
            applySecretConditions(secretForm);
        }

        initStatusTable();

        // Global config form submit
        const globalForm = document.getElementById('swan-global-form');
        if (globalForm) {
            globalForm.addEventListener('submit', (e) => {
                e.preventDefault();
                saveGlobalConfig(globalForm);
            });
        }

        initClickHandlers();
    });
})();
