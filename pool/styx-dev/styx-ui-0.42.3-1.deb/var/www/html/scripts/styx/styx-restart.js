document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('restart-form').addEventListener('submit', function(e) {
        e.preventDefault();
        var form = this;
        var msg = document.getElementById('restart-msg');
        msg.textContent = '';
        var btns = form.querySelectorAll('button');
        btns.forEach(b => b.disabled = true);
        apiClient.submit('restart-daemon', {})
        .then(function(resp) {
            if (resp.status === 'success') {
                msg.style.color = '#2ecc40';
                msg.textContent = 'Reboot requested successfully. Logging out in 5 seconds...';
                // The restart kills the session, so this page would otherwise sit
                // here forever. Give the message a moment to be read, then hand off
                // to the logout path so the user lands on login.
                setTimeout(function() {
                    window.location.href = '?page=logout';
                }, 5000);
            } else {
                msg.style.color = '#e74c3c';
                msg.textContent = resp.response_msg || 'Error requesting reboot.';
                btns.forEach(b => b.disabled = false);
            }
        })
        .catch(function() {
            msg.style.color = '#e74c3c';
            msg.textContent = 'Network error while requesting reboot.';
            btns.forEach(b => b.disabled = false);
        });
    });
});
