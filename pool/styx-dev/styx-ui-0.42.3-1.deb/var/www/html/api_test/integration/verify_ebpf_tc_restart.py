#!/usr/bin/env python3
"""Does a tc module that persists survive a real restart of the daemon, and is it adopted?

Flow: load a `tc_*` module that persists -> push an entry into one of its control maps ->
**save the config** -> **restart the daemon through the API** -> wait for a new process to
answer -> assert that the same instance is loaded with the **same program id** and the **same
link id**, and that the entry is still in the kernel map -> unload -> save again -> leftover
invariant.

The save is not decoration: the daemon boots from startup-config (copied over running-config
at the start) and a load only writes running-config, so an instance that was never saved is
gone at the next boot. That is the design (it is what the UI's Save does) and not a defect,
but it means the flow has a save on each side: without the second one the instance would stay
in the persistent config and come back at the next boot, which is the opposite of leaving the
box clean.

Why this one exists: it is the only part of the tc path that cannot be checked without
restarting the service. Everything else is covered by `verify_ebpf_tc.py` (the attach, the
reload in place) and from inside the box by `cli_tests/ebpf_tc_attach/` (the order, the pin).

What it proves, and why each part is needed:

  * the module **persists**: the link is pinned, so it outlives the process that attached it;
  * the new process **adopts** it: the kernel program id is the same one as before the
    restart. A module that was unloaded and loaded again would come back with a new id, and
    a module that did not come back at all would be missing from the list;
  * the link is the **same link**: the link id does not change. This is what "the attachment
    survived" means, and it is read from the instance view (`attachment.link_id`);
  * the **maps are the kernel's**, not new ones: the entry pushed before the restart is still
    there afterwards, without replaying anything. A fresh load would show it too (the
    control data is replayed from disk), which is why this alone is not the proof -- the
    program id is.

It restarts the daemon, so read this before pointing it at a box:
  * the API is down for the length of the boot (~40 s measured; the unit has `Restart=always`
    with a 5 s delay, and the TCP server comes up at the end of the configure pipeline);
  * everything else the gateway manages is reconciled on that boot, as in any restart. On a
    lab that is fine; on a box passing traffic it is a service interruption **you** asked for;
  * the module is a blocker with an empty blocklist (plus the one entry this pushes), so
    nothing else is filtered while it is loaded;
  * it **writes the persistent config** (that is what makes the instance survive the restart):
    if it is killed between the two saves, the instance stays in startup-config and comes back
    at the next boot. Unload it and save again to clean that up.

Usage:
    python api_test/integration/verify_ebpf_tc_restart.py --target NAME [--interface testbrid]
"""

import os
import sys
import time

if __package__ is None:  # run as a file (not via `python -m`): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish

DEFAULT_INTERFACE = "testbrid"  # the lab's test bridge: no IP, nothing riding on it
MODULE = "net_block"  # the one that persists: its link is pinned, which is what there is to adopt
MAP = "blocklist"
ENTRY = "198.51.100.7"  # TEST-NET-2: a valid address that cannot be anything on the box
RESTART_TIMEOUT_S = 180


def _snapshot(resp):
    result = resp["result"]
    return {
        "unmanaged": len(result.get("unmanaged_programs") or []),
        "stale": len(result.get("stale_components") or []),
        "missing": len(result.get("missing_components") or []),
        "styx_programs": result.get("styx_program_count", 0),
    }


def _instance(resp, instance_id):
    for item in resp["result"].get("instances") or []:
        if item.get("instance_id") == instance_id:
            return item
    return None


def _map_has(client, instance_id, entry):
    """The keys of a control map, read from the kernel, as plain strings for comparison."""
    resp = require_ok(
        client.request("ebpf_get_control_map", {"module": instance_id, "map": MAP}), "result.entries"
    )
    keys = set()
    for item in resp["result"].get("entries") or []:
        key = item.get("key")
        if isinstance(key, dict):
            keys.add(str(key.get("ip") or key))
        else:
            keys.add(str(key))
    return entry in keys


def _styx_uptime(client):
    """How long the daemon has been up, in seconds, or None when it does not report one."""
    resp = client.request("ping", {"client_timestamp": int(time.time()), "uptime": True})
    if not isinstance(resp, dict) or resp.get("status") != "success":
        return None
    value = ((resp.get("result") or {}).get("uptime") or {}).get("styx")
    return float(value) if isinstance(value, (int, float)) else None


def _wait_for_a_new_process(client, before):
    """Wait until the API answers *and* it is a different daemon.

    The restart is not instantaneous: the handler answers and the process goes down a moment
    later, so polling for "it answers again" can be satisfied by the process that is on its way
    out. It answers exactly what it did before, and every check below would pass without a
    restart having happened. The uptime is what tells the two apart (and, when the daemon does
    not report one, the wait falls back to requiring that the connection was refused first).
    """
    deadline = time.monotonic() + RESTART_TIMEOUT_S
    went_down = False
    while time.monotonic() < deadline:
        try:
            uptime = _styx_uptime(client)
        except ApiError:
            went_down = True
            uptime = None
        if uptime is not None:
            if before is None:
                if went_down:
                    return
            elif uptime < before:
                return
        time.sleep(3)
    raise AssertionError(
        f"the daemon did not come back as a new process within {RESTART_TIMEOUT_S} s "
        f"(uptime before: {before}, went down: {went_down})"
    )


def _wait_until_loaded(client, instance_id):
    """Poll until the instance is loaded again, or give up.

    A refused connection is the normal answer while the daemon restarts, so it is not an
    error: `None` comes back and the caller retries.
    """
    deadline = time.monotonic() + RESTART_TIMEOUT_S
    last = "no answer yet"
    while time.monotonic() < deadline:
        try:
            listed = _instance(require_ok(client.request("ebpf_get_module_list")), instance_id)
        except ApiError as e:
            last = f"the API is not answering yet ({e})"
            time.sleep(3)
            continue
        if listed and listed.get("status") == "loaded" and listed.get("program_id") is not None:
            return listed
        last = f"the instance is {listed.get('status') if listed else 'not listed'}"
        time.sleep(3)
    raise AssertionError(f"the instance did not come back within {RESTART_TIMEOUT_S} s: {last}")


def run(client, iface_name):
    tracker = ResourceTracker()

    def module_list():
        return require_ok(client.request("ebpf_get_module_list"), "result.instances")

    try:
        resp = require_ok(client.request("get_interfaces_names_ds"), "result.ifaces_list")
        iface_uuid = None
        for item in resp["result"]["ifaces_list"]:
            if item.get("interface") == iface_name and item.get("id"):
                iface_uuid = item["id"]
                break
        if iface_uuid is None:
            raise AssertionError(f"interface {iface_name} not found in get_interfaces_names_ds")
        print(f"  OK   {iface_name} = {iface_uuid}")

        before_list = module_list()
        before = _snapshot(before_list)
        if before["unmanaged"] or before["stale"]:
            raise AssertionError(
                f"the box is not clean to start with ({before['unmanaged']} unmanaged, "
                f"{before['stale']} stale); clean those first, see api_test/consistency"
            )
        print(f"  OK   baseline: {before}")

        loaded = require_ok(
            client.submit("ebpf_load_module", {"module": MODULE, "interface": iface_uuid}),
            "result.instance_ids",
        )
        instance_id = (loaded["result"]["instance_ids"] or [None])[0]
        if not instance_id:
            raise AssertionError(f"load succeeded but returned no instance id: {loaded}")
        # Armed before the restart: if anything below fails, the cleanup tries to unload it.
        tracker.remember("ebpf_unload_module", {"module": instance_id})
        print(f"  OK   loaded {MODULE} as {instance_id}")

        # The data that has to still be there after the restart, pushed and read back from the
        # kernel before it (so the check is about the maps surviving, not about the file).
        require_ok(
            client.submit(
                "ebpf_control_push",
                {"module": instance_id, "map": MAP, "items": [ENTRY], "op": "upsert"},
            )
        )
        if not _map_has(client, instance_id, ENTRY):
            raise AssertionError(f"the entry {ENTRY} is not in {MAP} right after pushing it")
        print(f"  OK   {ENTRY} pushed into {MAP} and read back from the kernel")

        listed = _instance(module_list(), instance_id)
        attachment = listed.get("attachment") or {}
        program_id = listed.get("program_id")
        link_id = attachment.get("link_id")
        if program_id is None or link_id is None:
            raise AssertionError(f"the instance must report its program and its link: {listed}")
        print(f"  OK   attached as {attachment.get('kind')} (link {link_id}, program {program_id})")

        # The config has to be saved for the instance to be there after the restart, and this is
        # the design and not a defect: the daemon boots from startup-config (copied over
        # running-config at the start), while a load only writes running-config. It is the same
        # Save the UI does, and the same reason a module loaded by hand and never saved is gone
        # at the next boot.
        require_ok(client.submit("save_config", {}))
        print("  OK   config saved, so the instance is part of what the daemon boots with")

        uptime_before = _styx_uptime(client)
        print(
            f"  OK   the daemon has been up {uptime_before:.0f} s"
            if uptime_before is not None
            else "  ..   the daemon does not report its uptime; the wait will use the connection"
        )
        print("  ..   restarting the daemon through the API")
        try:
            client.submit("restart-daemon", {})
        except ApiError as e:
            # The daemon exits while answering, so a broken response here means it did restart.
            print(f"  OK   restart requested (the connection ended as it went down: {e})")
        else:
            print("  OK   restart requested")

        _wait_for_a_new_process(client, uptime_before)
        print("  OK   a new daemon is answering")
        listed = _wait_until_loaded(client, instance_id)
        after_attachment = listed.get("attachment") or {}
        print(
            f"  OK   the instance is back: program {listed.get('program_id')}, "
            f"link {after_attachment.get('link_id')}"
        )

        if listed["program_id"] != program_id:
            raise AssertionError(
                f"the module was NOT adopted: its program went from {program_id} to "
                f"{listed['program_id']}. A new program id means the daemon unloaded it and "
                f"loaded it again instead of taking the one the kernel still had, which is the "
                f"difference between a pinned link (persist = true) and a fresh attach."
            )
        print(f"  OK   adopted: the same program {program_id} is still behind the hook")

        if after_attachment.get("link_id") != link_id:
            raise AssertionError(
                f"the link is not the one that survived: it went from {link_id} to "
                f"{after_attachment.get('link_id')}. The pin is what keeps it, so a different "
                f"link id means the attachment was rebuilt."
            )
        print(f"  OK   the same link {link_id} came through the restart")

        if not _map_has(client, instance_id, ENTRY):
            raise AssertionError(
                f"the entry {ENTRY} is gone from {MAP} after the restart. With the same program "
                f"id the maps are the kernel's and the data cannot be lost, so this is a "
                f"contradiction and not a slow reconciliation."
            )
        print(f"  OK   the kernel map kept {ENTRY}, so its maps are the ones from before")

        require_ok(client.submit("ebpf_unload_module", {"module": instance_id}))
        tracker.forget("ebpf_unload_module", {"module": instance_id})
        # And saved again, so the instance is out of the persistent config too: leaving it there
        # would bring it back at the next boot, which is the opposite of leaving the box clean.
        require_ok(client.submit("save_config", {}))

        after_list = module_list()
        after = _snapshot(after_list)
        print(f"  OK   after unload: {after}")
        for key in ("unmanaged", "stale", "missing", "styx_programs"):
            if after[key] != before[key]:
                raise AssertionError(
                    f"unload left something behind: {key} went from {before[key]} to {after[key]}. "
                    f"A pinned link whose instance is gone keeps the program attached and its "
                    f"maps alive, and it shows up in unmanaged_programs."
                )
        print("  OK   nothing of ours was left behind")

    finally:
        tracker.cleanup(client)


def main():
    parser = build_parser("Verify a persisted tc module is adopted across a daemon restart (RESTARTS IT)")
    parser.add_argument(
        "--interface",
        default=DEFAULT_INTERFACE,
        help=f"interface to load on (default: {DEFAULT_INTERFACE})",
    )
    args = parser.parse_args()
    client = build_client(args)
    try:
        run(client, args.interface)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
