#!/usr/bin/env python3
"""Does a module on the direct XDP lane survive a real restart of the daemon, and is it adopted?

Flow: load `xdp_cpu_redirect` -> push a flag into one of its control maps -> **save the config** ->
**restart the daemon through the API** -> wait for a new process to answer -> assert that the same
instance is loaded with the **same program id** and the **same link id**, that the flag is still in
the kernel map, and that the maps its companion fills at load time are still there -> unload -> save
again -> leftover invariant.

The save is not decoration: the daemon boots from startup-config (copied over running-config at the
start) and a load only writes running-config, so an instance that was never saved is gone at the next
boot. That is the design and not a defect, but it means the flow has a save on each side: without the
second one the instance would stay in the persistent config and come back at the next boot, which is
the opposite of leaving the box clean.

Why this one exists, next to `verify_ebpf_xdp_direct.py`: the pin, the adoption and the boot
reconcile are the only parts of the lane that cannot be checked without restarting the service.
Everything else (the attach, the exclusivity, the in-place reload) is in the other script. What each
part proves:

  * the module **persists**: its link is pinned under `/sys/fs/bpf/styx/xdp`, so it outlives the
    process that attached it;
  * the new process **adopts** it: the kernel program id is the same one as before the restart. A
    module that was unloaded and loaded again would come back with a new id, and one that did not
    come back at all would be missing from the list (the lane's own `missing_components` reads the
    device's XDP attachment, so it would say so);
  * the link is the **same link**: the link id does not change. That is what "the attachment
    survived" means, and it is read from the instance view (`attachment.link_id`), which for this
    lane is reported with `kind: "xdp_direct"`;
  * the **maps are the kernel's**, not new ones: the pushed flag is still there without the boot
    having to replay anything;
  * the maps the **companion builds at load time** are there too (`cpus_count`, filled by the
    `init_hook`). This is the half that a plain load covers by hand and that a restart only covers if
    every path that puts a module on the kernel runs that hook - the boot reconcile included. A
    module whose CPUMAP came back empty would be attached, passing traffic and steering nothing.

It restarts the daemon, so read this before pointing it at a box:
  * the API is down for the length of the boot (~40 s measured; the unit has `Restart=always` with a
    5 s delay, and the TCP server comes up at the end of the configure pipeline);
  * everything else the gateway manages is reconciled on that boot, as in any restart. On a lab that
    is fine; on a box passing traffic it is a service interruption **you** asked for;
  * while it runs, the module holds the interface's only XDP slot, and on a driver without native XDP
    it attaches in generic mode (the gateway logs an ERROR saying so; expected on the test bridge);
  * it **writes the persistent config** (that is what makes the instance survive the restart): if it
    is killed between the two saves, the instance stays in startup-config and comes back at the next
    boot. Unload it and save again to clean that up.

Usage:
    python api_test/integration/verify_ebpf_xdp_direct_restart.py --target NAME [--interface testbrid]
"""

import os
import sys
import time

if __package__ is None:  # run as a file (not via `python -m`): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish

DEFAULT_INTERFACE = "testbrid"  # the lab's test bridge: no IP, nothing riding on it
MODULE = "xdp_cpu_redirect"  # the module that persists on the direct lane
PARAMS = {"cpu_list": "0"}  # its required pre-attach param: the CPU pool to steer into
CFG_MAP = "cfg_map"  # its runtime flags (key 0: GRE decapsulation on/off)
CFG_ENTRY = {"key": 0, "value": 0}  # read back: gre_decap off, which is not the shipped default
BUILT_MAP = "cpus_count"  # filled by the companion's init_hook, not by any user push
BUILT_KEY = 0
BUILT_VALUE = "1"
RESTART_TIMEOUT_S = 180


def _snapshot(resp):
    result = resp["result"]
    return {
        "unmanaged": len(result.get("unmanaged_programs") or []),
        "stale": len(result.get("stale_components") or []),
        "missing": len(result.get("missing_components") or []),
        "styx_programs": result.get("styx_program_count", 0),
    }


def _instance(resp, instance_id):
    for item in resp["result"].get("instances") or []:
        if item.get("instance_id") == instance_id:
            return item
    return None


def _entry_value(client, instance_id, map_name, key):
    """The value of *key* in *map_name*, as the companion formatted it back (a string or an int)."""
    resp = require_ok(
        client.request("ebpf_get_control_map", {"module": instance_id, "map": map_name}), "result.entries"
    )
    for entry in resp["result"].get("entries") or []:
        entry_key = entry.get("key") if isinstance(entry, dict) else None
        if isinstance(entry_key, dict):
            entry_key = entry_key.get("key", entry_key)
        if str(entry_key) == str(key):
            return entry.get("value")
    return None


def _styx_uptime(client):
    """How long the daemon has been up, in seconds, or None when it does not report one."""
    resp = client.request("ping", {"client_timestamp": int(time.time()), "uptime": True})
    if not isinstance(resp, dict) or resp.get("status") != "success":
        return None
    value = ((resp.get("result") or {}).get("uptime") or {}).get("styx")
    return float(value) if isinstance(value, (int, float)) else None


def _wait_for_a_new_process(client, before):
    """Wait until the API answers *and* it is a different daemon.

    The restart is not instantaneous: the handler answers and the process goes down a moment later,
    so polling for "it answers again" can be satisfied by the process that is on its way out, and
    every check below would pass without a restart having happened. The uptime is what tells the two
    apart (and, when the daemon does not report one, the wait falls back to requiring that the
    connection was refused first).
    """
    deadline = time.monotonic() + RESTART_TIMEOUT_S
    went_down = False
    while time.monotonic() < deadline:
        try:
            uptime = _styx_uptime(client)
        except ApiError:
            went_down = True
            uptime = None
        if uptime is not None:
            if before is None:
                if went_down:
                    return
            elif uptime < before:
                return
        time.sleep(3)
    raise AssertionError(
        f"the daemon did not come back as a new process within {RESTART_TIMEOUT_S} s "
        f"(uptime before: {before}, went down: {went_down})"
    )


def _wait_until_loaded(client, instance_id):
    """Poll until the instance is loaded again, or give up.

    A refused connection is the normal answer while the daemon restarts, so it is not an error:
    `None` comes back and the caller retries.
    """
    deadline = time.monotonic() + RESTART_TIMEOUT_S
    last = "no answer yet"
    while time.monotonic() < deadline:
        try:
            listed = _instance(require_ok(client.request("ebpf_get_module_list")), instance_id)
        except ApiError as e:
            last = f"the API is not answering yet ({e})"
            time.sleep(3)
            continue
        if listed and listed.get("status") == "loaded" and listed.get("program_id") is not None:
            return listed
        last = f"the instance is {listed.get('status') if listed else 'not listed'}"
        time.sleep(3)
    raise AssertionError(f"the instance did not come back within {RESTART_TIMEOUT_S} s: {last}")


def _first_entry_value(client, instance_id, map_name):
    """The value of the first entry of *map_name*, as the map reader returns it.

    A map whose companion declares how to format it comes back as plain types (`cfg_map`: key 0,
    value 1). One that does not comes back as the raw bytes in hex, little-endian, which is how the
    kernel holds a `__u32` (`cpus_count`: `"01000000"`). Both shapes are what the API answers with,
    so the value is decoded where it is a raw one.
    """
    resp = require_ok(
        client.request("ebpf_get_control_map", {"module": instance_id, "map": map_name}), "result.entries"
    )
    entries = resp["result"].get("entries") or []
    return entries[0].get("value") if entries else None


def _u32_of(value):
    """A raw map value as an integer: four hex bytes, little-endian, or None."""
    if not isinstance(value, str):
        return value
    try:
        return int.from_bytes(bytes.fromhex(value), "little")
    except ValueError:
        return None


def run(client, iface_name):
    tracker = ResourceTracker()

    def module_list():
        return require_ok(client.request("ebpf_get_module_list"), "result.instances")

    try:
        resp = require_ok(client.request("get_interfaces_names_ds"), "result.ifaces_list")
        iface_uuid = None
        for item in resp["result"]["ifaces_list"]:
            if item.get("interface") == iface_name and item.get("id"):
                iface_uuid = item["id"]
                break
        if iface_uuid is None:
            raise AssertionError(f"interface {iface_name} not found in get_interfaces_names_ds")
        print(f"  OK   {iface_name} = {iface_uuid}")

        before_list = module_list()
        before = _snapshot(before_list)
        print(f"  OK   baseline: {before}")
        if before["unmanaged"] or before["stale"]:
            raise AssertionError(
                f"the box is not clean to start with ({before['unmanaged']} unmanaged, "
                f"{before['stale']} stale); clean those first, see api_test/consistency"
            )
        for entry in before_list["result"].get("instances") or []:
            if entry.get("hook_type") == "xdp" and entry.get("interface") == iface_name:
                raise AssertionError(
                    f"{iface_name} already carries XDP module {entry.get('name')} (instance "
                    f"{entry.get('instance_id')}); a device has one XDP slot, so unload it first"
                )

        loaded = require_ok(
            client.submit("ebpf_load_module", {"module": MODULE, "interface": iface_uuid, "params": PARAMS}),
            "result.instance_ids",
        )
        instance_id = loaded["result"]["instance_ids"][0]
        # Armed before the restart: if anything below fails, the cleanup tries to unload it. The
        # instance is in the persistent config from the save below on, so the cleanup saves again.
        tracker.remember("ebpf_unload_module", {"module": instance_id})
        print(f"  OK   loaded {MODULE} with {PARAMS} as {instance_id}")

        listed = _wait_until_loaded(client, instance_id)
        attachment = listed.get("attachment") or {}
        if attachment.get("kind") != "xdp_direct" or attachment.get("link_id") is None:
            raise AssertionError(f"the instance must be attached as a direct link: {attachment}")
        link_id = attachment["link_id"]
        program_id = listed["program_id"]
        print(f"  OK   attached as {attachment['kind']} (link {link_id}, program {program_id})")

        # The data that has to still be there after the restart. It goes into a map the user can
        # write (cfg_map), so it is the one that tells "the maps are the kernel's" apart from "the
        # boot replayed the config", and the one whose absence after a restart would be a real loss.
        require_ok(
            client.submit(
                "ebpf_control_push",
                {"module": instance_id, "map": CFG_MAP, "items": [CFG_ENTRY], "op": "upsert"},
            )
        )
        read_back = _entry_value(client, instance_id, CFG_MAP, CFG_ENTRY["key"])
        if str(read_back) != str(CFG_ENTRY["value"]):
            raise AssertionError(f"{CFG_MAP}[{CFG_ENTRY['key']}] reads {read_back!r}, pushed {CFG_ENTRY['value']}")
        print(f"  OK   {CFG_MAP}[{CFG_ENTRY['key']}] = {read_back}, pushed and read back from the kernel")

        require_ok(client.submit("save_config", {}))
        print("  OK   config saved, so the instance is part of what the daemon boots with")

        uptime_before = _styx_uptime(client)
        print(
            f"  OK   the daemon has been up {uptime_before:.0f} s"
            if uptime_before is not None
            else "  ..   the daemon does not report its uptime; the wait will use the connection"
        )

        print("  ..   restarting the daemon through the API")
        try:
            client.submit("restart-daemon", {})
        except ApiError as e:
            # The connection dying here is the restart starting, not a failure.
            print(f"  ..   the connection went down as expected: {e}")
        _wait_for_a_new_process(client, uptime_before)
        print("  OK   the daemon is back as a new process")

        listed = _wait_until_loaded(client, instance_id)
        attachment = listed.get("attachment") or {}
        if listed["program_id"] != program_id:
            raise AssertionError(
                f"the module was not adopted: the program id went from {program_id} to "
                f"{listed['program_id']}. A fresh load behind the pin would do that, and so would "
                f"a module that did not come back at all."
            )
        if attachment.get("link_id") != link_id:
            raise AssertionError(
                f"the attachment is not the same link: it went from {link_id} to "
                f"{attachment.get('link_id')}"
            )
        if attachment.get("kind") != "xdp_direct":
            raise AssertionError(f"the lane changed across the restart: {attachment}")
        print(
            f"  OK   adopted: same program ({program_id}) and same link ({link_id}) on "
            f"{attachment.get('interface')}"
        )

        read_back = _entry_value(client, instance_id, CFG_MAP, CFG_ENTRY["key"])
        if str(read_back) != str(CFG_ENTRY["value"]):
            raise AssertionError(
                f"{CFG_MAP}[{CFG_ENTRY['key']}] is {read_back!r} after the restart, not "
                f"{CFG_ENTRY['value']}: the maps the new process serves are not the ones the "
                f"datapath is using (they would be new, and the old ones would be orphaned)"
            )
        print(f"  OK   {CFG_MAP} kept its data: the maps are the kernel's, not fresh ones")

        # The maps the companion builds at load time. They are not pushed by anyone: they are the
        # init_hook's work, and after a restart only the boot reconcile can have done it.
        built = _u32_of(_first_entry_value(client, instance_id, BUILT_MAP))
        if built != 1:
            raise AssertionError(
                f"{BUILT_MAP}[{BUILT_KEY}] is {built!r} after the restart, not 1: the companion's "
                f"init_hook did not run on the boot path, so the module came back attached, passing "
                f"traffic and steering nothing"
            )
        print(f"  OK   the init_hook's maps are there after the restart: {BUILT_MAP} = {built}")

        # Clean up on both sides: the instance goes, and the persistent config is written again so
        # the next boot does not bring it back.
        require_ok(client.submit("ebpf_unload_module", {"module": instance_id}))
        tracker.forget("ebpf_unload_module", {"module": instance_id})
        require_ok(client.submit("save_config", {}))
        print("  OK   unloaded and saved again, so the next boot does not bring it back")

        after_list = module_list()
        after = _snapshot(after_list)
        print(f"  OK   after unload: {after}")
        for key in ("unmanaged", "stale", "missing", "styx_programs"):
            if after[key] != before[key]:
                raise AssertionError(
                    f"the restart-and-unload cycle left something behind: {key} went from "
                    f"{before[key]} to {after[key]}. A link or a pin of ours with no owner shows up "
                    f"in unmanaged_programs or stale_components."
                )
        if _instance(after_list, instance_id):
            raise AssertionError("the instance is still in the module list after unloading it")
        print("  OK   nothing of ours was left behind, config included")

    finally:
        tracker.cleanup(client)
        # If the run died after the save, the instance would come back at the next boot: saving
        # again is the only thing that takes it out of what the daemon boots with.
        try:
            client.submit("save_config", {})
        except Exception as e:  # noqa: BLE001 - the cleanup reports, it does not mask the failure
            print(f"  WARN could not save the config during the cleanup: {e}")


def main():
    parser = build_parser("Verify the direct XDP lane across a restart: pin, adoption, init_hook")
    parser.add_argument(
        "--interface",
        default=DEFAULT_INTERFACE,
        help=f"interface to load on (default: {DEFAULT_INTERFACE}, a bridge with no IP)",
    )
    args = parser.parse_args()

    client = build_client(args)
    failures = 0
    try:
        run(client, args.interface)
    except AssertionError as e:
        print(f"  FAIL {e}")
        failures += 1
    finish(failures)


if __name__ == "__main__":
    main()
