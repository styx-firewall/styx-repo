#!/usr/bin/env python3
"""Lifecycle verification for the TC modules (the `tcx` attach), with the leftover invariant.

Flow: discover the interface -> snapshot the module list -> load a `tc_*` module ->
check it comes up attached -> **reload it in place** -> unload it -> assert that
nothing of ours was left behind.

Why a second script and not another step in `verify_ebpf.py`: the XDP path and this
one are different mechanisms (a libxdp dispatcher with components vs a `bpf_link`
per program), and the reload is where they differ most. A reload of a `tc_*` module
that does not move in the chain points the live link at the new program
(`bpf_link__update_program`) instead of unloading and loading again, and for a module
that persists it keeps the pin. That path is what this exercises.

The module is an **observer by default** (`host_monitor`, `tc_egress`,
`persist = false`): it counts traffic per host and never decides over it, so loading
it on an interface with production traffic does not change what that interface
passes. `--module net_block` is the other half: it is a blocker (`persist = true`)
with an empty blocklist, and it is the one that exercises the pin.

Caveats before pointing it at a box:
  * it mutates real kernel state, so run it on a lab;
  * `net_block` blocks whatever is in its blocklist (empty when just loaded: nothing).

What this does NOT cover:
  * the pin. It is derived from the instance UUID, and the attachment below proves the link
    is there, but no action reports the pin itself: one left behind shows up indirectly, as
    a program of ours with no owner (the leftover net at the end).
  * where the instance sits in the chain, relative to the other attachments of the hook.
    That is the kernel's own order (`bpftool net list`), and it is asserted from the box by
    `cli_tests/ebpf_tc_attach/`, which drives ModuleManager in-process.

Usage:
    python api_test/integration/verify_ebpf_tc.py --target NAME [--interface testbrid] [--module host_monitor]
"""

import json
import os
import sys

if __package__ is None:  # run as a file (not via `python -m`): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish

DEFAULT_INTERFACE = "testbrid"  # the lab's test bridge: no IP, nothing riding on it
DEFAULT_MODULE = "host_monitor"  # an observer: it never decides over the traffic


def _snapshot(resp):
    """The numbers the leftover invariant is stated in.

    Mirrors `verify_ebpf.py`: the module list already computes them in the kernel, so
    the check needs no shell on the target.
    """
    result = resp["result"]
    return {
        "unmanaged": len(result.get("unmanaged_programs") or []),
        "stale": len(result.get("stale_components") or []),
        "missing": len(result.get("missing_components") or []),
        "styx_programs": result.get("styx_program_count", 0),
    }


def _our_kernel_names(client, available):
    """The kernel program names our modules use (the module name differs for most)."""
    names = set()
    for entry in available:
        module = entry.get("name") if isinstance(entry, dict) else None
        if not module:
            continue
        info = client.request("ebpf_get_module_info", {"module": module})
        if not isinstance(info, dict) or info.get("status") != "success":
            continue
        result = info.get("result") or {}
        names.add(result.get("bpf_fn_name") or module)
    return names


def _named_like_a_module(resp, catalogue):
    """Kernel programs named after one of our modules (the net the counters miss)."""
    result = resp["result"]
    kernel = {p.get("name") for p in (result.get("foreign_programs") or []) if isinstance(p, dict)}
    kernel |= {p.get("name") for p in (result.get("unmanaged_programs") or []) if isinstance(p, dict)}
    kernel.discard(None)  # a payload entry with no name is not a match
    return sorted(kernel & catalogue)


def _entry_key(item):
    """The key of one entry of a control map, whatever shape the companion formatted it into."""
    key = item.get("key") if isinstance(item, dict) else item
    if isinstance(key, dict):  # an IPv4 key comes back as {"ip": "..."}
        key = key.get("ip", key)
    return str(key)


def _pushed_keys(items):
    """The keys the pushed items will land under, in the same shape as the read-back above."""
    return [_entry_key(item) for item in items]


def _pushed_something(client, instance_id, map_name, items):
    resp = require_ok(
        client.request("ebpf_get_control_map", {"module": instance_id, "map": map_name}), "result.entries"
    )
    present = {_entry_key(entry) for entry in resp["result"].get("entries") or []}
    return [key for key in _pushed_keys(items) if key not in present]


def _instance(resp, instance_id):
    for item in resp["result"].get("instances") or []:
        if item.get("instance_id") == instance_id:
            return item
    return None


def run(client, iface_name, module, push_map=None, push_items=None):
    tracker = ResourceTracker()

    def module_list():
        return require_ok(client.request("ebpf_get_module_list"), "result.instances")

    try:
        # The load command takes an interface UUID, not a name.
        resp = require_ok(client.request("get_interfaces_names_ds"), "result.ifaces_list")
        iface_uuid = None
        for item in resp["result"]["ifaces_list"]:
            if item.get("interface") == iface_name and item.get("id"):
                iface_uuid = item["id"]
                break
        if iface_uuid is None:
            raise AssertionError(f"interface {iface_name} not found in get_interfaces_names_ds")
        print(f"  OK   {iface_name} = {iface_uuid}")

        before_list = module_list()
        before = _snapshot(before_list)
        print(f"  OK   baseline: {before}")
        if before["unmanaged"] or before["stale"]:
            raise AssertionError(
                f"the box is not clean to start with ({before['unmanaged']} unmanaged, "
                f"{before['stale']} stale); clean those first, see api_test/consistency"
            )

        loaded = require_ok(
            client.submit("ebpf_load_module", {"module": module, "interface": iface_uuid}),
            "result.instance_ids",
        )
        instance_ids = loaded["result"]["instance_ids"]
        if not instance_ids:
            raise AssertionError(f"load succeeded but returned no instance id: {loaded}")
        instance_id = instance_ids[0]
        # Armed before the checks below, so a failure still leaves the box clean.
        tracker.remember("ebpf_unload_module", {"module": instance_id})
        print(f"  OK   loaded {module} as {instance_id}")

        after_load = module_list()
        listed = _instance(after_load, instance_id)
        if not listed:
            raise AssertionError(f"the instance is not in the module list: {instance_id}")
        if listed.get("status") != "loaded":
            raise AssertionError(f"the instance is listed as {listed.get('status')!r}, not 'loaded'")
        if listed.get("hook_type") not in ("tc_egress", "tc_ingress"):
            raise AssertionError(
                f"a tc module must be listed with a tc hook, got {listed.get('hook_type')!r}"
            )
        print(f"  OK   the instance is listed as loaded on {listed.get('interface')} ({listed['hook_type']})")

        # The attachment, which is what a tc module is: a bpf_link of its own hanging off the
        # device. Without this the check would only see the datastore.
        attachment = listed.get("attachment") or {}
        if listed.get("program_id") is None:
            raise AssertionError(f"the instance view carries no program_id: {listed}")
        if attachment.get("kind") != f"tcx/{listed['hook_type'].split('_')[1]}":
            raise AssertionError(
                f"a tc module attaches as a tcx link and the view says {attachment.get('kind')!r}"
            )
        if attachment.get("link_id") is None:
            raise AssertionError(f"the attachment must report its link id: {attachment}")
        print(
            f"  OK   attached as {attachment['kind']} (link {attachment['link_id']}, "
            f"program {listed['program_id']})"
        )

        if after_load["result"].get("styx_program_count", 0) != before["styx_programs"] + 1:
            raise AssertionError(
                "loading must add exactly one program of ours to the kernel: "
                f"styx_program_count went from {before['styx_programs']} to "
                f"{after_load['result'].get('styx_program_count')}"
            )
        missing_ids = {m.get("instance_id") for m in after_load["result"].get("missing_components") or []}
        if instance_id in missing_ids:
            raise AssertionError(
                "the module loaded and its program is not on the interface, which is the "
                "condition missing_components reports"
            )
        print("  OK   the kernel holds one more program of ours")

        # The data, when the caller says which map to use. It goes in before the reload on
        # purpose: the in-place reload swaps the maps for the new object's, so what keeps the
        # rules after it is the replay of the persisted control data. A module that came back
        # with empty tables would be filtering nothing and look healthy.
        if push_map:
            require_ok(
                client.submit(
                    "ebpf_control_push",
                    {"module": instance_id, "map": push_map, "items": push_items, "op": "upsert"},
                )
            )
            absent = _pushed_something(client, instance_id, push_map, push_items)
            if absent:
                raise AssertionError(f"the entry/entries {absent} are not in {push_map} right after pushing them")
            print(f"  OK   pushed into {push_map} and read back from the kernel: {_pushed_keys(push_items)}")

        # The reload: for a tc module that does not move in the chain it points the live
        # link at the new program, and the instance keeps its UUID and its place.
        require_ok(client.submit("ebpf_reload_module", {"module": instance_id}))
        after_reload = module_list()
        reloaded = _instance(after_reload, instance_id)
        if not reloaded or reloaded.get("status") != "loaded":
            raise AssertionError(
                f"a reload must leave the same instance loaded, got "
                f"{reloaded.get('status') if reloaded else 'no entry'}"
            )
        if after_reload["result"].get("styx_program_count") != after_load["result"].get("styx_program_count"):
            raise AssertionError(
                "a reload in place must not change how many programs of ours are in the kernel: "
                "that is what reusing the link means (the alternative, unload+load, would go "
                "through zero or two)"
            )
        # The two halves of "the link did not move": the same link id, a different program. A
        # reload that went through unload+load would keep the count but change the link, and that
        # is the window this path exists to avoid.
        reloaded_attachment = reloaded.get("attachment") or {}
        if reloaded_attachment.get("link_id") != attachment["link_id"]:
            raise AssertionError(
                f"an in-place reload must keep the link: it went from {attachment['link_id']} to "
                f"{reloaded_attachment.get('link_id')}"
            )
        if reloaded.get("program_id") == listed["program_id"]:
            raise AssertionError(
                f"the reload must put a new program behind the link: the program id is still "
                f"{listed['program_id']}"
            )
        print(
            f"  OK   reloaded in place: link {attachment['link_id']} kept, program "
            f"{listed['program_id']} -> {reloaded['program_id']}"
        )

        if push_map:
            absent = _pushed_something(client, instance_id, push_map, push_items)
            if absent:
                raise AssertionError(
                    f"the in-place reload lost {absent} from {push_map}. The maps after it are the "
                    f"new object's, so the persisted control data has to be replayed into them; a "
                    f"module that comes back with empty tables filters nothing and looks healthy."
                )
            print(f"  OK   {push_map} kept its data across the reload")

        require_ok(client.submit("ebpf_unload_module", {"module": instance_id}))
        tracker.forget("ebpf_unload_module", {"module": instance_id})

        after_list = module_list()
        after = _snapshot(after_list)
        print(f"  OK   after unload: {after}")
        for key in ("unmanaged", "stale", "missing", "styx_programs"):
            if after[key] != before[key]:
                raise AssertionError(
                    f"unload left something behind: {key} went from {before[key]} to {after[key]}. "
                    f"A program of ours with no owner shows up in unmanaged_programs or "
                    f"stale_components, and it keeps its maps until something releases it."
                )
        catalogue = _our_kernel_names(client, after_list["result"].get("available") or [])
        if not catalogue:
            raise AssertionError(
                "no module answered with a bpf_fn_name, so the name check below can see nothing "
                "and would report a green run: check that ebpf_get_module_info answers (ebpf:read)."
            )
        already = _named_like_a_module(before_list, catalogue)
        if already:
            print(
                f"  WARN the box already held programs of ours outside the ownership index: "
                f"{already}. Nothing in this run caused that, and the check below is relative to it."
            )
        named = [name for name in _named_like_a_module(after_list, catalogue) if name not in already]
        if named:
            raise AssertionError(
                f"the kernel still holds a program of ours after unloading: {named}. It is not in "
                f"unmanaged_programs or stale_components because the ownership index is built from "
                f"the loaded instances, so a leftover of an unloaded module reads as a stranger's "
                f"(foreign_programs). Check with `bpftool net list` on the target."
            )
        print("  OK   nothing of ours was left behind")

    finally:
        tracker.cleanup(client)


def main():
    parser = build_parser("Verify the tc attach: load -> reload in place -> unload, no leftovers")
    parser.add_argument(
        "--interface",
        default=DEFAULT_INTERFACE,
        help=f"interface to load on (default: {DEFAULT_INTERFACE})",
    )
    parser.add_argument(
        "--module",
        default=DEFAULT_MODULE,
        help=f"tc module to load (default: {DEFAULT_MODULE}, an observer; net_block is the blocker)",
    )
    parser.add_argument(
        "--push-map",
        default=None,
        help="control map to push into before the reload, to check the data survives it (e.g. blocklist)",
    )
    parser.add_argument(
        "--push-items",
        default="[]",
        help='items to push, as JSON (e.g. \'["198.51.100.7"]\' for an IP map, \'[{"key":0,"value":1}]\' for a keyvalue one)',
    )
    args = parser.parse_args()

    push_items = json.loads(args.push_items)
    if args.push_map and not push_items:
        print("FAIL: --push-map needs --push-items with something to push")
        finish(1)
    if push_items and not args.push_map:
        print("FAIL: --push-items needs --push-map saying where they go")
        finish(1)

    client = build_client(args)
    try:
        run(client, args.interface, args.module, args.push_map, push_items)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
