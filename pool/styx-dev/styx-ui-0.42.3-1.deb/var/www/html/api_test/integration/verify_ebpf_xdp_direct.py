#!/usr/bin/env python3
"""Lifecycle verification for a module on the **direct XDP lane**, with the exclusivity and the leftover invariant.

Flow: discover the interface -> snapshot the module list -> load `xdp_cpu_redirect` (the module that
ships on this lane) with its pre-attach params -> check it comes up attached with the lane's own
`attachment` shape -> **refuse a stackable module and a second direct one on the same interface** (a
device has one XDP slot, and the kernel's EBUSY blames the dispatcher even when the one in the way is
another direct module) -> push a flag into one of its control maps and read it back from the kernel ->
**reload it in
place** and check the link did not move and the flag survived -> unload -> assert that nothing of
ours was left behind.

Why a script of its own, next to `verify_ebpf.py` (XDP on the dispatcher) and `verify_ebpf_tc.py`:
the three are different mechanisms. On this lane the attachment is a `bpf_link` of the module's own
(not a dispatcher component), it holds the device's only XDP slot (so it is exclusive), and it is
served by a companion `init_hook` that fills maps at load time - the three places where the lane can
be silently wrong. What each part proves:

  * the `attachment` of the instance view says `kind: "xdp_direct"` with a `link_id`: the module is
    attached as the lane says, and the link is what an in-place reload has to keep;
  * a second XDP module on the same interface is **refused by name** - the stackable one and the
    second direct one - and the direct one keeps its link: the exclusivity is ours (the kernel only
    says "busy") and it is checked before anything is attached;
  * a control-map push is read back, and it is still there after the reload: the reload swaps the
    maps for the new object's, so what keeps the data is the replay, and the module's `init_hook` has
    to have run again as well or its CPUMAP would be empty and it would steer nothing while looking
    healthy;
  * after the unload the leftover counters are back where they started (a pin or a link left behind
    shows up as a program of ours with no owner).

Caveats before pointing it at a box:
  * it mutates real kernel state: it takes the interface's XDP slot while it runs, so use a lab
    interface nothing rides on (the default is the test bridge);
  * `xdp_cpu_redirect` steers traffic to one CPU with the kernel CPUMAP, and it **passes** what it
    does not steer, so it does not drop anything; but on an interface whose driver has no native XDP
    it attaches in **generic mode** (much slower per packet) and the gateway logs an ERROR saying so.
    That is expected on the test bridge and is not a failure of this run.

What this does NOT cover: the survival of the module across a restart of the daemon (the pin and the
adoption). That is `verify_ebpf_xdp_direct_restart.py`, and it is the only part that cannot be checked
without restarting the service.

Usage:
    python api_test/integration/verify_ebpf_xdp_direct.py --target NAME [--interface testbrid]
"""

import json
import os
import sys

if __package__ is None:  # run as a file (not via `python -m`): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import require_ok
from api_test.apicore.api_client import fails
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish

DEFAULT_INTERFACE = "testbrid"  # the lab's test bridge: no IP, nothing riding on it
MODULE = "xdp_cpu_redirect"  # ships on the direct lane (attach_direct = true, persist = true)
STACKABLE = "xdp_dummy"  # a dispatcher-lane XDP module: only there to be refused
SECOND_DIRECT = "xdp_l3fwd_devmap"  # another direct module: only there to be refused as well
PARAMS = {"cpu_list": "0"}  # the module's required pre-attach param: the CPU pool to steer into
CFG_MAP = "cfg_map"  # its runtime flags (key 0: GRE decapsulation on/off)
CFG_ENTRY = {"key": 0, "value": 0}  # read back: gre_decap off, which is not the shipped default


def _snapshot(resp):
    """The numbers the leftover invariant is stated in (same as the tc verifier)."""
    result = resp["result"]
    return {
        "unmanaged": len(result.get("unmanaged_programs") or []),
        "stale": len(result.get("stale_components") or []),
        "missing": len(result.get("missing_components") or []),
        "styx_programs": result.get("styx_program_count", 0),
    }


def _instance(resp, instance_id):
    for item in resp["result"].get("instances") or []:
        if item.get("instance_id") == instance_id:
            return item
    return None


def _entry_value(client, instance_id, map_name, key):
    """The value of *key* in *map_name*, as the companion formatted it back (a string or an int)."""
    resp = require_ok(
        client.request("ebpf_get_control_map", {"module": instance_id, "map": map_name}), "result.entries"
    )
    for entry in resp["result"].get("entries") or []:
        entry_key = entry.get("key") if isinstance(entry, dict) else None
        if isinstance(entry_key, dict):
            entry_key = entry_key.get("key", entry_key)
        if str(entry_key) == str(key):
            return entry.get("value")
    return None


def _first_entry_value(client, instance_id, map_name):
    """The value of the first entry of *map_name*, as the map reader returns it.

    A map whose companion declares how to format it comes back as plain types (`cfg_map`: key 0,
    value 1). One that does not comes back as the raw bytes in hex, little-endian, which is how the
    kernel holds a `__u32` (`cpus_count`: `"01000000"`). Both shapes are what the API answers with,
    so the value is decoded where it is a raw one.
    """
    resp = require_ok(
        client.request("ebpf_get_control_map", {"module": instance_id, "map": map_name}), "result.entries"
    )
    entries = resp["result"].get("entries") or []
    return entries[0].get("value") if entries else None


def _u32_of(value):
    """A raw map value as an integer: four hex bytes, little-endian, or None."""
    if not isinstance(value, str):
        return value
    try:
        return int.from_bytes(bytes.fromhex(value), "little")
    except ValueError:
        return None


def run(client, iface_name):
    tracker = ResourceTracker()

    def module_list():
        return require_ok(client.request("ebpf_get_module_list"), "result.instances")

    try:
        resp = require_ok(client.request("get_interfaces_names_ds"), "result.ifaces_list")
        iface_uuid = None
        for item in resp["result"]["ifaces_list"]:
            if item.get("interface") == iface_name and item.get("id"):
                iface_uuid = item["id"]
                break
        if iface_uuid is None:
            raise AssertionError(f"interface {iface_name} not found in get_interfaces_names_ds")
        print(f"  OK   {iface_name} = {iface_uuid}")

        before_list = module_list()
        before = _snapshot(before_list)
        print(f"  OK   baseline: {before}")
        if before["unmanaged"] or before["stale"]:
            raise AssertionError(
                f"the box is not clean to start with ({before['unmanaged']} unmanaged, "
                f"{before['stale']} stale); clean those first, see api_test/consistency"
            )
        # The lane is exclusive: if the interface already carries a dispatcher module of ours (or a
        # direct one), the load below is refused on purpose and this run could not tell why.
        for entry in before_list["result"].get("instances") or []:
            if entry.get("hook_type") == "xdp" and entry.get("interface") == iface_name:
                raise AssertionError(
                    f"{iface_name} already carries XDP module {entry.get('name')} (instance "
                    f"{entry.get('instance_id')}); a device has one XDP slot, so unload it first"
                )

        loaded = require_ok(
            client.submit("ebpf_load_module", {"module": MODULE, "interface": iface_uuid, "params": PARAMS}),
            "result.instance_ids",
        )
        instance_id = loaded["result"]["instance_ids"][0]
        tracker.remember("ebpf_unload_module", {"module": instance_id})
        print(f"  OK   loaded {MODULE} with {PARAMS} as {instance_id}")

        after_load = module_list()
        listed = _instance(after_load, instance_id)
        if not listed:
            raise AssertionError(f"the instance is not in the module list: {instance_id}")
        if listed.get("status") != "loaded":
            raise AssertionError(f"the instance is listed as {listed.get('status')!r}, not 'loaded'")
        if listed.get("interface") != iface_name:
            raise AssertionError(f"the instance is on {listed.get('interface')!r}, not {iface_name!r}")

        # The attachment of this lane: a link of its own (unlike a dispatcher component, which has
        # none), and it is what says "the kernel really has it here".
        attachment = listed.get("attachment") or {}
        if listed.get("program_id") is None:
            raise AssertionError(f"the instance view carries no program_id: {listed}")
        if attachment.get("kind") != "xdp_direct":
            raise AssertionError(
                f"a module on the direct lane reports kind 'xdp_direct' and the view says "
                f"{attachment.get('kind')!r}"
            )
        if attachment.get("link_id") is None:
            raise AssertionError(f"the attachment must report its link id: {attachment}")
        if attachment.get("interface") != iface_name:
            raise AssertionError(f"the attachment must be on {iface_name}: {attachment}")
        print(
            f"  OK   attached as {attachment['kind']} (link {attachment['link_id']}, "
            f"program {listed['program_id']})"
        )

        if after_load["result"].get("styx_program_count", 0) != before["styx_programs"] + 1:
            raise AssertionError(
                "loading must add exactly one program of ours to the kernel: "
                f"styx_program_count went from {before['styx_programs']} to "
                f"{after_load['result'].get('styx_program_count')}"
            )
        missing_ids = {m.get("instance_id") for m in after_load["result"].get("missing_components") or []}
        if instance_id in missing_ids:
            raise AssertionError(
                "the module loaded and its program is not on the interface, which is the condition "
                "missing_components reports. On this lane that reads the device's XDP attachment."
            )
        print("  OK   the kernel holds one more program of ours, and it is the one on the interface")

        # The exclusivity, which is this lane's own rule: a device has one XDP slot, so a stackable
        # module cannot go on the same interface. What is checked is that the refusal is ours (it
        # names the module in the way) and that it costs nothing: the direct module keeps its link.
        refusal = client.submit("ebpf_load_module", {"module": STACKABLE, "interface": iface_uuid})
        if not fails(refusal, MODULE):
            raise AssertionError(
                f"loading {STACKABLE} on {iface_name} should be refused naming {MODULE}: {refusal}"
            )
        still = _instance(module_list(), instance_id)
        if (still or {}).get("attachment", {}).get("link_id") != attachment["link_id"]:
            raise AssertionError(
                "the refused load must not touch the module that is there: the link went from "
                f"{attachment['link_id']} to {(still or {}).get('attachment', {}).get('link_id')}"
            )
        print(f"  OK   {STACKABLE} refused by name, and the link ({attachment['link_id']}) is untouched")

        # The same rule, from the same lane: two direct modules do not stack either, and the kernel's
        # EBUSY for this case is written for the cross-lane one (it blames the dispatcher), so the
        # answer has to be ours too, naming the module that is in the way.
        second = client.submit(
            "ebpf_load_module",
            {"module": SECOND_DIRECT, "interface": iface_uuid, "params": {"egress_ifaces": iface_name}},
        )
        if not fails(second, MODULE):
            raise AssertionError(
                f"loading {SECOND_DIRECT} on {iface_name} should be refused naming {MODULE}: {second}"
            )
        if "dispatcher" in json.dumps(second):
            raise AssertionError(f"the refusal blames the dispatcher, which is not what is there: {second}")
        after_second = _instance(module_list(), instance_id)
        if (after_second or {}).get("attachment", {}).get("link_id") != attachment["link_id"]:
            raise AssertionError("the refused second direct load must not touch the module that is there")
        print(f"  OK   {SECOND_DIRECT} (same lane) refused by name, and the link is untouched")

        # The data path, as far as the API can see it: a flag written into the control map of the
        # *attached* module is read back from the kernel. The map is the one the datapath reads, so
        # this is also what proves the maps served are the module's own.
        require_ok(
            client.submit(
                "ebpf_control_push",
                {"module": instance_id, "map": CFG_MAP, "items": [CFG_ENTRY], "op": "upsert"},
            )
        )
        read_back = _entry_value(client, instance_id, CFG_MAP, CFG_ENTRY["key"])
        if str(read_back) != str(CFG_ENTRY["value"]):
            raise AssertionError(f"{CFG_MAP}[{CFG_ENTRY['key']}] reads {read_back!r}, pushed {CFG_ENTRY['value']}")
        print(f"  OK   pushed into {CFG_MAP} and read back from the kernel: {read_back}")

        # The reload: this lane reuses its link, so the instance keeps its UUID and its link id. The
        # new object brings its own maps, which is why the flag above has to survive the replay, and
        # the companion's init_hook has to run again (it is what fills the CPUMAP).
        require_ok(client.submit("ebpf_reload_module", {"module": instance_id}))
        after_reload = module_list()
        reloaded = _instance(after_reload, instance_id)
        if not reloaded or reloaded.get("status") != "loaded":
            raise AssertionError(
                f"a reload must leave the same instance loaded, got "
                f"{reloaded.get('status') if reloaded else 'no entry'}"
            )
        if after_reload["result"].get("styx_program_count") != after_load["result"].get("styx_program_count"):
            raise AssertionError(
                "a reload in place must not change how many programs of ours are in the kernel: "
                "that is what reusing the link means (unload+load would go through zero or two)"
            )
        reloaded_attachment = reloaded.get("attachment") or {}
        if reloaded_attachment.get("link_id") != attachment["link_id"]:
            raise AssertionError(
                f"an in-place reload must keep the link: it went from {attachment['link_id']} to "
                f"{reloaded_attachment.get('link_id')}"
            )
        if reloaded.get("program_id") == listed["program_id"]:
            raise AssertionError(
                f"the reload must put a new program behind the link: the program id is still "
                f"{listed['program_id']}"
            )
        print(
            f"  OK   reloaded in place: link {attachment['link_id']} kept, program "
            f"{listed['program_id']} -> {reloaded['program_id']}"
        )

        read_back = _entry_value(client, instance_id, CFG_MAP, CFG_ENTRY["key"])
        if str(read_back) != str(CFG_ENTRY["value"]):
            raise AssertionError(
                f"the in-place reload lost {CFG_MAP}[{CFG_ENTRY['key']}] (reads {read_back!r}). The "
                f"maps after it are the new object's, so the persisted control data has to be "
                f"replayed into them; a module that comes back with empty maps is configured to do "
                f"nothing and looks healthy."
            )
        print(f"  OK   {CFG_MAP} kept its data across the reload")

        # What the module builds at load time, read back through the API: the CPU pool the
        # companion's init_hook filled. Without it the module redirects nothing (an empty CPUMAP
        # answers "pass" for everything), which is the failure the direct lane's reload path had.
        cpus = _u32_of(_first_entry_value(client, instance_id, "cpus_count"))
        if cpus != 1:
            raise AssertionError(
                f"the CPU pool the init_hook fills reads {cpus!r}, not the 1 the param asked for: "
                f"the module would be attached, passing traffic and steering nothing. The hook is "
                f"what fills it, and an in-place reload brings a fresh object whose maps are empty."
            )
        print(f"  OK   the init_hook's CPU pool is in the kernel after the reload: cpus_count = {cpus}")

        require_ok(client.submit("ebpf_unload_module", {"module": instance_id}))
        tracker.forget("ebpf_unload_module", {"module": instance_id})

        after_list = module_list()
        after = _snapshot(after_list)
        print(f"  OK   after unload: {after}")
        for key in ("unmanaged", "stale", "missing", "styx_programs"):
            if after[key] != before[key]:
                raise AssertionError(
                    f"unload left something behind: {key} went from {before[key]} to {after[key]}. A "
                    f"link or a pin of ours with no owner shows up in unmanaged_programs or "
                    f"stale_components, and it keeps its maps until something releases it."
                )
        if _instance(after_list, instance_id):
            raise AssertionError("the instance is still in the module list after unloading it")
        print("  OK   nothing of ours was left behind")

    finally:
        tracker.cleanup(client)


def main():
    parser = build_parser("Verify the direct XDP lane: load -> exclusivity -> reload in place -> unload")
    parser.add_argument(
        "--interface",
        default=DEFAULT_INTERFACE,
        help=f"interface to load on (default: {DEFAULT_INTERFACE}, a bridge with no IP)",
    )
    args = parser.parse_args()

    client = build_client(args)
    failures = 0
    try:
        run(client, args.interface)
    except AssertionError as e:
        print(f"  FAIL {e}")
        failures += 1
    finish(failures)


if __name__ == "__main__":
    main()
