#!/usr/bin/env python3
"""Independent eBPF module operations: list, load, reload, unload.

One subcommand = one API call. This is **not** a lifecycle: it does not chain
the operations, does not track what it created and does not clean up after
itself. The box is left exactly as the single operation leaves it (after `load`
an instance stays loaded; after `unload` it is gone).

The four operations exist in the front API surface:

    list    -> request.php   ebpf_get_module_list   (ebpf:read)
    load    -> submit.php    ebpf_load_module       (ebpf:write)
    reload  -> submit.php    ebpf_reload_module     (ebpf:write)
    unload  -> submit.php    ebpf_unload_module     (ebpf:write)

Nothing is defaulted; the caller says what to act on:

  * `load` takes the module **name** (the directory under ebpf_modules/) and,
    for interface hooks, the Styx interface **UUID**.
  * `reload` and `unload` take the **instance UUID**: they act on an instance,
    and a module name is not resolved for them.
  * `reload` needs the instance to be loaded at that moment (it hot-swaps the
    running program).

Caveats, because these mutate real kernel state: attaching an XDP program costs
receive throughput on a virtio interface, and a module stays active (filtering)
while loaded. `unload` without `--preserve` deletes the instance and its
persisted control-map data (`/var/lib/styx/ebpf/<uuid>/`) and drops it from
autoload; with `--preserve` it suspends instead (data kept, UUID kept).

Usage:
    python api_test/ebpf_ops.py --target NAME list
    python api_test/ebpf_ops.py --target NAME list --json
    python api_test/ebpf_ops.py --target NAME load   --module ping_monitor --interface <iface-uuid>
    python api_test/ebpf_ops.py --target NAME reload --module <instance-uuid>
    python api_test/ebpf_ops.py --target NAME unload --module <instance-uuid> [--preserve]
"""

import argparse
import json
import os
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from api_test.apicore.api_client import ApiError, dump
from api_test.apicore.verify_common import build_client


def _looks_like_uuid(value):
    """Cheap shape check, to catch a module name passed where a UUID goes."""
    return len(value) == 36 and value.count("-") == 4


def _fail(msg):
    print(f"  FAIL {msg}")
    sys.exit(1)


def _run(client, *, action=None, command=None, data=None, label=""):
    """Run one call, print the response, and stop with code 1 on failure."""
    try:
        resp = client.request(action, data) if action else client.submit(command, data)
    except ApiError as e:
        _fail(f"{label}: {e}")
    if not isinstance(resp, dict) or resp.get("status") != "success":
        msg = resp.get("response_msg") if isinstance(resp, dict) else resp
        dump(resp)
        _fail(f"{label}: {msg or 'no response'}")
    return resp


#
# subcommands
#


def cmd_list(client, args):
    resp = _run(client, action="ebpf_get_module_list", label="list")
    result = resp.get("result") or {}

    if args.json:
        dump(resp)
        return

    instances = result.get("instances") or []
    print(f"Instances ({len(instances)}):")
    for i in instances:
        print(
            f"  {i.get('instance_id')}  "
            f"{(i.get('name') or '?'):<18} "
            f"{(i.get('interface') or '-'):<8} "
            f"{(i.get('mode') or '-'):<5} "
            f"{i.get('status') or '-'}"
            f"{'  autoload' if i.get('autoload') else ''}"
        )
    if not instances:
        print("  (none)")

    available = result.get("available") or []
    print(f"\nAvailable on disk ({len(available)}): {', '.join(a.get('name', '?') for a in available) or '(none)'}")

    print(
        f"\nPrograms: styx={result.get('styx_program_count', 0)} "
        f"kernel={result.get('total_kernel_programs', 0)}  |  "
        f"unmanaged={len(result.get('unmanaged_programs') or [])} "
        f"stale={len(result.get('stale_components') or [])} "
        f"missing={len(result.get('missing_components') or [])} "
        f"conflicts={len(result.get('conflicts') or [])}"
    )
    if result.get("scan_error"):
        print(f"scan_error: {result['scan_error']}")


def cmd_load(client, args):
    data = {"module": args.module}
    if args.interface:
        data["interface"] = args.interface
    if args.params:
        try:
            data["params"] = json.loads(args.params)
        except ValueError as e:
            _fail(f"load: --params is not valid JSON: {e}")

    resp = _run(client, command="ebpf_load_module", data=data, label="load")
    dump(resp)
    ids = (resp.get("result") or {}).get("instance_ids") or []
    if ids:
        print(f"\ninstance_ids: {' '.join(ids)}")


def cmd_reload(client, args):
    if not _looks_like_uuid(args.module):
        _fail(f"reload: {args.module!r} is not an instance UUID (reload acts on a loaded instance)")
    resp = _run(client, command="ebpf_reload_module", data={"module": args.module}, label="reload")
    dump(resp)


def cmd_unload(client, args):
    if not _looks_like_uuid(args.module):
        _fail(f"unload: {args.module!r} is not an instance UUID (unload acts on an instance)")
    data = {"module": args.module}
    if args.preserve:
        data["preserve"] = True
    resp = _run(client, command="ebpf_unload_module", data=data, label="unload")
    dump(resp)


#
# cli
#


def build_parser():
    p = argparse.ArgumentParser(
        description="Independent eBPF operations (list / load / reload / unload); one call per invocation.",
    )
    p.add_argument("--config", default=None, help="Path to config file (default: api_test/config.json)")
    p.add_argument("--target", default=None, help="Target name in the config's 'targets' map (required)")

    sub = p.add_subparsers(dest="op", required=True, metavar="OP")

    sp = sub.add_parser("list", help="List loaded instances, modules on disk and kernel program state")
    sp.add_argument("--json", action="store_true", help="Print the raw response instead of the summary")
    sp.set_defaults(func=cmd_list)

    sp = sub.add_parser("load", help="Load a module by name (one instance per interface)")
    sp.add_argument("--module", required=True, help="Module name: the directory under ebpf_modules/ (not a UUID)")
    sp.add_argument("--interface", default=None, help="Styx interface UUID; required by interface hooks")
    sp.add_argument("--params", default=None, help="Pre-attach params as a JSON object, e.g. '{\"priority\": 80}'")
    sp.set_defaults(func=cmd_load)

    sp = sub.add_parser("reload", help="Hot-reload a loaded instance (keeps its UUID)")
    sp.add_argument("--module", required=True, help="Instance UUID")
    sp.set_defaults(func=cmd_reload)

    sp = sub.add_parser("unload", help="Unload an instance by UUID")
    sp.add_argument("--module", required=True, help="Instance UUID")
    sp.add_argument("--preserve", action="store_true", help="Suspend instead of removing: keeps the instance and its data")
    sp.set_defaults(func=cmd_unload)

    return p


def main():
    args = build_parser().parse_args()
    client = build_client(args)
    args.func(client, args)


if __name__ == "__main__":
    main()
