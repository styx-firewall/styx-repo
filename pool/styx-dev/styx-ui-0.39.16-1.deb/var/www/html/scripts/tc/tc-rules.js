// tc-rules.js
// Handles the TC rule form with classifier-dependent structured fields,
// custom mode (raw filter), and set/label pickers.

document.addEventListener('DOMContentLoaded', () => {

    // Picker initialization 

    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }

    // DOM refs 

    const form = document.getElementById('tc-rule-form');
    const classifierSel = document.getElementById('tc-classifier');
    const classifierInput = document.getElementById('tc-classifier-input');
    const customModeCb = document.getElementById('tc-custom-mode');
    const directionSel = document.getElementById('tc-direction');
    const actionSel = document.getElementById('tc-action');
    const structuredDiv = document.getElementById('tc-structured-fields');
    const customDiv = document.getElementById('tc-custom-fields');
    const egressRow = document.getElementById('tc-egress-row');
    const mirrorDevCol = document.getElementById('tc-mirror-dev-col');
    const ifaceInput = document.getElementById('tc-iface');
    const parentSel = document.getElementById('tc-parent');

    if (!form) return;

    // Filter parent options by selected interface 

    function filterParents() {
        if (!parentSel) return;
        const ifaceUuid = ifaceInput ? ifaceInput.value : '';
        const options = parentSel.options;
        let found = false;
        for (let i = 0; i < options.length; i++) {
            const opt = options[i];
            const optIface = opt.getAttribute('data-iface') || '';
            const match = !optIface || optIface === ifaceUuid;
            opt.hidden = !match;
            if (match && !found && optIface) found = true;
        }
        if (!found && ifaceUuid) {
            parentSel.value = 'root';
        }
    }

    if (ifaceInput) {
        ifaceInput.addEventListener('change', filterParents);
        filterParents();
    }

    // Classifier -> field visibility 

    /** Clear all named inputs inside a hidden row (inputs, selects, picker hiddens). */
    function clearRowInputs(row) {
        row.querySelectorAll('input[name], select[name]').forEach(el => {
            if (el.type === 'hidden') {
                el.value = '';
                // Reset picker label if inside a set-picker-field
                const wrapper = el.closest('.set-picker-field');
                if (wrapper) {
                    const label = wrapper.querySelector('.js-set-picker-label');
                    const trigger = wrapper.querySelector('.set-picker-trigger');
                    const clearBtn = wrapper.querySelector('.js-set-picker-clear');
                    if (label && trigger) {
                        label.textContent = trigger.dataset.placeholder || 'Select...';
                    }
                    if (clearBtn) clearBtn.classList.add('sets-hidden');
                    trigger.classList.remove('set-picker-trigger--has-value');
                }
            } else if (el.tagName === 'SELECT') {
                el.selectedIndex = 0;
            } else {
                el.value = '';
            }
        });
    }

    function applyClassifier(cls) {
        const allFields = structuredDiv.querySelectorAll('.tc-field');
        allFields.forEach(row => {
            const classes = row.className.split(/\s+/);
            const match = classes.some(c => c === 'tc-cls-' + cls);
            const wasHidden = row.style.display === 'none';
            row.style.display = match ? '' : 'none';
            // Clear inputs when hiding a row that was previously visible
            if (!match && !wasHidden) {
                clearRowInputs(row);
            }
        });
    }

    function applyDirection(dir) {
        const isEgress = dir === 'egress';
        if (egressRow) egressRow.style.display = isEgress ? '' : 'none';
        const egressFields = structuredDiv.querySelectorAll('.tc-egress-only');
        egressFields.forEach(row => {
            const wasHidden = row.style.display === 'none';
            row.style.display = isEgress ? '' : 'none';
            if (!isEgress && !wasHidden) {
                clearRowInputs(row);
            }
        });
    }

    function applyMode() {
        const isCustom = customModeCb && customModeCb.checked;
        if (structuredDiv) structuredDiv.style.display = isCustom ? 'none' : '';
        if (customDiv) customDiv.style.display = isCustom ? '' : 'none';
        // Swap classifier: select for structured, text input for custom.
        // Disable the hidden one so FormData only picks up the visible field.
        if (classifierSel) {
            classifierSel.style.display = isCustom ? 'none' : '';
            classifierSel.disabled = isCustom;
        }
        if (classifierInput) {
            classifierInput.style.display = isCustom ? '' : 'none';
            classifierInput.disabled = !isCustom;
        }
        // Clear custom filter when switching to structured, and vice versa
        if (isCustom) {
            clearRowInputs(structuredDiv);
        } else {
            if (customDiv) clearRowInputs(customDiv);
        }
        // Hide parent column in custom mode (set via raw filter)
        if (egressRow) {
            if (isCustom) {
                egressRow.style.display = 'none';
                clearRowInputs(egressRow);
            } else {
                const isEgress = directionSel && directionSel.value === 'egress';
                egressRow.style.display = isEgress ? '' : 'none';
            }
        }
    }

    function applyAction() {
        const action = actionSel ? actionSel.value : '';
        if (mirrorDevCol) mirrorDevCol.style.display = action === 'mirror' ? '' : 'none';
    }

    function refreshFields() {
        const cls = classifierSel ? classifierSel.value : 'u32';
        const dir = directionSel ? directionSel.value : 'egress';
        applyClassifier(cls);
        applyDirection(dir);
        applyMode();
        applyAction();
    }

    // Event listeners 

    if (classifierSel) classifierSel.addEventListener('change', refreshFields);
    if (directionSel) directionSel.addEventListener('change', refreshFields);
    if (customModeCb) customModeCb.addEventListener('change', refreshFields);
    if (actionSel) actionSel.addEventListener('change', applyAction);

    // Initial state
    refreshFields();

    // Form submission 

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const data = {};

        formData.forEach((value, key) => {
            if (key === 'custom_mode') return;
            if (value === '' && key !== 'name' && key !== 'direction' && key !== 'interface_uuid') return;

            data[key] = value;
        });

        // Cast active to boolean
        if ('active' in data) {
            data.active = data.active === '1';
        }

        // Cast prio to int
        if (data.prio !== undefined && data.prio !== '') {
            data.prio = parseInt(data.prio, 10);
        }

        try {
            const result = await apiClient.submit('add_tc_rule', data);
            window.tcShowResult(result, {
                closeText: 'Close',
                reloadOnOk: true,
                boxStyle: { maxWidth: '50vw', maxHeight: '50vh' }
            });
        } catch (err) {
            window.tcShowResult(
                { ok: false, msg: err.message },
                { title: 'Error', closeText: 'Close' }
            );
        }
    });

    // Delete rule 

    document.querySelectorAll('.delete-rule').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.preventDefault();
            const ruleId = btn.getAttribute('data-id');
            if (!ruleId) return;
            if (!confirm('Are you sure you want to delete this rule?')) return;
            try {
                const result = await apiClient.submit('delete_tc_rule', { id: ruleId });
                window.tcShowResult(result, {
                    closeText: 'Close',
                    reloadOnOk: true,
                    boxStyle: { maxWidth: '50vw', maxHeight: '50vh' }
                });
            } catch (err) {
                window.tcShowResult(
                    { ok: false, msg: err.message },
                    { title: 'Error', closeText: 'Close' }
                );
            }
        });
    });

    // Toggle rule 

    document.querySelectorAll('.toggle-rule').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.preventDefault();
            const ruleId = btn.getAttribute('data-id');
            const ifaceUuid = btn.getAttribute('data-iface-uuid');
            const active = btn.getAttribute('data-active');
            if (!ruleId || !ifaceUuid) return;
            try {
                const result = await apiClient.submit('toggle_tc_rule', {
                    id: ruleId,
                    interface_uuid: ifaceUuid,
                    active: active === '1'
                });
                window.tcShowResult(result, {
                    closeText: 'Close',
                    reloadOnOk: true,
                    boxStyle: { maxWidth: '50vw', maxHeight: '50vh' }
                });
            } catch (err) {
                window.tcShowResult(
                    { ok: false, msg: err.message },
                    { title: 'Error', closeText: 'Close' }
                );
            }
        });
    });
});
