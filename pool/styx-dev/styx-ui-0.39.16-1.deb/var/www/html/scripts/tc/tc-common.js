// tc-common.js
// Shared helpers for TC scripts: processApiResult, showResult

(function(window){
    function processApiResult(result) {
        const topStatus = result && result.status;
        const cmdStatus = result && result.result && result.result.status;
        const msgText = (result && result.result && (result.result.msg || result.result.response_msg))
                     || (result && result.response_msg)
                     || '';
        const stderr = (result && result.result && result.result.stderr) ? result.result.stderr : '';
        const ok = (topStatus === 'success' && (!cmdStatus || cmdStatus === 'success'));
        return { ok, msg: msgText, stderr };
    }

    window.tcProcessApiResult = processApiResult;

    // Create a simple DOM node for a status message
    function createMessageNode(msg, ok) {
        const node = document.createElement('div');
        const strong = document.createElement('div');
        strong.style.fontWeight = 'bold';
        strong.style.color = ok ? '#080' : '#b00';
        strong.textContent = msg || '';
        node.appendChild(strong);
        return node;
    }

    // Show a processed or raw API result using showModal if available, otherwise alert.
    // options: { title, closeText, reloadOnOk, boxStyle, onClose }
    function showApiResult(resultOrProcessed, options) {
        const opts = options || {};
        const r = (resultOrProcessed && typeof resultOrProcessed.ok !== 'undefined') ? resultOrProcessed : processApiResult(resultOrProcessed);
        let msg = r.msg || '';
        if (!r.ok && r.stderr) msg = msg ? (msg + ' - ' + r.stderr) : r.stderr;

        const node = createMessageNode(msg, r.ok);

        if (typeof showModal === 'function') {
            const modalOpts = { title: opts.title || (r.ok ? 'Success' : 'Error'), closeText: opts.closeText || 'Close' };
            if (opts.boxStyle) modalOpts.boxStyle = opts.boxStyle;
            if (typeof opts.onClose === 'function') modalOpts.onClose = opts.onClose;
            if (opts.reloadOnOk && r.ok) modalOpts.onClose = () => window.location.reload();
            showModal(node, modalOpts);
        } else {
            if (r.ok) {
                alert(msg || 'Success');
                if (opts.reloadOnOk) window.location.reload();
            } else {
                alert(msg || 'Error');
            }
        }
    }

    window.tcCreateMessageNode = createMessageNode;
    window.tcShowResult = showApiResult;
})(window);
