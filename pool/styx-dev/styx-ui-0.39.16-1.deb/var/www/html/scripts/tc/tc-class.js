// tc-class.js
// Handles adding and deleting TC classes (channels).

document.addEventListener('DOMContentLoaded', () => {
    // Add class
    const addClassForm = document.getElementById('add-channel-form');
    if (addClassForm) {
        // Toggle child qdisc params visibility when kind changes
        const childQdiscKind = document.getElementById('child-qdisc-kind-select');
        const childQdiscParams = document.getElementById('child-qdisc-params-input');
        if (childQdiscKind && childQdiscParams) {
            childQdiscKind.addEventListener('change', () => {
                childQdiscParams.style.display = childQdiscKind.value ? 'inline-block' : 'none';
            });
            // Initial state
            childQdiscParams.style.display = childQdiscKind.value ? 'inline-block' : 'none';
        }

        addClassForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(addClassForm);
            const classname = formData.get('classname');
            const qdisc_iface = formData.get('qdisc_iface');
            const parent = formData.get('parent');
            const classid = formData.get('classid');
            const params = formData.get('params');
            const child_qdisc_kind = formData.get('child_qdisc_kind');
            const child_qdisc_params = formData.get('child_qdisc_params');

            // Parse interface_uuid from qdisc_iface select value (kind is resolved by backend)
            const parts = (qdisc_iface || '').split('|');
            const interface_uuid = parts[0] || '';

            // Build object for the backend
            const data = {
                classname,
                interface_uuid,
                parent,
                handle: classid,
                params
            };
            if (child_qdisc_kind && child_qdisc_kind !== '') {
                data.child_qdisc = {
                    kind: child_qdisc_kind,
                    params: child_qdisc_params || ''
                };
            }
            try {
                const result = await apiClient.submit('add_tc_class', data);
                window.tcShowResult(result, { title: 'Success', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                window.tcShowResult({ ok: false, msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Delete class - event delegation
    document.addEventListener('click', async (e) => {
        const btn = e.target.closest('.js-delete-channel');
        if (!btn) return;

        e.preventDefault();
        const id = btn.dataset.id;
        const ifaceUuid = btn.dataset.ifaceUuid;

        if (!id || !ifaceUuid) return;
        if (!confirm('Are you sure you want to delete this class?')) return;

        const data = { id: id, interface_uuid: ifaceUuid };

        try {
            const result = await apiClient.submit('delete_tc_class', data);
            window.tcShowResult(result, { title: 'Success', closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            window.tcShowResult({ ok: false, msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    });
});
