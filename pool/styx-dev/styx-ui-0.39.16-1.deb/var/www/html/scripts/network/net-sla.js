// net-sla.js
// Handles SLA monitor add via submit.php

document.addEventListener('DOMContentLoaded', function() {
    // Initialize set-picker fields (target host picker)
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }

    const form = document.getElementById('add-monitor-form');
    if (form) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            const formData = new FormData(form);
                // Build payload for backend
                const protocol = formData.get('protocol') || 'ping';
                const payload = {
                    command: 'add_monitor',
                    name: formData.get('name'),
                    protocol,
                    target: formData.get('target'),
                    interface: formData.get('interface') === 'none' ? null : formData.get('interface'),
                    interval_ms: formData.get('interval') ? parseInt(formData.get('interval'), 10) : 5000,
                    inactive_failures: formData.get('inactive_failures')
                        ? parseInt(formData.get('inactive_failures'), 10)
                        : 3,
                    restore_success: formData.get('restore_success')
                        ? parseInt(formData.get('restore_success'), 10)
                        : 3,
                    enabled: true
                };
                // Add ping-specific fields if protocol is ping
                if (protocol === 'ping') {
                    payload.latency_threshold = formData.get('latency_threshold')
                        ? parseInt(formData.get('latency_threshold'), 10)
                        : 30;
                    payload.latency_strikes = formData.get('latency_strikes')
                        ? parseInt(formData.get('latency_strikes'), 10)
                        : 3;
                    payload.jitter_threshold = formData.get('jitter_threshold')
                        ? parseInt(formData.get('jitter_threshold'), 10)
                        : 5;
                    payload.jitter_strikes = formData.get('jitter_strikes')
                        ? parseInt(formData.get('jitter_strikes'), 10)
                        : 3;
                }
            try {
                try {
                    const result = await apiClient.submit('add_monitor', payload);
                    showApiResult(result, { title: 'Add Monitor', closeText: 'Close' });
                    if (result.status === 'success') form.reset();
                } catch (err) {
                    showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                }
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Monitor action buttons (activate, deactivate, delete)
    document.querySelectorAll('.monitor-action-btn').forEach(function(btn) {
        btn.addEventListener('click', async function() {
            const id = btn.getAttribute('data-id');
            const action = btn.getAttribute('data-action');
            let command = '';
            if (action === 'activate') command = 'enable_monitor';
            else if (action === 'deactivate') command = 'disable_monitor';
            else if (action === 'delete') command = 'delete_monitor';
            if (!id || !command) return;
            try {
                try {
                    const result = await apiClient.submit(command, { id });
                    showApiResult(result, { title: 'Monitor action', closeText: 'Close', reloadOnOk: true });
                } catch (err) {
                    showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                }
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    });

    // Initial chart logic
    const monitors = window.slaMonitors || [];
    let currentMonitorId = monitors.length > 0 ? monitors[0].id : null;
    let currentType = 'latency';
    let currentRange = '15m';
    // null = full fetch needed; ISO string = last received data point timestamp
    let lastTimestamp = null;

    // Fetch SLA stats via apiClient, bypassing normalizeAndBucketData (wrong format for SLA)
    function fetchSlaStats(params, onSuccess) {
        apiClient.request('metrics', Object.assign({ metric: 'sla' }, params))
            .then(function(resp) {
                if (resp && resp.status === 'success') {
                    onSuccess(resp.result || {});
                } else {
                    appLog.warn('SLA stats fetch error:', resp);
                }
            })
            .catch(function(err) {
                appLog.warn('SLA stats fetch error:', err);
            });
    }

    function formatSlaLabel(ts, range) {
        if (!window.dateUtils || typeof window.dateUtils.formatShortTime !== 'function') return ts || '';
        const includeSeconds = (range === '5m' || range === '15m' || range === '30m');
        return window.dateUtils.formatShortTime(ts, { includeSeconds });
    }

    // Compute Y axis bounds with padding so the scale starts near actual data, not zero.
    // Re-evaluation on incremental updates uses a threshold: only rescale if the new
    // min/max would move the axis by more than 20% of the current range (avoids jitter).
    function computeYBounds(values) {
        const nums = values.filter(v => typeof v === 'number' && isFinite(v));
        if (nums.length === 0) return { beginAtZero: false };
        const min = Math.min.apply(null, nums);
        const max = Math.max.apply(null, nums);
        const span = max - min;
        const pad = Math.max(span * 0.15, span === 0 ? Math.abs(min) * 0.1 : 0, 0.5);
        return {
            beginAtZero: false,
            min: Math.max(0, min - pad),
            max: max + pad
        };
    }

    // Check if the current chart Y scale needs adjustment given new incoming values.
    // Returns true and updates the scale if a rescale is warranted.
    function maybeRescaleY(chart, newValues) {
        const scale = chart.options.scales && chart.options.scales.y;
        if (!scale) return false;
        const nums = newValues.filter(v => typeof v === 'number' && isFinite(v));
        if (nums.length === 0) return false;
        const newMin = Math.min.apply(null, nums);
        const newMax = Math.max.apply(null, nums);
        const curMin = scale.min !== undefined ? scale.min : 0;
        const curMax = scale.max !== undefined ? scale.max : 1;
        const curSpan = curMax - curMin || 1;
        // Rescale if new data is outside current bounds or the min has drifted > 20% of span
        const needsRescale = newMin < curMin
            || newMax > curMax
            || Math.abs(newMin - curMin) > curSpan * 0.2;
        if (!needsRescale) return false;
        // Recompute using all dataset values + new incoming ones
        const allValues = (chart.data.datasets[0].data || []).concat(nums);
        const bounds = computeYBounds(allValues);
        scale.min = bounds.min;
        scale.max = bounds.max;
        return true;
    }

    // Defensive normalization: sort asc, deduplicate by timestamp, discard points <= pivot ISO
    function normalizeIncomingStats(stats, pivotIso) {
        const pivotEpoch = pivotIso ? new Date(pivotIso).getTime() : null;
        const seen = new Set();
        return stats
            .filter(function(s) { return s && s.timestamp; })
            .sort(function(a, b) { return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime(); })
            .filter(function(s) {
                if (pivotEpoch !== null && new Date(s.timestamp).getTime() <= pivotEpoch) return false;
                if (seen.has(s.timestamp)) return false;
                seen.add(s.timestamp);
                return true;
            });
    }

    // SLA chart: first call does a full fetch; subsequent interval calls only request
    // data newer than the last received timestamp and append it to the existing chart.
    function setupSlaChart() {
        lastTimestamp = null;
        appLog('setupSlaChart called');

        // Clear any existing timer before re-registering to avoid duplicate intervals
        if (window.chartConfigs && window.chartConfigs['net-sla'] && window.chartConfigs['net-sla'].timer) {
            clearInterval(window.chartConfigs['net-sla'].timer);
            window.chartConfigs['net-sla'].timer = null;
        }
        if (window.charts && window.charts['net-sla'] && typeof window.charts['net-sla'].destroy === 'function') {
            window.charts['net-sla'].destroy();
            window.charts['net-sla'] = null;
        }

        window.registerChart('net-sla', null, function(range) {
            if (!currentMonitorId) {
                appLog.info('No SLA monitor configured; skipping SLA stats fetch');
                return;
            }
            if (lastTimestamp === null) {
                // Full fetch: clear canvas and rebuild chart from scratch
                var canvas = document.getElementById('net-sla-chart');
                if (canvas && canvas.parentElement) {
                    canvas.width = canvas.parentElement.offsetWidth;
                    canvas.height = canvas.parentElement.offsetHeight;
                    canvas.style.width = '100%';
                    canvas.style.height = '100%';
                    var ctx2d = canvas.getContext('2d');
                    ctx2d.clearRect(0, 0, canvas.width, canvas.height);
                }
                fetchSlaStats({ monitor_id: currentMonitorId, stat_type: currentType, range: range }, function(data) {
                    appLog('SLA chart full response:', data);
                    const stats = normalizeIncomingStats(data.stats || [], null);
                    const labels = stats.map(s => formatSlaLabel(s.timestamp, range));
                    const values = stats.map(s => s[currentType]);
                    if (window.charts['net-sla'] && typeof window.charts['net-sla'].destroy === 'function') {
                        window.charts['net-sla'].destroy();
                    }
                    window.charts['net-sla'] = makeSingleChart(
                        'net-sla-chart',
                        currentType.charAt(0).toUpperCase() + currentType.slice(1),
                        values,
                        'rgba(0,123,255,1)',
                        computeYBounds(values),
                        labels,
                        { responsive: true }
                    );
                    // Use last_timestamp from backend if available, else fall back to last point
                    lastTimestamp = data.last_timestamp || (stats.length > 0 ? stats[stats.length - 1].timestamp : null);
                });
            } else {
                // Incremental fetch: convert ISO lastTimestamp > epoch seconds for since_timestamp
                const sinceEpoch = new Date(lastTimestamp).getTime() / 1000;
                fetchSlaStats({ monitor_id: currentMonitorId, stat_type: currentType, since_timestamp: sinceEpoch }, function(data) {
                    appLog('SLA chart incremental response:', data);
                    const incoming = normalizeIncomingStats(data.stats || [], lastTimestamp);
                    if (incoming.length === 0) return;
                    const chart = window.charts['net-sla'];
                    if (!chart) {
                        // Chart was destroyed externally-trigger a full rebuild next tick
                        lastTimestamp = null;
                        return;
                    }
                    const newValues = incoming.map(s => s[currentType]);
                    maybeRescaleY(chart, newValues);
                    incoming.forEach(function(s) {
                        chart.data.labels.push(formatSlaLabel(s.timestamp, range));
                        chart.data.datasets[0].data.push(s[currentType]);
                    });
                    // Use last_timestamp from backend if available, else last appended point
                    lastTimestamp = data.last_timestamp || incoming[incoming.length - 1].timestamp;
                    chart.update();
                });
            }
        }, currentRange, {
            onChange: function(range) {
                // Range changed: keep currentRange in sync, reset for full rebuild
                currentRange = range;
                lastTimestamp = null;
                window.chartConfigs['net-sla'].range = range;
                window.startChartRefresh('net-sla');
            }
        });
    }

    // Reset state and restart the refresh cycle without re-registering the chart.
    // Used when monitor or type changes-avoids duplicate timers.
    function resetChart() {
        lastTimestamp = null;
        if (window.charts && window.charts['net-sla'] && typeof window.charts['net-sla'].destroy === 'function') {
            window.charts['net-sla'].destroy();
            window.charts['net-sla'] = null;
        }
        if (window.chartConfigs && window.chartConfigs['net-sla']) {
            window.startChartRefresh('net-sla');
        }
    }

    // Show/hide ping extra fields based on protocol selection
    const protocolSelect = document.getElementById('monitor-protocol');
    const pingFields = document.getElementById('ping-extra-fields');
    if (protocolSelect && pingFields) {
        const updatePingFields = () => {
            if (protocolSelect.value === 'ping') {
                pingFields.style.display = 'flex';
            } else {
                pingFields.style.display = 'none';
            }
        };
        protocolSelect.addEventListener('change', updatePingFields);
        // Force show if the initial value is 'ping' (default)
        setTimeout(updatePingFields, 0);
    }

    // Monitor selector (if you want to allow switching monitors)
    if (monitors.length > 1) {
        const selector = document.createElement('select');
        selector.id = 'monitor-selector';
        monitors.forEach(m => {
            const opt = document.createElement('option');
            opt.value = m.id;
            opt.textContent = m.name;
            selector.appendChild(opt);
        });
        selector.value = currentMonitorId;
        selector.style.marginRight = '12px';
        document.getElementById('sla-type-select').parentElement.prepend(selector);
        selector.addEventListener('change', function() {
            currentMonitorId = this.value;
            resetChart();
        });
    }

    // Type selector
    document.getElementById('sla-type-select').addEventListener('change', function() {
        currentType = this.value;
        resetChart();
    });

    // Initial chart render
    setupSlaChart();
});
