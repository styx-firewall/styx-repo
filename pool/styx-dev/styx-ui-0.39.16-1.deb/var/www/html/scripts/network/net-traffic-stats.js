/**
 * Traffic Stats page JS
 * Handles tab switching, chart rendering, and live polling.
 *
 * Depends on: api-client.js (global `apiClient`), Chart.js (global `Chart`)
 */

(function () {
    'use strict';

    let refreshTimer = null;
    const REFRESH_INTERVAL_MS = 5000;

    /** Chart instances cache */
    const charts = {};

    /* ---------- helpers ---------- */

    function escapeHtml(str) {
        if (typeof str !== 'string') return String(str);
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }

    /* ---------- tab switching ---------- */

    function initTabs() {
        document.querySelectorAll('.std-tab-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                document.querySelectorAll('.std-tab-btn').forEach(function (b) {
                    b.classList.remove('active');
                });
                this.classList.add('active');
                var tab = this.getAttribute('data-tab');
                document.querySelectorAll('.std-tab-panel').forEach(function (panel) {
                    panel.style.display = (panel.getAttribute('data-tab') === tab) ? 'block' : 'none';
                });
            });
        });
    }

    /* ---------- colour palette ---------- */

    var palette = [
        '#4e79a7', '#f28e2b', '#e15759', '#76b7b2', '#59a14f',
        '#edc948', '#b07aa1', '#ff9da7', '#9c755f', '#bab0ac',
        '#86bcf9', '#d4a6c8', '#a1c9f4', '#f4a582', '#92c5de'
    ];

    function colour(i) {
        return palette[i % palette.length];
    }

    /* ---------- chart rendering ---------- */

    function destroyChart(id) {
        if (charts[id] && typeof charts[id].destroy === 'function') {
            charts[id].destroy();
            delete charts[id];
        }
    }

    /**
     * Build pie / doughnut chart for interface distribution.
     */
    function renderIfaceChart(canvasId, summary, valueKey, label) {
        destroyChart(canvasId);
        var canvas = document.getElementById(canvasId);
        if (!canvas) return;
        if (!summary || Object.keys(summary).length === 0) {
            return;
        }
        var ctx = canvas.getContext('2d');
        var labels = [];
        var values = [];
        var colours = [];
        var idx = 0;
        for (var iface in summary) {
            if (!summary.hasOwnProperty(iface)) continue;
            labels.push(iface);
            values.push(parseInt(summary[iface][valueKey], 10) || 0);
            colours.push(colour(idx));
            idx++;
        }
        charts[canvasId] = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: values,
                    backgroundColor: colours,
                    borderColor: '#1e1e2e',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 0 },
                plugins: {
                    legend: { position: 'right', labels: { color: '#cdd6f4' } },
                    tooltip: {
                        callbacks: {
                            label: function (ctx2) {
                                var val = ctx2.parsed || 0;
                                if (valueKey === 'bytes') {
                                    return ctx2.label + ': ' + formatBytes(val);
                                }
                                return ctx2.label + ': ' + val.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }

    /**
     * Build horizontal bar chart for top 10 IPs by traffic (bytes).
     */
    function renderTopIpsChart(canvasId, setsIn, setsOut, setsFwd) {
        destroyChart(canvasId);
        var canvas = document.getElementById(canvasId);
        if (!canvas) return;

        // Aggregate bytes by IP across all directions
        var ipMap = {};
        function addEntries(entries) {
            for (var i = 0; i < entries.length; i++) {
                var e = entries[i];
                var ip = e.ip || 'unknown';
                if (!ipMap[ip]) ipMap[ip] = 0;
                ipMap[ip] += e.bytes || 0;
            }
        }
        addEntries(setsIn);
        addEntries(setsOut);
        addEntries(setsFwd);

        var ips = Object.keys(ipMap);
        if (ips.length === 0) return;

        // Sort descending by bytes, take top 10
        ips.sort(function (a, b) { return ipMap[b] - ipMap[a]; });
        var top = ips.slice(0, 10);
        var labels = [];
        var values = [];
        var colours = [];
        for (var j = 0; j < top.length; j++) {
            labels.push(top[j]);
            values.push(ipMap[top[j]]);
            colours.push(colour(j));
        }

        var ctx = canvas.getContext('2d');
        charts[canvasId] = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    data: values,
                    backgroundColor: colours,
                    borderColor: colours,
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 0 },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function (ctx2) {
                                return formatBytes(ctx2.parsed.x || 0);
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: '#cdd6f4',
                            callback: function (val) { return formatBytes(val); }
                        },
                        grid: { color: 'rgba(255,255,255,0.05)' }
                    },
                    y: {
                        ticks: { color: '#cdd6f4' },
                        grid: { display: false }
                    }
                }
            }
        });
    }

    /**
     * Build doughnut chart for protocol distribution.
     */
    function renderProtocolChart(canvasId, setsIn, setsOut, setsFwd, valueKey) {
        destroyChart(canvasId);
        var canvas = document.getElementById(canvasId);
        if (!canvas) return;

        // Aggregate by protocol across all directions
        var protoMap = {};
        function addEntries(entries) {
            for (var i = 0; i < entries.length; i++) {
                var e = entries[i];
                var proto = (e.proto || 'unknown').toUpperCase();
                if (!protoMap[proto]) protoMap[proto] = 0;
                protoMap[proto] += e[valueKey] || 0;
            }
        }
        addEntries(setsIn);
        addEntries(setsOut);
        addEntries(setsFwd);

        var protos = Object.keys(protoMap);
        if (protos.length === 0) return;

        // Sort by value descending
        protos.sort(function (a, b) { return protoMap[b] - protoMap[a]; });

        var labels = [];
        var values = [];
        var colours = [];
        for (var j = 0; j < protos.length; j++) {
            labels.push(protos[j]);
            values.push(protoMap[protos[j]]);
            colours.push(colour(j));
        }

        var ctx = canvas.getContext('2d');
        charts[canvasId] = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: values,
                    backgroundColor: colours,
                    borderColor: '#1e1e2e',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 0 },
                plugins: {
                    legend: { position: 'right', labels: { color: '#cdd6f4' } },
                    tooltip: {
                        callbacks: {
                            label: function (ctx2) {
                                var val = ctx2.parsed || 0;
                                if (valueKey === 'bytes') {
                                    return ctx2.label + ': ' + formatBytes(val);
                                }
                                return ctx2.label + ': ' + val.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }

    /**
     * Build doughnut chart for direction distribution.
     */
    function renderDirChart(canvasId, setsIn, setsOut, setsFwd, valueKey, label) {
        destroyChart(canvasId);
        var canvas = document.getElementById(canvasId);
        if (!canvas) return;
        var inTotal = setsIn.reduce(function (sum, e) { return sum + (e[valueKey] || 0); }, 0);
        var outTotal = setsOut.reduce(function (sum, e) { return sum + (e[valueKey] || 0); }, 0);
        var fwdTotal = setsFwd.reduce(function (sum, e) { return sum + (e[valueKey] || 0); }, 0);
        if (inTotal === 0 && outTotal === 0 && fwdTotal === 0) return;
        var ctx = canvas.getContext('2d');
        charts[canvasId] = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Inbound', 'Outbound', 'Forwarded'],
                datasets: [{
                    data: [inTotal, outTotal, fwdTotal],
                    backgroundColor: ['#4e79a7', '#f28e2b', '#76b7b2'],
                    borderColor: '#1e1e2e',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 0 },
                plugins: {
                    legend: { position: 'right', labels: { color: '#cdd6f4' } },
                    tooltip: {
                        callbacks: {
                            label: function (ctx2) {
                                var val = ctx2.parsed || 0;
                                if (valueKey === 'bytes') {
                                    return ctx2.label + ': ' + formatBytes(val);
                                }
                                return ctx2.label + ': ' + val.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }

    /* ---------- renderers ---------- */

    function renderSummaryBar(summaryAll) {
        var bar = document.querySelector('.ts-summary-bar');
        if (!bar) return;
        var items = bar.querySelectorAll('.ts-summary-item');
        if (items.length >= 3) {
            items[0].innerHTML = '<strong>Total:</strong> ' + formatBytes(summaryAll.bytes || 0);
            items[1].innerHTML = '<strong>Packets:</strong> ' + (summaryAll.packets || 0).toLocaleString();
            items[2].innerHTML = '<strong>Flows:</strong> ' + (summaryAll.flows || 0).toLocaleString();
        }
    }

    function renderSummaryTable(summary) {
        var container = document.querySelector('.ts-summary-table tbody');
        if (!container) return;
        if (!summary || Object.keys(summary).length === 0) {
            container.innerHTML = '<tr><td colspan="4" class="ts-empty">No data</td></tr>';
            return;
        }
        var html = '';
        for (var iface in summary) {
            if (!summary.hasOwnProperty(iface)) continue;
            var agg = summary[iface];
            html += '<tr>'
                + '<td><strong>' + escapeHtml(iface) + '</strong></td>'
                + '<td>' + (agg.packets || 0).toLocaleString() + '</td>'
                + '<td>' + formatBytes(agg.bytes || 0) + '</td>'
                + '<td>' + (agg.flows || 0).toLocaleString() + '</td>'
                + '</tr>';
        }
        container.innerHTML = html;
    }

    function renderDetailTable(tableId, entries) {
        var tbody = document.querySelector('#' + tableId + ' tbody');
        if (!tbody) return;
        if (!entries || entries.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="ts-empty">No traffic data</td></tr>';
            return;
        }
        var html = '';
        for (var i = 0; i < entries.length; i++) {
            var e = entries[i];
            html += '<tr>'
                + '<td>' + escapeHtml(e.iface || '-') + '</td>'
                + '<td>' + escapeHtml(e.ip || '-') + '</td>'
                + '<td>' + escapeHtml(e.proto || '-') + '</td>'
                + '<td>' + (e.packets || 0).toLocaleString() + '</td>'
                + '<td>' + formatBytes(e.bytes || 0) + '</td>'
                + '<td>' + escapeHtml(e.expires || '-') + '</td>'
                + '</tr>';
        }
        tbody.innerHTML = html;
    }

    function renderOverview(summary, setsIn, setsOut, setsFwd) {
        renderTopIpsChart('ts-chart-top-ips', setsIn, setsOut, setsFwd);
        renderIfaceChart('ts-chart-iface-packets', summary, 'packets');
        renderIfaceChart('ts-chart-iface-bytes', summary, 'bytes');
        renderProtocolChart('ts-chart-protocol', setsIn, setsOut, setsFwd, 'bytes');
        renderDirChart('ts-chart-dir-packets', setsIn, setsOut, setsFwd, 'packets');
        renderDirChart('ts-chart-dir-bytes', setsIn, setsOut, setsFwd, 'bytes');
    }

    /* ---------- data normalisation ---------- */

    function normalizeSetEntries(rawEntries) {
        if (!Array.isArray(rawEntries)) return [];
        return rawEntries.map(function (e) {
            if (!e || typeof e !== 'object') return null;
            return {
                iface: e.iface || '-',
                ip: e.ip || e.src_ip || e.dst_ip || '-',
                proto: e.proto || '-',
                packets: parseInt(e.packets, 10) || 0,
                bytes: parseInt(e.bytes, 10) || 0,
                expires: e.expires || '-',
            };
        }).filter(Boolean);
    }

    /* ---------- fetch & refresh ---------- */

    async function fetchAndRender() {
        try {
            var response = await window.apiClient.request('traffic-stats-get', {});
            if (!response || response.status !== 'success' || !response.result) {
                if (window.appLog) window.appLog.warn('traffic-stats: fetch failed', response);
                return;
            }

            var result = response.result;
            var sets = result.sets || {};
            var summary = result.summary || {};
            var summaryAll = result.summary_all || {};

            var setsIn = normalizeSetEntries(
                (sets.ipv4_traffic_in || []).concat(sets.ipv6_traffic_in || [])
            );
            var setsOut = normalizeSetEntries(
                (sets.ipv4_traffic_out || []).concat(sets.ipv6_traffic_out || [])
            );
            var setsFwd = normalizeSetEntries(
                (sets.ipv4_traffic_fwd || []).concat(sets.ipv6_traffic_fwd || [])
            );

            renderSummaryBar(summaryAll);
            renderSummaryTable(summary);
            renderDetailTable('ts-table-in', setsIn);
            renderDetailTable('ts-table-out', setsOut);
            renderDetailTable('ts-table-fwd', setsFwd);
            renderOverview(summary, setsIn, setsOut, setsFwd);

        } catch (err) {
            if (window.appLog) window.appLog.warn('traffic-stats: fetch error', err);
        }
    }

    /* ---------- auto-refresh controls ---------- */

    function startAutoRefresh() {
        stopAutoRefresh();
        refreshTimer = setInterval(fetchAndRender, REFRESH_INTERVAL_MS);
    }

    function stopAutoRefresh() {
        if (refreshTimer !== null) {
            clearInterval(refreshTimer);
            refreshTimer = null;
        }
    }

    /* ---------- init ---------- */

    function init() {
        initTabs();

        var refreshBtn = document.getElementById('ts-refresh-btn');
        var resetBtn = document.getElementById('ts-reset-btn');
        var autoCheckbox = document.getElementById('ts-auto-refresh');

        if (refreshBtn) {
            refreshBtn.addEventListener('click', function () { fetchAndRender(); });
        }

        if (resetBtn) {
            resetBtn.addEventListener('click', async function () {
                try {
                    var result = await window.apiClient.submit('traffic-stats-reset', {});
                    if (window.showApiResult) {
                        window.showApiResult(result, {
                            title: 'Reset Traffic Stats',
                            closeText: 'Close',
                            reloadOnOk: false
                        });
                    }
                    // Refresh the data regardless
                    fetchAndRender();
                } catch (err) {
                    if (window.showApiResult) {
                        window.showApiResult(
                            { status: 'error', response_msg: err.message },
                            { title: 'Error', closeText: 'Close' }
                        );
                    }
                }
            });
        }

        if (autoCheckbox) {
            autoCheckbox.addEventListener('change', function () {
                if (this.checked) startAutoRefresh();
                else stopAutoRefresh();
            });
        }
        if (autoCheckbox && autoCheckbox.checked) {
            startAutoRefresh();
        }

        fetchAndRender();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
