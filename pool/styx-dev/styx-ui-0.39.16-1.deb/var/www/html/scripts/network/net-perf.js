// iPerf3 UI - Async server/client management

let serverPollingInterval = null;
let tasksPollingInterval = null;
let activeTaskPollers = new Map();
// Track which task results we've already rendered to avoid duplicates
let renderedTaskResults = new Set();
// Pending chart creators per result suffix (deferred when panel is collapsed)
let pendingChartCreators = new Map();

// Helpers: provide safe fallbacks for response parsing and error message building
function parseHandlerResponse(resp) {
    if (!resp) return null;
    try {
        // If response is a JSON string, parse it
        if (typeof resp === 'string') {
            resp = JSON.parse(resp);
        }

        // If server returned an array of responses, pick the first
        if (Array.isArray(resp) && resp.length > 0) {
            resp = resp[0];
        }

        // If nested under a `response` or `result` envelope, normalize
        if (resp.response && typeof resp.response === 'object') {
            return resp.response;
        }

        return resp;
    } catch (e) {
        console.error('Failed to parse handler response:', e, resp);
        return null;
    }
}

function buildHandlerErrorMessage(r) {
    if (!r) return 'Unknown error';
    if (r.response_msg) return r.response_msg;
    if (r.message) return r.message;
    if (r.error) return typeof r.error === 'string' ? r.error : JSON.stringify(r.error);
    if (r.result && r.result.msg) return r.result.msg;
    return 'Handler error: ' + (typeof r === 'string' ? r : JSON.stringify(r).slice(0, 200));
}

// UI message helper for this page
function showIperfMessage(msg, isError = false, timeout = 4000) {
    try {
        let el = document.getElementById('iperf-response-msg');
        const cls = isError ? 'page-alert alert-error' : 'page-alert alert-info';
        if (!el) {
            el = document.createElement('div');
            el.id = 'iperf-response-msg';
            // insert at top of main content or body
            const main = document.querySelector('main.page-content') || document.body;
            main.insertBefore(el, main.firstChild);
        }
        el.className = cls;
        el.textContent = String(msg);

        if (timeout && timeout > 0) {
            setTimeout(() => {
                if (el && el.parentNode) el.parentNode.removeChild(el);
            }, timeout);
        }
    } catch (e) {
        console.error('showIperfMessage error:', e, msg);
    }
}

// Collect form fields into a plain object (skips empty strings, handles checkboxes)
function collectFormData(form) {
    var data = {};
    new FormData(form).forEach(function (value, key) {
        var input = form.querySelector('[name="' + key + '"]');
        if (input && input.type === 'checkbox') {
            data[key] = input.checked;
        } else if (value.trim() !== '') {
            data[key] = value;
        }
    });
    return data;
}

// Parse API response and dispatch success/error uniformly.
// Calls onSuccess(r) when r.status === 'success', shows error otherwise.
function handleSubmitResponse(resp, onSuccess) {
    var r = parseHandlerResponse(resp);
    if (!r) {
        showIperfMessage('Invalid response from server', true);
        return;
    }
    if (r.status === 'success') {
        onSuccess(r);
    } else {
        showIperfMessage(buildHandlerErrorMessage(r), true);
    }
}

// Update server status UI
function updateServerStatus(status) {
    const statusText = document.getElementById('server-status-text');
    const btnStart = document.getElementById('btn-start-server');
    const btnStop = document.getElementById('btn-stop-server');
    const statusPanel = document.getElementById('server-status');

    if (!statusText) return;

    const running = status?.running ?? false;
    const pid = status?.pid ?? null;
    const port = status?.port ?? null;
    const started_at = status?.started_at ?? null;

    statusText.textContent = running ? 'Running' : 'Stopped';
    statusText.dataset.status = running ? 'running' : 'stopped';

    if (statusPanel) {
        const indicator = statusPanel.querySelector('.status-indicator');
        if (indicator) {
            let html = `<span id="server-status-text" data-status="${running ? 'running' : 'stopped'}">${running ? 'Running' : 'Stopped'}</span>`;
            if (running) {
                html += `<span>PID: ${pid}</span>`;
                html += `<span>Port: ${port}</span>`;
                html += `<span>Started: ${started_at}</span>`;
            }
            indicator.innerHTML = html;
        }
    }

    if (btnStart) btnStart.disabled = running;
    if (btnStop) btnStop.disabled = !running;
}

// Poll server status
function pollServerStatus() {
    // Combined status+tasks request
    apiClient.request('iperf_status_and_tasks', {})
        .then(resp => {
            const r = parseHandlerResponse(resp);
            if (!r) {
                showIperfMessage('Invalid response from server', true, 5000);
                return;
            }
            if (r.status === 'success') {
                const server = r.result?.server_status || {};
                const tasks = r.result?.tasks || [];
                updateServerStatus(server);
                updateTasksList(tasks);
            } else {
                showIperfMessage(buildHandlerErrorMessage(r), true, 5000);
            }
        })
        .catch(err => {
            console.error('Failed to poll status and tasks:', err);
            showIperfMessage('Error polling status/tasks: ' + (err.message || err), true, 5000);
        });
}

// Start server polling (every 5 seconds)
function startServerPolling() {
    if (serverPollingInterval) return;
    pollServerStatus();
    // Use 3s for combined status+tasks polling
    serverPollingInterval = setInterval(pollServerStatus, 3000);
}

// Stop server polling
function stopServerPolling() {
    if (serverPollingInterval) {
        clearInterval(serverPollingInterval);
        serverPollingInterval = null;
    }
}

// Start iperf server
function startServer() {
    var form = document.querySelector('[data-js="server-form"]');
    if (!form) return;
    var data = collectFormData(form);

    apiClient.submit('iperf_start_server', data)
        .then(function (resp) {
            console.debug('iperf_start_server raw response:', resp);
            var r = parseHandlerResponse(resp);
            console.debug('iperf_start_server parsed response:', r);
            handleSubmitResponse(resp, function (r) {
                appLog.info('Server started successfully');
                showIperfMessage(r.response_msg || 'Server started');
                updateServerStatus(r.result || {});
                if (r.result && r.result.stderr_head) {
                    appLog.info('Server diagnostics: ' + r.result.stderr_head);
                }
            });
        })
        .catch(function (err) {
            appLog.error('Error starting server: ' + err.message);
            showIperfMessage('Error starting server: ' + (err.message || err), true);
        });
}

// Stop iperf server
function stopServer() {
    apiClient.submit('iperf_stop_server', {})
        .then(function (resp) {
            handleSubmitResponse(resp, function (r) {
                appLog.info('Server stopped successfully');
                showIperfMessage(r.response_msg || 'Server stopped');
                pollServerStatus();
            });
        })
        .catch(function (err) {
            appLog.error('Error stopping server: ' + err.message);
            showIperfMessage('Error stopping server: ' + (err.message || err), true);
        });
}

// Start client test
function startClientTest() {
    var form = document.querySelector('[data-js="client-form"]');
    if (!form) return;

    var data = collectFormData(form);

    if (!data.server_ip || data.server_ip.trim() === '') {
        appLog.warn('Server IP is required');
        return;
    }

    appLog.info('Starting client test...');

    apiClient.submit('iperf_start_client_test', data)
        .then(function (resp) {
            handleSubmitResponse(resp, function (r) {
                if (r.result && r.result.task_id) {
                    var taskId = r.result.task_id;
                    appLog.info('Client test started, task ID: ' + taskId);
                    showIperfMessage(r.response_msg || 'Client test started');
                    startTaskPolling(taskId);
                } else {
                    showIperfMessage(r.response_msg || 'Client test started');
                }
            });
        })
        .catch(function (err) {
            appLog.error('Error starting client test: ' + err.message);
            showIperfMessage('Error starting client test: ' + (err.message || err), true);
        });
}

// Poll a specific task result
function startTaskPolling(taskId) {
    if (activeTaskPollers.has(taskId)) return;

    const pollTaskResult = () => {
        apiClient.request('iperf_get_task_result', { task_id: taskId })
            .then(resp => {
                if (resp.status === 'success' && resp.result) {
                    const taskData = resp.result;
                    // Accept different gateway shapes: `state` or `status` (e.g. 'done')
                    let state = taskData.state || taskData.status || 'unknown';
                    if (state === 'done') state = 'completed';

                    if (state === 'completed' || state === 'error' || state === 'failed') {
                        clearInterval(activeTaskPollers.get(taskId));
                        activeTaskPollers.delete(taskId);

                        if (state === 'completed') {
                            // Extract actual test result from possible nested envelopes
                            let resultPayload = null;
                            if (taskData.result) {
                                // gateway may return { result: { ok: true, data: { ... } } }
                                if (taskData.result.data) {
                                    resultPayload = taskData.result.data;
                                } else if (taskData.result.result) {
                                    resultPayload = taskData.result.result;
                                } else {
                                    resultPayload = taskData.result;
                                }
                            } else if (taskData.result_data) {
                                resultPayload = taskData.result_data;
                            } else {
                                resultPayload = taskData;
                            }

                            if (resultPayload) renderIperfResult(resultPayload, { taskId });
                        } else {
                            appLog.error('Task failed: ' + (taskData.error || taskData.response_msg || 'Unknown error'));
                        }
                    }
                }
            })
            .catch(err => {
                console.error('Error polling task result:', err);
                clearInterval(activeTaskPollers.get(taskId));
                activeTaskPollers.delete(taskId);
            });
    };

    pollTaskResult();
    const intervalId = setInterval(pollTaskResult, 2000);
    activeTaskPollers.set(taskId, intervalId);
}

// Poll all tasks and update tasks list
function pollTasks() {
    apiClient.request('iperf_get_tasks', {})
        .then(resp => {
            if (resp.status === 'success' && resp.result?.tasks) {
                updateTasksList(resp.result.tasks);
            }
        })
        .catch(err => {
            console.error('Failed to poll tasks:', err);
        });
}

// Update tasks list UI
function updateTasksList(tasks) {
    const container = document.querySelector('[data-js="tasks-list"]');
    if (!container) return;

    const taskEntries = Object.entries(tasks);
    if (taskEntries.length === 0) {
        container.innerHTML = '<p>No active tasks</p>';
        return;
    }

    let html = '<ul class="tasks-list">';
    taskEntries.forEach(([taskId, task]) => {
        // normalize state/status naming
        const stateRaw = task.state || task.status || 'unknown';
        const state = stateRaw === 'done' ? 'completed' : stateRaw;
        // If no explicit progress provided, map completed=>100, running=>0
        let progress = typeof task.progress === 'number' ? task.progress : 0;
        if ((state === 'completed' || state === 'done') && progress === 0) progress = 100;

        html += `<li class="task-item task-state-${state}">
            <span class="task-id">${taskId}</span>
            <span class="task-state">${state}</span>
            <span class="task-progress">${progress}%</span>
        </li>`;
    });
    html += '</ul>';
    container.innerHTML = html;

    // If any task completed and includes a result payload, render it immediately
    taskEntries.forEach(([taskId, task]) => {
        const stateRaw = task.state || task.status || 'unknown';
        const state = stateRaw === 'done' ? 'completed' : stateRaw;
        const hasResult = task.result && (task.result.data || task.result.result || task.result);
        if (state === 'completed' && hasResult && !renderedTaskResults.has(taskId)) {
            // extract payload similarly to startTaskPolling
            let resultPayload = null;
            if (task.result) {
                if (task.result.data) {
                    resultPayload = task.result.data;
                } else if (task.result.result) {
                    resultPayload = task.result.result;
                } else {
                    resultPayload = task.result;
                }
            }
            if (resultPayload) {
                try { renderIperfResult(resultPayload, { taskId }); } catch (e) { console.error('renderIperfResult failed:', e); }
                renderedTaskResults.add(taskId);
            }

            // Clear any poller for this task if present
            if (activeTaskPollers.has(taskId)) {
                clearInterval(activeTaskPollers.get(taskId));
                activeTaskPollers.delete(taskId);
            }
        }
    });
}

// Start tasks polling (every 3 seconds)
function startTasksPolling() {
    if (tasksPollingInterval) return;
    pollTasks();
    tasksPollingInterval = setInterval(pollTasks, 3000);
}

// Stop tasks polling
function stopTasksPolling() {
    if (tasksPollingInterval) {
        clearInterval(tasksPollingInterval);
        tasksPollingInterval = null;
    }
}

// Render iperf3 results into tables and charts
function renderIperfResult(result, meta = {}) {
    if (!result) return;
    const taskId = meta.taskId || null;
    const suffix = taskId ? '-' + String(taskId).replace(/[^a-z0-9]/gi, '').slice(0, 8) : '-latest';

    const protocol = result?.start?.test_start?.protocol?.toUpperCase?.() || 'TCP';
    const intervals = result.intervals || [];
    const speeds = intervals.map(iv => iv.sum?.bits_per_second || 0);
    const cwnd = protocol === 'TCP' ? intervals.map(iv => iv.streams?.[0]?.snd_cwnd ?? null) : [];
    const rtt = protocol === 'TCP' ? intervals.map(iv => iv.streams?.[0]?.rtt ?? null) : [];
    const labels = intervals.map((iv, i) => `${Math.round(iv.sum?.end || (i + 1))}s`);

    let jitter = [];
    let lostPackets = [];
    if (protocol === 'UDP') {
        jitter = intervals.map(iv => iv.sum?.jitter_ms ?? iv.sum?.jitter ?? null);
        lostPackets = intervals.map(iv => iv.sum?.lost_packets ?? null);
    }

    const end = result.end || {};
    const sum_sent = end.sum_sent || {};
    const sum_received = end.sum_received || {};
    const cpu = end.cpu_utilization_percent || {};

    let html = '';

    // Summary table
    html += `<table class="std-table">
        <thead><tr><th colspan="2">Summary (${protocol})</th></tr></thead>
        <tbody>
            <tr><td>Duration</td><td>${(sum_sent.seconds || 0).toFixed(2)} s</td></tr>
            <tr><td>Bytes sent</td><td>${window.formatBytes(sum_sent.bytes ?? 0)}</td></tr>
            <tr><td>Average throughput</td><td>${(sum_sent.bits_per_second / 1e6).toFixed(2)} Mbps</td></tr>
            ${protocol === 'TCP' ? `<tr><td>Retransmissions</td><td>${sum_sent.retransmits ?? '-'}</td></tr>` : ''}
            <tr><td>Bytes received</td><td>${window.formatBytes(sum_received.bytes ?? 0)}</td></tr>
            <tr><td>Average throughput received</td><td>${(sum_received.bits_per_second / 1e6).toFixed(2)} Mbps</td></tr>
            ${protocol === 'UDP' && typeof sum_received.lost_packets !== 'undefined' ? `<tr><td>Lost packets</td><td>${sum_received.lost_packets}</td></tr>` : ''}
            ${protocol === 'UDP' && typeof sum_received.lost_percent !== 'undefined' ? `<tr><td>Loss (%)</td><td>${sum_received.lost_percent.toFixed(2)}%</td></tr>` : ''}
        </tbody>
    </table>`;

    // CPU table
    if (cpu && Object.keys(cpu).length) {
        html += `<table class="std-table">
            <thead><tr><th colspan="2">CPU Utilization (%)</th></tr></thead>
            <tbody>
                <tr><td>Host total</td><td>${cpu.host_total?.toFixed(1) ?? '-'}</td></tr>
                <tr><td>Host user</td><td>${cpu.host_user?.toFixed(1) ?? '-'}</td></tr>
                <tr><td>Host system</td><td>${cpu.host_system?.toFixed(1) ?? '-'}</td></tr>
                <tr><td>Remote total</td><td>${cpu.remote_total?.toFixed(1) ?? '-'}</td></tr>
                <tr><td>Remote user</td><td>${cpu.remote_user?.toFixed(1) ?? '-'}</td></tr>
                <tr><td>Remote system</td><td>${cpu.remote_system?.toFixed(1) ?? '-'}</td></tr>
            </tbody>
        </table>`;
    }

    // Intervals table (only if not too many)
    if (intervals.length && intervals.length <= 20) {
        html += `<table class="std-table">
            <thead>
                <tr>
                    <th>Interval</th>
                    <th>Seconds</th>
                    <th>Bytes</th>
                    <th>Mbps</th>
                    ${protocol === 'TCP' ? '<th>Retrans.</th>' : ''}
                    ${protocol === 'UDP' && typeof intervals[0]?.sum?.lost_packets !== 'undefined' ? '<th>Lost</th>' : ''}
                    ${protocol === 'UDP' && typeof intervals[0]?.sum?.lost_percent !== 'undefined' ? '<th>Loss (%)</th>' : ''}
                </tr>
            </thead>
            <tbody>
                ${intervals.map((iv, i) => {
            const s = iv.sum || {};
            return `<tr>
                        <td>${i + 1}</td>
                        <td>${s.seconds?.toFixed(2) ?? '-'}</td>
                        <td>${window.formatBytes(s.bytes ?? 0)}</td>
                        <td>${(s.bits_per_second / 1e6).toFixed(2)}</td>
                        ${protocol === 'TCP' ? `<td>${s.retransmits ?? '-'}</td>` : ''}
                        ${protocol === 'UDP' && typeof s.lost_packets !== 'undefined' ? `<td>${s.lost_packets}</td>` : ''}
                        ${protocol === 'UDP' && typeof s.lost_percent !== 'undefined' ? `<td>${s.lost_percent.toFixed(2)}</td>` : ''}
                    </tr>`;
        }).join('')}
            </tbody>
        </table>`;
    }

    const resultsContainer = document.querySelector('[data-js="results-container"]');
    if (resultsContainer) {
        // Wrap result with a panel header so multiple tests stack clearly
        const headerLabel = taskId ? `Test ${taskId}` : `Test ${new Date().toISOString()}`;
        const panelHtml = `
            <section class="iperf-result-panel" data-task-id="${taskId || ''}">
                <div class="iperf-result-header">
                    <strong class="iperf-result-title">${headerLabel}</strong>
                    <span class="iperf-result-meta">${result?.start?.timestamp?.time || ''}</span>
                    <button type="button" class="iperf-toggle-btn" aria-expanded="true">▾</button>
                </div>
                <div class="iperf-result-body">
                    ${html}
                </div>
                <div class="iperf-result-graphs" id="iperf-graphs${suffix}"></div>
            </section>
        `;
        // Append so multiple tests appear one after another
        resultsContainer.insertAdjacentHTML('beforeend', panelHtml);

        // Collapse behavior: if more than one panel exists, collapse newly added one by default
        const panels = resultsContainer.querySelectorAll('.iperf-result-panel');
        const newPanel = panels[panels.length - 1];
        const toggleBtn = newPanel.querySelector('.iperf-toggle-btn');
        const body = newPanel.querySelector('.iperf-result-body');
        const graphs = newPanel.querySelector('.iperf-result-graphs');

        const setCollapsed = (collapsed) => {
            if (collapsed) {
                body.style.display = 'none';
                graphs.style.display = 'none';
                toggleBtn.textContent = '▸';
                toggleBtn.setAttribute('aria-expanded', 'false');
            } else {
                body.style.display = '';
                graphs.style.display = '';
                toggleBtn.textContent = '▾';
                toggleBtn.setAttribute('aria-expanded', 'true');
            }
        };

        // If there's more than one panel, collapse the new one by default.
        if (panels.length > 1) {
            setCollapsed(true);
        } else {
            setCollapsed(false);
        }

        // Toggle handler (also trigger pending chart creation when expanding)
        toggleBtn.addEventListener('click', () => {
            const isExpanded = toggleBtn.getAttribute('aria-expanded') === 'true';
            const willBeExpanded = !isExpanded;
            setCollapsed(isExpanded);
            if (willBeExpanded) {
                const pending = pendingChartCreators.get(suffix);
                if (typeof pending === 'function') {
                    try { pending(); } catch (e) { console.error('deferred chart creation failed', e); }
                    pendingChartCreators.delete(suffix);
                }
            }
        });
    }

    // Render charts
    // Render graphs inside the per-result graphs container (unique id)
    const graphsContainer = document.getElementById(`iperf-graphs${suffix}`);
    if (graphsContainer) {
        graphsContainer.innerHTML = `
            <div id="iperf-graph-speed${suffix}" class="iperf-graph-item">
                <div class="iperf-graph-title">Speed (Mbps)</div>
                <canvas id="iperf-speed-chart${suffix}" height="180"></canvas>
            </div>
            ${protocol === 'TCP' && cwnd.some(v => v !== null) ? `
            <div id="iperf-graph-cwnd${suffix}" class="iperf-graph-item">
                <div class="iperf-graph-title">Congestion window (bytes)</div>
                <canvas id="iperf-cwnd-chart${suffix}" height="120"></canvas>
            </div>` : ''}
            ${protocol === 'TCP' && rtt.some(v => v !== null) ? `
            <div id="iperf-graph-rtt${suffix}" class="iperf-graph-item">
                <div class="iperf-graph-title">RTT (ms)</div>
                <canvas id="iperf-rtt-chart${suffix}" height="120"></canvas>
            </div>` : ''}
            ${protocol === 'UDP' && jitter.some(v => v !== null) ? `
            <div id="iperf-graph-jitter${suffix}" class="iperf-graph-item">
                <div class="iperf-graph-title">Jitter (ms)</div>
                <canvas id="iperf-jitter-chart${suffix}" height="120"></canvas>
            </div>` : ''}
            ${protocol === 'UDP' && lostPackets.some(v => v !== null) ? `
            <div id="iperf-graph-lost${suffix}" class="iperf-graph-item">
                <div class="iperf-graph-title">Lost packets</div>
                <canvas id="iperf-lost-chart${suffix}" height="120"></canvas>
            </div>` : ''}
        `;
        graphsContainer.classList.add('iperf-graphs--active');

        const createCharts = () => {
            // Speed chart
            if (typeof makeSingleChart === 'function' && speeds.length) {
                makeSingleChart(
                    `iperf-speed-chart${suffix}`,
                    'Mbps',
                    speeds.map(bps => bps / 1e6),
                    'rgba(42,122,226,1)',
                    { beginAtZero: true },
                    labels
                );
            }

            // cwnd chart (TCP only)
            if (protocol === 'TCP' && typeof makeSingleChart === 'function' && cwnd.some(v => v !== null)) {
                makeSingleChart(
                    `iperf-cwnd-chart${suffix}`,
                    'snd_cwnd (bytes)',
                    cwnd,
                    'rgba(255,193,7,1)',
                    { beginAtZero: true },
                    labels
                );
            }

            // rtt chart (TCP only)
            if (protocol === 'TCP' && typeof makeSingleChart === 'function' && rtt.some(v => v !== null)) {
                makeSingleChart(
                    `iperf-rtt-chart${suffix}`,
                    'RTT (ms)',
                    rtt,
                    'rgba(220,53,69,1)',
                    { beginAtZero: true },
                    labels
                );
            }

            // jitter chart (UDP only)
            if (protocol === 'UDP' && typeof makeSingleChart === 'function' && jitter.some(v => v !== null)) {
                makeSingleChart(
                    `iperf-jitter-chart${suffix}`,
                    'Jitter (ms)',
                    jitter,
                    'rgba(255,87,34,1)',
                    { beginAtZero: true },
                    labels
                );
            }

            // lost packets chart (UDP only)
            if (protocol === 'UDP' && typeof makeSingleChart === 'function' && lostPackets.some(v => v !== null)) {
                makeSingleChart(
                    `iperf-lost-chart${suffix}`,
                    'Lost packets',
                    lostPackets,
                    'rgba(220,53,69,1)',
                    { beginAtZero: true },
                    labels
                );
            }
        };

        // If graphs container is hidden (panel collapsed), defer creation until expand
        const compStyle = window.getComputedStyle(graphsContainer);
        if (compStyle && compStyle.display === 'none') {
            pendingChartCreators.set(suffix, createCharts);
        } else {
            try { createCharts(); } catch (e) { console.error('createCharts failed', e); }
        }
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function () {
    // Start polling server status and tasks
    startServerPolling();

    // Server controls
    const btnStartServer = document.querySelector('[data-js="start-server"]');
    if (btnStartServer) {
        btnStartServer.addEventListener('click', startServer);
    }

    const btnStopServer = document.querySelector('[data-js="stop-server"]');
    if (btnStopServer) {
        btnStopServer.addEventListener('click', stopServer);
    }

    // Client form
    const clientForm = document.querySelector('[data-js="client-form"]');
    if (clientForm) {
        clientForm.addEventListener('submit', function (e) {
            e.preventDefault();
            startClientTest();
        });
    }
});
