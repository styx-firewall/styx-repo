/**
 * net-routing-rules.js
 * Client logic for Route Rules (ip rule) management.
 * Handles form preview, add/submit, delete, toggle, and edit operations.
 *
 * Dependencies:
 *   - api-client.js  (apiClient.submit)
 *   - common.js      (showApiResult, showModal)
 */
(function (window) {
    'use strict';

    // Helpers 

    /** Returns trimmed string value of an input/select, or '' if missing. */
    function rrVal(id) {
        const el = document.getElementById(id);
        return el ? (el.value || '').trim() : '';
    }

    /** Returns checked state of a checkbox. */
    function rrChecked(id) {
        const el = document.getElementById(id);
        return el ? el.checked : false;
    }

    /**
     * Enables or disables a field (input/select) and its picker wrapper.
     * For hidden inputs inside a set-picker-field, also toggles the
     * picker buttons and clears the label.
     */
    function rrSetDisabled(id, disabled) {
        const el = document.getElementById(id);
        if (!el) return;
        el.disabled = disabled;
        if (disabled && el.value) el.value = '';

        // Handle picker wrapper for hidden inputs
        if (el.type === 'hidden') {
            const wrapper = el.closest('[data-js="set-picker-field"], [data-js="label-picker-field"]');
            if (wrapper) {
                const openBtn  = wrapper.querySelector('.js-set-picker-open');
                const clearBtn = wrapper.querySelector('.js-set-picker-clear');
                const labelEl  = wrapper.querySelector('.js-set-picker-label');
                if (openBtn) {
                    openBtn.disabled = disabled;
                    if (disabled) openBtn.classList.remove('set-picker-trigger--has-value');
                }
                if (disabled) {
                    if (clearBtn) clearBtn.classList.add('sets-hidden');
                    if (labelEl) labelEl.textContent = openBtn?.dataset.placeholder || 'Select...';
                }
            }
        }

        const col = el.closest('.rr-col');
        if (col) col.classList.toggle('rr-disabled', disabled);
    }

    /** Delegates to the global showApiResult (common.js). */
    function rrShowResult(res, opts) {
        showApiResult(res, opts);
    }

    // Incompatibility handlers 

    /** from (src) and to (dst) are mutually exclusive. */
    function rrOnSrcIp() {
        const hasSrc = !!document.getElementById('rr_src_ip').value;
        rrSetDisabled('rr_dst_ip', hasSrc);
        if (hasSrc) {
            document.getElementById('rr_dst_ip').dispatchEvent(new Event('input', { bubbles: true }));
        }
        rrDebouncedBuild();
    }

    function rrOnDstIp() {
        const hasDst = !!document.getElementById('rr_dst_ip').value;
        rrSetDisabled('rr_src_ip', hasDst);
        if (hasDst) {
            document.getElementById('rr_src_ip').dispatchEvent(new Event('input', { bubbles: true }));
        }
        rrDebouncedBuild();
    }

    /**
     * sport / dport require an explicit proto (tcp or udp).
     */
    function rrOnProto() {
        const proto = rrVal('rr_proto');
        const needsProto = proto === 'tcp' || proto === 'udp';
        rrSetDisabled('rr_src_port', !needsProto);
        rrSetDisabled('rr_dst_port', !needsProto);
        rrDebouncedBuild();
    }

    // Action visibility 

    /** Shows the routing table select only when action is 'lookup'. */
    function rrToggleLookup() {
        const action = rrVal('rr_action');
        const wrap = document.getElementById('rr_table_wrap');
        if (wrap) wrap.style.display = action === 'lookup' ? '' : 'none';
        rrDebouncedBuild();
    }

    // Debounced preview fetch (backend) 

    let _rrPreviewTimer = null;

    /**
     * Fetches the ``ip rule`` preview from the backend without persisting.
     * Uses the same payload as ``rrCollectFormData``.
     */
    async function rrBuild() {
        const preview = document.getElementById('rr_preview');
        if (!preview) return;

        const payload = rrCollectFormData();

        // Client-side validation: name is required
        if (!payload.name) {
            preview.textContent = '';
            return;
        }
        // At least one match condition is recommended
        const hasMatcher = payload.mark || payload.src || payload.dst
                        || payload.iif || payload.sport || payload.dport;
        if (!hasMatcher) {
            preview.textContent = 'Add at least one match condition to preview';
            return;
        }
        // lookup action requires a table
        if (payload.action === 'lookup' && !payload.table) {
            preview.textContent = 'A routing table is required for the lookup action';
            return;
        }

        preview.textContent = 'Fetching preview...';

        try {
            const res = await apiClient.submit('preview_routing_rule', payload);
            const data = Array.isArray(res) ? res[0] : res;
            if (data && data.status === 'success' && data.result && data.result.ip_run) {
                preview.textContent = data.result.ip_run;
            } else if (data && data.response_msg) {
                preview.textContent = '⚠ ' + data.response_msg;
            } else {
                preview.textContent = '⚠ Preview error';
            }
        } catch (err) {
            preview.textContent = '⚠ ' + (err.message || 'Request failed');
        }
    }

    function rrDebouncedBuild() {
        if (_rrPreviewTimer) clearTimeout(_rrPreviewTimer);
        _rrPreviewTimer = setTimeout(rrBuild, 300);
    }

    // Collect form data 

    /**
     * Gathers all form field values into a flat object
     * ready to send to submit.php.
     * Reads directly from hidden inputs (no intermediate selects).
     */
    function rrCollectFormData() {
        const data = {};

        data.name     = rrVal('rr_name');
        data.priority = rrVal('rr_priority');
        data.active   = rrVal('rr_active') === '1';
        data.invert   = rrChecked('rr_invert');

        // Match conditions-read directly from hidden inputs
        data.mark   = document.getElementById('rr_mark')?.value   || null;
        data.src    = document.getElementById('rr_src_ip')?.value  || null;
        data.dst    = document.getElementById('rr_dst_ip')?.value  || null;
        data.iif    = document.getElementById('rr_iface')?.value   || null;
        data.proto  = rrVal('rr_proto') || null;
        data.sport  = document.getElementById('rr_src_port')?.value || null;
        data.dport  = document.getElementById('rr_dst_port')?.value || null;

        // Action
        data.action = rrVal('rr_action') || 'lookup';
        data.table  = document.getElementById('rr_table')?.value  || null;

        return data;
    }

    // Submit handlers 

    /** Add a new route rule via apiClient.submit(). */
    async function rrSubmit() {
        const data = rrCollectFormData();

        if (!data.name) {
            alert('Please enter a rule name.');
            return;
        }

        const hasMatcher = data.mark || data.src || data.dst
                        || data.iif || data.sport || data.dport;
        if (!hasMatcher) {
            alert('Add at least one match condition.');
            return;
        }

        if (data.action === 'lookup' && !data.table) {
            alert('A routing table is required for the lookup action.');
            return;
        }

        try {
            const result = await apiClient.submit('set_routing_rule', data);
            rrShowResult(result, {
                title: 'Add Route Rule',
                closeText: 'Close',
                reloadOnOk: true,
                boxStyle: { maxWidth: '50vw', maxHeight: '50vh' }
            });
        } catch (err) {
            rrShowResult({ ok: false, msg: err.message }, {
                title: 'Error',
                closeText: 'Close'
            });
        }
    }

    /** Delete a route rule by UUID. */
    async function rrDelete(id) {
        if (!id) return;
        if (!confirm('Are you sure you want to delete rule ' + id.substr(0, 8) + '\u2026 ?')) return;

        try {
            const result = await apiClient.submit('delete_routing_rule', { id: id });
            rrShowResult(result, {
                title: 'Delete Route Rule',
                closeText: 'Close',
                reloadOnOk: true,
                boxStyle: { maxWidth: '50vw', maxHeight: '50vh' }
            });
        } catch (err) {
            rrShowResult({ ok: false, msg: err.message }, {
                title: 'Error',
                closeText: 'Close'
            });
        }
    }

    /** Toggle a route rule active/inactive. */
    async function rrToggle(id, currentlyActive) {
        if (!id) return;

        try {
            const result = await apiClient.submit('toggle_routing_rule', {
                id: id,
                active: !currentlyActive
            });
            rrShowResult(result, {
                title: 'Toggle Route Rule',
                closeText: 'Close',
                reloadOnOk: true,
                boxStyle: { maxWidth: '50vw', maxHeight: '50vh' }
            });
        } catch (err) {
            rrShowResult({ ok: false, msg: err.message }, {
                title: 'Error',
                closeText: 'Close'
            });
        }
    }

    /** Edit a route rule-opens a pre-filled form (stub). */
    function rrEdit(id) {
        // TODO: Implement inline edit or modal with pre-populated fields
        alert('Edit mode for rule ' + id.substr(0, 8) + '\u2026 is not yet implemented.');
    }

    // UUID copy 

    function rrCopy(text, el) {
        if (!navigator.clipboard) {
            alert('Clipboard API not available.');
            return;
        }
        navigator.clipboard.writeText(text).then(() => {
            const orig = el.innerHTML;
            el.innerHTML = '<span class="std-badge std-badge--uuid">Copied!</span>';
            setTimeout(() => { el.innerHTML = orig; }, 1200);
        }).catch(() => {
            alert('Failed to copy to clipboard.');
        });
    }

    // Init 

    document.addEventListener('DOMContentLoaded', function () {
        // Initial UI state
        rrToggleLookup();
        rrOnProto();

        // Preview rebuild: bind input/change events to rrDebouncedBuild 
        ['rr_name', 'rr_invert'].forEach(function (id) {
            document.getElementById(id)?.addEventListener('input', rrDebouncedBuild);
        });
        ['rr_mark', 'rr_iface', 'rr_src_ip', 'rr_dst_ip', 'rr_src_port', 'rr_dst_port', 'rr_table'].forEach(function (id) {
            document.getElementById(id)?.addEventListener('input', rrDebouncedBuild);
        });
        ['rr_proto', 'rr_action', 'rr_active'].forEach(function (id) {
            document.getElementById(id)?.addEventListener('change', rrDebouncedBuild);
        });
        document.getElementById('rr_priority')?.addEventListener('input', rrDebouncedBuild);

        // Specific dependency handlers 
        document.getElementById('rr_src_ip')?.addEventListener('input', rrOnSrcIp);
        document.getElementById('rr_dst_ip')?.addEventListener('input', rrOnDstIp);
        document.getElementById('rr_proto')?.addEventListener('change', rrOnProto);
        document.getElementById('rr_action')?.addEventListener('change', rrToggleLookup);

        // Submit button 
        document.querySelector('[data-rr-submit]')?.addEventListener('click', rrSubmit);

        // UUID copy 
        document.querySelectorAll('[data-rr-copy]').forEach(function (el) {
            el.addEventListener('click', function () {
                var uuid = el.getAttribute('data-rr-copy');
                if (uuid) rrCopy(uuid, el);
            });
        });

        // Row action buttons via delegation (works with dynamic rows) 
        document.querySelector('.rr-root')?.addEventListener('click', function (e) {
            var btn = e.target.closest('button');
            if (!btn) return;

            var id = btn.dataset.id;

            if (btn.classList.contains('rr-delete')) {
                e.preventDefault();
                rrDelete(id);
            } else if (btn.classList.contains('rr-toggle')) {
                e.preventDefault();
                var isActive = btn.dataset.active === '1';
                rrToggle(id, isActive);
            } else if (btn.classList.contains('rr-edit')) {
                e.preventDefault();
                rrEdit(id);
            }
        });

        // Picker initialization 

        // Label picker helper (fwmark, routing tables)
        function initLabelPicker(pickerId, setType, title) {
            const picker = document.getElementById(pickerId);
            const field = picker ? picker.closest('[data-js="label-picker-field"]') : null;
            if (!picker || !field) return;
            const openBtn = field.querySelector('.js-set-picker-open');
            const clearBtn = field.querySelector('.js-set-picker-clear');
            const labelEl = field.querySelector('.js-set-picker-label');
            const filterScope = field.dataset.filterScope || null;
            openBtn?.addEventListener('click', function () {
                window.labelsMgmt.openPicker(field.dataset.setType || setType, {
                    title: title,
                    scope: filterScope,
                    onSelect: function (selection) {
                        if (!selection || !selection.length) return;
                        const pick = selection[0];
                        picker.value = pick.id || '';
                        if (labelEl) labelEl.textContent = pick.name || pick.id || '';
                        picker.dispatchEvent(new Event('input', { bubbles: true }));
                    },
                });
            });
            if (clearBtn) {
                clearBtn.addEventListener('click', function () {
                    picker.value = '';
                    if (labelEl) labelEl.textContent = openBtn?.dataset.placeholder || title;
                    picker.dispatchEvent(new Event('input', { bubbles: true }));
                });
            }
        }

        if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
            try {
                window.setsModal.initPickerFields(document);
            } catch (e) {
                console.error('setsModal init failed', e);
            }
        }

        initLabelPicker('rr_mark', 'packet_marking', 'Select fwmark');
        initLabelPicker('rr_table', 'routing_tables', 'Select routing table');
    });

})(window);
