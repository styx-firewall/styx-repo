// JS for network tuning forms

document.querySelectorAll('.std-tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.std-tab-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const tab = this.getAttribute('data-tab');
        document.querySelectorAll('.std-tab-panel').forEach(panel => {
            panel.style.display = (panel.getAttribute('data-tab') === tab) ? 'block' : 'none';
        });
    });
});

function normalizeSpaces(str) {
    return (str || '').replace(/\s+/g, ' ').trim();
}

function getChangedFields(form) {
    const changed = [];
    const keys = form.querySelectorAll('input[name="sysctl_keys[]"]');
    keys.forEach((keyInput) => {
        const key = keyInput.value;
        // Find the value input by data-sysctl-key among all js hooks
        const valueInput = form.querySelector('.js-sysctl-value[data-sysctl-key="' + key + '"]');
        if (!valueInput) return;
        let currentValue;
        if (valueInput.type === 'checkbox') {
            currentValue = valueInput.checked ? '1' : '0';
        } else {
            currentValue = valueInput.value;
        }
        // Normalize internal and external whitespace
        const originalNormalized = normalizeSpaces(valueInput.getAttribute('data-original'));
        const currentNormalized = normalizeSpaces(currentValue);
        if (currentNormalized !== originalNormalized) {
            changed.push({
                sysctl_key: key,
                value: currentValue
            });
        }
    });
    return changed;
}

function validateChangedFields(changedFields, form) {
    const errors = [];
    const keys = form.querySelectorAll('input[name="sysctl_keys[]"]');
    changedFields.forEach((field, i) => {
        // Find the corresponding input by sysctl_key
        const valueInput = form.querySelector('.js-sysctl-value[data-sysctl-key="' + field.sysctl_key + '"]');
        if (!valueInput) return;
        const original = valueInput.getAttribute('data-original');
        const current = field.value;
        // INT
        if (/^-?\d+$/.test(original)) {
            if (!/^-?\d+$/.test(current)) {
                errors.push(field.sysctl_key + ': must be an integer');
            }
        }
        // Triplet like "n n n" with spaces
        else if (/^\d+\s+\d+\s+\d+$/.test(original)) {
            if (!/^\d+\s+\d+\s+\d+$/.test(current)) {
                errors.push(field.sysctl_key + ': must be a three-number triplet separated by spaces (e.g., 1 2 3)');
            }
        }
        // String (non-empty)
        else {
            if (typeof current !== 'string' || current.trim() === '') {
                errors.push(field.sysctl_key + ': cannot be empty');
            }
        }
    });
    return errors;
}

function handleTunningFormSubmit(e) {
    e.preventDefault();
    const changedFields = getChangedFields(this);
    if (changedFields.length === 0) {
        alert('No changes to save');
        return;
    }
    const errors = validateChangedFields(changedFields, this);
    if (errors.length > 0) {
        alert('Validation errors:\n' + errors.join('\n'));
        return;
    }
    appLog('Changed fields:', changedFields);

    apiClient.submit('save_sysctl_tunning', { sysctl_keys: changedFields })
    .then(data => {
        showApiResult(data, { closeText: 'Close' });
    })
    .catch(err => {
        showApiResult({ status: 'error', response_msg: err?.message || String(err) }, { title: 'Error', closeText: 'Close' });
    });

}

// Strictly select forms by `data-js` attributes
document.querySelector('[data-js="sysctl-tunning-fields"]')?.closest('form')
    ?.addEventListener('submit', handleTunningFormSubmit);

document.querySelector('[data-js="sysctl-adv-tunning-fields"]')?.closest('form')
    ?.addEventListener('submit', handleTunningFormSubmit);
