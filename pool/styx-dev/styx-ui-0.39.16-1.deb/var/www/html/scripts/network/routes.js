// routes.js
// JS to handle add/delete table forms and add route in net-routes.tpl.php

document.addEventListener('DOMContentLoaded', () => {
    // Init pickers (set pickers + label pickers-both are used in the add-route form)
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }

    // Delete Route
    document.querySelectorAll('.delete-route-btn').forEach(btn => {
        btn.addEventListener('click', async function() {
            const routeId = this.getAttribute('data-route-id');
            if (!routeId) return;
            showModal('Are you sure you want to delete this route?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                        try {
                            const result = await apiClient.submit('delete_route_by_id', { route_id: routeId });
                            showApiResult(result, { title: 'Delete Route', closeText: 'Close', reloadOnOk: true });
                        } catch (err) {
                            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                        }
                }
            });
        });
    });
    // Route Filters
    function filterRoutesTables() {
        const tableValue = document.getElementById('filter-table-select')?.value || '';
        const scopeValue = document.getElementById('filter-scope-select')?.value || '';
        const typeValue = document.getElementById('filter-type-select')?.value || '';
        // Filter both tables
        [document.getElementById('ipv4-routes-table'), document.getElementById('ipv6-routes-table')].forEach(table => {
            if (!table) return;
            Array.from(table.tBodies[0].rows).forEach(row => {
                // Adjust indices according to the actual table structure
                // 0: warning, 1: dst, 2: gateway, 3: dev, 4: table, 5: protocol,
                // 6: scope, 7: prefsrc, 8: type, 9: flags,
                // 10: metric, 11: mtu, 12: actions
                const scopeCol = row.cells[6]?.textContent.trim();
                const typeCol = row.cells[8]?.textContent.trim();
                const tableCol = row.cells[4]?.textContent.trim();
                let visible = true;
                if (tableValue && tableCol !== tableValue) visible = false;
                if (scopeValue && scopeCol !== scopeValue) visible = false;
                if (typeValue && typeCol !== typeValue) visible = false;
                row.style.display = visible ? '' : 'none';
            });
        });
    }
    ['filter-table-select', 'filter-scope-select', 'filter-type-select'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', filterRoutesTables);
    });
    // Run filter on load
    filterRoutesTables();

    // Show/hide multipath nexthops section inside advanced options
    const pathModeCheckbox = document.getElementById('path-mode-checkbox');
    const multipathDiv = document.getElementById('multipath-nexthops');
    const nexthopList = document.getElementById('nexthop-list');
    const addNexthopBtn = document.getElementById('add-nexthop-btn');
    const mainIfaceSelect = document.querySelector('select[name="iface"]');
    if (pathModeCheckbox && multipathDiv) {
        // Toggle visibility by adding/removing `im-hide` class (CSS controls display)
        pathModeCheckbox.addEventListener('change', function() {
            if (this.checked) {
                multipathDiv.classList.remove('im-hide');
            } else {
                multipathDiv.classList.add('im-hide');
            }
        });
        // Initialize state on load
        if (pathModeCheckbox.checked) {
            multipathDiv.classList.remove('im-hide');
        } else {
            multipathDiv.classList.add('im-hide');
        }
    }
    // Add nexthop dynamically
    if (addNexthopBtn && nexthopList) {
        addNexthopBtn.addEventListener('click', function() {
            // Create a field block for a nexthop-requires mainIfaceSelect to exist
            const idx = nexthopList.children.length;
            const nhDiv = document.createElement('div');
            nhDiv.className = 'nexthop-row';
                // Gateway set-picker
                const gatewayPicker = document.createElement('div');
                gatewayPicker.className = 'nexthop-gateway-picker';
                gatewayPicker.innerHTML =
                    '<div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-filter-scope="host" data-required>'
                    + '<input type="hidden" name="nexthops[' + idx + '][gateway]" value="">'
                    + '<button type="button" class="std-btn set-picker-trigger js-set-picker-open"'
                    + ' data-placeholder="Select gateway&hellip;">'
                    + '<span class="js-set-picker-label">Select gateway&hellip;</span>'
                    + '</button>'
                    + '<button type="button" class="std-btn set-picker-clear js-set-picker-clear sets-hidden"'
                    + ' title="Clear selection">&#215;</button>'
                    + '</div>';

                // Build iface select cloned from main iface select only if options exist
                let ifaceField = null;
                if (mainIfaceSelect && mainIfaceSelect.options && mainIfaceSelect.options.length > 0) {
                    ifaceField = document.createElement('select');
                    ifaceField.name = `nexthops[${idx}][iface]`;
                    ifaceField.className = 'nexthop-input nexthop-iface input-select';
                    Array.from(mainIfaceSelect.options).forEach(opt => {
                        const o = document.createElement('option');
                        o.value = opt.value;
                        o.textContent = opt.textContent;
                        ifaceField.appendChild(o);
                    });
                }

                const weightInput = document.createElement('input');
                weightInput.type = 'number';
                weightInput.name = `nexthops[${idx}][weight]`;
                weightInput.min = '1';
                weightInput.value = '1';
                weightInput.placeholder = 'Weight';
                weightInput.className = 'nexthop-input nexthop-weight';

                const removeBtn = document.createElement('button');
                removeBtn.type = 'button';
                removeBtn.className = 'remove-nexthop-btn';
                removeBtn.textContent = 'Remove';
                removeBtn.addEventListener('click', function() {
                    nhDiv.remove();
                });

                nhDiv.appendChild(gatewayPicker);
                if (ifaceField) nhDiv.appendChild(ifaceField);
                nhDiv.appendChild(weightInput);
                nhDiv.appendChild(removeBtn);
                nexthopList.appendChild(nhDiv);
                window.setsModal.initPickerFields(nhDiv);
        });
    }
    // Show/hide advanced options in the route form
    // Note: CSS sets `.advanced-options { display: none; }` by default,
    // so we must use inline style.display to override it when showing.
    const toggleAdvancedBtn = document.getElementById('toggle-advanced-btn');
    const advancedOptionsDiv = document.getElementById('advanced-options');
    if (toggleAdvancedBtn && advancedOptionsDiv) {
        // Toggle advanced options by toggling the `im-hide` class.
        toggleAdvancedBtn.addEventListener('click', function() {
            const hidden = advancedOptionsDiv.classList.toggle('im-hide');
            this.textContent = hidden ? 'Show advanced options' : 'Hide advanced options';
        });

        // Ensure selecting multipath also reveals advanced options so nexthops are visible
        if (pathModeCheckbox) {
            pathModeCheckbox.addEventListener('change', function() {
                if (this.checked) {
                    if (advancedOptionsDiv.classList.contains('im-hide')) {
                        advancedOptionsDiv.classList.remove('im-hide');
                        if (toggleAdvancedBtn) toggleAdvancedBtn.textContent = 'Hide advanced options';
                    }
                }
            });
            // Initialize: if pathMode already multipath, reveal advanced options
            if (pathModeCheckbox.checked && advancedOptionsDiv.classList.contains('im-hide')) {
                advancedOptionsDiv.classList.remove('im-hide');
                if (toggleAdvancedBtn) toggleAdvancedBtn.textContent = 'Hide advanced options';
            }
        }
    }
    // Tab Handling
    window.showTab = function(tab) {
        const tabView = document.getElementById('tab-content-view');
        const tabAdd = document.getElementById('tab-content-add');
        const btnView = document.getElementById('tab-view');
        const btnAdd = document.getElementById('tab-add');
        if (tabView && tabAdd && btnView && btnAdd) {
                // show/hide views by toggling the standard hide class
                tabView.classList.toggle('im-hide', tab !== 'view');
                tabAdd.classList.toggle('im-hide', tab !== 'add');
                // toggle legacy route-tab-active for backward CSS
                btnView.classList.toggle('route-tab-active', tab === 'view');
                btnAdd.classList.toggle('route-tab-active', tab === 'add');
                // Also toggle std-tab-panel/std-tab-btn active state for std-tabs
                tabView.classList.toggle('active', tab === 'view');
                tabAdd.classList.toggle('active', tab === 'add');
                if (btnView) btnView.classList.toggle('active', tab === 'view');
                if (btnAdd) btnAdd.classList.toggle('active', tab === 'add');
        }
    }
    // Initialize with route view
    showTab('view');
    // Assign events to tab buttons
    const btnView = document.getElementById('tab-view');
    const btnAdd = document.getElementById('tab-add');
    // Add Route
    const addRouteForm = document.querySelector('.js-add-route-form');
    if (addRouteForm) {
        addRouteForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(addRouteForm);
            const route = {};
            let route_type = '';
            // Collect all simple fields
            for (const [key, value] of formData.entries()) {
                if (key === 'route_type') {
                    route_type = value;
                } else if (key === 'iface') {
                    route['dev'] = value;
                } else if (key.endsWith('[]')) {
                    const arrKey = key.replace('[]', '');
                    if (!route[arrKey]) route[arrKey] = [];
                    route[arrKey].push(value);
                } else if (key.match(/^nexthops\[[0-9]+\]\[[a-zA-Z0-9_]+\]$/)) {
                    // Multipath nexthops fields
                    const match = key.match(/^nexthops\[([0-9]+)\]\[([a-zA-Z0-9_]+)\]$/);
                    if (match) {
                        const idx = match[1];
                        const field = match[2];
                        if (!route.nexthops) route.nexthops = [];
                        if (!route.nexthops[idx]) route.nexthops[idx] = {};
                        // If the field is iface in nexthop, also rename it to dev
                        if (field === 'iface') {
                            route.nexthops[idx]['dev'] = value;
                        } else {
                            route.nexthops[idx][field] = value;
                        }
                    }
                } else {
                    route[key] = value;
                }
            }
            // Remove empty fields
            Object.keys(route).forEach(k => {
                if (route[k] === '' || route[k] === null || route[k] === undefined) delete route[k];
            });
            // Compact nexthops array: remove empty/sparse entries and reindex
            if (route.nexthops) {
                route.nexthops = route.nexthops.filter(nh => nh && Object.keys(nh).length > 0);
                if (route.nexthops.length === 0) delete route.nexthops;
            }
            // Validate required picker fields
            if (!route.dst) {
                showModal('<p>Please select a destination address set.</p>', { title: 'Validation error', closeText: 'Close' });
                return;
            }
            const isMultipath = route.path_mode === 'multipath';
            if (!isMultipath && !route.gateway) {
                showModal('<p>Please select a gateway address set.</p>', { title: 'Validation error', closeText: 'Close' });
                return;
            }
            const data = {
                command: 'add_route',
                route_type,
                route
            };
            try {
                const result = await apiClient.submit('add_route', data);
                showApiResult(result, { title: 'Add Route', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

});
