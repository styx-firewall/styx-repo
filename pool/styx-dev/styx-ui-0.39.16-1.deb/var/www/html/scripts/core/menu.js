document.addEventListener('DOMContentLoaded', function() {
    // start with all submenus closed
    document.querySelectorAll('.submenu').forEach(function(div) {
        div.classList.remove('open');
    });

    // Function to open and mark the section/submenu based on the URL
    function activateMenuSection(pageName, submenuId, pageParam) {
        if (page === pageName) {
            var section = document.querySelector('.menu-section[data-toggle="' + submenuId + '"]');
            var submenu = document.getElementById(submenuId);
            if (submenu) submenu.classList.add('open');
            if (section) section.classList.add('selected');
            var links = document.querySelectorAll('#' + submenuId + ' .submenu-link');
            links.forEach(function(link) {
                if (link.href && link.href.includes('?page=' + pageParam)) {
                    link.classList.add('selected');
                }
            });
        }
    }

    // Keep the submenu open based on the URL
    var params = new URLSearchParams(window.location.search);
    var page = (params.get('page') || '').toLowerCase().trim();
    var sectionParam = (params.get('section') || '').toLowerCase().trim();

    document.querySelectorAll('.submenu').forEach(function(submenu) {
        var links = submenu.querySelectorAll('.submenu-link');
        var matched = false;
        links.forEach(function(link) {
            if (!link.href) return;
            var href = link.href.toLowerCase();
            if (href.indexOf('?page=' + page) !== -1) {
                if (!sectionParam || href.indexOf('&section=' + sectionParam) !== -1) {
                    matched = true;
                    link.classList.add('selected');
                }
            }
        });
        if (matched) {
            submenu.classList.add('open');
            var section = document.querySelector('.menu-section[data-toggle="' + submenu.id + '"]');
            if (section) section.classList.add('selected');
        }
    });

    // Expand/collapse sidebar subsections
    document.querySelectorAll('.menu-section').forEach(function(section) {
        section.addEventListener('click', function(e) {
            // Ignore if the click was on a submenu link
            if (e.target.closest('.submenu-link')) return;
            var submenu = document.getElementById(this.dataset.toggle);
            if (submenu) {
                submenu.classList.toggle('open');
            }
            // Mark section as selected
            document.querySelectorAll('.menu-section').forEach(function(s) {
                s.classList.remove('selected');
            });
            this.classList.add('selected');
            // Remove selection from submenu links
            document.querySelectorAll('.submenu-link').forEach(function(a) {
                a.classList.remove('selected');
            });
        });
    });
    // Mark submenu item as selected
    document.querySelectorAll('.submenu-link').forEach(function(link) {
        link.addEventListener('click', function(e) {
            // Remove selection from submenu links
            document.querySelectorAll('.submenu-link').forEach(function(a) {
                a.classList.remove('selected');
            });
            this.classList.add('selected');
            // Mark the parent section as selected
            document.querySelectorAll('.menu-section').forEach(function(s) {
                s.classList.remove('selected');
            });
            var parentSection = this.closest('.menu-section-wrap').querySelector('.menu-section');
            if (parentSection) {
                parentSection.classList.add('selected');
            }
            // Keep the parent submenu open
            var parentSubmenu = this.closest('.submenu');
            if (parentSubmenu) {
                parentSubmenu.classList.add('open');
            }
        });
    });
});