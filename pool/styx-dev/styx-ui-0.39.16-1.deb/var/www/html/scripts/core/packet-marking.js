// Helpers 

// Protocol filtering by family 
function filterProtocolOptions(family) {
    const sel = document.getElementById('rule_proto');
    if (!sel) return;
    let currentValid = false;
    for (const opt of sel.options) {
        if (!opt.value) continue;
        const optFamily = opt.dataset.family || 'both';
        const show = !family || optFamily === 'both' || optFamily === family;
        opt.hidden   = !show;
        opt.disabled = !show;
        if (sel.value === opt.value && show) currentValid = true;
    }
    if (!currentValid && sel.value) {
        sel.value = '';
        if (family) setHint('h_proto', 'protocol not available for ' + family, true);
    } else {
        setHint('h_proto', '');
    }
}

function getSelectedData(id) {
    const el = document.getElementById(id);
    if (!el || !el.value) return null;
    if (el.type === 'hidden') {
        const wrapper = el.closest('[data-js="set-picker-field"], [data-js="label-picker-field"]');
        const labelEl = wrapper?.querySelector('.js-set-picker-label');
        return {
            id:     el.value,
            label:  labelEl?.textContent?.trim() || '',
            family: wrapper?.dataset.filterFamily || '',
        };
    }
    // select element (chain, proto, etc.)
    const opt = el.options[el.selectedIndex];
    return {
        id:     el.value,
        family: opt.dataset.family ?? '',
    };
}

// Dependencies / disabled 
const NETDEV_CHAINS = new Set(['ingress', 'egress']);
const PORT_PROTO    = new Set(['tcp', 'udp', 'sctp']);

function setFieldDisabled(id, disabled, hintId, hintText, hintWarn) {
    const el = document.getElementById(id);
    if (!el) return;
    el.disabled = disabled;
    if (disabled && el.value) el.value = '';
    if (el.type === 'hidden') {
        const wrapper = el.closest('[data-js="set-picker-field"]');
        if (wrapper) {
            const openBtn  = wrapper.querySelector('.js-set-picker-open');
            const clearBtn = wrapper.querySelector('.js-set-picker-clear');
            const labelEl  = wrapper.querySelector('.js-set-picker-label');
            if (openBtn) {
                openBtn.disabled = disabled;
                if (disabled) openBtn.classList.remove('set-picker-trigger--has-value');
            }
            if (disabled) {
                if (clearBtn) clearBtn.classList.add('sets-hidden');
                if (labelEl) labelEl.textContent = openBtn?.dataset.placeholder || 'Select...';
            }
        }
    }
    if (hintId) setHint(hintId, hintText, hintWarn);
}

function setHint(id, text, warn) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent  = text || '';
    el.className    = 'hint' + (warn ? ' warn' : '');
}

function filterIpSetOptions(family) {
    const prevFamily = filterIpSetOptions._prevFamily;
    const familyChanged = family !== prevFamily;
    filterIpSetOptions._prevFamily = family;

    for (const id of ['f_src_addr', 'f_dst_addr']) {
        const hiddenInput = document.getElementById(id);
        if (!hiddenInput) continue;
        const wrapper = hiddenInput.closest('[data-js="set-picker-field"]');
        if (wrapper) {
            if (family) {
                wrapper.dataset.filterFamily = family;
            } else {
                delete wrapper.dataset.filterFamily;
            }
        }
        // Clear current selection only when family filter actually changes.
        if (hiddenInput.value && familyChanged) {
            hiddenInput.value = '';
            if (wrapper) {
                const openBtn  = wrapper.querySelector('.js-set-picker-open');
                const clearBtn = wrapper.querySelector('.js-set-picker-clear');
                const labelEl  = wrapper.querySelector('.js-set-picker-label');
                if (labelEl) labelEl.textContent = openBtn?.dataset.placeholder || '— any —';
                if (openBtn) openBtn.classList.remove('set-picker-trigger--has-value');
                if (clearBtn) clearBtn.classList.add('sets-hidden');
            }
        }
        const hintId = id === 'f_src_addr' ? 'h_src_addr' : 'h_dst_addr';
        setHint(hintId, '');
    }
}

function filterIfaceSetOptions(onlySingle) {
    const hiddenInput = document.getElementById('f_iface_set');
    if (!hiddenInput) return;
    const wrapper = hiddenInput.closest('[data-js="set-picker-field"]');
    if (wrapper) {
        if (onlySingle) {
            wrapper.dataset.filterType = 'single';
        } else {
            delete wrapper.dataset.filterType;
        }
    }
    // Always clear current selection when switching to single-only mode.
    if (hiddenInput.value && onlySingle) {
        hiddenInput.value = '';
        if (wrapper) {
            const openBtn  = wrapper.querySelector('.js-set-picker-open');
            const clearBtn = wrapper.querySelector('.js-set-picker-clear');
            const labelEl  = wrapper.querySelector('.js-set-picker-label');
            if (labelEl) labelEl.textContent = openBtn?.dataset.placeholder || '— none —';
            if (openBtn) openBtn.classList.remove('set-picker-trigger--has-value');
            if (clearBtn) clearBtn.classList.add('sets-hidden');
        }
    }
}

function applyDependencies() {
    const chain    = document.getElementById('rule_chain')?.value   || '';
    const proto    = document.getElementById('rule_proto')?.value   || '';
    const family   = document.getElementById('rule_family')?.value  || '';
    const ifaceDir = document.getElementById('f_iface_dir')?.value  || '';
    const isNetdev = NETDEV_CHAINS.has(chain);
    const hasProto = PORT_PROTO.has(proto);

    // Filter protocols by family (empty family = show all)
    filterProtocolOptions(family);

    // iface_dir / iface_set
    // In netdev the device is in the chain, iif/oif are not valid matchers.
    // In OUTPUT/POSTROUTING iif makes no sense (packet already routed).
    const outChain = ['output', 'postrouting'].includes(chain);

    if (isNetdev) {
        setFieldDisabled('f_iface_dir', true, 'h_iface_dir', '', false);
        // netdev needs a single-interface set as the device target
        filterIfaceSetOptions(true);
        setFieldDisabled('f_iface_set', false, 'h_iface_set', 'required: select the device (single interface sets only)', false);
    } else if (outChain && ifaceDir === 'iifname') {
        // iifname invalid in output chains-clear and warn
        document.getElementById('f_iface_dir').value = '';
        setFieldDisabled('f_iface_set', true, 'h_iface_dir',
            'iif not available in output chains', true);
        document.getElementById('f_iface_dir').disabled = false;
        setHint('h_iface_dir', 'iif not available in this chain', true);
    } else {
        document.getElementById('f_iface_dir').disabled = false;
        setHint('h_iface_dir', '');
        filterIfaceSetOptions(false);
        // iface_set requires direction selected
        if (!ifaceDir) {
            setFieldDisabled('f_iface_set', true, 'h_iface_set', 'select direction first', false);
        } else {
            setFieldDisabled('f_iface_set', false, 'h_iface_set', '', false);
        }
    }

    // chain hint
    if (isNetdev) {
        setHint('h_chain', 'netdev table-iface is the chain device');
    } else {
        setHint('h_chain', '');
    }

    // ports require tcp, udp or sctp
    for (const [id, hintId] of [['f_src_port','h_src_port'], ['f_dst_port','h_dst_port']]) {
        setFieldDisabled(id, !hasProto, hintId,
            !hasProto ? 'requires tcp, udp or sctp' : '',
            !hasProto && proto !== '');
    }

    // mark_target: lock to meta when no connection state available
    const lockMeta = proto === 'icmp' || proto === 'icmpv6' || chain === 'ingress';
    const mts = document.getElementById('rule_mark_target');
    if (mts) { mts.disabled = lockMeta; if (lockMeta) mts.value = 'meta'; }
    setHint('h_mark_target',
        proto === 'icmp' || proto === 'icmpv6' ? 'icmp/icmpv6 has no connection state-meta mark only'
        : chain === 'ingress'                  ? 'ct mark not available in netdev ingress'
        : '', lockMeta);

    // Filter IP sets by family (ip/ip6)-hide mismatched sets
    filterIpSetOptions(family);

    debouncedBuildCondition();
}

// Debounced preview fetch (backend) 
let _previewTimer = null;

function _buildPreviewPayload() {
    const payload = {
        name:         document.getElementById('rule_name')?.value?.trim()       || '',
        chain:        document.getElementById('rule_chain')?.value             || null,
        protocol:     document.getElementById('rule_proto')?.value             || null,
        priority:     _parsePriority(),
        mark:         document.getElementById('rule_mark')?.value              || null,
        mark_target:  document.getElementById('rule_mark_target')?.value       || 'meta',
        family:       document.getElementById('rule_family')?.value            || null,
        active:       document.getElementById('rule_active')?.value === '1',
        iface_dir:    document.getElementById('f_iface_dir')?.value            || null,
        iface_set:    document.getElementById('f_iface_set')?.value            || null,
        src_addr:     document.getElementById('f_src_addr')?.value             || null,
        dst_addr:     document.getElementById('f_dst_addr')?.value             || null,
        src_port:     document.getElementById('f_src_port')?.value     || null,
        dst_port:     document.getElementById('f_dst_port')?.value     || null,
    };
    return payload;
}

function _parsePriority() {
    const el = document.getElementById('rule_priority');
    if (!el || el.value === '' || el.value === undefined) return null;
    const v = parseInt(el.value, 10);
    return isNaN(v) ? null : v;
}

async function buildCondition() {
    const preview = document.getElementById('condition_preview');
    if (!preview) return;

    const payload = _buildPreviewPayload();

    // Client-side validation: match backend required fields before sending
    if (!payload.chain || !payload.family) {
        preview.textContent = '';
        return;
    }
    if (!payload.name || !payload.mark) {
        const missing = [];
        if (!payload.name) missing.push('name');
        if (!payload.mark) missing.push('mark value');
        preview.textContent =  missing.join(' and ') + ' is required';
        return;
    }

    // Show loading state
    preview.textContent = 'Fetching preview...';

    try {
        const res = await apiClient.submit('preview_pm_rule', payload);
        // submit.php returns an array of responses; unwrap the first element
        const data = Array.isArray(res) ? res[0] : res;
        if (data && data.status === 'success' && data.result && data.result.nft_run) {
            preview.textContent = data.result.nft_run;
        } else if (data && data.response_msg) {
            preview.textContent = '⚠ ' + data.response_msg;
        } else {
            preview.textContent = '⚠ Preview error';
        }
    } catch (err) {
        preview.textContent = '⚠ ' + (err.message || 'Request failed');
    }
}

function debouncedBuildCondition() {
    if (_previewTimer) clearTimeout(_previewTimer);
    _previewTimer = setTimeout(buildCondition, 300);
}

// Listeners 
[
    'rule_name', 'rule_chain', 'rule_proto', 'rule_family', 'rule_mark', 'rule_mark_target', 'f_iface_dir'
].forEach(id => {
    document.getElementById(id)?.addEventListener('change', applyDependencies);
});
['f_iface_set', 'f_src_addr', 'f_dst_addr', 'f_src_port', 'f_dst_port', 'rule_mark'].forEach(id => {
    document.getElementById(id)?.addEventListener('input', applyDependencies);
});
document.getElementById('rule_priority')?.addEventListener('change', debouncedBuildCondition);

// Submit 
async function submitRule() {
    const payload = _buildPreviewPayload();

    // Validations specific to submit (stricter than preview)
    if (!payload.name) return alert('Name is required.');
    if (!payload.chain) return alert('Chain is required.');
    if (!payload.family) return alert('IP family is required.');

    const uuidRe = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
    if (!uuidRe.test(payload.mark)) return alert('Select a valid mark.');

    if (!['meta', 'ct'].includes(payload.mark_target)) return alert('Invalid mark_target.');

    // Client-side validation: require at least one matcher/condition
    // (interface set for netdev or IP/port sets). This prevents sending
    // a rule that only contains an action (e.g. "meta mark set ...").
    const hasMatcher = Boolean(
        payload.iface_set || payload.src_addr || payload.dst_addr ||
        payload.src_port  || payload.dst_port
    );
    if (!hasMatcher) return alert('Select at least one matcher: interface set, IP set or port set.');
    if (NETDEV_CHAINS.has(payload.chain) && !payload.iface_set)
        return alert('A device interface set is required for ingress/egress chains.');

    try {
        const result = await apiClient.submit('set_pm_rule', payload);
        showResult(result, { title: 'Add Rule', closeText: 'Close', reloadOnOk: true });
    } catch (err) {
        showResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
    }
}

// UUID copy 
function copyText(text, el) {
    navigator.clipboard?.writeText(text).then(() => {
        const orig = el.innerHTML;
        el.innerHTML = '<span class="std-badge std-badge--uuid" style="color:var(--green);border-color:var(--green);">Copied!</span>';
        setTimeout(() => { el.innerHTML = orig; }, 1200);
    });
}

// Delegated rule actions (via data-action) 
function _shortId(id) {
    return id && id.length > 8 ? id.substring(0, 8) + '...' : id;
}

const RULE_ACTIONS = {
    'toggle-rule': id => confirmThenReload(`Toggle rule ${_shortId(id)}?`, 'toggle_pm_rule', id),
    'delete-rule': id => confirmThenReload(`Delete rule ${_shortId(id)}?`, 'delete_pm_rule', id),
    'edit-rule': id => {
        const shortId = _shortId(id);
        if (typeof showModal === 'function') {
            showModal(`<p>Edit rule <strong>${shortId}</strong></p><p><em>Not implemented.</em></p>`, { title: 'Edit Rule', closeText: 'Close' });
        } else {
            alert('Edit stub-id: ' + id);
        }
    },
};

document.addEventListener('click', async e => {
    const btn = e.target.closest('[data-action][data-id]');
    if (!btn) return;
    const action = btn.dataset.action;
    if (!RULE_ACTIONS[action]) return;
    try { await RULE_ACTIONS[action](btn.dataset.id); } catch (err) { showResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' }); }
});

// Show result 
function showResult(res, opts = {}) {
    showApiResult(res, opts);
}

// Confirm then reload helper 
function isResultOk(res) {
    if (!res) return false;
    if (Array.isArray(res)) {
        return res.some(function (r) { return r && r.status === 'success'; });
    }
    return res.status === 'success';
}

function confirmThenReload(message, submitAction, id) {
    if (!confirm(message)) return;
    apiClient.submit(submitAction, { id }).then(res => {
        if (isResultOk(res)) { window.location.reload(); return; }
        showResult(res, { title: 'Error', closeText: 'Close' });
    }).catch(err => {
        showResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
    });
}

// Init 
if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
    window.setsModal.initPickerFields(document);
}
if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
    window.labelsMgmt.initPickerFields(document);
}
applyDependencies();