import { sendRefreshRequest } from '../refresh/refreshDispatcher.js';

function init() {
    sendRefreshRequest();
    setInterval(sendRefreshRequest, 20 * 1000); // Refresh every 15 seconds
}

document.addEventListener('DOMContentLoaded', init);
