document.addEventListener('DOMContentLoaded', function() {
    const topPanelBtn = document.getElementById('top-panel-btn');
    const fixedPanel = document.getElementById('fixed-panel');
    let dragging = false;
    let startY = 0;
    let startTop = 0;

    // Function to recalculate the panel offset
    function recalcularOffsetPanel() {
        fixedPanel.style.top = (-fixedPanel.offsetHeight) + 'px';
        topPanelBtn.style.top = '0px';
    }
    window.recalcularOffsetPanel = recalcularOffsetPanel;

    // Defer layout read until after stylesheets are applied to avoid
    // "Layout was forced before the page was fully loaded" warning.
    requestAnimationFrame(() => recalcularOffsetPanel());

    topPanelBtn.addEventListener('mousedown', function(e) {
        dragging = true;
        startY = e.clientY;
        // Usar getComputedStyle para obtener el valor actual de top
        startTop = parseInt(window.getComputedStyle(topPanelBtn).top);
        document.body.style.userSelect = 'none';
    });
    // Click event on the top button adjusts the scroll height only if not dragging
    let clickDragBlock = false;
    topPanelBtn.addEventListener('mousedown', function(e) { clickDragBlock = false; });
    topPanelBtn.addEventListener('mousemove', function(e) { clickDragBlock = true; });
    topPanelBtn.addEventListener('click', function(e) {
        if (clickDragBlock) return;
        const panelScroll = document.getElementById('panel-scroll');
        const contenidoAltura = panelScroll.scrollHeight;
        const alturaActual = parseInt(panelScroll.style.maxHeight) || 0;
        const nuevaAltura = Math.min(300, contenidoAltura + 14);
        if (alturaActual > 60) {
            // If open, collapse and fully hide the panel
            panelScroll.style.maxHeight = '60px';
            recalcularOffsetPanel();
        } else {
            // If closed, open it
            panelScroll.style.maxHeight = nuevaAltura + 'px';
            topPanelBtn.style.top = nuevaAltura + 'px';
            fixedPanel.style.top = (nuevaAltura - fixedPanel.offsetHeight) + 'px';
        }
    });
    document.addEventListener('mousemove', function(e) {
        if (dragging) {
            let delta = e.clientY - startY;
            let newTop = Math.max(0, startTop + delta);
            let panelTop = newTop - fixedPanel.offsetHeight;
            // Lock if the panel is fully revealed
            if (panelTop >= 0) {
                topPanelBtn.style.top = fixedPanel.offsetHeight + 'px';
                fixedPanel.style.top = '0px';
                return;
            }
            topPanelBtn.style.top = newTop + 'px';
            fixedPanel.style.top = panelTop + 'px';
            // Adjust `panel-scroll` height dynamically
            const panelScroll = document.getElementById('panel-scroll');
            const minHeight = 60;
            const maxHeight = 400;
            let newHeight = Math.max(minHeight, Math.min(maxHeight, newTop + 20));
            panelScroll.style.maxHeight = newHeight + 'px';
        }
    });
    document.addEventListener('mouseup', function(e) {
        if (dragging) {
            dragging = false;
            document.body.style.userSelect = '';
        }
    });
});
