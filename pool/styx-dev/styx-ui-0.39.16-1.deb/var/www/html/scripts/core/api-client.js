/**
 * api-client.js
 * Centralized client for calling request.php and submit.php
 * - Provides: apiClient.request(action, data, opts) and apiClient.submit(command, data, opts)
 * - Handles JSON encoding, timeouts (AbortController), credentials and unified error shape
 */
(function (window) {
    'use strict';

    const DEFAULT_TIMEOUT = 10000; // ms
    let _connectionErrorActive = false; // guard against duplicate modals

    /**
     * Detect whether a response indicates the backend gateway is unreachable.
     * Uses the `error_code` set by the PHP backend when the socket connection fails.
     */
    function _isConnectionError(data) {
        return !!(data && data.error_code === 'GATEWAY_UNREACHABLE');
    }

    /**
     * Show a modal with Retry / Logout when the backend is unreachable.
     * @param {Function} retryFn-re-executes the original request
     * @returns {Promise<any>}-the retry result, or an error object on logout / guard
     */
    function _handleConnectionError(retryFn) {
        if (_connectionErrorActive) {
            // Already showing the modal-return an error object (not null)
            // so callers can safely inspect .status / .response_msg
            return Promise.resolve({ status: 'error', response_msg: 'Connection lost', error_code: 'GATEWAY_UNREACHABLE' });
        }
        _connectionErrorActive = true;

        return new Promise((resolve) => {
            const doRetry = async () => {
                _connectionErrorActive = false;
                try {
                    const result = await retryFn();
                    resolve(result);
                } catch (e) {
                    // Retry threw-show the modal again
                    resolve(await _handleConnectionError(retryFn));
                }
            };

            const doLogout = () => {
                _connectionErrorActive = false;
                window.location.href = '/?page=logout&fast=1';
                resolve({ status: 'error', response_msg: 'Logged out', error_code: 'GATEWAY_UNREACHABLE' });
            };

            const html = '<p>The backend service is temporarily unavailable. You can retry the operation or log out.</p>';

            try {
                if (typeof window.showModal === 'function') {
                    window.showModal(html, {
                        title: 'Connection lost',
                        showConfirm: true,
                        confirmText: 'Retry',
                        closeText: 'Logout',
                        onConfirm: doRetry,
                        onClose: doLogout,
                        modalStyle: { zIndex: '99999' }
                    });
                } else {
                    if (confirm('Backend service unavailable. Click OK to retry or Cancel to log out.')) {
                        doRetry();
                    } else {
                        doLogout();
                    }
                }
            } catch (e) {
                // Safety net: if showModal throws synchronously, don't deadlock
                _connectionErrorActive = false;
                resolve({ status: 'error', response_msg: 'Connection lost', error_code: 'GATEWAY_UNREACHABLE' });
            }
        });
    }

    function _timeoutPromise(ms, controller) {
        return setTimeout(() => controller.abort(), ms);
    }

    async function _postJson(endpoint, payload, timeout = DEFAULT_TIMEOUT, opts = {}) {
        const controller = new AbortController();
        const timer = _timeoutPromise(timeout, controller);
        const externalSignal = opts && opts.signal;
        let externalAbortListener = null;

        if (externalSignal && typeof externalSignal.addEventListener === 'function') {
            // If external signal aborts, abort our internal controller
            externalAbortListener = () => controller.abort();
            externalSignal.addEventListener('abort', externalAbortListener);
        }

        try {
            const res = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
                credentials: 'same-origin',
                signal: controller.signal
            });

            // Try to parse JSON; if parsing fails, return standardized error
            const text = await res.text();
            try {
                const json = text ? JSON.parse(text) : { status: 'error', response_msg: 'Empty response' };
                // normalize structure
                if (json && typeof json === 'object') {
                    if (json.error_code === 'UNAUTHORIZED') {
                        window.location.href = '/?page=login';
                    }
                    // Connection error detection-explicit signal from backend
                    if (_isConnectionError(json)) {
                        return await _handleConnectionError(() => _postJson(endpoint, payload, timeout, opts));
                    }
                    return json;
                }
                return { status: 'error', response_msg: 'Invalid JSON response' };
            } catch (e) {
                return { status: 'error', response_msg: 'Invalid JSON response: ' + e.message };
            }
        } catch (err) {
            if (err && err.name === 'AbortError') {
                return { status: 'error', response_msg: 'Request timeout' };
            }
            // Network-level failure (PHP server unreachable)-show modal
            return await _handleConnectionError(() => _postJson(endpoint, payload, timeout, opts));
        } finally {
            clearTimeout(timer);
            if (externalSignal && externalAbortListener && typeof externalSignal.removeEventListener === 'function') {
                externalSignal.removeEventListener('abort', externalAbortListener);
            }
        }
    }

    async function _postRaw(endpoint, payload, timeout = DEFAULT_TIMEOUT, opts = {}) {
        const controller = new AbortController();
        const timer = _timeoutPromise(timeout, controller);
        const externalSignal = opts && opts.signal;
        let externalAbortListener = null;

        if (externalSignal && typeof externalSignal.addEventListener === 'function') {
            externalAbortListener = () => controller.abort();
            externalSignal.addEventListener('abort', externalAbortListener);
        }

        try {
            const res = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
                credentials: 'same-origin',
                signal: controller.signal
            });
            return res;
        } catch (err) {
            // Preserve AbortError for callers to handle cancellations
            throw err;
        } finally {
            clearTimeout(timer);
            if (externalSignal && externalAbortListener && typeof externalSignal.removeEventListener === 'function') {
                externalSignal.removeEventListener('abort', externalAbortListener);
            }
        }
    }

    function _ensureMetadata(obj) {
        if (!obj.metadata || typeof obj.metadata !== 'object') obj.metadata = {};
        return obj;
    }

    /**
     * Send action to request.php
     * @param {string} action
     * @param {object} data
     * @param {object} opts { timeout, client_request_id }
     */
    function request(action, data = {}, opts = {}) {
        const timeout = Number(opts.timeout ?? DEFAULT_TIMEOUT);
        const payload = Object.assign({}, data);
        payload.action = action;
        _ensureMetadata(payload);
        if (opts.client_request_id) payload.metadata.client_request_id = opts.client_request_id;
        return _postJson('/request.php', payload, timeout, opts);
    }

    /**
     * requestRaw: same as request but returns the raw Response for callers
     */
    function requestRaw(action, data = {}, opts = {}) {
        const timeout = Number(opts.timeout ?? DEFAULT_TIMEOUT);
        const payload = Object.assign({}, data);
        payload.action = action;
        _ensureMetadata(payload);
        if (opts.client_request_id) payload.metadata.client_request_id = opts.client_request_id;
        return _postRaw('/request.php', payload, timeout, opts);
    }

    /**
     * Send command to submit.php
     * @param {string} command
     * @param {object} data
     * @param {object} opts { timeout, client_request_id }
     */
    function submit(command, data = {}, opts = {}) {
        const timeout = Number(opts.timeout ?? DEFAULT_TIMEOUT);
        const payload = Object.assign({}, data);
        payload.command = command;
        _ensureMetadata(payload);
        if (opts.client_request_id) payload.metadata.client_request_id = opts.client_request_id;
        return _postJson('/submit.php', payload, timeout, opts);
    }

    /**
     * postRaw: low-level post that returns raw Response
     */
    function postRaw(endpoint, payload = {}, opts = {}) {
        const timeout = Number(opts.timeout ?? DEFAULT_TIMEOUT);
        return _postRaw(endpoint, payload, timeout, opts);
    }

    // Export to global namespace
    window.apiClient = {
        request,
        submit,
        // low-level for ad-hoc calls
        postJson: _postJson,
        postRaw: postRaw,
        requestRaw: requestRaw,
        defaultTimeout: DEFAULT_TIMEOUT
    };

})(window);
