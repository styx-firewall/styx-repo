function createDynamicTable({thead, data, controlsId, tableId, rowLink, onRowClick, collapsibleRows = false, collapsibleFilters = false, rowClass, columnsConfig = null}) {
    let columns = Object.keys(thead).map(key => ({
        key,
        label: thead[key],
        visible: columnsConfig ? (columnsConfig[key] !== undefined ? columnsConfig[key] : true) : true
    }));

    function renderControls() {
        const controls = document.getElementById(controlsId);
        controls.innerHTML = '';
        const dragContainer = document.createElement('div');
        dragContainer.classList.add('std-drag-container');

        columns.forEach((col, idx) => {
            const wrapper = document.createElement('div');
            wrapper.classList.add('std-drag-wrapper');
            wrapper.draggable = true;
            wrapper.dataset.idx = idx;

            wrapper.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('text/plain', idx);
                wrapper.classList.add('dragging');
            });
            wrapper.addEventListener('dragend', (e) => {
                wrapper.classList.remove('dragging');
            });
            wrapper.addEventListener('dragover', (e) => {
                e.preventDefault();
                wrapper.classList.add('drag-over');
            });
            wrapper.addEventListener('dragleave', (e) => {
                wrapper.classList.remove('drag-over');
            });
            wrapper.addEventListener('drop', (e) => {
                e.preventDefault();
                wrapper.classList.remove('drag-over');
                const fromIdx = parseInt(e.dataTransfer.getData('text/plain'));
                const toIdx = parseInt(wrapper.dataset.idx);
                if (fromIdx !== toIdx) {
                    const moved = columns.splice(fromIdx, 1)[0];
                    columns.splice(toIdx, 0, moved);
                    renderControls();
                    renderTable();
                }
            });

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.checked = col.visible;
            checkbox.onchange = () => {
                col.visible = checkbox.checked;
                renderTable();
            };
            wrapper.appendChild(checkbox);

            const label = document.createElement('label');
            label.textContent = col.label;
            label.classList.add('std-drag-label');
            wrapper.appendChild(label);

            dragContainer.appendChild(wrapper);
        });
        if (collapsibleFilters) {
            // Encapsulate controls in a standard collapsible
            const collapseBox = document.createElement('div');
            collapseBox.className = 'std-collapse-box';
            const collapseHeader = document.createElement('div');
            collapseHeader.className = 'std-collapse-header';
            collapseHeader.textContent = 'Column filters';
            collapseHeader.onclick = function() {
                collapseBox.classList.toggle('open');
            };
            collapseBox.appendChild(collapseHeader);
            const collapseContent = document.createElement('div');
            collapseContent.className = 'std-collapse-content';
            collapseContent.appendChild(dragContainer);
            collapseBox.appendChild(collapseContent);
            controls.appendChild(collapseBox);
            // Collapsed by default
            collapseBox.classList.remove('open');
        } else {
            controls.appendChild(dragContainer);
        }
    }

    function renderTable() {
        const table = document.getElementById(tableId);
        table.innerHTML = '';
        const theadEl = document.createElement('thead');
        const trHead = document.createElement('tr');
        const visibleCols = columns.map((col, idx) => ({...col, absIdx: idx})).filter(col => col.visible);

        visibleCols.forEach((col, visIdx) => {
            const th = document.createElement('th');
            th.textContent = col.label;
            th.draggable = true;
            th.classList.add('std-drag-grab');
            th.dataset.visIdx = visIdx;

            th.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('vis-idx', visIdx);
                th.classList.add('dragging');
            });
            th.addEventListener('dragend', (e) => {
                th.classList.remove('dragging');
            });
            th.addEventListener('dragover', (e) => {
                e.preventDefault();
                th.classList.add('th-drag-over');
            });
            th.addEventListener('dragleave', (e) => {
                th.classList.remove('th-drag-over');
            });
            th.addEventListener('drop', (e) => {
                e.preventDefault();
                th.classList.remove('th-drag-over');
                const fromVisIdx = parseInt(e.dataTransfer.getData('vis-idx'));
                const toVisIdx = visIdx;
                if (fromVisIdx === toVisIdx) return;
                const fromAbsIdx = visibleCols[fromVisIdx].absIdx;
                const toAbsIdx = visibleCols[toVisIdx].absIdx;
                const moved = columns.splice(fromAbsIdx, 1)[0];
                columns.splice(toAbsIdx, 0, moved);
                renderControls();
                renderTable();
            });

            trHead.appendChild(th);
        });
        theadEl.appendChild(trHead);
        table.appendChild(theadEl);

        const tbodyEl = document.createElement('tbody');
        data.forEach(row => {
            const tr = document.createElement('tr');
            // Apply class if `rowClass` is defined
            if (typeof rowClass === 'function') {
                const cls = rowClass(row);
                if (cls) tr.classList.add(cls);
            }
            visibleCols.forEach(col => {
                const td = document.createElement('td');
                td.textContent = row[col.key];
                tr.appendChild(td);
            });
            // Support for `onRowClick` and `rowLink`
            if (typeof onRowClick === 'function') {
                tr.addEventListener('click', function() {
                    onRowClick(row);
                });
                tr.classList.add('row-link-cursor');
            } else if (typeof rowLink === 'function') {
                tr.addEventListener('click', function() {
                    const url = rowLink(row);
                    if (url) window.location.href = url;
                });
                tr.addEventListener('mouseover', function() {
                    tr.classList.add('row-link-cursor');
                });
                tr.addEventListener('mouseout', function() {
                    tr.classList.remove('row-link-cursor');
                });
            }
            tbodyEl.appendChild(tr);
        });
        table.appendChild(tbodyEl);
    }

    renderControls();
    renderTable();
}
