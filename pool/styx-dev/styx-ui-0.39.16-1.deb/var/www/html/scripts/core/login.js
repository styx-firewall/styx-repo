// Login form submit handler moved from tpl/default/login.tpl.php
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('login-form');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        try {
            if (window.showLoader) {
                window.showLoader(true);
            }
        } catch (err) {
            /* noop */
        }

        const username = form.username.value;
        const password = form.password.value;
        const realm = form.realm.value;

        const payload = {
            command: 'login',
            username: username,
            password: password,
            realm: realm
        };

        apiClient.submit('login', payload)
        .then(function (data) {
            const msgDiv = document.getElementById('login-message');

            if (data.status === 'success') {
                msgDiv.style.color = 'green';
                msgDiv.textContent = data.response_msg || 'Login correcto';

                try {
                    const currentUser = data.user || username;
                    if (window.localStorage && currentUser) {
                        localStorage.setItem('app:current_user', currentUser);
                    }
                } catch (err) {}

                try {
                    if (window.hideLoader) {
                        window.hideLoader();
                    }
                } catch (err) {
                    /* noop */
                }

                setTimeout(function () {
                    window.location.href = '?page=dashboard';
                }, 60);
            } else {
                msgDiv.style.color = 'red';
                msgDiv.textContent = data.response_msg || 'Login incorrecto';
                try {
                    if (window.hideLoader) {
                        window.hideLoader();
                    }
                } catch (err) {
                    /* noop */
                }
            }
        })
        .catch(function () {
            const msgDiv = document.getElementById('login-message');
            msgDiv.style.color = 'red';
            msgDiv.textContent = 'Error de red o servidor';
            try {
                if (window.hideLoader) {
                    window.hideLoader();
                }
            } catch (err) {
                /* noop */
            }
        });
    });
});
