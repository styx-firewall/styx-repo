/**
 * state-storage.js
 * Lightweight localStorage helper scoped per user and feature.
 * Key format: app:state:{username}:{scope}:{key}
 *
 * Globals exposed: saveState, loadState, clearState, setCurrentUser, clearCurrentUser
 */
(function () {
    const _USER_KEY = 'app:current_user';
    const _PREFIX = 'app:state:';

    let _stateUser = '';
    try {
        _stateUser = (window.localStorage && localStorage.getItem(_USER_KEY)) || '';
    } catch (e) {}

    function _key(scope, key) {
        const userPart = _stateUser ? _stateUser + ':' : '';
        return `${_PREFIX}${userPart}${scope}:${key}`;
    }

    function saveState(scope, key, value) {
        if (!window.localStorage) return;
        try {
            localStorage.setItem(_key(scope, key), JSON.stringify(value));
        } catch (e) {}
    }

    function loadState(scope, key, def) {
        if (def === undefined) { def = null; }
        if (!window.localStorage) return def;
        try {
            const raw = localStorage.getItem(_key(scope, key));
            return raw !== null ? JSON.parse(raw) : def;
        } catch (e) {
            return def;
        }
    }

    function clearState(scope) {
        if (!window.localStorage) return;
        const prefix = `${_PREFIX}${_stateUser ? _stateUser + ':' : ''}${scope}:`;
        Object.keys(localStorage)
            .filter(k => k.startsWith(prefix))
            .forEach(k => localStorage.removeItem(k));
    }

    function setCurrentUser(username) {
        _stateUser = username || '';
        try {
            if (window.localStorage) {
                localStorage.setItem(_USER_KEY, _stateUser);
            }
        } catch (e) {}
    }

    function clearCurrentUser() {
        _stateUser = '';
        try {
            if (window.localStorage) {
                localStorage.removeItem(_USER_KEY);
            }
        } catch (e) {}
    }

    window.saveState = saveState;
    window.loadState = loadState;
    window.clearState = clearState;
    window.setCurrentUser = setCurrentUser;
    window.clearCurrentUser = clearCurrentUser;
})();
