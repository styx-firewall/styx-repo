/**
 * Dashboard widgets-Muuri masonry + drag & drop + localStorage.
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'dashboard-widget-order';
    var container = document.getElementById('dashboard-grid');
    if (!container || typeof Muuri === 'undefined') return;

    function getCols() {
        var w = window.innerWidth;
        if (w >= 1260) return 3;
        if (w >= 860) return 2;
        return 1;
    }

    function syncWidths() {
        var cols = getCols();
        var w = Math.floor(container.offsetWidth / cols) - 10;
        var items = container.querySelectorAll('.std-grid-item-type1');
        for (var i = 0; i < items.length; i++) {
            items[i].style.width = w + 'px';
        }
    }

    // Persistence 
    function loadOrder() {
        try {
            var saved = localStorage.getItem(STORAGE_KEY);
            return saved ? JSON.parse(saved) : null;
        } catch (e) { return null; }
    }

    function saveOrder() {
        var ids = grid.getItems().map(function (item) {
            return item.getElement().dataset.widgetId;
        });
        localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
    }

    // Init 
    syncWidths();

    var grid = new Muuri(container, {
        items: '.std-grid-item-type1',
        dragEnabled: true,
        layout: {
            fillGaps: true,
            horizontal: false,
        },
    });

    // Restore saved order
    var order = loadOrder();
    if (order && order.length) {
        grid.sort(function (a, b) {
            var idA = a.getElement().dataset.widgetId;
            var idB = b.getElement().dataset.widgetId;
            return order.indexOf(idA) - order.indexOf(idB);
        });
        grid.layout();
    }

    grid.on('layoutEnd', saveOrder);

    // Re-layout after charts render (async fetches complete at staggered times)
    setTimeout(function () { grid.refreshItems().layout(); }, 3000);
    setTimeout(function () { grid.refreshItems().layout(); }, 5000);
    setTimeout(function () { grid.refreshItems().layout(); }, 8000);

    // Resize 
    var timer;
    window.addEventListener('resize', function () {
        clearTimeout(timer);
        timer = setTimeout(function () {
            syncWidths();
            grid.refreshItems().layout();
        }, 200);
    });
})();
