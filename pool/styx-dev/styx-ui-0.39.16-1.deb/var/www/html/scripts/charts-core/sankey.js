
function drawSankey(containerId, flows, options = {}) {
    if (!window.google || !window.google.charts) {
        console.error('Google Charts is not loaded');
        return;
    }
    const defaultOptions = {
        width: 520,
        height: 320,
        sankey: {
            link: { colorMode: 'gradient', colors: ['#007bff', '#17a2b8', '#ffc107', '#dc3545', '#28a745', '#6c757d'] },
            node: {
                colors: ['#007bff', '#17a2b8', '#ffc107', '#dc3545', '#28a745', '#6c757d'],
                label: {
                    fontSize: 13,
                    color: '#f8f9fa',
                    bold: true
                },
                labelPadding: 12,
                labelAlignment: 'start',
                nodePadding: 30
            }
        }
    };
    const chartOptions = Object.assign({}, defaultOptions, options);
    const data = new google.visualization.DataTable();
    data.addColumn('string', 'From');
    data.addColumn('string', 'To');
    data.addColumn('number', 'Packets');
    data.addRows(flows);
    const chart = new google.visualization.Sankey(document.getElementById(containerId));
    chart.draw(data, chartOptions);
}
window.drawSankey = drawSankey;
