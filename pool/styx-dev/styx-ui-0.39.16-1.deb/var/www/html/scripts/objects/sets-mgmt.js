window.addEventListener('DOMContentLoaded', function() {
    try { initUnifiedObjectForms(); } catch (e) { /* noop */ }
    try {
        if (document.getElementById('sets-tabs')) {
            initSetsTabs();
        }
    } catch (e) { /* noop */ }
    // root = undefined > page mode, filter state persisted to URL.
    initAddressFilters();
    initInterfaceFilters();
    initPortFilters();
    initTableTextFilter({ tableId: 'domain-set-table',  inputId: 'domain-filter',  nameClass: 'col-name', valueClass: 'col-value' });
    initTableTextFilter({ tableId: 'port-table',        inputId: 'port-filter',    nameClass: 'col-name', valueClass: 'col-value' });
    initTableTextFilter({ tableId: 'iface-set-table',   inputId: 'iface-filter',   nameClass: 'col-name', valueClass: 'col-value' });
    initTableTextFilter({ tableId: 'address-table',     inputId: 'address-filter', nameClass: 'col-name', valueClass: 'col-value' });
});
