	// DHCP GLOBAL CONFIG FORM SUBMIT
	// Submits the global DHCP server configuration
	const dhcpGlobalForm = document.getElementById('dhcp-global-form');
	if (dhcpGlobalForm) {
		dhcpGlobalForm.addEventListener('submit', function(e) {
			e.preventDefault();
			const formData = new FormData(dhcpGlobalForm);
			const config = {};
			const intFields = ['default_lease_time', 'max_lease_time', 'renew_timer', 'rebind_timer'];
			const setIdFields = ['global_dns_set_id', 'global_domain_set_id', 'global_domain_search_set_id'];
			formData.forEach((value, key) => {
				if (intFields.includes(key)) {
					config[key] = parseInt(value, 10) || 0;
				} else if (setIdFields.includes(key)) {
					config[key] = value !== '' ? value : null;
				} else {
					config[key] = value;
				}
			});
			config.command = 'set_dhcp_global_config';
			apiClient.submit(config.command, config)
			.then(result => {
				showApiResult(result, { closeText: 'Close', reloadOnOk: true });
			})
			.catch(err => {
				showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
			});
		});
	}
// Show/hide DHCP config and reservation forms based on switches
document.addEventListener('DOMContentLoaded', function () {
	// Initialize set-picker widgets (sets-mgmt-core.js is loaded before this script)
	window.setsModal.initPickerFields(document);
	// Update visible picker label, clear button and has-value class from a display object or string
	function setPickerLabel(id, display) {
		const el = document.getElementById(id);
		if (!el) return;
		const wrap = el.closest('.set-picker-field');
		if (!wrap) return;
		const lbl = wrap.querySelector('.js-set-picker-label');
		const clearBtn = wrap.querySelector('.js-set-picker-clear');
		const triggerBtn = wrap.querySelector('.set-picker-trigger');
		let text = '';
		if (display) {
			if (typeof display === 'object') {
				text = display.name || display.value || '';
			} else {
				text = String(display);
			}
		}
		if (lbl) lbl.textContent = text || wrap.querySelector('.js-set-picker-trigger')?.getAttribute('data-placeholder') || '';
		if (triggerBtn) {
			if (text) triggerBtn.classList.add('set-picker-trigger--has-value'); else triggerBtn.classList.remove('set-picker-trigger--has-value');
		}
		if (clearBtn) {
			if (text) clearBtn.classList.remove('sets-hidden'); else clearBtn.classList.add('sets-hidden');
		}
	}

	// Utility to set DHCP config form values
	function setDhcpConfigFormValues(config) {
		const dhcpv4Switch = document.getElementById('dhcpv4_enabled');
		const dhcpv6Switch = document.getElementById('dhcpv6_enabled');
		const leaseTime = document.getElementById('lease_time');
		const rangeSetId = document.getElementById('range_set_id');
		const gatewaySetId = document.getElementById('gateway_set_id');
		const dnsSetId = document.getElementById('dns_set_id');
		const domainSetId = document.getElementById('domain_set_id');
		const range6SetId = document.getElementById('range6_set_id');
		const gateway6SetId = document.getElementById('gateway6_set_id');
		const dns6SetId = document.getElementById('dns6_set_id');
		const domain6SetId = document.getElementById('domain6_set_id');
		if (dhcpv4Switch) dhcpv4Switch.checked = !!config.dhcpv4_enabled;
		if (dhcpv6Switch) dhcpv6Switch.checked = !!config.dhcpv6_enabled;
		if (leaseTime) leaseTime.value = config.lease_time || '';
		if (rangeSetId) rangeSetId.value = config.range_set_id || '';
		if (gatewaySetId) gatewaySetId.value = config.gateway_set_id || '';
		if (dnsSetId) dnsSetId.value = config.dns_set_id || '';
		if (domainSetId) domainSetId.value = config.domain_set_id || '';
		if (range6SetId) range6SetId.value = config.range6_set_id || '';
		if (gateway6SetId) gateway6SetId.value = config.gateway6_set_id || '';
		if (dns6SetId) dns6SetId.value = config.dns6_set_id || '';
		if (domain6SetId) domain6SetId.value = config.domain6_set_id || '';

		setPickerLabel('range_set_id', config.range_set_id_display || null);
		setPickerLabel('gateway_set_id', config.gateway_set_id_display || null);
		setPickerLabel('dns_set_id', config.dns_set_id_display || null);
		setPickerLabel('domain_set_id', config.domain_set_id_display || null);
		setPickerLabel('range6_set_id', config.range6_set_id_display || null);
		setPickerLabel('gateway6_set_id', config.gateway6_set_id_display || null);
		setPickerLabel('dns6_set_id', config.dns6_set_id_display || null);
		setPickerLabel('domain6_set_id', config.domain6_set_id_display || null);
	}

	// Utility to set reservations in hidden forms
	function setDhcpReservations(reservations, reservations6) {
		const resInput = document.getElementById('reservations-json');
		const res6Input = document.getElementById('reservations6-json');
		if (resInput) resInput.value = JSON.stringify(reservations || []);
		if (res6Input) res6Input.value = JSON.stringify(reservations6 || []);
	}

	// DHCP RESERVATIONS FORM (Generic for IPv4/IPv6)
	// Handles the table, button, and hidden field for DHCP reservations (IPv4 and IPv6)
	function setupReservationsBlock({
		addBtnId,
		tableId,
		jsonInputId,
		rowFields,
		emptyRow,
		removeBtnClass,
		inputClasses
	}) {
		const addBtn = document.getElementById(addBtnId);
		const table = document.getElementById(tableId);
		const jsonInput = document.getElementById(jsonInputId);
		let reservations = [];

		function renderTable() {
			if (!table) return;
			const tbody = table.querySelector('tbody');
			tbody.innerHTML = '';
			reservations.forEach((res, idx) => {
				const tr = document.createElement('tr');
				let rowHtml = '';
				rowFields.forEach((field, i) => {
					rowHtml += '<td><input type="text" class="input-text ' +
						inputClasses[i] +
						'" value="' + (res[field] || '') +
						'" placeholder="' + emptyRow[field] +
						'" style="width:98%"></td>';
				});
				rowHtml += `<td><button type="button" class="${removeBtnClass}" data-idx="${idx}" title="Remove">✖</button></td>`;
				tr.innerHTML = rowHtml;
				tbody.appendChild(tr);
			});
			if (jsonInput) {
				jsonInput.value = JSON.stringify(reservations);
			}
		}

		// Expose global object to manipulate reservations and render table
		window[tableId + '_block'] = {
			set: function(newReservations) {
				reservations = Array.isArray(newReservations) ? newReservations.slice() : [];
				renderTable();
			},
			renderTable: renderTable
		};

		if (addBtn && table) {
			addBtn.addEventListener('click', function() {
				reservations.push({ ...emptyRow });
				renderTable();
			});
			table.addEventListener('click', function(e) {
				if (e.target.classList.contains(removeBtnClass)) {
					const idx = parseInt(e.target.getAttribute('data-idx'));
					reservations.splice(idx, 1);
					renderTable();
				}
			});
			table.addEventListener('input', function(e) {
				const tr = e.target.closest('tr');
				if (!tr) return;
				const idx = Array.from(table.querySelectorAll('tbody tr')).indexOf(tr);
				if (idx < 0) return;
				rowFields.forEach((field, i) => {
					if (e.target.classList.contains(inputClasses[i])) {
						reservations[idx][field] = e.target.value;
					}
				});
				if (jsonInput) {
					jsonInput.value = JSON.stringify(reservations);
				}
			});
			renderTable();
		}
	}

	// Setup for IPv4 reservations
	setupReservationsBlock({
		addBtnId: 'add-reservation-btn',
		tableId: 'reservations-table',
		jsonInputId: 'reservations-json',
		rowFields: ['mac', 'ip'],
		emptyRow: { mac: '', ip: '' },
		removeBtnClass: 'remove-res-btn',
		inputClasses: ['mac-input', 'ip-input']
	});

	// Setup for IPv6 reservations
	setupReservationsBlock({
		addBtnId: 'add-reservation6-btn',
		tableId: 'reservations6-table',
		jsonInputId: 'reservations6-json',
		rowFields: ['duid', 'ipv6'],
		emptyRow: { duid: '', ipv6: '' },
		removeBtnClass: 'remove-res6-btn',
		inputClasses: ['duid-input', 'ipv6-input']
	});

	// DHCP CONFIG FORM SUBMIT (IPv4 + IPv6)
	// Submits the general DHCP server configuration, including both IPv4 and IPv6 fields
	const dhcpConfigForm = document.getElementById('dhcp-config-form');
	if (dhcpConfigForm) {
		dhcpConfigForm.addEventListener('submit', function(e) {
			e.preventDefault();
			const formData = new FormData(dhcpConfigForm);
			const config = {};
			const setIdFields = [
				'range_set_id', 'range6_set_id',
				'gateway_set_id', 'gateway6_set_id',
				'dns_set_id', 'dns6_set_id',
				'domain_set_id', 'domain6_set_id',
			];
			formData.forEach((value, key) => {
				if (setIdFields.includes(key)) {
					config[key] = value !== '' ? value : null;
				} else if (key === 'lease_time') {
					config[key] = parseInt(value, 10) || 0;
				} else if (key === 'dhcpv4_enabled' || key === 'dhcpv6_enabled') {
					config[key] = (value === '1' || value === 'true');
				} else {
					config[key] = value;
				}
			});
			config.command = 'set_dhcp_config';
			apiClient.submit(config.command, config)
			.then(result => {
				showApiResult(result, { closeText: 'Close', reloadOnOk: true });
			})
			.catch(err => {
				showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
			});
		});
	}

	// DHCP RESERVATIONS FORM SUBMIT (IPv4 + IPv6)
	// Submits DHCP reservations (both versions) to the backend
	const dhcpReservationsForm = document.getElementById('dhcp-reservations-form');
	if (dhcpReservationsForm) {
		dhcpReservationsForm.addEventListener('submit', function(e) {
			e.preventDefault();
			const formData = new FormData(dhcpReservationsForm);
			const config = {};
			formData.forEach((value, key) => {
				config[key] = value;
			});
			// Parse reservations and reservations6 as arrays, not strings
			const reservationsJson = document.getElementById('reservations-json');
			const reservations6Json = document.getElementById('reservations6-json');
			if (reservationsJson && reservationsJson.value) {
				try {
					config.reservations = JSON.parse(reservationsJson.value);
				} catch (e) {
					config.reservations = [];
				}
			}
			if (reservations6Json && reservations6Json.value) {
				try {
					config.reservations6 = JSON.parse(reservations6Json.value);
				} catch (e) {
					config.reservations6 = [];
				}
			}
			config.command = 'set_dhcp_reservations';
			apiClient.submit(config.command, config)
			.then(result => {
				showApiResult(result, { closeText: 'Close', reloadOnOk: true });
			})
			.catch(err => {
				showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
			});
		});
	}
	const dhcpv4Switch = document.getElementById('dhcpv4_enabled');
	const dhcpv6Switch = document.getElementById('dhcpv6_enabled');
	const configV4Block = document.getElementById('dhcpv4-config-block');
	const configV6Block = document.getElementById('dhcpv6-config-block');
	const reservationsForm = document.getElementById('dhcp-reservations-form');
	const reservationsV4Block = document.getElementById('reservations-v4-block');
	const reservationsV6Block = document.getElementById('reservations-v6-block');

	function updateDhcpSwitchesByIface() {
		const sel = document.getElementById('interface');
		const dhcpv4Switch = document.getElementById('dhcpv4_enabled');
		const dhcpv6Switch = document.getElementById('dhcpv6_enabled');
		// Feature flags from PHP
		const v4Feature = typeof window.dhcpv4FeatureEnabled !== 'undefined' ? window.dhcpv4FeatureEnabled : false;
		const v6Feature = typeof window.dhcpv6FeatureEnabled !== 'undefined' ? window.dhcpv6FeatureEnabled : false;
		if (!sel) return;
		const opt = sel.options[sel.selectedIndex];
		// If feature is not enabled, always disable the switch
		if (dhcpv4Switch) {
			if (!v4Feature) {
				dhcpv4Switch.disabled = true;
				dhcpv4Switch.checked = false;
			} else {
				if (!opt || !opt.value) {
					dhcpv4Switch.disabled = true;
					dhcpv4Switch.checked = false;
				} else {
					const hasV4 = !!(opt.getAttribute('data-ipv4'));
					dhcpv4Switch.disabled = !hasV4;
					if (!hasV4) dhcpv4Switch.checked = false;
				}
			}
		}
		if (dhcpv6Switch) {
			if (!v6Feature) {
				dhcpv6Switch.disabled = true;
				dhcpv6Switch.checked = false;
			} else {
				if (!opt || !opt.value) {
					dhcpv6Switch.disabled = true;
					dhcpv6Switch.checked = false;
				} else {
					const hasV6 = !!(opt.getAttribute('data-ipv6'));
					dhcpv6Switch.disabled = !hasV6;
					if (!hasV6) dhcpv6Switch.checked = false;
				}
			}
		// Update the iface-specific warning message
		if (typeof updateIfaceWarning === 'function') updateIfaceWarning();
		}
	}

	function updateIfaceInfoBlock() {
		const sel = document.getElementById('interface');
		const ipv4Span = document.querySelector('.iface-ipv4-value');
		const netmaskSpan = document.querySelector('.iface-netmask-value');
		const ipv6Span = document.querySelector('.iface-ipv6-value');
		const prefixSpan = document.querySelector('.iface-prefix-value');
		if (!sel || !ipv4Span || !netmaskSpan || !ipv6Span || !prefixSpan) return;
		const opt = sel.options[sel.selectedIndex];
		if (opt && opt.value) {
			ipv4Span.textContent = opt.getAttribute('data-ipv4') || '-';
			netmaskSpan.textContent = opt.getAttribute('data-netmask') || '-';
			ipv6Span.textContent = opt.getAttribute('data-ipv6') || '-';
			prefixSpan.textContent = opt.getAttribute('data-prefix') || '-';
		} else {
			ipv4Span.textContent = '-';
			netmaskSpan.textContent = '-';
			ipv6Span.textContent = '-';
			prefixSpan.textContent = '-';
		}
	}

	function updateIfaceWarning() {
		const sel = document.getElementById('interface');
		const warnDiv = document.getElementById('dhcp-iface-warning');
		if (!warnDiv) return;
		if (!sel || !sel.value) {
			warnDiv.style.display = 'none';
			warnDiv.textContent = '';
			return;
		}
		const opt = sel.options[sel.selectedIndex];
		const v4Feature = typeof window.dhcpv4FeatureEnabled !== 'undefined' ? window.dhcpv4FeatureEnabled : false;
		const v6Feature = typeof window.dhcpv6FeatureEnabled !== 'undefined' ? window.dhcpv6FeatureEnabled : false;
		const hasV4 = !!opt.getAttribute('data-ipv4');
		const hasV6 = !!opt.getAttribute('data-ipv6');
		const disabledV4 = !v4Feature || !hasV4;
		const disabledV6 = !v6Feature || !hasV6;

		// If neither version is disabled, hide the warning
		if (!disabledV4 && !disabledV6) {
			warnDiv.style.display = 'none';
			warnDiv.textContent = '';
			return;
		}

		// Build clearer, version-specific messages
		if (disabledV4 && disabledV6) {
			const reason4 = !v4Feature ? 'feature disabled globally' : 'interface has no IPv4 address';
			const reason6 = !v6Feature ? 'feature disabled globally' : 'interface has no IPv6 address';
			warnDiv.textContent = 'Cannot enable DHCP on this interface: DHCPv4: ' + reason4 + '; DHCPv6: ' + reason6;
		} else if (disabledV4) {
			const reason4 = !v4Feature ? 'feature disabled globally' : 'interface has no IPv4 address';
			warnDiv.textContent = 'DHCPv4 cannot be enabled on this interface: ' + reason4;
		} else {
			const reason6 = !v6Feature ? 'feature disabled globally' : 'interface has no IPv6 address';
			warnDiv.textContent = 'DHCPv6 cannot be enabled on this interface: ' + reason6;
		}
		warnDiv.style.display = '';
	}

	// Interface selector logic
	const interfaceSelector = document.getElementById('interface');
	const configHidden = document.getElementById('dhcp-config-interface-id');
	const reservationsHidden = document.getElementById('dhcp-reservations-interface-id');


	function updateFormsVisibilityByInterface() {
		// Hide forms if no interface is selected
		const hasIface = interfaceSelector && interfaceSelector.value;
		const configForm = document.getElementById('dhcp-config-form');
		const reservationsForm = document.getElementById('dhcp-reservations-form');
		if (configForm) configForm.style.display = hasIface ? '' : 'none';
		// Reservations only if there is an interface AND at least one switch is active
		const dhcp4on = dhcpv4Switch && dhcpv4Switch.checked;
		const dhcp6on = dhcpv6Switch && dhcpv6Switch.checked;
		if (reservationsForm) {
			reservationsForm.style.display = (hasIface && (dhcp4on || dhcp6on)) ? '' : 'none';
		}
		updateIfaceInfoBlock();
	}

	function updateHiddenInterfaceId() {
		if (interfaceSelector) {
			const selectedId = interfaceSelector.value;
			if (configHidden) configHidden.value = selectedId;
			if (reservationsHidden) reservationsHidden.value = selectedId;
		}
		updateFormsVisibilityByInterface();
		updateDhcpSwitchesByIface();
		if (typeof updateIfaceWarning === 'function') updateIfaceWarning();
	}

	if (interfaceSelector) {
		interfaceSelector.addEventListener('change', function() {
			updateHiddenInterfaceId();
			updateDhcpSwitchesByIface();
			// Get config from the selected interface
			const ifaceId = interfaceSelector.value;
			let config = {};
			let reservations = [];
			let reservations6 = [];
			// dhcp_config is a global PHP variable, injected by the template
			if (typeof window.dhcp_config !== 'undefined' && ifaceId && window.dhcp_config[ifaceId]) {
				const entry = window.dhcp_config[ifaceId];
				config = entry.config || {};
				reservations = entry.reservations || [];
				reservations6 = entry.reservations6 || [];
			}
			setDhcpConfigFormValues(config);
			setDhcpReservations(reservations, reservations6);
			// Update reservation arrays and visual tables using the global object
			if (window['reservations-table_block']) {
				window['reservations-table_block'].set(reservations);
			}
			if (window['reservations6-table_block']) {
				window['reservations6-table_block'].set(reservations6);
			}
			// Force update of form visibility if switches changed by JS
			updateFormsVisibility();
			if (typeof updateIfaceWarning === 'function') updateIfaceWarning();
		});
		// Initialize on load
		updateHiddenInterfaceId();
		updateIfaceInfoBlock();
		updateDhcpSwitchesByIface();
		if (typeof updateIfaceWarning === 'function') updateIfaceWarning();
		// Initialize form values according to the selected interface
		setTimeout(() => {
			const ifaceId = interfaceSelector.value;
			let config = {};
			let reservations = [];
			let reservations6 = [];
			if (typeof window.dhcp_config !== 'undefined' && ifaceId && window.dhcp_config[ifaceId]) {
				const entry = window.dhcp_config[ifaceId];
				config = entry.config || {};
				reservations = entry.reservations || [];
				reservations6 = entry.reservations6 || [];
			}
			setDhcpConfigFormValues(config);
			setDhcpReservations(reservations, reservations6);
			if (window['reservations-table_block']) {
				window['reservations-table_block'].set(reservations);
			}
			if (window['reservations6-table_block']) {
				window['reservations6-table_block'].set(reservations6);
			}
			updateFormsVisibility();
			if (typeof updateIfaceWarning === 'function') updateIfaceWarning();
		}, 0);
	}

	function updateFormsVisibility() {
		// Show/hide IPv4 config block
		if (configV4Block) {
			configV4Block.style.display = (dhcpv4Switch && dhcpv4Switch.checked) ? '' : 'none';
		}
		// Show/hide IPv6 config block
		if (configV6Block) {
			configV6Block.style.display = (dhcpv6Switch && dhcpv6Switch.checked) ? '' : 'none';
		}

		// Show/hide reservations v4 block
		if (reservationsV4Block) {
			reservationsV4Block.style.display = (dhcpv4Switch && dhcpv4Switch.checked) ? '' : 'none';
		}
		// Show/hide reservations v6 block
		if (reservationsV6Block) {
			reservationsV6Block.style.display = (dhcpv6Switch && dhcpv6Switch.checked) ? '' : 'none';
		}

		// Show/hide the whole reservations form if neither block is visible
		if (reservationsForm) {
			if ((dhcpv4Switch && dhcpv4Switch.checked) || (dhcpv6Switch && dhcpv6Switch.checked)) {
				reservationsForm.style.display = '';
			} else {
				reservationsForm.style.display = 'none';
			}
		}
	}

	if (dhcpv4Switch) dhcpv4Switch.addEventListener('change', updateFormsVisibility);
	if (dhcpv6Switch) dhcpv6Switch.addEventListener('change', updateFormsVisibility);


	// Initial state
	updateFormsVisibility();
});
