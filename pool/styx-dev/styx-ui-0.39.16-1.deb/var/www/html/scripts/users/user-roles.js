/**
 * User Roles management.
 * Handles role assignment and removal via submit.php.
 *
 * Requires: common.js (api-client)
 */

document.addEventListener('DOMContentLoaded', () => {
    document.addEventListener('click', (e) => {
        const saveBtn = e.target.closest('[data-js="save-role"]');
        const removeBtn = e.target.closest('[data-js="remove-role"]');

        if (saveBtn) {
            e.preventDefault();
            const username = saveBtn.dataset.username;
            const select = document.querySelector(
                `[data-js="role-select"][data-username="${username}"]`
            );
            if (!select) {
                return;
            }
            const role = select.value;
            if (!role) {
                alert('Please select a role');
                return;
            }
            window.apiClient.submit('set_role', { username, role })
                .then((resp) => {
                    if (resp.status === 'error') {
                        alert(resp.response_msg || 'Error saving role');
                        return;
                    }
                    location.reload();
                })
                .catch((err) => {
                    alert('Request failed: ' + err);
                });
        }

        if (removeBtn) {
            e.preventDefault();
            const username = removeBtn.dataset.username;
            if (!confirm(`Remove role from ${username}?`)) {
                return;
            }
            window.apiClient.submit('remove_role', { username })
                .then((resp) => {
                    if (resp.status === 'error') {
                        alert(resp.response_msg || 'Error removing role');
                        return;
                    }
                    location.reload();
                })
                .catch((err) => {
                    alert('Request failed: ' + err);
                });
        }
    });
});
