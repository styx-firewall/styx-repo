// User Profile Settings Module
// Handles saving per-user timezone, locale and debug preferences.

(function () {
    'use strict';

    const form     = document.getElementById('userProfileForm');
    const feedback = document.getElementById('profileFormFeedback');


    if (!form) {
        return;
    }

    function showFeedback(msg, isError) {
        if (!feedback) return;
        feedback.textContent = msg;
        feedback.className   = 'form-feedback ' + (isError ? 'form-feedback-error' : 'form-feedback-success');
        feedback.hidden      = false;
    }

    function hideFeedback() {
        if (!feedback) return;
        feedback.hidden = true;
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        hideFeedback();

        const timezoneSelect = document.getElementById('profileTimezoneSelect');
        const localeSelect   = document.getElementById('profileLocaleSelect');
        const debugCheck     = document.getElementById('profileDebugCheck');

        const payload = {
            timezone : timezoneSelect ? timezoneSelect.value : '',
            locale   : localeSelect ? localeSelect.value : '',
            debug    : debugCheck ? debugCheck.checked : false,
        };

        window.apiClient.submit('save_profile', payload)
            .then(function (data) {
                if (data.status === 'success') {
                    showFeedback('Preferences saved. Reloading...', false);
                    setTimeout(function () {
                        window.location.reload();
                    }, 800);
                } else {
                    showFeedback('Error: ' + (data.response_msg || 'Unknown error'), true);
                }
            })
            .catch(function (err) {
                showFeedback('Request failed: ' + err.message, true);
            });
    });

}());
