// Bearer Tokens Management Module
// Manages API tokens for external integrations

(function() {
    // Generate new token
    function generateToken() {
        var tmpl = document.getElementById('tmpl-generate-token');
        if (!tmpl) return;
        var frag = tmpl.content.cloneNode(true);
        showModal(frag);

        setTimeout(function () {
            var form = document.getElementById('generateTokenForm');
            if (!form) return;

            form.onsubmit = function (e) {
                e.preventDefault();
                var name = form.name.value.trim();
                var expiresAt = form.expires_at.value || null;

                if (expiresAt) {
                    expiresAt = expiresAt + 'T00:00:00Z';
                }

                if (!name) {
                    alert('Token name is required');
                    return;
                }

                window.apiClient.submit('generate_bearer_token', {
                    name: name,
                    expires_at: expiresAt
                })
                .then(function (data) {
                    if (data.status === 'success' && data.result && data.result.token) {
                        hideModal();
                        showTokenResult(data.result.token, name);
                    } else {
                        showApiResult(data, { title: 'Error', closeText: 'Close' });
                    }
                })
                .catch(function (error) {
                    appLog.error('Error generating token:', error);
                    showApiResult({ status: 'error', response_msg: 'Network error generating token' },
                        { title: 'Error', closeText: 'Close' });
                });
            };
        }, 100);
    }

    // Show token result (only time the full token is shown)
    function showTokenResult(token, name) {
        var tmpl = document.getElementById('tmpl-token-result');
        if (!tmpl) return;
        var frag = tmpl.content.cloneNode(true);

        var nameEl = frag.querySelector('[data-js="result-name"]');
        var tokenEl = frag.querySelector('[data-js="result-token"]');
        if (nameEl) nameEl.textContent = name;
        if (tokenEl) tokenEl.textContent = token;

        showModal(frag);

        setTimeout(function () {
            var copyBtn = document.getElementById('copyTokenBtn');
            var closeBtn = document.getElementById('closeTokenResultBtn');

            if (copyBtn) {
                copyBtn.onclick = function () {
                    if (navigator.clipboard) {
                        navigator.clipboard.writeText(token).then(function () {
                            copyBtn.textContent = '✓ Copied!';
                            copyBtn.style.background = '#4caf50';
                            setTimeout(function () {
                                copyBtn.textContent = 'Copy to Clipboard';
                                copyBtn.style.background = '';
                            }, 2000);
                        }).catch(function (err) {
                            appLog.error('Copy failed:', err);
                            alert('Failed to copy to clipboard');
                        });
                    } else {
                        var textArea = document.createElement('textarea');
                        textArea.value = token;
                        document.body.appendChild(textArea);
                        textArea.select();
                        try {
                            document.execCommand('copy');
                            copyBtn.textContent = '✓ Copied!';
                            copyBtn.style.background = '#4caf50';
                        } catch (err) {
                            alert('Failed to copy to clipboard');
                        }
                        document.body.removeChild(textArea);
                    }
                };
            }

            if (closeBtn) {
                closeBtn.onclick = function () {
                    hideModal();
                    window.location.reload();
                };
            }
        }, 100);
    }

    // Revoke token
    function revokeToken(tokenId, tokenName) {
        if (!confirm(
            'Are you sure you want to revoke token "' + tokenName + '"?\n\n'
            + 'This action cannot be undone and any scripts using this token will stop working.'
        )) {
            return;
        }

        window.apiClient.submit('revoke_bearer_token', { token_id: tokenId })
        .then(data => {
            if (data.status === 'success') {
                appLog('Token revoked successfully');
                // Reload page to refresh token list
                window.location.reload();
            } else {
                showApiResult(data, { title: 'Error', closeText: 'Close' });
            }
        })
        .catch(error => {
            appLog.error('Error revoking token:', error);
            showApiResult({ status: 'error', response_msg: 'Network error revoking token' }, { title: 'Error', closeText: 'Close' });
        });
    }

    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        const generateBtn = document.getElementById('generateTokenBtn');
        if (generateBtn) {
            generateBtn.onclick = generateToken;
        }

        // Attach event listeners to revoke buttons (tokens are pre-rendered from PHP)
        document.querySelectorAll('.js-revoke-token').forEach(btn => {
            btn.onclick = function() {
                const tokenId = this.getAttribute('data-token-id');
                const tokenName = this.getAttribute('data-token-name');
                revokeToken(tokenId, tokenName);
            };
        });
    });

})();
