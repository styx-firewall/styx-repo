/**
 * Update the tasks table with the latest task data.
 *
 * The backend returns a mapping of task id -> task object in most cases,
 * but the handler may return an empty array on error. The frontend should
 * accept both an object mapping and an empty array.
 *
 * Top-level mapping (typical):
 * {
 *   "<task-id>": { <task-object> },
 *   ...
 * }
 *
 * Task object (observed fields):
 * - status: string
 *     Overall task state at task level (e.g. "pending", "done", "error").
 * - result: null | object | array | string
 *     - null: no result yet (in-progress)
 *     - object: result payload (see examples below)
 *     - array: shorthand list of subtasks (array of subtask objects)
 *     - string: error message string (backend may store str(e))
 * - started_at: ISO8601 string | null
 * - finished_at: ISO8601 string | null
 * - command: string | null
 * - args: array (serialized)
 * - kwargs: object (serialized)
 * - func: string
 * - desc: string
 * - main_arg: string | null
 *
 * Result object variants observed:
 * 1) Service-style result (example from feature/package tasks):
 *    {
 *      "status": "success" | "error",
 *      "command": "<main command>",
 *      "response_msg": "User-readable message",
 *      "data": { "stdout": "...", "stderr": "..." }?,
 *      "packages": [ <subtask>, ... ]?
 *    }
 *    - `packages` is an array of subtask objects with fields like
 *      `package`, `command`, `status`, `stdout`, `stderr`, `response_msg`.
 *
 * 2) Subprocess-style result (from RB.subprocess_response / SubprocessHelper):
 *    {
 *      "status": "success" | "error",
 *      "stdout": "...",
 *      "stderr": "...",
 *      "returncode": int,
 *      "msg": "..."
 *    }
 *    - Note: uses `msg` instead of `response_msg`.
 *
 * 3) Simple list-of-subtasks:
 *    - `result` may be an array of subtask objects (same shape as `packages`).
 *
 * Subtask object (used in `result` array or `result.packages`):
 * - package?: string
 * - command?: string
 * - status?: string ("success" | "error" etc.)
 * - response_msg?: string
 * - stdout?: string
 * - stderr?: string
 *
 * Frontend display rules / fallbacks (recommended):
 * - Prefer `result.status` then fallback to `task.status`.
 * - Prefer `result.command` then fallback to `task.command`.
 * - Prefer `result.response_msg` then `result.msg` then a top-level `response_msg` if present.
 * - For stdout/stderr:
 *     1. If `result` is an array or `result.packages` exists, use each subtask's `stdout`/`stderr`.
 *     2. Else look for `result.stdout` / `result.stderr`.
 *     3. Else look for `result.stdout` / `result.stderr`.
 * - Accept `result` being a string (error) and display it as a message.
 * - Accept `tasks` being an empty array (backend error case).
 *
 * Serialization notes:
 * - `args` and `kwargs` are serialized to JSON-friendly values. Non-serializable
 *   objects are converted to a placeholder like "<ClassName>".
 *
 * Examples
 * -------
 * Top-level response containing tasks (handler returns via RB.command_response):
 * {
 *   "status": "success",
 *   "command": "ping",
 *   "response_msg": "pong",
 *   "data": {
 *     "tasks": {
 *       "550e8400-e29b-41d4-a716-446655440000": {
 *         "status": "pending",
 *         "result": null,
 *         "started_at": "2026-02-26T12:00:00.000000",
 *         "finished_at": null,
 *         "command": "do-something",
 *         "args": ["target1"],
 *         "kwargs": {},
 *         "func": "do_something",
 *         "desc": "Task 'do-something' (target1)",
 *         "main_arg": "target1"
 *       }
 *     }
 *   }
 * }
 *
 * Example result with packages (from StyxFeatures._handle_option_packages):
 * {
 *   "status": "success",
 *   "command": "apt-get install -y pkg",
 *   "response_msg": "All packages installed",
 *   "packages": [
 *     { "package": "pkg", "command": "apt-get install -y pkg", "status": "success",
 *       "stdout": "...", "stderr": "", "response_msg": "Package installed: pkg" }
 *   ]
 * }
 *
 * Example subprocess-style result:
 * {
 *   "status": "error",
 *   "stdout": "",
 *   "stderr": "some failure",
 *   "returncode": 1,
 *   "msg": "Command failed"
 * }
 *
 * @param {Object|Array} tasks - Mapping of task ID -> task object, or an empty
 *                              array when the backend failed to retrieve tasks.
 */ 
/**
 * Parse task result into a normalized structure.
 * Handles array results, packages arrays, and plain objects.
 */
function parseTaskResult(task) {
    const result = task?.result || {};
    const isArray = Array.isArray(result);
    const isPackages = !isArray && Array.isArray(result.packages);
    const subtasks = isArray ? result : (isPackages ? result.packages : null);
    const forRow = isArray ? (result[0] || {}) : (isPackages ? (result.packages[0] || {}) : result);
    return { result, subtasks, forRow };
}

function formatTime(t) {
    if (!t) return '';
    const match = t.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/);
    return match ? match[0].replace('T', ' ') : t;
}

function createCell(val, className) {
    const td = document.createElement('td');
    if (className) td.className = className;
    if (val instanceof Node) {
        td.appendChild(val);
    } else {
        td.textContent = val ?? '';
    }
    return td;
}

// Shared modal options for task modals
const TASK_MODAL_OPTS = {
    modalClass: 'tasks-modal-overlay',
    boxClass: 'tasks-modal-box',
    contentClass: 'tasks-modal-content'
};

export function updateTasks(tasks) {
    if (!tasks || typeof tasks !== 'object') return;
    const tbody = document.getElementById('tasks-tbody');
    if (!tbody) return;

    // Keep a reference to the latest tasks so delegated handler can access them
    tbody._currentTasks = tasks;

    // Add a single delegated click handler to open modals for stdout/stderr/details.
    // The handler reads the latest tasks from `tbody._currentTasks` so it works
    // across multiple `updateTasks` invocations without reattaching listeners.
    if (!tbody._tasksDelegateAdded) {
        tbody.addEventListener('click', function (ev) {
            const btn = ev.target.closest('button');
            if (!btn) return;
            const tr = btn.closest('tr');
            if (!tr) return;
            const id = tr.getAttribute('data-task-id');
            const current = tbody._currentTasks || {};
            const task = current[id];
            if (!task) return;

            const { subtasks, forRow: resultForRow } = parseTaskResult(task);

            function buildContentForStd(isStdout) {
                const field = isStdout ? 'stdout' : 'stderr';
                const cls = 'task-pre task-pre-' + field;
                const frag = document.createDocumentFragment();
                if (subtasks) {
                    subtasks.forEach((sub, idx) => {
                        if (sub[field] && sub[field].trim().length > 0) {
                            const b = document.createElement('b');
                            b.textContent = sub.package || sub.command || ('Subtask ' + (idx + 1));
                            frag.appendChild(b);
                            frag.appendChild(document.createElement('br'));
                            const pre = document.createElement('pre');
                            pre.className = cls;
                            pre.textContent = sub[field];
                            frag.appendChild(pre);
                        }
                    });
                } else {
                    const pre = document.createElement('pre');
                    pre.className = cls;
                    pre.textContent = resultForRow[field] || '';
                    frag.appendChild(pre);
                }
                return frag;
            }

            function buildSubtasksContent() {
                const wrapper = document.createElement('div');
                wrapper.className = 'task-subtasks-wrapper';
                // Add task-level metadata: command/func/desc/main_arg/args/kwargs
                const meta = document.createElement('div');
                meta.className = 'task-meta';
                const metaList = document.createElement('div');
                metaList.className = 'task-meta-list';
                const metaPairs = [
                    ['Command', resultForRow.command ?? task.command],
                    ['Func', resultForRow.func ?? task.func],
                    ['Desc', task.desc ?? resultForRow.desc],
                    ['Main arg', task.main_arg ?? ''],
                ];
                metaPairs.forEach(([k, v]) => {
                    if (v !== undefined && v !== null && String(v).length > 0) {
                        const row = document.createElement('div');
                        row.className = 'task-meta-row';
                        const key = document.createElement('b');
                        key.textContent = k + ': ';
                        row.appendChild(key);
                        const span = document.createElement('span');
                        span.textContent = String(v);
                        row.appendChild(span);
                        metaList.appendChild(row);
                    }
                });
                // args and kwargs (pretty-print if present)
                if (task && Array.isArray(task.args) && task.args.length > 0) {
                    const ar = document.createElement('div');
                    ar.className = 'task-meta-row';
                    const key = document.createElement('b');
                    key.textContent = 'Args: ';
                    ar.appendChild(key);
                    const pre = document.createElement('pre');
                    pre.className = 'task-meta-pre';
                    try { pre.textContent = JSON.stringify(task.args, null, 2); } catch (e) { pre.textContent = String(task.args); }
                    ar.appendChild(pre);
                    metaList.appendChild(ar);
                }
                if (task && task.kwargs && Object.keys(task.kwargs).length > 0) {
                    const kr = document.createElement('div');
                    kr.className = 'task-meta-row';
                    const key = document.createElement('b');
                    key.textContent = 'Kwargs: ';
                    kr.appendChild(key);
                    const pre = document.createElement('pre');
                    pre.className = 'task-meta-pre';
                    try { pre.textContent = JSON.stringify(task.kwargs, null, 2); } catch (e) { pre.textContent = String(task.kwargs); }
                    kr.appendChild(pre);
                    metaList.appendChild(kr);
                }
                meta.appendChild(metaList);
                wrapper.appendChild(meta);

                if (subtasks) {
                    subtasks.forEach((sub, idx) => {
                        const block = document.createElement('div');
                        block.className = 'task-subtask';
                        const b = document.createElement('b');
                        b.textContent = sub.package || sub.command || ('Subtask ' + (idx + 1));
                        block.appendChild(b);
                        block.appendChild(document.createElement('br'));
                        const statusSpan = document.createElement('span');
                        statusSpan.textContent = 'Status: ' + (sub.status || '');
                        block.appendChild(statusSpan);
                        block.appendChild(document.createElement('br'));
                        const msgSpan = document.createElement('span');
                        msgSpan.textContent = 'Message: ' + (sub.response_msg || '');
                        block.appendChild(msgSpan);
                        block.appendChild(document.createElement('br'));
                        if (sub.stdout && sub.stdout.trim().length > 0) {
                            const details = document.createElement('details');
                            const summary = document.createElement('summary');
                            summary.textContent = 'Stdout';
                            details.appendChild(summary);
                            const pre = document.createElement('pre');
                            pre.className = 'task-pre task-pre-stdout';
                            pre.textContent = sub.stdout;
                            details.appendChild(pre);
                            block.appendChild(details);
                        }
                        if (sub.stderr && sub.stderr.trim().length > 0) {
                            const details = document.createElement('details');
                            const summary = document.createElement('summary');
                            summary.textContent = 'Stderr';
                            details.appendChild(summary);
                            const pre = document.createElement('pre');
                            pre.className = 'task-pre task-pre-stderr';
                            pre.textContent = sub.stderr;
                            details.appendChild(pre);
                            block.appendChild(details);
                        }
                        wrapper.appendChild(block);
                    });
                }
                return wrapper;
            }

            if (btn.classList.contains('show-stdout-btn')) {
                window.showModal(buildContentForStd(true), { ...TASK_MODAL_OPTS, title: 'Stdout' });
            } else if (btn.classList.contains('show-stderr-btn')) {
                window.showModal(buildContentForStd(false), { ...TASK_MODAL_OPTS, title: 'Stderr' });
            } else if (btn.classList.contains('show-subtasks-btn')) {
                window.showModal(buildSubtasksContent(), { ...TASK_MODAL_OPTS, title: 'Subtasks' });
            }
        });
        tbody._tasksDelegateAdded = true;
    }

    for (const [id, rawTask] of Object.entries(tasks)) {
        // Some backends wrap the task payload in `task_info`.
        // Normalize so `task` always refers to the real task object.
        const task = rawTask?.task_info ?? rawTask;
        if (!task || typeof task !== 'object') continue;

        let row = tbody.querySelector(`tr[data-task-id="${id}"]`);
        const { subtasks, forRow: resultForRow } = parseTaskResult(task);

        // Check for any stdout/stderr in any subtask if array, else use resultForRow
        let hasStdout = false, hasStderr = false;
        if (subtasks) {
            hasStdout = subtasks.some(sub => sub.stdout && sub.stdout.trim().length > 0);
            hasStderr = subtasks.some(sub => sub.stderr && sub.stderr.trim().length > 0);
        } else {
            hasStdout = resultForRow.stdout && resultForRow.stdout.trim().length > 0;
            hasStderr = resultForRow.stderr && resultForRow.stderr.trim().length > 0;
        }

        // Separate columns for `func` and `command`. If both are absent show `desc`.
        const commandText = resultForRow.command || task.command || '';
        const commandCell = createCell(commandText, 'task-td');

        const funcVal = resultForRow.func || task.func || '';
        const funcCell = createCell(funcVal, 'task-td');

        // If neither command nor func present, fall back to desc in the command cell
        if (!commandText && !funcVal) {
            const descVal = task.desc || resultForRow.desc || '';
            if (descVal) commandCell.textContent = descVal;
        }

        // Tooltip: include main_arg for quick debugging on func cell
        const mainArg = task.main_arg ?? task.args?.[0] ?? '';
        if (mainArg) funcCell.title = 'main: ' + mainArg;
        // Prefer lifecycle status from the task object (e.g. 'pending'/'done').
        // Do NOT use `result.status` to determine lifecycle: that field reflects
        // the command/send outcome and may be `success` even if the task failed.
        // If `task.status` is missing, show 'unknown' as a clear fallback.
        const lifecycleStatus = (typeof task.status === 'string' && task.status.trim().length > 0) ? task.status : 'unknown';
        const statusCell = createCell(lifecycleStatus, 'task-td');
        if (typeof resultForRow.status === 'string') {
            statusCell.title = 'result: ' + resultForRow.status;
        }
        const startedCell = createCell(formatTime(task.started_at ?? task.created_at ?? ''), 'task-td');
        const finishedCell = createCell(formatTime(task.finished_at ?? ''), 'task-td');

        // ID: show abbreviated in-cell but full ID in title for accessibility
        const idShort = (typeof id === 'string' && id.length > 10) ? (id.slice(0, 8) + '...') : (id ?? '');
        const idSpan = document.createElement('span');
        idSpan.className = 'task-id-small';
        idSpan.textContent = idShort;
        if (id) idSpan.title = id;
        const idCell = createCell(idSpan, 'task-td');

        const infoCell = document.createElement('td');
        infoCell.className = 'task-td';
        infoCell.textContent = (resultForRow.response_msg ?? task.response_msg ?? '');

        if (hasStdout) {
            const b = document.createElement('button');
            b.className = 'task-btn show-stdout-btn stdout';
            b.type = 'button';
            b.textContent = 'Stdout';
            infoCell.appendChild(b);
        }
        if (hasStderr) {
            const b = document.createElement('button');
            b.className = 'task-btn show-stderr-btn stderr';
            b.type = 'button';
            b.textContent = 'Stderr';
            infoCell.appendChild(b);
        }
        // Always provide a Details button so metadata (func/args/kwargs) is visible
        const b = document.createElement('button');
        b.className = 'task-btn show-subtasks-btn details';
        b.type = 'button';
        b.textContent = 'Details';
        infoCell.appendChild(b);

        if (!row) {
            row = document.createElement('tr');
            row.setAttribute('data-task-id', id);
            tbody.appendChild(row);
        } else {
            row.replaceChildren();
        }
        // Order: func, command, status, started, finished, id, info
        row.append(funcCell, commandCell, statusCell, startedCell, finishedCell, idCell, infoCell);
    }
    // Auto-scroll to bottom
    const panelScroll = document.getElementById('panel-scroll');
    if (panelScroll) {
        panelScroll.scrollTop = panelScroll.scrollHeight;
        const maxHeight = parseInt(panelScroll.style.maxHeight) || 0;
        if (typeof window.recalcularOffsetPanel === 'function' && maxHeight <= 60) {
            window.recalcularOffsetPanel();
        }
    }
}