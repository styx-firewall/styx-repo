import { refreshCommandHandlers } from './refreshCommandHandlers.js';
import { getUrlParams } from './utils.js';
import { updateGatewayLed } from './gatewayLed.js';
let firstRefresh = true;

export function sendRefreshRequest() {
    const params = getUrlParams();
    const payload = {
        action: 'refresh',
        page: params.page || 'dashboard',
        section: params.section || '',
        commands: [],
        firstRefresh,

        client_timestamp: Date.now() / 1000
    };
    // Include last_task_id if present
    if (window.lastTaskId) {
        payload.last_task_id = window.lastTaskId;
    }
    // Include pending task IDs if present
    if (
        window.pendingTaskIds &&
        Array.isArray(window.pendingTaskIds) &&
        window.pendingTaskIds.length > 0
    ) {
        payload.pending_task_ids = window.pendingTaskIds;
    }
    appLog('sendRefreshRequest payload:', JSON.stringify(payload));
    if (params.action === 'create') {
        payload.create = true;
    }
    if (params.action === 'modify') {
        payload.modify = true;
    }
    // Include lastSystemLogId if present and we are on a logs page
    if (
        (
            params.page === 'logs' ||
            params.section === 'logs-system' ||
            params.section === 'sys-logs'
        ) &&
        window.lastSystemLogId
    ) {
        payload.last_id = window.lastSystemLogId;
    }
    //console.log('Sending refresh request:', payload);

    apiClient.request('refresh', payload)
    .then(async data => {
        appLog('Refresh Response:', data);

        const showRefreshErrors = (commands) => {
            if (!Array.isArray(commands)) return;
            // Exclude ping errors-those are handled silently via the gateway LED
            const errs = commands.filter(
                c => c && c.status === 'error' && c.command !== 'ping'
            );
            if (!errs.length) return;

            const msgs = errs.map(c => {
                const label = c.command ? `${c.command}: ` : '';
                return label + (c.response_msg || JSON.stringify(c));
            });

            const htmlItems = msgs.map(m => `<div style="margin-bottom:6px">${m}</div>`);
            const html = `<div style="color:#b00">\n${htmlItems.join('\n')}\n</div>`;

            if (typeof window.showModal === 'function') {
                try {
                    window.showModal(
                        html,
                        {
                            title: 'Refresh error',
                            closeText: 'OK',
                            modalStyle: { zIndex: '99999' }
                        }
                    );
                } catch (e) {
                    console.error('showModal failed', e);
                }
            } else {
                console.error('Refresh errors:', errs);
                try { alert(msgs.join('\n\n')); } catch (e) { /* ignore */ }
            }
        };

        showRefreshErrors(data.commands);
        // If backend indicates unauthorized via top-level response, redirect to logout
        if (
            data &&
            data.status === 'error' &&
            typeof data.response_msg === 'string' &&
            data.response_msg.toLowerCase().indexOf('unauthor') !== -1
        ) {
            window.location.href = '/?page=logout';
            return;
        }
        if (
            Array.isArray(data.commands) &&
            data.commands.length > 0 &&
            data.commands[0]['token_error'] === 1
        ) {
            window.location.href = '/?page=logout';
            return;
        }
        let commands = data.commands;
        let pingOk = false;

        if (Array.isArray(commands) && commands.length > 0) {
            const pingCommand = commands.find(cmd =>
                cmd.method === 'gateway-daemon.ping' && cmd.status === 'success' && cmd.id === 'ping'
            );

            if (pingCommand) {
                pingCommand.metadata = data.metadata || {};
                pingOk = true;
                // Execute ping first (if needed)
                for (const fn of refreshCommandHandlers) {
                    if (typeof fn === 'function') await fn(pingCommand);
                }
            }
            for (const cmd of commands) {
                if (cmd === pingCommand) continue;
                cmd.metadata = data.metadata || {};
                for (const fn of refreshCommandHandlers) {
                    if (typeof fn === 'function') await fn(cmd);
                }
            }
        } else {
            // If the response is empty something failed, set the LED to red
            updateGatewayLed(null);
        }
        // If there were commands but none was a successful ping, force the LED to red
        if (!pingOk) {
            updateGatewayLed(null);
        }
        document.dispatchEvent(new CustomEvent('refreshResponse', { detail: data }));
    })
    .catch(err => {
        // Connection errors are handled internally by _postJson (api-client.js).
        // This .catch only fires for unexpected handler bugs.
        updateGatewayLed(null);
        console.error('Refresh handler error:', err);
    });

    firstRefresh = false;
}
