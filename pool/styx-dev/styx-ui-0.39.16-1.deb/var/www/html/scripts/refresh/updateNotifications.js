/**
 * Updates the notification bell and dropdown in the header.
 * @param {Array<Object>} notifications - Array of notification objects
 */
export function updateNotifications(notifications) {
    //console.log('updateNotifications', notifications);
	const bell = document.getElementById('notif-bell');
	const badge = bell ? bell.querySelector('.notif-badge') : null;
	const dropdown = document.getElementById('notif-dropdown');
	if (!bell || !dropdown) return;

	// Badge: show count if > 0
	if (badge) badge.remove();
	if (Array.isArray(notifications) && notifications.length > 0) {
		const newBadge = document.createElement('span');
		newBadge.className = 'notif-badge';
		newBadge.textContent = notifications.length;
		bell.appendChild(newBadge);
	}

	// Dropdown: render notifications
	const title = dropdown.querySelector('.notif-dropdown-title');
	let list = dropdown.querySelector('ul');
	if (list) list.remove();
	let emptyDiv = dropdown.querySelector('.notif-empty');
	if (emptyDiv) emptyDiv.remove();

	if (Array.isArray(notifications) && notifications.length > 0) {
		// Sort notifications from newest to oldest
		const sortedNotifications = notifications
			.slice()
			.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
		list = document.createElement('ul');
		sortedNotifications.forEach(n => {
			const li = document.createElement('li');
			li.className = 'notif-' + (n.level_name ? n.level_name.toLowerCase() : 'info');
			// Format date
			let dateStr = '';
			if (n.timestamp) {
				dateStr = window.dateUtils
					? window.dateUtils.formatTimestamp(n.timestamp)
					: n.timestamp;
			}

			const msgSpan = document.createElement('span');
			msgSpan.className = 'notif-msg';
			msgSpan.textContent = n.message ?? '';

			const dateSpan = document.createElement('span');
			dateSpan.className = 'notif-date';
			dateSpan.textContent = dateStr;

			const closeBtn = document.createElement('button');
			closeBtn.type = 'button';
			closeBtn.className = 'notif-close-btn';
			closeBtn.title = 'Dismiss notification';
			closeBtn.style.setProperty('float', 'right');
			closeBtn.style.marginLeft = '12px';
			closeBtn.style.padding = '0 8px';
			closeBtn.style.fontSize = '16px';
			closeBtn.style.background = 'none';
			closeBtn.style.color = '#aaa';
			closeBtn.style.border = 'none';
			closeBtn.style.cursor = 'pointer';
			closeBtn.style.lineHeight = '1';
			closeBtn.textContent = '\u00D7';

			li.appendChild(msgSpan);
			li.appendChild(dateSpan);
			li.appendChild(closeBtn);
			list.appendChild(li);
		});
			// Handler to close/dismiss a notification
		list.querySelectorAll('.notif-close-btn').forEach(function(btn, idx) {
			btn.addEventListener('click', function () {
				// Find the notification id
				const li = btn.closest('li');
				const notif = sortedNotifications[idx];
				if (!notif || !notif.id) return;
				btn.disabled = true;
				apiClient.submit('toggle_ack', { id: notif.id })
				.then(data => {
					if (data.status === 'success') {
						if (li) li.remove();
						const badge = bell.querySelector('.notif-badge');
						if (badge) {
							let count = parseInt(badge.textContent, 10) - 1;
							if (count > 0) {
								badge.textContent = count;
							} else {
								badge.remove();
								if (list.children.length === 0) {
									const emptyDiv = document.createElement('div');
									emptyDiv.className = 'notif-empty';
									emptyDiv.textContent = 'No notifications';
									dropdown.appendChild(emptyDiv);
								}
							}
						}
					} else {
						btn.disabled = false;
						showApiResult(data, { title: 'Error', closeText: 'Close' });
					}
				})
				.catch(() => {
					btn.disabled = false;
					showApiResult({ status: 'error', response_msg: 'Network error while dismissing notification' }, { title: 'Error', closeText: 'Close' });
				});
			});
		});
		dropdown.appendChild(list);
	} else {
		emptyDiv = document.createElement('div');
		emptyDiv.className = 'notif-empty';
		emptyDiv.textContent = 'No notifications';
		dropdown.appendChild(emptyDiv);
	}
}