import { getUrlParams } from './utils.js';
import { updateGatewayLed } from './gatewayLed.js';
import { updateLoadLed } from './loadLed.js';
import { updateTasks } from './updateTasks.js';
import { updateNotifications } from './updateNotifications.js';

/**
 * Read the app version from the meta tag injected by the backend.
 * Used for cache-busting dynamic imports so updated modules are
 * always fetched after a version bump.
 */
function getAppVersion() {
    const meta = document.querySelector('meta[name="app-version"]');
    return meta ? meta.content : '0';
}

export const refreshCommandHandlers = [
    async function(cmd) {
        const params = getUrlParams();
            if (cmd.method === 'gateway-daemon.ping') {
            updateGatewayLed(cmd);
            updateLoadLed(cmd);
            if (cmd.result && cmd.result.tasks) {
                updateTasks(cmd.result.tasks);
                // Save the last id of the last task (unsorted, just the last one)
                const taskIds = Object.keys(cmd.result.tasks);
                if (taskIds.length > 0) {
                    window.lastTaskId = taskIds[taskIds.length - 1];
                }
                // Keep in pendingTaskIds the ids that have not arrived,
                // and remove only those that arrive and are no longer pending
                if (!window.pendingTaskIds) {
                    window.pendingTaskIds = [];
                }
                // 1. Mark those that arrive and are still pending
                const stillPending = [];
                // 2. Mark those that arrive and are no longer pending
                const noLongerPending = [];
                for (const [id, rawTask] of Object.entries(cmd.result.tasks)) {
                    // Normalize `task_info` wrapper when present and use the
                    // task-level lifecycle status (e.g. 'pending' | 'done').
                    let task;
                    if (rawTask && rawTask.task_info) {
                        task = rawTask.task_info;
                    } else {
                        task = rawTask;
                    }

                    let status = 'unknown';
                    if (
                        task &&
                        typeof task.status === 'string' &&
                        task.status.trim().length > 0
                    ) {
                        status = task.status;
                    }

                    if (status === 'pending') {
                        stillPending.push(id);
                    } else {
                        noLongerPending.push(id);
                    }
                }
                // 3. Keep the ids that were in pendingTaskIds and did not arrive in the response
                const keepMissing = window.pendingTaskIds.filter(id => !(id in cmd.result.tasks));
                // 4. Merge those that are still pending and those that are missing
                window.pendingTaskIds = [...stillPending, ...keepMissing];
                //console.log('pendingTaskIds:', window.pendingTaskIds);
            }
            // Always handle notifications if present (do not skip when tasks exist)
            if (cmd.result && cmd.result.notifications) {
                updateNotifications(cmd.result.notifications);
            }
        }
        if (cmd.method === 'system-overview.get_system_info') {
            const mod = await import('./systemOverview.js?v=' + getAppVersion());
            mod.getSystemOverview(cmd);
        }
    }
];
