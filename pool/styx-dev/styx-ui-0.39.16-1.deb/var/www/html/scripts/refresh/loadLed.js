
export function updateLoadLed(cmd) {
    const led = document.getElementById('cpu_status');
    if (!led) {
        console.error('CPU LED element not found');
        return;
    }
    // Reset class
    led.className = 'led-load';
    let led_status = 'led-green';
    let cpu_load = 'N/A';
    if (cmd && cmd.result && typeof cmd.result.cpu_load !== 'undefined') {
        const load = parseFloat(cmd.result.cpu_load);
        if (!isNaN(load)) {
            cpu_load = load.toFixed(1) + '%';
            if (load >= 80) {
                led_status = 'led-red';
            } else if (load >= 40) {
                led_status = 'led-orange';
            } else {
                led_status = 'led-green';
            }
        }
    }
    led.classList.add(led_status);
    led.classList.add('blink2');
    led.title = `CPU Load: ${cpu_load}`;
}
