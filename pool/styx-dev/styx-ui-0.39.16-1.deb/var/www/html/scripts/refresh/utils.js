export function getUrlParams() {
    const params = {};
    const search = window.location.search.substring(1);
    search.split('&').forEach(function (part) {
        const [key, value] = part.split('=');
        if (key) params[key] = decodeURIComponent(value || '');
    });
    return params;
}
