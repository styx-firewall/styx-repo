// routing-policies.js
// FRR Policies-toggle forms + add/edit submit + delete

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }

    // Helper: set a label-picker hidden input and update its display label
    function setLabelPicker(form, sel, uuid, displayName) {
        const hidden = form.querySelector(sel);
        if (!hidden || uuid === undefined) return;
        hidden.value = uuid;
        const field = hidden.closest('.set-picker-field');
        if (!field) return;
        const label = field.querySelector('.js-set-picker-label');
        const clearBtn = field.querySelector('.js-set-picker-clear');
        if (label) {
            label.textContent = displayName || 'None';
        }
        if (clearBtn) {
            if (uuid) { clearBtn.classList.remove('sets-hidden'); }
            else { clearBtn.classList.add('sets-hidden'); }
        }
    }

    const cmdMap = {
        prefix_list:    { add: 'routing_add_prefix_list',    upd: 'routing_update_prefix_list' },
        route_map:      { add: 'routing_add_route_map',      upd: 'routing_update_route_map' },
        as_path_list:   { add: 'routing_add_as_path_list',   upd: 'routing_update_as_path_list' },
        community_list: { add: 'routing_add_community_list', upd: 'routing_update_community_list' },
    };

    // Toggle form visibility (add mode + cancel) 
    document.querySelectorAll('[data-js="policies-toggle-form"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = document.getElementById(btn.dataset.target);
            if (!target) return;
            if (target.style.display === 'none') {
                // Opening via "+ Add" button
                resetFormToAdd(target);
                target.style.display = 'block';
                btn.style.display = 'none';
            } else {
                // Closing via Cancel or toggling off
                resetFormToAdd(target);
                target.style.display = 'none';
                const addBtn = document.querySelector(
                    '[data-js="policies-toggle-form"][data-target="' + btn.dataset.target + '"]'
                );
                if (addBtn) addBtn.style.display = '';
            }
        });
    });

    // Edit button-populate form 
    document.querySelectorAll('.js-policy-edit').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = document.getElementById(btn.dataset.target);
            if (!target) return;

            const form = target.querySelector('[data-js="policy-add-form"]');
            const policy = btn.dataset.policy;

            // Set hidden id
            const idEl = form.querySelector('.js-policy-id');
            if (idEl) idEl.value = btn.dataset.id;

            // Set name / desc
            setVal(form, '.js-policy-name', btn.dataset.name);
            setVal(form, '.js-policy-desc', btn.dataset.desc);

            // Set entry fields
            setVal(form, '.js-entry-seq', btn.dataset.seq);
            setSel(form, '.js-entry-action', btn.dataset.action);

            if (policy === 'prefix_list') {
                setVal(form, '.js-entry-prefix-set', btn.dataset.prefixSet);
                setLabelPicker(form, '.js-entry-prefix-set', btn.dataset.prefixSet, btn.dataset.prefixSetName || '');
                setVal(form, '.js-entry-ge', btn.dataset.ge);
                setVal(form, '.js-entry-le', btn.dataset.le);
            }

            if (policy === 'route_map') {
                setVal(form, '.js-entry-desc', btn.dataset.entryDesc);
                setSel(form, '.js-match-prefix-list', btn.dataset.matchPl);
                setSel(form, '.js-match-as-path-list', btn.dataset.matchAspl);
                setSel(form, '.js-match-community-list', btn.dataset.matchCl);
                setChk(form, '.js-match-community-exact', btn.dataset.matchClExact);
                setVal(form, '.js-set-local-pref', btn.dataset.setLp);
                setVal(form, '.js-set-metric', btn.dataset.setMetric);
                setVal(form, '.js-set-community', btn.dataset.setCommunity);
                setLabelPicker(form, '.js-set-community', btn.dataset.setCommunity, btn.dataset.setCommunityName || '');
                setChk(form, '.js-set-community-additive', btn.dataset.setCommAdd);
                setVal(form, '.js-set-ip-next-hop', btn.dataset.setNh);
                setLabelPicker(form, '.js-set-ip-next-hop', btn.dataset.setNh, btn.dataset.setNhName || '');
                setSel(form, '.js-set-origin', btn.dataset.setOrigin);
                setVal(form, '.js-set-weight', btn.dataset.setWeight);
                setVal(form, '.js-set-as-prepend', btn.dataset.setPrepend);
                setLabelPicker(form, '.js-set-as-prepend', btn.dataset.setPrepend, btn.dataset.setPrependName || '');
            }

            if (policy === 'as_path_list') {
                setVal(form, '.js-entry-regex', btn.dataset.regex);
                setLabelPicker(form, '.js-entry-regex', btn.dataset.regex, btn.dataset.regexName || '');
            }

            if (policy === 'community_list') {
                setSel(form, '.js-list-type', btn.dataset.listType);
                setVal(form, '.js-entry-community', btn.dataset.community);
                setLabelPicker(form, '.js-entry-community', btn.dataset.community, btn.dataset.communityName || '');
            }

            // Update title and button
            const titleEl = document.getElementById(btn.dataset.title);
            const submitBtn = document.getElementById(btn.dataset.submitBtn);
            if (titleEl) titleEl.textContent = 'Edit ' + policyName(policy);
            if (submitBtn) submitBtn.textContent = 'Save';

            // Hide add button, show form
            const addBtn = document.querySelector(
                '[data-js="policies-toggle-form"][data-target="' + btn.dataset.target + '"]'
            );
            if (addBtn) addBtn.style.display = 'none';
            target.style.display = 'block';
        });
    });

    // Submit (add or update) 
    document.querySelectorAll('[data-js="policy-add-form"]').forEach(form => {
        const submitBtn = form.querySelector('.js-policy-submit');
        if (!submitBtn) return;

        submitBtn.addEventListener('click', async () => {
            const policy = form.dataset.policy;
            const cmds = cmdMap[policy];
            if (!cmds) return;

            const idEl = form.querySelector('.js-policy-id');
            const id = idEl ? idEl.value.trim() : '';
            const isUpdate = !!id;

            const nameEl = form.querySelector('.js-policy-name');
            if (!nameEl || !nameEl.value.trim()) {
                showModal('<p>Name is required.</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }

            const data = { name: nameEl.value.trim() };
            const descEl = form.querySelector('.js-policy-desc');
            data.description = (descEl && descEl.value.trim()) ? descEl.value.trim() : null;

            if (isUpdate) data.id = id;

            const listTypeEl = form.querySelector('.js-list-type');
            if (listTypeEl) data.list_type = listTypeEl.value;

            // Build entry
            const entry = {};
            const seqEl = form.querySelector('.js-entry-seq');
            if (seqEl) entry.seq = parseInt(seqEl.value, 10) || 10;
            const actionEl = form.querySelector('.js-entry-action');
            if (actionEl) entry.action = actionEl.value;

            if (policy === 'prefix_list') {
                const pfSet = form.querySelector('.js-entry-prefix-set');
                if (!pfSet || !pfSet.value.trim()) {
                    showModal('<p>A network address set is required.</p>',
                        { title: 'Validation', closeText: 'Close' });
                    return;
                }
                entry.prefix_set = pfSet.value.trim();
                entry.ge = numOrNull(form, '.js-entry-ge');
                entry.le = numOrNull(form, '.js-entry-le');
            }

            if (policy === 'route_map') {
                const entryDesc = form.querySelector('.js-entry-desc');
                if (entryDesc && entryDesc.value.trim()) entry.description = entryDesc.value.trim();

                entry.match = {
                    prefix_list:         selValOrNull(form, '.js-match-prefix-list'),
                    as_path_list:        selValOrNull(form, '.js-match-as-path-list'),
                    community_list:      selValOrNull(form, '.js-match-community-list'),
                    community_exact_match: chkVal(form, '.js-match-community-exact'),
                };

                entry.set = {
                    local_preference:    numOrNull(form, '.js-set-local-pref'),
                    metric:              numOrNull(form, '.js-set-metric'),
                    community:           txtOrNull(form, '.js-set-community'),
                    community_additive:  chkVal(form, '.js-set-community-additive'),
                    ip_next_hop_set:     txtOrNull(form, '.js-set-ip-next-hop'),
                    origin:              selValOrNull(form, '.js-set-origin'),
                    weight:              numOrNull(form, '.js-set-weight'),
                    as_path_prepend:     txtOrNull(form, '.js-set-as-prepend'),
                };
            }

            if (policy === 'as_path_list') {
                const regex = form.querySelector('.js-entry-regex');
                if (!regex || !regex.value.trim()) {
                    showModal('<p>Regex is required.</p>', { title: 'Validation', closeText: 'Close' });
                    return;
                }
                entry.regex = regex.value.trim();
            }

            if (policy === 'community_list') {
                const comm = form.querySelector('.js-entry-community');
                if (!comm || !comm.value.trim()) {
                    showModal('<p>Community value is required.</p>', { title: 'Validation', closeText: 'Close' });
                    return;
                }
                entry.community = comm.value.trim();
            }

            data.entries = [entry];

            const command = isUpdate ? cmds.upd : cmds.add;
            const title = (isUpdate ? 'Update ' : 'Add ') + policyName(policy);

            try {
                const result = await apiClient.submit(command, data);
                showApiResult(result, { title: title, closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message },
                    { title: 'Error', closeText: 'Close' });
            }
        });
    });

    // Delete 
    document.querySelectorAll('[data-js="policies-delete"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const policy = btn.dataset.policy;
            const id = btn.dataset.id;
            const cmds = cmdMap[policy];
            if (!cmds) return;

            const delCmd = cmds.upd.replace('update_', 'delete_');
            showModal('Delete this ' + policyName(policy).toLowerCase() + '?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit(delCmd, { id });
                        showApiResult(result, {
                            title: 'Delete ' + policyName(policy),
                            closeText: 'Close',
                            reloadOnOk: true,
                        });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message },
                            { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });
});

// Helpers 

function policyName(policy) {
    const names = {
        prefix_list: 'Prefix List', route_map: 'Route Map',
        as_path_list: 'AS Path List', community_list: 'Community List',
    };
    return names[policy] || policy;
}

function resetFormToAdd(formContainer) {
    const form = formContainer.querySelector('[data-js="policy-add-form"]');
    if (!form) return;
    const idEl = form.querySelector('.js-policy-id');
    if (idEl) idEl.value = '';
    // Clear text/numbers, reset selects to first option
    form.querySelectorAll('input[type="text"], input[type="number"]').forEach(el => {
        if (el.classList.contains('js-entry-seq')) el.value = '10';
        else el.value = '';
    });
    form.querySelectorAll('select').forEach(el => el.selectedIndex = 0);
    form.querySelectorAll('input[type="checkbox"]').forEach(el => el.checked = false);
    // Reset all picker fields: hidden inputs, labels, and clear buttons
    form.querySelectorAll('.set-picker-field').forEach(field => {
        const hidden = field.querySelector('input[type="hidden"]');
        if (hidden) hidden.value = '';
        const label = field.querySelector('.js-set-picker-label');
        if (label) {
            const placeholder = (field.querySelector('.js-set-picker-open') || {}).dataset?.placeholder;
            label.textContent = placeholder || 'None';
        }
        const clearBtn = field.querySelector('.js-set-picker-clear');
        if (clearBtn) clearBtn.classList.add('sets-hidden');
    });
    const policy = form.dataset.policy;
    const titleEl = formContainer.querySelector('[id$="-form-title"]');
    const submitBtn = formContainer.querySelector('.js-policy-submit');
    if (titleEl) titleEl.textContent = 'Add ' + policyName(policy);
    if (submitBtn) submitBtn.textContent = 'Create';
}

function setVal(form, sel, val) {
    const el = form.querySelector(sel);
    if (el && val !== undefined) el.value = val;
}
function setSel(form, sel, val) {
    const el = form.querySelector(sel);
    if (el && val !== undefined) el.value = val;
}
function setChk(form, sel, val) {
    const el = form.querySelector(sel);
    if (el) el.checked = (val === '1' || val === true);
}
function numOrNull(form, sel) {
    const el = form.querySelector(sel);
    if (el && el.value.trim()) return parseInt(el.value, 10);
    return null;
}
function txtOrNull(form, sel) {
    const el = form.querySelector(sel);
    if (el && el.value.trim()) return el.value.trim();
    return null;
}
function selValOrNull(form, sel) {
    const el = form.querySelector(sel);
    if (el && el.value) return el.value;
    return null;
}
function chkVal(form, sel) {
    const el = form.querySelector(sel);
    return el ? el.checked : false;
}
