// routing-rip.js
// RIP configuration and network management

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }

    // Save RIP global config
    const saveConfigBtn = document.querySelector('[data-js="rip-save-config"]');
    if (saveConfigBtn) {
        saveConfigBtn.addEventListener('click', async () => {
            // Collect redistribute entries from checkboxes
            const redistribute = [];
            document.querySelectorAll('.js-rip-redist-proto:checked').forEach(cb => {
                const proto = cb.value;
                const entry = { protocol: proto };
                const rmEl = document.querySelector('.js-rip-redist-route-map[data-proto="' + proto + '"]');
                if (rmEl && rmEl.value) entry.route_map = rmEl.value;
                const metricEl = document.querySelector('.js-rip-redist-metric[data-proto="' + proto + '"]');
                if (metricEl && metricEl.value) {
                    const m = parseInt(metricEl.value, 10);
                    if (m >= 1 && m <= 16) entry.metric = m;
                }
                redistribute.push(entry);
            });

            // Collect passive interfaces from multi-select
            const passiveSel = document.getElementById('rip_passive_interfaces');
            const passiveInterfaces = [];
            if (passiveSel) {
                for (let i = 0; i < passiveSel.options.length; i++) {
                    if (passiveSel.options[i].selected) {
                        passiveInterfaces.push(passiveSel.options[i].value);
                    }
                }
            }

            const data = {
                version:            parseInt(document.getElementById('rip_version').value, 10),
                enabled:            document.getElementById('rip_enabled').checked,
                default_metric:     parseInt(document.getElementById('rip_default_metric').value, 10) || 1,
                update_timer:       parseInt(document.getElementById('rip_update_timer').value, 10) || 30,
                timeout_timer:      parseInt(document.getElementById('rip_timeout_timer').value, 10) || 180,
                garbage_timer:      parseInt(document.getElementById('rip_garbage_timer').value, 10) || 120,
                bfd_default_profile: document.getElementById('rip_bfd_default_profile').value || null,
                passive_interfaces:  passiveInterfaces.length > 0 ? passiveInterfaces : undefined,
                redistribute:        redistribute.length > 0 ? redistribute : undefined,
            };
            try {
                const result = await apiClient.submit('routing_save_rip_config', data);
                showApiResult(result, { title: 'RIP Configuration', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Show/hide add network form
    const addNetworkOpenBtn = document.querySelector('[data-js="rip-add-network-open"]');
    const addNetworkForm    = document.getElementById('rip-add-network-form');
    const addNetworkCancel  = document.querySelector('[data-js="rip-add-network-cancel"]');

    if (addNetworkOpenBtn && addNetworkForm) {
        addNetworkOpenBtn.addEventListener('click', () => {
            addNetworkForm.style.display = '';
            addNetworkOpenBtn.style.display = 'none';
        });
    }
    if (addNetworkCancel && addNetworkForm) {
        addNetworkCancel.addEventListener('click', () => {
            addNetworkForm.style.display = 'none';
            if (addNetworkOpenBtn) addNetworkOpenBtn.style.display = '';
        });
    }

    // Add RIP network
    const saveNetworkBtn = document.querySelector('[data-js="rip-network-save"]');
    if (saveNetworkBtn) {
        saveNetworkBtn.addEventListener('click', async () => {
            const networkSet = document.getElementById('rip_network_set').value.trim();

            if (!networkSet) {
                showModal('<p>Select an address set for the network.</p>',
                    { title: 'Validation', closeText: 'Close' });
                return;
            }

            const bfdProfile = document.getElementById('rip_network_bfd_profile').value.trim();
            const plIn = document.getElementById('rip_network_pl_in').value.trim();
            const plOut = document.getElementById('rip_network_pl_out').value.trim();

            const data = {
                network_set:    networkSet,
                bfd:            document.getElementById('rip_network_bfd').checked || undefined,
                bfd_profile:    bfdProfile || undefined,
                prefix_list_in: plIn || undefined,
                prefix_list_out: plOut || undefined,
            };
            try {
                const result = await apiClient.submit('routing_add_rip_network', data);
                showApiResult(result, { title: 'Add RIP Network', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Delete RIP network
    document.querySelectorAll('[data-js="rip-delete-network"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this RIP network?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('routing_delete_rip_network', { id });
                        showApiResult(result, { title: 'Delete RIP Network', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });
});
