// routing-evpn.js
document.addEventListener('DOMContentLoaded', () => {
    // Init label pickers
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }

    // Config save
    const saveCfg = document.querySelector('[data-js="evpn-save-config"]');
    if (saveCfg) {
        saveCfg.addEventListener('click', async () => {
            try {
                const r = await apiClient.submit('routing_save_evpn', {
                    enabled: document.getElementById('evpn_enabled').checked,
                    advertise_all_vni: document.getElementById('evpn_all_vni').checked,
                    advertise_svi_ip: document.getElementById('evpn_svi_ip').checked,
                });
                showApiResult(r, { title: 'EVPN Config', closeText: 'Close', reloadOnOk: true });
            } catch (e) { showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' }); }
        });
    }
    // Toggle VRF form
    document.querySelectorAll('[data-js="evpn-toggle-form"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const t = document.getElementById(btn.dataset.target);
            if (!t) return;
            if (t.style.display === 'none') {
                // Opening via "+ Add" button
                resetVrfForm();
                t.style.display = 'block'; btn.style.display = 'none';
            } else {
                // Closing via Cancel or toggling off
                resetVrfForm();
                t.style.display = 'none';
                const ab = document.querySelector('[data-js="evpn-toggle-form"][data-target="' + btn.dataset.target + '"]');
                if (ab) ab.style.display = '';
            }
        });
    });

    function resetVrfForm() {
        document.getElementById('evpn_vrf_iface').value = '';
        document.getElementById('evpn_l3vni').value = '';
        document.getElementById('evpn_vrf_rd').value = '';
        document.getElementById('evpn_vrf_rt_export').value = '';
        document.getElementById('evpn_vrf_rt_import').value = '';
        document.getElementById('evpn_adv_v4').checked = true;
        document.getElementById('evpn_adv_v6').checked = false;
        // Reset label picker display
        const label = document.querySelector('#evpn-vrf-add-form .js-set-picker-label');
        if (label) label.textContent = 'Select VNI label';
        const clearBtn = document.querySelector('#evpn-vrf-add-form .js-set-picker-clear');
        if (clearBtn) clearBtn.classList.add('sets-hidden');
    }
    // Add VRF
    const saveVrf = document.querySelector('[data-js="evpn-vrf-save"]');
    if (saveVrf) {
        saveVrf.addEventListener('click', async () => {
            const vrfIface = document.getElementById('evpn_vrf_iface').value.trim();
            const l3vni = document.getElementById('evpn_l3vni').value.trim();
            if (!vrfIface) { showModal('<p>VRF interface is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }
            if (!l3vni) { showModal('<p>L3VNI label is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }
            const payload = {
                vrf_iface: vrfIface,
                l3vni: l3vni,
                advertise_ipv4_unicast: document.getElementById('evpn_adv_v4').checked,
                advertise_ipv6_unicast: document.getElementById('evpn_adv_v6').checked,
            };
            const rd = document.getElementById('evpn_vrf_rd').value.trim();
            if (rd) payload.rd = rd;
            const rtExport = document.getElementById('evpn_vrf_rt_export').value.trim();
            if (rtExport) payload.rt_export = rtExport;
            const rtImport = document.getElementById('evpn_vrf_rt_import').value.trim();
            if (rtImport) payload.rt_import = rtImport;
            try {
                const r = await apiClient.submit('routing_add_evpn_vrf', payload);
                showApiResult(r, { title: 'Add VRF', closeText: 'Close', reloadOnOk: true });
            } catch (e) { showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' }); }
        });
    }
    // Delete VRF
    document.querySelectorAll('[data-js="evpn-delete-vrf"]').forEach(btn => {
        btn.addEventListener('click', () => {
            showModal('Delete this VRF binding?', { title: 'Confirm', closeText: 'Cancel', showConfirm: true, confirmText: 'Delete',
                onConfirm: async () => {
                    try { const r = await apiClient.submit('routing_delete_evpn_vrf', { id: btn.dataset.id });
                        showApiResult(r, { title: 'Delete VRF', closeText: 'Close', reloadOnOk: true }); }
                    catch (e) { showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' }); }
                }});
        });
    });
});
