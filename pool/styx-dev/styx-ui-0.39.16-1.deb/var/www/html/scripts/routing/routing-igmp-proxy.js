// routing-igmp-proxy.js
// IGMP Proxy configuration and interface management

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }

    // Save IGMP global config 
    const saveConfigBtn = document.querySelector('[data-js="igmp-save-config"]');
    if (saveConfigBtn) {
        saveConfigBtn.addEventListener('click', async () => {
            const enabledEl = document.getElementById('igmp_enabled');
            if (!enabledEl) return;
            const data = {
                enabled: enabledEl.checked,
            };
            try {
                const result = await apiClient.submit('routing_save_igmp_config', data);
                showApiResult(result, { title: 'IGMP Proxy Configuration', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Show/hide add interface form 
    const addIfaceForm   = document.getElementById('igmp-add-iface-form');
    const addIfaceTitle  = document.getElementById('igmp-add-iface-title');
    const addIfaceCancel = document.querySelector('[data-js="igmp-add-iface-cancel"]');
    const roleInput      = document.getElementById('igmp_iface_role');
    const whitelistRow   = document.getElementById('igmp-whitelist-row');
    const whitelistInput = document.getElementById('igmp_whitelist');
    const ifaceSelect    = document.getElementById('igmp_iface');

    document.querySelectorAll('[data-js="igmp-add-iface-open"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const role = btn.dataset.role;
            if (roleInput) roleInput.value = role;
            if (addIfaceTitle) {
                addIfaceTitle.textContent = role === 'upstream' ? 'Set Upstream Interface' : 'Add Downstream Interface';
            }
            // Show whitelist picker only for downstream
            if (whitelistRow) {
                whitelistRow.style.display = role === 'downstream' ? '' : 'none';
            }
            // Reset form fields
            if (whitelistInput) whitelistInput.value = '';
            if (ifaceSelect) ifaceSelect.value = '';
            // Clear set picker labels
            const label = document.querySelector('#igmp-whitelist-row .js-set-picker-label');
            if (label) label.textContent = 'None (all groups allowed)';
            const clearBtn = document.querySelector('#igmp-whitelist-row .js-set-picker-clear');
            if (clearBtn) clearBtn.classList.add('sets-hidden');

            if (addIfaceForm) addIfaceForm.style.display = '';
        });
    });

    if (addIfaceCancel && addIfaceForm) {
        addIfaceCancel.addEventListener('click', () => {
            addIfaceForm.style.display = 'none';
        });
    }

    // Add interface 
    const saveIfaceBtn = document.querySelector('[data-js="igmp-iface-save"]');
    if (saveIfaceBtn) {
        saveIfaceBtn.addEventListener('click', async () => {
            const roleEl  = document.getElementById('igmp_iface_role');
            const ifaceEl = document.getElementById('igmp_iface');
            if (!roleEl || !ifaceEl) return;

            const role  = roleEl.value;
            const iface = ifaceEl.value;

            if (!iface) {
                showModal('<p>Select an interface.</p>',
                    { title: 'Validation', closeText: 'Close' });
                return;
            }

            const data = { role, iface };

            // Include whitelist if set (downstream only)
            const whitelistEl = document.getElementById('igmp_whitelist');
            if (whitelistEl) {
                const whitelist = whitelistEl.value.trim();
                if (whitelist) {
                    data.whitelist = whitelist;
                }
            }

            try {
                const result = await apiClient.submit('routing_add_igmp_iface', data);
                showApiResult(result, { title: 'Add IGMP Interface', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Delete interface 
    document.querySelectorAll('[data-js="igmp-delete-iface"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Remove this interface from IGMP Proxy?', {
                title: 'Confirm Remove',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Remove',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('routing_delete_igmp_iface', { id });
                        showApiResult(result, { title: 'Remove Interface', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });
});
