// routing-zebra.js
document.addEventListener('DOMContentLoaded', () => {
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }
    const save = document.querySelector('[data-js="zebra-save-config"]');
    if (save) {
        save.addEventListener('click', async () => {
            try {
                const nhgKeep = parseInt(document.getElementById('zebra_nhg_keep').value, 10);
                if (isNaN(nhgKeep) || nhgKeep < 1 || nhgKeep > 3600) {
                    showModal('<p>Nexthop Group Keep must be between 1 and 3600.</p>', { title: 'Validation', closeText: 'Close' });
                    return;
                }
                const rmDelay = parseInt(document.getElementById('zebra_rm_delay').value, 10);
                if (isNaN(rmDelay) || rmDelay < 0 || rmDelay > 600) {
                    showModal('<p>Route Map Delay Timer must be between 0 and 600.</p>', { title: 'Validation', closeText: 'Close' });
                    return;
                }
                const r = await apiClient.submit('routing_save_zebra_config', {
                    router_id: document.getElementById('zebra_router_id').value.trim() || null,
                    ip_nht_resolve_via_default: document.getElementById('zebra_ip_nht').checked,
                    ipv6_nht_resolve_via_default: document.getElementById('zebra_ipv6_nht').checked,
                    nexthop_group_keep: nhgKeep,
                    route_map_delay_timer: rmDelay,
                    protocol_route_maps: (function () {
                        const items = [];
                        document.querySelectorAll('.js-zebra-proto-rm:checked').forEach(cb => {
                            const proto = cb.value;
                            const sel = document.querySelector('.js-zebra-proto-rm-map[data-proto="' + proto + '"]');
                            items.push({
                                protocol: proto,
                                route_map: (sel && sel.value) ? sel.value : null,
                            });
                        });
                        return items;
                    })(),
                });
                showApiResult(r, { title: 'Zebra Config', closeText: 'Close', reloadOnOk: true });
            } catch (e) { showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' }); }
        });
    }
});
