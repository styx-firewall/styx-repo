// routing-ospf.js
// OSPF configuration and area management

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }

    // Save OSPF global config 
    const saveConfigBtn = document.querySelector('[data-js="ospf-save-config"]');
    if (saveConfigBtn) {
        saveConfigBtn.addEventListener('click', async () => {
            const data = {
                router_id:                 document.getElementById('ospf_router_id').value.trim(),
                reference_bandwidth:       parseInt(document.getElementById('ospf_reference_bandwidth').value, 10) || 100,
                enabled:                   document.getElementById('ospf_enabled').checked,
                log_adjacency_changes:     document.getElementById('ospf_log_adjacency').checked,
                passive_interface_default: document.getElementById('ospf_passive_default').checked,
            };
            try {
                const result = await apiClient.submit('routing_save_ospf_config', data);
                showApiResult(result, { title: 'OSPF Configuration', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Show/hide add area form 
    const addAreaOpenBtn = document.querySelector('[data-js="ospf-add-area-open"]');
    const addAreaForm    = document.getElementById('ospf-add-area-form');
    const addAreaCancel  = document.querySelector('[data-js="ospf-add-area-cancel"]');

    if (addAreaOpenBtn && addAreaForm) {
        addAreaOpenBtn.addEventListener('click', () => {
            addAreaForm.style.display = '';
            addAreaOpenBtn.style.display = 'none';
        });
    }
    if (addAreaCancel && addAreaForm) {
        addAreaCancel.addEventListener('click', () => {
            addAreaForm.style.display = 'none';
            if (addAreaOpenBtn) addAreaOpenBtn.style.display = '';
        });
    }

    // Add OSPF area 
    const saveAreaBtn = document.querySelector('[data-js="ospf-area-save"]');
    if (saveAreaBtn) {
        saveAreaBtn.addEventListener('click', async () => {
            const areaId     = document.getElementById('ospf_area_id').value.trim();
            const type       = document.getElementById('ospf_area_type').value;
            const networkSet = document.getElementById('ospf_area_network_set').value.trim();

            if (!areaId) {
                showModal('<p>Area ID label is required.</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }
            if (!networkSet) {
                showModal('<p>Select an address set for the area network.</p>',
                    { title: 'Validation', closeText: 'Close' });
                return;
            }

            const noSumEl = document.getElementById('ospf_area_no_summary');
            const data = {
                area_id:    areaId,
                type,
                no_summary: noSumEl ? noSumEl.checked : false,
                network_set: networkSet,
            };
            try {
                const result = await apiClient.submit('routing_add_ospf_area', data);
                showApiResult(result, { title: 'Add OSPF Area', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Delete OSPF area 
    document.querySelectorAll('[data-js="ospf-delete-area"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this OSPF area?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('routing_delete_ospf_area', { id });
                        showApiResult(result, { title: 'Delete OSPF Area', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });

    // Area type > no-summary visibility 
    const areaTypeSelect = document.querySelector('[data-js="ospf-area-type"]');
    const noSummaryCol   = document.getElementById('ospf-no-summary-col');
    if (areaTypeSelect && noSummaryCol) {
        areaTypeSelect.addEventListener('change', () => {
            const t = areaTypeSelect.value;
            noSummaryCol.style.display = (t === 'stub' || t === 'nssa') ? '' : 'none';
        });
    }

    // Show/hide add interface form 
    const addIfaceOpenBtn = document.querySelector('[data-js="ospf-add-iface-open"]');
    const addIfaceForm    = document.getElementById('ospf-add-iface-form');
    const addIfaceCancel  = document.querySelector('[data-js="ospf-add-iface-cancel"]');

    if (addIfaceOpenBtn && addIfaceForm) {
        addIfaceOpenBtn.addEventListener('click', () => {
            addIfaceForm.style.display = '';
            addIfaceOpenBtn.style.display = 'none';
        });
    }
    if (addIfaceCancel && addIfaceForm) {
        addIfaceCancel.addEventListener('click', () => {
            addIfaceForm.style.display = 'none';
            if (addIfaceOpenBtn) addIfaceOpenBtn.style.display = '';
        });
    }

    // Add OSPF interface override 
    const saveIfaceBtn = document.querySelector('[data-js="ospf-iface-save"]');
    if (saveIfaceBtn) {
        saveIfaceBtn.addEventListener('click', async () => {
            const iface = document.getElementById('ospf_iface').value.trim();
            if (!iface) {
                showModal('<p>Select an interface.</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }
            const costVal = document.getElementById('ospf_iface_cost').value.trim();
            const data = {
                iface:          iface,
                priority:       parseInt(document.getElementById('ospf_iface_priority').value, 10),
                cost:           costVal ? parseInt(costVal, 10) : null,
                hello_interval: parseInt(document.getElementById('ospf_iface_hello').value, 10),
                dead_interval:  parseInt(document.getElementById('ospf_iface_dead').value, 10),
                poll_interval:  parseInt(document.getElementById('ospf_iface_poll').value, 10),
                passive:        document.getElementById('ospf_iface_passive').checked,
            };
            try {
                const result = await apiClient.submit('routing_add_ospf_iface', data);
                showApiResult(result, { title: 'Add OSPF Interface', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Delete OSPF interface override 
    document.querySelectorAll('[data-js="ospf-delete-iface"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this interface override?', {
                title: 'Confirm Delete',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('routing_delete_ospf_iface', { id });
                        showApiResult(result, { title: 'Delete Interface', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });

    // OSPFv3

    // Save config 
    const save6 = document.querySelector('[data-js="ospf6-save-config"]');
    if (save6) {
        save6.addEventListener('click', async () => {
            try {
                const r = await apiClient.submit('routing_save_ospf6_config', {
                    router_id: document.getElementById('ospf6_router_id').value.trim(),
                    reference_bandwidth: parseInt(document.getElementById('ospf6_ref_bw').value, 10) || 100,
                    enabled: document.getElementById('ospf6_enabled').checked,
                    log_adjacency_changes: document.getElementById('ospf6_log_adj').checked,
                    stub_router_administrative: document.getElementById('ospf6_stub_router').checked,
                });
                showApiResult(r, { title: 'OSPFv3 Config', closeText: 'Close', reloadOnOk: true });
            } catch (e) { showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' }); }
        });
    }

    // Area: toggle form 
    const a6Open = document.querySelector('[data-js="ospf6-add-area-open"]');
    const a6Form = document.getElementById('ospf6-add-area-form');
    const a6Cancel = document.querySelector('[data-js="ospf6-add-area-cancel"]');
    if (a6Open && a6Form) { a6Open.addEventListener('click', () => { a6Form.style.display = ''; a6Open.style.display = 'none'; }); }
    if (a6Cancel && a6Form) { a6Cancel.addEventListener('click', () => { a6Form.style.display = 'none'; if (a6Open) a6Open.style.display = ''; }); }

    // Area: save 
    const a6Save = document.querySelector('[data-js="ospf6-area-save"]');
    if (a6Save) {
        a6Save.addEventListener('click', async () => {
            const id = document.getElementById('ospf6_area_id').value.trim();
            const ns = document.getElementById('ospf6_network_set').value.trim();
            if (!id) { showModal('<p>Area ID is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }
            if (!ns) { showModal('<p>Network is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }
            try {
                const r = await apiClient.submit('routing_add_ospf6_area', {
                    area_id: id, type: document.getElementById('ospf6_area_type').value,
                    no_summary: document.getElementById('ospf6_area_nosum').checked, network_set: ns,
                });
                showApiResult(r, { title: 'Add OSPFv3 Area', closeText: 'Close', reloadOnOk: true });
            } catch (e) { showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' }); }
        });
    }

    // Area: delete 
    document.querySelectorAll('[data-js="ospf6-delete-area"]').forEach(btn => {
        btn.addEventListener('click', () => {
            showModal('Delete this area?', { title: 'Confirm', closeText: 'Cancel', showConfirm: true, confirmText: 'Delete',
                onConfirm: async () => {
                    try { const r = await apiClient.submit('routing_delete_ospf6_area', { id: btn.dataset.id });
                        showApiResult(r, { title: 'Delete Area', closeText: 'Close', reloadOnOk: true }); }
                    catch (e) { showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' }); }
                }});
        });
    });

    // Iface: toggle 
    const i6Open = document.querySelector('[data-js="ospf6-add-iface-open"]');
    const i6Form = document.getElementById('ospf6-add-iface-form');
    const i6Cancel = document.querySelector('[data-js="ospf6-add-iface-cancel"]');
    if (i6Open && i6Form) { i6Open.addEventListener('click', () => { i6Form.style.display = ''; i6Open.style.display = 'none'; }); }
    if (i6Cancel && i6Form) { i6Cancel.addEventListener('click', () => { i6Form.style.display = 'none'; if (i6Open) i6Open.style.display = ''; }); }

    // Iface: save 
    const i6Save = document.querySelector('[data-js="ospf6-iface-save"]');
    if (i6Save) {
        i6Save.addEventListener('click', async () => {
            const iface = document.getElementById('ospf6_iface').value.trim();
            const area = document.getElementById('ospf6_iface_area').value.trim();
            if (!iface) { showModal('<p>Interface UUID is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }
            if (!area) { showModal('<p>Area is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }
            const cost = document.getElementById('ospf6_iface_cost').value.trim();
            try {
                const r = await apiClient.submit('routing_add_ospf6_iface', {
                    iface: iface, area_set: area,
                    priority: parseInt(document.getElementById('ospf6_iface_prio').value, 10) || 1,
                    cost: cost ? parseInt(cost, 10) : null,
                    hello_interval: parseInt(document.getElementById('ospf6_iface_hello').value, 10) || 10,
                    dead_interval: parseInt(document.getElementById('ospf6_iface_dead').value, 10) || 40,
                    passive: document.getElementById('ospf6_iface_passive').checked,
                });
                showApiResult(r, { title: 'Add OSPFv3 Iface', closeText: 'Close', reloadOnOk: true });
            } catch (e) { showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' }); }
        });
    }

    // Iface: delete 
    document.querySelectorAll('[data-js="ospf6-delete-iface"]').forEach(btn => {
        btn.addEventListener('click', () => {
            showModal('Delete this interface?', { title: 'Confirm', closeText: 'Cancel', showConfirm: true, confirmText: 'Delete',
                onConfirm: async () => {
                    try { const r = await apiClient.submit('routing_delete_ospf6_iface', { id: btn.dataset.id });
                        showApiResult(r, { title: 'Delete Iface', closeText: 'Close', reloadOnOk: true }); }
                    catch (e) { showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' }); }
                }});
        });
    });
});
