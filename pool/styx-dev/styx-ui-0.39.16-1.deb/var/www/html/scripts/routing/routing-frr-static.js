// routing-frr-static.js
// FRR Static Routes-toggle + add/edit/submit + delete

document.addEventListener('DOMContentLoaded', () => {
    if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
        window.setsModal.initPickerFields(document);
    }
    if (window.labelsMgmt && typeof window.labelsMgmt.initPickerFields === 'function') {
        window.labelsMgmt.initPickerFields(document);
    }

    // Picker helpers 
    function resetPicker(hiddenId) {
        const hidden = document.getElementById(hiddenId);
        if (!hidden) return;
        hidden.value = '';
        const field = hidden.closest('.set-picker-field');
        if (!field) return;
        const label = field.querySelector('.js-set-picker-label');
        const clearBtn = field.querySelector('.js-set-picker-clear');
        const trigger = field.querySelector('.js-set-picker-open');
        if (label && trigger) {
            label.textContent = trigger.dataset.placeholder || 'None';
        }
        if (clearBtn) clearBtn.classList.add('sets-hidden');
    }

    function populatePicker(hiddenId, uuid, displayName) {
        const hidden = document.getElementById(hiddenId);
        if (!hidden) return;
        hidden.value = uuid || '';
        const field = hidden.closest('.set-picker-field');
        if (!field) return;
        const label = field.querySelector('.js-set-picker-label');
        const clearBtn = field.querySelector('.js-set-picker-clear');
        const trigger = field.querySelector('.js-set-picker-open');
        if (label) {
            label.textContent = displayName || (trigger && trigger.dataset.placeholder) || 'None';
        }
        if (clearBtn) {
            if (uuid) { clearBtn.classList.remove('sets-hidden'); }
            else { clearBtn.classList.add('sets-hidden'); }
        }
    }

    // Save config 
    const saveCfg = document.querySelector('[data-js="frr-static-save-config"]');
    if (saveCfg) {
        saveCfg.addEventListener('click', async () => {
            try {
                const r = await apiClient.submit('routing_save_frr_static_config', {
                    enabled: document.getElementById('frr_static_enabled').checked,
                });
                showApiResult(r, { title: 'Static Routes Config', closeText: 'Close', reloadOnOk: true });
            } catch (e) {
                showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Toggle form 
    document.querySelectorAll('[data-js="frr-static-toggle-form"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const t = document.getElementById(btn.dataset.target);
            if (!t) return;
            if (t.style.display === 'none') {
                // Opening via "+ Add" button
                resetForm();
                t.style.display = 'block';
                btn.style.display = 'none';
            } else {
                // Closing via Cancel or toggling off
                resetForm();
                t.style.display = 'none';
                const ab = document.querySelector('[data-js="frr-static-toggle-form"][data-target="' + btn.dataset.target + '"]');
                if (ab) ab.style.display = '';
            }
        });
    });

    function resetForm() {
        document.getElementById('frr_static_id').value = '';
        ['network','gateway','interface','desc','vrf','nh_vrf'].forEach(f =>
            { const el = document.getElementById('frr_static_' + f); if (el) el.value = ''; });
        ['distance','metric','weight'].forEach(f =>
            { const el = document.getElementById('frr_static_' + f); if (el) el.value = ''; });
        resetPicker('frr_static_tag');
        resetPicker('frr_static_table');
        document.getElementById('frr_static_type').value = 'unicast';
        document.getElementById('frr_static_onlink').checked = false;
        document.getElementById('frr-static-form-title').textContent = 'Add Static Route';
        toggleUnicastFields();
    }

    // Type-dependent field visibility 
    function toggleUnicastFields() {
        const type = document.getElementById('frr_static_type').value;
        const isUnicast = (type === 'unicast');
        document.querySelectorAll('.js-frr-static-unicast-only').forEach(el => {
            if (isUnicast) {
                el.style.display = '';
                el.querySelectorAll('input, select, button').forEach(c => c.disabled = false);
            } else {
                el.style.display = 'none';
                el.querySelectorAll('input, select, button').forEach(c => c.disabled = true);
            }
        });
    }

    const typeSel = document.getElementById('frr_static_type');
    if (typeSel) { typeSel.addEventListener('change', toggleUnicastFields); }

    // Edit 
    document.querySelectorAll('.js-frr-static-edit').forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('frr_static_id').value = btn.dataset.id;
            document.getElementById('frr_static_network').value = btn.dataset.network;
            document.getElementById('frr_static_gateway').value = btn.dataset.gateway;
            document.getElementById('frr_static_interface').value = btn.dataset.interface;
            document.getElementById('frr_static_distance').value = btn.dataset.distance;
            document.getElementById('frr_static_metric').value = btn.dataset.metric;
            populatePicker('frr_static_tag', btn.dataset.routeTag, btn.dataset.routeTagDisplay);
            document.getElementById('frr_static_weight').value = btn.dataset.weight;
            populatePicker('frr_static_table', btn.dataset.table, btn.dataset.tableDisplay);
            document.getElementById('frr_static_vrf').value = btn.dataset.vrf;
            document.getElementById('frr_static_nh_vrf').value = btn.dataset.nhVrf;
            document.getElementById('frr_static_type').value = btn.dataset.type;
            document.getElementById('frr_static_onlink').checked = (btn.dataset.onlink === '1');
            document.getElementById('frr_static_desc').value = btn.dataset.desc;
            document.getElementById('frr-static-form-title').textContent = 'Edit Static Route';
            toggleUnicastFields();
            const f = document.getElementById('frr-static-add-form');
            f.style.display = 'block';
            const ab = document.querySelector('[data-js="frr-static-toggle-form"][data-target="frr-static-add-form"]');
            if (ab) ab.style.display = 'none';
        });
    });

    // Save route 
    const saveRoute = document.querySelector('[data-js="frr-static-route-save"]');
    if (saveRoute) {
        saveRoute.addEventListener('click', async () => {
            const id = document.getElementById('frr_static_id').value.trim();
            const network = document.getElementById('frr_static_network').value.trim();
            if (!network) { showModal('<p>Network is required.</p>', { title: 'Validation', closeText: 'Close' }); return; }

            const type = document.getElementById('frr_static_type').value;
            const gateway = document.getElementById('frr_static_gateway').value.trim();
            const iface = document.getElementById('frr_static_interface').value.trim();

            if (type === 'unicast' && !gateway && !iface) {
                showModal('<p>Unicast route requires at least one of gateway or interface.</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }

            const distance = parseInt(document.getElementById('frr_static_distance').value, 10);
            if (distance && (distance < 1 || distance > 255)) {
                showModal('<p>Distance must be between 1 and 255.</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }

            const metric = parseInt(document.getElementById('frr_static_metric').value, 10);
            if (metric && (metric < 0 || metric > 4294967295)) {
                showModal('<p>Metric must be between 0 and 4294967295.</p>', { title: 'Validation', closeText: 'Close' });
                return;
            }

            const weightRaw = document.getElementById('frr_static_weight').value.trim();
            if (weightRaw) {
                const weight = parseInt(weightRaw, 10);
                if (isNaN(weight) || weight < 1 || weight > 65535) {
                    showModal('<p>Weight must be between 1 and 65535.</p>', { title: 'Validation', closeText: 'Close' });
                    return;
                }
            }

            const data = {
                network: network,
                gateway:     gateway || null,
                interface:   iface || null,
                distance:    distance || 1,
                metric:      metric || 0,
                route_tag:   document.getElementById('frr_static_tag').value.trim() || null,
                weight:      weightRaw ? parseInt(weightRaw, 10) : null,
                table:       document.getElementById('frr_static_table').value.trim() || null,
                vrf:         document.getElementById('frr_static_vrf').value.trim() || null,
                nexthop_vrf: document.getElementById('frr_static_nh_vrf').value.trim() || null,
                type:        type,
                onlink:      document.getElementById('frr_static_onlink').checked,
                description: document.getElementById('frr_static_desc').value.trim() || null,
            };
            const cmd = id ? 'routing_update_frr_static_route' : 'routing_add_frr_static_route';
            if (id) data.id = id;
            const title = id ? 'Update Static Route' : 'Add Static Route';
            try {
                const r = await apiClient.submit(cmd, data);
                showApiResult(r, { title: title, closeText: 'Close', reloadOnOk: true });
            } catch (e) {
                showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // Delete 
    document.querySelectorAll('[data-js="frr-static-delete"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            showModal('Delete this static route?', {
                title: 'Confirm Delete', closeText: 'Cancel',
                showConfirm: true, confirmText: 'Delete',
                onConfirm: async () => {
                    try {
                        const r = await apiClient.submit('routing_delete_frr_static_route', { id });
                        showApiResult(r, { title: 'Delete Route', closeText: 'Close', reloadOnOk: true });
                    } catch (e) {
                        showApiResult({ status: 'error', response_msg: e.message }, { title: 'Error', closeText: 'Close' });
                    }
                },
            });
        });
    });
});
