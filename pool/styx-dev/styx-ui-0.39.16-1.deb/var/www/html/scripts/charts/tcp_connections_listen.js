export default function tcp_connections_listen(range) {
    fetchAndUpdateChart('tcp_connections_listen', range, function(data) {
        var metrics = (data.tcp_connections_listen_metrics || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.value || m.tcp_connections_listen || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['tcp_connections_listen']) {
            window.charts['tcp_connections_listen'] = makeSingleChart(
                'tcp-connections-listen-chart',
                'TCP LISTEN',
                dsValues,
                'rgba(0,188,212,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['tcp_connections_listen'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #tcp-connections-listen-chart), h3:has(+ canvas#tcp-connections-listen-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('tcp listen')
            );
        }
        if (titleElem) titleElem.textContent = 'TCP LISTEN';
    });
}
