export default function udp_inuse(range) {
    fetchAndUpdateChart('udp_inuse', range, function(data) {
        var metrics = (data.udp_inuse_metrics || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.udp_socket_inuse || m.value || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['udp_inuse']) {
            window.charts['udp_inuse'] = makeSingleChart(
                'udp-inuse-chart',
                'UDP Inuse',
                dsValues,
                'rgba(205,220,57,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['udp_inuse'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
    });
}
