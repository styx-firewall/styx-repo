export default function tcp_mem(range) {
    fetchAndUpdateChart('tcp_mem', range, function(data) {
        var metrics = (data.tcp_mem_metrics || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var rawValues = metrics.map(m => m.tcp_mem_reserved || m.value || 0);
        var max = Math.max.apply(null, rawValues);
        var scale = 1, unit = 'Bytes';
        if (max >= 1_000_000_000) { scale = 1_000_000_000; unit = 'GB'; }
        else if (max >= 1_000_000) { scale = 1_000_000; unit = 'MB'; }
        else if (max >= 1_000) { scale = 1_000; unit = 'KB'; }
        var values = rawValues.map(v => v/scale);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        var chartTitle = 'TCP Memory (' + unit + ')';
        if (!window.charts['tcp_mem']) {
            window.charts['tcp_mem'] = makeSingleChart(
                'tcp-mem-chart',
                chartTitle,
                dsValues,
                'rgba(0,188,212,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['tcp_mem'];
            chart.options.plugins.title.text = chartTitle;
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #tcp-mem-chart), h3:has(+ canvas#tcp-mem-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('tcp memory')
            );
        }
        if (titleElem) titleElem.textContent = chartTitle;
    });
}
