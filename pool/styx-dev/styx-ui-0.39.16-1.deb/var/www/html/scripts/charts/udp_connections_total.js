export default function udp_connections_total(range) {
    fetchAndUpdateChart('udp_connections_total', range, function(data) {
        var metrics = (data.udp_connections_total_metrics || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.value || m.udp_connections_total || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['udp_connections_total']) {
            window.charts['udp_connections_total'] = makeSingleChart(
                'udp-connections-total-chart',
                'UDP Total',
                dsValues,
                'rgba(205,220,57,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['udp_connections_total'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #udp-connections-total-chart), h3:has(+ canvas#udp-connections-total-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('udp total')
            );
        }
        if (titleElem) titleElem.textContent = 'UDP Total';
    });
}
