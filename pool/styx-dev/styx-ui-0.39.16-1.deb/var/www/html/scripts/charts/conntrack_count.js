export default function conntrack_count(range) {
    fetchAndUpdateChart('conntrack_count', range, function(data) {
        var metrics = (data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.nf_conntrack_count || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['conntrack_count']) {
            window.charts['conntrack_count'] = makeSingleChart(
                'conntrack-count-chart',
                'ConnTrack Count',
                dsValues,
                'rgba(0,188,212,1)',
                { min: 0 },
                dsLabels
            );
        } else {
            var chart = window.charts['conntrack_count'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #conntrack-count-chart), h3:has(+ canvas#conntrack-count-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('conntrack count')
            );
        }
        if (titleElem) titleElem.textContent = 'ConnTrack Count';
    });
}
