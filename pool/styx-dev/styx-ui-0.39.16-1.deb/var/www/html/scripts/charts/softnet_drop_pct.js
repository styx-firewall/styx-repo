export default function softnet_drop_pct(range) {
    fetchAndUpdateChart('softnet_drop_pct', range, function(data) {
        var shortLabels = formatShortTimeLabels(data.labels);
        var allCpus = data.ifaces;
        var cpuDataRaw = allCpus.map(function(cpu) { return data.metrics[cpu]; });
        var cpuData = cpuDataRaw.map(arr => arr.map(function(v) { return v || 0; }));
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(shortLabels, blockSize);
        var dsCpuData = cpuData.map(arr => downsampleAvg(arr, blockSize));
        var dynColors = generateColors(allCpus.length);
        var totalIdx = allCpus.indexOf('total');
        if (totalIdx >= 0) dynColors[totalIdx] = 'rgba(255,255,255,1)';
        var chart = window.charts['softnet_drop_pct'];
        if (!chart || chart.data.datasets.length !== allCpus.length) {
            if (chart) chart.destroy();
            window.charts['softnet_drop_pct'] = makeMultilineChart(
                'softnet-drop-pct-chart',
                dsLabels,
                allCpus,
                dsCpuData,
                dynColors
            );
        } else {
            chart.data.labels = dsLabels;
            chart.data.datasets.forEach(function(ds, idx) {
                ds.data = dsCpuData[idx];
                ds.label = allCpus[idx];
                ds.borderColor = dynColors[idx % dynColors.length];
                ds.backgroundColor = dynColors[idx % dynColors.length].replace('1)', '0.2)');
            });
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #softnet-drop-pct-chart), h3:has(+ canvas#softnet-drop-pct-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('softnet drop %')
            );
        }
        if (titleElem) titleElem.textContent = 'Softnet Drop %';
    });
}
