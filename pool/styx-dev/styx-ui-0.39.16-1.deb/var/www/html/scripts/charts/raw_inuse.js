export default function raw_inuse(range) {
    fetchAndUpdateChart('raw_inuse', range, function(data) {
        var metrics = (data.raw_inuse_metrics || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.raw_sockets_inuse || m.value || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['raw_inuse']) {
            window.charts['raw_inuse'] = makeSingleChart(
                'raw-inuse-chart',
                'RAW Inuse',
                dsValues,
                'rgba(121,85,72,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['raw_inuse'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
    });
}
