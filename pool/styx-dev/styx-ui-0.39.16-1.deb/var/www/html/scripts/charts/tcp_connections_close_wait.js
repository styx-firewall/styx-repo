export default function tcp_connections_close_wait(range) {
    fetchAndUpdateChart('tcp_connections_close_wait', range, function(data) {
        var metrics = (data.tcp_connections_close_wait_metrics || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.value || m.tcp_connections_close_wait || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['tcp_connections_close_wait']) {
            window.charts['tcp_connections_close_wait'] = makeSingleChart(
                'tcp-connections-close-wait-chart',
                'TCP CLOSE_WAIT',
                dsValues,
                'rgba(156,39,176,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['tcp_connections_close_wait'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #tcp-connections-close-wait-chart), h3:has(+ canvas#tcp-connections-close-wait-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('tcp close_wait')
            );
        }
        if (titleElem) titleElem.textContent = 'TCP CLOSE_WAIT';
    });
}
