export default function fragments(range) {
    fetchAndUpdateChart('fragments', range, function(data) {
        var metrics = (data.fragments || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.value || m.fragments || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['fragments']) {
            window.charts['fragments'] = makeSingleChart(
                'fragments-chart',
                'Fragments',
                dsValues,
                'rgba(233,30,99,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['fragments'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
    });
}
