export default function network_rx(range) {
    fetchAndUpdateChart('network_rx', range, function(data) {
        var shortLabels = formatShortTimeLabels(data.labels);
        var allIfaces = data.ifaces;
        var rxDataRaw = allIfaces.map(function(iface) { return data.metrics[iface]; });
        var flat = rxDataRaw.flat();
        var max = Math.max.apply(null, flat);
        var scale = 1, unit = 'B/s';
        if (max >= 1_000_000) { scale = 1_000_000; unit = 'MB/s'; }
        else if (max >= 1_000) { scale = 1_000; unit = 'KB/s'; }
        var rxData = rxDataRaw.map(arr => arr.map(v => v/scale));
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(shortLabels, blockSize);
        var dsRxData = rxData.map(arr => downsampleAvg(arr, blockSize));
        var dynColors = generateColors(allIfaces.length);
        var chart = window.charts['network_rx'];
        if (!chart || chart.data.datasets.length !== allIfaces.length) {
            if (chart) chart.destroy();
            window.charts['network_rx'] = makeMultilineChart(
                'network-rx-chart',
                dsLabels,
                allIfaces,
                dsRxData,
                dynColors
            );
        } else {
            chart.data.labels = dsLabels;
            chart.data.datasets.forEach(function(ds, idx) {
                ds.data = dsRxData[idx];
                ds.label = allIfaces[idx];
                ds.borderColor = dynColors[idx % dynColors.length];
                ds.backgroundColor = dynColors[idx % dynColors.length].replace('1)', '0.2)');
            });
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #network-rx-chart), h3:has(+ canvas#network-rx-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('network rx')
            );
        }
        if (titleElem) titleElem.textContent = 'Network RX (' + unit + ')';
    });
}
