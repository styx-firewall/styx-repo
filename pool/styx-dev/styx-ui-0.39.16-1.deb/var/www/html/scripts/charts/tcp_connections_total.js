export default function tcp_connections_total(range) {
    fetchAndUpdateChart('tcp_connections_total', range, function(data) {
        var metrics = (data.tcp_connections_total_metrics || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.value || m.tcp_connections_total || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['tcp_connections_total']) {
            window.charts['tcp_connections_total'] = makeSingleChart(
                'tcp-connections-total-chart',
                'TCP Total',
                dsValues,
                'rgba(121,85,72,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['tcp_connections_total'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #tcp-connections-total-chart), h3:has(+ canvas#tcp-connections-total-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('tcp total')
            );
        }
        if (titleElem) titleElem.textContent = 'TCP Total';
    });
}
