export default function softnet_processed(range) {
    fetchAndUpdateChart('softnet_processed', range, function(data) {
        var shortLabels = formatShortTimeLabels(data.labels);
        var allCpus = data.ifaces;
        var cpuDataRaw = allCpus.map(function(cpu) { return data.metrics[cpu]; });
        var flat = cpuDataRaw.flat();
        var max = Math.max.apply(null, flat);
        var scale = 1, unit = 'pps';
        if (max >= 1_000_000) { scale = 1_000_000; unit = 'Mpps'; }
        else if (max >= 1_000) { scale = 1_000; unit = 'Kpps'; }
        var cpuData = cpuDataRaw.map(arr => arr.map(v => v/scale));
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(shortLabels, blockSize);
        var dsCpuData = cpuData.map(arr => downsampleAvg(arr, blockSize));
        var dynColors = generateColors(allCpus.length);
        // Make total line stand out
        var totalIdx = allCpus.indexOf('total');
        if (totalIdx >= 0) dynColors[totalIdx] = 'rgba(255,255,255,1)';
        var chart = window.charts['softnet_processed'];
        if (!chart || chart.data.datasets.length !== allCpus.length) {
            if (chart) chart.destroy();
            window.charts['softnet_processed'] = makeMultilineChart(
                'softnet-processed-chart',
                dsLabels,
                allCpus,
                dsCpuData,
                dynColors
            );
        } else {
            chart.data.labels = dsLabels;
            chart.data.datasets.forEach(function(ds, idx) {
                ds.data = dsCpuData[idx];
                ds.label = allCpus[idx];
                ds.borderColor = dynColors[idx % dynColors.length];
                ds.backgroundColor = dynColors[idx % dynColors.length].replace('1)', '0.2)');
            });
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #softnet-processed-chart), h3:has(+ canvas#softnet-processed-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('softnet processed')
            );
        }
        if (titleElem) titleElem.textContent = 'Softnet Processed (' + unit + ')';
    });
}
