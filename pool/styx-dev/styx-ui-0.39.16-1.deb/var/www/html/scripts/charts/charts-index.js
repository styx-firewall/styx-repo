import cpu from './cpu.js';
import iowait from './iowait.js';
import memory from './memory.js';
import network_tx from './network_tx.js';
import network_rx from './network_rx.js';
import tcp_mem from './tcp_mem.js';
import udp_mem from './udp_mem.js';
import tcp_inuse from './tcp_inuse.js';
import udp_inuse from './udp_inuse.js';
import raw_inuse from './raw_inuse.js';
import fragments from './fragments.js';
import tcp_orphan from './tcp_orphan.js';
import tcp_time_wait from './tcp_time_wait.js';
import tcp_connections_established from './tcp_connections_established.js';
import tcp_connections_close_wait from './tcp_connections_close_wait.js';
import tcp_connections_listen from './tcp_connections_listen.js';
import tcp_connections_total from './tcp_connections_total.js';
import udp_connections_total from './udp_connections_total.js';
import conntrack_count from './conntrack_count.js';
import conntrack_pressure from './conntrack_pressure.js';
import softnet_processed from './softnet_processed.js';
import softnet_dropped from './softnet_dropped.js';
import softnet_drop_pct from './softnet_drop_pct.js';
import softnet_squeeze from './softnet_squeeze.js';
import softnet_squeeze_pct from './softnet_squeeze_pct.js';

const refreshers = {
    cpu,
    iowait,
    memory,
    network_tx,
    network_rx,
    tcp_mem,
    udp_mem,
    tcp_inuse,
    udp_inuse,
    raw_inuse,
    fragments,
    tcp_orphan,
    tcp_time_wait,
    tcp_connections_established,
    tcp_connections_close_wait,
    tcp_connections_listen,
    tcp_connections_total,
    udp_connections_total,
    conntrack_count,
    conntrack_pressure,
    softnet_processed,
    softnet_dropped,
    softnet_drop_pct,
    softnet_squeeze,
    softnet_squeeze_pct
};

export default refreshers;
