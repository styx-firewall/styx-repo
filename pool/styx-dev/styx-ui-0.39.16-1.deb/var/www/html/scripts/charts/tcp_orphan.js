export default function tcp_orphan(range) {
    fetchAndUpdateChart('tcp_orphan', range, function(data) {
        var metrics = (data.tcp_orphan_metrics || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.value || m.tcp_orphan || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['tcp_orphan']) {
            window.charts['tcp_orphan'] = makeSingleChart(
                'tcp-orphan-chart',
                'TCP Orphan',
                dsValues,
                'rgba(255,152,0,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['tcp_orphan'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #tcp-orphan-chart), h3:has(+ canvas#tcp-orphan-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('tcp orphan')
            );
        }
        if (titleElem) titleElem.textContent = 'TCP Orphan';
    });
}
