export default function memory(range) {
    fetchAndUpdateChart('memory', range, function(data) {
        var metrics = data.metrics || [];
        var labels = metrics.map(m => m.timestamp);
        var values = metrics.map(m => m.memory_usage);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['memory']) {
            window.charts['memory'] = makeSingleChart(
                'memory-chart',
                'Memory %',
                dsValues,
                'rgba(76,175,80,1)',
                { min: 0, max: 100, stepSize: 20 },
                dsLabels
            );
        } else {
            var chart = window.charts['memory'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
    });
}
