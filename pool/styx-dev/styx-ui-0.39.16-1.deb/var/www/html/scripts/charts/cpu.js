export default function cpu(range) {
    fetchAndUpdateChart('cpu', range, function(data) {
        var metrics = data.metrics || [];
        var labels = metrics.map(m => m.timestamp);
        var values = metrics.map(m => m.cpu_usage);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['cpu']) {
            window.charts['cpu'] = makeSingleChart(
                'cpu-chart',
                'CPU %',
                dsValues,
                'rgba(42,122,226,1)',
                { min: 0, max: 100, stepSize: 20 },
                dsLabels
            );
        } else {
            var chart = window.charts['cpu'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
    });
}
