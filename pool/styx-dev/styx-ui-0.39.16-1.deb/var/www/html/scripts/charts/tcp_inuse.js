export default function tcp_inuse(range) {
    fetchAndUpdateChart('tcp_inuse', range, function(data) {
        var metrics = (data.tcp_inuse_metrics || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.tcp_socket_inuse || m.value || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['tcp_inuse']) {
            window.charts['tcp_inuse'] = makeSingleChart(
                'tcp-inuse-chart',
                'TCP Inuse',
                dsValues,
                'rgba(255,87,34,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['tcp_inuse'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
    });
}
