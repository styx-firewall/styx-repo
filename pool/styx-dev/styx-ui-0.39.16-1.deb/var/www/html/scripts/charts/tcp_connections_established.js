export default function tcp_connections_established(range) {
    fetchAndUpdateChart('tcp_connections_established', range, function(data) {
        var metrics = (data.tcp_connections_established_metrics || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.value || m.tcp_connections_established || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['tcp_connections_established']) {
            window.charts['tcp_connections_established'] = makeSingleChart(
                'tcp-connections-established-chart',
                'TCP ESTABLISHED',
                dsValues,
                'rgba(76,175,80,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['tcp_connections_established'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #tcp-connections-established-chart), h3:has(+ canvas#tcp-connections-established-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('tcp established')
            );
        }
        if (titleElem) titleElem.textContent = 'TCP ESTABLISHED';
    });
}
