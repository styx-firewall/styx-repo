export default function conntrack_pressure(range) {
    fetchAndUpdateChart('conntrack_pressure', range, function(data) {
        var metrics = (data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.nf_conntrack_pressure_pct || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['conntrack_pressure']) {
            window.charts['conntrack_pressure'] = makeSingleChart(
                'conntrack-pressure-chart',
                'ConnTrack Pressure %',
                dsValues,
                'rgba(255,87,34,1)',
                { min: 0, max: 100, stepSize: 20 },
                dsLabels
            );
        } else {
            var chart = window.charts['conntrack_pressure'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #conntrack-pressure-chart), h3:has(+ canvas#conntrack-pressure-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('conntrack pressure')
            );
        }
        if (titleElem) titleElem.textContent = 'ConnTrack Pressure %';
    });
}
