export default function tcp_time_wait(range) {
    fetchAndUpdateChart('tcp_time_wait', range, function(data) {
        var metrics = (data.tcp_time_wait_metrics || data.metrics || []);
        var labels = metrics.map(m => m.timestamp || m.label || '');
        var values = metrics.map(m => m.value || m.tcp_time_wait || 0);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['tcp_time_wait']) {
            window.charts['tcp_time_wait'] = makeSingleChart(
                'tcp-time-wait-chart',
                'TCP TIME_WAIT',
                dsValues,
                'rgba(33,150,243,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['tcp_time_wait'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
        var titleElem = document.querySelector(
            'h3:has(+ #tcp-time-wait-chart), h3:has(+ canvas#tcp-time-wait-chart)'
        );
        if (!titleElem) {
            titleElem = Array.from(document.querySelectorAll('h3')).find(h =>
                h.textContent.trim().toLowerCase().startsWith('tcp time_wait')
            );
        }
        if (titleElem) titleElem.textContent = 'TCP TIME_WAIT';
    });
}
