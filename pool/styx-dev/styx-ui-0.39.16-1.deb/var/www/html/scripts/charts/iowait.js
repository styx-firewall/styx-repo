export default function iowait(range) {
    fetchAndUpdateChart('iowait', range, function(data) {
        var metrics = data.metrics || [];
        var labels = metrics.map(m => m.timestamp);
        var values = metrics.map(m => m.iowait_usage);
        var blockSize = getBlockSizeForRange(range);
        var dsLabels = downsampleLabels(formatShortTimeLabels(labels), blockSize);
        var dsValues = downsampleAvg(values, blockSize);
        if (!window.charts['iowait']) {
            window.charts['iowait'] = makeSingleChart(
                'iowait-chart',
                'I/O Wait %',
                dsValues,
                'rgba(255,193,7,1)',
                undefined,
                dsLabels
            );
        } else {
            var chart = window.charts['iowait'];
            chart.data.labels = dsLabels;
            chart.data.datasets[0].data = dsValues;
            chart.update();
        }
    });
}
