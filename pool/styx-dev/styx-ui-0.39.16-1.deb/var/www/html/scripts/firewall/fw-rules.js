/**
 * Firewall rules presentation with IPv4/IPv6 tabs
 */

/**
 * Initialize tabbed firewall rules table (forward)
 * @param {Object} config - { thead, data, controlsId, tableIdPrefix, rowLinkFn, endpoint, columnsConfig }
 */
function initForwardRulesTabs(config) {
    const { thead, data, controlsId, tableIdPrefix, rowLinkFn, endpoint, columnsConfig } = config;

    // Filter rules by family
    const ipv4Rules = data.filter(r => r.family === 'ip');
    const ipv6Rules = data.filter(r => r.family === 'ip6');

    // Create IPv4 table
    createDraggableTable({
        thead: thead,
        data: ipv4Rules,
        controlsId: controlsId + '-ipv4',
        tableId: tableIdPrefix + '-ipv4',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix
    });

    // Create IPv6 table
    createDraggableTable({
        thead: thead,
        data: ipv6Rules,
        controlsId: controlsId + '-ipv6',
        tableId: tableIdPrefix + '-ipv6',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix
    });

    // Initialize tab buttons for this context
    initTabButtons();

    // Show IPv4 by default (or restore saved tab)
    showTab(loadState('fw-rules', tableIdPrefix, 'ipv4'), tableIdPrefix);
}

/**
 * Initialize tabbed firewall rules table (local: input/output)
 * @param {Object} config - { thead, inputData, outputData, controlsIdPrefix, tableIdPrefix, rowLinkFn, endpoint, columnsConfig }
 */
function initLocalRulesTabs(config) {
    const { thead, inputData, outputData, controlsIdPrefix, tableIdPrefix, rowLinkFn, endpoint, columnsConfig } = config;

    // Filter input rules by family
    const inputIpv4 = inputData.filter(r => r.family === 'ip');
    const inputIpv6 = inputData.filter(r => r.family === 'ip6');

    // Filter output rules by family
    const outputIpv4 = outputData.filter(r => r.family === 'ip');
    const outputIpv6 = outputData.filter(r => r.family === 'ip6');

    // Create IPv4 INPUT table
    createDraggableTable({
        thead: thead,
        data: inputIpv4,
        controlsId: controlsIdPrefix + '-input-ipv4',
        tableId: tableIdPrefix + '-input-ipv4',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix + '-local'
    });

    // Create IPv6 INPUT table
    createDraggableTable({
        thead: thead,
        data: inputIpv6,
        controlsId: controlsIdPrefix + '-input-ipv6',
        tableId: tableIdPrefix + '-input-ipv6',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix + '-local'
    });

    // Create IPv4 OUTPUT table
    createDraggableTable({
        thead: thead,
        data: outputIpv4,
        controlsId: controlsIdPrefix + '-output-ipv4',
        tableId: tableIdPrefix + '-output-ipv4',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix + '-local'
    });

    // Create IPv6 OUTPUT table
    createDraggableTable({
        thead: thead,
        data: outputIpv6,
        controlsId: controlsIdPrefix + '-output-ipv6',
        tableId: tableIdPrefix + '-output-ipv6',
        rowLink: rowLinkFn,
        endpoint: endpoint,
        idField: 'id',
        handlerField: 'handle',
        cellHtml: true,
        stripedRows: true,
        columnsConfig: columnsConfig,
        stateKey: tableIdPrefix + '-local'
    });

    // Initialize tab buttons for this context
    initTabButtons();

    // Show IPv4 by default for both input and output (or restore saved tab)
    showTab(loadState('fw-rules', 'fw-local', 'ipv4'), 'fw-local');
}

/**
 * Show a specific tab and hide others
 * @param {string} family - 'ipv4' or 'ipv6'
 * @param {string} context - table context identifier
 */
function showTab(family, context) {
    // Hide all tabs for this context
    const allTabs = document.querySelectorAll(`[data-tab-context="${context}"]`);
    allTabs.forEach(tab => tab.style.display = 'none');

    // Show all selected tabs (can be multiple for the same family)
    const selectedTabs = document.querySelectorAll(`[data-tab-context="${context}"][data-tab-family="${family}"]`);
    selectedTabs.forEach(tab => tab.style.display = 'block');

    // Update tab buttons
    const allButtons = document.querySelectorAll(`[data-tab-btn-context="${context}"]`);
    allButtons.forEach(btn => btn.classList.remove('active'));

    const activeButton = document.querySelector(`[data-tab-btn-context="${context}"][data-tab-btn-family="${family}"]`);
    if (activeButton) {
        activeButton.classList.add('active');
    }
}

/**
 * Initialize tab button click handlers
 */
function initTabButtons() {
    document.querySelectorAll('[data-tab-btn-context]').forEach(btn => {
        btn.addEventListener('click', function() {
            const context = this.getAttribute('data-tab-btn-context');
            const family = this.getAttribute('data-tab-btn-family');
            showTab(family, context);
            saveState('fw-rules', context, family);
        });
    });
}

