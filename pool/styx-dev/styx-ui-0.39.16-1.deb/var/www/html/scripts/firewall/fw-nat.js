// fw-nat.js
// NAT Rules management: Port Forwarding, Outbound NAT, Static NAT (1:1)
// Tables are rendered server-side; JS only handles inline forms and actions.

(function () {
    'use strict';

    var setsData = window.__natSetsData || { addresses: [], ports: [], ifaces: [] };

    // ===== SET / PICKER UTILITIES =====

    function getSetIds(el) {
        if (!el) return [];
        if (el.tagName === 'SELECT') {
            return Array.from(el.selectedOptions)
                .map(function (o) { return o.value; })
                .filter(function (v) { return v !== ''; });
        }
        return (el.value || '').split(',').map(function (v) { return v.trim(); }).filter(function (v) { return v !== ''; });
    }

    function getSingleSetId(selectEl) {
        if (!selectEl || !selectEl.value) return '';
        return selectEl.value;
    }

    function filterSetsByScope(sets, allowedScopes) {
        return sets.filter(function (s) { return allowedScopes.includes(s.scope); });
    }

    function preloadPickerField(hiddenInput, ids, sets) {
        if (!hiddenInput || !ids || ids.length === 0) return;
        var cleanIds = ids.filter(function (v) { return v && v.trim() !== ''; });
        if (cleanIds.length === 0) return;
        var wrapper = hiddenInput.closest('[data-js="set-picker-field"]');
        if (!wrapper) return;
        var labelEl = wrapper.querySelector('.js-set-picker-label');
        var triggerBtn = wrapper.querySelector('.js-set-picker-open');
        var clearBtn = wrapper.querySelector('.js-set-picker-clear');
        hiddenInput.value = cleanIds.join(',');
        if (labelEl && sets) {
            var names = cleanIds.map(function (id) {
                var found = (sets || []).find(function (s) { return (s.id || s) === id; });
                return found ? (found.name || id) : id;
            });
            labelEl.textContent = names.join(', ');
        }
        if (triggerBtn) triggerBtn.classList.add('set-picker-trigger--has-value');
        if (clearBtn) clearBtn.classList.remove('sets-hidden');
    }

    function updatePickerFamilyFilter(form, family) {
        if (!form) return;
        form.querySelectorAll('[data-js="set-picker-field"][data-set-type="address"]').forEach(function (wrapper) {
            if (family) {
                wrapper.setAttribute('data-filter-family', family);
            } else {
                wrapper.removeAttribute('data-filter-family');
            }
        });
    }

    function resolvedIds(setsArr) {
        if (!Array.isArray(setsArr)) return [];
        return setsArr.map(function (s) { return s.id || s; });
    }

    function resetPickerField(hiddenInput) {
        if (!hiddenInput) return;
        var wrapper = hiddenInput.closest('[data-js="set-picker-field"]');
        if (!wrapper) return;
        var labelEl = wrapper.querySelector('.js-set-picker-label');
        var triggerBtn = wrapper.querySelector('.js-set-picker-open');
        var clearBtn = wrapper.querySelector('.js-set-picker-clear');
        hiddenInput.value = '';
        if (labelEl && triggerBtn) {
            labelEl.textContent = triggerBtn.dataset.placeholder || '';
        }
        if (triggerBtn) triggerBtn.classList.remove('set-picker-trigger--has-value');
        if (clearBtn) clearBtn.classList.add('sets-hidden');
    }

    function resetAllPickerFields(form) {
        form.querySelectorAll('[data-js="set-picker-field"] input[type="hidden"]').forEach(resetPickerField);
    }

    // ===== RELOAD HELPER =====

    function reload() {
        location.reload();
    }

    function submitAndReload(command, payload) {
        apiClient.submit(command, payload).then(function (resp) {
            if (resp.status === 'success') {
                reload();
            } else {
                showModal(resp.response_msg || 'Error.', { title: 'Error', closeText: 'Close' });
            }
        });
    }

    // ===== INLINE FORM-PORT FORWARDING =====

    var pfAbortCtrl = null;

    function hidePfForm() {
        if (pfAbortCtrl) { pfAbortCtrl.abort(); pfAbortCtrl = null; }
        var panel = document.getElementById('nat-pf-form-panel');
        if (panel) panel.classList.add('sets-hidden');
    }

    function showPfForm(rule) {
        rule = rule || {};
        var isEdit = !!rule.id;
        var panel = document.getElementById('nat-pf-form-panel');
        var form = document.getElementById('nat-pf-form');
        if (!panel || !form) return;

        form.reset();
        resetAllPickerFields(form);
        var prevId = form.querySelector('input[name="id"]');
        if (prevId) prevId.parentNode.removeChild(prevId);

        form.querySelector('#pf-name').value = rule.name || '';
        form.querySelector('#pf-family').value = rule.family || 'ip';
        form.querySelector('#pf-protocol').value = rule.protocol || '';
        form.querySelector('#pf-comment').value = rule.comment || '';
        form.querySelector('[name="enabled"]').checked = rule.enabled !== false;
        form.querySelector('.js-submit-btn').textContent = isEdit ? 'Save' : 'Create';

        if (isEdit) {
            var idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'id';
            idInput.value = rule.id;
            form.insertBefore(idInput, form.firstChild);
            var addresses = setsData.addresses || [];
            var ports = setsData.ports || [];
            var ifaces = setsData.ifaces || [];
            preloadPickerField(form.querySelector('#pf-src_ifaces'), resolvedIds(rule.src_ifaces), ifaces);
            preloadPickerField(form.querySelector('#pf-dst_ports'), resolvedIds(rule.dst_ports), ports);
            preloadPickerField(form.querySelector('#pf-src_ips'), resolvedIds(rule.src_ips), addresses);
            preloadPickerField(form.querySelector('#pf-to_set'),
                rule.to_set ? [rule.to_set.id || rule.to_set] : [], filterSetsByScope(addresses, ['host']));
            preloadPickerField(form.querySelector('#pf-to_ports'),
                rule.to_ports ? [rule.to_ports.id || rule.to_ports] : [], ports);
        }

        updatePickerFamilyFilter(form, form.querySelector('#pf-family').value);
        panel.classList.remove('sets-hidden');

        if (pfAbortCtrl) pfAbortCtrl.abort();
        pfAbortCtrl = new AbortController();
        var pfSig = pfAbortCtrl.signal;
        form.querySelector('#pf-family').addEventListener('change', function () {
            updatePickerFamilyFilter(form, this.value);
        }, { signal: pfSig });
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var data = collectPortForwardingForm(form);
            if (!data.name) { alert('Name is required.'); return; }
            if (!data.dst_ports || data.dst_ports.length === 0) { alert('Incoming port is required.'); return; }
            if (!data.to_set) { alert('Target IP is required.'); return; }
            if (!data.to_ports) { alert('Target port is required.'); return; }
            hidePfForm();
            submitAndReload('set_nat_rule', data);
        }, { signal: pfSig });
    }

    // ===== INLINE FORM-OUTBOUND NAT =====

    var obAbortCtrl = null;

    function hideObForm() {
        if (obAbortCtrl) { obAbortCtrl.abort(); obAbortCtrl = null; }
        var panel = document.getElementById('nat-ob-form-panel');
        if (panel) panel.classList.add('sets-hidden');
    }

    function showObForm(rule) {
        rule = rule || {};
        var isEdit = !!rule.id;
        var panel = document.getElementById('nat-ob-form-panel');
        var form = document.getElementById('nat-ob-form');
        if (!panel || !form) return;

        form.reset();
        resetAllPickerFields(form);
        var prevId = form.querySelector('input[name="id"]');
        if (prevId) prevId.parentNode.removeChild(prevId);

        form.querySelector('#ob-name').value = rule.name || '';
        form.querySelector('#ob-family').value = rule.family || 'ip';
        form.querySelector('#ob-action').value = rule.action || 'masquerade';
        form.querySelector('#ob-protocol').value = rule.protocol || '';
        form.querySelector('#ob-comment').value = rule.comment || '';
        form.querySelector('[name="enabled"]').checked = rule.enabled !== false;
        form.querySelector('.js-submit-btn').textContent = isEdit ? 'Save' : 'Create';

        var toSetLabel = form.querySelector('#ob-to-set-label');
        if (toSetLabel) {
            toSetLabel.style.display = (rule.action === 'snat') ? '' : 'none';
        }

        if (isEdit) {
            var idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'id';
            idInput.value = rule.id;
            form.insertBefore(idInput, form.firstChild);
            var addresses = setsData.addresses || [];
            var ifaces = setsData.ifaces || [];
            preloadPickerField(form.querySelector('#ob-to_set'),
                rule.to_set ? [rule.to_set.id || rule.to_set] : [], filterSetsByScope(addresses, ['host']));
            preloadPickerField(form.querySelector('#ob-src_ips'), resolvedIds(rule.src_ips), addresses);
            preloadPickerField(form.querySelector('#ob-dst_ifaces'), resolvedIds(rule.dst_ifaces), ifaces);
            preloadPickerField(form.querySelector('#ob-dst_ips'), resolvedIds(rule.dst_ips), addresses);
        }

        updatePickerFamilyFilter(form, form.querySelector('#ob-family').value);
        panel.classList.remove('sets-hidden');

        if (obAbortCtrl) obAbortCtrl.abort();
        obAbortCtrl = new AbortController();
        var obSig = obAbortCtrl.signal;
        form.querySelector('#ob-family').addEventListener('change', function () {
            updatePickerFamilyFilter(form, this.value);
        }, { signal: obSig });
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var data = collectOutboundForm(form);
            if (!data.name) { alert('Name is required.'); return; }
            if (data.action === 'snat' && !data.to_set) {
                alert('Fixed source IP set (to_set) is required for SNAT action.');
                return;
            }
            hideObForm();
            submitAndReload('set_nat_rule', data);
        }, { signal: obSig });
    }

    // ===== INLINE FORM-STATIC NAT =====

    var snAbortCtrl = null;

    function hideSnForm() {
        if (snAbortCtrl) { snAbortCtrl.abort(); snAbortCtrl = null; }
        var panel = document.getElementById('nat-sn-form-panel');
        if (panel) panel.classList.add('sets-hidden');
    }

    function showSnForm() {
        var panel = document.getElementById('nat-sn-form-panel');
        var form = document.getElementById('nat-sn-form');
        if (!panel || !form) return;

        form.reset();
        resetAllPickerFields(form);
        updatePickerFamilyFilter(form, form.querySelector('#sn-family').value);
        panel.classList.remove('sets-hidden');

        if (snAbortCtrl) snAbortCtrl.abort();
        snAbortCtrl = new AbortController();
        var snSig = snAbortCtrl.signal;
        form.querySelector('#sn-family').addEventListener('change', function () {
            updatePickerFamilyFilter(form, this.value);
        }, { signal: snSig });
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var data = collectStaticNatForm(form);
            if (!data.name) { alert('Name is required.'); return; }
            if (!data.to_private_set) { alert('Map to private set (to_private_set) is required.'); return; }
            if (!data.to_public_set) { alert('Map to public set (to_public_set) is required.'); return; }
            if (!data.dst_ips || data.dst_ips.length === 0) { alert('Public IP set is required.'); return; }
            if (!data.src_ips || data.src_ips.length === 0) { alert('Private IP set is required.'); return; }
            hideSnForm();
            submitAndReload('set_static_nat_rule', data);
        }, { signal: snSig });
    }

    // ===== DATA COLLECTION =====

    function collectPortForwardingForm(form) {
        var idEl = form.querySelector('[name="id"]');
        var data = {
            command: 'set_nat_rule',
            table: 'nat',
            chain: 'prerouting',
            action: 'dnat',
            nat_rule_type: 'port_forwarding',
            name: form.querySelector('#pf-name').value.trim(),
            family: form.querySelector('#pf-family').value,
            to_set: getSingleSetId(form.querySelector('#pf-to_set')),
            to_ports: getSingleSetId(form.querySelector('#pf-to_ports')),
            protocol: form.querySelector('#pf-protocol').value,
            src_ifaces: getSetIds(form.querySelector('#pf-src_ifaces')),
            dst_ports: getSetIds(form.querySelector('#pf-dst_ports')),
            src_ips: getSetIds(form.querySelector('#pf-src_ips')),
            comment: form.querySelector('#pf-comment').value,
            enabled: form.querySelector('[name="enabled"]').checked ? 1 : 0,
        };
        if (idEl) {
            data.id = idEl.value;
        }
        return data;
    }

    function collectOutboundForm(form) {
        var idEl = form.querySelector('[name="id"]');
        var action = form.querySelector('#ob-action').value;
        var data = {
            command: 'set_nat_rule',
            table: 'nat',
            chain: 'postrouting',
            nat_rule_type: 'outbound',
            name: form.querySelector('#ob-name').value.trim(),
            family: form.querySelector('#ob-family').value,
            action: action,
            src_ips: getSetIds(form.querySelector('#ob-src_ips')),
            dst_ifaces: getSetIds(form.querySelector('#ob-dst_ifaces')),
            dst_ips: getSetIds(form.querySelector('#ob-dst_ips')),
            protocol: form.querySelector('#ob-protocol').value,
            comment: form.querySelector('#ob-comment').value,
            enabled: form.querySelector('[name="enabled"]').checked ? 1 : 0,
        };
        if (action === 'snat') {
            data.to_set = getSingleSetId(form.querySelector('#ob-to_set'));
        }
        if (idEl) {
            data.id = idEl.value;
        }
        return data;
    }

    function collectStaticNatForm(form) {
        var dstIpsEl = form.querySelector('#sn-dst_ips');
        var srcIpsEl = form.querySelector('#sn-src_ips');
        var srcIfacesEl = form.querySelector('#sn-src_ifaces');
        var dstIfacesEl = form.querySelector('#sn-dst_ifaces');
        return {
            command: 'set_static_nat_rule',
            name: form.querySelector('#sn-name').value.trim(),
            family: form.querySelector('#sn-family').value,
            to_private_set: getSingleSetId(form.querySelector('#sn-to_private_set')),
            to_public_set: getSingleSetId(form.querySelector('#sn-to_public_set')),
            dst_ips: dstIpsEl && dstIpsEl.value ? [dstIpsEl.value] : [],
            src_ips: srcIpsEl && srcIpsEl.value ? [srcIpsEl.value] : [],
            src_ifaces: srcIfacesEl && srcIfacesEl.value ? [srcIfacesEl.value] : [],
            dst_ifaces: dstIfacesEl && dstIfacesEl.value ? [dstIfacesEl.value] : [],
            protocol: form.querySelector('#sn-protocol').value,
            enabled: form.querySelector('[name="enabled"]').checked ? 1 : 0,
        };
    }

    // ===== TABLE ACTION HANDLERS (server-rendered tables) =====

    function findRuleById(type, id) {
        var data = window.__natData || {};
        var arr = (type === 'portForwarding') ? (data.portForwarding || [])
                : (type === 'outbound') ? (data.outbound || [])
                : [];
        return arr.find(function (r) { return r.id === id; });
    }

    function handleTableAction(btn) {
        var js = btn.dataset.js;
        var id = btn.dataset.id;
        var name = btn.dataset.name;

        if (js === 'nat-pf-edit') {
            showPfForm(findRuleById('portForwarding', id));
        } else if (js === 'nat-ob-edit') {
            showObForm(findRuleById('outbound', id));
        } else if (js === 'nat-pf-delete' || js === 'nat-ob-delete') {
            showModal('Delete rule "<strong>' + name + '</strong>"?', {
                title: 'Confirm Delete',
                showConfirm: true,
                confirmText: 'Delete',
                closeText: 'Cancel',
                onConfirm: function () {
                    submitAndReload('delete_nat_rule', { id: id });
                },
            });
        } else if (js === 'nat-sn-delete') {
            showModal('Delete static NAT pair "<strong>' + name + '</strong>"?'
                + '<br><small>Both DNAT and SNAT rules of this pair will be deleted.</small>', {
                title: 'Confirm Delete',
                showConfirm: true,
                confirmText: 'Delete',
                closeText: 'Cancel',
                onConfirm: function () {
                    submitAndReload('delete_static_nat_rule', { id: id });
                },
            });
        } else if (js === 'nat-pf-toggle' || js === 'nat-ob-toggle' || js === 'nat-sn-toggle') {
            var enabled = btn.dataset.enabled !== '1' ? 1 : 0;
            submitAndReload('set_nat_rule_enabled', { id: id, enabled: enabled });
        }
    }

    // ===== INIT =====

    document.addEventListener('DOMContentLoaded', function () {

        // Move form HTML from <template> blocks into the inline panel containers.
        [
            { panelId: 'nat-pf-form-panel', tmplId: 'tmpl-nat-pf-form' },
            { panelId: 'nat-ob-form-panel', tmplId: 'tmpl-nat-ob-form' },
            { panelId: 'nat-sn-form-panel', tmplId: 'tmpl-nat-sn-form' },
        ].forEach(function (item) {
            var panel = document.getElementById(item.panelId);
            var tmpl = document.getElementById(item.tmplId);
            if (panel && tmpl) panel.appendChild(tmpl.content.cloneNode(true));
        });

        if (window.setsModal && typeof window.setsModal.initPickerFields === 'function') {
            window.setsModal.initPickerFields(document);
        }

        // Outbound SNAT label toggle
        var obActionSel = document.getElementById('ob-action');
        var obToSetLabel = document.getElementById('ob-to-set-label');
        if (obActionSel && obToSetLabel) {
            obActionSel.addEventListener('change', function () {
                obToSetLabel.style.display = obActionSel.value === 'snat' ? '' : 'none';
            });
        }

        // Cancel buttons
        var pfCancelBtn = document.querySelector('#nat-pf-form [data-js="nat-pf-cancel"]');
        if (pfCancelBtn) pfCancelBtn.addEventListener('click', hidePfForm);
        var obCancelBtn = document.querySelector('#nat-ob-form [data-js="nat-ob-cancel"]');
        if (obCancelBtn) obCancelBtn.addEventListener('click', hideObForm);
        var snCancelBtn = document.querySelector('#nat-sn-form [data-js="nat-sn-cancel"]');
        if (snCancelBtn) snCancelBtn.addEventListener('click', hideSnForm);

        // Create buttons
        var pfCreateBtn = document.getElementById('nat-pf-create-btn');
        if (pfCreateBtn) pfCreateBtn.addEventListener('click', function () { showPfForm(null); });
        var obCreateBtn = document.getElementById('nat-ob-create-btn');
        if (obCreateBtn) obCreateBtn.addEventListener('click', function () { showObForm(null); });
        var snCreateBtn = document.getElementById('nat-sn-create-btn');
        if (snCreateBtn) snCreateBtn.addEventListener('click', showSnForm);

        // Event delegation for server-rendered table action buttons
        var wraps = ['nat-pf-table-wrap', 'nat-ob-table-wrap', 'nat-sn-table-wrap'];
        wraps.forEach(function (id) {
            var wrap = document.getElementById(id);
            if (wrap) {
                wrap.addEventListener('click', function (e) {
                    var btn = e.target.closest('[data-js]');
                    if (btn) handleTableAction(btn);
                });
            }
        });

        // Persist active tab across reloads via sessionStorage
        restoreTab();
        var tabsBar = document.getElementById('nat-tabs');
        if (tabsBar) {
            tabsBar.addEventListener('click', function (e) {
                var btn = e.target.closest('.std-tab-btn');
                if (btn && btn.dataset.tab) {
                    try { sessionStorage.setItem('natTab', btn.dataset.tab); } catch (ex) { /* noop */ }
                }
            });
        }
    });

    function restoreTab() {
        var tab;
        try { tab = sessionStorage.getItem('natTab'); } catch (ex) { /* noop */ }
        if (!tab) return;
        var btn = document.querySelector('#nat-tabs .std-tab-btn[data-tab="' + tab + '"]');
        if (btn) btn.click();
    }

}());
