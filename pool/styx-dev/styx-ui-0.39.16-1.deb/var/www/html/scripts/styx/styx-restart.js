document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('restart-form').addEventListener('submit', function(e) {
        e.preventDefault();
        var form = this;
        var msg = document.getElementById('restart-msg');
        msg.textContent = '';
        var btns = form.querySelectorAll('button');
        btns.forEach(b => b.disabled = true);
        apiClient.submit('restart-daemon', {})
        .then(function(resp) {
            if (resp.status === 'success') {
                msg.style.color = '#2ecc40';
                msg.textContent = 'Reboot requested successfully. The gateway will reboot shortly.';
            } else {
                msg.style.color = '#e74c3c';
                msg.textContent = resp.response_msg || 'Error requesting reboot.';
                btns.forEach(b => b.disabled = false);
            }
        })
        .catch(function() {
            msg.style.color = '#e74c3c';
            msg.textContent = 'Network error while requesting reboot.';
            btns.forEach(b => b.disabled = false);
        });
    });
});
