/*
 * Sends `update_web_settings` requests containing the selected certificate id
 * as `ssl_cert_select`. The server forwards this id as `ssl_certificate_id`
 * to the gateway. Optional fields included: `https_port`, `styx_branch`,
 * and `styx_theme`.
 */
document.addEventListener('DOMContentLoaded', function() {
    const webForm = document.getElementById('web-settings-form');

    if (webForm) {
        const sel = webForm.querySelector('#ssl-cert-select');

        // Only allow submit when a certificate id is selected. Do not send paths.
        webForm.addEventListener('submit', async function(e) {
            // Require a selected id in the select
            if (!sel || !sel.value) {
                e.preventDefault();
                alert('Please select a certificate from the list before saving.');
                return;
            }

            // Prevent normal submit and POST to submit.php (StyxSubmitController)
            e.preventDefault();
            const payload = { command: 'update_web_settings', ssl_cert_select: sel.value };
            // include https_port if present
            const portField = webForm.querySelector('[name="https_port"]');
            if (portField && portField.value !== '') {
                payload.https_port = portField.value;
            }
            // include branch and theme even if the controls are disabled (JS can read them)
            const branchEl = document.getElementById('styx_branch');
            if (branchEl) {
                payload.styx_branch = branchEl.value;
            }
            const themeEl = document.getElementById('styx_theme');
            if (themeEl) {
                payload.styx_theme = themeEl.value;
            }
            const logLevelEl = document.getElementById('styx_log_level');
            if (logLevelEl) {
                payload.styx_log_level = logLevelEl.value;
            }

            try {
                const data = await apiClient.submit('update_web_settings', payload);
                showApiResult(data, { closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            }
        });
    }

    const restartBtn = document.getElementById('restart-styx-ui-btn');
    if (restartBtn) {
        restartBtn.addEventListener('click', async function() {
            if (!confirm('Are you sure you want to restart the Styx UI? The page will reload once the service is back.')) {
                return;
            }
            restartBtn.disabled = true;
            restartBtn.textContent = 'Restarting...';
            try {
                const data = await apiClient.submit('restart_styx_ui', { command: 'restart_styx_ui' });
                // apiClient.submit never throws on network errors-it returns
                // { status: 'error', response_msg: 'NetworkError...' } instead.
                // A network error is expected because the HTTP server restarts.
                if (data.status === 'error' && data.response_msg && data.response_msg.includes('NetworkError')) {
                    showApiResult(
                        { status: 'success', response_msg: 'Styx UI is restarting. The page will reload shortly.' },
                        { title: 'Restarting', closeText: 'Close', reloadOnOk: true }
                    );
                } else {
                    showApiResult(data, { closeText: 'Close', reloadOnOk: true });
                }
            } catch (err) {
                showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
            } finally {
                restartBtn.disabled = false;
                restartBtn.textContent = 'Restart Styx UI';
            }
        });
    }
});
