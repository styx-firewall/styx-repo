document.addEventListener('DOMContentLoaded', function () {
    // Backup download (fetch as blob)
    document.getElementById('backup-form').addEventListener('submit', function(e) {
        e.preventDefault();
        var msg = document.getElementById('backup-msg');
        msg.textContent = '';
        var type = document.getElementById('backup-type-select').value;
        var data = { data: { type: type } };
        apiClient.requestRaw('styx-backup-download', data)
        .then(async function(response) {
            var contentType = response.headers.get('Content-Type') || '';
            // If it's JSON, it can be an error or a backup in JSON
            if (contentType.indexOf('application/json') !== -1 && !response.headers.get('Content-Disposition')) {
                var data = await response.json();
                if (data.status === 'success' && data.result && data.result.backup_content) {
                    var filename = 'styx-backup.json';
                    if (typeof data.result.filename === 'string' && data.result.filename) {
                        filename = data.result.filename;
                    }
                    var jsonStr = JSON.stringify(data.result.backup_content, null, 2);
                    var blob = new Blob([jsonStr], {type: 'application/json'});
                    var url = window.URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.href = url;
                    a.download = filename;
                    // Anchor created programmatically; no loader attribute needed
                    document.body.appendChild(a);
                    a.click();
                    setTimeout(function() {
                        window.URL.revokeObjectURL(url);
                        document.body.removeChild(a);
                    }, 100);
                    msg.style.color = '#2ecc40';
                    msg.textContent = 'Backup downloaded.';
                    return;
                } else {
                    appLog(data);
                    msg.style.color = '#e74c3c';
                    msg.textContent = data.response_msg || 'Failed to generate backup.';
                    return;
                }
            }
            // If not, it's a file
            var disposition = response.headers.get('Content-Disposition');
            var filename = 'styx-backup.json';
            if (disposition && disposition.indexOf('filename=') !== -1) {
                filename = disposition.split('filename=')[1].replace(/"/g, '').trim();
            }
            var blob = await response.blob();
            var url = window.URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            setTimeout(function() {
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            }, 100);
            msg.style.color = '#2ecc40';
            msg.textContent = 'Backup downloaded.';
        })
        .catch(function(err) {
            msg.style.color = '#e74c3c';
            msg.textContent = 'Error downloading backup: ' +
                (err && err.message ? err.message : 'Unknown error');
        });

    });

    // Restore backup
    document.getElementById('restore-form').addEventListener('submit', function(e) {
        e.preventDefault();
        var msg = document.getElementById('restore-msg');
        msg.textContent = '';
        var fileInput = document.getElementById('backup-file');
        var type = document.getElementById('restore-type-select').value;
        if (!fileInput.files.length) {
            msg.style.color = '#e74c3c';
            msg.textContent = 'Please select a backup file.';
            return;
        }
        var btns = this.querySelectorAll('button');
        btns.forEach(b => b.disabled = true);
        var file = fileInput.files[0];
        var reader = new FileReader();
        reader.onload = function(evt) {
            var fileContent = evt.target.result;
            apiClient.submit('styx-backup-restore', { backup_json: fileContent, type: type })
            .then(function(resp) {
                appLog(resp);
                if (resp && resp.status === 'success') {
                    msg.style.color = '#2ecc40';
                    msg.textContent = 'Backup restored successfully.';
                } else {
                    msg.style.color = '#e74c3c';
                    msg.textContent = (resp && resp.response_msg) ? resp.response_msg : 'Failed to restore backup.';
                    btns.forEach(b => b.disabled = false);
                }
            })
            .catch(function() {
                msg.style.color = '#e74c3c';
                msg.textContent = 'Network error while restoring backup.';
                btns.forEach(b => b.disabled = false);
            });
        };
        reader.readAsText(file);
    });

});
