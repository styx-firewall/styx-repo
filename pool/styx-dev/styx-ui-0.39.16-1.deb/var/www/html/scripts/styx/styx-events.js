document.addEventListener('DOMContentLoaded', function () {
    // Styx Events
    document.querySelectorAll('.ack-btn').forEach(function(btn) {
        btn.addEventListener('click', function () {
            const eventId = this.getAttribute('data-id');
            const msg = document.getElementById('ack-msg');
            msg.textContent = '';
            msg.style.color = '';
            // Disable only this button while processing
            this.disabled = true;
            apiClient.submit('toggle_ack', { id: eventId })
            .then(data => {
                if (data.status === 'success') {
                    msg.style.color = '#2ecc40';
                    msg.textContent = 'Event acknowledged successfully.';
                    const row = btn.closest('tr');
                    if (row) row.remove();
                } else {
                    msg.style.color = '#e74c3c';
                    msg.textContent = data.response_msg || 'Error marking ACK';
                    this.disabled = false;
                }
            })
            .catch(() => {
                msg.style.color = '#e74c3c';
                msg.textContent = 'Network error while marking ACK';
                this.disabled = false;
            });
        });
    });
    document.querySelectorAll('.raw-btn').forEach(function(btn) {
        btn.addEventListener('click', function () {
            var raw = btn.getAttribute('data-raw') || '';
            var encoding = btn.getAttribute('data-raw-enc') || '';
            var modal = document.getElementById('raw-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'raw-modal';
                modal.style.position = 'fixed';
                modal.style.top = '0';
                modal.style.left = '0';
                modal.style.width = '100vw';
                modal.style.height = '100vh';
                modal.style.background = 'rgba(0,0,0,0.6)';
                modal.style.zIndex = '99999';
                modal.style.display = 'flex';
                modal.style.alignItems = 'center';
                modal.style.justifyContent = 'center';
                modal.innerHTML = `
                    <div
                        style="background:#222;color:#eee;padding:32px 24px;border-radius:10px;
                               min-width:340px;max-width:96vw;box-shadow:0 2px 24px #0008;">
                        <div id='raw-modal-content'></div>
                        <button id='close-raw-modal' style='margin-top:18px;'>Close</button>
                    </div>`;
                document.body.appendChild(modal);
                modal.querySelector('#close-raw-modal').onclick = function() {
                    modal.style.display = 'none';
                };
            } else {
                modal.style.display = 'flex';
            }
            var pretty = '';
            // If the template explicitly marks the payload as base64, decode and parse it.
            // Otherwise just show the raw attribute.
            if (encoding === 'b64') {
                try {
                    var decoded = atob(raw);
                    pretty = JSON.stringify(JSON.parse(decoded), null, 2);
                } catch (err) {
                    try { pretty = decoded || raw; } catch (e) { pretty = raw; }
                }
            } else {
                pretty = raw;
            }
            modal.querySelector('#raw-modal-content').innerHTML =
                `<h3>Raw Data</h3>` +
                `<pre style="max-height:350px;overflow:auto;background:#222;color:#eee;` +
                `padding:12px;border-radius:6px;">${pretty.replace(/</g,'&lt;')}</pre>`;
        });
    });
});
