function editSetting(key, value) {
    let label = key.charAt(0).toUpperCase() + key.slice(1);
    // Build the form using DOM APIs to avoid HTML string concatenation and XSS
    const form = document.createElement('form');
    form.id = 'edit-setting-form';
    form.className = 'settings-form';

    const title = document.createElement('h3');
    title.textContent = 'Edit ' + label;

    let input;
    if (key === 'timezone') {
        input = document.createElement('select');
        input.name = 'value';
        input.className = 'settings-input';

        // Prefer the browser-provided tz list when available, fallback to a reasonable set
        const tzList = (typeof Intl !== 'undefined' && typeof Intl.supportedValuesOf === 'function')
            ? Intl.supportedValuesOf('timeZone')
            : [
                'UTC','Etc/UTC','Europe/London','Europe/Paris','Europe/Berlin','Europe/Madrid',
                'America/New_York','America/Chicago','America/Denver','America/Los_Angeles',
                'Asia/Tokyo','Asia/Shanghai','Asia/Kolkata','Australia/Sydney'
            ];

        tzList.forEach(tz => {
            const opt = document.createElement('option');
            opt.value = tz;
            opt.textContent = tz;
            if (tz === (value || '')) opt.selected = true;
            input.appendChild(opt);
        });
    } else {
        input = document.createElement('input');
        input.type = 'text';
        input.name = 'value';
        input.value = value || '';
        input.className = 'settings-input';
        input.autofocus = true;
    }

    const hidden = document.createElement('input');
    hidden.type = 'hidden';
    hidden.name = 'key';
    hidden.value = key;

    const submitWrap = document.createElement('div');
    submitWrap.className = 'settings-submit-container';
    const btn = document.createElement('button');
    btn.type = 'submit';
    btn.className = 'std-btn';
    btn.textContent = 'Save';
    submitWrap.appendChild(btn);

    form.appendChild(title);
    form.appendChild(input);
    form.appendChild(hidden);
    form.appendChild(submitWrap);

    // Show modal with the form node (showModal accepts Node)
    showModal(form, { title: '' });

    // Ensure input is focused after modal is shown
    setTimeout(() => { try { input.focus(); } catch (e) { /* noop */ } }, 50);

    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        const newValue = form.elements['value'].value;
        const settingKey = form.elements['key'].value;
        const data = await apiClient.submit('update_setting', { key: settingKey, value: newValue });
        appLog('editSetting response', data);
        if (data.status === 'success') {
            const element = document.getElementById('setting-' + settingKey + '-value');
            if (element) element.textContent = newValue;
            hideModal();
            if (data.response_msg) {
                setTimeout(() => showResponse(data.response_msg, 'Result'), 150);
            }
        } else {
            hideModal();
            setTimeout(() => showResponse('Error: ' + (data.response_msg || 'Unknown error'), 'Error'), 150);
        }
    });
}

// show response message in a modal, fallback to alert if not visible
function showResponse(message, title) {
    try {
        // Use a DOM node to avoid inserting unsanitized HTML
        const p = document.createElement('p');
        p.textContent = message;
        showModal(p, { title: title || '', closeText: 'OK', modalStyle: { zIndex: '99999' } });
        // If modal not visible after a short timeout, fallback to alert
        setTimeout(() => {
            const m = document.getElementById('std-modal');
            if (!m || m.style.display === 'none') {
                alert(message);
            }
        }, 200);
    } catch (e) {
        alert(message);
    }
}


// Generic config modal builder
function openConfigModal(opts) {
    const title = opts.title || '';
    const schema = opts.schema || [];
    const values = opts.values || {};
    const onSave = opts.onSave; // async function

    let html = '';
    // render warnings if provided
    if (opts.warnings && Array.isArray(opts.warnings) && opts.warnings.length) {
        html += `<div class="alert alert-warning"><ul>`;
        opts.warnings.forEach(w => { html += `<li>${w}</li>`; });
        html += `</ul></div>`;
    }
    html += `<form id="cfg-form" class="settings-form">`;
    schema.forEach(f => {
        const val = values[f.name] ?? '';
        if (f.type === 'checkbox') {
            html += '<div class="form-group"><label>' +
                '<input type="checkbox" name="' + f.name + '" ' +
                (val ? 'checked' : '') + '/> ' + f.label +
                '</label></div>';
        } else if (f.type === 'multiselect') {
            html += '<div class="form-group"><label>' + f.label + '</label>' +
                '<select name="' + f.name + '" multiple class="form-control">';
            (f.options || []).forEach(opt => {
                const sel = (Array.isArray(val) && val.indexOf(opt) !== -1) ? 'selected' : '';
                html += `<option value="${opt}" ${sel}>${opt}</option>`;
            });
            html += `</select></div>`;
        } else {
            html += '<div class="form-group"><label>' + f.label + '</label>' +
                '<input name="' + f.name + '" type="' + f.type + '" value="' + val +
                '" class="form-control"/></div>';
        }
    });
        html += `<div class="text-center">
            <button type="submit" class="std-btn">Save</button>
        </div>`;
    html += `</form>`;

    showModal(html, { title });

    const form = document.getElementById('cfg-form');
    form.onsubmit = async function(e) {
        e.preventDefault();
        const fd = new FormData(form);
        const payload = {};
        schema.forEach(f => {
            if (f.type === 'checkbox') {
                payload[f.name] = !!form.elements[f.name].checked;
            } else if (f.type === 'multiselect') {
                payload[f.name] = Array.from(form.elements[f.name].selectedOptions).map(o => o.value);
            } else if (f.type === 'number') {
                payload[f.name] = Number(fd.get(f.name));
            } else {
                payload[f.name] = fd.get(f.name);
            }
        });

        try {
            if (typeof onSave === 'function') {
                await onSave(payload);
            }

        } catch (err) {
            alert('Error: ' + (err.message || err));
        }
    };
}

// Open SSH configuration modal: fetch current config then open modal
async function openSshConfig() {
    // Simplified: open edit modal for SSH port only (other SSH options moved elsewhere)
    try {
        const el = document.getElementById('setting-ssh_port-value');
        const current = el ? el.textContent.trim() : '';
        // reuse generic editSetting modal for a single field
        editSetting('ssh_port', current || '22');
    } catch (err) {
        console.error(err);
        alert('Failed to open SSH port editor: ' + (err.message || err));
    }
}

// Export to global so template inline onclick can use it
window.openSshConfig = openSshConfig;
window.openConfigModal = openConfigModal;

// --- DNS management ---

/**
 * Open modal to edit DNS servers (comma-separated IP list).
 * @param {string} currentValue
 */
function editDnsServers(currentValue) {
    const form = document.createElement('form');
    form.id = 'edit-dns-form';
    form.className = 'settings-form';

    const title = document.createElement('h3');
    title.textContent = 'Edit DNS Servers';

    const label = document.createElement('label');
    label.textContent = 'DNS Servers (comma-separated IPs):';
    label.htmlFor = 'dns-servers-input';

    const input = document.createElement('input');
    input.type = 'text';
    input.name = 'nameservers';
    input.id = 'dns-servers-input';
    input.value = currentValue || '';
    input.className = 'settings-input';
    input.placeholder = '8.8.8.8, 1.1.1.1';
    input.autofocus = true;

    const hint = document.createElement('p');
    hint.className = 'text-muted';
    hint.textContent = 'Enter IPs separated by commas.';

    const submitWrap = document.createElement('div');
    submitWrap.className = 'settings-submit-container';
    const btn = document.createElement('button');
    btn.type = 'submit';
    btn.className = 'std-btn';
    btn.textContent = 'Save';
    submitWrap.appendChild(btn);

    form.appendChild(title);
    form.appendChild(label);
    form.appendChild(input);
    form.appendChild(hint);
    form.appendChild(submitWrap);

    showModal(form, { title: '' });

    setTimeout(function () { try { input.focus(); } catch (e) {} }, 50);

    form.addEventListener('submit', async function (e) {
        e.preventDefault();
        const raw = form.elements['nameservers'].value.trim();
        const nameservers = raw
            ? raw.split(',').map(function (s) { return s.trim(); }).filter(Boolean)
            : [];

        // Read current search domains from the page so they aren't lost
        const searchEl = document.getElementById('setting-dns_search-value');
        const searchStr = searchEl ? searchEl.textContent.trim() : '';
        const searchDomains = searchStr
            ? searchStr.split(',').map(function (s) { return s.trim(); }).filter(Boolean)
            : [];

        const payload = { nameservers: nameservers };
        if (searchDomains.length > 0) {
            payload.search_domains = searchDomains;
        }

        const data = await apiClient.submit('set_dns', payload);
        appLog('setDns response', data);
        if (data.status === 'success') {
            document.getElementById('setting-dns_servers-value').textContent = nameservers.join(', ');
            hideModal();
            if (data.response_msg) {
                setTimeout(function () { showResponse(data.response_msg, 'Result'); }, 150);
            }
            setTimeout(function () { window.location.reload(); }, 800);
        } else {
            hideModal();
            setTimeout(function () {
                showResponse('Error: ' + (data.response_msg || 'Unknown error'), 'Error');
            }, 150);
        }
    });
}

/**
 * Open modal to edit DNS search domains (comma-separated list).
 * @param {string} currentValue
 */
function editDnsSearch(currentValue) {
    const form = document.createElement('form');
    form.id = 'edit-dns-search-form';
    form.className = 'settings-form';

    const title = document.createElement('h3');
    title.textContent = 'Edit Search Domains';

    const label = document.createElement('label');
    label.textContent = 'Search Domains (comma-separated):';
    label.htmlFor = 'dns-search-input';

    const input = document.createElement('input');
    input.type = 'text';
    input.name = 'search_domains';
    input.id = 'dns-search-input';
    input.value = currentValue || '';
    input.className = 'settings-input';
    input.placeholder = 'envigo.net, corp.local';
    input.autofocus = true;

    const hint = document.createElement('p');
    hint.className = 'text-muted';
    hint.textContent = 'Enter domains separated by commas. Leave empty to clear.';

    const submitWrap = document.createElement('div');
    submitWrap.className = 'settings-submit-container';
    const btn = document.createElement('button');
    btn.type = 'submit';
    btn.className = 'std-btn';
    btn.textContent = 'Save';
    submitWrap.appendChild(btn);

    form.appendChild(title);
    form.appendChild(label);
    form.appendChild(input);
    form.appendChild(hint);
    form.appendChild(submitWrap);

    showModal(form, { title: '' });

    setTimeout(function () { try { input.focus(); } catch (e) {} }, 50);

    form.addEventListener('submit', async function (e) {
        e.preventDefault();
        const raw = form.elements['search_domains'].value.trim();
        const searchDomains = raw
            ? raw.split(',').map(function (s) { return s.trim(); }).filter(Boolean)
            : [];

        // Read current DNS servers from the page
        const serversEl = document.getElementById('setting-dns_servers-value');
        const serversStr = serversEl ? serversEl.textContent.trim() : '';
        const nameservers = serversStr
            ? serversStr.split(',').map(function (s) { return s.trim(); }).filter(Boolean)
            : [];

        const data = await apiClient.submit('set_dns', { nameservers: nameservers, search_domains: searchDomains });
        appLog('setDns (search) response', data);
        if (data.status === 'success') {
            document.getElementById('setting-dns_search-value').textContent = searchDomains.join(', ');
            hideModal();
            if (data.response_msg) {
                setTimeout(function () { showResponse(data.response_msg, 'Result'); }, 150);
            }
            setTimeout(function () { window.location.reload(); }, 800);
        } else {
            hideModal();
            setTimeout(function () {
                showResponse('Error: ' + (data.response_msg || 'Unknown error'), 'Error');
            }, 150);
        }
    });
}

window.editDnsServers = editDnsServers;
window.editDnsSearch = editDnsSearch;
