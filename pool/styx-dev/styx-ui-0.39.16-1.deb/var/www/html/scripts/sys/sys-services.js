(function () {
    'use strict';

    function findActionFromClass(el) {
        const m = (el.className || '').match(/btn-service-(start|stop|restart|enable|disable)/);
        return m ? m[1] : null;
    }

    async function handleClick(e) {
        const btn = e.target.closest('button');
        if (!btn) return;
        const action = findActionFromClass(btn);
        if (!action) return;
        const service = btn.dataset.service;
        if (!service) return;

        const confirmMsg = action.charAt(0).toUpperCase() + action.slice(1) + ' service ' + service + '?';
        if (!confirm(confirmMsg)) return;

        try {
            const resp = await apiClient.submit('system-services', { service: service, action: action });
            showApiResult(resp, { title: 'Service action', closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult({ status: 'error', response_msg: err.message }, { title: 'Error', closeText: 'Close' });
        }
    }

    document.addEventListener('click', handleClick);
})();
