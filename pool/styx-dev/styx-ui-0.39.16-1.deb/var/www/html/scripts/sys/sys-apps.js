/**
 * sys-apps.js
 * Package management UI: install, search, remove, purge, update, upgrade.
 */
document.addEventListener('DOMContentLoaded', function() {
    // Ensure pendingTaskIds is initialised for refresh-based task tracking.
    if (typeof window.pendingTaskIds === 'undefined') {
        window.pendingTaskIds = [];
    }
    if (typeof window.lastTaskId === 'undefined') {
        window.lastTaskId = null;
    }

    function showModalResult(msg) {
        if (typeof showModal === 'function') {
            showModal(msg);
        } else if (window.showModal) {
            window.showModal(msg);
        }
    }

    function formatResponse(data) {
        let out = '';
        if (data && typeof data === 'object') {
            const payload = data.result;
            if (payload && typeof payload === 'object') {
                if (payload.packages && Array.isArray(payload.packages)) {
                    out += '<table style="width:100%;border-collapse:collapse;">';
                    out += '<thead><tr><th style="text-align:left;padding:4px 8px;">Package</th><th style="text-align:left;padding:4px 8px;">Description</th></tr></thead>';
                    out += '<tbody>';
                    payload.packages.forEach(p => {
                        const escName = p.name.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                        out += `<tr><td class="pkg-select" data-pkg="${escName}" style="padding:4px 8px;font-weight:bold;cursor:pointer;color:#4ea6ff;" title="Click to select">${escName}</td><td style="padding:4px 8px;">${p.description || ''}</td></tr>`;
                    });
                    out += '</tbody></table>';
                }
                if (payload.stdout) out += `<pre style='color:#8f8;'>${payload.stdout}</pre>`;
                if (payload.stderr) out += `<pre style='color:#f88;'>${payload.stderr}</pre>`;
                if (payload.response_msg) out += `<div>${payload.response_msg}</div>`;
            }
            if (data.response_msg) out += `<div>${data.response_msg}</div>`;
            if (out) return out;
        }
        // If not found, show the full JSON
        return `<pre>${JSON.stringify(data, null, 2)}</pre>`;
    }

    // Delegated click: picking a package name from search results fills the input and closes the modal
    document.addEventListener('click', function(e) {
        const cell = e.target.closest('.pkg-select');
        if (!cell) return;
        const pkg = cell.getAttribute('data-pkg');
        if (!pkg) return;
        const input = document.querySelector('input[name="package_name"]');
        if (input) input.value = pkg;
        if (typeof hideModal === 'function') hideModal();
        else if (window.hideModal) window.hideModal();
    });

    // Search for package
    const btnSearch = document.getElementById('btn-search-package');
            if (btnSearch) {
        btnSearch.addEventListener('click', function() {
            const pkg = document.querySelector('input[name="package_name"]').value.trim();
            if (!pkg) return showModalResult('Enter the package name');
            apiClient.submit('search-package', { package_name: pkg })
            .then(data => showModalResult(formatResponse(data)))
            .catch(e => showModalResult('Error: ' + e));
        });
    }

    // Install package
    const form = document.getElementById('sys-apps-form');
                if (form) {
                    form.addEventListener('submit', function(e) {
                        e.preventDefault();
                        const pkgInput = form.querySelector('input[name="package_name"]');
                        const pkg = pkgInput ? pkgInput.value.trim() : '';
                        if (!pkg) return showModalResult('Enter the package name');
                        apiClient.submit('install-package', { package_name: pkg })
                        .then(data => showModalResult(formatResponse(data)))
                        .catch(e => showModalResult('Error: ' + e));
                    });
                }

    // Uninstall package and purge with double confirmation
    function showConfirmModal(msg, confirmId, callback) {
        window.showModal(
            `<h3>${msg}</h3>` +
            `<button id="${confirmId}" style="margin-right:12px;">Yes, continue</button>` +
            `<button id="cancel-action">Cancel</button>`
        );
        document.getElementById(confirmId).onclick = function() {
            window.hideModal();
            callback();
        };
        document.getElementById('cancel-action').onclick = function() {
            window.hideModal();
        };
    }

    function bindRemoveButtons() {
        document.querySelectorAll('.btn-package-remove').forEach(btn => {
            btn.addEventListener('click', function() {
                const pkg = this.getAttribute('data-package');
                        showConfirmModal(
                    `Are you sure you want to uninstall <b>${pkg}</b>?`,
                    'confirm-remove-package',
                    function() {
                        apiClient.submit('uninstall-package', { package_name: pkg })
                        .then(data => showModalResult(formatResponse(data)))
                        .catch(e => showModalResult('Error: ' + e));
                    }
                );
            });
        });
    }
    bindRemoveButtons();
    function bindPurgeButtons() {
        document.querySelectorAll('.btn-package-purge').forEach(btn => {
            btn.addEventListener('click', function() {
                const pkg = this.getAttribute('data-package');
                        showConfirmModal(
                    `Are you sure you want to purge <b>${pkg}</b>?`,
                    'confirm-purge-package',
                    function() {
                        apiClient.submit('purge-package', { package_name: pkg })
                        .then(data => showModalResult(formatResponse(data)))
                        .catch(e => showModalResult('Error: ' + e));
                    }
                );
            });
        });
    }
    bindPurgeButtons();
    // Filter table rows based on the input
    const inputPkg = document.querySelector('input[name="package_name"]');
    if (inputPkg) {
        inputPkg.addEventListener('input', function() {
            const filter = this.value.trim().toLowerCase();
            document.querySelectorAll('#installed-packages-table tbody tr').forEach(row => {
                const pkgName = row.querySelector('td')?.textContent?.toLowerCase() || '';
                row.style.display = (!filter || pkgName.includes(filter)) ? '' : 'none';
            });
        });
    }

    // --- System Update / Upgrade ---
    const upgradeMsgEl = document.getElementById('upgrade-msg');

    function setUpgradeMsg(text, isError) {
        if (!upgradeMsgEl) return;
        upgradeMsgEl.textContent = text;
        upgradeMsgEl.style.color = isError ? '#e74c3c' : '#2ecc40';
    }

    function trackTask(taskId) {
        if (!taskId) return;
        if (!Array.isArray(window.pendingTaskIds)) {
            window.pendingTaskIds = [];
        }
        if (!window.pendingTaskIds.includes(taskId)) {
            window.pendingTaskIds.push(taskId);
        }
        window.lastTaskId = taskId;
    }

    // Update package lists (apt update)
    const btnUpdateLists = document.getElementById('btn-update-lists');
    if (btnUpdateLists) {
        btnUpdateLists.addEventListener('click', function() {
            this.disabled = true;
            setUpgradeMsg('Starting package list update...', false);

            apiClient.submit('update-package-lists', {}, { timeout: 30000 })
            .then(data => {
                if (data && data.status === 'success') {
                    const taskId = data.result && data.result.task_id ? data.result.task_id : null;
                    if (taskId) {
                        trackTask(taskId);
                        setUpgradeMsg('Package list update started (task: ' + taskId.slice(0, 8) + '...). Check the task panel for progress.', false);
                    } else {
                        setUpgradeMsg(data.response_msg || 'Package list update completed.', false);
                    }
                } else {
                    setUpgradeMsg('Error: ' + (data.response_msg || 'Unknown error'), true);
                }
            })
            .catch(err => {
                setUpgradeMsg('Network error: ' + (err.message || err), true);
            })
            .finally(() => {
                this.disabled = false;
            });
        });
    }

    // Upgrade packages (apt dist-upgrade)
    const btnUpgrade = document.getElementById('btn-upgrade-packages');
    if (btnUpgrade) {
        btnUpgrade.addEventListener('click', function() {
            setUpgradeMsg('Starting package upgrade...', false);
            // Confirm before upgrade
            if (typeof window.showModal === 'function') {
                const confirmHtml = '<h3>Upgrade all packages?</h3>' +
                    '<p>This will run apt dist-upgrade to upgrade all packages. This may take a while.</p>' +
                    '<button id="confirm-upgrade-run" class="std-btn std-btn-warning mr-8" style="margin-top:12px;">Yes, Upgrade</button>' +
                    '<button id="cancel-upgrade" class="std-btn">Cancel</button>';
                window.showModal(confirmHtml, { title: 'Confirm upgrade' });

                document.getElementById('confirm-upgrade-run').onclick = function() {
                    if (typeof window.hideModal === 'function') window.hideModal();
                    runUpgrade(btnUpgrade);
                };
                document.getElementById('cancel-upgrade').onclick = function() {
                    if (typeof window.hideModal === 'function') window.hideModal();
                };
            } else {
                if (confirm('Upgrade all packages?')) {
                    runUpgrade(btnUpgrade);
                }
            }
        });
    }

    function runUpgrade(btn) {
        btn.disabled = true;
        setUpgradeMsg('Starting package upgrade...', false);

        apiClient.submit('upgrade-packages', { run_update_first: true }, { timeout: 30000 })
        .then(data => {
            if (data && data.status === 'success') {
                const taskId = data.result && data.result.task_id ? data.result.task_id : null;
                if (taskId) {
                    trackTask(taskId);
                    setUpgradeMsg('Package upgrade started (task: ' + taskId.slice(0, 8) + '...). Check the task panel for progress.', false);
                } else {
                    setUpgradeMsg(data.response_msg || 'Package upgrade completed.', false);
                }
            } else {
                setUpgradeMsg('Error: ' + (data.response_msg || 'Unknown error'), true);
            }
        })
        .catch(err => {
            setUpgradeMsg('Network error: ' + (err.message || err), true);
        })
        .finally(() => {
            btn.disabled = false;
        });
    }

    const closeModalBtn = document.getElementById('close-std-modal');
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', () => {
            document.getElementById('std-modal').style.display = 'none';
        });
    }
});
