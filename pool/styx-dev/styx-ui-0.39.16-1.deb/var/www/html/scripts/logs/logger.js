/**
 * Logger.js - Robust logging system for web applications.
 *
 * Input log format:
 * {
 *   level: 'error' | 'warn' | 'info' | 'debug', // Log level
 *   message: string,                            // Main message
 *   context?: object,                           // (Optional) Additional context (user, module, etc.)
 *   stack?: string,                             // (Optional) Stacktrace if it's an error
 *   timestamp?: string                          // (Optional) ISO8601, auto-generated if not provided
 * }
 *
 * Output format (request to endpoint):
 * POST /api/log
 * Content-Type: application/json
 * Body: same as input format
 *
 * Expected response:
 * { status: "ok" } or { status: "error", message: "..." }
 *
 * Usage example:
 * const logger = new Logger({ endpoint: '/api/log', flushInterval: 3000 });
 * logger.error('Failed to save', { module: 'firewall' }, new Error('...').stack);
 * logger.info('User authenticated', { user: 'admin' });
 */

class Logger {
    constructor(options = {}) {
        this.endpoint = options.endpoint || '/api/log';
        this.defaultLevel = options.defaultLevel || 'info';
        this.buffer = [];
        this.flushInterval = options.flushInterval || 5000; // ms
        this.maxBuffer = options.maxBuffer || 10;
        this.timer = null;
        this.enabled = true;
        this.init();
    }

    init() {
        // Attempt automatic flush every X milliseconds
        this.timer = setInterval(() => this.flush(), this.flushInterval);
        // Flush on window unload
        window.addEventListener('beforeunload', () => this.flush(true));
    }

    log({ level, message, context = {}, stack = '', timestamp = null }) {
        if (!this.enabled) return;
        const entry = {
            level: level || this.defaultLevel,
            message,
            context,
            stack,
            timestamp: timestamp || new Date().toISOString()
        };
        this.buffer.push(entry);
        if (this.buffer.length >= this.maxBuffer) {
            this.flush();
        }
    }

    info(message, context = {}) {
        this.log({ level: 'info', message, context });
    }

    warn(message, context = {}) {
        this.log({ level: 'warn', message, context });
    }

    error(message, context = {}, stack = '') {
        this.log({ level: 'error', message, context, stack });
    }

    debug(message, context = {}) {
        this.log({ level: 'debug', message, context });
    }

    async flush(force = false) {
        if (!this.enabled || this.buffer.length === 0) return;
        const logsToSend = this.buffer.splice(0, this.buffer.length);
        try {
            // Send logs to the endpoint (when available) via centralized apiClient
            await apiClient.postJson(this.endpoint, logsToSend.length === 1 ? logsToSend[0] : logsToSend);
        } catch (e) {
            // If it fails, reinsert into buffer (only if not a window-unload flush)
            if (!force) this.buffer.unshift(...logsToSend);
        }
    }

    disable() {
        this.enabled = false;
        clearInterval(this.timer);
    }

    enable() {
        if (!this.enabled) {
            this.enabled = true;
            this.init();
        }
    }
}

