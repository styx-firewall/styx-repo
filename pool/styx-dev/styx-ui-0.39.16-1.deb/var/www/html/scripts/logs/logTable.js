// logTable.js
// Standard module for efficient handling of real-time logs/events tables
// - Does not redraw controls or header
// - Allows adding, updating and removing rows
// - Preserves selection and scroll
// - Designed for reuse in other views

class LogTable {
    constructor({ tableId, columns, onRowClick, rowClass }) {
        this.table = document.getElementById(tableId);
        this.columns = columns; // [{ key, label, visible }]
        this.onRowClick = onRowClick;
        this.rowClass = rowClass;
        this.selectedRowId = null;
        this.rows = new Map(); // uuid -> row data
        this.renderHeader();
    }

    renderHeader() {
        // Renders only once
        if (this.table.querySelector('thead')) return;
        const thead = document.createElement('thead');
        const tr = document.createElement('tr');
        this.columns.forEach(col => {
            const th = document.createElement('th');
            th.textContent = col.label;
            if (col.visible === false) {
                th.style.display = 'none';
            }
            tr.appendChild(th);
        });
        thead.appendChild(tr);
        this.table.appendChild(thead);
        if (!this.table.querySelector('tbody')) {
            this.table.appendChild(document.createElement('tbody'));
        }
    }

    addRows(logs, highlightNew = false) {
        // Adds multiple logs and keeps only the most recent up to the limit
        logs.forEach(log => this.addRow(log, highlightNew));
        // Remove older
        const tbody = this.table.querySelector('tbody');
        const maxRows = window.currentLimit || 200;
        while (tbody.children.length > maxRows) {
            tbody.removeChild(tbody.lastChild);
        }
    }

    addRow(log, highlightNew = false) {
        // Adds the log as-is, without deduplication or uuid/id
        const tbody = this.table.querySelector('tbody');
        const tr = document.createElement('tr');
        if (typeof this.rowClass === 'function') {
            const cls = this.rowClass(log);
            if (cls) tr.classList.add(cls);
        }
        if (highlightNew) {
            tr.classList.add('log-row-new');
        }
        this.columns.forEach(col => {
            const td = document.createElement('td');
            const raw = log[col.key] ?? '';
            // Allow render to return a DOM Node (button, link, etc.), a string
            // or any primitive. If the column explicitly sets `html: true`
            // then treat string results as HTML.
            const rendered = (typeof col.render === 'function') ? col.render(raw, log) : raw;
            try {
                if (rendered instanceof Node) {
                    td.appendChild(rendered);
                } else if (col.html === true && typeof rendered === 'string') {
                    td.innerHTML = rendered;
                } else {
                    td.textContent = rendered;
                }
            } catch (e) {
                // Fallback to text in case of cross-origin or other DOM issues
                td.textContent = String(rendered);
            }
            if (col.visible === false) {
                td.style.display = 'none';
            }
            tr.appendChild(td);
        });

        if (typeof this.onRowClick === 'function') {
            tr.addEventListener('click', () => {
                this.onRowClick(log);
            });
            tr.style.cursor = 'pointer';
        }

        tbody.insertBefore(tr, tbody.firstChild); // Insert at top
    }

    updateRow(uuid, newData) {
        if (!this.rows.has(uuid)) return;
        this.rows.set(uuid, newData);
        const tbody = this.table.querySelector('tbody');
        const tr = tbody.querySelector(`tr[data-uuid='${uuid}']`);
        if (tr) {
            this.columns.forEach((col, idx) => {
                if (col.visible !== false) {
                    tr.children[idx].textContent = newData[col.key] ?? '';
                }
            });
        }
    }

    removeRow(uuid) {
        this.rows.delete(uuid);
        const tbody = this.table.querySelector('tbody');
        const tr = tbody.querySelector(`tr[data-uuid='${uuid}']`);
        if (tr) tbody.removeChild(tr);
    }

    clearRows() {
        this.rows.clear();
        const tbody = this.table.querySelector('tbody');
        tbody.innerHTML = '';
    }

    selectRow(uuid) {
        const tbody = this.table.querySelector('tbody');
        Array.from(tbody.children).forEach(tr => tr.classList.remove('selected-row'));
        const tr = tbody.querySelector(`tr[data-uuid='${uuid}']`);
        if (tr) tr.classList.add('selected-row');
        this.selectedRowId = uuid;
    }

    getSelectedRow() {
        return this.rows.get(this.selectedRowId);
    }

    getAllRows() {
        return Array.from(this.rows.values());
    }
}

window.LogTable = LogTable;
