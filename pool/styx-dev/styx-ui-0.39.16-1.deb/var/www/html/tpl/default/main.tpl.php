<?php
/**
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 * @version 0.6
 */
/**
 * In frontend->getTpl()

 * @var array<mixed> $tdata
 */
?>
<!DOCTYPE html>
<html lang="<?= $tdata['lang'] ?>" dir="<?= $tdata['dir'] ?? 'ltr' ?>">
    <head>
        <meta charset="<?= $tdata['web_charset'] ?>" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="description" content="<?= $tdata['web_description'] ?? '' ?>">
        <link rel="shortcut icon" href="favicon.ico" />
        <meta name="referrer" content="never">
        <meta name="app-debug" content="<?= $tdata['tpl_data']['app_debug'] ? '1' : '0' ?>">
        <meta name="app-version" content="<?= $tdata['tpl_data']['app_version'] ?? '' ?>">
        <meta name="app-tz" content="<?= $tdata['tpl_data']['client_timezone'] ?>">
        <meta name="app-locale" content="<?= $tdata['tpl_data']['client_locale'] ?>">
        <title><?= $tdata['web_name'] ?></title>
        <?= $tdata['main_head'] ?>
    <!-- <style>* { border: 1px solid red;}</style>  -->
    </head>

    <body>
        <div id="loading_wrap" class="loading hidden" role="status" aria-live="polite" aria-hidden="true">
            <div class="spinner" aria-hidden="true"></div>
        </div>
        <div class="main">
            <?= $tdata['main_body'] ?>
        </div>
        <footer><?= $tdata['main_footer'] ?></footer>
        <?= $tdata['footer_script'] ?? '' ?>
        <!-- Global Modal -->
        <div id="std-modal" style="display:none;"></div>
    </body>
</html>
