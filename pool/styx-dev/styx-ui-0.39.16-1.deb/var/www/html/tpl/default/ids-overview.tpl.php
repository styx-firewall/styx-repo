<?php
/**
 * IDS/IPS Overview Template (Suricata)
 */
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
    <h1>Suricata IDS/IPS - Overview (Non Functional Template)</h1>
        <div class="content-box">
            <ul>
                <li>Engine status: <strong>Active</strong></li>
                <li>Version: <strong>7.0.2</strong></li>
                <li>Monitored interfaces: <strong>eth0, eth1</strong></li>
                <li>Loaded rules: <strong>12,345</strong></li>
                <li>Alerts last 24h: <strong>8</strong></li>
                <li>Last reload: <strong>2025-06-22 09:30</strong></li>
                <li>Auto-update rules: <strong>Enabled</strong></li>
                <li>Traffic inspected today: <strong>1.2 TB</strong></li>
            </ul>
            <div style="margin-top:1em;">
                <button class="std-btn">Restart Suricata</button>
                <button class="std-btn">Reload configuration</button>
                <button class="std-btn">View IDS/IPS logs</button>
            </div>
        </div>
        <div class="content-box" style="margin-top:2em;">
            <h2>Service and integration status</h2>
            <ul>
                <li>Suricata service: <strong>Active</strong></li>
                <li>Rule update: <strong>OK</strong></li>
                <li>Remote syslog: <strong>Connected</strong></li>
                <li>Notifications: <strong>OK</strong></li>
                <li>SIEM integration: <strong>OK</strong></li>
            </ul>
        </div>
        <div class="content-box" style="margin-top:2em;">
            <h2>Performance statistics</h2>
            <ul>
                <li>IDS/IPS CPU: <strong>23%</strong></li>
                <li>IDS/IPS Memory: <strong>512 MB</strong></li>
                <li>Packets processed today: <strong>2,345,678</strong></li>
            </ul>
        </div>
        <div class="content-box" style="margin-top:2em;">
            <h2>Latest configuration changes</h2>
            <ul>
                <li>[2025-06-21 18:00] SIEM integration enabled</li>
                <li>[2025-06-20 09:00] Added IP 10.0.0.5 to whitelist</li>
            </ul>
        </div>
        <div class="content-box" style="margin-top:2em;">
            <h2>Latest critical events</h2>
            <ul>
                <li>[10:00] Alert: Nmap Scripting Engine detected on eth0</li>
                <li>[09:45] Drop: SSH Brute Force blocked on eth1</li>
            </ul>
        </div>
    </main>
</div>
