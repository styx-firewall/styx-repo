<?php

/**
 * TemplateService->getTpl()
 *
 * Includes: sys-settings.js
 * @var array<mixed> $tdata
 */
$settings = $tdata['page_data'] ?? [];
$sys = $settings['system_info'] ?? [];
$ssh = $settings['ssh'] ?? [];
$interfaces = $settings['interfaces'] ?? [];

// DNS fields
$dnsServersStr = $settings['dns_servers_str'] ?? '';
$dnsSearchStr = $settings['dns_search_str'] ?? '';
$dnsIsConfigured = $settings['dns_is_configured'] ?? false;
$resolvLines = $settings['resolv_lines'] ?? [];
$activeSources = $settings['active_sources'] ?? [];
$isAdmin = $settings['is_admin'] ?? false;

// Use formatter-provided display strings when available (no template fallbacks)
$ssh_enabled_text = $settings['ssh_enabled_text'] ?? (
    (!empty($ssh['enabled'])) ? 'Enabled, port ' . ($ssh['port'] ?? '22') : 'Disabled'
);
$ssh_listen_text = $settings['ssh_listen_text'] ?? (
    (!empty($ssh['listen_addresses']) && is_array($ssh['listen_addresses']))
        ? implode(', ', $ssh['listen_addresses'])
        : ''
);
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>System Settings</h1>
        <h2>View, Change System Settings</h2>
        <div class="content-box">
            <?php if (!empty($settings['response_msg'])): ?>
                <div class="alert alert-danger">
                    <strong>Error:</strong> <?= $settings['response_msg'] ?>
                </div>
            <?php elseif (!empty($settings['warnings']) && is_array($settings['warnings'])): ?>
                <div class="alert alert-warning">
                    <strong>Partial data:</strong>
                    <ul>
                        <?php foreach ($settings['warnings'] as $w): ?>
                            <li><?= $w ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            <table class="std-table">
                <thead>
                    <tr>
                        <th>Setting</th>
                        <th>Value</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Hostname</td>
                        <td id="setting-hostname-value"><?= $sys['hostname'] ?? '' ?></td>
                        <td>
                            <button type="button"
                                    onclick="editSetting('hostname', '<?= $sys['hostname'] ?? '' ?>')">
                                Edit
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td>Hostname Domain</td>
                        <td id="setting-hostname_domain-value"><?= $sys['hostname_domain'] ?? '' ?></td>
                        <td>
                            <button type="button"
                                    onclick="editSetting('hostname_domain', '<?= $sys['hostname_domain'] ?? '' ?>')">
                                Edit
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td>Timezone</td>
                        <td id="setting-timezone-value"><?= $sys['timezone'] ?? '' ?></td>
                        <td>
                            <button type="button"
                                    onclick="editSetting('timezone', '<?= $sys['timezone'] ?? '' ?>')">
                                Edit
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td>Language</td>
                        <td id="setting-language-value"><?= $sys['language'] ?? '' ?></td>
                        <td>
                            <button type="button"
                                    onclick="editSetting('language', '<?= $sys['language'] ?? '' ?>')">
                                Edit
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td>SSH Port</td>
                        <td id="setting-ssh_port-value"><?= $ssh['port'] ?? '22' ?></td>
                        <td><button type="button" onclick="editSetting('ssh_port', '<?= $ssh['port'] ?? '22' ?>')">Edit</button></td>
                    </tr>
                    <tr>
                        <td>DNS Servers</td>
                        <td id="setting-dns_servers-value"><?= htmlspecialchars($dnsServersStr) ?></td>
                        <td>
                            <?php if ($isAdmin): ?>
                            <button type="button" class="std-btn"
                                    onclick="editDnsServers('<?= htmlspecialchars($dnsServersStr, ENT_QUOTES) ?>')">
                                Edit
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>DNS Search Domain</td>
                        <td id="setting-dns_search-value"><?= htmlspecialchars($dnsSearchStr) ?></td>
                        <td>
                            <?php if ($isAdmin): ?>
                            <button type="button" class="std-btn"
                                    onclick="editDnsSearch('<?= htmlspecialchars($dnsSearchStr, ENT_QUOTES) ?>')">
                                Edit
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>

            <!-- Current resolv.conf (read-only) -->
            <h3>Active DNS (read-only)</h3>
            <table class="std-table">
                <thead>
                    <tr>
                        <th>/etc/resolv.conf</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($resolvLines)): ?>
                        <tr><td><em>No data</em></td></tr>
                    <?php else: ?>
                        <?php foreach ($resolvLines as $line): ?>
                            <?php $trimmed = trim($line); ?>
                            <?php if ($trimmed !== ''): ?>
                            <tr><td><code><?= htmlspecialchars($trimmed) ?></code></td></tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php if (!empty($activeSources)): ?>
                <p class="text-muted">Active sources: <?= htmlspecialchars(implode(', ', $activeSources)) ?></p>
            <?php endif; ?>

        </div>
    </main>
</div>
