<?php
/**
 * Interface main template
 * JS included via PageNetwork footer script: /scripts/network/net-interfaces.js
 */

// Prepared by App\Pages\Fmt\NetInterfacesFormatter
// Virtual interface types provided by formatter (no fallbacks)
$virtualInterfaceTypes = $tdata['page_data']['virtualInterfaceTypes'];

?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Network interfaces</h1>

        <div class="ni-margin-bottom">
            <select class="std-select" id="create-interface-select">
                <?php foreach ($virtualInterfaceTypes as $val => $label): ?>
                    <option value="<?= $val ?>"><?= $label ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="content-box">

            <?= $tdata['physical_table'] ?? '' ?>

            <?= $tdata['virtual_table'] ?? '' ?>

        </div>
    </main>
</div>
