<?php
/**
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 * Includes:
 * serv-dhcp.js
 * css: default-dhcp.css
*/
// Page data prepared by PageServices and formatters
$pagep = $tdata['page_data'] ?? [];
/** $cfg array provided by TemplateService->getTpl */
// Features are available in $pagep if needed by fragments
?>
<script>
// JS config and feature flags provided by formatter
window.dhcp_config = <?= $tdata['page_data']['dhcp_config_json'] ?? 'null' ?>;
window.dhcpv4FeatureEnabled = <?= !empty($tdata['page_data']['dhcpv4_enabled']) ? 'true' : 'false' ?>;
window.dhcpv6FeatureEnabled = <?= !empty($tdata['page_data']['dhcpv6_enabled']) ? 'true' : 'false' ?>;
</script>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>DHCP</h1>
        <section class="content-box">
            <div class="std-tabs" id="dhcp-tabs">
                <button class="std-tab-btn active" data-tab="global">Global Configuration</button>
                <button class="std-tab-btn" data-tab="config">Interfaces Configuration</button>
                <button class="std-tab-btn" data-tab="leases">Leases</button>
            </div>
            <div class="std-tab-panel active" id="tab-global">
                <?= $tdata['serv_dhcp_global'] ?? '' ?>
            </div>
            <div class="std-tab-panel" id="tab-config">
                <?= $tdata['serv_dhcp_config'] ?? '' ?>
            </div>
            <div class="std-tab-panel" id="tab-leases">
                <?= $tdata['serv_dhcp_leases'] ?? '' ?>
            </div>
        </section>
    </main>
</div>
