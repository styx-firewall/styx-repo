<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */

$audit_rows = $tdata['page_data']['sec_audit_rows'] ?? [];
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Security Audit</h1>
        <div class="content-box">
        </div>
    </main>
</div>
