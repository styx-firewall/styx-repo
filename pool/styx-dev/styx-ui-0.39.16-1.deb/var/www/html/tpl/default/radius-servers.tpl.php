<?php

/**
 * TemplateService->getTpl()
 
 * @var array<mixed> $tdata
 */

?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Radius Servers</h1>
        <h2>Contenido Radius Servers (Non Functional Template)</h2>
        <div class="content-box">
            <table class="std-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Port</th>
                        <th>Secret</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>radius1</td>
                        <td>192.168.10.10</td>
                        <td>1812</td>
                        <td>••••••••</td>
                        <td>Online</td>
                        <td>
                            <button>Edit</button>
                            <button>Delete</button>
                        </td>
                    </tr>
                    <tr>
                        <td>radius2</td>
                        <td>192.168.10.11</td>
                        <td>1812</td>
                        <td>••••••••</td>
                        <td>Offline</td>
                        <td>
                            <button>Edit</button>
                            <button>Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <button>Add Radius Server</button>
        </div>
    </main>
</div>
