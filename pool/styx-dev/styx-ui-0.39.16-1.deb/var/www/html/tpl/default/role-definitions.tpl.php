<?php

/**
 * Role Definitions management template.
 *
 * @var array<mixed> $tdata
 */
$defs    = $tdata['page_data']['definition_rows'] ?? [];
$canMgmt = $tdata['page_data']['can_manage'] ?? false;
$groups  = $tdata['page_data']['capability_groups'] ?? [];
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Role Definitions</h1>
        <?php if (!empty($tdata['page_data']['error'])): ?>
        <div class="alert alert-error"><?= $tdata['page_data']['error'] ?></div>
        <?php endif; ?>

        <?php if ($canMgmt): ?>
        <div class="content-box">
            <h2>Create Custom Role</h2>
            <form id="create-role-form" class="std-form" data-js="create-role-form">
                <label>
                    Role name:
                    <input type="text" name="role" required placeholder="e.g. auditor" />
                </label>
                <fieldset class="caps-fieldset">
                    <legend>Capabilities</legend>
                    <?php foreach ($groups as $module => $caps): ?>
                    <div class="caps-module">
                        <strong><?= $module ?></strong>
                        <?php foreach ($caps as $cap): ?>
                        <label class="caps-label">
                            <input type="checkbox" name="cap_<?= $cap['full'] ?>" value="<?= $cap['full'] ?>" />
                            <?= $cap['action'] ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                    <?php endforeach; ?>
                </fieldset>
                <button type="submit" class="std-btn">Create</button>
                <span id="create-role-msg" class="msg"></span>
            </form>
        </div>
        <?php endif; ?>

        <div class="content-box">
            <table class="std-table">
                <thead>
                    <tr>
                        <th>Role</th>
                        <th>Type</th>
                        <th>Capabilities</th>
                        <?php if ($canMgmt): ?>
                        <th>Actions</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($defs as $def): ?>
                    <tr data-role-row="<?= $def['name'] ?>">
                        <td><?= $def['name'] ?></td>
                        <td><?= $def['builtin'] ? 'Built-in' : 'Custom' ?></td>
                        <td title="<?= $def['capabilities'] ?>">
                            <?= $def['caps_count'] ?> capability(ies)
                        </td>
                        <?php if ($canMgmt): ?>
                        <td>
                            <?php if (!$def['builtin']): ?>
                            <button data-js="edit-role-def"
                                    data-role="<?= $def['name'] ?>"
                                    data-caps='<?= $def['caps_json'] ?>'
                                    class="std-btn">Edit</button>
                            <button data-js="delete-role-def"
                                    data-role="<?= $def['name'] ?>"
                                    class="std-btn btn-danger">Delete</button>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php if ($canMgmt && !empty($groups)): ?>
<template id="edit-role-tmpl">
    <tr class="edit-row">
        <td colspan="4">
            <fieldset class="caps-fieldset caps-fieldset--inline">
                <legend>Edit <strong>__ROLE__</strong></legend>
                <?php foreach ($groups as $module => $caps): ?>
                <div class="caps-module">
                    <strong><?= $module ?></strong>
                    <?php foreach ($caps as $cap): ?>
                    <label class="caps-label">
                        <input type="checkbox" class="edit-caps-check"
                               value="<?= $cap['full'] ?>"
                               data-cap="<?= $cap['full'] ?>" />
                        <?= $cap['action'] ?>
                    </label>
                    <?php endforeach; ?>
                </div>
                <?php endforeach; ?>
                <div class="edit-actions">
                    <button data-js="save-role-def" class="std-btn">Save</button>
                    <button data-js="cancel-edit-role" class="std-btn">Cancel</button>
                </div>
            </fieldset>
        </td>
    </tr>
</template>
<?php endif; ?>
