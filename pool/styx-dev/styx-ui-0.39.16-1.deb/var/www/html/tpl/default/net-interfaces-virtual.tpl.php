<?php
/**
 * Fragment: Virtual interfaces table for net-interfaces
 * Expects $tdata['tpl_data']['virtual_interfaces']
 */
$virtual = $tdata['tpl_data']['virtual_interfaces'] ?? [];
?>
<!-- Virtual interfaces table -->
<h3>Virtual interfaces</h3>
<table class="std-table" id="virtual-interfaces-table">
    <thead>
        <tr>
            <th>Interface</th>
            <th>Parent</th>
            <th>IPv4</th>
            <th>IPv6</th>
            <th>MAC</th>
            <th>MTU</th>
            <th>Status</th>
            <th>Oper. State</th>
            <th>Actions</th>
            <th>Refs</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($virtual as $row): ?>
            <tr data-iface="<?= $row['interface'] ?? '' ?>" data-iface-id="<?= $row['iface_id'] ?? '' ?>" data-iface-type="<?= $row['iface_type'] ?? '' ?>" data-iface-subtype="<?= $row['iface_subtype'] ?? '' ?>" class="<?= $row['row_class'] ?>">
                <td><?= $row['interface'] ?? '' ?></td>
                <td><?= $row['assoc'] ?? '' ?></td>
                <td>
                    <?php foreach ($row['ipv4_rows'] ?? [] as $ip): ?>
                        <div title="<?= $ip['tooltip'] ?? '' ?>"><?= $ip['label'] ?? '' ?></div>
                    <?php endforeach; ?>
                </td>
                <td>
                    <?php foreach ($row['ipv6_rows'] ?? [] as $ip): ?>
                        <div title="<?= $ip['tooltip'] ?? '' ?>"><?= $ip['label'] ?? '' ?></div>
                    <?php endforeach; ?>
                </td>
                <td><?= $row['mac'] ?? '' ?></td>
                <td><?= $row['mtu'] ?? '' ?></td>
                <td>
                    <?php if (strtolower($row['interface'] ?? '') !== 'lo'): ?>
                        <?php if (empty($row['managed'])): ?>
                            <span class="std-badge std-badge--unmanaged">Unmanaged</span>
                        <?php else: ?>
                            <?= $row['status'] ?? '' ?>
                        <?php endif; ?>
                        <?php if (!empty($row['missing'])): ?>
                            <span class="ni-missing-label" title="Missing from system">
                                <svg
                                    class="ni-missing-icon"
                                    xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 20 20"
                                    width="16"
                                    height="16"
                                >
                                    <polygon points="10,2 19,18 1,18" fill="#FFD600" stroke="#d00" stroke-width="1.5" />
                                    <rect x="9" y="7" width="2" height="6" rx="1" fill="#d00" />
                                    <circle cx="10" cy="15.5" r="1" fill="#d00" />
                                </svg>
                            </span>
                        <?php elseif (!empty($row['warning_msg'])): ?>
                            <span class="ni-missing-label" title="<?= $row['warning_msg'] ?>">
                                <svg
                                    class="ni-missing-icon"
                                    xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 20 20"
                                    width="16"
                                    height="16"
                                >
                                    <polygon points="10,2 19,18 1,18" fill="#FFD600" stroke="#d00" stroke-width="1.5" />
                                    <rect x="9" y="7" width="2" height="6" rx="1" fill="#d00" />
                                    <circle cx="10" cy="15.5" r="1" fill="#d00" />
                                </svg>
                            </span>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if (strtolower($row['interface'] ?? '') !== 'lo'): ?>
                        <span
                            class="<?= $row['oper_led_class'] ?> iface-led"
                            title="<?= ucfirst($row['operstate'] ?? 'unknown') ?>"
                        ></span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if (empty($row['hide_actions'])): ?>
                    <button
                        type="button"
                        class="btn-delete js-delete-virtual"
                        data-action="delete-virtual"
                        data-id="<?= $row['iface_id'] ?? '' ?>"
                        title="Delete virtual interface"
                    >Delete</button>
                    <?php endif; ?>
                </td>
                <td><?= $row['refs_count'] ?? 0 ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<!-- End virtual interfaces table -->
