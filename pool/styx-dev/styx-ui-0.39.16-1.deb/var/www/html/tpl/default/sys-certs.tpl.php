<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */
// Grouped by group-key
// Template consumes `certificates_grouped` preformatted by SysCertsFormatter
$certs_grouped = $tdata['page_data']['certificates_grouped'] ?? [];
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>System Certs</h1>
        <h2>Manage System Certificates</h2>
        <?php if (!empty($tdata['page_data']['can_upload'])): ?>
        <button id="btn-upload-cert" class="std-btn upload-btn">Upload cert</button>
        <?php endif; ?>

        <!-- Upload modal (hidden by default) -->
        <div id="upload-cert-modal" class="modal-overlay">
            <div class="modal-panel">
                <h3 class="modal-title">Upload Certificate</h3>
                <div class="modal-radio-section">
                    <label class="modal-radio-label">
                        <input type="radio" name="upload-type" value="single" checked>
                        Cert (single file)
                    </label>
                    &nbsp;&nbsp;
                    <label class="modal-radio-label">
                        <input type="radio" name="upload-type" value="pair">
                        Cert + Key
                    </label>
                </div>

                <form id="upload-cert-form">
                    <div class="modal-section">
                        <label class="modal-radio-label">Optional name for certificate</label>
                        <br>
                        <input
                            type="text"
                            name="cert_name"
                            id="cert_name"
                            class="modal-input-file"
                            placeholder="e.g. my-cert.pem"
                            style="width:100%; box-sizing:border-box;"
                        />
                    </div>
                    <div id="upload-single" class="modal-section">
                        <label class="modal-radio-label">Certificate file (.pem/.crt/.cer)</label><br>
                        <input type="file" name="cert_file" accept=".pem,.crt,.cer" class="modal-input-file" />
                    </div>

                    <div id="upload-pair" class="modal-section hidden">
                        <label class="modal-radio-label">Certificate file (.pem/.crt/.cer)</label><br>
                        <input type="file" name="cert_file_pair" accept=".pem,.crt,.cer" class="modal-input-file" />
                        <br><br>
                        <label class="modal-radio-label">Private key file (.key/.priv)</label><br>
                        <input type="file" name="key_file_pair" accept=".key,.priv,.pem" class="modal-input-file" />
                    </div>

                    <div class="modal-actions">
                        <button id="btn-upload-submit" class="std-btn" type="button">Upload</button>
                        <button id="btn-upload-cancel" class="std-btn" type="button">Cancel</button>
                    </div>
                    <div id="upload-cert-msg" class="modal-msg"></div>
                </form>
            </div>
        </div>
        <div class="content-box">
            <h3>Certificates</h3>
            <?php foreach ($certs_grouped as $groupKey => $certs): ?>
                <h4 class="certs-directory">Directory:
                    <span class="std-badge std-badge--std">
                        <?= $groupKey ?>
                    </span>
                </h4>
                <table class="std-table certs-table">
                    <thead>
                        <tr>
                            <th>Cert Name</th>
                            <th>Subject</th>
                            <th>Usage</th>
                            <th>Expiration</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($certs as $cert): ?>
                        <?php
                            $dateClass = $cert['date_class'] ?? '';
                        ?>
                        <tr>
                            <td title="<?= $cert['cert_path'] ?? '' ?>"><?= $cert['name'] ?? '' ?></td>
                            <td><?= $cert['subject'] ?? '' ?></td>
                            <td><?= $cert['usage_str'] ?? '' ?></td>
                            <td class="<?= $dateClass ?>"><?= $cert['expiration'] ?? '' ?></td>
                            <td>
                                <?php if (!empty($cert['id']) && !empty($cert['can_delete'])): ?>
                                    <button data-cert-id="<?= $cert['id'] ?>" class="btn-delete">
                                        Delete
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endforeach; ?>
        </div>
    </main>
</div>
