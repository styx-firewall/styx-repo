<?php
/**
 * Fragment: Interfaces configuration and reservations for serv-dhcp
 * Expects formatter-provided values in $tdata['tpl_data']:
 * - iface_list (normalized with first_ipv4/first_netmask/first_ipv6/first_prefix)
 * - dhcpv4_enabled (bool)
 * - dhcpv6_enabled (bool)
 * - dhcp_config (structure)
 * - sets_range, sets_gateway, sets_dns, sets_domain_single
 * js: serv-dhcp-global.js
 * css: default-dhcp.css
 */
$pagep        = $tdata['tpl_data'];
$iface_list     = $pagep['iface_list'] ?? [];
$dhcpv4_enabled = !empty($pagep['dhcpv4_enabled']);
$dhcpv6_enabled = !empty($pagep['dhcpv6_enabled']);
?>
<div id="dhcp-forms-block">
    <!-- Interface selector moved outside the form -->
    <div class="form-row dhcp-iface-row">
        <div class="dhcp-iface-warning-col">
            <div id="dhcp-iface-warning" class="std-error-box"></div>
        </div>
        <div class="dhcp-iface-flex">
            <div class="dhcp-iface-col">
                <label for="interface" class="dhcp-iface-label">Interface</label>
                <select id="interface" name="interface" class="std-select dhcp-iface-select" required>
                        <?php if (!empty($iface_list)): ?>
                            <option value="" selected>Select an interface</option>
                            <?php foreach ($iface_list as $iface): ?>
                                <option
                                    value="<?= $iface['id'] ?? '' ?>"
                                    data-name="<?= $iface['interface'] ?? '' ?>"
                                    data-ipv4="<?= $iface['first_ipv4'] ?? '' ?>"
                                    data-netmask="<?= $iface['first_netmask'] ?? '' ?>"
                                    data-ipv6="<?= $iface['first_ipv6'] ?? '' ?>"
                                    data-prefix="<?= $iface['first_prefix'] ?? '' ?>"
                                >
                                    <?= $iface['interface'] ?? '' ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No interfaces found</option>
                        <?php endif; ?>
                </select>
            </div>
            <div class="dhcp-iface-info-wrap">
                <div id="iface-info-block" class="dhcp-iface-info">
                    <span id="iface-ipv4-info">
                        IPv4: <span class="iface-ipv4-value">-</span>
                        <span class="dhcp-slash">/</span>
                        <span class="iface-netmask-value">-</span>
                    </span>
                    <br>
                    <span id="iface-ipv6-info">
                        IPv6: <span class="iface-ipv6-value">-</span>
                        <span class="dhcp-slash">/</span>
                        <span class="iface-prefix-value">-</span>
                    </span>
                </div>
            </div>
        </div>
    </div>
    <form id="dhcp-config-form" method="post" action="submit.php" class="std-form dhcp-config-form">
        <input type="hidden" name="interface_id" id="dhcp-config-interface-id" value="">
        <h2 class="dhcp-config-title">DHCP Server Configuration</h2>
        <div class="form-row dhcp-config-row">
            <div class="form-col dhcp-config-col">
                <label for="dhcpv4_enabled" class="dhcp-config-label">Enable DHCPv4</label>
                <label class="std-switch">
                    <input type="hidden" name="dhcpv4_enabled" value="0">
                    <input
                        type="checkbox"
                        id="dhcpv4_enabled"
                        name="dhcpv4_enabled"
                        value="1"
                        <?= $dhcpv4_enabled ? '' : 'disabled' ?>
                    >
                    <span class="std-switch-slider" data-off="Off" data-on="On"></span>
                </label>
            </div>
            <div class="form-col dhcp-config-col">
                <label for="dhcpv6_enabled" class="dhcp-config-label">Enable DHCPv6</label>
                <label class="std-switch">
                    <input type="hidden" name="dhcpv6_enabled" value="0">
                    <input
                        type="checkbox"
                        id="dhcpv6_enabled"
                        name="dhcpv6_enabled"
                        value="1"
                        <?= $dhcpv6_enabled ? '' : 'disabled' ?>
                    >
                    <span class="std-switch-slider" data-off="Off" data-on="On"></span>
                </label>
            </div>
        </div>
        <div id="dhcpv4-config-block" class="dhcpv4-config-block">
            <h3 class="dhcpv4-title">
                <span class="dhcpv4-title-main">IPv4</span>
                <span class="dhcpv4-title-icon">🟦</span>
            </h3>
            <div class="form-row dhcpv4-row1">
                <div class="form-col dhcpv4-col1">
                    <label for="lease_time">Lease (s)
                        <span class="js-info-icon" data-info-modal="help-lease-time"></span>
                    </label>
                    <input
                        type="number"
                        id="lease_time"
                        name="lease_time"
                        class="input-number dhcpv4-input1"
                        min="<?= $pagep['dhcp_timer_min'] ?>" max="<?= $pagep['dhcp_timer_max'] ?>"
                        value="3600"
                    >
                </div>
            </div>
            <div class="form-row dhcpv4-row2">
                <div class="form-col dhcpv4-col2">
                    <label for="range_set_id">Pool/Range
                        <span class="js-info-icon" data-info-modal="help-range"></span>
                    </label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-filter-type="range" data-filter-family="ip" data-max-select="1">
                        <input type="hidden" name="range_set_id" id="range_set_id" value="">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select range">
                            <span class="js-set-picker-label">Select range</span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear selection">&#215;</button>
                    </div>
                </div>
                <div class="form-col dhcpv4-col2">
                    <label for="gateway_set_id">Gateway
                        <span class="js-info-icon" data-info-modal="help-gateway"></span>
                    </label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-filter-family="ip" data-max-select="1">
                        <input type="hidden" name="gateway_set_id" id="gateway_set_id" value="">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select gateway">
                            <span class="js-set-picker-label">Select gateway</span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear selection">&#215;</button>
                    </div>
                </div>
            </div>
            <div class="form-row dhcpv4-row2">
                <div class="form-col dhcpv4-col2">
                    <label for="dns_set_id">DNS
                        <span class="js-info-icon" data-info-modal="help-dns"></span>
                    </label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-max-select="1">
                        <input type="hidden" name="dns_set_id" id="dns_set_id" value="">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select DNS">
                            <span class="js-set-picker-label">Select DNS</span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear selection">&#215;</button>
                    </div>
                </div>
                <div class="form-col dhcpv4-col2">
                    <label for="domain_set_id">Domain
                        <span class="js-info-icon" data-info-modal="help-domain"></span>
                    </label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="domain" data-max-select="1">
                        <input type="hidden" name="domain_set_id" id="domain_set_id" value="">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select domain">
                            <span class="js-set-picker-label">Select domain</span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear selection">&#215;</button>
                    </div>
                </div>
            </div>
        </div>
        <div id="dhcpv6-config-block" class="dhcpv6-config-block">
            <h3 class="dhcpv6-title">
                <span class="dhcpv6-title-main">IPv6</span>
                <span class="dhcpv6-title-icon">🟩</span>
            </h3>
            <div class="form-row dhcpv6-row2">
                <div class="form-col dhcpv6-col2">
                    <label for="range6_set_id">IPv6 Range
                        <span class="js-info-icon" data-info-modal="help-range6"></span>
                    </label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-filter-type="range" data-filter-family="ip6" data-max-select="1">
                        <input type="hidden" name="range6_set_id" id="range6_set_id" value="">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select IPv6 range">
                            <span class="js-set-picker-label">Select IPv6 range</span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear selection">&#215;</button>
                    </div>
                </div>
                <div class="form-col dhcpv6-col2">
                    <label for="gateway6_set_id">Gateway IPv6
                        <span class="js-info-icon" data-info-modal="help-gateway6"></span>
                    </label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-filter-family="ip6" data-max-select="1">
                        <input type="hidden" name="gateway6_set_id" id="gateway6_set_id" value="">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select gateway IPv6">
                            <span class="js-set-picker-label">Select gateway IPv6</span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear selection">&#215;</button>
                    </div>
                </div>
            </div>
            <div class="form-row dhcpv6-row2">
                <div class="form-col dhcpv6-col2">
                    <label for="dns6_set_id">DNS IPv6
                        <span class="js-info-icon" data-info-modal="help-dns6"></span>
                    </label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="address" data-filter-family="ip6" data-max-select="1">
                        <input type="hidden" name="dns6_set_id" id="dns6_set_id" value="">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select DNS IPv6">
                            <span class="js-set-picker-label">Select DNS IPv6</span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear selection">&#215;</button>
                    </div>
                </div>
                <div class="form-col dhcpv6-col2">
                    <label for="domain6_set_id">Domain IPv6
                        <span class="js-info-icon" data-info-modal="help-domain6"></span>
                    </label>
                    <div class="set-picker-field" data-js="set-picker-field" data-set-type="domain" data-max-select="1">
                        <input type="hidden" name="domain6_set_id" id="domain6_set_id" value="">
                        <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open" data-placeholder="Select domain IPv6">
                            <span class="js-set-picker-label">Select domain IPv6</span>
                        </button>
                        <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden" title="Clear selection">&#215;</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-row dhcp-btn-row">
            <button type="submit" class="std-btn dhcp-btn-save">Save</button>
        </div>

        <!-- Help content for DHCP Config (referenced by data-info-modal) -->
        <div id="help-lease-time" class="dhcp-help">
            <p><strong>Lease</strong>: Default lease duration (in seconds) assigned to IPv4 clients on this interface.</p>
        </div>

        <div id="help-range" class="dhcp-help">
            <p><strong>Range</strong>: Select an address range set that defines the pool of IPv4 addresses for clients on this interface.</p>
        </div>

        <div id="help-gateway" class="dhcp-help">
            <p><strong>Gateway</strong>: Choose a gateway set to provide gateway IPs to DHCP clients (option router).</p>
        </div>

        <div id="help-dns" class="dhcp-help">
            <p><strong>DNS</strong>: Select a DNS server set to be delivered to DHCP clients.</p>
        </div>

        <div id="help-domain" class="dhcp-help">
            <p><strong>Domain</strong>: Select the domain name provided to clients via DHCP.</p>
        </div>

        <div id="help-range6" class="dhcp-help">
            <p><strong>IPv6 Range</strong>: Address pool for IPv6 clients (prefixes or ranges depending on implementation).</p>
        </div>

        <div id="help-gateway6" class="dhcp-help">
            <p><strong>Gateway IPv6</strong>: Gateway address(es) provided to IPv6 clients.</p>
        </div>

        <div id="help-dns6" class="dhcp-help">
            <p><strong>DNS IPv6</strong>: IPv6 DNS servers to provide to clients.</p>
        </div>

        <div id="help-domain6" class="dhcp-help">
            <p><strong>Domain IPv6</strong>: Domain name for IPv6 clients.</p>
        </div>

    </form>

    <form id="dhcp-reservations-form" method="post" action="submit.php" class="std-form dhcp-resv-form">
        <input type="hidden" name="interface_id" id="dhcp-reservations-interface-id" value="">
        <h2 class="dhcp-resv-title">DHCP Reservations</h2>
        <div id="reservations-v4-block" class="dhcp-resv4-block">
            <h3 class="dhcp-resv4-title">
                <span class="dhcp-resv4-title-main">IPv4 Reservations</span>
                <span class="dhcp-resv4-title-icon">🟦</span>
            </h3>
            <div class="form-row dhcp-resv4-row">
                <div class="form-col dhcp-resv-col">
                    <label>Reservations (MAC &rarr; IP)</label>
                    <table id="reservations-table" class="std-table dhcp-resv4-table">
                        <thead>
                            <tr>
                                <th class="dhcp-resv-th48">MAC Address</th>
                                <th class="dhcp-resv-th48">IP Address</th>
                                <th class="dhcp-resv-th4"></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    <button
                        type="button"
                        class="std-btn dhcp-resv4-btn"
                        id="add-reservation-btn"
                    >Add Reservation</button>
                    <input type="hidden" name="reservations" id="reservations-json">
                </div>
            </div>
        </div>
        <div id="reservations-v6-block" class="dhcp-resv6-block">
            <h3 class="dhcp-resv6-title">
                <span class="dhcp-resv6-title-main">IPv6 Reservations</span>
                <span class="dhcp-resv6-title-icon">🟩</span>
            </h3>
            <div class="form-row dhcp-resv6-row">
                <div class="form-col dhcp-resv-col">
                    <label>Reservations (DUID &rarr; IPv6)</label>
                    <table id="reservations6-table" class="std-table dhcp-resv6-table">
                        <thead>
                            <tr>
                                <th class="dhcp-resv-th48">DUID</th>
                                <th class="dhcp-resv-th48">IPv6 Address</th>
                                <th class="dhcp-resv-th4"></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    <button
                        type="button"
                        class="std-btn dhcp-resv6-btn"
                        id="add-reservation6-btn"
                    >Add Reservation</button>
                    <input type="hidden" name="reservations6" id="reservations6-json">
                </div>
            </div>
        </div>
        <div class="form-row dhcp-btn-row">
            <button type="submit" class="std-btn dhcp-btn-save-resv">Save Reservations</button>
        </div>
    </form>
</div>
