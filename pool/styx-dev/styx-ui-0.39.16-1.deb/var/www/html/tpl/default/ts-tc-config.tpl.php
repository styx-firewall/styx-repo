<?php
/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
*/

// Backend-provided tc_config and helpers from formatter
$tdata['tc_config'] = $tdata['page_data']['tc_config'] ?? [];
$tc_qdiscs = $tdata['page_data']['tc_qdiscs'] ?? [];
$qdisc_with_classes = $tdata['page_data']['qdisc_with_classes'] ?? [];
$qdiscs_data = $tdata['page_data']['qdiscs_data'] ?? [];
$channels_data = $tdata['page_data']['channels_data'] ?? [];
$qdisc_select_options = $tdata['page_data']['qdisc_select_options'] ?? [];
$cmd_warnings = $tdata['page_data']['cmd_warnings'] ?? [];

?>

<?php if (!empty($cmd_warnings)): ?>
<div class="tc-warnings-box">
    <strong>Warnings:</strong>
    <ul>
        <?php foreach ($cmd_warnings as $w): ?>
            <li><?= $w ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>QoS/Traffic Control - QDISC and Classes</h1>
        <div class="content-box">
            <!-- Row: Qdisc configuration per interface -->
            <h2>Qdisc per Interface</h2>
            <table class="std-table">
                            <thead>
                                <tr>
                                    <th>Interface</th>
                                    <th>ID Root</th>
                                    <th>Qdisc</th>
                                    <th>Parameters</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="qdiscs-table-body">
                                <?php foreach ($qdiscs_data as $row): ?>
                                <tr>
                                    <td><?= $row['interface_name'] ?? '' ?> <?= $row['warn_html'] ?? '' ?></td>
                                    <td><?= $row['handle'] ?? '' ?></td>
                                    <td><?= $row['kind_label'] ?? '' ?></td>
                                    <td><?= $row['params'] ?? '' ?></td>
                                    <td>
                                        <button
                                            class="btn btn-warning btn-sm js-edit-qdisc"
                                            data-iface-uuid="<?= $row['interface_uuid'] ?? '' ?>"
                                            data-kind="<?= $row['kind'] ?? '' ?>"
                                            data-handle="<?= $row['handle'] ?? '' ?>"
                                            data-params="<?= $row['params'] ?? '' ?>"
                                        >Edit</button>
                                        <button
                                            class="btn btn-danger btn-sm js-delete-qdisc"
                                            data-iface-uuid="<?= $row['interface_uuid'] ?? '' ?>"
                                        >Delete</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
        </div>

        <!-- Fila : Canales (clases) por interfaz/qdisc -->
        <div class="content-box">
            <h2>Channels per Interface/Qdisc</h2>
            <table class="std-table">
                            <thead>
                                <tr>
                                    <th>Class Name</th>
                                    <th>Interface</th>
                                    <th>Type</th>
                                    <th>Channel ID</th>
                                    <th>Parent</th>
                                    <th>Parameters</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="channels-table-body">
                                <?php foreach ($channels_data as $row): ?>
                                <tr>
                                    <td><?= $row['classname'] ?? '' ?></td>
                                    <td><?= $row['interface_name'] ?? '' ?> <?= $row['warn_html'] ?? '' ?></td>
                                    <td><?= $row['class_type'] ?? '' ?></td>
                                    <td><?= $row['handle'] ?? '' ?></td>
                                    <td><?= $row['parent'] ?? '' ?></td>
                                    <td><?= $row['params'] ?? '' ?></td>
                                    <td>
                                        <button
                                            class="btn btn-danger btn-sm js-delete-channel"
                                            data-id="<?= $row['id'] ?? '' ?>"
                                            data-iface-uuid="<?= $row['interface_uuid'] ?? '' ?>"
                                        >Delete</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <form
                            id="add-channel-form"
                            data-action="add-channel"
                            class="tc-add-channel-form"
                        >
                            <div class="tc-flex-1">
                                <label class="form-label">Class Name:</label>
                                <input
                                    type="text"
                                    class="form-control"
                                    name="classname"
                                    maxlength="32"
                                    size="16"
                                    placeholder="Ex: VoIP, Bulk, Default"
                                >
                            </div>
                            <div class="tc-flex-2">
                                <label class="form-label">Qdisc/Interface:</label>
                                <?php
                                $qdisc_with_classes = ['htb', 'hfsc', 'prio'];
                                ?>
                                <select class="form-select" name="qdisc_iface" id="qdisc-iface-select" required>
                                    <option value="">-- Select Qdisc/Interface --</option>
                                    <?php foreach ($qdisc_select_options as $opt): ?>
                                        <option value="<?= $opt['value'] ?>"><?= $opt['label'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="tc-flex-0-7">
                                <label class="form-label">Parent:</label>
                                <input
                                    type="text"
                                    class="form-control tc-max-w-90"
                                    name="parent"
                                    placeholder="Ex: 1:"
                                    required
                                    maxlength="6"
                                    size="6"
                                >
                            </div>
                            <div class="tc-flex-0-9">
                                <label class="form-label">Class ID:</label>
                                <input
                                    type="text"
                                    class="form-control tc-max-w-110"
                                    name="classid"
                                    placeholder="Ex: 1:10"
                                    required
                                    maxlength="8"
                                    size="8"
                                >
                            </div>
                            <div class="tc-flex-2">
                                <label class="form-label">Parameters:</label>
                                <input
                                    type="text"
                                    class="form-control"
                                    name="params"
                                    maxlength="255"
                                    size="40"
                                    placeholder="Ex: rate 10mbit ceil 20mbit prio 1"
                                >
                            </div>
                            <div class="tc-flex-2">
                                <label class="form-label">Child Qdisc (optional):</label>
                                <div class="tc-flex-row-center">
                                    <select
                                        class="form-select tc-select-width-auto"
                                        name="child_qdisc_kind"
                                        id="child-qdisc-kind-select"
                                    >
                                        <option value="">None</option>
                                        <?php foreach ($tc_qdiscs as $k => $v): ?>
                                            <option value="<?= $k ?>"><?= $v ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <input
                                        type="text"
                                        class="form-control tc-child-qdisc-params"
                                        name="child_qdisc_params"
                                        id="child-qdisc-params-input"
                                        placeholder="Ex: limit 1000 flows 1024 ecn"
                                    >
                                </div>
                            </div>
                            <div class="tc-flex-1 tc-align-self-end">
                                <button type="submit" class="btn btn-success">
                                    Add Channel
                                </button>
                            </div>
                        </form>
        </div>
    </main>
</div>
