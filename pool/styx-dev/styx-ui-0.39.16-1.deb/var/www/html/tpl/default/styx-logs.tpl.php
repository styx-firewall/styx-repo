<?php

/**
 * TemplateService->getTpl()
 * @var array<mixed> $tdata
 *
 * Response Handle
 * logs-parser.js (used in sys-logs and styx-logs)
 */

// Levels and limit prepared by StyxLogsFormatter (trusted)
$levels = $tdata['page_data']['levels_options'];
$limit = $tdata['page_data']['limit'];
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Styx Logs</h1>
        <div class="content-box">
            <form method="get" class="std-form" id="styx-logs-form" style="max-width:600px;">
                <div class="form-row">
                    <div class="form-col">
                        <label>Level
                            <select
                                name="level"
                                class="std-select"
                                id="log-level"
                            >
                                <?php foreach ($levels as $lvl): ?>
                                    <option
                                        value="<?= $lvl['value'] ?>"
                                        <?php if (!empty($lvl['selected'])): ?> selected<?php endif; ?>
                                    >
                                        <?= $lvl['value'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    </div>
                    <div class="form-col">
                        <label>Logs count
                            <input
                                type="number"
                                name="limit"
                                class="std-input"
                                id="log-limit"
                                min="10"
                                max="1000"
                                step="10"
                                value="<?= intval($limit) ?>"
                            >
                        </label>
                    </div>
                    <div class="form-col align-self-end">
                        <button type="submit" class="std-btn">Filter / Refresh</button>
                    </div>
                </div>
            </form>
            <table class="std-table" id="styx-logs-table">
                <thead>
                    <tr>
                        <th class="date-col mono">Date</th>
                        <th>Level</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody id="styx-logs-tbody">
                    <!-- JS will populate logs here -->
                </tbody>
            </table>
        </div>
    </main>
</div>
