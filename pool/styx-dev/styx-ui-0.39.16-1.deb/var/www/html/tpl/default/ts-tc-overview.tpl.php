<?php
// Backend data contract for TC statistics ($tdata['tc_stats']):
//
// Structure per interface (example):
// $tdata['tc_stats'][iface] = [
//     'qdisc' => string,
//     'id_root' => string,
//     'rate' => string,
//     'stats' => [ 'bytes'=>int, 'packets'=>int, 'drops'=>int, 'overlimits'=>int, 'backlog'=>string, 'q_len'=>int ],
//     'children' => [ /* recursive children arrays */ ]
// ];
//
// The formatter moves display preparation (sankey links and stats rows) into App\Pages\Fmt\TsTcOverviewFormatter.
/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */
// Template consumes preformatted data when available
$tc_stats = $tdata['page_data']['tc_stats_formatted'] ?? $tdata['page_data']['tc_stats'] ?? [];
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>QoS / Traffic Control - Overview</h1>
        <div class="content-box">
            <?php // Formatter moved recursive functions into App\Pages\Fmt\TsTcOverviewFormatter ?>
            <div class="tc-grid">
                <?php foreach ($tc_stats as $iface => $data): ?>
                    <?php
                    // Use formatter-provided fields when available
                    $div_id      = $data['div_id']      ?? ('sankey_tc_' . $iface);
                    $iface_label = $data['iface_label']  ?? $iface;
                    $flows_json  = $data['flows_json']   ?? '[]';
                    $root_stats  = $data['root_stats']   ?? [];
                    $stats_rows_html = $data['stats_rows_html'] ?? '';
                    $qdisc_label = $data['qdisc_label']  ?? (strtoupper($root_stats['qdisc'] ?? '') . ' (root)');
                    ?>
                    <div class="tc-item">
                        <h3 class="tc-h3">
                            Traffic flow:
                            <?= $iface_label ?>
                            (<?= $qdisc_label ?>)
                        </h3>
                        <div id="<?= $div_id ?>" class="tc-sankey"></div>
                        <script>
                        var tcFlows_<?= $iface ?> = <?= $flows_json ?>;
                        if (window.google && window.google.charts) {
                            window.google.charts.load('current', { 'packages': ['sankey'] });
                            window.google.charts.setOnLoadCallback(function() {
                                if (typeof window.drawSankey === 'function') {
                                    window.drawSankey('<?= $div_id ?>', tcFlows_<?= $iface ?>);
                                }
                            });
                        }
                        </script>
                        <div class="tc-stats">
                            <h4 class="tc-h4">Channel statistics:</h4>
                            <table class="std-table tc-table">
                                <thead>
                                    <tr>
                                        <th>Channel</th>
                                        <th>Bytes</th>
                                        <th>Packets</th>
                                        <th>Drops</th>
                                        <th>Overlimits</th>
                                        <th>Backlog</th>
                                        <th>Qlen</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($root_stats)): ?>
                                        <?php
                                            $root_qdisc   = strtoupper($root_stats['qdisc'] ?? '');
                                            $root_bytes   = $root_stats['bytes_formatted'] ?? '-';
                                            $root_packets = $root_stats['packets'] ?? '-';
                                            $root_drops   = $root_stats['drops'] ?? '-';
                                            $root_over    = $root_stats['overlimits'] ?? '-';
                                            $root_backlog = $root_stats['backlog_formatted'] ?? '-';
                                            $root_q_len   = $root_stats['q_len'] ?? '-';
                                        ?>
                                        <tr>
                                            <td><?= $root_qdisc ?> (root)</td>
                                            <td><?= $root_bytes ?></td>
                                            <td><?= $root_packets ?></td>
                                            <td><?= $root_drops ?></td>
                                            <td><?= $root_over ?></td>
                                            <td><?= $root_backlog ?></td>
                                            <td><?= $root_q_len ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <?= $stats_rows_html ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </main>
</div>
