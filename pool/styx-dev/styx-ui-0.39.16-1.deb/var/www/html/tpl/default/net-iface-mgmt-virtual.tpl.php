<?php
/**
 * Fragment: virtual interface specific fields (veth)
 * Expects $tdata with tpl_data
 */

// Trust formatter-provided tpl_data entirely.
$action = $tdata['tpl_data']['action'];
$iface_type = $tdata['tpl_data']['iface_type'];
$iface_subtype = $tdata['tpl_data']['iface_subtype'] ?? '';
$iface_config = $tdata['tpl_data']['iface_config'];
$ip_mode = $tdata['tpl_data']['ip_mode'];

$ipv4_resolved = $tdata['tpl_data']['ipv4_resolved'];
$ipv6_resolved = $tdata['tpl_data']['ipv6_resolved'];
$ipv4_selected = $tdata['tpl_data']['ipv4_selected'];
$ipv6_selected = $tdata['tpl_data']['ipv6_selected'];

if ($iface_subtype === 'veth'): ?>
    <label>
        Peer name
        <input
            type="text"
            name="peer_name"
            value="<?= $iface_config['peer_name'] ?>"
            required
        >
    </label>
    <label>
        IP mode
        <select name="ip_mode" id="ip_mode_select" class="std-select" required>
            <option value="static" <?= $ip_mode === 'static' ? 'selected' : '' ?>>Static</option>
            <option value="dhcp" <?= $ip_mode === 'dhcp' ? 'selected' : '' ?>>DHCP</option>
            <option value="none" <?= $ip_mode === 'none' ? 'selected' : '' ?>>No IP</option>
        </select>
    </label>
    <div id="ip_mode_static" class="im-hide">
        <div id="ipv4-block">
            <label>IPv4 addresses</label>
            <?php foreach ($ipv4_selected as $sel_id):
                $sel_name = '';
                foreach ($ipv4_resolved as $opt) {
                    if (($opt['id'] ?? '') === $sel_id) {
                        $sel_name = $opt['name'] ?? ($opt['id'] ?? '');
                        break;
                    }
                }
                $has_val = !empty($sel_id);
            ?>
            <div class="ipv4-row">
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="address" data-filter-family="ip" data-filter-scope="host_prefix" data-max-select="1">
                    <input type="hidden" name="ipv4[]" value="<?= $has_val ? $sel_id : '' ?>">
                    <button type="button"
                        class="std-btn-picker set-picker-trigger js-set-picker-open<?= $has_val ? ' set-picker-trigger--has-value' : '' ?>"
                        data-placeholder="Select IPv4 address">
                        <span class="js-set-picker-label"><?= $has_val ? $sel_name : 'Select IPv4 address' ?></span>
                    </button>
                    <button type="button"
                        class="std-btn-picker set-picker-clear js-set-picker-clear<?= $has_val ? '' : ' sets-hidden' ?>"
                        title="Clear selection">&#215;</button>
                </div>
                <button type="button" class="remove-ipv4" onclick="removeIpRow(this, 'ipv4')">Remove</button>
            </div>
            <?php endforeach; ?>
            <button type="button" onclick="addIpRow('ipv4')">Add IPv4</button>
            <template id="ipv4-picker-template">
                <div class="ipv4-row">
                    <div class="set-picker-field" data-js="set-picker-field"
                        data-set-type="address" data-filter-family="ip" data-filter-scope="host_prefix" data-max-select="1">
                        <input type="hidden" name="ipv4[]" value="">
                        <button type="button"
                            class="std-btn-picker set-picker-trigger js-set-picker-open"
                            data-placeholder="Select IPv4 address">
                            <span class="js-set-picker-label">Select IPv4 address</span>
                        </button>
                        <button type="button"
                            class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                    <button type="button" class="remove-ipv4" onclick="removeIpRow(this, 'ipv4')">Remove</button>
                </div>
            </template>
        </div>
        <div id="ipv6-block" class="im-margin-top">
            <label>IPv6 addresses</label>
            <?php foreach ($ipv6_selected as $sel_id):
                $sel_name = '';
                foreach ($ipv6_resolved as $opt) {
                    if (($opt['id'] ?? '') === $sel_id) {
                        $sel_name = $opt['name'] ?? ($opt['id'] ?? '');
                        break;
                    }
                }
                $has_val = !empty($sel_id);
            ?>
            <div class="ipv6-row">
                <div class="set-picker-field" data-js="set-picker-field"
                    data-set-type="address" data-filter-family="ip6" data-filter-scope="host_prefix" data-max-select="1">
                    <input type="hidden" name="ipv6[]" value="<?= $has_val ? $sel_id : '' ?>">
                    <button type="button"
                        class="std-btn-picker set-picker-trigger js-set-picker-open<?= $has_val ? ' set-picker-trigger--has-value' : '' ?>"
                        data-placeholder="Select IPv6 address">
                        <span class="js-set-picker-label"><?= $has_val ? $sel_name : 'Select IPv6 address' ?></span>
                    </button>
                    <button type="button"
                        class="std-btn-picker set-picker-clear js-set-picker-clear<?= $has_val ? '' : ' sets-hidden' ?>"
                        title="Clear selection">&#215;</button>
                </div>
                <button type="button" class="remove-ipv6" onclick="removeIpRow(this, 'ipv6')">Remove</button>
            </div>
            <?php endforeach; ?>
            <button type="button" onclick="addIpRow('ipv6')">Add IPv6</button>
            <template id="ipv6-picker-template">
                <div class="ipv6-row">
                    <div class="set-picker-field" data-js="set-picker-field"
                        data-set-type="address" data-filter-family="ip6" data-filter-scope="host_prefix" data-max-select="1">
                        <input type="hidden" name="ipv6[]" value="">
                        <button type="button"
                            class="std-btn-picker set-picker-trigger js-set-picker-open"
                            data-placeholder="Select IPv6 address">
                            <span class="js-set-picker-label">Select IPv6 address</span>
                        </button>
                        <button type="button"
                            class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                            title="Clear selection">&#215;</button>
                    </div>
                    <button type="button" class="remove-ipv6" onclick="removeIpRow(this, 'ipv6')">Remove</button>
                </div>
            </template>
        </div>
    </div>
<?php endif; ?>
<?php if ($iface_subtype === 'vrf'): ?>
    <label>Table ID</label>
    <div class="set-picker-field" data-js="label-picker-field"
         data-set-type="routing_tables" data-max-select="1"
         data-label-title="Select routing table">
        <input type="hidden" name="table_id" value="<?= $iface_config['table_id'] ?>">
        <button type="button"
            class="std-btn-picker set-picker-trigger js-set-picker-open"
            data-placeholder="Select routing table">
            <span class="js-set-picker-label">Select routing table</span>
        </button>
        <button type="button"
            class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
            title="Clear">&#215;</button>
    </div>
    <label>
        Enslaved ports
        <select name="vrf_ports[]" multiple class="im-multi-select">
            <?php if (!empty($tdata['tpl_data']['vrf_ports_options'])): ?>
                <?= $tdata['tpl_data']['vrf_ports_options_html'] ?>
            <?php else: ?>
                <option disabled><?= $tdata['tpl_data']['no_interfaces_msg'] ?? 'No interfaces available' ?></option>
            <?php endif; ?>
        </select>
    </label>
<?php endif;
