<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>System Reboot</h1>
        <div class="content-box reboot-container">
            <form id="reboot-form" class="reboot-form">
                <p class="reboot-message">Are you sure you want to restart the system?</p>
                <?php if (!empty($tdata['page_data']['can_reboot'])): ?>
                <button type="submit" class="std-btn std-btn-danger reboot-btn-spacing">
                    Restart
                </button>
                <?php else: ?>
                <p class="reboot-message">You do not have permission to restart the system.</p>
                <?php endif; ?>
                <button type="button" class="std-btn" onclick="history.back();return false;">
                    Cancel
                </button>
                <div id="reboot-msg" class="reboot-status-msg"></div>
            </form>
        </div>
    </main>
</div>
<script>
document.getElementById('reboot-form').addEventListener('submit', function(e) {
    e.preventDefault();
    var form = this;
    var msg = document.getElementById('reboot-msg');
    msg.textContent = '';
    var btns = form.querySelectorAll('button');
    btns.forEach(b => b.disabled = true);

    fetch('/submit.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({command: 'system-reboot'})
    })
    .then(r => r.json())
    .then(function(resp) {
        if (resp.status === 'success') {
            msg.className = 'reboot-status-msg text-success';
            msg.textContent = 'System reboot requested successfully. The system will restart shortly.';
        } else {
            msg.className = 'reboot-status-msg text-error';
            msg.textContent = resp.response_msg || 'Error requesting system reboot.';
            btns.forEach(b => b.disabled = false);
        }
    })
    .catch(function() {
        msg.className = 'reboot-status-msg text-error';
        msg.textContent = 'Network error when requesting system reboot.';
        btns.forEach(b => b.disabled = false);
    });
});
</script>
