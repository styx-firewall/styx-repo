<?php

/**
 * TemplateService->getTpl()
 
 * @var array<mixed> $tdata
 */

?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>System HA</h1>
        <h2>Configure, Monitor High Availability (Non Functional Template)</h2>
        <div class="content-box">
            <table class="std-table">
                <thead>
                    <tr>
                        <th>Node</th>
                        <th>Status</th>
                        <th>Role</th>
                        <th>Last Sync</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>server01</td>
                        <td>Online</td>
                        <td>Primary</td>
                        <td>2024-06-01 12:00</td>
                    </tr>
                    <tr>
                        <td>server02</td>
                        <td>Online</td>
                        <td>Secondary</td>
                        <td>2024-06-01 11:59</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </main>
</div>
