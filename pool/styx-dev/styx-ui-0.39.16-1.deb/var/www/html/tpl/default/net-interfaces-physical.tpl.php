<?php
/**
 * Fragment: Physical interfaces table for net-interfaces
 * Expects $tdata['tpl_data']['physical_interfaces']
 */
$physical = $tdata['tpl_data']['physical_interfaces'] ?? [];

$warning_icon = '<svg class="ni-missing-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="16" height="16">'
    . '<polygon points="10,2 19,18 1,18" fill="#FFD600" stroke="#d00" stroke-width="1.5" />'
    . '<rect x="9" y="7" width="2" height="6" rx="1" fill="#d00" />'
    . '<circle cx="10" cy="15.5" r="1" fill="#d00" />'
    . '</svg>';
?>
<!-- Physical interfaces table -->
<h3>Physical interfaces</h3>
<table class="std-table" id="physical-interfaces-table">
    <thead>
        <tr>
            <th>Interface</th>
            <th>IPv4</th>
            <th>IPv6</th>
            <th>MAC</th>
            <th>MTU</th>
            <th>Status</th>
            <th>Oper. State</th>
            <th>Refs</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($physical as $iface): ?>
            <tr data-iface="<?= $iface['interface'] ?? '' ?>" data-iface-id="<?= $iface['iface_id'] ?? '' ?>" data-iface-type="<?= $iface['type'] ?? '' ?>" data-iface-subtype="<?= $iface['subtype'] ?? '' ?>" class="<?= $iface['row_class'] ?>">
                <td><?= $iface['interface'] ?? '' ?></td>
                <td>
                    <?php foreach ($iface['ipv4_rows'] ?? [] as $ip): ?>
                        <div title="<?= $ip['tooltip'] ?? '' ?>"><?= $ip['label'] ?? '' ?></div>
                    <?php endforeach; ?>
                </td>
                <td>
                    <?php foreach ($iface['ipv6_rows'] ?? [] as $ip): ?>
                        <div title="<?= $ip['tooltip'] ?? '' ?>"><?= $ip['label'] ?? '' ?></div>
                    <?php endforeach; ?>
                </td>
                <td><?= $iface['mac'] ?? '' ?></td>
                <td><?= $iface['mtu'] ?? '' ?></td>
                <td>
                    <?php if (!$iface['is_loopback']): ?>
                        <?php if (empty($iface['managed'])): ?>
                            <span class="std-badge std-badge--unmanaged">Unmanaged</span>
                        <?php else: ?>
                            <?= $iface['status'] ?? '' ?>
                        <?php endif; ?>
                        <?php if (!empty($iface['missing'])): ?>
                            <span class="ni-missing-label" title="Missing from system"><?= $warning_icon ?></span>
                        <?php elseif (!empty($iface['warning_msg'])): ?>
                            <span class="ni-missing-label" title="<?= $iface['warning_msg'] ?>"><?= $warning_icon ?></span>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if (!$iface['is_loopback']): ?>
                        <span
                            class="<?= $iface['oper_led_class'] ?> iface-led"
                            title="<?= ucfirst($iface['operstate'] ?? 'unknown') ?>"
                        ></span>
                    <?php endif; ?>
                </td>
                <td><?= $iface['refs_count'] ?? 0 ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<!-- End physical interfaces table -->
