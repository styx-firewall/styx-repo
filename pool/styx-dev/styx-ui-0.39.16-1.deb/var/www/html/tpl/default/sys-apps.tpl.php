<?php
/**
 * TemplateService->getTpl()
 *
 * @var array<mixed> $tdata
 *
 * Files: default-sys.css, state-storage.js
 */
$packages = $tdata['page_data']['packages_rows'] ?? ($tdata['page_data']['packages'] ?? []);
$upgRows = $tdata['page_data']['upgradable_rows'] ?? [];
$upgCount = $tdata['page_data']['upgradable_count'] ?? 0;
$secCount = $tdata['page_data']['security_count'] ?? 0;
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>System Applications</h1>

        <!-- System Upgrade Section -->
        <h2>System Update & Upgrade</h2>
        <div class="content-box upgrade-section">
            <?php if ($upgCount > 0): ?>
                <div class="upgrade-summary">
                    <span class="upgrade-summary-text">
                        <?= $upgCount ?> package<?= $upgCount !== 1 ? 's' : '' ?> available for upgrade
                        <?php if ($secCount > 0): ?>
                            (<strong><?= $secCount ?></strong> security update<?= $secCount !== 1 ? 's' : '' ?>)
                        <?php endif; ?>
                    </span>
                </div>
            <?php else: ?>
                <div class="upgrade-summary">
                    <span class="upgrade-summary-text">No pending updates</span>
                </div>
            <?php endif; ?>
            <div class="upgrade-actions">
                <?php if (!empty($tdata['page_data']['can_update'])): ?>
            <?php if (!empty($tdata['page_data']['can_update'])): ?>
            <button type="button" id="btn-update-lists" class="std-btn mr-8">Update Package Lists</button>
            <?php endif; ?>
            <?php endif; ?>
                <?php if (!empty($tdata['page_data']['can_upgrade'])): ?>
            <?php if (!empty($tdata['page_data']['can_upgrade'])): ?>
            <button type="button" id="btn-upgrade-packages" class="std-btn std-btn-warning mr-8">Upgrade Packages</button>
            <?php endif; ?>
            <?php endif; ?>
            </div>
            <div id="upgrade-msg" class="msg mt-12"></div>

            <?php if (!empty($upgRows)): ?>
                <table class="std-table mt-18" id="upgradable-packages-table">
                    <thead>
                        <tr>
                            <th>Package</th>
                            <th>Archive</th>
                            <th>Current Version</th>
                            <th>Available Version</th>
                            <th>Arch</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($upgRows as $p): ?>
                        <tr>
                            <td><?= $p['name'] ?></td>
                            <td><?= $p['archive'] ?></td>
                            <td><?= $p['old_version'] ?></td>
                            <td><?= $p['version'] ?></td>
                            <td><?= $p['arch'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Installed Packages Section -->
        <h2>Install and List Installed Packages</h2>
        <div class="content-box">
            <form id="sys-apps-form" class="std-form package-form">
                <label class="package-form-label">
                    Package Name:
                    <input type="text" name="package_name" placeholder="e.g. htop" />
                </label>
                <?php if (!empty($tdata['page_data']['can_install'])): ?>
                <button type="submit">Install Package</button>
                <?php endif; ?>
                <button type="button" id="btn-search-package">Search</button>
            </form>
            <div class="table-scroll-box">
                <table class="std-table" id="installed-packages-table">
                    <thead>
                        <tr>
                            <th>Package</th>
                            <th>Version</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($packages as $pkg): ?>
                        <tr>
                            <td><?= $pkg['package'] ?? '' ?></td>
                            <td><?= $pkg['version'] ?? '' ?></td>
                            <td><?= $pkg['statusStr'] ?? '' ?></td>
                            <td>
                                <?php if (!empty($pkg['show_remove']) && !empty($tdata['page_data']['can_remove'])): ?>
                                    <button class="btn-package-remove"
                                            data-package="<?= $pkg['package'] ?? '' ?>">
                                        Remove
                                    </button>
                                <?php endif; ?>
                                <?php if (!empty($tdata['page_data']['can_remove'])): ?>
                                <button class="btn-package-purge"
                                        data-package="<?= $pkg['package'] ?? '' ?>">
                                    Purge
                                </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
