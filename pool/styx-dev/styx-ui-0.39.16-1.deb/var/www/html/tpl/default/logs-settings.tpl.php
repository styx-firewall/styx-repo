<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */
$log_settings = $tdata['log_settings'] ?? [
    'min_level' => 'INFO',
    'max_entries' => 1000,
    'log_to_file' => true,
    'log_to_syslog' => false,
    'log_file_path' => '/var/log/styx-ui.log',
];
$levels = ['DEBUG', 'INFO', 'NOTICE', 'WARNING', 'ERROR', 'CRITICAL', 'ALERT', 'EMERGENCY'];
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Logs Settings</h1>
        <h2>Logging system configuration (Non Functional Template)</h2>
        <div class="content-box">
            <form id="logs-settings-form" class="std-form" method="post" action="?page=logs&section=settings">
                <label>
                    Minimum log level
                    <select name="min_level" class="std-select">
                        <?php foreach ($levels as $level): ?>
                            <?php
                                $sel = ($log_settings['min_level'] === $level
                                    || ($level === 'DEBUG' && empty($log_settings['min_level'])))
                                    ? ' selected' : '';
                            ?>
                            <option
                                value="<?= $level ?>"<?= $sel ?>
                            >
                                <?= $level ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>
                    Maximum entries to save
                    <input
                        type="number"
                        name="max_entries"
                        value="<?= $log_settings['max_entries'] ?>"
                        min="10"
                        max="100000"
                    >
                </label>
                <label>
                    <input
                        type="checkbox"
                        name="log_to_file"
                        value="1"
                        <?= $log_settings['log_to_file'] ? 'checked' : '' ?>
                    >
                    Enable file logging
                </label>
                <label>
                    UI Log file path
                    <input type="text" disabled name="log_file_path" value="<?= $log_settings['log_file_path'] ?>">
                </label>
                <label>
                    <input
                        type="checkbox"
                        name="log_to_syslog"
                        value="1"
                        <?= $log_settings['log_to_syslog'] ? 'checked' : '' ?>
                    >
                    Enable syslog logging
                </label>
                <button type="submit" disabled class="std-btn">Save configuration</button>
            </form>
        </div>
    </main>
</div>
