<?php
/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */
$levels = $tdata['page_data']['levels_options'] ?? ($tdata['page_data']['levels'] ?? []);
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>System Logs</h1>
        <div class="content-box">
            <form method="get" class="std-form logs-form" id="system-logs-form">
                <div class="form-row">
                    <div class="form-col">
                        <label>Level
                            <select name="level" class="std-select" id="system-log-level">
                                <?php foreach ($levels as $opt): ?>
                                    <option value="<?= $opt['value'] ?? $opt ?>"
                                            <?= !empty($opt['selected']) ? ' selected' : '' ?>>
                                        <?= $opt['label'] ?? ($opt['value'] ?? $opt) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    </div>
                    <div class="form-col">
                        <label for="system-log-limit">Log count
                            <input type="number" name="limit" id="system-log-limit"
                                   class="std-input" min="50" step="10" value="50" />
                        </label>
                    </div>
                    <div class="form-col logs-form-col-end">
                        <button type="submit" class="std-btn">Filter / Refresh</button>
                    </div>
                </div>
            </form>
            <table class="std-table" id="system-logs-table">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th class="logs-date-header">Date</th>
                        <th>Level</th>
                        <th>Service</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- JS population -->
                </tbody>
            </table>
        </div>
    </main>
</div>
