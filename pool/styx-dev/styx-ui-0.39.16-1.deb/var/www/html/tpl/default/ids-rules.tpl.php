<?php
/**
 * IDS/IPS Rules Template (Suricata)
 */
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
    <h1>Suricata IDS/IPS - Rules (Non Functional Template)</h1>
        <div class="content-box">
            <form id="ids-rules-form" class="std-form" style="margin-bottom:1em;">
                <input type="text" placeholder="Search by SID or message..." style="width:200px;">
                <select>
                    <option>All states</option>
                    <option>Active</option>
                    <option>Inactive</option>
                </select>
                <select>
                    <option>All actions</option>
                    <option>alert</option>
                    <option>drop</option>
                    <option>pass</option>
                </select>
                <select>
                    <option>All categories</option>
                    <option>Malware</option>
                    <option>Scan</option>
                    <option>Policy</option>
                </select>
                <select>
                    <option>All sources</option>
                    <option>ET Open</option>
                    <option>Snort GPL</option>
                    <option>Custom</option>
                </select>
                <button class="std-btn" type="button">Filter</button>
                <button class="std-btn" type="button">Import rules</button>
                <button class="std-btn" type="button">Export selected</button>
                <button class="std-btn" type="button">Reload rules</button>
            </form>
            <table class="std-table">
                <thead>
                    <tr>
                        <th><input type="checkbox"></th>
                        <th>SID</th>
                        <th>Message</th>
                        <th>Action</th>
                        <th>Status</th>
                        <th>Category</th>
                        <th>Source</th>
                        <th>Expression</th>
                        <th>Reference</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td>2100498</td>
                        <td>ET SCAN Nmap Scripting Engine User-Agent Detected</td>
                        <td>alert</td>
                        <td>Active</td>
                        <td>Scan</td>
                        <td>ET Open</td>
                        <td>flow:to_server,established; content:"Nmap"; ...</td>
                        <td>https://doc.emergingthreats.net/2100498</td>
                        <td>
                            <button class="std-btn">Edit</button>
                            <button class="std-btn">Deactivate</button>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td>2024218</td>
                        <td>GPL SSH Brute Force login attempt</td>
                        <td>drop</td>
                        <td>Active</td>
                        <td>Malware</td>
                        <td>Snort GPL</td>
                        <td>flow:to_server,established; content:"SSH"; ...</td>
                        <td>https://doc.snort.org/2024218</td>
                        <td>
                            <button class="std-btn">Edit</button>
                            <button class="std-btn">Deactivate</button>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td>2100369</td>
                        <td>ET POLICY Outbound SSH Connection</td>
                        <td>alert</td>
                        <td>Inactive</td>
                        <td>Policy</td>
                        <td>Custom</td>
                        <td>flow:to_server,established; content:"SSH"; ...</td>
                        <td>https://doc.local/2100369</td>
                        <td>
                            <button class="std-btn">Edit</button>
                            <button class="std-btn">Activate</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div style="margin-top:1em;">
                <button class="std-btn">Add rule</button>
                <button class="std-btn">Activate selected</button>
                <button class="std-btn">Deactivate selected</button>
                <button class="std-btn">Delete selected</button>
                <span>Page 1 of 10</span>
                <button class="std-btn">&lt;</button>
                <button class="std-btn">&gt;</button>
                <span>Sync status: <strong>OK</strong></span>
            </div>
        </div>
    </main>
</div>
