<?php

/**
 * System Features Template (Next-Gen Router/Firewall)

 * @var array<mixed> $tdata
 */
// Features prepared by StyxFeaturesFormatter (trusted)
$features = $tdata['page_data']['features'];
$features_json = $tdata['page_data']['features_json'];

?>
<script>
    window.styxFeaturesData = <?= $features_json ?>;
</script>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
    <h1>Styx Features</h1>
    <?php if (!empty($tdata['page_data']['error'])): ?>
        <div class="std-error-box">
            <strong>Error:</strong> <?= $tdata['page_data']['error'] ?>
        </div>
    <?php elseif (!empty($tdata['page_data']['warnings'])): ?>
        <div class="std-error-box std-warning-box">
            <strong>Warning:</strong> some data may be incomplete.
            <ul style="margin:8px 0 0 16px;">
                <?php foreach ($tdata['page_data']['warnings'] as $w): ?>
                    <li><?= $w ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <h2>Activate main functionalities</h2>
        <form class="std-form max-w-1100 mx-auto">
            <!-- Main features section -->
            <div class="flex-row-wrap">
                <fieldset class="feature-fieldset">
                    <legend>Main Functions</legend>
                    <div class="flex-wrap-gap-1em">
                        <?php foreach ($features as $feature): ?>
                            <?php if ($feature['visible']): ?>
                                <label class="feature-label" data-feature-key="<?= $feature['key'] ?>">
                                    <input
                                        type="checkbox"
                                        name="<?= $feature['key'] ?>_enabled"
                                        data-feature-key="<?= $feature['key'] ?>"
                                        <?= $feature['checked_attr'] ?>
                                        <?= $feature['disabled_attr'] ?>
                                    >
                                    <?= $feature['name'] ?>
                                </label>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </fieldset>
            </div>
            <!-- Options/apps section -->
            <div class="flex-row-wrap">
                <?php foreach ($features as $feature): ?>
                    <?php if ($feature['visible'] && count($feature['options']) > 0): ?>
                        <fieldset
                            id="<?= $feature['key'] ?>_fieldset"
                            class="feature-options-fieldset <?= $feature['fieldset_class'] ?>"
                        >
                            <legend>
                                <?= $feature['name'] ?>: Options
                            </legend>
                            <div
                                id="<?= $feature['key'] ?>_options_block"
                                class="feature-options-block"
                            >
                                <?php foreach ($feature['options'] as $opt): ?>
                                    <label
                                        class="opt-label feature-option-label"
                                        data-feature-key="<?= $feature['key'] ?>"
                                        data-option-key="<?= $opt['key'] ?>"
                                    >
                                        <span class="std-switch">
                                            <input
                                                type="<?= $feature['input_type'] ?>"
                                                name="<?= $feature['input_name'] ?>"
                                                value="<?= $opt['key'] ?>"
                                                <?= $opt['checked_attr'] ?>
                                                <?= $opt['disabled_attr'] ?>
                                            >
                                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                                        </span>
                                        <span class="std-switch-label"><?= $opt['name'] ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </fieldset>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </form>
        <div id="feature-info-modal" class="modal-overlay">
            <div class="modal-content">
                <div id="feature-info-content"></div>
                <button
                    onclick="document.getElementById('feature-info-modal').style.display='none'"
                    class="mt-18"
                >
                    Close
                </button>
            </div>
        </div>
    </main>
</div>
