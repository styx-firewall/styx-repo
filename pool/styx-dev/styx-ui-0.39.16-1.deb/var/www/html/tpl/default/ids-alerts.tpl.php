<?php
/**
 * IDS/IPS Alerts Template (Suricata)
 */
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
    <h1>Suricata IDS/IPS - Alerts (Non Functional Template)</h1>
        <div class="content-box">
            <form id="ids-alerts-form" class="std-form" style="margin-bottom:1em;">
                <input type="date">
                <input type="text" placeholder="SID or message..." style="width:150px;">
                <input type="text" placeholder="Source IP" style="width:120px;">
                <input type="text" placeholder="Destination IP" style="width:120px;">
                <select>
                    <option>All severities</option>
                    <option>High</option>
                    <option>Medium</option>
                    <option>Low</option>
                </select>
                <select>
                    <option>All categories</option>
                    <option>Malware</option>
                    <option>Scan</option>
                    <option>Policy</option>
                </select>
                <select>
                    <option>All actions</option>
                    <option>alert</option>
                    <option>drop</option>
                </select>
                <button class="std-btn" type="button">Filter</button>
                <button class="std-btn" type="button">Export CSV</button>
                <button class="std-btn" type="button">Export JSON</button>
                <button class="std-btn" type="button">Mark all as reviewed</button>
            </form>
            <table class="std-table">
                <thead>
                    <tr>
                        <th><input type="checkbox"></th>
                        <th>Date</th>
                        <th>SID</th>
                        <th>Message</th>
                        <th>Source</th>
                        <th>Destination</th>
                        <th>Protocol</th>
                        <th>Severity</th>
                        <th>Category</th>
                        <th>Action</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td>2025-06-22 10:00</td>
                        <td>2100498</td>
                        <td>ET SCAN Nmap Scripting Engine User-Agent Detected</td>
                        <td>192.168.1.100:54321</td>
                        <td>192.168.1.1:80</td>
                        <td>TCP</td>
                        <td>High</td>
                        <td>Scan</td>
                        <td>alert</td>
                        <td>
                            <button class="std-btn">View details</button>
                            <button class="std-btn">Dismiss</button>
                            <button class="std-btn">Payload</button>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td>2025-06-22 09:45</td>
                        <td>2024218</td>
                        <td>GPL SSH Brute Force login attempt</td>
                        <td>203.0.113.5:34567</td>
                        <td>192.168.1.10:22</td>
                        <td>TCP</td>
                        <td>Medium</td>
                        <td>Malware</td>
                        <td>drop</td>
                        <td>
                            <button class="std-btn">View details</button>
                            <button class="std-btn">Dismiss</button>
                            <button class="std-btn">Payload</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div style="margin-top:1em;">
                <button class="std-btn">Dismiss selected</button>
                <button class="std-btn">Mark selected as reviewed</button>
                <button class="std-btn">Export selected</button>
                <span>Page 1 of 10</span>
                <button class="std-btn">&lt;</button>
                <button class="std-btn">&gt;</button>
            </div>
        </div>
    </main>
</div>
