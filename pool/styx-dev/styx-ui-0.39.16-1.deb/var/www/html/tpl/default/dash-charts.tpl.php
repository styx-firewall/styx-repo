<?php

/**
 * TemplateService->getTpl()
  * @var array<mixed> $tdata
 * $tdata['page_data']['charts'] - array of {id: string, label: string}
 */

$charts = $tdata['page_data']['charts'] ?? [];

?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Charts Dashboard</h1>
        <h2>Charts Dashboard</h2>
        <div class="content-box">
            <div class="std-switches-scroll-container">
                <div class="chart-switch-box">
                    <?php foreach ($charts as $chart): ?>
                    <div class="std-switch-group">
                        <label class="std-switch">
                            <input type="checkbox" id="switch-<?= $chart['id'] ?>" />
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                        <span class="std-switch-label"><?= htmlspecialchars($chart['label']) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div id="charts-list" class="std-grid-type1">
                <?php foreach ($charts as $chart): ?>
                <div class="std-grid-item-type1 hidden" id="chart-<?= $chart['id'] ?>-block">
                    <h3><?= htmlspecialchars($chart['label']) ?></h3>
                    <canvas id="<?= $chart['id'] ?>-chart" class="chart-canvas"></canvas>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </main>
</div>
