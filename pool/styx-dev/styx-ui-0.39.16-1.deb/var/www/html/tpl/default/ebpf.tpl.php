<?php
/**
 * eBPF Module Management  -  main template.
 *
 * Fragments are loaded via load_tpl in PageEbpf and rendered into named places.
 * JS reads all data from DOM dataset attributes  -  no JSON injection needed.
 *
 * @var array $tdata
 */
$pd = $tdata['page_data'] ?? [];
$api_ok = $pd['api_ok'] ?? false;
$error  = $pd['error'] ?? '';
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>eBPF Modules</h1>
        <div class="content-box">

            <?php if (!$api_ok): ?>
            <div class="ebpf-error-banner">
                <p><b>eBPF Service Unavailable</b></p>
                <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
            </div>
            <?php else: ?>

            <?= $tdata['ebpf_list'] ?? '' ?>
            <?= $tdata['ebpf_kernel'] ?? '' ?>
            <?= $tdata['ebpf_detail'] ?? '' ?>

            <?php endif; ?>

        </div>
    </main>
</div>
