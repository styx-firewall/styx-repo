<?php

/**
 * TemplateService->getTpl()
 
 * @var array<mixed> $tdata
 */

?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Single Sign-On</h1>
        <h2>Contenido SSO (Non Functional Template)</h2>
        <div class="content-box">
            <table class="std-table">
                <thead>
                    <tr>
                        <th>Provider</th>
                        <th>Type</th>
                        <th>Client ID</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Google</td>
                        <td>OAuth2</td>
                        <td>google-client-id-123</td>
                        <td>Enabled</td>
                        <td>
                            <button>Edit</button>
                            <button>Disable</button>
                        </td>
                    </tr>
                    <tr>
                        <td>LDAP</td>
                        <td>LDAP</td>
                        <td>ldap-client</td>
                        <td>Enabled</td>
                        <td>
                            <button>Edit</button>
                            <button>Disable</button>
                        </td>
                    </tr>
                    <tr>
                        <td>Radius</td>
                        <td>RADIUS</td>
                        <td>radius-client</td>
                        <td>Disabled</td>
                        <td>
                            <button>Edit</button>
                            <button>Enable</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <button>Add SSO Provider</button>
        </div>
    </main>
</div>
