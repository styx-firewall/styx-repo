<?php

/**
 * TemplateService->getTpl()
 
 * @var array<mixed> $tdata
 */

?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Ldap Servers</h1>
        <h2>Contenido Ldap Servers (Non Functional Template)</h2>
        <div class="content-box">
            <table class="std-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Host</th>
                        <th>Port</th>
                        <th>Base DN</th>
                        <th>Bind DN</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>ldap1</td>
                        <td>ldap.example.com</td>
                        <td>389</td>
                        <td>dc=example,dc=com</td>
                        <td>cn=admin,dc=example,dc=com</td>
                        <td>Online</td>
                        <td>
                            <button>Edit</button>
                            <button>Delete</button>
                        </td>
                    </tr>
                    <tr>
                        <td>ldap2</td>
                        <td>ldap2.example.com</td>
                        <td>389</td>
                        <td>dc=example,dc=org</td>
                        <td>cn=admin,dc=example,dc=org</td>
                        <td>Offline</td>
                        <td>
                            <button>Edit</button>
                            <button>Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <button>Add LDAP Server</button>
        </div>
    </main>
</div>
