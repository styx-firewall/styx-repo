<?php
/**
 * @var array<mixed> $tdata
 * js: scripts/routing/routing-bfd.js
 */
$page_data    = $tdata['page_data'];
$sessions     = $page_data['sessions'] ?? [];
$bfd_profiles = $page_data['bfd_profiles'] ?? [];
$can_add      = !empty($page_data['can_add']);
$can_save     = !empty($page_data['can_save']);
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>BFD</h1>

        <details class="nat-help">
            <summary>Help</summary>
            <div class="nat-help-content">
                <p><strong>BFD (Bidirectional Forwarding Detection)</strong> provides sub-second link failure detection for routing protocols. It is not a routing protocol itself - it accelerates convergence when a link or peer fails.</p>
                <ul>
                    <li><strong>Peers:</strong> Manually configure BFD peers with source/destination IPs and detection parameters.</li>
                    <li><strong>Profiles:</strong> Reusable parameter templates (interval, multiplier). Assign to peers for consistency.</li>
                    <li><strong>Usage:</strong> Enable BFD on BGP/OSPF neighbors to detect failures in milliseconds instead of waiting for protocol timers.</li>
                </ul>
            </div>
        </details>

        <div class="content-box">
            <h2>BFD Sessions</h2>
            <p class="content-note">
                BFD sessions are automatically created by BGP/OSPF when BFD is enabled on neighbors.
                This view is read-only.
            </p>
            <table class="std-table" id="bfd-sessions-table">
                <thead>
                    <tr>
                        <th>Peer Address</th>
                        <th>Local Address</th>
                        <th>Interface</th>
                        <th>Status</th>
                        <th>Tx Interval (ms)</th>
                        <th>Rx Interval (ms)</th>
                        <th>Multiplier</th>
                        <th>Uptime</th>
                    </tr>
                </thead>
                <tbody id="bfd-sessions-tbody">
                <?php if (empty($sessions)): ?>
                    <tr class="std-table-empty"><td colspan="8">No active BFD sessions.</td></tr>
                <?php else: ?>
                    <?php foreach ($sessions as $s): ?>
                    <tr>
                        <td><?= $s['peer'] ?></td>
                        <td><?= $s['local'] ?? '-' ?></td>
                        <td><?= $s['interface'] ?? '-' ?></td>
                        <td>
                            <span class="std-badge std-badge--<?= $s['status'] === 'up' ? 'active' : 'inactive' ?>">
                                <span class="std-status-dot <?= $s['status'] === 'up' ? 'on' : 'off' ?>"></span>
                                <?= $s['status'] ?>
                            </span>
                        </td>
                        <td><?= $s['tx_interval'] ?></td>
                        <td><?= $s['rx_interval'] ?></td>
                        <td><?= $s['multiplier'] ?></td>
                        <td><?= $s['uptime'] ?? '-' ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- BFD Profiles -->
        <div class="content-box">
            <div class="content-box-header">
                <h2>BFD Profiles</h2>
                <?php if ($can_add): ?>
                <button type="button" class="std-btn" data-js="bfd-profile-toggle-form"
                    data-target="bfd-profile-add-form">+ Add Profile</button>
                <?php endif; ?>
            </div>

            <div class="content-box" id="bfd-profile-add-form" style="display:none;">
                <h3 id="bfd-profile-form-title">Add BFD Profile</h3>
                <form class="std-form form-compact" data-js="bfd-profile-form">
                    <input type="hidden" id="bfd_profile_id" value="">
                    <div class="form-row">
                        <div class="form-col">
                            <label for="bfd_profile_name">Name</label>
                            <input type="text" id="bfd_profile_name" class="std-input" required placeholder="e.g. fast-detect">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bfd_profile_detect_mult">Detect Multiplier</label>
                            <input type="number" id="bfd_profile_detect_mult" class="std-input" min="2" max="255" value="3">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bfd_profile_rx">Rx Interval (ms)</label>
                            <input type="number" id="bfd_profile_rx" class="std-input" min="10" max="60000" value="300">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bfd_profile_tx">Tx Interval (ms)</label>
                            <input type="number" id="bfd_profile_tx" class="std-input" min="10" max="60000" value="300">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col form-col--tight">
                            <label for="bfd_profile_echo">Echo Mode</label>
                            <label class="std-switch">
                                <input type="checkbox" id="bfd_profile_echo">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bfd_profile_echo_rx">Echo Rx (ms)</label>
                            <input type="number" id="bfd_profile_echo_rx" class="std-input" min="10" placeholder="default">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bfd_profile_echo_tx">Echo Tx (ms)</label>
                            <input type="number" id="bfd_profile_echo_tx" class="std-input" min="10" placeholder="default">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="bfd_profile_passive">Passive</label>
                            <label class="std-switch">
                                <input type="checkbox" id="bfd_profile_passive">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col form-col--tight">
                            <label for="bfd_profile_min_ttl">Min TTL</label>
                            <input type="number" id="bfd_profile_min_ttl" class="std-input" min="1" max="254" placeholder="default">
                        </div>
                    </div>
                    <div class="form-row">
                        <button type="button" class="std-btn" data-js="bfd-profile-save">Save</button>
                        <button type="button" class="std-btn std-btn--secondary"
                            data-js="bfd-profile-toggle-form"
                            data-target="bfd-profile-add-form">Cancel</button>
                    </div>
                </form>
            </div>

            <table class="std-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Detect Mult</th>
                        <th>Rx (ms)</th>
                        <th>Tx (ms)</th>
                        <th>Echo</th>
                        <th>Passive</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($bfd_profiles)): ?>
                    <tr class="std-table-empty"><td colspan="7">No BFD profiles configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($bfd_profiles as $bfp): ?>
                    <tr data-profile-id="<?= $bfp['id'] ?>">
                        <td><?= $bfp['name'] ?></td>
                        <td><?= $bfp['detect_multiplier'] ?></td>
                        <td><?= $bfp['receive_interval'] ?></td>
                        <td><?= $bfp['transmit_interval'] ?></td>
                        <td><?= $bfp['echo_mode_label'] ?? 'No' ?></td>
                        <td><?= $bfp['passive_label'] ?? 'No' ?></td>
                        <td>
                            <?php if (!empty($bfp['can_delete'])): ?>
                            <button type="button" class="std-btn std-btn--sm js-bfd-profile-edit"
                                data-id="<?= $bfp['id'] ?>"
                                data-name="<?= $bfp['name'] ?>"
                                data-detect-mult="<?= $bfp['detect_multiplier'] ?>"
                                data-rx="<?= $bfp['receive_interval'] ?>"
                                data-tx="<?= $bfp['transmit_interval'] ?>"
                                data-echo="<?= !empty($bfp['echo_mode']) ? '1' : '0' ?>"
                                data-echo-rx="<?= $bfp['echo_receive_interval'] ?? '' ?>"
                                data-echo-tx="<?= $bfp['echo_transmit_interval'] ?? '' ?>"
                                data-passive="<?= !empty($bfp['passive_mode']) ? '1' : '0' ?>"
                                data-min-ttl="<?= $bfp['minimum_ttl'] ?? '' ?>"
                            >Edit</button>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="bfd-profile-delete" data-id="<?= $bfp['id'] ?>">Delete</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

    </main>
</div>
