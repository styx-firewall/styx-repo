<?php
/**
 * TemplateService->getTpl()
 *
 * @var array<mixed> $tdata
 *
 * Example content for $predefined and $custom:
 * $predefined = [
 *   [
 *     'key' => 'rp_filter',
 *     'sysctl_key' => 'net.ipv4.conf.all.rp_filter',
 *     'value' => '1',
 *     'default' => '0',
 *     'comment' => 'IP packet filtering',
 *     'input_type' => 'number',
 *     'checked' => false,
 *     'predefined' => true
 *   ],
 *   ...
 * ];
 * $custom = [
 *   [
 *     'key' => 'custom_param',
 *     'sysctl_key' => 'net.custom.param',
 *     'value' => 'foo',
 *     'default' => '-',
 *     'comment' => 'Custom parameter',
 *     'input_type' => 'text',
 *     'checked' => false,
 *     'predefined' => false
 *   ],
 *   ...
 * ];
 */
$predefined = $tdata['page_data']['predefined'] ?? [];
$custom = $tdata['page_data']['custom'] ?? [];
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <aside><?= $tdata['sidebar'] ?></aside>
    <main class="page-content">
        <h1>Sysctl Network Tuning</h1>
        <div class="content-box">
            <div class="std-tabs">
                <button type="button" class="std-tab-btn active" data-tab="tunning">Tuning</button>
                <button type="button" class="std-tab-btn" data-tab="adv-tunning">Advanced Raw Tuning</button>
            </div>
            <div class="std-tab-panel active" data-tab="tunning">
                <form id="sysctl-tunning-form" method="post" autocomplete="off">
                    <div class="std-grid-type1" data-js="sysctl-tunning-fields">
                    <?php
                    if (!empty($predefined)) {
                        foreach ($predefined as $item) {
                            echo '<div class="form-col std-grid-item-type1 sysctl-grid-item">';
                            echo '<label for="value-' . $item['key'] . '" class="sysctl-label">'
                                . $item['sysctl_key'] . '</label>';
                            echo '<input type="hidden" name="sysctl_keys[]" value="' . $item['sysctl_key'] . '">';
                            if ($item['input_type'] === 'number') {
                                echo '<input type="number" name="value[]" id="value-' . $item['key'] . '" value="'
                                    . $item['value'] . '" data-original="' . $item['value'] . '" data-sysctl-key="'
                                    . $item['sysctl_key'] . '" class="js-sysctl-value std-grid-input" autocomplete="off">';
                            } elseif ($item['input_type'] === 'checkbox') {
                                $checked = $item['checked'] ? 'checked' : '';
                                echo '<label class="std-switch">';
                                echo '<input type="checkbox" name="value[]" id="value-' . $item['key'] . '" value="1" '
                                    . 'data-original="' . ($item['checked'] ? '1' : '0') . '" ';
                                echo 'data-sysctl-key="' . $item['sysctl_key'] . '" class="js-sysctl-value std-grid-input" '
                                    . $checked . '>';
                                echo '<span class="std-switch-slider" data-off="No" data-on="Yes"></span>';
                                echo '</label>';
                            } else {
                                echo '<input type="text" name="value[]" id="value-' . $item['key'] . '" value="'
                                    . $item['value'] . '" data-original="' . $item['value'] . '" data-sysctl-key="'
                                    . $item['sysctl_key'] . '" class="js-sysctl-value std-grid-input" autocomplete="off">';
                            }
                            if ($item['comment']) {
                                echo '<div class="sysctl-comment">' . $item['comment'] . '</div>';
                            }
                            echo '<div class="sysctl-default">Default: <span id="default-' . $item['key'] . '">'
                                . $item['default'] . '</span></div>';
                            echo '</div>';
                        }
                    }
                    ?>
                    </div>
                    <button type="submit" id="sysctl-tunning-submit">Save changes</button>
                </form>
            </div>
            <div class="std-tab-panel" data-tab="adv-tunning">
                <form id="sysctl-adv-tunning-form" method="post" autocomplete="off">
                    <div class="std-grid-type1" data-js="sysctl-adv-tunning-fields">
                    <?php
                    if (!empty($custom)) {
                        foreach ($custom as $item) {
                            echo '<div class="form-col std-grid-item-type1 sysctl-grid-item">';
                            echo '<label for="value-' . $item['key'] . '" class="sysctl-label">'
                                . $item['sysctl_key'] . '</label>';
                            echo '<input type="hidden" name="sysctl_keys[]" value="' . $item['sysctl_key'] . '">';
                            if ($item['input_type'] === 'number') {
                                echo '<input type="number" name="value[]" id="value-' . $item['key'] . '" value="'
                                    . $item['value'] . '" data-original="' . $item['value'] . '" data-sysctl-key="'
                                    . $item['sysctl_key'] . '" class="js-sysctl-value std-grid-input" autocomplete="off">';
                            } elseif ($item['input_type'] === 'checkbox') {
                                $checked = $item['checked'] ? 'checked' : '';
                                echo '<label class="std-switch">';
                                echo '<input type="checkbox" name="value[]" id="value-' . $item['key'] . '" value="1" '
                                    . 'data-original="' . ($item['checked'] ? '1' : '0') . '" ';
                                echo 'data-sysctl-key="' . $item['sysctl_key'] . '" class="js-sysctl-value std-grid-input" '
                                    . $checked . '>';
                                echo '<span class="std-switch-slider" data-off="No" data-on="Yes"></span>';
                                echo '</label>';
                            } else {
                                echo '<input type="text" name="value[]" id="value-' . $item['key'] . '" value="'
                                    . $item['value'] . '" data-original="' . $item['value'] . '" data-sysctl-key="'
                                    . $item['sysctl_key'] . '" class="js-sysctl-value std-grid-input" autocomplete="off">';
                            }
                            if ($item['comment']) {
                                echo '<div class="sysctl-comment">' . $item['comment'] . '</div>';
                            }
                            echo '<div class="sysctl-default">Default: <span id="default-' . $item['key'] . '">'
                                . $item['default'] . '</span></div>';
                            echo '</div>';
                        }
                    }
                    ?>
                    </div>
                    <button type="submit" id="sysctl-adv-tunning-submit">Save changes</button>
                </form>

            </div>
        </div>
    </main>
</div>

