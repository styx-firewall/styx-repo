<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */

?>
<script>try { if (window.localStorage) localStorage.removeItem('app:current_user'); } catch(e) {}</script>

<div class="login-wrap">
    <div>
        <form id="login-form" class="std-form" method="post" autocomplete="off">
            <img src="/img/logo.png" alt="Logo" class="login-logo">
            <label>
                User:
                <input type="text" name="username" required autofocus autocomplete="username" />
            </label>
            <label>
                Password:
                <input type="password" name="password" required autocomplete="current-password" />
            </label>
            <label>
                Realm:
                <select name="realm">
                    <option value="pam" selected>Linux PAM</option>
                </select>
            </label>
            <button type="submit">Login</button>
        </form>
        <div id="login-message" class="login-message"></div>
    </div>
</div>
