<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */

//var_dump($tdata['sec_overview_audit_frag']);
//$audit_fag = $tdata['']
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Security Overview</h1>
        <div class="content-box">
            <?php
            echo $tdata['sec_overview_audit_frag'] ?? '<div class="empty">No audit data available.</div>';
            ?>
        </div>
    </main>
</div>
