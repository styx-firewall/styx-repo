<?php
/**
 * eBPF fragment: detail panel skeleton (tabs + containers).
 * Content is populated by JS from API responses.
 *
 * @var array $tdata - $tdata['tpl_data'] is not used here (JS-driven)
 */
?>

<div id="ebpf-detail-panel" class="ebpf-detail-panel hidden">
    <div class="ebpf-detail-topbar">
        <button id="ebpf-back-btn" class="std-btn ebpf-back-btn" type="button">← Back to List</button>
        <div id="ebpf-detail-actions" class="ebpf-detail-actions"></div>
    </div>
    <div id="ebpf-detail-header" class="ebpf-detail-header"></div>

    <div class="std-tabs" id="ebpf-detail-tabs">
        <button class="std-tab-btn active" data-tab="ebpf-tab-overview">Overview</button>
        <button class="std-tab-btn" data-tab="ebpf-tab-control-maps">Control Maps</button>
        <button class="std-tab-btn" data-tab="ebpf-tab-telemetry">Telemetry</button>
        <button class="std-tab-btn" data-tab="ebpf-tab-events">Events</button>
    </div>

    <div id="ebpf-detail-tab-panels">
        <div class="std-tab-panel active" id="tab-ebpf-tab-overview">
            <div id="ebpf-overview-content"></div>
        </div>
        <div class="std-tab-panel" id="tab-ebpf-tab-control-maps">
            <div id="ebpf-control-maps-content"></div>
        </div>
        <div class="std-tab-panel" id="tab-ebpf-tab-telemetry">
            <div id="ebpf-telemetry-content"></div>
        </div>
        <div class="std-tab-panel" id="tab-ebpf-tab-events">
            <div class="ebpf-events-toolbar">
                <button id="ebpf-events-pause-btn" class="std-btn" type="button">⏸ Pause</button>
                <button id="ebpf-events-clear-btn" class="std-btn ebpf-btn-secondary" type="button">Clear</button>
                <label class="ebpf-autoscroll-label">
                    <input type="checkbox" id="ebpf-events-autoscroll" checked> Auto-scroll
                </label>
            </div>
            <div id="ebpf-events-table-wrap" class="ebpf-events-table-wrap">
                <table id="ebpf-events-table" class="ebpf-events-table">
                    <thead><tr><th>Severity</th><th>Time</th><th>Source</th><th>Summary</th></tr></thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>
