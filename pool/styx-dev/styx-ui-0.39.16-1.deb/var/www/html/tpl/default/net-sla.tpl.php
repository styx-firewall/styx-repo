<?php

/**
 * TemplateService->getTpl()
 * net-sla.js
 * @var array<mixed> $tdata
 */
$ifaces_names = $tdata['page_data']['ifaces_names'];
$monitors = $tdata['page_data']['monitors'];
$addresses_host = $tdata['page_data']['addresses_host'] ?? [];
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Styx SLA</h1>
        <div class="content-box sla-content-box">
                <div class="sla-center">
                    <div class="sla-center sla-header-row">
                        <div>
                            <select id="sla-type-select" class="sla-select-sm">
                                <option value="latency">Latency</option>
                                <option value="jitter">Jitter</option>
                                <option value="drops">Drops</option>
                            </select>
                        </div>
                    </div>
                    <div class="sla-chart-wrap">
                        <canvas id="net-sla-chart" class="sla-chart-canvas"></canvas>
                    </div>
                </div>
                <div class="sla-center sla-margin-top-32">
                    <form id="add-monitor-form" class="form-box sla-form">
                        <div class="sla-form-row">
                            <label for="monitor-name" class="sla-label">Name</label>
                            <input
                                type="text"
                                id="monitor-name"
                                name="name"
                                required
                                class="sla-input"
                                maxlength="31"
                                size="31"
                                style="width:31ch;"
                            >

                            <label for="monitor-protocol" class="sla-label">Protocol</label>
                            <select disabled id="monitor-protocol" name="protocol" required class="sla-select-col">
                                <option value="ping">Ping</option>
                                <option value="http">HTTP</option>
                                <option value="dns">DNS</option>
                            </select>

                            <label for="monitor-interface" class="sla-label">Interface</label>
                            <select id="monitor-interface" name="interface" required class="sla-select-col">
                                <option value="none">None</option>
                                <?php foreach ($ifaces_names as $iface): ?>
                                    <option value="<?= $iface['id'] ?>"><?= $iface['interface'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <label for="monitor-interval" class="sla-label">Interval (ms)</label>
                            <input
                                type="number"
                                id="monitor-interval"
                                name="interval"
                                min="500"
                                max="9999"
                                step="500"
                                required
                                class="sla-num-sm"
                                value="5000"
                            >
                            <label for="monitor-target" class="sla-label">Target</label>
                            <div class="set-picker-field" data-js="set-picker-field"
                                data-set-type="address" data-filter-scope="host" data-max-select="1">
                                <input type="hidden" id="monitor-target" name="target" value="">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select target host">
                                    <span class="js-set-picker-label">Select target host</span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear selection">&#215;</button>
                            </div>
                        </div>
                        <div id="ping-extra-fields-row" class="sla-ping-extra-row">
                            <div id="ping-extra-fields" class="sla-ping-extra">
                                <label for="monitor-inactive" class="sla-label">Inactive Failures</label>
                                <input
                                    type="number"
                                    id="monitor-inactive"
                                    name="inactive_failures"
                                    min="1"
                                    step="1"
                                    required
                                    class="sla-num-xs"
                                    value="3"
                                >
                                <label for="monitor-restore" class="sla-label">Restore Success</label>
                                <input
                                    type="number"
                                    id="monitor-restore"
                                    name="restore_success"
                                    min="1"
                                    step="1"
                                    required
                                    class="sla-num-xs"
                                    value="3"
                                >                                
                                <label for="latency-threshold" class="sla-label">Latency Threshold (ms)</label>
                                <input
                                    type="number"
                                    id="latency-threshold"
                                    name="latency_threshold"
                                    min="1"
                                    step="1"
                                    class="sla-num-md"
                                    value="30"
                                >
                                <label for="latency-strikes" class="sla-label">Latency Strikes</label>
                                <input
                                    type="number"
                                    id="latency-strikes"
                                    name="latency_strikes"
                                    min="1"
                                    step="1"
                                    class="sla-num-xs"
                                    value="3"
                                >
                                <label for="jitter-threshold" class="sla-label">Jitter Threshold (ms)</label>
                                <input
                                    type="number"
                                    id="jitter-threshold"
                                    name="jitter_threshold"
                                    min="1"
                                    step="1"
                                    class="sla-num-md"
                                    value="5"
                                >
                                <label for="jitter-strikes" class="sla-label">Jitter Strikes</label>
                                <input
                                    type="number"
                                    id="jitter-strikes"
                                    name="jitter_strikes"
                                    min="1"
                                    step="1"
                                    class="sla-num-xs"
                                    value="3"
                                >
                            </div>
                        </div>
                        <div class="sla-margin-top-12">
                            <button type="submit" class="sla-add-btn">Add Monitor</button>
                        </div>
                    </form>
                </div>
                <!-- Inject monitors array for JS -->
                <script>
                window.slaMonitors = <?= json_encode($monitors) ?>;
                </script>
            </div>
            <div class="sla-monitors-wrap">
                <table id="monitors-table" class="sla-monitors-table">
                    <thead class="sla-monitors-thead">
                        <tr>
                        <th>Name</th>
                        <th>Protocol</th>
                        <th>Target</th>
                        <th>Interface</th>
                        <th>Interval (ms)</th>
                        <th>Inactive Failures</th>
                        <th>Restore Success</th>
                        <th>Extra Params</th>
                        <th>Status</th>
                        <th>Actions</th>
                        </tr>
					</thead>
					<tbody>
                        <?php if (is_array($monitors) && count($monitors)): ?>
                            <?php foreach ($monitors as $monitor): ?>
                                <tr>
                                    <td><?= $monitor['name'] ?></td>
                                    <td><?= $monitor['protocol'] ?></td>
                                    <td>
                                        <?php if (!empty($monitor['target_display'])): ?>
                                            <span<?php if (!empty($monitor['target_tooltip'])): ?> title="<?= $monitor['target_tooltip'] ?>"<?php endif; ?>><?= $monitor['target_display'] ?></span>
                                        <?php else: ?>
                                            <?= $monitor['target'] ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($monitor['interface_display'])): ?>
                                            <span<?php if (!empty($monitor['interface_tooltip'])): ?> title="<?= $monitor['interface_tooltip'] ?>"<?php endif; ?>><?= $monitor['interface_display'] ?></span>
                                        <?php else: ?>
                                            <span class="sla-none">None</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= $monitor['interval_ms'] ?></td>
                                    <td><?= $monitor['inactive_failures'] ?></td>
                                    <td><?= $monitor['restore_success'] ?></td>
                                    <td class="sla-extras-cell">
                                        <?php if (!empty($monitor['extras']) && is_array($monitor['extras'])): ?>
                                            <?= implode('<br>', $monitor['extras']) ?>
                                        <?php else: ?>
                                            <span class="sla-none">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($monitor['enabled'])): ?>
                                            <span class="sla-status-active">Active</span>
                                        <?php else: ?>
                                            <span class="sla-status-inactive">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($monitor['enabled'])): ?>
                                            <button
                                                class="monitor-action-btn sla-btn-deactivate"
                                                data-action="deactivate"
                                                data-id="<?= $monitor['id'] ?>"
                                            >Deactivate</button>
                                        <?php else: ?>
                                            <button
                                                class="monitor-action-btn sla-btn-activate"
                                                data-action="activate"
                                                data-id="<?= $monitor['id'] ?>"
                                            >Activate</button>
                                        <?php endif; ?>
                                        <button
                                            class="monitor-action-btn sla-btn-delete"
                                            data-action="delete"
                                            data-id="<?= $monitor['id'] ?>"
                                        >Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="10" class="sla-text-center sla-none">No monitors found</td></tr>
                        <?php endif; ?>
					</tbody>
				</table>
			</div>
    </main>
</div>
