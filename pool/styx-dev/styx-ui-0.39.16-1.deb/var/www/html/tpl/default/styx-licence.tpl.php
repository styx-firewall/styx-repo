<?php
/**
 * Template: styx-licence
 * @var array<mixed> $tdata
 */
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1 style="text-align:center;margin-bottom:12px;">Styx Licence</h1>
        <div class="content-box">
            <article class="license-container" style="max-width:880px;margin:0 auto;padding:20px;background:#0f1724;border:1px solid rgba(255,255,255,0.04);border-radius:6px;box-shadow:0 1px 3px rgba(2,6,23,0.6);">
                <div style="white-space:pre-wrap;font-family:monospace;font-size:0.95rem;line-height:1.6;color:#cbd5e1;">
**Non-Production Evaluation License**

Copyright (c) 20022-2026 [Styx FLF]

All rights reserved.

**Early Stage Notice:**
This Software is in an early stage of development and may contain bugs, errors, or incomplete features. It is provided for testing and evaluation purposes only and should not be relied upon for any critical use. Compatibility between versions is not guaranteed and the software may break between releases until a stable version is published.

Permission is hereby granted to any individual or entity obtaining a copy of this software (the "Software") to use the Software solely for **testing** and **evaluation** purposes.

This license is granted on a limited, non-exclusive, non-transferable, and revocable basis.

**Permitted Use:**

* Use of the Software in testing environments
* Internal evaluation of the Software’s functionality and performance

**Restrictions:**
You may NOT, under any circumstances:

* Use the Software in production environments
* Use the Software for any commercial purpose
* Provide, distribute, or make the Software available as a service to third parties
* Redistribute, sublicense, lease, or transfer the Software
* Modify, reverse engineer, decompile, or create derivative works based on the Software (unless expressly authorized)

**Termination:**
This license is effective until terminated. It will terminate automatically without notice if you fail to comply with any of its terms.

**Disclaimer of Warranty:**
The Software is provided "as is", in an early stage of development, without warranty of any kind, express or implied, including but not limited to warranties of merchantability, fitness for a particular purpose, and non-infringement.

**Limitation of Liability:**
In no event shall the author or copyright holder be liable for any claim, damages, or other liability arising from, out of, or in connection with the Software or the use or other dealings in the Software.


                </div>
                <footer class="license-footer" style="text-align:center;margin-top:18px;color:#94a3b8;font-size:0.92rem;">
                    Final license pending - subject to change until a stable release.
                </footer>
            </article>
        </div>
    </main>
</div>
