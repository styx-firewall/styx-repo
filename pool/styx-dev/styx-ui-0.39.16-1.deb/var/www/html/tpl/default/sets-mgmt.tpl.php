<?php
/**
 *
 */
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Firewall: Address and Port Objects</h1>

        <div class="content-box">
            <div class="std-tabs" role="tablist" id="sets-tabs">
                <button class="std-tab-btn active" role="tab" data-target="panel-address">Addresses</button>
                <button class="std-tab-btn" role="tab" data-target="panel-ports">Ports</button>
                <button class="std-tab-btn" role="tab" data-target="panel-interfaces">Interfaces</button>
                <button class="std-tab-btn" role="tab" data-target="panel-domain">Domains</button>
            </div>

            <div class="std-tab-panel active" id="panel-address" role="tabpanel">
                <?= $tdata['sets_addresses'] ?? '' ?>
            </div>
            <div class="std-tab-panel" id="panel-ports" role="tabpanel">
                <?= $tdata['sets_ports'] ?? '' ?>
            </div>
            <div class="std-tab-panel" id="panel-interfaces" role="tabpanel">
                <?= $tdata['sets_interfaces'] ?? '' ?>
            </div>
            <div class="std-tab-panel" id="panel-domain" role="tabpanel">
                <?= $tdata['sets_domain'] ?? '' ?>
            </div>
        </div>
    </main>
</div>
