
<?php
/**
 * TemplateService->getTpl()
 *
 * @var array<mixed> $tdata
 */
$groups = $tdata['page_data']['services_groups'] ?? [];
$hasAny = false;
foreach ($groups as $g) {
    if (!empty($g['rows'])) {
        $hasAny = true;
        break;
    }
}
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Services</h1>
        <h2>Manage Linux systemd Services</h2>
        <div class="content-box">
            <?php if ($hasAny): ?>
                <table class="std-table" id="services-table">
                    <thead>
                        <tr>
                            <th>Service</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Enabled</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($groups as $group): ?>
                            <?php if (empty($group['rows'])) continue; ?>
                            <tr class="services-section-header">
                                <td colspan="5"><?= $group['label'] ?></td>
                            </tr>
                            <?php foreach ($group['rows'] as $svc): ?>
                                <tr>
                                    <td><?= $svc['service'] ?></td>
                                    <td><?= $svc['description'] ?></td>
                                    <?php $badge = $svc['status_badge'] ?? ''; ?>
                                    <td><span class="std-badge <?= $badge ?>"><?= $svc['active'] ?></span></td>
                                    <td><?= $svc['enabled'] ?></td>
                                    <td><?= $svc['actions_html'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No services data available.</p>
            <?php endif; ?>
        </div>
    </main>
</div>
