<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Styx Gateway Restart</h1>
        <div class="content-box styx-content-center">
            <form id="restart-form" class="small-card">
                <p class="lead-text mb-18"><?= $tdata['page_data']['confirm_message'] ?></p>
                <?php if (!empty($tdata['page_data']['can_restart_gateway'])): ?>
                <button type="submit" class="std-btn std-btn-danger mr-16">Restart</button>
                <?php else: ?>
                <p class="lead-text mb-18">You do not have permission to restart the gateway.</p>
                <?php endif; ?>
                <button type="button" class="std-btn" onclick="history.back();return false;">Cancel</button>
                <div id="restart-msg" class="msg"></div>
            </form>
        </div>
    </main>
</div>
