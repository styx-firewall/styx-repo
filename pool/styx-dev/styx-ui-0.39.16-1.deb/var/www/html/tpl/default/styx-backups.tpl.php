<?php

/**
 * TemplateService->getTpl()
 * Includes JS: styx-backups.js
 *
 * @var array<mixed> $tdata
 */
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Styx Config Backup</h1>
        <?php if (!empty($tdata['page_data']['error'])): ?>
            <div class="std-error-box">
                <strong>Error:</strong> <?= $tdata['page_data']['error'] ?>
            </div>
        <?php elseif (!empty($tdata['page_data']['warnings'])): ?>
            <div class="std-error-box std-warning-box">
                <strong>Warning:</strong> some data may be incomplete.
                <ul style="margin:8px 0 0 16px;">
                    <?php foreach ($tdata['page_data']['warnings'] as $w): ?>
                        <li><?= $w ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="content-box styx-content-center styx-backups">
            <div class="styx-card-small">
                <form id="backup-form" class="mb-32">
                    <p class="mb-18">Download a backup of the current configuration.</p>
                    <?php $backup_types = $tdata['page_data']['backup_types'] ?? []; ?>
                    <div class="mb-12">
                        <label for="backup-type-select" class="mr-8">Type:</label>
                        <select id="backup-type-select" name="backup_type" required>
                            <?php foreach ($backup_types as $i => $bt): ?>
                                <option value="<?= $bt ?>">
                                    <?= $bt ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                        <button type="submit" class="std-btn mb-8">Download Backup</button>
                        <div id="backup-msg" class="mt-12 font-bold"></div>
                </form>
                <form id="restore-form">
                    <p class="mb-18">Restore configuration from a backup file.</p>
                    <div class="mb-12">
                        <label for="restore-type-select" class="mr-8">Type:</label>
                        <select id="restore-type-select" name="restore_type" required>
                            <?php foreach ($backup_types as $i => $bt): ?>
                                    <option value="<?= $bt ?>">
                                        <?= $bt ?>
                                    </option>
                                <?php endforeach; ?>
                        </select>
                    </div>
                    <input
                        type="file"
                        name="backup_file"
                        id="backup-file"
                        accept=".json"
                        required
                        class="mb-12"
                    />
                    <br>
                    <?php if (!empty($tdata['page_data']['can_restore'])): ?>
                    <button type="submit" class="std-btn std-btn-danger mr-16">Restore Backup</button>
                    <?php endif; ?>
                    <button
                        type="button"
                        class="std-btn"
                        onclick="history.back();return false;"
                    >
                        Cancel
                    </button>
                    <div id="restore-msg" class="mt-18 font-bold"></div>
                </form>
            </div>
        </div>
    </main>
</div>
