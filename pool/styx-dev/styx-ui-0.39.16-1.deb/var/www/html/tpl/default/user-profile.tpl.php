<?php

/**
 * TemplateService->getTpl()
 * @var array<mixed> $tdata
 */

$username         = $tdata['page_data']['username'] ?? null;
$timezones        = $tdata['page_data']['timezones'] ?? [];
$profileTimezone  = $tdata['page_data']['profile_timezone'] ?? '';
$profileLocale    = $tdata['page_data']['profile_locale'] ?? '';
$profileDebug     = (bool)($tdata['page_data']['profile_debug'] ?? false);
$currentTimezone  = $tdata['page_data']['current_timezone'] ?? 'UTC';
$currentLocale    = $tdata['page_data']['current_locale'] ?? 'en-US';
$sampleShort      = $tdata['page_data']['sample_short'] ?? '';
$sampleLong       = $tdata['page_data']['sample_long'] ?? '';

$hasCustomTz  = $profileTimezone !== '';
$hasCustomLoc = $profileLocale !== '';
$effectiveTz  = $hasCustomTz ? $profileTimezone : $currentTimezone . ' (auto)';
$effectiveLoc = $hasCustomLoc ? $profileLocale : $currentLocale . ' (auto)';
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Profile</h1>

        <?php if ($username === null): ?>
        <div class="content-box">
            <div class="alert alert-warning">
                <strong>Session refresh required.</strong>
                Please <a href="?page=logout">log out</a> and log back in to use profile preferences.
            </div>
        </div>
        <?php else: ?>

        <!-- Summary card -->
        <section class="content-box upro-card">
            <h3><?= $username ?></h3>
            <div class="upro-summary">
                <div class="upro-summary-item">
                    <span class="upro-summary-label">Timezone</span>
                    <span class="upro-summary-value"><?= $effectiveTz ?></span>
                </div>
                <div class="upro-summary-item">
                    <span class="upro-summary-label">Locale</span>
                    <span class="upro-summary-value"><?= $effectiveLoc ?></span>
                </div>
                <div class="upro-summary-item">
                    <span class="upro-summary-label">Debug mode</span>
                    <span class="upro-summary-value"><?= $profileDebug ? 'Enabled' : 'Disabled' ?></span>
                </div>
            </div>
            <div class="upro-summary upro-summary--samples">
                <div class="upro-summary-item">
                    <span class="upro-summary-label">Short format</span>
                    <span class="upro-summary-value"><code><?= htmlspecialchars($sampleShort) ?></code></span>
                </div>
                <div class="upro-summary-item">
                    <span class="upro-summary-label">Long format</span>
                    <span class="upro-summary-value"><code><?= htmlspecialchars($sampleLong) ?></code></span>
                </div>
            </div>
        </section>

        <!-- Preferences form -->
        <section class="content-box upro-card">
            <h3>Preferences</h3>
            <form id="userProfileForm" class="std-form upro-form">

                <div class="form-group">
                    <label for="profileTimezoneSelect">Display timezone</label>
                    <div class="input-row">
                        <select id="profileTimezoneSelect" name="timezone" class="upro-select">
                            <option value="">- Auto-detect (<?= $currentTimezone ?>) -</option>
                            <?php foreach ($timezones as $tz): ?>
                            <option value="<?= $tz ?>"<?= $tz === $profileTimezone ? ' selected' : '' ?>><?= $tz ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                    <small>Sets the display timezone used for dates, logs and charts throughout the UI.</small>
                </div>

                <div class="form-group">
                    <label for="profileLocaleSelect">Display locale</label>
                    <div class="input-row">
                        <select id="profileLocaleSelect" name="locale" class="upro-select">
                            <option value="">- Auto-detect (<?= $currentLocale ?>) -</option>
                            <option value="en-US"<?= $profileLocale === 'en-US' ? ' selected' : '' ?>>English (US)</option>
                            <option value="es-ES"<?= $profileLocale === 'es-ES' ? ' selected' : '' ?>>Español (ES)</option>
                            <option value="en-GB"<?= $profileLocale === 'en-GB' ? ' selected' : '' ?>>English (UK)</option>
                            <option value="de-DE"<?= $profileLocale === 'de-DE' ? ' selected' : '' ?>>Deutsch</option>
                            <option value="fr-FR"<?= $profileLocale === 'fr-FR' ? ' selected' : '' ?>>Français</option>
                            <option value="pt-PT"<?= $profileLocale === 'pt-PT' ? ' selected' : '' ?>>Português</option>
                            <option value="it-IT"<?= $profileLocale === 'it-IT' ? ' selected' : '' ?>>Italiano</option>
                            <option value="nl-NL"<?= $profileLocale === 'nl-NL' ? ' selected' : '' ?>>Nederlands</option>
                        </select>
                    </div>
                    <small>Sets the date and number format used throughout the UI.</small>
                </div>

                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="profileDebugCheck" name="debug"<?= $profileDebug ? ' checked' : '' ?>>
                        Enable debug mode for my session
                    </label>
                    <small>Shows extended error information and enables verbose logging for your user only.</small>
                </div>

                <div id="profileFormFeedback" class="form-feedback" hidden></div>

                <div class="form-actions">
                    <button type="submit" id="saveProfileBtn" class="std-btn">Save preferences</button>
                </div>
            </form>
        </section>
        <?php endif ?>
    </main>
</div>
