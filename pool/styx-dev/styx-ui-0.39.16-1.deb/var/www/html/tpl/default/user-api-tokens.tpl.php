<?php

/**
 * TemplateService->getTpl()
 * @var array<mixed> $tdata
 */
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>API Bearer Tokens</h1>

        <div class="content-box">
            <h3>Manage API Tokens</h3>
            <p class="apitoken-note">
                Bearer tokens provide long-lived authentication for external scripts and integrations
                without requiring session management. Each token acts as a permanent API key that can
                be used in automation scripts, CI/CD pipelines, and third-party integrations.
            </p>
            <p class="apitoken-security">
                <strong>Security Notice:</strong> Keep your tokens secure and never commit them to version control.
                Revoke tokens immediately if compromised.
            </p>

            <table class="std-table" id="bearerTokensTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>User</th>
                        <th>Token ID</th>
                        <th>Created</th>
                        <th>Last Used</th>
                        <th>Expires</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="bearerTokensTableBody">
                        <?php if (!empty($tdata['page_data']['error'])): ?>
                            <tr>
                                <td colspan="7" class="apitoken-error">
                                    Error: <?= $tdata['page_data']['error'] ?>
                                </td>
                            </tr>
                        <?php elseif (empty($tdata['page_data']['tokens'])): ?>
                            <tr>
                                <td colspan="7" class="apitoken-empty">
                                    No tokens yet. Generate one to get started.
                                </td>
                            </tr>
                    <?php else: ?>
                        <?php foreach ($tdata['page_data']['tokens'] as $token): ?>
                        <tr>
                            <td><?= $token['name'] ?? 'Unnamed' ?></td>
                            <td><?= $token['username'] ?? ($token['user'] ?? '') ?></td>
                            <td class="token-id-cell" style="font-family: monospace; font-size: 0.9em;">
                                <?= isset($token['token_id']) ? substr($token['token_id'], 0, 16) . '...' : 'N/A' ?>
                            </td>
                            <td><?= $token['created_at'] ?? 'N/A' ?></td>
                            <td><?= $token['last_used_at'] ?? 'Never' ?></td>
                            <td><?= $token['expires_at'] ?? 'Never' ?></td>
                            <td>
                                <?php if (!empty($token['revoked'])): ?>
                                    <span class="apitoken-revoked-label">Revoked</span>
                                <?php elseif (!empty($token['can_revoke'])): ?>
                                    <button class="js-revoke-token apitoken-revoke-btn"
                                            data-token-id="<?= $token['token_id'] ?? '' ?>"
                                            data-token-name="<?= $token['name'] ?? 'Unnamed' ?>">
                                        Revoke
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php if (!empty($tdata['page_data']['can_generate'])): ?>
            <button id="generateTokenBtn" class="apitoken-generate-btn">Generate New Token</button>
            <?php endif; ?>
        </div>

        <div class="content-box">
            <h3>Usage Examples</h3>
            <p style="margin-bottom: 10px; color: #888;">
                Use bearer tokens in your scripts by including them in the Authorization header:
            </p>

            <div class="apitoken-usage-box">
                <label class="apitoken-usage-label">Bash/curl example:</label>
                <pre class="apitoken-pre">curl -X POST https://your-router.local/submit.php \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{"command":"add_user","username":"alice","password":"pass123"}'</pre>
            </div>

            <div class="apitoken-usage-box">
                <label class="apitoken-usage-label">Python example:</label>
                <pre class="apitoken-pre">import requests

headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer YOUR_TOKEN_HERE"
}
payload = {"command": "add_user", "username": "alice", "password": "pass123"}
response = requests.post("https://your-router.local/submit.php",
                        json=payload, headers=headers)
print(response.json())</pre>
            </div>
        </div>
    </main>
</div>

<template id="tmpl-generate-token">
    <div class="apitoken-modal">
        <h2 class="apitoken-title">Generate API Token</h2>
        <form id="generateTokenForm" class="apitoken-modal-form">
            <div>
                <label>Token Name:</label>
                <input type="text" name="name" required
                    placeholder="e.g., Automation Script" class="apitoken-modal-input">
            </div>
            <div>
                <label>Expires (optional):</label>
                <input type="date" name="expires_at" class="apitoken-modal-input">
                <small class="apitoken-modal-small">Leave empty for no expiration</small>
            </div>
            <button type="submit" class="std-btn">Generate Token</button>
        </form>
    </div>
</template>

<template id="tmpl-token-result">
    <div class="apitoken-modal">
        <h2 class="apitoken-success">Token Generated Successfully</h2>
        <p class="apitoken-note">
            This is the only time you'll see the full token. Copy it now
            and store it securely.
        </p>
        <div class="apitoken-usage-box">
            <label class="apitoken-token-name">Token Name:</label>
            <div class="apitoken-token-value" data-js="result-name"></div>
            <label class="apitoken-token-name">Token:</label>
            <div class="apitoken-token-value" data-js="result-token"></div>
        </div>
        <button id="copyTokenBtn" class="std-btn apitoken-copy-btn">Copy to Clipboard</button>
        <button id="closeTokenResultBtn" class="std-btn apitoken-close-btn">Close</button>
        <p class="apitoken-warning">⚠️ Save this token now. You won't be able to see it again.</p>
    </div>
</template>
