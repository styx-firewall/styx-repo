<?php
/**
 * IDS/IPS Config Template (Suricata)
 */
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
    <h1>Suricata IDS/IPS - Configuration (Non Functional Template)</h1>
        <div class="content-box">
            <form id="ids-config-form" class="std-form">
                <label>Monitored interfaces:
                    <select multiple>
                        <option selected>eth0</option>
                        <option selected>eth1</option>
                        <option>eth2</option>
                    </select>
                </label>
                <label>Mode:
                    <select>
                        <option selected>IDS (detection)</option>
                        <option>IPS (prevention)</option>
                    </select>
                </label>
                <label>Active rules:
                    <input type="number" value="1234" readonly>
                </label>
                <label>Auto-update rules:
                    <input type="checkbox" checked>
                </label>
                <label>Logging:
                    <select>
                        <option selected>Normal</option>
                        <option>Detailed</option>
                        <option>Alerts only</option>
                    </select>
                </label>
                <label>Exclusions (IP/network/port):
                    <input type="text" placeholder="192.168.1.0/24, 10.0.0.5, 443">
                </label>
                <fieldset style="margin-top:1em;">
                    <legend>Alert types to enable</legend>
                    <label><input type="checkbox" checked> Malware</label>
                    <label><input type="checkbox" checked> Network attacks</label>
                    <label><input type="checkbox"> PUA (Potentially Unwanted Apps)</label>
                    <label><input type="checkbox" checked> Scan/Reconnaissance</label>
                    <label><input type="checkbox"> Policies/Compliance</label>
                    <label><input type="checkbox"> Others</label>
                    <br>
                    <label>Minimum severity:
                        <select>
                            <option value="low">Low</option>
                            <option value="medium" selected>Medium</option>
                            <option value="high">High</option>
                        </select>
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Advanced options</legend>
                    <label>Inspection mode:
                        <select>
                            <option selected>By stream</option>
                            <option>By packet</option>
                        </select>
                    </label>
                    <label>Analysis threads:
                        <input type="number" min="1" max="32" value="4">
                    </label>
                    <label>Maximum memory (MB):
                        <input type="number" min="128" max="16384" value="2048">
                    </label>
                    <label>Log rotation (days):
                        <input type="number" min="1" max="90" value="7">
                    </label>
                    <label>Send alerts by email:
                        <input type="checkbox">
                    </label>
                    <label>Alert webhook:
                        <input type="url" placeholder="https://miwebhook/alerta">
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Rule sources</legend>
                    <label><input type="checkbox" checked> Emerging Threats (ET Open)</label>
                    <label><input type="checkbox"> Snort GPL</label>
                    <label><input type="checkbox"> Custom rules</label>
                    <label><input type="checkbox"> Commercial rules (ET Pro, Snort Subscriptions)</label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Notifications</legend>
                    <label>Notify by email:
                        <input type="email" placeholder="admin@dominio.com">
                    </label>
                    <label>Notify by Telegram:
                        <input type="text" placeholder="@usuario_o_id_canal">
                    </label>
                    <label>Notify by Slack:
                        <input type="text" placeholder="#canal o webhook">
                    </label>
                    <label>SIEM integration:
                        <input type="text" placeholder="URL o token SIEM">
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Test mode and whitelists</legend>
                    <label>Enable test mode (alerts only, no blocking):
                        <input type="checkbox">
                    </label>
                    <label>Whitelist of IPs/ranges/SIDs:
                        <input type="text" placeholder="192.168.1.10, 10.0.0.0/24, 2100498">
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Remote syslog integration</legend>
                    <label>Remote syslog server:
                        <input type="text" placeholder="syslog.midominio.com:514">
                    </label>
                    <label>Protocol:
                        <select>
                            <option selected>UDP</option>
                            <option>TCP</option>
                            <option>TLS</option>
                        </select>
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Rule update scheduling</legend>
                    <label>Frequency:
                        <select>
                            <option>Manual</option>
                            <option>Daily</option>
                            <option>Weekly</option>
                            <option>Specific time</option>
                        </select>
                    </label>
                    <label>Time (if applicable):
                        <input type="time">
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Alert threshold control</legend>
                    <label>Max alerts per minute:
                        <input type="number" min="1" max="10000" value="100">
                    </label>
                    <label>Max alerts per hour:
                        <input type="number" min="1" max="100000" value="1000">
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Maintenance and profiles</legend>
                    <label>Enable maintenance mode (pause inspection):
                        <input type="checkbox">
                    </label>
                    <label>Configuration profile:
                        <select>
                            <option>Production</option>
                            <option>Testing</option>
                            <option>High security</option>
                        </select>
                        <button class="std-btn" type="button">Save profile</button>
                        <button class="std-btn" type="button">Load profile</button>
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Integrations and external actions</legend>
                    <label>External script on critical alert:
                        <input type="text" placeholder="/usr/local/bin/alerta.sh">
                    </label>
                    <label>Automatic action on critical alert:
                        <select>
                            <option>None</option>
                            <option>Block IP</option>
                            <option>Restart interface</option>
                        </select>
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Log retention and size</legend>
                    <label>Log retention days:
                        <input type="number" min="1" max="365" value="30">
                    </label>
                    <label>Max log size (MB):
                        <input type="number" min="10" max="100000" value="1024">
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Resources and schedules</legend>
                    <label>CPU usage limit (%):
                        <input type="number" min="1" max="100" value="80">
                    </label>
                    <label>Silent/night mode:
                        <input type="checkbox"> (reduce alerts/notifications from 22:00 to 07:00)
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Additional notifications</legend>
                    <label>Notify by SMS:
                        <input type="text" placeholder="+34123456789">
                    </label>
                    <label>Notify by Microsoft Teams:
                        <input type="text" placeholder="webhook/canal">
                    </label>
                    <label>Notify by Discord:
                        <input type="text" placeholder="webhook/canal">
                    </label>
                    <label>PagerDuty integration:
                        <input type="text" placeholder="API key">
                    </label>
                    <label>Splunk integration:
                        <input type="text" placeholder="URL/token">
                    </label>
                    <label>Graylog integration:
                        <input type="text" placeholder="URL/token">
                    </label>
                    <label>Elastic/Logstash integration:
                        <input type="text" placeholder="URL/token">
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Blacklists and honeypot</legend>
                    <label>Blacklist of IPs/SIDs:
                        <input type="text" placeholder="8.8.8.8, 2100500">
                    </label>
                    <label>Enable honeypot mode:
                        <input type="checkbox">
                    </label>
                </fieldset>
                <fieldset style="margin-top:1em;">
                    <legend>Interface access control</legend>
                    <label>Enable 2FA:
                        <input type="checkbox">
                    </label>
                    <label>Allowed IPs for access:
                        <input type="text" placeholder="192.168.1.0/24, 10.0.0.5">
                    </label>
                </fieldset>
                <div style="margin-top:1em;">
                    <button type="button" class="std-btn">Save changes</button>
                    <button type="button" class="std-btn">Reload configuration</button>
                </div>
            </form>
        </div>
    </main>
</div>