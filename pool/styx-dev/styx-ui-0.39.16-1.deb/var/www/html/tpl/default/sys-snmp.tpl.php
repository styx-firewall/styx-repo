<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */

?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>System SNMP</h1>
        <h2>Configure System SNMP (Non Functional Template)</h2>
        <div class="content-box">
            <form id="sys-snmp-form" class="std-form">
                <label>
                    SNMP Enabled:
                    <select>
                        <option selected>Yes</option>
                        <option>No</option>
                    </select>
                </label>
                <label>
                    Community String:
                    <input type="text" value="public" />
                </label>
                <label>
                    SNMP Version:
                    <select>
                        <option selected>v2c</option>
                        <option>v1</option>
                        <option>v3</option>
                    </select>
                </label>
                <button type="submit">Save</button>
            </form>
        </div>
    </main>
</div>
