<?php

/**
 * TemplateService->getTpl()
 *
 * Included: styx-settings.js
 *
 * @var array<mixed> $tdata
 */
// Page data provided by StyxSettingsFormatter (trusted)
$certs = $tdata['page_data']['certs'];
$ui_settings = $tdata['page_data']['ui_settings'];
$styx_settings = $tdata['page_data']['styx_settings'];
$loglevel_options = $tdata['page_data']['loglevel_options'];
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Styx Settings</h1>
        <?php if (!empty($tdata['page_data']['error'])): ?>
            <div class="std-error-box">
                <strong>Error:</strong> <?= $tdata['page_data']['error'] ?>
            </div>
        <?php elseif (!empty($tdata['page_data']['warnings'])): ?>
            <div class="std-error-box std-warning-box">
                <strong>Warning:</strong> some data may be incomplete.
                <ul style="margin:8px 0 0 16px;">
                    <?php foreach ($tdata['page_data']['warnings'] as $w): ?>
                        <li><?= $w ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="content-box">
            <!-- Styx Settings Form -->
            <div class="form-section">
                <form id="styx-settings-form" method="post" action="" class="centered-form">
                    <div class="form-group form-group-flex">
                        <label for="styx_branch" class="min-w-110">Styx Branch
                            <span class="js-info-icon" data-info-modal="help-styx-branch"></span>
                        </label>
                        <?php $branch = $styx_settings['styx_branch']; ?>
                        <select
                            id="styx_branch"
                            name="styx_branch"
                            class="form-control min-w-120 max-w-220">
                            <option
                                value="dev"
                                <?php if ($branch === 'dev'): ?>selected<?php endif; ?>
                            >
                                Develop
                            </option>
                            <option
                                value="test"
                                <?php if ($branch === 'test'): ?>selected<?php endif; ?>
                            >
                                Testing
                            </option>
                        </select>
                    </div>
                 </form>
            </div>
            <div class="form-section">
                <form id="styx-theme-form" method="post" action="" class="centered-form">
                    <div class="form-group form-group-flex">
                        <label for="styx_theme" class="min-w-110">Styx Theme
                            <span class="js-info-icon" data-info-modal="help-styx-theme"></span>
                        </label>
                        <?php $theme = $styx_settings['styx_theme']; ?>
                        <select disabled id="styx_theme" name="styx_theme" class="form-control">
                            <option
                                value="default"
                                <?php if ($theme === 'default'): ?>selected<?php endif; ?>
                            >
                                Default
                            </option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="form-section">
                <form id="web-settings-form" method="post" action="submit.php" class="centered-form">
                    <h2 class="text-center">Styx Service Settings</h2>
                    <div class="form-group form-group-flex">
                        <label for="https-port" class="min-w-110">Styx Port (HTTPS)
                            <span class="js-info-icon" data-info-modal="help-styx-https-port"></span>
                        </label>
                        <?php
                            $https_val = $ui_settings['https_port'];
                        ?>
                        <input
                            type="number"
                            id="https-port"
                            name="https_port"
                            class="form-control min-w-60 max-w-120"
                            value="<?= $https_val ?>"
                            min="1"
                            max="65535"
                            required
                        />
                    </div>
                    <div class="form-group form-group-flex">
                        <label for="styx_log_level" class="min-w-110">Styx Log Level
                            <span class="js-info-icon" data-info-modal="help-styx-loglevel"></span>
                        </label>
                        <select id="styx_log_level" name="styx_log_level" class="form-control min-w-120 max-w-220">
                            <option value="" <?php if ($styx_settings['styx_log_level'] === null): ?>selected<?php endif; ?> disabled>
                                Select log level
                            </option>
                            <?php foreach ($loglevel_options as $option): ?>
                                <option value="<?= $option['value'] ?>" <?php if ($option['selected']): ?>selected<?php endif; ?>>
                                    <?= $option['name'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <input type="hidden" name="command" value="update_web_settings" />
                    <div class="form-group form-group-flex">
                        <label for="ssl-cert-select" class="min-w-110">Choose certificate
                            <span class="js-info-icon" data-info-modal="help-styx-cert"></span>
                        </label>
                        <select id="ssl-cert-select" name="ssl_cert_select" class="form-control min-w-220 max-w-420">
                            <?php foreach ($certs as $c): ?>
                                <option
                                    value="<?= $c['id'] ?>"
                                    data-cert-path="<?= $c['cert_path'] ?>"
                                    data-key-path="<?= $c['key_path'] ?>"
                                    <?php if (!empty($c['selected'])): ?> selected<?php endif; ?>
                                >
                                    <?= $c['display'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="text-center" style="margin-top:12px;">
                        <button type="submit" class="std-btn">Save</button>
                    </div>
                </form>
            </div>
            <div class="form-section">
                <div class="text-center" style="margin-top:12px;">
                    <button id="restart-styx-ui-btn" class="std-btn std-btn-warning">Restart Styx UI</button>
                </div>
            </div>
            <!-- Help blocks for Styx Settings forms -->
            <div id="help-styx-branch" style="display:none">
                <p><strong>Styx Branch</strong>: The release channel used by Styx (Develop/Testing). Changing
                this controls which APT repository branch updates are pulled from.</p>
            </div>
            <div id="help-styx-theme" style="display:none">
                <p><strong>Styx Theme</strong>: Visual theme selection for the Styx UI. Most deployments use the default option.</p>
            </div>
            <div id="help-styx-https-port" style="display:none">
                <p><strong>Styx Port (HTTPS)</strong>: TCP port where the Styx web service listens for HTTPS connections.</p>
            </div>
            <div id="help-styx-loglevel" style="display:none">
                <p><strong>Styx Log Level</strong>: Granularity of logging output for Styx (info, warning, error, debug).</p>
            </div>
            <div id="help-styx-cert" style="display:none">
                <p><strong>Choose certificate</strong>: Select the TLS certificate used by Styx for HTTPS. Certificates are
                managed in the Certificates panel.</p>
            </div>
        </div>
    </main>
</div>
