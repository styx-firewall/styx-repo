<?php
/**
 * @var array<mixed> $tdata
 * js: scripts/routing/routing-ospf.js
 */
$page_data   = $tdata['page_data'];
$ospf_config = $page_data['ospf_config'] ?? [];
$areas       = $page_data['areas'] ?? [];
$interfaces  = $page_data['interfaces'] ?? [];
$neighbors   = $page_data['neighbors'] ?? [];
$ospf6_config = $page_data['ospf6_config'] ?? [];
$areas6       = $page_data['areas6'] ?? [];
$interfaces6  = $page_data['interfaces6'] ?? [];
$neighbors6   = $page_data['neighbors6'] ?? [];
$ifaces       = $page_data['ospf_ifaces'] ?? [];
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>OSPF</h1>

        <div class="std-tabs" id="ospf-tabs">
            <button class="std-tab-btn active" data-tab="ospf-v2">OSPFv2</button>
            <button class="std-tab-btn" data-tab="ospf-v3">OSPFv3</button>
        </div>

        <!-- OSPFv2 -->
        <div class="std-tab-panel active" id="tab-ospf-v2">

        <details class="nat-help">
            <summary>Help - OSPFv2</summary>
            <div class="nat-help-content">
                <p><strong>OSPFv2 (Open Shortest Path First)</strong> is a link-state routing protocol for IPv4. It builds a complete topology map and computes shortest paths using Dijkstra's algorithm.</p>
                <ul>
                    <li><strong>Router ID:</strong> Unique 32-bit identifier (dotted-quad). Usually an loopback IP.</li>
                    <li><strong>Reference Bandwidth:</strong> Used to auto-calculate interface cost = ref_bw / link_speed (Mbps). Set high enough for 10G+ links.</li>
                    <li><strong>Areas:</strong> Backbone (area 0) is required. Use stub/NSSA areas to reduce LSAs on low-end routers. Each area needs a network prefix (address set).</li>
                    <li><strong>Interfaces:</strong> Override per-interface OSPF parameters - priority (DR election), cost, timers, passive mode (suppress hellos).</li>
                </ul>
            </div>
        </details>

        <!-- Global OSPF config -->
        <div class="content-box">
            <h2>OSPF Configuration</h2>
            <form id="ospf-config-form" class="std-form form-compact" data-js="ospf-config-form">
                <div class="form-row">
                    <div class="form-col form-col--tight">
                        <label for="ospf_enabled">Enabled</label>
                        <label class="std-switch">
                            <input type="checkbox" id="ospf_enabled" name="enabled"
                                <?= !empty($ospf_config['enabled']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col">
                        <label>Router ID</label>
                        <?php $ridDisplay = $ospf_config['router_id_display'] ?? null; ?>
                        <div class="set-picker-field" data-js="label-picker-field" data-set-type="router_id"
                             data-max-select="1" data-label-title="Select Router ID">
                            <input type="hidden" id="ospf_router_id" name="router_id"
                                value="<?= $ospf_config['router_id'] ?? '' ?>">
                            <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                data-placeholder="Select Router ID">
                                <span class="js-set-picker-label"><?= $ridDisplay ? $ridDisplay['name'] : 'Select Router ID' ?></span>
                            </button>
                            <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear<?= $ridDisplay ? '' : ' sets-hidden' ?>"
                                title="Clear selection">&#215;</button>
                        </div>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf_reference_bandwidth">Reference Bandwidth (Mbps)</label>
                        <input type="number" id="ospf_reference_bandwidth" name="reference_bandwidth" class="std-input"
                            min="1" max="4294967" placeholder="100"
                            value="<?= $ospf_config['reference_bandwidth'] ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf_log_adjacency">Log Adjacency Changes</label>
                        <label class="std-switch">
                            <input type="checkbox" id="ospf_log_adjacency" name="log_adjacency_changes"
                                <?= !empty($ospf_config['log_adjacency_changes']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf_passive_default">Passive Interface Default</label>
                        <label class="std-switch">
                            <input type="checkbox" id="ospf_passive_default" name="passive_interface_default"
                                <?= !empty($ospf_config['passive_interface_default']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <div class="form-row">
                <?php if (!empty($page_data['can_save'])): ?>
                    <button type="button" class="std-btn" data-js="ospf-save-config">Save Configuration</button>
                <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Areas table -->
        <div class="content-box">
            <div class="content-box-header">
                <h2>OSPF Areas</h2>
                <?php if (!empty($page_data['can_add'])): ?>
                    <button type="button" class="std-btn" data-js="ospf-add-area-open">+ Add Area</button>
                <?php endif; ?>
            </div>
            <table class="std-table" id="ospf-areas-table">
                <thead>
                    <tr>
                        <th>Area ID</th>
                        <th>Type</th>
                        <th>Network (set)</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="ospf-areas-tbody">
                <?php if (empty($areas)): ?>
                    <tr class="std-table-empty"><td colspan="4">No areas configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($areas as $area): ?>
                    <?php $netDisplay = $area['network_set_display'] ?? null; ?>
                    <tr data-area-id="<?= $area['id'] ?>">
                        <td>
                            <?php $areaDisplay = $area['area_id_display'] ?? null; ?>
                            <?php if ($areaDisplay): ?>
                                <span class="set-ref" title="ID: <?= $areaDisplay['id'] ?>">
                                    <span class="set-name"><?= $areaDisplay['name'] ?></span>
                                    <?php if (!empty($areaDisplay['value'])): ?><span class="set-type"><?= $areaDisplay['value'] ?></span><?php endif; ?>
                                </span>
                            <?php else: ?>
                                <?= $area['area_id'] ?>
                            <?php endif; ?>
                        </td>
                        <td><?= $area['type'] ?? 'normal' ?></td>
                        <td>
                            <?php if ($netDisplay): ?>
                                <span class="set-ref" title="ID: <?= $netDisplay['id'] ?>">
                                    <?php if (!empty($netDisplay['family'])): ?><span class="set-type"><?= $netDisplay['family'] ?></span><?php endif; ?>
                                    <span class="set-name"><?= $netDisplay['name'] ?></span>
                                </span>
                            <?php else: ?>
                                <span class="text-dim"> - </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="ospf-delete-area" data-id="<?= $area['id'] ?>">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Add area form (hidden by default) -->
        <div class="content-box" id="ospf-add-area-form" style="display:none;">
            <h2>Add OSPF Area</h2>
            <form class="std-form form-compact" data-js="ospf-area-form">
                <div class="form-row">
                    <div class="form-col">
                        <label>Area ID</label>
                        <div class="set-picker-field" data-js="label-picker-field" data-set-type="ospf_area"
                             data-max-select="1" data-label-title="Select OSPF area">
                            <input type="hidden" id="ospf_area_id" name="area_id" value="">
                            <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                data-placeholder="Select OSPF area">
                                <span class="js-set-picker-label">Select OSPF area</span>
                            </button>
                            <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                title="Clear selection">&#215;</button>
                        </div>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf_area_type">Type</label>
                        <select id="ospf_area_type" name="type" class="std-select" data-js="ospf-area-type">
                            <option value="normal">Normal</option>
                            <option value="stub">Stub</option>
                            <option value="nssa">NSSA</option>
                        </select>
                    </div>
                    <div class="form-col form-col--tight" id="ospf-no-summary-col" style="display:none;">
                        <label for="ospf_area_no_summary">No Summary</label>
                        <label class="std-switch">
                            <input type="checkbox" id="ospf_area_no_summary" name="no_summary">
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col">
                        <label>Network (address set)</label>
                        <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                             data-max-select="1" data-filter-scope="network">
                            <input type="hidden" id="ospf_area_network_set" name="network_set" value="">
                            <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                data-placeholder="Select network set">
                                <span class="js-set-picker-label">Select network</span>
                            </button>
                            <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                title="Clear selection">&#215;</button>
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-col">
                        <button type="button" class="std-btn" data-js="ospf-area-save">Add Area</button>
                        <button type="button" class="std-btn std-btn--secondary" data-js="ospf-add-area-cancel">Cancel</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Interface Settings -->
        <div class="content-box">
            <div class="content-box-header">
                <h2>Interface Settings</h2>
                <?php if (!empty($page_data['can_add'])): ?>
                <button type="button" class="std-btn" data-js="ospf-add-iface-open">+ Add Interface</button>
                <?php endif; ?>
            </div>
            <table class="std-table" id="ospf-ifaces-table">
                <thead>
                    <tr>
                        <th>Interface</th>
                        <th>Hello (s)</th>
                        <th>Dead (s)</th>
                        <th>Priority</th>
                        <th>Cost</th>
                        <th>Poll (s)</th>
                        <th>Passive</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="ospf-ifaces-tbody">
                <?php if (empty($interfaces)): ?>
                    <tr class="std-table-empty"><td colspan="8">No interface overrides configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($interfaces as $iface): ?>
                    <?php $ifaceDisplay = $iface['iface_display'] ?? null; ?>
                    <tr data-iface-id="<?= $iface['id'] ?>">
                        <td>
                            <?php if ($ifaceDisplay): ?>
                                <span class="set-ref" title="ID: <?= $ifaceDisplay['id'] ?>">
                                    <span class="set-name"><?= $ifaceDisplay['name'] ?></span>
                                </span>
                            <?php else: ?>
                                <?= $iface['iface'] ?>
                            <?php endif; ?>
                        </td>
                        <td><?= $iface['hello_interval'] ?></td>
                        <td><?= $iface['dead_interval'] ?></td>
                        <td><?= $iface['priority'] ?></td>
                        <td><?= $iface['cost_display'] ?></td>
                        <td><?= $iface['poll_interval'] ?></td>
                        <td><?= $iface['passive_label'] ?></td>
                        <td>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="ospf-delete-iface" data-id="<?= $iface['id'] ?>">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Add interface form (hidden) -->
        <div class="content-box" id="ospf-add-iface-form" style="display:none;">
            <h2>Add Interface Override</h2>
            <form class="std-form form-compact" data-js="ospf-iface-form">
                <div class="form-row">
                    <div class="form-col">
                        <label for="ospf_iface">Interface</label>
                        <select id="ospf_iface" class="std-input" required>
                            <option value="">Select interface</option>
                            <?php foreach ($ifaces as $iface): ?>
                            <option value="<?= $iface['id'] ?>"><?= $iface['interface'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf_iface_priority">Priority</label>
                        <input type="number" id="ospf_iface_priority" name="priority" class="std-input"
                            min="0" max="255" value="1">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf_iface_cost">Cost</label>
                        <input type="number" id="ospf_iface_cost" name="cost" class="std-input"
                            min="1" max="65535" placeholder="auto">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf_iface_hello">Hello (s)</label>
                        <input type="number" id="ospf_iface_hello" name="hello_interval" class="std-input"
                            min="1" max="65535" value="10">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf_iface_dead">Dead (s)</label>
                        <input type="number" id="ospf_iface_dead" name="dead_interval" class="std-input"
                            min="1" max="65535" value="40">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf_iface_poll">Poll (s)</label>
                        <input type="number" id="ospf_iface_poll" name="poll_interval" class="std-input"
                            min="1" max="65535" value="120">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf_iface_passive">Passive</label>
                        <label class="std-switch">
                            <input type="checkbox" id="ospf_iface_passive" name="passive">
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-col">
                        <button type="button" class="std-btn" data-js="ospf-iface-save">Add Interface</button>
                        <button type="button" class="std-btn std-btn--secondary" data-js="ospf-add-iface-cancel">Cancel</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Neighbors (read-only, discovered by OSPF) -->
        <div class="content-box">
            <h2>OSPF Neighbors</h2>
            <table class="std-table" id="ospf-neighbors-table">
                <thead>
                    <tr>
                        <th>Neighbor ID</th>
                        <th>Interface</th>
                        <th>State</th>
                        <th>Dead Time</th>
                        <th>Address</th>
                    </tr>
                </thead>
                <tbody id="ospf-neighbors-tbody">
                <?php if (empty($neighbors)): ?>
                    <tr class="std-table-empty"><td colspan="5">No neighbors discovered.</td></tr>
                <?php else: ?>
                    <?php foreach ($neighbors as $n): ?>
                    <tr>
                        <td><?= $n['neighbor_id'] ?></td>
                        <td><?= $n['interface'] ?></td>
                        <td><span class="std-badge std-badge--<?= $n['state'] === 'full' ? 'active' : 'inactive' ?>"><span class="std-status-dot <?= $n['state'] === 'full' ? 'on' : 'off' ?>"></span><?= $n['state'] ?></span></td>
                        <td><?= $n['dead_time'] ?? '-' ?></td>
                        <td><?= $n['address'] ?? '-' ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div><!-- /tab-ospf-v2 -->

    <!-- OSPFv3 -->
    <div class="std-tab-panel" id="tab-ospf-v3">

        <details class="nat-help">
            <summary>Help - OSPFv3</summary>
            <div class="nat-help-content">
                <p><strong>OSPFv3</strong> is the IPv6-capable version of OSPF. It uses link-local addresses for adjacency and supports multiple instances per link.</p>
                <ul>
                    <li><strong>Router ID:</strong> Still a 32-bit dotted-quad (same format as OSPFv2).</li>
                    <li><strong>Areas:</strong> Normal or NSSA only (stub is not supported in OSPFv3). Each area needs an IPv6 network prefix.</li>
                    <li><strong>Interfaces:</strong> Assign an interface UUID and area label. Configure priority, cost, timers, and passive mode per interface.</li>
                </ul>
            </div>
        </details>

        <div class="content-box">
            <h2>OSPFv3 Configuration</h2>
            <form class="std-form form-compact" data-js="ospf6-config-form">
                <div class="form-row">
                    <div class="form-col form-col--tight">
                        <label for="ospf6_enabled">Enabled</label>
                        <label class="std-switch">
                            <input type="checkbox" id="ospf6_enabled"
                                <?= !empty($ospf6_config['enabled']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                    <div class="form-col">
                        <label>Router ID</label>
                        <?php $rid6 = $ospf6_config['router_id_display'] ?? null; ?>
                        <div class="set-picker-field" data-js="label-picker-field" data-set-type="router_id"
                             data-max-select="1" data-label-title="Select Router ID">
                            <input type="hidden" id="ospf6_router_id"
                                value="<?= $ospf6_config['router_id'] ?? '' ?>">
                            <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                data-placeholder="Select Router ID">
                                <span class="js-set-picker-label"><?= $rid6 ? $rid6['name'] : 'Select Router ID' ?></span>
                            </button>
                            <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear<?= $rid6 ? '' : ' sets-hidden' ?>"
                                title="Clear">&#215;</button>
                        </div>
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf6_ref_bw">Reference BW (Mbps)</label>
                        <input type="number" id="ospf6_ref_bw" class="std-input" min="1"
                            value="<?= $ospf6_config['reference_bandwidth'] ?? 100 ?>">
                    </div>
                    <div class="form-col form-col--tight">
                        <label for="ospf6_log_adj">Log Adjacency</label>
                        <label class="std-switch">
                            <input type="checkbox" id="ospf6_log_adj"
                                <?= !empty($ospf6_config['log_adjacency_changes']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-col form-col--tight">
                        <label for="ospf6_stub_router">Stub Router Admin</label>
                        <label class="std-switch">
                            <input type="checkbox" id="ospf6_stub_router"
                                <?= !empty($ospf6_config['stub_router_administrative']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <?php if (!empty($page_data['can_save'])): ?>
                <button type="button" class="std-btn" data-js="ospf6-save-config">Save</button>
                <?php endif; ?>
            </form>
        </div>

        <div class="content-box">
            <div class="content-box-header">
                <h2>OSPFv3 Areas</h2>
                <?php if (!empty($page_data['can_add'])): ?>
                <button type="button" class="std-btn" data-js="ospf6-add-area-open">+ Add Area</button>
                <?php endif; ?>
            </div>
            <div class="content-box" id="ospf6-add-area-form" style="display:none;">
                <h3>Add OSPFv3 Area</h3>
                <form class="std-form form-compact" data-js="ospf6-area-form">
                    <div class="form-row">
                        <div class="form-col form-col--tight">
                            <label>Area ID</label>
                            <div class="set-picker-field" data-js="label-picker-field"
                                 data-set-type="ospf_area" data-max-select="1">
                                <input type="hidden" id="ospf6_area_id" value="">
                                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select area">
                                    <span class="js-set-picker-label">Select area</span>
                                </button>
                                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear">&#215;</button>
                            </div>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="ospf6_area_type">Type</label>
                            <select id="ospf6_area_type" class="std-input">
                                <option value="normal">normal</option>
                                <option value="nssa">nssa</option>
                            </select>
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="ospf6_area_nosum">No Summary</label>
                            <label class="std-switch">
                                <input type="checkbox" id="ospf6_area_nosum">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <div class="form-col">
                            <label>Network (address set)</label>
                            <div class="set-picker-field" data-js="set-picker-field"
                                 data-set-type="address" data-max-select="1" data-filter-scope="network">
                                <input type="hidden" id="ospf6_network_set" value="">
                                <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                    data-placeholder="Select network">
                                    <span class="js-set-picker-label">Select network</span>
                                </button>
                                <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                    title="Clear">&#215;</button>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <button type="button" class="std-btn" data-js="ospf6-area-save">Add Area</button>
                        <button type="button" class="std-btn std-btn--secondary" data-js="ospf6-add-area-cancel">Cancel</button>
                    </div>
                </form>
            </div>
            <table class="std-table">
                <thead><tr><th>Area ID</th><th>Type</th><th>Network</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if (empty($areas6)): ?>
                    <tr class="std-table-empty"><td colspan="4">No areas configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($areas6 as $a): ?>
                    <tr data-area-id="<?= $a['id'] ?>">
                        <td><?= $a['area_id_display']['name'] ?? $a['area_id'] ?></td>
                        <td><?= $a['type'] ?? 'normal' ?></td>
                        <td><?= $a['network_set_display']['name'] ?? $a['network_set'] ?></td>
                        <td>
                            <?php if (!empty($a['can_delete'])): ?>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="ospf6-delete-area" data-id="<?= $a['id'] ?>">Delete</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="content-box">
            <div class="content-box-header">
                <h2>OSPFv3 Interfaces</h2>
                <?php if (!empty($page_data['can_add'])): ?>
                <button type="button" class="std-btn" data-js="ospf6-add-iface-open">+ Add Interface</button>
                <?php endif; ?>
            </div>
            <div class="content-box" id="ospf6-add-iface-form" style="display:none;">
                <h3>Add OSPFv3 Interface</h3>
                <form class="std-form form-compact" data-js="ospf6-iface-form">
                    <div class="form-row">
                        <div class="form-col">
                            <label for="ospf6_iface">Interface</label>
                            <select id="ospf6_iface" class="std-input" required>
                                <option value="">Select interface</option>
                                <?php foreach ($ifaces as $iface): ?>
                                <option value="<?= $iface['id'] ?>"><?= $iface['interface'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-col">
                            <label for="ospf6_iface_area">Area</label>
                            <input type="text" id="ospf6_iface_area" class="std-input" required placeholder="Area label UUID">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="ospf6_iface_prio">Priority</label>
                            <input type="number" id="ospf6_iface_prio" class="std-input" min="0" max="255" value="1">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="ospf6_iface_cost">Cost</label>
                            <input type="number" id="ospf6_iface_cost" class="std-input" min="1" placeholder="auto">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col form-col--tight">
                            <label for="ospf6_iface_hello">Hello (s)</label>
                            <input type="number" id="ospf6_iface_hello" class="std-input" min="1" value="10">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="ospf6_iface_dead">Dead (s)</label>
                            <input type="number" id="ospf6_iface_dead" class="std-input" min="1" value="40">
                        </div>
                        <div class="form-col form-col--tight">
                            <label for="ospf6_iface_passive">Passive</label>
                            <label class="std-switch">
                                <input type="checkbox" id="ospf6_iface_passive">
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row">
                        <button type="button" class="std-btn" data-js="ospf6-iface-save">Add Interface</button>
                        <button type="button" class="std-btn std-btn--secondary" data-js="ospf6-add-iface-cancel">Cancel</button>
                    </div>
                </form>
            </div>
            <table class="std-table">
                <thead><tr><th>Interface</th><th>Area</th><th>Hello</th><th>Dead</th><th>Pri</th><th>Cost</th><th>Passive</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if (empty($interfaces6)): ?>
                    <tr class="std-table-empty"><td colspan="8">No interface overrides.</td></tr>
                <?php else: ?>
                    <?php foreach ($interfaces6 as $iface): ?>
                    <tr data-iface-id="<?= $iface['id'] ?>">
                        <td><?= $iface['iface_display'] ?? $iface['iface'] ?></td>
                        <td><?= $iface['area_set_display']['name'] ?? $iface['area_set'] ?></td>
                        <td><?= $iface['hello_interval'] ?></td>
                        <td><?= $iface['dead_interval'] ?></td>
                        <td><?= $iface['priority'] ?></td>
                        <td><?= $iface['cost_display'] ?></td>
                        <td><?= $iface['passive_label'] ?></td>
                        <td>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="ospf6-delete-iface" data-id="<?= $iface['id'] ?>">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="content-box">
            <h2>OSPFv3 Neighbors</h2>
            <table class="std-table">
                <thead><tr><th>Neighbor ID</th><th>Interface</th><th>State</th><th>Dead Time</th><th>Address</th></tr></thead>
                <tbody>
                <?php if (empty($neighbors6)): ?>
                    <tr class="std-table-empty"><td colspan="5">No neighbors.</td></tr>
                <?php else: ?>
                    <?php foreach ($neighbors6 as $n): ?>
                    <tr>
                        <td><?= $n['neighbor_id'] ?></td>
                        <td><?= $n['interface'] ?></td>
                        <td><span class="std-badge std-badge--<?= ($n['state'] ?? '') === 'full' ? 'active' : 'inactive' ?>"><?= $n['state'] ?></span></td>
                        <td><?= $n['dead_time'] ?? '-' ?></td>
                        <td><?= $n['address'] ?? '-' ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div><!-- /tab-ospf-v3 -->

    </main>
</div>
