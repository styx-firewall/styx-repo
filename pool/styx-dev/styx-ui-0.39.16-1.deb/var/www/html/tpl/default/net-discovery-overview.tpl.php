<?php
/**
 * Fragment: Network Discovery Overview tab.
 * Loaded via load_tpl into the disc-overview panel.
 * Expects $tdata['tpl_data'] with keys: service_status, stats, source_labels.
 *
 * @var array<mixed> $tdata
 */

$stats       = $tdata['tpl_data']['stats'] ?? [];
$source_labels = $tdata['tpl_data']['source_labels'] ?? [];

$total               = (int)($stats['total'] ?? 0);
$with_mac            = (int)($stats['with_mac'] ?? 0);
$with_hostname       = (int)($stats['with_hostname'] ?? 0);
$router_count        = (int)($stats['router_count'] ?? 0);
$discovered_last_hour = (int)($stats['discovered_last_hour'] ?? 0);
$discovered_last_24h  = (int)($stats['discovered_last_24h'] ?? 0);
$discovered_last_week = (int)($stats['discovered_last_week'] ?? 0);
$seen_count   = (int)($stats['seen'] ?? 0);
$unseen_count = (int)($stats['unseen'] ?? 0);
$by_source           = $stats['by_source'] ?? [];
$top_vendors         = $stats['top_vendors'] ?? [];
?>

<!-- Summary cards -->
<div class="disc-cards-row">
    <div class="content-box disc-card">
        <div class="disc-card-value" data-js="disc-ov-total"><?= $total ?></div>
        <div class="disc-card-label">Discovered Hosts</div>
    </div>
    <div class="content-box disc-card">
        <div class="disc-card-value" data-js="disc-ov-routers"><?= $router_count ?></div>
        <div class="disc-card-label">Routers</div>
    </div>
    <div class="content-box disc-card">
        <div class="disc-card-value" data-js="disc-ov-mac"><?= $with_mac ?></div>
        <div class="disc-card-label">With L2 MAC</div>
    </div>
    <div class="content-box disc-card">
        <div class="disc-card-value" data-js="disc-ov-hostname"><?= $with_hostname ?></div>
        <div class="disc-card-label">Resolved Names</div>
    </div>
    <div class="content-box disc-card">
        <div class="disc-card-value" data-js="disc-ov-hour"><?= $discovered_last_hour ?></div>
        <div class="disc-card-label">New (last hour)</div>
    </div>
    <div class="content-box disc-card">
        <div class="disc-card-value" data-js="disc-ov-24h"><?= $discovered_last_24h ?></div>
        <div class="disc-card-label">New (last 24h)</div>
    </div>
    <div class="content-box disc-card">
        <div class="disc-card-value" data-js="disc-ov-week"><?= $discovered_last_week ?></div>
        <div class="disc-card-label">New (last week)</div>
    </div>
    <div class="content-box disc-card disc-card-online">
        <div class="disc-card-value disc-online" data-js="disc-ov-online"><?= $seen_count ?></div>
        <div class="disc-card-label">Seen (&lt;10 min)</div>
    </div>
    <div class="content-box disc-card disc-card-offline">
        <div class="disc-card-value disc-offline" data-js="disc-ov-offline"><?= $unseen_count ?></div>
        <div class="disc-card-label">Unseen (&gt;10 min)</div>
    </div>
</div>

<!-- Bottom tables side by side -->
<div class="disc-bottom-row">
<?php if (!empty($top_vendors)): ?>
<div class="content-box disc-section disc-half">
    <h3>Top 10 Vendors</h3>
    <table class="std-table disc-vendor-table">
        <thead>
            <tr><th>Vendor</th><th>Hosts</th></tr>
        </thead>
        <tbody>
            <?php foreach ($top_vendors as $v): ?>
            <tr>
                <td><?= $v['vendor'] !== '' ? $v['vendor'] : '<em>Unknown</em>' ?></td>
                <td><?= (int)$v['count'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php if (!empty($by_source)): ?>
<div class="content-box disc-section disc-half">
    <h3>Discovery Sources</h3>
    <table class="std-table disc-source-table">
        <thead>
            <tr><th>Source</th><th>Hosts</th></tr>
        </thead>
        <tbody>
            <?php foreach ($by_source as $src => $count): ?>
            <tr>
                <td><?= $source_labels[$src] ?? $src ?></td>
                <td><?= (int)$count ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
</div>
