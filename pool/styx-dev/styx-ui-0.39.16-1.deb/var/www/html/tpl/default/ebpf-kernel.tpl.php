<?php
/**
 * eBPF fragment: foreign programs, conflicts, coexisting sections.
 *
 * @var array $tdata - $tdata['tpl_data'] contains the full formatted page data
 */
$pd = $tdata['tpl_data'] ?? [];
$hasNewForeign = $pd['has_new_foreign'] ?? false;
$canWrite = $pd['can_write'] ?? false;
?>

<!-- Styx Internal Programs -->
<?php if ($pd['has_internal'] ?? false): ?>
<div id="ebpf-internal-section" class="ebpf-section ebpf-collapsible-section">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-internal-body">
        <span class="ebpf-section-title">Styx Internal</span>
        <span id="ebpf-internal-count" class="ebpf-count-badge"><?= count($pd['internal_rows']) ?></span>
        <span class="ebpf-collapse-arrow">▼</span>
    </div>
    <div id="ebpf-internal-body" class="ebpf-collapse-body hidden">
        <table id="ebpf-internal-table" class="ebpf-module-table">
            <thead><tr><th>ID</th><th>Type</th><th>Name</th><th>Tag</th><th>Loaded At</th><th>UID</th></tr></thead>
            <tbody>
                <?php foreach ($pd['internal_rows'] as $ir): ?>
                <tr>
                    <td><?= htmlspecialchars((string)$ir['id'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($ir['type'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($ir['name'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td class="ebpf-mono"><?= htmlspecialchars($ir['tag'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($ir['loaded_at'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars((string)$ir['uid'], ENT_QUOTES, 'UTF-8') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Foreign Programs -->
<?php if ($pd['has_foreign'] ?? false): ?>
<div id="ebpf-foreign-section" class="ebpf-section ebpf-collapsible-section"
     data-has-new-foreign="<?= $hasNewForeign ? '1' : '0' ?>">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-foreign-body">
        <span class="ebpf-section-title">Foreign Programs</span>
        <span id="ebpf-foreign-count" class="ebpf-count-badge"><?= count($pd['foreign_rows']) ?></span>
        <?php if ($hasNewForeign): ?>
        <span id="ebpf-foreign-new-badge" class="ebpf-new-badge--warn">WARNING</span>
        <?php endif; ?>
        <span class="ebpf-collapse-arrow">▼</span>
    </div>
    <div id="ebpf-foreign-body" class="ebpf-collapse-body hidden">
        <?php if ($hasNewForeign): ?>
        <div id="ebpf-foreign-ack-bar" class="ebpf-ack-bar">
            <span class="ebpf-ack-bar-text">⚠ Unrecognized BPF programs detected</span>
            <button id="ebpf-ack-all-btn" class="std-btn ebpf-btn-ack-all" type="button">Acknowledge All</button>
        </div>
        <?php endif; ?>
        <table id="ebpf-foreign-table" class="ebpf-module-table">
            <thead><tr><th>ID</th><th>Type</th><th>Name</th><th>Tag</th><th>Loaded At</th><th>UID</th><?php if ($canWrite): ?><th>Actions</th><?php endif; ?></tr></thead>
            <tbody>
                <?php foreach ($pd['foreign_rows'] as $fr): ?>
                <tr<?= ($fr['is_new'] ?? false) ? ' class="ebpf-foreign-new-row"' : '' ?>>
                    <td><?= htmlspecialchars((string)$fr['id'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($fr['type'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($fr['name'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td class="ebpf-mono"><?= htmlspecialchars($fr['tag'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($fr['loaded_at'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars((string)$fr['uid'], ENT_QUOTES, 'UTF-8') ?></td>
                    <?php if ($canWrite): ?>
                    <td>
                        <?php if ($fr['detachable'] ?? false): ?>
                        <button class="std-btn ebpf-detach-btn"
                                data-program-id="<?= htmlspecialchars((string)$fr['id'], ENT_QUOTES, 'UTF-8') ?>"
                                data-program-name="<?= htmlspecialchars($fr['name'], ENT_QUOTES, 'UTF-8') ?>"
                                data-program-type="<?= htmlspecialchars($fr['type'], ENT_QUOTES, 'UTF-8') ?>"
                                data-is-xdp="<?= ($fr['is_xdp'] ?? false) ? '1' : '0' ?>"
                                data-has-dispatcher="<?= ($fr['has_dispatcher'] ?? false) ? '1' : '0' ?>"
                                type="button">Detach</button>
                        <?php else: ?>
                        <button class="std-btn ebpf-detach-btn ebpf-detach-btn--disabled"
                                title="Manual detach required - use bpftool"
                                disabled
                                type="button">Detach</button>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Conflicts -->
<?php if ($pd['has_conflicts'] ?? false): ?>
<div id="ebpf-conflicts-section" class="ebpf-section ebpf-collapsible-section">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-conflicts-body">
        <span class="ebpf-section-title ebpf-section-title--warn">⚠ Conflicts</span>
        <span id="ebpf-conflicts-count" class="ebpf-count-badge ebpf-count-badge--warn"><?= count($pd['conflict_rows']) ?></span>
        <span class="ebpf-collapse-arrow">▼</span>
    </div>
    <div id="ebpf-conflicts-body" class="ebpf-collapse-body hidden">
        <table id="ebpf-conflicts-table" class="ebpf-module-table">
            <thead><tr><th>Interface</th><th>Hook</th><th>Styx Module</th><th>Occupied By</th></tr></thead>
            <tbody>
                <?php foreach ($pd['conflict_rows'] as $cr): ?>
                <tr>
                    <td><?= htmlspecialchars($cr['interface'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($cr['hook'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><b><?= htmlspecialchars($cr['styx_module'], ENT_QUOTES, 'UTF-8') ?></b></td>
                    <td><?= htmlspecialchars($cr['occupied_by'], ENT_QUOTES, 'UTF-8') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Coexisting -->
<?php if ($pd['has_coexisting'] ?? false): ?>
<div id="ebpf-coexisting-section" class="ebpf-section ebpf-collapsible-section">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-coexisting-body">
        <span class="ebpf-section-title">Coexisting</span>
        <span id="ebpf-coexisting-count" class="ebpf-count-badge"><?= count($pd['coexisting_rows']) ?></span>
        <span class="ebpf-collapse-arrow">▼</span>
    </div>
    <div id="ebpf-coexisting-body" class="ebpf-collapse-body hidden">
        <table id="ebpf-coexisting-table" class="ebpf-module-table">
            <thead><tr><th>Interface</th><th>Hook</th><th>Styx Module</th><th>Other Programs</th></tr></thead>
            <tbody>
                <?php foreach ($pd['coexisting_rows'] as $cr): ?>
                <tr>
                    <td><?= htmlspecialchars($cr['interface'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($cr['hook'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><b><?= htmlspecialchars($cr['styx_module'], ENT_QUOTES, 'UTF-8') ?></b></td>
                    <td><?= htmlspecialchars($cr['others'], ENT_QUOTES, 'UTF-8') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
