<?php

/**
 * TemplateService->getTpl()

 * @var array<mixed> $tdata
 */

// Template consumes `users_regular_rows` and `users_system_rows` prepared by formatter
$users_regular = $tdata['page_data']['users_regular_rows'] ?? [];
$users_system = $tdata['page_data']['users_system_rows'] ?? [];
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Users</h1>
        <div class="content-box">
        <h3>Regular users (UID &gt; 1000)</h3>
            <table class="std-table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>UID</th>
                        <th>GID</th>
                        <th>Home</th>
                        <th>Shell</th>
                        <th>Groups</th>
                        <th>Gecos</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($users_regular as $user): ?>
                    <tr>
                        <td><?= $user['username'] ?></td>
                        <td><?= $user['uid'] ?></td>
                        <td><?= $user['gid'] ?></td>
                        <td><?= $user['home'] ?></td>
                        <td><?= $user['shell'] ?></td>
                        <td><?= $user['groups_str'] ?></td>
                        <td><?= $user['gecos'] ?></td>
                        <td>
                            <?php if (!empty($user['can_edit'])): ?>
                            <button class="std-btn"
                                data-edit-user='<?= $user['edit_json'] ?>'
                            >
                                Edit
                            </button>
                            <?php endif; ?>
                            <?php if (!empty($user['can_delete'])): ?>
                            <button class="std-btn">
                                Delete
                            </button>
                            <?php endif; ?>
                            <?php if (!empty($user['can_lock'])): ?>
                            <button class="std-btn"
                                style="<?= $user['lock_btn_style'] ?>"
                                title="<?= $user['lock_btn_text'] ?> user"
                                data-locked="<?= $user['lock_btn_data'] ?>"
                            >
                                <?= $user['lock_btn_text'] ?>
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php if (!empty($tdata['page_data']['can_add'])): ?>
        <button id="addUserBtn" class="std-btn">Add User</button>
        <?php endif; ?>
        </div>
        <div class="content-box">
            <h3>System users (UID ≤ 1000)</h3>
            <table class="std-table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>UID</th>
                        <th>GID</th>
                        <th>Home</th>
                        <th>Shell</th>
                        <th>Groups</th>
                        <th>Gecos</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($users_system as $user): ?>
                    <tr>
                        <td><?= $user['username'] ?></td>
                        <td><?= $user['uid'] ?></td>
                        <td><?= $user['gid'] ?></td>
                        <td><?= $user['home'] ?></td>
                        <td><?= $user['shell'] ?></td>
                        <td><?= $user['groups_str'] ?></td>
                        <td><?= $user['gecos'] ?></td>
                        <td>
                            <?php if (!empty($user['can_edit'])): ?>
                            <button
                                data-edit-user='<?= $user['edit_json'] ?>'
                            >
                                Edit
                            </button>
                            <?php endif; ?>
                            <?php if (!empty($user['can_delete'])): ?>
                            <button>
                                Delete
                            </button>
                            <?php endif; ?>
                            <?php if (!empty($user['can_lock'])): ?>
                            <button
                                style="<?= $user['lock_btn_style'] ?>"
                                title="<?= $user['lock_btn_text'] ?> user"
                                data-locked="<?= $user['lock_btn_data'] ?>"
                            >
                                <?= $user['lock_btn_text'] ?>
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<template id="tmpl-user-form">
    <h2 data-js="user-form-title" class="user-form-title"></h2>
    <form id="userForm" autocomplete="off" class="user-form">
        <div class="user-form-field">
            <label class="user-form-label">Username:</label>
            <input type="text" name="username" required autocomplete="off">
        </div>
        <div class="user-form-field">
            <label class="user-form-label">Comment (Gecos):</label>
            <input type="text" name="gecos" autocomplete="off">
        </div>
        <div class="user-form-field">
            <label class="user-form-label">Password:</label>
            <input type="password" name="password" required autocomplete="new-password">
        </div>
        <div class="user-form-check">
            <input type="checkbox" name="nologin" id="nologinCheckbox">
            <label for="nologinCheckbox">Do not allow login (nologin)</label>
        </div>
        <div class="user-form-field">
            <label class="user-form-label">Extra groups:</label>
            <select name="groups" multiple size="3" class="std-select"></select>
        </div>
        <button type="submit" class="std-btn user-form-submit"
            data-js="user-form-submit"></button>
    </form>
</template>
