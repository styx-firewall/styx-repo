<?php

/**
 * TemplateService->getTpl()
 *
 * @var array<mixed> $tdata
 */

$aide_data = $tdata['page_data']['aide'] ?? [];

$status = $aide_data['status'] ?? ($aide_data['result']['status'] ?? 'unknown');
$last_check = $aide_data['result']['last_check'] ?? '';
$summary = $aide_data['result']['summary'] ?? [];
$alerts = $aide_data['result']['alerts'] ?? [];

?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>AIDEAdvanced Intrusion Detection Environment</h1>

        <div class="content-box">
            <h2>Status</h2>
            <div class="aide-status">
                <span class="aide-status-badge aide-status-<?= $status ?>">
                    <?= ucfirst($status) ?>
                </span>
                <?php if (!empty($last_check)): ?>
                <span class="aide-last-check">Last check: <?= $last_check ?></span>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($summary)): ?>
        <div class="content-box">
            <h2>Summary</h2>
            <table class="aide-summary-table">
                <thead>
                    <tr>
                        <th>Metric</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($summary as $key => $value): ?>
                    <tr>
                        <td><?= ucfirst(str_replace('_', ' ', $key)) ?></td>
                        <td><?= (string)$value ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <?php if (!empty($alerts)): ?>
        <div class="content-box">
            <h2>Alerts</h2>
            <table class="aide-alerts-table">
                <thead>
                    <tr>
                        <th>File</th>
                        <th>Change</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($alerts as $alert): ?>
                    <tr>
                        <td><?= $alert['file'] ?? '' ?></td>
                        <td><?= $alert['change'] ?? '' ?></td>
                        <td><?= $alert['details'] ?? '' ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <?php if (empty($summary) && empty($alerts)): ?>
        <div class="content-box">
            <div class="empty">No AIDE data available.</div>
        </div>
        <?php endif; ?>
    </main>
</div>
