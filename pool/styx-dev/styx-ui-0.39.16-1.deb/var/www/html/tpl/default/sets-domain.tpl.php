<?php
/**
 * Fragment: Domain sets - unified panel.
 * mode=mgmt   : accordion panel on Objects page (headings + text filter)
 * mode=picker : selection modal - CRUD available + checkbox column + confirm button
 * Expects $tdata['tpl_data']['domain_sets'], $tdata['tpl_data']['mode']
 */
$domain_sets = $tdata['tpl_data']['domain_sets'] ?? [];
$mode = $tdata['tpl_data']['mode'] ?? 'picker';
?>
<?php if ($mode === 'mgmt'): ?>
<h2>Domain Sets</h2>
<?php endif; ?>
<form id="domain-set-form" class="std-form" autocomplete="off">
    <input type="hidden" name="id" id="domain_id" value="">
    <div class="std-flex-row">
        <label>Type*
            <select name="type" required>
                <option value="single">Single</option>
                <option value="set">Set</option>
            </select>
        </label>
        <label>Name*
            <span class="js-info-icon" data-info-modal="help-domain-name"></span>
            <input type="text" name="name" required maxlength="32" placeholder="Unique name">
        </label>
        <label>Description
            <span class="js-info-icon" data-info-modal="help-domain-description"></span>
            <input type="text" name="description" maxlength="64" placeholder="Optional">
        </label>
        <label>Tags
            <span class="js-info-icon" data-info-modal="help-domain-tags"></span>
            <input type="text" name="tags" placeholder="Tags separated by spaces or commas">
        </label>
    </div>

    <div class="std-flex-row value-row value-row-single">
        <label>Domain*
            <input type="text" name="value_single" placeholder="E.g.: example.com">
        </label>
    </div>

    <div class="std-flex-row value-row value-row-set sets-hidden">
        <label>Domains*
            <div class="set-list"></div>
            <button type="button" class="add-set-btn std-btn">Add</button>
        </label>
    </div>

    <div id="help-domain-name" style="display:none">
        <p><strong>Name</strong>: Fully qualified domain name for matching.</p>
    </div>
    <div id="help-domain-description" style="display:none">
        <p><strong>Description</strong>: Optional human-readable description.</p>
    </div>
    <div id="help-domain-tags" style="display:none">
        <p><strong>Tags</strong>: Space or comma-separated tags for filtering.</p>
    </div>

    <div class="std-flex-row">
        <button type="submit" class="std-btn">Save</button>
        <button type="button" class="std-btn cancel-edit-btn sets-hidden">Cancel</button>
    </div>
</form>

<hr>
<?php if ($mode === 'mgmt'): ?>
<h3>Existing Domain Sets</h3>
<?php endif; ?>
<?php if ($mode === 'mgmt' || $mode === 'picker'): ?>
<div class="std-flex-row filters-row">
    <label>Filter
        <input type="text" id="domain-filter" class="set-filter-input" placeholder="Filter by name, value or tags">
    </label>
</div>
<?php endif; ?>
<table class="std-table" id="domain-set-table">
    <thead>
        <tr>
            <?php if ($mode === 'picker'): ?><th>Select</th><?php endif; ?>
            <th>Name</th>
            <th>Type</th>
            <th>Value</th>
            <th>Description</th>
            <th>Tags</th>
            <th>Refs</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($domain_sets as $d): ?>
            <tr>
                <?php if ($mode === 'picker'): ?>
                <td>
                    <input type="checkbox" class="js-set-pick-row"
                        value="<?= $d['id'] ?? '' ?>"
                        data-name="<?= $d['name'] ?? '' ?>">
                </td>
                <?php endif; ?>
                <td class="col-name"><?= $d['name'] ?? '' ?></td>
                <td class="col-type"><?= $d['type'] ?? '' ?></td>
                <td class="col-value"><?= $d['value_display'] ?? '' ?></td>
                <td class="col-description"><?= $d['description'] ?? '' ?></td>
                <td class="tags-cell col-tags"><?= $d['tags_html'] ?? '' ?></td>
                <td class="col-refs"><?= $d['refs_count'] ?? 0 ?></td>
                <td>
                    <button class="std-btn std-btn-edit"
                        data-id="<?= $d['id'] ?? '' ?>"
                        aria-label="Edit" title="Edit"></button>
                    <?php if (($d['refs_count'] ?? 0) == 0): ?>
                        <button class="std-btn std-btn-delete"
                            data-id="<?= $d['id'] ?? '' ?>"
                            aria-label="Delete" title="Delete"></button>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php if ($mode === 'picker'): ?>
<div class="js-set-picker-actions sets-hidden">
    <button type="button" class="std-btn js-set-picker-confirm">Use selected</button>
</div>
<?php endif; ?>
