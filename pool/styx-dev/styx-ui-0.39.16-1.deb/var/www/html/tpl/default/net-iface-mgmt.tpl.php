<?php
/**
 *
 * Interface Management Template
 * Types: physical_ethernet, virtual_ethernet, vlan, bridge, bond, loopback, wifi
 * JS Include net-iface-mgmt.js
 */

// Presentation variables prepared by App\Pages\Fmt\NetIfaceFormatter
$action = $tdata['page_data']['action'];
$iface_type = $tdata['page_data']['iface_type'];
$iface_subtype = $tdata['page_data']['iface_subtype'] ?? '';
$iface_config = $tdata['page_data']['iface_config'];
$sysctl_keys = $tdata['page_data']['sysctl_keys'];
$iface_name = $tdata['page_data']['iface_name'];
$interface_list = $tdata['page_data']['interface_list'];
$interface_options = $tdata['page_data']['interface_options'];
$bridge_ports_options = $tdata['page_data']['bridge_ports_options'];
$bond_slaves_options = $tdata['page_data']['bond_slaves_options'];
$has_interface_list = $tdata['page_data']['has_interface_list'];
$no_interfaces_msg = $tdata['page_data']['no_interfaces_msg'];
$interface_options_html = $tdata['page_data']['interface_options_html'] ?? '';
$bridge_ports_options_html = $tdata['page_data']['bridge_ports_options_html'] ?? '';
$bridge_ports_options_noselect_html = $tdata['page_data']['bridge_ports_options_noselect_html'] ?? '';
$bridge_own_ports_options = $tdata['page_data']['bridge_own_ports_options'] ?? [];
$bridge_own_ports_options_html = $tdata['page_data']['bridge_own_ports_options_html'] ?? '';
$bond_slaves_options_html = $tdata['page_data']['bond_slaves_options_html'] ?? '';
$ip_mode = $tdata['page_data']['ip_mode'];
$vlan_id = $tdata['page_data']['vlan_id'];
$role = $tdata['page_data']['role'];
$ifaceRoles = $tdata['page_data']['iface_roles'] ?? [];
$parent_iface = $tdata['page_data']['parent_iface'];
$bridge_ports = $tdata['page_data']['ports'];
$bond_slaves = $tdata['page_data']['slaves'];
$bond_mode = $tdata['page_data']['mode'];
$dhcp_enabled = $tdata['page_data']['dhcp_enabled'];
$has_dhcp_options = $tdata['page_data']['has_dhcp_options'];
$dhcp_range_start = $tdata['page_data']['dhcp_range_start'];
$dhcp_range_end = $tdata['page_data']['dhcp_range_end'];
$dhcp_netmask = $tdata['page_data']['dhcp_netmask'];
$dhcp_gateway = $tdata['page_data']['dhcp_gateway'];
$dhcp_dns = $tdata['page_data']['dhcp_dns'];
$iface_status_checked = $tdata['page_data']['iface_status_checked'];
$mtu_value = $tdata['page_data']['mtu_value'];
$pppoe = $tdata['page_data']['pppoe'];
$wifi_ssid = $tdata['page_data']['wifi_ssid'];
$wifi_pass = $tdata['page_data']['wifi_pass'];
$listen_ssh_checked = $tdata['page_data']['listen_ssh_checked'];
$listen_styx_ui_checked = $tdata['page_data']['listen_styx_ui_checked'];
$ipv4_resolved = $tdata['page_data']['ipv4_resolved'];
$ipv6_resolved = $tdata['page_data']['ipv6_resolved'];

?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>
            <?php if ($action === 'create'): ?>
                Create interface <?= ucfirst($iface_subtype ?: $iface_type) ?>
            <?php else: ?>
                Edit interface <?= $iface_name ?>
                <?php if (!empty($tdata['page_data']['error_msg'])): ?>
                    <div class="im-error">Error: <?= $tdata['page_data']['error_msg'] ?></div>
                <?php endif; ?>
            <?php endif; ?>
        </h1>
        <div class="im-flex-row">
            <div class="im-flex-form">
                <form id="iface-form" class="std-form" method="post" action="?page=network&section=net-iface-mgmt">
                    <input type="hidden" name="action" value="<?= $action ?>">
                    <input type="hidden" name="iface_subtype" value="<?= $iface_subtype ?>">
                    <?php if ($action === 'modify'): ?>
                    <input type="hidden" name="iface_name" value="<?= $iface_name ?>">
                    <input type="hidden" name="iface_id" value="<?= $tdata['page_data']['iface_id'] ?? '' ?>">
                    <?php endif; ?>

                        <!-- Interface status switch -->
                        <label class="im-label-row">
                            <span class="std-switch-label">Status:</span>
                            <label class="std-switch">
                                <input type="checkbox" name="status" id="iface_status_switch" value="up"
                                    <?= $iface_status_checked ?> >
                                <span class="std-switch-slider" data-off="Down" data-on="Up"></span>
                            </label>
                        </label>
                    <!-- Role + Interface name inline row -->
                    <div class="form-inline-row">
                        <?php if ($action === 'modify' || in_array($iface_subtype, ['vlan','bridge','veth','bond','macvlan','loopback','vti','gre','vxlan','pppoe','vrf','xfrm'])): ?>
                        <label>
                            Role
                            <select name="role" id="role_select" class="std-select input-sm">
                                <option value="">Select role...</option>
                                <?php foreach ($ifaceRoles as $r): ?>
                                <option value="<?= $r ?>" <?= $role === $r ? 'selected' : '' ?>><?= strtoupper($r) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                        <?php endif; ?>

                        <?php if ($iface_subtype === 'vlan'): ?>
                        <label>
                            Interface name
                            <input
                                type="text"
                                name="iface_name"
                                id="iface_name_input"
                                value="<?= $iface_name ?>"
                                <?= $action === 'modify' ? 'disabled' : '' ?>
                                <?= $action === 'create' ? 'required' : '' ?>
                            >
                        </label>
                        <?php else: ?>
                        <label>
                            Interface name
                            <input type="text" name="iface_name" id="iface_name_input" value="<?= $iface_name ?>"
                            <?= $action === 'modify' ? 'readonly' : '' ?> required>
                        </label>
                        <?php endif; ?>
                    </div>
                    <!-- IP mode: placed under Role / Interface name -->
                    <?php if (in_array($iface_type, [
                        'physical', 'physical_ethernet', 'virtual_ethernet', 'loopback', 'wifi']
                        ) || in_array($iface_subtype, ['vlan', 'bridge', 'vti', 'gre', 'vxlan', 'macvlan', 'bond', 'pppoe', 'xfrm'])): ?>
                        <label>
                            IP mode
                            <select name="ip_mode" id="ip_mode_select" class="std-select" required>
                                <option value="static" <?= $ip_mode === 'static' ? 'selected' : '' ?>>Static</option>
                                <option value="dhcp" <?= $ip_mode === 'dhcp' ? 'selected' : '' ?>>DHCP</option>
                                <option value="none" <?= $ip_mode === 'none' ? 'selected' : '' ?>>No IP</option>
                            </select>
                        </label>
                        <div id="ip_mode_static" class="im-hide">
                            <div id="ipv4-block">
                                <label>IPv4 addresses</label>
                                <?php
                                $ipv4_selected = $tdata['page_data']['ipv4_selected'] ?? [];
                                foreach ($ipv4_selected as $sel_id):
                                    $sel_name = '';
                                    foreach ($ipv4_resolved as $opt) {
                                        if (($opt['id'] ?? '') === $sel_id) {
                                            $sel_name = $opt['name'] ?? ($opt['id'] ?? '');
                                            break;
                                        }
                                    }
                                    $has_val = !empty($sel_id);
                                ?>
                                <div class="ipv4-row">
                                    <div class="set-picker-field" data-js="set-picker-field"
                                        data-set-type="address" data-filter-family="ip" data-filter-scope="host_prefix" data-max-select="1">
                                        <input type="hidden" name="ipv4[]" value="<?= $has_val ? $sel_id : '' ?>">
                                        <button type="button"
                                            class="std-btn-picker set-picker-trigger js-set-picker-open<?= $has_val ? ' set-picker-trigger--has-value' : '' ?>"
                                            data-placeholder="Select IPv4 address">
                                            <span class="js-set-picker-label"><?= $has_val ? $sel_name : 'Select IPv4 address' ?></span>
                                        </button>
                                        <button type="button"
                                            class="std-btn-picker set-picker-clear js-set-picker-clear<?= $has_val ? '' : ' sets-hidden' ?>"
                                            title="Clear selection">&#215;</button>
                                    </div>
                                    <button type="button" class="remove-ipv4" onclick="removeIpRow(this, 'ipv4')">Remove</button>
                                </div>
                                <?php endforeach; ?>
                                <button type="button" onclick="addIpRow('ipv4')">Add IPv4</button>
                                <template id="ipv4-picker-template">
                                    <div class="ipv4-row">
                                        <div class="set-picker-field" data-js="set-picker-field"
                                            data-set-type="address" data-filter-family="ip" data-filter-scope="host_prefix" data-max-select="1">
                                            <input type="hidden" name="ipv4[]" value="">
                                            <button type="button"
                                                class="std-btn-picker set-picker-trigger js-set-picker-open"
                                                data-placeholder="Select IPv4 address">
                                                <span class="js-set-picker-label">Select IPv4 address</span>
                                            </button>
                                            <button type="button"
                                                class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                                title="Clear selection">&#215;</button>
                                        </div>
                                        <button type="button" class="remove-ipv4" onclick="removeIpRow(this, 'ipv4')">Remove</button>
                                    </div>
                                </template>
                            </div>
                            <div id="ipv6-block" class="im-margin-top">
                                <label>IPv6 addresses</label>
                                <?php
                                $ipv6_selected = $tdata['page_data']['ipv6_selected'] ?? [];
                                foreach ($ipv6_selected as $sel_id):
                                    $sel_name = '';
                                    foreach ($ipv6_resolved as $opt) {
                                        if (($opt['id'] ?? '') === $sel_id) {
                                            $sel_name = $opt['name'] ?? ($opt['id'] ?? '');
                                            break;
                                        }
                                    }
                                    $has_val = !empty($sel_id);
                                ?>
                                <div class="ipv6-row">
                                    <div class="set-picker-field" data-js="set-picker-field"
                                        data-set-type="address" data-filter-family="ip6" data-filter-scope="host_prefix" data-max-select="1">
                                        <input type="hidden" name="ipv6[]" value="<?= $has_val ? $sel_id : '' ?>">
                                        <button type="button"
                                            class="std-btn-picker set-picker-trigger js-set-picker-open<?= $has_val ? ' set-picker-trigger--has-value' : '' ?>"
                                            data-placeholder="Select IPv6 address">
                                            <span class="js-set-picker-label"><?= $has_val ? $sel_name : 'Select IPv6 address' ?></span>
                                        </button>
                                        <button type="button"
                                            class="std-btn-picker set-picker-clear js-set-picker-clear<?= $has_val ? '' : ' sets-hidden' ?>"
                                            title="Clear selection">&#215;</button>
                                    </div>
                                    <button type="button" class="remove-ipv6" onclick="removeIpRow(this, 'ipv6')">Remove</button>
                                </div>
                                <?php endforeach; ?>
                                <button type="button" onclick="addIpRow('ipv6')">Add IPv6</button>
                                <template id="ipv6-picker-template">
                                    <div class="ipv6-row">
                                        <div class="set-picker-field" data-js="set-picker-field"
                                            data-set-type="address" data-filter-family="ip6" data-filter-scope="host_prefix" data-max-select="1">
                                            <input type="hidden" name="ipv6[]" value="">
                                            <button type="button"
                                                class="std-btn-picker set-picker-trigger js-set-picker-open"
                                                data-placeholder="Select IPv6 address">
                                                <span class="js-set-picker-label">Select IPv6 address</span>
                                            </button>
                                            <button type="button"
                                                class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                                title="Clear selection">&#215;</button>
                                        </div>
                                        <button type="button" class="remove-ipv6" onclick="removeIpRow(this, 'ipv6')">Remove</button>
                                    </div>
                                </template>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if ($iface_subtype === 'vlan'): ?>
                        <div class="form-inline-row">
                            <label>
                                Parent interface
                                <select name="parent_iface" id="parent_iface_select" required <?= !$has_interface_list ? 'disabled' : '' ?>>
                                    <option value="">Select parent...</option>
                                    <?php if ($has_interface_list): ?>
                                        <?= $interface_options_html ?>
                                    <?php else: ?>
                                        <option value="" disabled><?= $no_interfaces_msg ?></option>
                                    <?php endif; ?>
                                </select>
                            </label>
                            <label>VLAN</label>
                            <?php $vlan_label = $tdata['page_data']['vlan_label'] ?? null; ?>
                            <div class="set-picker-field" data-js="label-picker-field" data-set-type="vlans"
                                 data-max-select="1" data-label-title="Select VLAN">
                                <input type="hidden" name="vlan_id" id="vlan_id_input"
                                    value="<?= $vlan_label['id'] ?? $vlan_id ?? '' ?>"
                                    data-value="<?= $vlan_label['value'] ?? $vlan_id ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $vlan_label ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="Select VLAN">
                                    <span class="js-set-picker-label"><?= $vlan_label ? ($vlan_label['name'] ?? '') : 'Select VLAN' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $vlan_label ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                        </div>
                    <?php elseif ($iface_subtype === 'macvlan'): ?>
                        <label>
                            Parent interface
                            <select name="parent_iface" id="parent_iface_select" required <?= !$has_interface_list ? 'disabled' : '' ?>>
                                <option value="">Select parent...</option>
                                <?php if ($has_interface_list): ?>
                                    <?= $interface_options_html ?>
                                <?php else: ?>
                                    <option value="" disabled><?= $no_interfaces_msg ?></option>
                                <?php endif; ?>
                            </select>
                        </label>
                        <label>
                            MacVLAN mode
                            <select name="macvlan_mode" id="macvlan_mode_select" class="std-select">
                                <option value="">Select mode...</option>
                                <option value="bridge" <?= $tdata['page_data']['macvlan_mode'] === 'bridge' ? 'selected' : '' ?>>bridge</option>
                                <option value="private" <?= $tdata['page_data']['macvlan_mode'] === 'private' ? 'selected' : '' ?>>private</option>
                                <option value="vepa" <?= $tdata['page_data']['macvlan_mode'] === 'vepa' ? 'selected' : '' ?>>vepa</option>
                                <option value="passthru" <?= $tdata['page_data']['macvlan_mode'] === 'passthru' ? 'selected' : '' ?>>passthru</option>
                                <option value="source" <?= $tdata['page_data']['macvlan_mode'] === 'source' ? 'selected' : '' ?>>source</option>
                            </select>
                        </label>
                    <?php elseif ($iface_subtype === 'vti'): ?>
                        <div class="form-inline-row">
                        <?php $vtiLocal = $tdata['page_data']['vti_local_display']; ?>
                            <div class="set-picker-field" data-js="set-picker-field"
                                data-set-type="address" data-filter-scope="host" data-max-select="1">
                                <input type="hidden" name="local" value="<?= $vtiLocal['id'] ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $vtiLocal ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="Local">
                                    <span class="js-set-picker-label"><?= $vtiLocal ? ($vtiLocal['name'] ?? $vtiLocal['id']) : 'Local' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $vtiLocal ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                        <?php $vtiRemote = $tdata['page_data']['vti_remote_display']; ?>
                            <div class="set-picker-field" data-js="set-picker-field"
                                data-set-type="address" data-filter-scope="host" data-max-select="1">
                                <input type="hidden" name="remote" value="<?= $vtiRemote['id'] ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $vtiRemote ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="Remote">
                                    <span class="js-set-picker-label"><?= $vtiRemote ? ($vtiRemote['name'] ?? $vtiRemote['id']) : 'Remote' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $vtiRemote ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                        <?php $vtiKey = $tdata['page_data']['vti_key_display']; ?>
                            <div class="set-picker-field" data-js="label-picker-field" data-set-type="packet_marking"
                                 data-filter-scope="mark" data-max-select="1" data-label-title="Select marking key">
                                <input type="hidden" name="key"
                                    value="<?= $vtiKey['id'] ?? '' ?>"
                                    data-value="<?= $vtiKey['value'] ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $vtiKey ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="Key">
                                    <span class="js-set-picker-label"><?= $vtiKey ? ($vtiKey['name'] ?? '') : 'Key' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $vtiKey ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                        </div>
                    <?php elseif ($iface_subtype === 'gre'): ?>
                        <div class="form-inline-row">
                        <?php $greLocal = $tdata['page_data']['gre_local_display']; ?>
                            <div class="set-picker-field" data-js="set-picker-field"
                                data-set-type="address" data-filter-scope="host" data-max-select="1">
                                <input type="hidden" name="local" value="<?= $greLocal['id'] ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $greLocal ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="Local">
                                    <span class="js-set-picker-label"><?= $greLocal ? ($greLocal['name'] ?? $greLocal['id']) : 'Local' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $greLocal ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                        <?php $greRemote = $tdata['page_data']['gre_remote_display']; ?>
                            <div class="set-picker-field" data-js="set-picker-field"
                                data-set-type="address" data-filter-scope="host" data-max-select="1">
                                <input type="hidden" name="remote" value="<?= $greRemote['id'] ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $greRemote ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="Remote">
                                    <span class="js-set-picker-label"><?= $greRemote ? ($greRemote['name'] ?? $greRemote['id']) : 'Remote' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $greRemote ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                        <?php $greIkey = $tdata['page_data']['gre_ikey_display']; ?>
                            <div class="set-picker-field" data-js="label-picker-field" data-set-type="gre_ikey"
                                 data-max-select="1" data-label-title="Select IKey">
                                <input type="hidden" name="ikey"
                                    value="<?= $greIkey['id'] ?? '' ?>"
                                    data-value="<?= $greIkey['value'] ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $greIkey ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="IKey">
                                    <span class="js-set-picker-label"><?= $greIkey ? ($greIkey['name'] ?? '') : 'IKey' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $greIkey ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                        <?php $greOkey = $tdata['page_data']['gre_okey_display']; ?>
                            <div class="set-picker-field" data-js="label-picker-field" data-set-type="gre_okey"
                                 data-max-select="1" data-label-title="Select OKey">
                                <input type="hidden" name="okey"
                                    value="<?= $greOkey['id'] ?? '' ?>"
                                    data-value="<?= $greOkey['value'] ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $greOkey ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="OKey">
                                    <span class="js-set-picker-label"><?= $greOkey ? ($greOkey['name'] ?? '') : 'OKey' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $greOkey ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                            <label>
                                TTL
                                <input type="number" name="gre_ttl" value="<?= $iface_config['gre_ttl'] ?? $iface_config['ttl'] ?? '' ?>"
                                    min="0" max="255" placeholder="inherit" class="std-grid-input">
                            </label>
                        </div>
                    <?php elseif ($iface_subtype === 'vxlan'): ?>
                        <div class="form-inline-row">
                        <?php $vxlanVni = $tdata['page_data']['vxlan_vni_display']; ?>
                            <div class="set-picker-field" data-js="label-picker-field" data-set-type="vni"
                                 data-max-select="1" data-label-title="Select VNI">
                                <input type="hidden" name="vni"
                                    value="<?= $vxlanVni['id'] ?? '' ?>"
                                    data-value="<?= $vxlanVni['value'] ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $vxlanVni ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="VNI">
                                    <span class="js-set-picker-label"><?= $vxlanVni ? ($vxlanVni['name'] ?? '') : 'VNI' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $vxlanVni ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                        <?php $vxlanLocalIp = $tdata['page_data']['vxlan_local_ip_display']; ?>
                            <div class="set-picker-field" data-js="set-picker-field"
                                data-set-type="address" data-filter-scope="host" data-max-select="1">
                                <input type="hidden" name="local_ip" value="<?= $vxlanLocalIp['id'] ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $vxlanLocalIp ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="VTEP">
                                    <span class="js-set-picker-label"><?= $vxlanLocalIp ? ($vxlanLocalIp['name'] ?? $vxlanLocalIp['id']) : 'VTEP' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $vxlanLocalIp ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                        <?php $vxlanDstport = $tdata['page_data']['vxlan_dstport_display']; ?>
                            <div class="set-picker-field" data-js="set-picker-field"
                                data-set-type="address" data-filter-scope="host" data-max-select="1">
                                <input type="hidden" name="dstport" value="<?= $vxlanDstport['id'] ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $vxlanDstport ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="Dst port">
                                    <span class="js-set-picker-label"><?= $vxlanDstport ? ($vxlanDstport['name'] ?? $vxlanDstport['id']) : 'Dst port' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $vxlanDstport ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                        </div>
                        <div class="im-inline-group">
                            <label>
                                <input type="checkbox" name="nolearning" value="1"
                                    <?= ($iface_config['nolearning'] ?? true) ? 'checked' : '' ?>>
                                No learning
                            </label>
                            <label>
                                <input type="checkbox" name="external" value="1"
                                    <?= !empty($iface_config['external']) ? 'checked' : '' ?>>
                                External
                            </label>
                            <label>
                                <input type="checkbox" name="vnifilter" value="1"
                                    <?= !empty($iface_config['vnifilter']) ? 'checked' : '' ?>>
                                VNI filter
                            </label>
                        </div>
                    <?php elseif ($iface_subtype === 'xfrm'): ?>
                        <label>
                            Parent interface
                            <select name="parent_iface" id="parent_iface_select" required <?= !$has_interface_list ? 'disabled' : '' ?>>
                                <option value="">Select parent...</option>
                                <?php if ($has_interface_list): ?>
                                    <?= $interface_options_html ?>
                                <?php else: ?>
                                    <option value="" disabled><?= $no_interfaces_msg ?></option>
                                <?php endif; ?>
                            </select>
                        </label>
                        <div class="form-inline-row">
                        <?php $xfrmIfId = $tdata['page_data']['xfrm_if_id_display']; ?>
                            <div class="set-picker-field" data-js="label-picker-field" data-set-type="xfrm_if_id"
                                 data-max-select="1" data-label-title="Select XFRM Interface ID">
                                <input type="hidden" name="if_id"
                                    value="<?= $xfrmIfId['id'] ?? '' ?>"
                                    data-value="<?= $xfrmIfId['value'] ?? '' ?>">
                                <button type="button"
                                    class="std-btn-picker set-picker-trigger js-set-picker-open<?= $xfrmIfId ? ' set-picker-trigger--has-value' : '' ?>"
                                    data-placeholder="XFRM if_id (optional)">
                                    <span class="js-set-picker-label"><?= $xfrmIfId ? ($xfrmIfId['name'] ?? '') : 'XFRM if_id (optional)' ?></span>
                                </button>
                                <button type="button"
                                    class="std-btn-picker set-picker-clear js-set-picker-clear<?= $xfrmIfId ? '' : ' sets-hidden' ?>"
                                    title="Clear selection">&#215;</button>
                            </div>
                        </div>
                    <?php else: ?>
                        <!-- Interface name moved to inline row above -->
                    <?php endif; ?>
                    <?= $tdata['virtual_section'] ?? '' ?>

                    <!-- Interface services configuration -->
                    <div class="im-config-group im-margin-top">
                        <h3>Interface Services</h3>
                        <div class="im-inline-group">
                            <label>
                                <input type="checkbox" name="listen_ssh" value="1" <?= $listen_ssh_checked ?> >
                                SSH
                            </label>
                            <label>
                                <input type="checkbox" name="listen_styx_ui" value="1" <?= $listen_styx_ui_checked ?> >
                                Styx UI
                            </label>
                        </div>
                    </div>

                    <!-- IP mode moved earlier in the form -->
                    <?php if ($iface_subtype === 'pppoe'): ?>
                        <label>
                            Parent interface
                            <select name="parent_iface" required <?= !$has_interface_list ? 'disabled' : '' ?>>
                                <option value="">Select interface...</option>
                                <?php if ($has_interface_list): ?>
                                    <?= $interface_options_html ?>
                                <?php else: ?>
                                    <option value="" disabled><?= $no_interfaces_msg ?></option>
                                <?php endif; ?>
                            </select>
                        </label>
                        <label>
                            PPPoE user
                                <input type="text" name="pppoe[username]" value="<?= $tdata['page_data']['pppoe']['username'] ?? '' ?>"
                                id="pppoe_user_input">
                        </label>
                        <label>
                            PPPoE service (optional)
                                <input type="text" name="pppoe[service]" value="<?= $tdata['page_data']['pppoe']['service'] ?? '' ?>"
                                id="pppoe_service_input">
                        </label>
                        <label>
                            PPPoE password
                                <input type="password" name="pppoe[password]" value="<?= $tdata['page_data']['pppoe']['password'] ?? '' ?>"
                                id="pppoe_pass_input">
                        </label>
                    <?php elseif ($iface_subtype === 'bridge'): ?>
                        <label>
                            Bridge ports
                            <select name="ports[]" multiple required class="im-multi-select">
                                <?php if (!empty($bridge_ports_options)): ?>
                                    <?= $bridge_ports_options_html ?>
                                <?php else: ?>
                                    <option disabled><?= $no_interfaces_msg ?></option>
                                <?php endif; ?>
                            </select>
                        </label>

                        <label>
                            VLAN filtering
                            <input id="vlan_filtering_checkbox" type="checkbox" name="vlan_filtering" value="1" <?= !empty($tdata['page_data']['iface_config']['vlan_filtering']) ? 'checked' : '' ?>>
                        </label>

                        <!-- MTU and MAC are exposed in Advanced Options; not duplicated here -->

                        <div id="bridge-vlans-section" class="im-margin-top" style="<?= !empty($tdata['page_data']['iface_config']['vlan_filtering']) ? '' : 'display:none' ?>">
                            <?php if ($action !== 'modify'): ?>
                                <p class="im-note">VLAN filtering is enabled - VLANs 2-4094 will be applied to the bridge
                                and all ports by default. Edit the bridge after creation to specify individual VLANs.</p>
                            <?php else: ?>
                                <?php
                                $existing_bv = $tdata['page_data']['iface_config']['bridge_vlans'] ?? [];
                                if (!is_array($existing_bv)) $existing_bv = [];
                                $bv_self  = array_filter($existing_bv, fn($bv) => empty($bv['port']));
                                $bv_ports = array_filter($existing_bv, fn($bv) => !empty($bv['port']));
                                ?>
                                <!-- Bridge-self VLANs (no port) -->
                                <div class="vlan-section">
                                <h4>Bridge VLANs</h4>
                                <p class="im-note">VLANs that apply to the bridge and all its ports.</p>
                                <div id="bridge-vlans-self-container">
                                    <?php foreach ($bv_self as $bv):
                                        $bv_vlan = $bv['vlan_id'] ?? '';
                                        $bv_vlan_display = $bv['vlan_id_display'] ?? null;
                                        $bv_vlan_name = is_array($bv_vlan_display) ? ($bv_vlan_display['name'] ?? $bv_vlan) : $bv_vlan;
                                    ?>
                                    <div class="bridge-vlan-row bridge-vlan-self">
                                        <div class="set-picker-field" data-js="label-picker-field" data-set-type="vlans" data-max-select="1" data-label-title="Select VLAN">
                                            <input type="hidden" class="bv-vlan-id"
                                                value="<?= $bv_vlan ?>"
                                                data-value="<?= is_array($bv_vlan_display) ? ($bv_vlan_display['value'] ?? '') : '' ?>">
                                            <button type="button"
                                                class="std-btn-picker set-picker-trigger js-set-picker-open<?= $bv_vlan ? ' set-picker-trigger--has-value' : '' ?>"
                                                data-placeholder="Select VLAN">
                                                <span class="js-set-picker-label"><?= $bv_vlan ? $bv_vlan_name : 'Select VLAN' ?></span>
                                            </button>
                                            <button type="button"
                                                class="std-btn-picker set-picker-clear js-set-picker-clear<?= $bv_vlan ? '' : ' sets-hidden' ?>"
                                                title="Clear selection">&#215;</button>
                                        </div>
                                        <button type="button" class="remove-bridge-vlan" onclick="removeBridgeVlanRow(this)">Remove</button>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <button type="button" onclick="addBridgeSelfVlanRow()">Add VLAN to Bridge</button>
                                </div><!-- .vlan-section -->

                                <!-- Per-port VLANs -->
                                <div class="vlan-section">
                                <h4>Per-port VLANs</h4>
                                <p class="im-note">VLANs assigned to a specific bridge port with optional PVID / untagged.</p>
                                <div id="bridge-vlans-port-container">
                                    <?php foreach ($bv_ports as $bv):
                                        $bv_vlan = $bv['vlan_id'] ?? '';
                                        $bv_vlan_display = $bv['vlan_id_display'] ?? null;
                                        $bv_vlan_name = is_array($bv_vlan_display) ? ($bv_vlan_display['name'] ?? $bv_vlan) : $bv_vlan;
                                        $bv_pvid = !empty($bv['pvid']) ? 'checked' : '';
                                        $bv_untag = !empty($bv['untagged']) ? 'checked' : '';
                                        $bv_port = $bv['port'] ?? '';
                                    ?>
                                    <div class="bridge-vlan-row bridge-vlan-port">
                                        <select class="bv-port std-select">
                                            <option value="">Port...</option>
                                            <?php foreach ($bridge_own_ports_options as $opt):
                                                $sel = ($opt['value'] === $bv_port) ? 'selected' : '';
                                                echo '<option value="' . $opt['value'] . '" ' . $sel . '>' . $opt['label'] . '</option>';
                                            endforeach; ?>
                                        </select>
                                        <div class="set-picker-field" data-js="label-picker-field" data-set-type="vlans" data-max-select="1" data-label-title="Select VLAN">
                                            <input type="hidden" class="bv-vlan-id"
                                                value="<?= $bv_vlan ?>"
                                                data-value="<?= is_array($bv_vlan_display) ? ($bv_vlan_display['value'] ?? '') : '' ?>">
                                            <button type="button"
                                                class="std-btn-picker set-picker-trigger js-set-picker-open<?= $bv_vlan ? ' set-picker-trigger--has-value' : '' ?>"
                                                data-placeholder="Select VLAN">
                                                <span class="js-set-picker-label"><?= $bv_vlan ? $bv_vlan_name : 'Select VLAN' ?></span>
                                            </button>
                                            <button type="button"
                                                class="std-btn-picker set-picker-clear js-set-picker-clear<?= $bv_vlan ? '' : ' sets-hidden' ?>"
                                                title="Clear selection">&#215;</button>
                                        </div>
                                        <label><input type="checkbox" class="bv-pvid" <?= $bv_pvid ?>> PVID</label>
                                        <label><input type="checkbox" class="bv-untagged" <?= $bv_untag ?>> Untagged</label>
                                        <button type="button" class="remove-bridge-vlan" onclick="removeBridgeVlanRow(this)">Remove</button>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <button type="button" onclick="addBridgePortVlanRow()">Add VLAN to Port</button>
                                </div><!-- .vlan-section -->

                                <!-- Templates for cloning -->
                                <div id="bridge-vlan-self-template">
                                    <div class="bridge-vlan-row bridge-vlan-self">
                                        <div class="set-picker-field" data-js="label-picker-field" data-set-type="vlans" data-max-select="1" data-label-title="Select VLAN">
                                            <input type="hidden" class="bv-vlan-id" value="" data-value="">
                                            <button type="button"
                                                class="std-btn-picker set-picker-trigger js-set-picker-open"
                                                data-placeholder="Select VLAN">
                                                <span class="js-set-picker-label">Select VLAN</span>
                                            </button>
                                            <button type="button"
                                                class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                                title="Clear selection">&#215;</button>
                                        </div>
                                        <button type="button" class="remove-bridge-vlan" onclick="removeBridgeVlanRow(this)">Remove</button>
                                    </div>
                                </div>
                                <div id="bridge-vlan-port-template">
                                    <div class="bridge-vlan-row bridge-vlan-port">
                                        <select class="bv-port std-select">
                                            <option value="">Port...</option>
                                            <?= $bridge_own_ports_options_html ?>
                                        </select>
                                        <div class="set-picker-field" data-js="label-picker-field" data-set-type="vlans" data-max-select="1" data-label-title="Select VLAN">
                                            <input type="hidden" class="bv-vlan-id" value="" data-value="">
                                            <button type="button"
                                                class="std-btn-picker set-picker-trigger js-set-picker-open"
                                                data-placeholder="Select VLAN">
                                                <span class="js-set-picker-label">Select VLAN</span>
                                            </button>
                                            <button type="button"
                                                class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                                title="Clear selection">&#215;</button>
                                        </div>
                                        <label><input type="checkbox" class="bv-pvid"> PVID</label>
                                        <label><input type="checkbox" class="bv-untagged"> Untagged</label>
                                        <button type="button" class="remove-bridge-vlan" onclick="removeBridgeVlanRow(this)">Remove</button>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- refs are internal-only; not exposed in UI -->
                    <?php elseif ($iface_subtype === 'bond'): ?>
                        <label>
                            Bond slaves
                            <select name="slaves[]" multiple required class="im-multi-select">
                                <?php if (!empty($bond_slaves_options)): ?>
                                    <?= $bond_slaves_options_html ?>
                                <?php else: ?>
                                    <option disabled><?= $no_interfaces_msg ?></option>
                                <?php endif; ?>
                            </select>
                        </label>
                        <label>
                            Bonding mode
                            <select name="mode" class="std-select" required>
                                <option value="">Select mode...</option>
                                <option value="balance-rr"
                                    <?= $bond_mode === 'balance-rr' ? 'selected' : '' ?>>balance-rr</option>
                                <option value="active-backup"
                                    <?= $bond_mode === 'active-backup' ? 'selected' : '' ?>>active-backup</option>
                                <option value="balance-xor"
                                    <?= $bond_mode === 'balance-xor' ? 'selected' : '' ?>>balance-xor</option>
                                <option value="broadcast"
                                    <?= $bond_mode === 'broadcast' ? 'selected' : '' ?>>broadcast</option>
                                <option value="802.3ad"
                                    <?= $bond_mode === '802.3ad' ? 'selected' : '' ?>>802.3ad</option>
                                <option value="balance-tlb"
                                    <?= $bond_mode === 'balance-tlb' ? 'selected' : '' ?>>balance-tlb</option>
                                <option value="balance-alb"
                                    <?= $bond_mode === 'balance-alb' ? 'selected' : '' ?>>balance-alb</option>
                            </select>
                        </label>
                    <?php elseif ($iface_subtype === 'wifi'): ?>
                        <label>
                            SSID
                            <input type="text" name="wifi_ssid" value="<?= $wifi_ssid ?>" required>
                        </label>
                        <label>
                            Password
                            <input type="password" name="wifi_pass" value="<?= $wifi_pass ?>">
                        </label>
                    <?php endif; ?>
                    <?= $tdata['advanced_section'] ?? '' ?>
                    <button type="submit">
                        <?= $action === 'create' ? 'Create interface' : 'Save changes' ?>
                    </button>
                </form>
            </div>

            <div class="im-right-column">
                <?= $tdata['right_column'] ?? '' ?>
            </div>
        </div>
    </main>
</div>
