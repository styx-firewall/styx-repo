
<?php

/**
 * User Roles management template.
 *
 * @var array<mixed> $tdata
 */
$roles = $tdata['page_data']['user_rows'] ?? [];
$validRoles = $tdata['page_data']['valid_roles'] ?? [];
$canManage = $tdata['page_data']['can_manage'] ?? false;
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>User Roles</h1>
        <?php if (!empty($tdata['page_data']['error'])): ?>
        <div class="alert alert-error"><?= $tdata['page_data']['error'] ?></div>
        <?php endif; ?>
        <div class="content-box">
            <table class="std-table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Role</th>
                        <?php if ($canManage): ?>
                        <th>Actions</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($roles as $entry): ?>
                    <?php $immutable = !empty($entry['immutable']); ?>
                    <tr>
                        <td>
                            <?= $entry['username'] ?? '' ?>
                            <?php if ($immutable): ?>
                            <em>(system)</em>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($canManage && !$immutable): ?>
                            <select data-js="role-select"
                                    data-username="<?= $entry['username'] ?? '' ?>">
                                <option value="">-- No role --</option>
                                <?php foreach ($validRoles as $r): ?>
                                <option value="<?= $r ?>"
                                    <?= ($entry['role'] ?? '') === $r ? 'selected' : '' ?>>
                                    <?= ucfirst($r) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <?php else: ?>
                            <span><?= ucfirst($entry['role'] ?? 'None') ?></span>
                            <?php endif; ?>
                        </td>
                        <?php if ($canManage && !$immutable): ?>
                        <td>
                            <button data-js="save-role"
                                    data-username="<?= $entry['username'] ?? '' ?>"
                                    class="std-btn">Save</button>
                            <?php if (!empty($entry['role'])): ?>
                            <button data-js="remove-role"
                                    data-username="<?= $entry['username'] ?? '' ?>"
                                    class="std-btn btn-danger">Remove</button>
                            <?php endif; ?>
                        </td>
                        <?php elseif ($canManage): ?>
                        <td></td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
