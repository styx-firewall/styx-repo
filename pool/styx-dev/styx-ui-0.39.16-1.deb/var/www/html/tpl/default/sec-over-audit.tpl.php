<?php
/**
 * Reusable fragment: Security Overview / Audit card set.
 * To be rendered via TemplateService->load_tpl or included directly.
 * @var array<mixed> $tdata
 */


//var_dump($tdata['tpl_data']);
$audit_overview = $tdata['tpl_data']['audit'] ?? null;
//var_dump($audit_overview);
//$audit = $tdata['tpl_data']['audit'] ?? null;
?>

<?php if ($audit_overview): ?>
<section class="sec-grid">
    <div class="card summary-card">
        <div class="card-header">
            <h2 class="card-heading">Audit Summary</h2>
        </div>
        <div class="donut-wrap">
            <svg viewBox="0 0 36 36" class="donut" aria-hidden="true">
                <path class="donut-bg" d="M18 2.0845
                    a 15.9155 15.9155 0 0 1 0 31.831
                    a 15.9155 15.9155 0 0 1 0 -31.831"/>
                <?php
                    $cov = (float)($audit_overview['coverage_pct'] ?? 0);
                    $cov = max(0, min(100, $cov));
                    if ($cov < 50) {
                        $cov_color = '#ef4444';
                    } elseif ($cov < 75) {
                        $cov_color = '#f97316';
                    } elseif ($cov < 90) {
                        $cov_color = '#f59e0b';
                    } else {
                        $cov_color = '#10b981';
                    }
                ?>
                <path class="donut-fg" stroke="<?php echo $cov_color ?>" stroke-dasharray="<?php echo $cov ?>,100" d="M18 2.0845
                    a 15.9155 15.9155 0 0 1 0 31.831
                    a 15.9155 15.9155 0 0 1 0 -31.831"/>
                <text x="18" y="20" class="donut-text"><?php echo $cov ?>%</text>
            </svg>
        </div>
        <div class="rating">Rating: <strong><?php echo $audit_overview['rating'] ?? 'N/A' ?></strong></div>
        <div class="msg small muted"><?php echo $audit_overview['msg'] ?? '' ?></div>
    </div>

    <div class="card stats-card">
        <div class="card-header">
            <h2 class="card-heading">Checks & Score</h2>
        </div>
        <div class="stat-row">
            <div class="stat-label">Total checks</div>
            <div class="stat-number"><?php echo (int)($audit_overview['total_checks'] ?? 0) ?></div>
        </div>
        <div class="stat-row">
            <div class="stat-label">Passed</div>
            <div class="progress-wrap">
                <div class="progress-bar passed" style="width:<?php echo (float)($audit_overview['pass_pct'] ?? 0) ?>%"></div>
            </div>
            <div class="stat-number small"><?php echo (int)($audit_overview['passed'] ?? 0) ?> <span class="muted">(<?php echo (float)($audit_overview['pass_pct'] ?? 0) ?>%)</span></div>
        </div>
        <div class="stat-row">
            <div class="stat-label">Failed</div>
            <div class="progress-wrap">
                <div class="progress-bar failed" style="width:<?php echo (float)($audit_overview['fail_pct'] ?? 0) ?>%"></div>
            </div>
            <div class="stat-number small"><?php echo (int)($audit_overview['failed'] ?? 0) ?> <span class="muted">(<?php echo (float)($audit_overview['fail_pct'] ?? 0) ?>%)</span></div>
        </div>
        <div class="stat-row">
            <div class="stat-label">Score</div>
            <div class="progress-wrap">
                <div class="progress-bar score" style="width:<?php echo (float)($audit_overview['score_pct'] ?? 0) ?>%;background:<?php echo $cov_color ?>"></div>
            </div>
            <div class="stat-number small"><?php echo (int)($audit_overview['achieved_score'] ?? 0) ?> / <?php echo (int)($audit_overview['max_score'] ?? 0) ?> <span class="muted">(<?php echo (float)($audit_overview['score_pct'] ?? 0) ?>%)</span></div>
        </div>
    </div>

    <?php if (!empty($audit_overview['coverage_by_tag'])): ?>
    <div class="card">
        <div class="card-header">
            <h2 class="card-heading">Coverage by Benchmark</h2>
        </div>
        <?php foreach ($audit_overview['coverage_by_tag'] as $tag => $pct): ?>
        <?php
            $pct = max(0, min(100, (float)$pct));
            if ($pct < 50) {
                $bar_color = '#ef4444';
            } elseif ($pct < 75) {
                $bar_color = '#f97316';
            } elseif ($pct < 90) {
                $bar_color = '#f59e0b';
            } else {
                $bar_color = '#10b981';
            }
        ?>
        <div class="stat-row">
            <div class="stat-label"><?= $tag ?></div>
            <div class="progress-wrap">
                <div class="progress-bar" style="width:<?= $pct ?>%;background:<?= $bar_color ?>"></div>
            </div>
            <div class="stat-number small"><?= $pct ?>%</div>
        </div>
        <?php endforeach ?>
    </div>
    <?php endif ?>
</section>

<?php else: ?>
    <div class="empty">No audit data available.</div>
<?php endif; ?>
