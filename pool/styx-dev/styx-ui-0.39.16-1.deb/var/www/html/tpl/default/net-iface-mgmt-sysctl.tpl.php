<?php
/**
 * Fragment: Interface Sysctl section for net-iface-mgmt
 * Rendered by TemplateService->getTpl() with $tdata containing tpl_data.sysctl_keys
 */

$sysctl_keys = $tdata['tpl_data']['sysctl_keys'] ?? [];

if (!empty($sysctl_keys) && is_array($sysctl_keys)): ?>
<div id="sysctl-collapse-box" class="std-collapse-box im-margin-top0">
    <div class="std-collapse-header" onclick="this.parentNode.classList.toggle('open')">
        Interface Sysctl
    </div>
    <div class="std-collapse-content">
        <form id="iface-sysctl-form" data-js="iface-sysctl-form" method="post" autocomplete="off">
            <div class="iface-sysctl-grid im-sysctl-grid">
            <?php foreach ($sysctl_keys as $item):
                $hl_class = !empty($item['differs']) ? ' im-sysctl-differs' : '';
                $disabled = $item['disabled'] ? 'disabled' : '';
                $type = $item['type'];
            ?>
                <div class="iface-sysctl-item im-sysctl-item<?= $hl_class ?>">
                    <div class="im-sysctl-key"><?= $item['sysctl_key'] ?></div>
                    <input type="hidden" name="sysctl_keys[]" value="<?= $item['sysctl_key'] ?>">
                    <?php if ($item['comment'] !== ''): ?>
                    <div class="im-sysctl-keyrow"><span class="im-sysctl-keytext"><?= $item['comment'] ?></span></div>
                    <?php endif; ?>
                    <label for="value-<?= $item['key'] ?>" class="im-sysctl-label">Value:</label>
                    <?php if ($type === 'number' || $type === 'int'): ?>
                    <input type="number" name="value[]" id="value-<?= $item['key'] ?>"
                        value="<?= $item['value'] ?>"
                        data-original="<?= $item['value'] ?>"
                        data-sysctl-key="<?= $item['sysctl_key'] ?>"
                        class="im-sysctl-input js-sysctl-value std-grid-input"
                        autocomplete="off" <?= $disabled ?>>
                    <?php elseif ($type === 'checkbox' || $type === 'bool' || $type === 'boolean'):
                        $checked = ($item['value'] == '1' || $item['value'] === true) ? 'checked' : ''; ?>
                    <label class="std-switch">
                        <input type="checkbox" name="value[]" id="value-<?= $item['key'] ?>"
                            value="1"
                            data-original="<?= $checked ? '1' : '0' ?>"
                            data-sysctl-key="<?= $item['sysctl_key'] ?>"
                            class="js-sysctl-value std-grid-input"
                            <?= $checked ?> <?= $disabled ?>>
                        <span class="std-switch-slider" data-off="No" data-on="Yes"></span>
                    </label>
                    <?php else: ?>
                    <input type="text" name="value[]" id="value-<?= $item['key'] ?>"
                        value="<?= $item['value'] ?>"
                        data-original="<?= $item['value'] ?>"
                        data-sysctl-key="<?= $item['sysctl_key'] ?>"
                        class="im-sysctl-input js-sysctl-value std-grid-input"
                        autocomplete="off" <?= $disabled ?>>
                    <?php endif; ?>
                    <div class="im-sysctl-default">Default: <span id="default-<?= $item['key'] ?>"><?= $item['default'] ?></span></div>
                </div>
            <?php endforeach; ?>
            </div>
            <button type="submit" id="iface-sysctl-submit">
                Save changes
            </button>
        </form>
    </div>
</div>
<?php endif;
