<?php
/**
 * Formatter for system logs page.
 * Prepares level select options for the template.
 */
namespace App\Pages\Fmt;

class SysLogsFormatter
{
    /**
     * Build `levels_options` from `levels` and optional selected level.
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $levels = $fmt_data['levels'] ?? [];
        $selected = $fmt_data['selected_level'] ?? 'DEBUG';

        $opts = [];
        foreach ($levels as $lvl) {
            $opts[] = [
                'value' => $lvl,
                'label' => $lvl,
                'selected' => ($lvl === $selected)
            ];
        }

        $fmt_data['levels_options'] = $opts;
        return $fmt_data;
    }
}
