<?php
/**
 * Formatter for system settings page.
 * Moves small presentation helpers out of the template.
 */
namespace App\Pages\Fmt;

class SysSettingsFormatter
{
    /**
     * Prepare display strings and ensure keys exist for the template.
     *
     * @param array<string,mixed> $fmt_data
     * @param bool $isAdmin
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data, bool $isAdmin = false): array
    {
        $settings = $fmt_data ?? [];
        $sys = $settings['system_info'] ?? [];
        $ssh = $settings['ssh'] ?? [];
        $dns = $settings['dns'] ?? [];

        $ssh_enabled_text = (!empty($ssh['enabled']))
            ? 'Enabled, port ' . ($ssh['port'] ?? '22')
            : 'Disabled';

        $ssh_listen_text = '';
        if (!empty($ssh['listen_addresses']) && is_array($ssh['listen_addresses'])) {
            $ssh_listen_text = implode(', ', $ssh['listen_addresses']);
        }

        // DNS
        $desired = $dns['desired_config'] ?? [];
        $dnsServers = $desired['dns_servers'] ?? null;
        $dnsSearch = $desired['dns_search'] ?? [];
        $isConfigured = is_array($dnsServers);
        $dnsServersStr = is_array($dnsServers) ? implode(', ', $dnsServers) : '';
        $dnsSearchStr = is_array($dnsSearch) ? implode(', ', $dnsSearch) : '';
        $resolvConf = $dns['resolv_conf'] ?? '';
        $resolvLines = !empty($resolvConf) ? explode("\n", trim($resolvConf)) : [];
        $activeSources = $dns['active_sources'] ?? [];

        $fmt_data['system_info'] = $sys;
        $fmt_data['ssh'] = $ssh;
        $fmt_data['ssh_enabled_text'] = $ssh_enabled_text;
        $fmt_data['ssh_listen_text'] = $ssh_listen_text;
        $fmt_data['dns_servers_str'] = $dnsServersStr;
        $fmt_data['dns_servers'] = $dnsServers;
        $fmt_data['dns_search_str'] = $dnsSearchStr;
        $fmt_data['dns_search'] = $dnsSearch;
        $fmt_data['dns_is_configured'] = $isConfigured;
        $fmt_data['resolv_lines'] = $resolvLines;
        $fmt_data['active_sources'] = $activeSources;
        $fmt_data['is_admin'] = $isAdmin;

        return $fmt_data;
    }
}
