<?php
/**
 * Formatter for users page.
 * Prepares rows for regular and system users for template consumption.
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class UsersFormatter
{
    /**
     * Normalize users arrays into presentation-ready rows.
     *
     * @param array<string,mixed> $fmt_data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data, array $userCaps = []): array
    {
        $isAdmin = RoleHelper::hasCapability($userCaps, 'users:admin');
        $fmt_data['can_add'] = $isAdmin;

        $users = $fmt_data['users']['users'] ?? [];

        $regular = [];
        $system = [];

        if (is_array($users)) {
            foreach ($users as $user) {
                if (isset($user['uid']) && $user['uid'] < 1000) {
                    $system[] = $user;
                } elseif (isset($user['uid']) && $user['uid'] >= 1000) {
                    $regular[] = $user;
                }
            }
        } else {
            $regular = $fmt_data['users_regular'] ?? [];
            $system = $fmt_data['users_system'] ?? [];
        }

        $formatUser = function ($u) use ($isAdmin) {
            $username = $u['username'] ?? '';
            $isLocked = isset($u['lock']) && $u['lock'] == 1;
            $lockBtnStyle = $isLocked ? 'background:#c0392b;color:#fff;border:1px solid #a93226;' : '';
            $lockBtnText = $isLocked ? 'Unlock' : 'Lock';
            $lockBtnData = $isLocked ? '1' : '0';
            $groupsStr = '';
            if (!empty($u['groups']) && is_array($u['groups'])) {
                $groupsStr = implode(', ', $u['groups']);
            }

            return [
                'username' => $username,
                'uid' => $u['uid'] ?? '',
                'gid' => $u['gid'] ?? '',
                'home' => $u['home'] ?? '',
                'shell' => $u['shell'] ?? '',
                'groups_str' => $groupsStr,
                'gecos' => $u['gecos'] ?? '',
                'edit_json' => json_encode(['username' => $username], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
                'is_locked' => $isLocked,
                'lock_btn_style' => $lockBtnStyle,
                'lock_btn_text' => $lockBtnText,
                'lock_btn_data' => $lockBtnData,
                'can_edit' => $isAdmin,
                'can_delete' => $isAdmin,
                'can_lock' => $isAdmin,
            ];
        };

        $regularRows = [];
        foreach ($regular as $u) {
            $regularRows[] = $formatUser($u);
        }

        $systemRows = [];
        foreach ($system as $u) {
            $systemRows[] = $formatUser($u);
        }

        $fmt_data['users_regular_rows'] = $regularRows;
        $fmt_data['users_system_rows'] = $systemRows;

        return $fmt_data;
    }
}
