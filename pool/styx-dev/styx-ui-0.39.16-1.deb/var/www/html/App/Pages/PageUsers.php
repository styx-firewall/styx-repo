<?php
/**
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Controllers\Request\UserRequestController;
use App\Pages\Fmt\UsersFormatter;
use App\Pages\Fmt\ApiTokensFormatter;
use App\Pages\Fmt\UserRolesFormatter;
use App\Pages\Fmt\RoleDefinitionsFormatter;
use App\Services\AuthService;
use App\Services\DateFormatter;
use App\Services\Filter;
use App\Services\UserProfileService;


class PageUsers
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'users',
            'user-api-tokens',
            'user-roles',
            'role-definitions',
            'ldap-servers',
            'radius-servers',
            'sso',
            'user-profile',
        ];

        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'users';
        }

        if ($section === 'users') {
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/users/users-mgmt.js'];
            $controller = new UserRequestController($ctx);
            $response = $controller->getUsers();
            if ($response['status'] !== 'error') {
                $users = $response['result'] ?? [];
                $auth = $ctx->get(AuthService::class);
                $fmt = UsersFormatter::format(['users' => $users], $auth->getCapabilities());
            } else {
                $fmt = [
                    'users' => [],
                    'error' => $response['response_msg'] ?? 'Error loading users',
                ];
            }
        } elseif ($section === 'user-api-tokens') {
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/users/bearer-tokens.js'];
            $userController = new UserRequestController($ctx);
            $response = $userController->getBearerTokens();
            if ($response['status'] !== 'error') {
                $clientTz = $cfg->get('client.timezone', 'UTC');
                $auth = $ctx->get(AuthService::class);
                $fmt = ApiTokensFormatter::format($ctx, ['tokens' => $response['result'] ?? []], $clientTz, $auth->getCapabilities());
            } else {
                $fmt = [
                    'tokens' => [],
                    'error' => $response['response_msg'] ?? 'Error loading tokens',
                ];
            }
        } elseif ($section === 'user-profile') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/users/user-profile.js'];
            $auth = $ctx->get(AuthService::class);
            $username = $auth->getUsername();

            $profile = UserProfileService::readProfile($username ?? '');
            // Generate sample date/time strings using the effective settings.
            // Use a fixed reference timestamp so the format is stable and
            // all components (month, day, hour, min, sec) are clearly visible.
            // 2024-07-04 15:30:45 UTC = 1720107045
            $sampleTs     = 1720107045;
            $sampleShort  = DateFormatter::fromTimestamp($ctx, $sampleTs);

            // Also produce a long-format sample (weekday + full month) via IntlDateFormatter
            $effTz   = $cfg->get('client.timezone', 'UTC');
            $effLoc  = $cfg->get('client.locale', 'en-US');
            $sampleDate = new \DateTime('@' . $sampleTs);
            $sampleDate->setTimezone(new \DateTimeZone($effTz));
            $longFmt = new \IntlDateFormatter(
                $effLoc,
                \IntlDateFormatter::FULL,
                \IntlDateFormatter::SHORT,
                $effTz
            );
            $pattern = $longFmt->getPattern();
            if (!str_contains($pattern, 'ss')) {
                $pattern = str_replace('mm', 'mm:ss', $pattern);
                $longFmt->setPattern($pattern);
            }
            $sampleLong = $longFmt->format($sampleDate);

            $fmt = [
                'username' => $username,
                'profile_timezone' => $profile['timezone'] ?? '',
                'profile_locale' => $profile['locale'] ?? '',
                'profile_debug' => (bool)($profile['debug'] ?? false),
                'timezones' => \DateTimeZone::listIdentifiers(),
                'current_timezone' => $cfg->get('client.timezone', 'UTC'),
                'current_locale' => $cfg->get('client.locale', 'en-US'),
                'sample_short' => $sampleShort,
                'sample_long'  => $sampleLong,
            ];
        } elseif ($section === 'user-roles') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/users/user-roles.js'];
            $controller = new UserRequestController($ctx);
            $response = $controller->getRoles();
            if ($response['status'] !== 'error') {
                $auth = $ctx->get(AuthService::class);
                $fmt = UserRolesFormatter::format([
                    'users' => $response['result']['users'] ?? [],
                    'valid_roles' => $response['result']['valid_roles'] ?? [],
                ], $auth->getCapabilities());
            } else {
                $fmt = [
                    'users' => [],
                    'valid_roles' => [],
                    'error' => $response['response_msg'] ?? 'Error loading roles',
                ];
            }
        } elseif ($section === 'role-definitions') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/users/role-definitions.js'];
            $ctrl = new \App\Controllers\Request\RoleRequestController($ctx);
            $respDefs = $ctrl->getDefinitions();
            $respCaps = $ctrl->getCapabilities();
            $fmt_data = [];
            if ($respDefs['status'] !== 'error') {
                $fmt_data['role_definitions'] = $respDefs['result']['role_definitions'] ?? [];
            } else {
                $fmt_data['role_definitions'] = [];
                $fmt_data['error'] = $respDefs['response_msg'] ?? 'Error loading role definitions';
            }
            if ($respCaps['status'] !== 'error') {
                $fmt_data['available_capabilities'] = $respCaps['result']['capabilities'] ?? [];
            } else {
                $fmt_data['available_capabilities'] = [];
            }
            $auth = $ctx->get(AuthService::class);
            $fmt = RoleDefinitionsFormatter::format(
                $fmt_data,
                $auth->getCapabilities(),
                $cfg->get('features', [])
            );
        }

        $page['page'] = $section;
        $page['page_data'] = $fmt ?? [];
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }
}