<?php
/**
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Controllers\Request\StrongswanRequestController;
use App\Pages\Fmt\StrongswanFormatter;
use App\Services\AuthService;

class PageVPN
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'vpn-strongswan',
            'vpn-wireguard',
        ];

        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'vpn-strongswan';
        }
        $page['page'] = $section;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        // Load section-specific scripts and data
        if ($section === 'vpn-strongswan') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/vpn/vpn-strongswan.js'];

            // Fetch VPN page data from the daemon via StrongswanRequestController
            $swanController = new StrongswanRequestController($ctx);
            $swanResponse = $swanController->getPageData();
            $fmt_data = [];
            if (($swanResponse['status'] ?? 'error') === 'success' && is_array($swanResponse['result'] ?? null)) {
                $fmt_data = $swanResponse['result'];
            }
            $auth = $ctx->get(AuthService::class);
            $fmt = StrongswanFormatter::format($fmt_data, $auth->getCapabilities());
            $page['page_data'] = $fmt;

            // Inject form partials with formatted data (same $fmt, PHP COW)
            $page['load_tpl'][] = [
                'file'     => 'vpn-strongswan-conn-form',
                'place'    => 'swan_conn_form',
                'tpl_data' => $fmt,
                'weight'   => 5,
            ];
            $page['load_tpl'][] = [
                'file'     => 'vpn-strongswan-pool-form',
                'place'    => 'swan_pool_form',
                'weight'   => 6,
            ];
            $page['load_tpl'][] = [
                'file'     => 'vpn-strongswan-secret-form',
                'place'    => 'swan_secret_form',
                'weight'   => 7,
            ];
        }

        return $page;
    }
}
