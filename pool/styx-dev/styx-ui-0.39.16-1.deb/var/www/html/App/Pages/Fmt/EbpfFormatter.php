<?php
/**
 * Formatter for eBPF module management page.
 *
 * Transforms raw API responses into template-ready arrays with pre-computed
 * HTML, CSS classes, and display values. The template only loops and echoes.
 */
namespace App\Pages\Fmt;

class EbpfFormatter
{
    /** @var array<string, string> */
    private const STATUS_BADGE = [
        'loaded'        => 'ebpf-status-loaded',
        'suspended'     => 'ebpf-status-suspended',
        'inactive'      => 'ebpf-status-inactive',
        'available'     => 'ebpf-status-available',
        'incompatible'  => 'ebpf-status-incompatible',
        'error'         => 'ebpf-status-error',
    ];

    private const STATUS_LABEL = [
        'loaded'        => '● Loaded',
        'suspended'     => '◐ Suspended',
        'inactive'      => '○ Inactive',
        'available'     => '○ Available',
        'incompatible'  => '✗ Incompatible',
        'error'         => '⚠ Error',
    ];

    /** @var array<string, string> */
    private const TYPE_BADGE = [
        'core' => 'ebpf-type-core',
        'bcc'  => 'ebpf-type-bcc',
    ];

    //
    // PUBLIC API
    //

    /**
     * Format the module-list response for template consumption.
     *
     * @param array<string,mixed> $data Raw result from ebpf.module-list
     * @return array<string,mixed>
     */
    public static function formatModuleList(array $data): array
    {
        $instances = $data['instances'] ?? [];
        $available = $data['available'] ?? [];

        // Instances rows
        $instancesRows = [];
        foreach ($instances as $mod) {
            $instancesRows[] = self::buildModuleRow($mod, true);
        }

        // Available rows
        $availableRows = [];
        foreach ($available as $mod) {
            $availableRows[] = self::buildModuleRow($mod, false);
        }

        // New foreign tags (programs not yet acknowledged)
        // Match by tag  -  the stable identity (SHA hash of BPF instructions).
        // Kernel IDs are ephemeral and change on every load; never match by id.
        $newForeignTags = [];
        foreach ($data['new_foreign_programs'] ?? [] as $nfp) {
            if (!empty($nfp['tag'])) {
                $newForeignTags[(string)$nfp['tag']] = true;
            }
        }

        // Detachable types (backend can safely detach these)
        $detachableTypes = ['xdp' => true, 'sched_cls' => true, 'sched_act' => true];

        // Internal programs (Styx infrastructure, e.g. xdp_dispatcher)
        $internalRows = [];
        foreach ($data['internal_programs'] ?? [] as $ip) {
            $internalRows[] = [
                'id'        => $ip['id'] ?? ' - ',
                'type'      => $ip['type'] ?? ' - ',
                'name'      => $ip['name'] ?? ' - ',
                'tag'       => isset($ip['tag']) ? substr((string)$ip['tag'], 0, 16) : ' - ',
                'loaded_at' => isset($ip['loaded_at']) ? date('Y-m-d H:i:s', (int)$ip['loaded_at']) : ' - ',
                'uid'       => $ip['uid'] ?? ' - ',
            ];
        }

        // Detect xdp_dispatcher in internal_programs (used as context hint)
        $hasDispatcher = false;
        foreach ($data['internal_programs'] ?? [] as $ip) {
            if (($ip['type'] ?? '') === 'xdp' && ($ip['name'] ?? '') === 'xdp_dispatcher') {
                $hasDispatcher = true;
                break;
            }
        }
        // Fallback: also check foreign_programs (backward compat)
        if (!$hasDispatcher) {
            foreach ($data['foreign_programs'] ?? [] as $fp) {
                if (($fp['type'] ?? '') === 'xdp' && ($fp['name'] ?? '') === 'xdp_dispatcher') {
                    $hasDispatcher = true;
                    break;
                }
            }
        }

        // Foreign programs
        $foreignRows = [];
        foreach ($data['foreign_programs'] ?? [] as $fp) {
            $fpTag = isset($fp['tag']) ? (string)$fp['tag'] : null;
            $fpType = $fp['type'] ?? '';
            $isXdp = $fpType === 'xdp';
            $foreignRows[] = [
                'id'             => $fp['id'] ?? '-',
                'type'           => $fpType ?: '-',
                'name'           => $fp['name'] ?? '-',
                'tag'            => isset($fp['tag']) ? substr((string)$fp['tag'], 0, 16) : '-',
                'loaded_at'      => isset($fp['loaded_at']) ? date('Y-m-d H:i:s', (int)$fp['loaded_at']) : '-',
                'uid'            => $fp['uid'] ?? '-',
                'is_new'         => $fpTag !== null && isset($newForeignTags[$fpTag]),
                'detachable'     => isset($detachableTypes[$fpType]),
                'is_xdp'         => $isXdp,
                'has_dispatcher' => $isXdp && $hasDispatcher,
            ];
        }

        // Conflicts
        $conflictRows = [];
        foreach ($data['conflicts'] ?? [] as $c) {
            $occupied = [];
            foreach ($c['occupied_by'] ?? [] as $o) {
                $occupied[] = ($o['name'] ?? '?') . ' (id=' . ($o['id'] ?? '?') . ')';
            }
            $conflictRows[] = [
                'interface'    => $c['interface'] ?? '-',
                'hook'         => $c['hook'] ?? '-',
                'styx_module'  => $c['styx_module'] ?? '-',
                'occupied_by'  => implode(', ', $occupied) ?: '-',
            ];
        }

        // Coexisting
        $coexistingRows = [];
        foreach ($data['coexisting'] ?? [] as $c) {
            $other = [];
            foreach ($c['other_programs'] ?? [] as $o) {
                $other[] = ($o['name'] ?? '?') . ' (id=' . ($o['id'] ?? '?') . ')';
            }
            $coexistingRows[] = [
                'interface'   => $c['interface'] ?? '-',
                'hook'        => $c['hook'] ?? '-',
                'styx_module' => $c['styx_module'] ?? '-',
                'others'      => implode(', ', $other) ?: '-',
            ];
        }

        return [
            'instances_rows'    => $instancesRows,
            'available_rows'    => $availableRows,
            'internal_rows'     => $internalRows,
            'has_internal'      => !empty($internalRows),
            'foreign_rows'      => $foreignRows,
            'has_foreign'       => !empty($foreignRows),
            'has_new_foreign'   => !empty($newForeignTags),
            'conflict_rows'     => $conflictRows,
            'has_conflicts'     => !empty($conflictRows),
            'coexisting_rows'   => $coexistingRows,
            'has_coexisting'    => !empty($coexistingRows),
            'styx_count'        => $data['styx_program_count'] ?? 0,
            'kernel_count'      => $data['total_kernel_programs'] ?? 0,
            'api_ok'            => true,
        ];
    }

    //
    // HELPERS
    //

    public static function statusBadge(string $status): string
    {
        $cls  = self::STATUS_BADGE[$status] ?? 'ebpf-status-available';
        $label = self::STATUS_LABEL[$status] ?? '○ Available';
        return '<span class="ebpf-status-badge ' . $cls . '">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</span>';
    }

    public static function typeBadge(string $mode): string
    {
        $cls = self::TYPE_BADGE[$mode] ?? '';
        return '<span class="ebpf-info-tag ' . $cls . '">' . htmlspecialchars($mode, ENT_QUOTES, 'UTF-8') . '</span>';
    }

    public static function shortUuid(?string $uuid): string
    {
        if (empty($uuid)) return '-';
        if (strlen($uuid) > 12) return substr($uuid, 0, 8) . '...' . substr($uuid, -4);
        return $uuid;
    }

    public static function uuidLabel(?string $uuid): string
    {
        if (empty($uuid)) return '';
        return '<span class="ebpf-uuid" title="' . htmlspecialchars($uuid, ENT_QUOTES, 'UTF-8') . '">'
            . self::shortUuid($uuid) . '</span>';
    }

    //
    // PRIVATE
    //

    private static function buildModuleRow(array $mod, bool $isInstance): array
    {
        $status = $mod['status'] ?? ($isInstance ? 'loaded' : 'available');
        $interface = $mod['interface'] ?? '';

        return [
            'name'          => $mod['name'] ?? '-',
            'version'       => $mod['version'] ?? '',
            'instance_id'   => $mod['instance_id'] ?? null,
            'uuid_html'     => self::uuidLabel($mod['instance_id'] ?? null),
            'status_html'   => self::statusBadge($status),
            'status'        => $status,
            'type_html'     => self::typeBadge($mod['mode'] ?? ''),
            'mode'          => $mod['mode'] ?? '',
            'hook_type'     => $mod['hook_type'] ?? '-',
            'interface'     => $interface !== '' ? $interface : '-',
            'autoload'             => (bool)($mod['autoload'] ?? false),
            'autoload_attr'        => ($mod['autoload'] ?? false) ? 'checked' : '',
            'attach_target'        => $mod['attach_target'] ?? 'interface',
            'has_autoload'         => $isInstance && !empty($mod['instance_id']),
            'pre_attach_params'    => $mod['pre_attach_params'] ?? [],
            'has_pre_attach_params' => !empty($mod['pre_attach_params'] ?? []),
        ];
    }
}
