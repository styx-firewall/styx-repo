<?php
namespace App\Pages\Fmt;

use App\Core\AppContext;

class PacketMarkingFormatter
{
    /**
     * @param AppContext $ctx
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(AppContext $ctx, array $fmt_data): array
    {
        $fmt_data['chains'] = [
            'input'       => 'Input',
            'output'      => 'Output',
            'forward'     => 'Forward',
            'prerouting'  => 'Prerouting',
            'postrouting' => 'Postrouting',
            'ingress'     => 'Ingress',
            'egress'      => 'Egress',
        ];
        $fmt_data['protocols'] = [
            'tcp'    => 'TCP',
            'udp'    => 'UDP',
            'icmp'   => 'ICMP',
            'icmpv6' => 'ICMPv6',
            'any'    => 'Any',
        ];

        // Normalise protocol for each rule; *_display fields come pre-resolved from the backend.
        foreach ($fmt_data['rules'] as $k => $r) {
            $proto = $r['protocol'] ?? '';
            $fmt_data['rules'][$k]['protocol'] = ($proto === null || $proto === '')
                ? 'any'
                : strtolower((string)$proto);
        }

        return $fmt_data;
    }
}
