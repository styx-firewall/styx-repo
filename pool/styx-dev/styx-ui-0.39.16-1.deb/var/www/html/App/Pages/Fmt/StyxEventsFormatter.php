<?php
/**
 * Formatter for Styx events page.
 */
namespace App\Pages\Fmt;

use App\Core\AppContext;
use App\Services\DateFormatter;
use App\Core\Config;

class StyxEventsFormatter
{
    /**
     * Normalize events and filter options for the template.
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(AppContext $ctx, array $fmt_data): array
    {
        $filters = $fmt_data['filters'] ?? ['level' => '', 'limit' => '', 'search' => ''];
        $filters['level'] = $filters['level'] ?? '';
        $filters['limit'] = $filters['limit'] ?? '';
        $filters['search'] = $filters['search'] ?? '';

        $loglevel = $fmt_data['loglevel'] ?? [];

        $levels_options = [];
        // 'All' option
        $levels_options[] = [
            'name' => 'All',
            'value' => '',
            'selected' => ($filters['level'] === '' || $filters['level'] === null)
        ];
        foreach ($loglevel as $level_name => $level_value) {
            $levels_options[] = [
                'name' => $level_name,
                'value' => $level_value,
                'selected' => (
                    $filters['level'] !== '' && (string)$filters['level'] === (string)$level_value
                )
            ];
        }

        $limit_options = [];
        foreach ([50, 100, 200, 500] as $qty) {
            $selected = false;
            if ($filters['limit'] !== '') {
                $selected = ((int)$filters['limit'] == $qty);
            } else {
                // default to 50 when no limit specified
                $selected = ($qty === 50);
            }
            $limit_options[] = [
                'value' => $qty,
                'selected' => $selected
            ];
        }
        $events = $fmt_data['events'] ?? [];
        $events_rows = [];
        foreach ($events as $event) {
            $row = [];
            $row['id'] = $event['id'] ?? '';
            $row['datetime'] = DateFormatter::fromBackend($ctx, (string)$event['timestamp_iso']);
            $row['level_name'] = $event['level_name'] ?? '';
            $row['event_name'] = $event['event_name'] ?? '';
            $row['message'] = $event['message'] ?? '';
            $row['has_data'] = !empty($event['data']);
            $row['raw_b64'] = '';
            if ($row['has_data']) {
                $row['raw_b64'] = base64_encode(
                    json_encode($event['data'], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)
                );
            }
            $events_rows[] = $row;
        }

        $fmt_data['levels_options'] = $levels_options;
        $fmt_data['limit_options'] = $limit_options;
        $fmt_data['events_rows'] = $events_rows;
        // expose normalized filters back to template
        $fmt_data['filters'] = $filters;

        return $fmt_data;
    }
}
