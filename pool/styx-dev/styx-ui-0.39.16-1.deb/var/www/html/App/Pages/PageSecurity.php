<?php
/**
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Controllers\Request\SecurityRequestController;
use App\Pages\Fmt\SecurityFormatter;
use App\Services\Filter;

class PageSecurity
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'sec-overview',
            'sec-audit',
            'sec-auditd',
            'sec-aide',
        ];

        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'sec-overview';
        }

        $reqController = new SecurityRequestController($ctx);
        $fmt = [];

        if ($section === 'sec-overview') {
            $overview_data = [];
            $response = $reqController->getSecOverview();

            if (!empty($response['result']['sec_overview']['audit_summary'])) {
                $overview_data['audit_summary'] = $response['result']['sec_overview']['audit_summary'];
            }
            $partial_fmt = SecurityFormatter::format($section, $overview_data);
            // Render the reusable overview fragment into the page via load_tpl
            $page['load_tpl'][] = [
                'file'     => 'sec-over-audit',
                'place'    => 'sec_overview_audit_frag',
                'tpl_data' => $partial_fmt,
                'weight'   => 1,
            ];
        } elseif ($section === 'sec-audit') {
            $response = $reqController->getSecAudit();
            $audit_overview = [];
            if(!empty($response['result']['sec_audit']['report']['audit_summary'])) {
                $audit_overview['audit_summary'] = $response['result']['sec_audit']['report']['audit_summary'];
            }
            $partial_fmt = SecurityFormatter::format($section, $audit_overview);

            $page['load_tpl'][] = [
                'file'     => 'sec-over-audit',
                'place'    => 'sec_overview_audit_frag',
                'tpl_data' => $partial_fmt,
                'weight'   => 1,
            ];
            $audit_checks = $response['result']['sec_audit']['report']['checks'] ?? [];
            $fmt['audit'] = SecurityFormatter::format($section, $audit_checks);

        } elseif ($section === 'sec-auditd') {
            $response = $reqController->getSecAuditd();
            $fmt['auditd'] = SecurityFormatter::format($section, $response);
        } elseif ($section === 'sec-aide') {
            $response = $reqController->getSecAide();
            $fmt['aide'] = SecurityFormatter::format($section, $response);
        }

        $page['page'] = $section;
        $page['page_data'] = $fmt;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }
}
