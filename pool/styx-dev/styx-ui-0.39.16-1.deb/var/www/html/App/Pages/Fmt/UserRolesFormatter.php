<?php
/**
 * Formatter for user roles page.
 * Pre-computes capability flags for the template.
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class UserRolesFormatter
{
    /**
     * Prepare roles data for template consumption.
     *
     * @param array<string,mixed> $fmt_data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data, array $userCaps = []): array
    {
        $fmt_data['can_manage'] = RoleHelper::hasCapability($userCaps, 'users:admin');

        $users = $fmt_data['users'] ?? [];
        $rows = [];
        foreach ($users as $u) {
            $username = $u['username'] ?? '';
            $rows[] = [
                'username'  => $username,
                'role'      => $u['role'] ?? null,
                'immutable' => ($username === 'admin'),
            ];
        }
        $fmt_data['user_rows'] = $rows;

        return $fmt_data;
    }
}
