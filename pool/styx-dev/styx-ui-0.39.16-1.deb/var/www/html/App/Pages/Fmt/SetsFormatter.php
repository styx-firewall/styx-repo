<?php
namespace App\Pages\Fmt;

class SetsFormatter
{
    /**
     * Prepare presentation keys for fw-mgmt-sets page.
     * Moves display logic out of the template.
     * @param array $fmt_data
     * @return array
     */
    public static function format(array $fmt_data): array
    {
        $sets = $fmt_data['sets'] ?? [];

        $address_sets = [];
        foreach ($sets['address'] ?? [] as $a) {
            $display = '';
            $type = $a['type'] ?? '';
            if ($type === 'single') {
                $display = $a['value_single'] ?? '';
            } elseif ($type === 'range') {
                $display = trim(($a['value_range_start'] ?? '') . ' - ' . ($a['value_range_end'] ?? ''));
            } elseif ($type === 'set') {
                $display = !empty($a['value_set']) && is_array($a['value_set']) ? implode(', ', $a['value_set']) : '';
            }
            $a['value_display'] = $display;
            $a['refs_count'] = (isset($a['refs']) && is_array($a['refs'])) ? count($a['refs']) : 0;
            // Prepare separate display fields for type, scope and family
            $scope = '';
            if (isset($a['scope'])) {
                if (is_array($a['scope'])) {
                    $scope = implode(',', $a['scope']);
                } else {
                    $scope = (string)$a['scope'];
                }
            }
            $a['type_display'] = $type;
            $a['scope_display'] = $scope;

            // Family may be provided as 'family' (e.g. 'ip' or 'ip6') - convert to human label
            $family = $a['family'] ?? '';
            if ($family === 'ip') {
                $a['family_display'] = 'IPv4';
            } elseif ($family === 'ip6') {
                $a['family_display'] = 'IPv6';
            } else {
                $a['family_display'] = $family;
            }
            // Prepare tags HTML for templates to render tag chips (keeps logic out of tpl files)
            $tags_html = '';
            if (isset($a['tags']) && is_array($a['tags'])) {
                foreach ($a['tags'] as $t) {
                    $tags_html .= '<span class="tag-chip">' . (string)$t . '</span>';
                }
            }
            $a['tags_html'] = $tags_html;
            $address_sets[] = $a;
        }

        // Build unique address scopes for the filter dropdown (moved from template)
        $address_scopes = [];
        foreach ($address_sets as $a) {
            $sval = $a['scope'] ?? '';
            if ($sval === '') continue;
            $sval = is_array($sval) ? implode(',', $sval) : (string)$sval;
            if (!isset($address_scopes[$sval])) {
                $address_scopes[$sval] = $a['scope_display'] ?? $sval;
            }
        }

        $ports_sets = [];
        foreach ($sets['ports'] ?? [] as $p) {
            $display = '';
            $type = $p['type'] ?? '';
            if ($type === 'single') {
                $display = $p['value_single'] ?? '';
            } elseif ($type === 'range') {
                $display = trim(($p['value_range_start'] ?? '') . ' - ' . ($p['value_range_end'] ?? ''));
            } elseif ($type === 'set') {
                $display = !empty($p['value_set']) && is_array($p['value_set']) ? implode(', ', $p['value_set']) : '';
            }
            $p['value_display'] = $display;
            $p['refs_count'] = (isset($p['refs']) && is_array($p['refs'])) ? count($p['refs']) : 0;
            // Normalize scope display (like address does)
            $scope = '';
            if (isset($p['scope'])) {
                if (is_array($p['scope'])) {
                    $scope = implode(',', $p['scope']);
                } else {
                    $scope = (string)$p['scope'];
                }
            }
            $p['scope_display'] = $scope;
            $tags_html = '';
            if (isset($p['tags']) && is_array($p['tags'])) {
                foreach ($p['tags'] as $t) {
                    $tags_html .= '<span class="tag-chip">' . (string)$t . '</span>';
                }
            }
            $p['tags_html'] = $tags_html;
            $ports_sets[] = $p;
        }

        // Build unique port scopes for the filter dropdown (moved from template)
        $ports_scopes = [];
        foreach ($ports_sets as $p) {
            $sval = $p['scope'] ?? '';
            if ($sval === '') continue;
            $sval = is_array($sval) ? implode(',', $sval) : (string)$sval;
            if (!isset($ports_scopes[$sval])) {
                $ports_scopes[$sval] = $p['scope_display'] ?? $sval;
            }
        }

        $interfaces_sets = [];
        foreach ($sets['interfaces_sets'] ?? [] as $iset) {
            $display = '';
            $itype = $iset['type'] ?? '';
            if ($itype === 'single') {
                $display = $iset['value_single'] ?? '';
            } elseif (!empty($iset['interfaces']) && is_array($iset['interfaces'])) {
                $display = implode(', ', $iset['interfaces']);
            } elseif (!empty($iset['value_set']) && is_array($iset['value_set'])) {
                $display = implode(', ', $iset['value_set']);
            }
            $iset['value_display'] = $display;
            $iset['refs_count'] = (isset($iset['refs']) && is_array($iset['refs'])) ? count($iset['refs']) : 0;
            $tags_html = '';
            if (isset($iset['tags']) && is_array($iset['tags'])) {
                foreach ($iset['tags'] as $t) {
                    $tags_html .= '<span class="tag-chip">' . (string)$t . '</span>';
                }
            }
            $iset['tags_html'] = $tags_html;
            $interfaces_sets[] = $iset;
        }

        $ifaces_names = $sets['ifaces_names'] ?? [];

        $domain_sets = [];
        foreach ($sets['domain'] ?? [] as $d) {
            $display = '';
            $type = $d['type'] ?? '';
            if ($type === 'single') {
                $display = $d['value_single'] ?? '';
            } elseif ($type === 'set') {
                $display = !empty($d['value_set']) && is_array($d['value_set']) ? implode(', ', $d['value_set']) : '';
            }
            $d['value_display'] = $display;
            $d['refs_count'] = (isset($d['refs']) && is_array($d['refs'])) ? count($d['refs']) : 0;
            $tags_html = '';
            if (isset($d['tags']) && is_array($d['tags'])) {
                foreach ($d['tags'] as $t) {
                    $tags_html .= '<span class="tag-chip">' . (string)$t . '</span>';
                }
            }
            $d['tags_html'] = $tags_html;
            $domain_sets[] = $d;
        }

        $fmt_data['address_sets'] = $address_sets;
        $fmt_data['address_scopes'] = $address_scopes;
        $fmt_data['ports_sets'] = $ports_sets;
        $fmt_data['ports_scopes'] = $ports_scopes;
        $fmt_data['interfaces_sets'] = $interfaces_sets;
        $fmt_data['domain_sets'] = $domain_sets;
        $fmt_data['ifaces_names'] = $ifaces_names;

        return $fmt_data;
    }
}
