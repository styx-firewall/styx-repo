<?php
/**
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Controllers\Request\DhcpRequestController;
use App\Pages\Fmt\ServDhcpFormatter;

class PageServices
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'serv-dhcp',
        ];

        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'serv-dhcp';
        }

        if ($section === 'serv-dhcp') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/dhcp/serv-dhcp.js'];
            $dhcpController = new DhcpRequestController($ctx);
            $dhcp_response = $dhcpController->getPageData();

            $fmt_data = [];
            $fmt_data['iface_list'] = [];
            $fmt_data['dhcp_config'] = [];
            $fmt_data['dhcp_global_config'] = [];
            $fmt_data['leases'] = [];
            $fmt_data['address_sets'] = [];
            $fmt_data['domain_sets'] = [];
            if ($dhcp_response['status'] !== 'error') {
                $all_ifaces = $dhcp_response['result']['interfaces'] ?? [];
                $fmt_data['iface_list'] = array_values(array_filter($all_ifaces, function($iface) {
                    if (isset($iface['interface']) && strtolower($iface['interface']) === 'lo') return false;
                    if (!isset($iface['ip_mode']) || strtolower($iface['ip_mode']) !== 'static') return false;
                    if (!empty($iface['missing'])) return false;
                    return (!empty($iface['ipv4']) || !empty($iface['ipv6']));
                }));
                $fmt_data['dhcp_config'] = $dhcp_response['result']['dhcp_config'] ?? [];
                $fmt_data['dhcp_global_config'] = $dhcp_response['result']['dhcp_global_config'] ?? [];
                $fmt_data['leases'] = $dhcp_response['result']['leases'] ?? [];
                $fmt_data['address_sets'] = $dhcp_response['result']['address_sets'] ?? [];
                $fmt_data['domain_sets'] = $dhcp_response['result']['domain_sets'] ?? [];
            }
            $fmt_data['features'] = $cfg->get('features', []);
            $fmt = ServDhcpFormatter::format($ctx, $fmt_data);

            // Inject serv-dhcp fragments with formatted data (PHP COW)
            $page['load_tpl'][] = [
                'file'     => 'serv-dhcp-global',
                'place'    => 'serv_dhcp_global',
                'tpl_data' => $fmt,
                'weight'   => 5,
            ];
            $page['load_tpl'][] = [
                'file'     => 'serv-dhcp-config',
                'place'    => 'serv_dhcp_config',
                'tpl_data' => $fmt,
                'weight'   => 6,
            ];
            $page['load_tpl'][] = [
                'file'     => 'serv-dhcp-leases',
                'place'    => 'serv_dhcp_leases',
                'tpl_data' => $fmt,
                'weight'   => 7,
            ];
        }

        $page['page'] = $section;
        $page['page_data'] = $fmt ?? [];
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }
}
