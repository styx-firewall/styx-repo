<?php
/**
 * Formatter for system certificates page.
 * Precomputes display strings and classes per certificate.
 */
namespace App\Pages\Fmt;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\DateFormatter;
use App\Helpers\RoleHelper;
class SysCertsFormatter
{
    /**
     * Group raw certificates by group_key and compute presentation flags.
     *
     * @param AppContext $ctx
     * @param array $certs Raw certificates list
     * @param string[] $userCaps
     * @return array{can_upload: bool, certificates_grouped: array}
     */
    public static function format(AppContext $ctx, array $certs, array $userCaps = []): array
    {
        $isAdmin = RoleHelper::hasCapability($userCaps, 'system:admin');
        $now = time();

        // Group by group_key
        $grouped = [];
        foreach ($certs as $cert) {
            $groupKey = $cert['group_key'] ?? 'unknown';
            $grouped[$groupKey][] = $cert;
        }

        $fmt_data = [
            'can_upload' => $isAdmin,
        ];

        $outGrouped = [];
        foreach ($grouped as $groupKey => $certs) {
            $outCerts = [];
            foreach ($certs as $cert) {
                $c = $cert;
                $expired = (($c['status'] ?? '') === 'expired');
                $expiringSoon = false;
                if (!empty($c['expiration']) && $c['status'] !== 'expired') {
                    $expTimestamp = strtotime($c['expiration']);
                    $daysLeft = ($expTimestamp - $now) / 86400;
                    if ($daysLeft <= 30 && $daysLeft > 0) {
                        $expiringSoon = true;
                    }
                }

                $dateClass = $expired ? 'expired-date' : ($expiringSoon ? 'expiring-soon-date' : '');

                // Normalize usage to a printable string
                $usageVal = $c['usage'] ?? null;
                if (is_array($usageVal)) {
                    $usageStr = implode(', ', $usageVal);
                } elseif ($usageVal !== null) {
                    $usageStr = (string)$usageVal;
                } else {
                    $usageStr = '';
                }

                $c['expired'] = $expired;
                $c['expiring_soon'] = $expiringSoon;
                $c['date_class'] = $dateClass;
                $c['usage_str'] = $usageStr;
                if (!empty($c['expiration'])) {
                    $c['expiration'] = DateFormatter::fromBackend($ctx, $c['expiration']);
                }
                $c['can_delete'] = $isAdmin;

                $outCerts[] = $c;
            }
            $outGrouped[$groupKey] = $outCerts;
        }

        $fmt_data['certificates_grouped'] = $outGrouped;
        return $fmt_data;
    }
}
