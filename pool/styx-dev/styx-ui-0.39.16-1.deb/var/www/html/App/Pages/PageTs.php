<?php
/**
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Controllers\Request\TCRequestController;
use App\Services\Filter;
use App\Pages\Fmt\TsTcOverviewFormatter;
use App\Pages\Fmt\TsTcRulesFormatter;
use App\Pages\Fmt\TsTcConfigFormatter;

class PageTs
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = ['ts-tc-rules', 'ts-tc-config'];

        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'ts-tc-overview';
        }

        if ($section === 'ts-tc-overview') {
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/thirdparty/sankey-loader.js'];
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/charts-core/sankey.js'];
        } else if ($section === 'ts-tc-rules') {
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/tc/tc-common.js'];
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/tc/tc-rules.js'];
        } else if ($section === 'ts-tc-config') {
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/tc/tc-common.js'];
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/tc/tc-config.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/tc/tc-class.js', 'module' => true];
        }

        $fmt_data = [];

        if ($section === 'ts-tc-rules' || $section === 'ts-tc-config') {
            $tcController = new TCRequestController($ctx);
            $tc_config = $tcController->getTcConfig();
            $fmt_data['tc_config'] = [];
            $fmt_data['tc_valid_qdisc'] = [];
            $fmt_data['tc_warnings'] = [];
            if (isset($tc_config['status']) && $tc_config['status'] === 'success') {
                if (isset($tc_config['result']['config']['interfaces']) && is_array($tc_config['result']['config']['interfaces'])) {
                    $fmt_data['tc_config']= $tc_config['result']['config']['interfaces'];
                }
                if (isset($tc_config['result']['valid_qdisc']) && is_array($tc_config['result']['valid_qdisc'])) {
                    $fmt_data['tc_valid_qdisc'] = $tc_config['result']['valid_qdisc'];
                }
                // Extract command-level warnings from the controller response
                if (isset($tc_config['warnings']) && is_array($tc_config['warnings'])) {
                    $fmt_data['tc_warnings'] = $tc_config['warnings'];
                }
                // Run minimal formatter to prepare display-ready data for templates
                if ($section === 'ts-tc-rules') {
                    $fmt_data = TsTcRulesFormatter::format($fmt_data);
                } else {
                    $fmt_data = TsTcConfigFormatter::format($fmt_data);
                }
            }
        } else if ($section === 'ts-tc-overview') {
            $tcController = new TCRequestController($ctx);
            $tc_stats = $tcController->getTcStats();
            $fmt_data['tc_stats'] = [];
            if (isset($tc_stats['status']) && $tc_stats['status'] === 'success') {
                $fmt_data['tc_stats'] = $tc_stats['result'] ?? [];
                // Run minimal formatter for overview display (sankey flows, rows)
                $fmt_data = TsTcOverviewFormatter::format($fmt_data);
            }
        }

        $page['page'] = $section;
        $page['page_data'] = $fmt_data;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }
}
