<?php
/**
 * Formatter for API tokens page.
 * Converts backend date strings (UTC) into client timezone for presentation.
 */
namespace App\Pages\Fmt;

use App\Core\AppContext;
use App\Services\DateFormatter;
use App\Helpers\RoleHelper;

class ApiTokensFormatter
{
    /**
     * Prepare tokens data for template consumption.
     *
     * @param AppContext $ctx
     * @param array<string,mixed> $fmt_data
     * @param string $clientTz
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(AppContext $ctx, array $fmt_data, string $clientTz = 'UTC', array $userCaps = []): array
    {
        $canManage = RoleHelper::hasCapability($userCaps, 'auth:write');
        $fmt_data['can_generate'] = $canManage;

        $tokens = $fmt_data['tokens'] ?? [];

        foreach ($tokens as &$t) {
            if (!empty($t['created_at'])) {
                $t['created_at'] = DateFormatter::fromBackend($ctx, (string)$t['created_at']);
            }
            if (!empty($t['last_used_at'])) {
                $t['last_used_at'] = DateFormatter::fromBackend($ctx, (string)$t['last_used_at']);
            }
            if (!empty($t['expires_at'])) {
                $t['expires_at'] = DateFormatter::fromBackend($ctx, (string)$t['expires_at']);
            }
            $t['can_revoke'] = $canManage;
        }
        unset($t);

        $fmt_data['tokens'] = $tokens;
        return $fmt_data;
    }
}
