<?php
/**
 * Formatter for Styx settings page.
 * Moves presentation formatting out of the template.
 */
namespace App\Pages\Fmt;

class StyxSettingsFormatter
{
    /**
     * Normalize styx settings, UI settings and certs for templates.
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $styx = $fmt_data['styx_settings'] ?? [];
        $logLevels = $fmt_data['loglevel'] ?? [];

        // UI settings
        $ui = $fmt_data['ui_settings'] ?? [];
        $ui['pemfile'] = $ui['pemfile'] ?? ($styx['pemfile'] ?? '');
        $ui['https_port'] = $ui['https_port']  ?? 443;

        // Ensure some common styx settings have defaults so templates can trust them
        $styx['styx_branch'] = $styx['styx_branch'] ?? 'dev';
        $styx['styx_theme'] = $styx['styx_theme'] ?? 'default';
        if (isset($styx['styx_log_level']) && is_numeric($styx['styx_log_level'])) {
            $styx['styx_log_level'] = (int)$styx['styx_log_level'];
        } else {
            $styx['styx_log_level'] = null;
        }

        $logLevelOptions = [];
        foreach ($logLevels as $name => $value) {
            $logLevelOptions[] = [
                'name' => $name,
                'value' => $value,
                'selected' => ((int)$styx['styx_log_level'] === (int)$value),
            ];
        }

        // Certs processing: ensure fields and selection flag
        $certs_in = $fmt_data['certs'] ?? [];
        $certs = [];
        foreach ($certs_in as $c) {
            $id = $c['id'] ?? '';
            $name = $c['name'] ?? ($c['file_name'] ?? $id);
            $display = $c['display'] ?? ($name . ' (' . ($c['type'] ?? '') . ')');
            $certs[] = [
                'id' => $id,
                'name' => $name,
                'display' => $display,
                'cert_path' => $c['cert_path'] ?? '',
                'key_path' => $c['key_path'] ?? '',
                'file_missing' => !empty($c['file_missing']),
                'selected' => (
                    (!empty($ui['pemfile'])
                        && (($c['cert_path'] ?? '') === $ui['pemfile']))
                    || !empty($c['selected'])
                )
            ];
        }

        $fmt_data['styx_settings'] = $styx;
        $fmt_data['ui_settings'] = $ui;
        $fmt_data['certs'] = $certs;
        $fmt_data['loglevel_options'] = $logLevelOptions;

        return $fmt_data;
    }
}
