<?php
/**
 * Formatter for Styx logs page.
 * Prepares level options and limit defaults for the template.
 */
namespace App\Pages\Fmt;

class StyxLogsFormatter
{
    /**
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $levels = $fmt_data['levels'] ?? ['DEBUG','INFO','NOTICE','WARNING','ERROR','CRITICAL','ALERT','EMERGENCY'];
        $filters = $fmt_data['filters'] ?? ['level' => '', 'limit' => 50];

        $levels_options = [];
        foreach ($levels as $lvl) {
            $selectedLevel = (string)($filters['level'] ?? '');
            $isLevelSet = $selectedLevel !== '';
            $isSelected = $isLevelSet
                ? $selectedLevel === (string)$lvl
                : $lvl === 'DEBUG';

            $levels_options[] = [
                'value' => $lvl,
                'selected' => $isSelected,
            ];
        }

        $limit_value = isset($filters['limit']) && is_numeric($filters['limit']) ? (int)$filters['limit'] : 50;

        $fmt_data['levels_options'] = $levels_options;
        $fmt_data['limit'] = $limit_value;
        $fmt_data['filters'] = $filters;

        return $fmt_data;
    }
}
