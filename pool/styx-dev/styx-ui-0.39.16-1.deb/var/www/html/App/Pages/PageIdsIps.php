<?php
/**
 * IDS/IPS main page controller
 */
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;

class PageIdsIps
{
    /**
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'ids-rules',
            'ids-alerts',
            'ids-config',
        ];
        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'ids-overview';
        }
        $page['page'] = $section;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];
        $page['load_tpl'][] = [
            'file' => $section,
            'place' => 'page-content',
        ];
        return $page;
    }
}
