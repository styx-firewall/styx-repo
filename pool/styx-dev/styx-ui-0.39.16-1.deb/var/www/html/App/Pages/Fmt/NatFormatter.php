<?php

namespace App\Pages\Fmt;

class NatFormatter
{
    /**
     * Separate raw NAT rules by type, encode as JSON for JS, and produce
     * server-rendered row arrays for the template tables.
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $rules = $fmt_data['rules'] ?? [];
        $portForwarding = [];
        $outbound = [];
        $staticNat = [];

        foreach ($rules as $rule) {
            $type = $rule['nat_rule_type'] ?? null;
            if ($type === 'port_forwarding') {
                $portForwarding[] = $rule;
            } elseif ($type === 'outbound') {
                $outbound[] = $rule;
            } elseif ($type === 'static_nat') {
                $staticNat[] = $rule;
            }
        }

        $fmt_data['port_forwarding_rules_json'] = json_encode($portForwarding);
        $fmt_data['outbound_rules_json']         = json_encode($outbound);
        $fmt_data['static_nat_rules_json']       = json_encode($staticNat);
        $fmt_data['addresses_json']              = json_encode($fmt_data['addresses'] ?? []);
        $fmt_data['ports_json']                  = json_encode($fmt_data['ports'] ?? []);
        $fmt_data['ifaces_json']                 = json_encode($fmt_data['ifaces_sets'] ?? []);

        // Server-rendered table rows
        $fmt_data['pf_rows']  = self::formatPfRows($portForwarding);
        $fmt_data['ob_rows']  = self::formatObRows($outbound);
        $fmt_data['sn_rows']  = self::formatSnRows($staticNat);
        $fmt_data['ov_rows']  = self::formatOverviewRows($portForwarding, $outbound, $staticNat, $rules);

        return $fmt_data;
    }

    // ------------------------------------------------------------------
    // Row formatters
    // ------------------------------------------------------------------

    /**
     * @param array<int,array<string,mixed>> $rules
     * @return array<int,array<string,mixed>>
     */
    private static function formatPfRows(array $rules): array
    {
        $rows = [];
        foreach ($rules as $rule) {
            $rows[] = [
                'enabled'       => !empty($rule['enabled']),
                'name'          => $rule['name'] ?? '',
                'family'        => $rule['family'] ?? '',
                'src_ifaces'    => self::joinNames($rule['src_ifaces'] ?? []),
                'dst_ports'     => self::joinNames($rule['dst_ports'] ?? []),
                'src_ips'       => self::joinNames($rule['src_ips'] ?? []),
                'to_set'        => self::singleName($rule['to_set'] ?? null),
                'to_ports'      => self::singleName($rule['to_ports'] ?? null),
                'protocol'      => $rule['protocol'] ?? '',
                'packets'       => $rule['packets'] ?? '',
                'bytes'         => $rule['bytes'] ?? '',
                'id'            => $rule['id'] ?? '',
            ];
        }
        return $rows;
    }

    /**
     * @param array<int,array<string,mixed>> $rules
     * @return array<int,array<string,mixed>>
     */
    private static function formatObRows(array $rules): array
    {
        $rows = [];
        foreach ($rules as $rule) {
            $rows[] = [
                'enabled'       => !empty($rule['enabled']),
                'name'          => $rule['name'] ?? '',
                'family'        => $rule['family'] ?? '',
                'action'        => $rule['action'] ?? '',
                'to_set'        => self::singleName($rule['to_set'] ?? null),
                'src_ips'       => self::joinNames($rule['src_ips'] ?? []),
                'dst_ifaces'    => self::joinNames($rule['dst_ifaces'] ?? []),
                'dst_ips'       => self::joinNames($rule['dst_ips'] ?? []),
                'protocol'      => $rule['protocol'] ?? '',
                'packets'       => $rule['packets'] ?? '',
                'bytes'         => $rule['bytes'] ?? '',
                'id'            => $rule['id'] ?? '',
            ];
        }
        return $rows;
    }

    /**
     * Group static NAT rules into display pairs, then format.
     *
     * @param array<int,array<string,mixed>> $rules
     * @return array<int,array<string,mixed>>
     */
    private static function formatSnRows(array $rules): array
    {
        $grouped = [];
        foreach ($rules as $rule) {
            $ref = $rule['nat_pair_ref'] ?? $rule['id'] ?? '';
            if (!isset($grouped[$ref])) {
                $grouped[$ref] = [];
            }
            $grouped[$ref][] = $rule;
        }
        $rows = [];
        foreach ($grouped as $pair) {
            $dnat = null;
            $snat = null;
            foreach ($pair as $r) {
                if (($r['action'] ?? '') === 'snat') {
                    $snat = $r;
                } else {
                    $dnat = $r;
                }
            }
            if ($dnat === null) {
                $dnat = $pair[0];
            }
            $rows[] = [
                'enabled'        => !empty($dnat['enabled']),
                'name'           => $dnat['name'] ?? '',
                'family'         => $dnat['family'] ?? '',
                'to_public_set'  => self::singleName($snat ? ($snat['to_public_set'] ?? null) : null),
                'to_private_set' => self::singleName($dnat['to_private_set'] ?? null),
                'src_ifaces'     => self::joinNames($dnat['src_ifaces'] ?? []),
                'packets'        => $dnat['packets'] ?? '',
                'bytes'          => $dnat['bytes'] ?? '',
                'id'             => $dnat['id'] ?? '',
            ];
        }
        return $rows;
    }

    /**
     * Merge all rule types into a single overview row set.
     *
     * @param array<int,array<string,mixed>> $pf
     * @param array<int,array<string,mixed>> $ob
     * @param array<int,array<string,mixed>> $sn
     * @param array<int,array<string,mixed>> $allRules
     * @return array<int,array<string,mixed>>
     */
    private static function formatOverviewRows(array $pf, array $ob, array $sn, array $allRules): array
    {
        $rows = [];
        foreach ($pf as $r) {
            $rows[] = self::ovRow($r, 'port_forwarding', 'dnat');
        }
        foreach ($ob as $r) {
            $rows[] = self::ovRow($r, 'outbound', $r['action'] ?? '');
        }
        foreach ($sn as $r) {
            $rows[] = self::ovRow($r, 'static_nat', '');
        }
        // Include untyped / system rules
        foreach ($allRules as $r) {
            if (!empty($r['nat_rule_type'])) {
                continue;
            }
            $rows[] = self::ovRow($r, $r['nat_rule_type'] ?? 'system', $r['action'] ?? $r['chain'] ?? '');
        }
        return $rows;
    }

    /**
     * Build a single overview row.
     */
    private static function ovRow(array $r, string $type, string $action): array
    {
        $typ = $type;
        $src = '';
        $dest = '';
        $outiface = '';

        if ($typ === 'port_forwarding') {
            $src      = self::joinNames($r['src_ips'] ?? []);
            $dest     = self::singleName($r['to_set'] ?? null)
                      . ($r['to_ports'] ?? null ? ' :' . self::singleName($r['to_ports']) : '');
            $outiface = self::joinNames($r['src_ifaces'] ?? []);
        } elseif ($typ === 'outbound') {
            $src      = self::joinNames($r['src_ips'] ?? []);
            $dest     = self::joinNames($r['dst_ips'] ?? []);
            $outiface = self::joinNames($r['dst_ifaces'] ?? []);
        } elseif ($typ === 'static_nat') {
            $dest     = self::singleName($r['to_public_set'] ?? null)
                      . ' ↔ ' . self::singleName($r['to_private_set'] ?? null);
            $outiface = self::joinNames($r['src_ifaces'] ?? []);
        } else {
            $src      = self::joinNames($r['src_ips'] ?? $r['src_ip'] ?? []);
            $dest     = self::joinNames($r['dst_ips'] ?? $r['dst_ip'] ?? []);
            $outiface = self::joinNames($r['dst_ifaces'] ?? $r['src_ifaces'] ?? []);
        }

        return [
            'type'      => $typ,
            'name'      => $r['name'] ?? '',
            'family'    => $r['family'] ?? '',
            'action'    => $action,
            'source'    => $src,
            'dest'      => $dest,
            'outiface'  => $outiface,
            'enabled'   => !empty($r['enabled']),
            'packets'   => $r['packets'] ?? '',
            'bytes'     => $r['bytes'] ?? '',
            'system'    => ($typ === 'system' || !empty($r['system_rule'])),
        ];
    }

    // ------------------------------------------------------------------
    // Display helpers
    // ------------------------------------------------------------------

    /**
     * Join display names from an array of set objects.
     *
     * @param array<int,array<string,mixed>> $sets
     * @return string
     */
    private static function joinNames(array $sets): string
    {
        $names = [];
        foreach ($sets as $s) {
            if (is_array($s)) {
                $names[] = $s['name'] ?? $s['id'] ?? '';
            } else {
                $names[] = (string) $s;
            }
        }
        return implode(', ', array_filter($names));
    }

    /**
     * Resolve a single set object to its display name.
     *
     * @param array<string,mixed>|null $set
     * @return string
     */
    private static function singleName($set): string
    {
        if ($set === null || !is_array($set)) {
            return '';
        }
        return $set['name'] ?? $set['id'] ?? '';
    }
}
