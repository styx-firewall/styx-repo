<?php
/**
 * Formatter for system applications page.
 * Prepares package rows for the template (status string, permissions).
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class SysAppsFormatter
{
    /**
     * Normalize packages data for presentation.
     *
     * @param array<string,mixed> $fmt_data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data, array $userCaps = []): array
    {
        $isAdmin = RoleHelper::hasCapability($userCaps, 'system:admin');

        $fmt_data['can_update'] = $isAdmin;
        $fmt_data['can_upgrade'] = $isAdmin;
        $fmt_data['can_install'] = $isAdmin;
        $fmt_data['can_remove'] = $isAdmin;

        $packages = $fmt_data['packages'] ?? [];
        $rows = [];
        foreach ($packages as $p) {
            $status = $p['status'] ?? '';
            if (is_array($status)) {
                $statusStr = implode(', ', $status);
            } else {
                $statusStr = (string)$status;
            }

            // Decide if the Remove action should be shown. Matches existing logic.
            $showRemove = ($statusStr !== '' && strpos($statusStr, 'deinstalled') !== 0);

            $rows[] = [
                'package' => $p['package'] ?? '',
                'version' => $p['version'] ?? '',
                'statusStr' => $statusStr,
                'show_remove' => $showRemove,
            ];
        }

        $fmt_data['packages_rows'] = $rows;

        // Format upgradable packages
        $upgPackages = $fmt_data['upgradable_packages'] ?? [];
        $upgRows = [];
        foreach ($upgPackages as $p) {
            $upgRows[] = [
                'name'       => $p['name'] ?? '',
                'archive'    => $p['archive'] ?? '',
                'version'    => $p['version'] ?? '',
                'arch'       => $p['arch'] ?? '',
                'old_version'=> $p['old_version'] ?? '',
            ];
        }
        $fmt_data['upgradable_rows'] = $upgRows;

        return $fmt_data;
    }
}
