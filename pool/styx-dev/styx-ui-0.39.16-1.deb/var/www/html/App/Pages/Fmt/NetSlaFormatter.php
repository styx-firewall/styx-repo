<?php
namespace App\Pages\Fmt;

class NetSlaFormatter
{
    /**
     * Normalize SLA page data for templates.
     *
     * @param array $fmt_data
     * @param array $response
     * @return array
     */
    public static function format(array $fmt_data, array $response): array
    {
        $data = $response['result'] ?? [];
        $ifaces = $data['ifaces_names'] ?? [];
        $monitors = $data['monitors'] ?? [];
        $addresses_host = $data['addresses_host'] ?? [];

        $fmt_data['ifaces_names'] = $ifaces;
        $fmt_data['monitors'] = [];
        $fmt_data['addresses_host'] = $addresses_host;

        if (!is_array($monitors)) {
            return $fmt_data;
        }

        foreach ($monitors as $m) {
            if (!is_array($m)) {
                $m = [];
            }
            $monitor = [];
            $monitor['id'] = $m['id'] ?? '';
            $monitor['name'] = $m['name'] ?? '';
            $monitor['protocol'] = $m['protocol'] ?? '';
            $monitor['target'] = $m['target'] ?? '';
            $monitor['interface'] = $m['interface'] ?? '';
            // Prefer a human-friendly interface name when available from gateway
            if (!empty($m['interface_config']) && is_array($m['interface_config'])) {
                $monitor['interface_display'] = $m['interface_config']['interface'] ?? $m['interface_config']['id'] ?? $monitor['interface'];
                // Use interface id as tooltip when available
                $monitor['interface_tooltip'] = $m['interface_config']['id'] ?? null;
            } else {
                $monitor['interface_display'] = $monitor['interface'];
                $monitor['interface_tooltip'] = null;
            }
            // Prefer a human-friendly target value when gateway returns target_set
            if (!empty($m['target_set']) && is_array($m['target_set'])) {
                // Prefer a readable name for display, use value_single for tooltip
                if (!empty($m['target_set']['name'])) {
                    $monitor['target_display'] = $m['target_set']['name'];
                } elseif (!empty($m['target_set']['value_single'])) {
                    $monitor['target_display'] = $m['target_set']['value_single'];
                } else {
                    $monitor['target_display'] = $m['target_set']['id'] ?? $monitor['target'];
                }
                $monitor['target_tooltip'] = $m['target_set']['value_single'] ?? null;
            } else {
                $monitor['target_display'] = $monitor['target'];
                $monitor['target_tooltip'] = null;
            }

            // interval in ms
            if (isset($m['interval_ms'])) {
                $monitor['interval_ms'] = (int)$m['interval_ms'];
            } elseif (isset($m['interval'])) {
                $monitor['interval_ms'] = (int)$m['interval'];
            } else {
                $monitor['interval_ms'] = 0;
            }

            if (isset($m['inactive_failures'])) {
                $monitor['inactive_failures'] = (int)$m['inactive_failures'];
            } else {
                $monitor['inactive_failures'] = 0;
            }

            if (isset($m['restore_success'])) {
                $monitor['restore_success'] = (int)$m['restore_success'];
            } else {
                $monitor['restore_success'] = 0;
            }
            $monitor['enabled'] = !empty($m['enabled']);

            // Extras as plain text array; template will render HTML/spacing
            $extras = [];
            if (($monitor['protocol'] ?? '') === 'ping') {
                if (isset($m['latency_threshold'])) {
                    $extras[] = 'Latency Threshold: ' . (int)$m['latency_threshold'] . 'ms';
                }
                if (isset($m['latency_strikes'])) {
                    $extras[] = 'Latency Strikes: ' . (int)$m['latency_strikes'];
                }
                if (isset($m['jitter_threshold'])) {
                    $extras[] = 'Jitter Threshold: ' . (int)$m['jitter_threshold'] . 'ms';
                }
                if (isset($m['jitter_strikes'])) {
                    $extras[] = 'Jitter Strikes: ' . (int)$m['jitter_strikes'];
                }
            }
            $monitor['extras'] = $extras;

            $fmt_data['monitors'][] = $monitor;
        }

        return $fmt_data;
    }
}
