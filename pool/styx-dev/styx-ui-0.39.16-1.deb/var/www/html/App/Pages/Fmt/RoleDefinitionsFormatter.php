<?php
/**
 * Formatter for role definitions page.
 * Pre-computes capability flags and marks builtin roles.
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class RoleDefinitionsFormatter
{
    /**
     * Prepare role definitions for template consumption.
     *
     * @param array<string,mixed> $fmt_data
     * @param string[] $userCaps
     * @param array<string,mixed> $features
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data, array $userCaps = [], array $features = []): array
    {
        $fmt_data['can_manage'] = RoleHelper::hasCapability($userCaps, 'users:admin');

        // Module → feature flag mapping. Modules not listed here are always shown.
        $moduleFeatures = [
            'ebpf'            => 'ebpf',
            'idsips'          => 'ids_ips',
            'packet_marking'  => 'packet_marking',
            'routing'         => ['frrouting', 'igmp_proxy'],
            'services'        => 'kea_dhcp4',
            'traffic_shaping' => 'tc',
            'vpn'             => 'vpn',
        ];

        // Group available capabilities by module prefix for checkbox UI
        $allCaps = $fmt_data['available_capabilities'] ?? [];
        $groupedCaps = [];
        foreach ($allCaps as $cap) {
            $parts = explode(':', $cap, 2);
            $module = $parts[0];
            $action = $parts[1] ?? '';
            if (!isset($groupedCaps[$module])) {
                $groupedCaps[$module] = [];
            }
            $groupedCaps[$module][] = [
                'full' => $cap,
                'action' => $action,
            ];
        }

        // Filter out modules whose feature is not enabled
        $filtered = [];
        foreach ($groupedCaps as $module => $caps) {
            $req = $moduleFeatures[$module] ?? null;
            if ($req === null) {
                // No feature gate  -  always visible
                $filtered[$module] = $caps;
                continue;
            }
            if (is_array($req)) {
                $hasFeature = false;
                foreach ($req as $f) {
                    if (!empty($features[$f])) {
                        $hasFeature = true;
                        break;
                    }
                }
            } else {
                $hasFeature = !empty($features[$req]);
            }
            if ($hasFeature) {
                $filtered[$module] = $caps;
            }
        }
        $fmt_data['capability_groups'] = $filtered;

        $defs = $fmt_data['role_definitions'] ?? [];
        $rows = [];
        foreach ($defs as $def) {
            $isBuiltin = !empty($def['builtin']);
            $caps = $def['capabilities'] ?? [];
            $rows[] = [
                'name'         => $def['name'] ?? '',
                'builtin'      => $isBuiltin,
                'capabilities' => is_array($caps) ? implode(', ', $caps) : (string)$caps,
                'caps_count'   => is_array($caps) ? count($caps) : 0,
                'caps_json'    => json_encode($caps, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            ];
        }

        $fmt_data['definition_rows'] = $rows;
        return $fmt_data;
    }
}
