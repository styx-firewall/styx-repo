<?php
/**
 * Formatter for Styx restart page.
 * Keeps page data consistent for template.
 */
namespace App\Pages\Fmt;

class StyxRestartFormatter
{
    /**
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        // Nothing complex required now, add placeholders for future use
        $fmt_data['confirm_message'] = $fmt_data['confirm_message'] ?? 'Are you sure you want to restart the gateway?';
        return $fmt_data;
    }
}
