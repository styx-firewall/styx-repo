<?php
/**
 * Formatter for net-iface page data.
 * DP: 20260310
 */
namespace App\Pages\Fmt;

class NetIfaceFormatter
{
    /**
     * Prepare presentation-ready keys used by the net-iface template.
     * Preserves existing semantics from the template's top block.
     *
     * @param array $fmt_data
     * @return array
     */
    public static function format(array $fmt_data): array
    {
        $t = $fmt_data;

        $action = $t['action'] ?? null;

        if ($action === 'create') {
            // For create the caller must provide the explicit subtype (e.g. bridge, vlan).
            $iface_subtype = $t['iface_subtype'] ?? '';
            // Broad type must be provided explicitly; if absent but subtype exists,
            // derive `virtual` to preserve semantic correctness.
            $iface_type = $t['iface_type'] ?? (!empty($iface_subtype) ? 'virtual' : '');
            $iface_config = [];
            $sysctl_keys = [];
            $iface_name = '';
            $iface_id = '';
        } else {
            // Require caller to supply a normalized `iface_config` and
            // `iface_sysctl_keys` directly in page_data.
            $iface_config = $t['iface_config'] ?? [];
            $sysctl_keys = $t['iface_sysctl_keys'] ?? [];

            // Keep `iface_type` as the broad category (virtual/physical) and
            // expose `iface_subtype` for specific virtual flavours (bridge, vlan...).
            if (($iface_config['type'] ?? '') === 'virtual') {
                $iface_type = 'virtual';
                $iface_subtype = $iface_config['subtype'] ?? '';
            } else {
                $iface_type = $iface_config['type'] ?? '';
                $iface_subtype = '';
            }
            $iface_name = $iface_config['interface'] ?? '';
            // canonical persistent identifier: use backend `id` only.
            $iface_id = $iface_config['id'] ?? '';
        }

        // Expect `interfaces` to be provided as a direct array of interface items
        // (current gateway shape). No legacy fallbacks.
        $interface_list = [];
        if (isset($t['interfaces']) && is_array($t['interfaces'])) {
            $interface_list = $t['interfaces'];
        }

        // normalize nested structures and defaults used by template
        $iface_config = is_array($iface_config) ? $iface_config : [];
        // ipv4/ipv6 must be arrays of string IDs (new API). Normalize strictly.
        $iface_config['ipv4'] = is_array($iface_config['ipv4'] ?? null)
            ? array_values(array_filter($iface_config['ipv4'], 'is_string'))
            : [];
        $iface_config['ipv6'] = is_array($iface_config['ipv6'] ?? null)
            ? array_values(array_filter($iface_config['ipv6'], 'is_string'))
            : [];

        // common optional fields
        $optionalFields = [
            'peer_name','mac','stp','forward_delay','primary_slave',
            'lacp_rate','miimon','updelay','downdelay','mru','service_name','ac_name',
            'lcp_echo_interval','lcp_echo_failure','idle','holdoff','maxfail','ipparam',
            'ttl',
        ];

        // VXLAN optional booleans
        if (!array_key_exists('nolearning', $iface_config)) {
            $iface_config['nolearning'] = true;
        }
        if (!array_key_exists('external', $iface_config)) {
            $iface_config['external'] = false;
        }
        if (!array_key_exists('vnifilter', $iface_config)) {
            $iface_config['vnifilter'] = false;
        }
        // Bridge VLAN filtering defaults to disabled
        if (!array_key_exists('vlan_filtering', $iface_config)) {
            $iface_config['vlan_filtering'] = false;
        }
        if (!array_key_exists('bridge_vlans', $iface_config)) {
            $iface_config['bridge_vlans'] = [];
        }
        foreach ($optionalFields as $fld) {
            if (!array_key_exists($fld, $iface_config)) {
                $iface_config[$fld] = '';
            }
        }

        // STP defaults to enabled when creating a bridge
        if ($action === 'create' && ($iface_subtype ?? '') === 'bridge') {
            $iface_config['stp'] = '1';
        }

        // VRF table_id: label UUID for routing_tables
        if (!array_key_exists('table_id', $iface_config)) {
            $iface_config['table_id'] = '';
        }

        // macvlan_mode default
        if (!array_key_exists('macvlan_mode', $iface_config)) {
            $iface_config['macvlan_mode'] = '';
        }

        // new optional booleans for interface-scoped services
        if (!array_key_exists('listen_ssh', $iface_config)) {
            $iface_config['listen_ssh'] = false;
        }
        if (!array_key_exists('listen_styx_ui', $iface_config)) {
            $iface_config['listen_styx_ui'] = false;
        }

        // normalize sysctl keys entries
        if (!is_array($sysctl_keys)) {
            $sysctl_keys = [];
        }

        foreach ($sysctl_keys as $k => $item) {
            if (!is_array($item)) {
                $item = [];
            }
            $item['sysctl_key'] = $item['sysctl_key'] ?? ($item['key'] ?? '');
            $item['key'] = $item['key'] ?? (string)$k;
            $item['value'] = $item['value'] ?? '';
            $item['default'] = $item['default'] ?? '-';
            $item['type'] = $item['type'] ?? ($item['input_type'] ?? 'string');
            $item['disabled'] = !empty($item['disabled']);
            $item['comment'] = $item['comment'] ?? '';
            // Mark when a non-trivial default differs from current value
            $has_default = ($item['default'] !== '-' && $item['default'] !== '');
            $item['differs'] = $has_default && ($item['value'] !== $item['default']);
            $sysctl_keys[$k] = $item;
        }
        if (!isset($iface_config['mtu'])) {
            if ($action === 'create') {
                // mtu default depends on PPPoE subtype when creating
                $iface_config['mtu'] = (($iface_subtype ?? '') === 'pppoe') ? '1492' : '1500';
            } else {
                $iface_config['mtu'] = '';
            }
        }

        $ip_mode = $iface_config['ip_mode'] ?? 'none';

        // Normalize selected address arrays for templates: always provide
        // a non-empty array so templates can iterate without defensive
        // checks. Elements may be IDs (new API) or legacy objects.
        $ipv4_selected = [];
        if (is_array($iface_config['ipv4'])) {
            $ipv4_selected = $iface_config['ipv4'];
        }
        if (empty($ipv4_selected)) {
            $ipv4_selected = [''];
        }

        $ipv6_selected = [];
        if (is_array($iface_config['ipv6'])) {
            $ipv6_selected = $iface_config['ipv6'];
        }
        if (empty($ipv6_selected)) {
            $ipv6_selected = [''];
        }

        $fmt_data['ipv4_selected'] = $ipv4_selected;
        $fmt_data['ipv6_selected'] = $ipv6_selected;
        $vlan_id = $iface_config['vlan_id_label'] ?? '';
        $role = $iface_config['role'] ?? '';
        $parent_iface = $iface_config['parent_iface'] ?? '';
        // Require backend `ports` key. No legacy fallbacks allowed per policy.
        if (!array_key_exists('ports', $iface_config)) {
            $bridge_ports = null;
        } else {
            $bridge_ports = $iface_config['ports'];
        }
        $bond_slaves = $iface_config['bond_slaves'] ?? $iface_config['slaves'] ?? '';
        $bond_mode = $iface_config['bond_mode'] ?? $iface_config['mode'] ?? '';
        $vrf_ports = $iface_config['vrf_ports'] ?? [];
        $dhcp_enabled = $iface_config['dhcp_enabled'] ?? false;
        $has_dhcp_options =
            !empty($iface_config['dhcp_range_start'] ?? '')
            || !empty($iface_config['dhcp_range_end'] ?? '')
            || !empty($iface_config['dhcp_netmask'] ?? '')
            || !empty($iface_config['dhcp_gateway'] ?? '')
            || !empty($iface_config['dhcp_dns'] ?? '');
        if ($has_dhcp_options) {
            $dhcp_enabled = true;
        }
        $dhcp_range_start = $iface_config['dhcp_range_start'] ?? '';
        $dhcp_range_end = $iface_config['dhcp_range_end'] ?? '';
        $dhcp_netmask = $iface_config['dhcp_netmask'] ?? '';
        $dhcp_gateway = $iface_config['dhcp_gateway'] ?? '';
        $dhcp_dns = $iface_config['dhcp_dns'] ?? '';

        // presentation helpers used by template (checked attributes, select options, etc.)
        if (!empty($iface_config['status']) && $iface_config['status'] === 'up') {
            $fmt_data['iface_status_checked'] = 'checked';
        } else {
            $fmt_data['iface_status_checked'] = '';
        }

        // presentation helpers for new checkboxes
        $ssh_list = $t['ssh_list'] ?? [];
        $styx_list = $t['styx_ui_list'] ?? [];
        if (!is_array($ssh_list)) {
            $ssh_list = [];
        }
        if (!is_array($styx_list)) {
            $styx_list = [];
        }

        // Determine service binding checkboxes strictly by `iface_id` membership.
        $fmt_data['listen_ssh_checked'] = '';
        $fmt_data['listen_styx_ui_checked'] = '';

        // Disable MAC field for physical interfaces on modify (MAC cannot be changed)
        $fmt_data['mac_disabled'] = ($action === 'modify' && in_array($iface_type, ['physical', 'physical_ethernet'], true));
        // Determine whether to show the MAC field based on interface type.
        $mac_types = ['physical', 'physical_ethernet', 'virtual_ethernet'];
        $mac_subtypes = ['vlan', 'bridge', 'bond', 'pppoe', 'veth', 'loopback', 'vxlan', 'vrf'];
        $fmt_data['show_mac'] = in_array($iface_type, $mac_types, true)
            || in_array($iface_subtype, $mac_subtypes, true);
        if (!empty($iface_id) && (is_string($iface_id) || is_numeric($iface_id))) {
            $fmt_data['listen_ssh_checked'] = in_array($iface_id, $ssh_list, true) ? 'checked' : '';
            $fmt_data['listen_styx_ui_checked'] = in_array($iface_id, $styx_list, true) ? 'checked' : '';
        }

        // normalize interface list to simple array of interfaces
        $normalized_iflist = [];
        foreach ($interface_list as $ifitem) {
            if (!is_array($ifitem)) {
                $normalized_iflist[] = ['interface' => (string)$ifitem, 'iface_id' => ''];
                continue;
            }
            $ifitem['interface'] = $ifitem['interface'] ?? '';
            $ifitem['missing'] = !empty($ifitem['missing']);
            // expose canonical `iface_id` using backend `id` (no fallbacks)
            $ifitem['iface_id'] = $ifitem['id'] ?? '';
            $normalized_iflist[] = $ifitem;
        }
        $interface_list = $normalized_iflist;

        // Prepare option structures for templates to consume
        // Use backend `id` as option value and show `interface` as label.
        $interface_options = [];
        foreach ($interface_list as $ifitem) {
            $iface_id_val = $ifitem['iface_id'] ?? $ifitem['id'] ?? '';
            $label = $ifitem['interface'] ?? $iface_id_val;
            $selected = ($parent_iface === $iface_id_val) || ($parent_iface === ($ifitem['interface'] ?? ''));
            $interface_options[] = [
                'value' => $iface_id_val,
                'label' => $label,
                'selected' => $selected,
            ];
        }

        // Selected arrays for bridge ports and bond slaves
        $selected_ports = [];
        if (is_array($bridge_ports)) {
            $selected_ports = $bridge_ports;
        } elseif (is_string($bridge_ports) && trim($bridge_ports) !== '') {
            $selected_ports = explode(' ', $bridge_ports);
        }

        $selected_slaves = [];
        if (is_array($bond_slaves)) {
            $selected_slaves = $bond_slaves;
        } elseif (is_string($bond_slaves) && trim($bond_slaves) !== '') {
            $selected_slaves = explode(' ', $bond_slaves);
        }

        $selected_vrf_ports = [];
        if (is_array($vrf_ports)) {
            $selected_vrf_ports = $vrf_ports;
        } elseif (is_string($vrf_ports) && trim($vrf_ports) !== '') {
            $selected_vrf_ports = explode(' ', $vrf_ports);
        }

        $bridge_ports_options = [];
        $bond_slaves_options = [];
        $vrf_ports_options = [];
        foreach ($interface_list as $ifitem) {
            $iface_id_val = $ifitem['iface_id'] ?? $ifitem['id'] ?? '';
            $label = $ifitem['interface'] ?? $iface_id_val;
            $bridge_selected = in_array($iface_id_val, $selected_ports, true) || in_array($ifitem['interface'] ?? '', $selected_ports, true);
            $bond_selected = in_array($iface_id_val, $selected_slaves, true) || in_array($ifitem['interface'] ?? '', $selected_slaves, true);
            $vrf_selected = in_array($iface_id_val, $selected_vrf_ports, true) || in_array($ifitem['interface'] ?? '', $selected_vrf_ports, true);
            $bridge_ports_options[] = [
                'value' => $iface_id_val,
                'label' => $label,
                'selected' => $bridge_selected,
            ];
            $bond_slaves_options[] = [
                'value' => $iface_id_val,
                'label' => $label,
                'selected' => $bond_selected,
            ];
            $vrf_ports_options[] = [
                'value' => $iface_id_val,
                'label' => $label,
                'selected' => $vrf_selected,
            ];
        }

        $has_interface_list = !empty($interface_options);
        $no_interfaces_msg = 'No interfaces available';

        // Pre-build HTML option strings to eliminate duplicate loops in the template.
        $interface_options_html = '';
        $bridge_ports_options_html = '';
        $bridge_ports_options_noselect_html = '';
        $bond_slaves_options_html = '';
        $bond_slaves_options_noselect_html = '';
        $vrf_ports_options_html = '';
        foreach ($interface_options as $opt) {
            $sel = !empty($opt['selected']) ? 'selected' : '';
            $dis = ($opt['value'] === '') ? 'disabled' : '';
            $tag = '<option value="' . $opt['value'] . '" ' . $sel . ' ' . $dis . '>' . $opt['label'] . '</option>';
            $interface_options_html .= $tag;
        }
        foreach ($bridge_ports_options as $opt) {
            $sel = !empty($opt['selected']) ? 'selected' : '';
            $dis = ($opt['value'] === '') ? 'disabled' : '';
            $tag = '<option value="' . $opt['value'] . '" ' . $sel . ' ' . $dis . '>' . $opt['label'] . '</option>';
            $bridge_ports_options_html .= $tag;
            // Without pre-computed selected (for bridge VLAN rows where selected is per-row)
            $tag_no_sel = '<option value="' . $opt['value'] . '" ' . $dis . '>' . $opt['label'] . '</option>';
            $bridge_ports_options_noselect_html .= $tag_no_sel;
        }
        foreach ($bond_slaves_options as $opt) {
            $sel = !empty($opt['selected']) ? 'selected' : '';
            $dis = ($opt['value'] === '') ? 'disabled' : '';
            $tag = '<option value="' . $opt['value'] . '" ' . $sel . ' ' . $dis . '>' . $opt['label'] . '</option>';
            $bond_slaves_options_html .= $tag;
        }
        foreach ($vrf_ports_options as $opt) {
            $sel = !empty($opt['selected']) ? 'selected' : '';
            $dis = ($opt['value'] === '') ? 'disabled' : '';
            $tag = '<option value="' . $opt['value'] . '" ' . $sel . ' ' . $dis . '>' . $opt['label'] . '</option>';
            $vrf_ports_options_html .= $tag;
        }

        // prepare bridge/bond select values as arrays of options for template loops
        $fmt_data['parent_iface'] = $parent_iface;
        $fmt_data['macvlan_mode'] = $iface_config['macvlan_mode'];
        $fmt_data['interface_list'] = $interface_list;
        $fmt_data['interface_options'] = $interface_options;
        $fmt_data['bridge_ports_options'] = $bridge_ports_options;
        $fmt_data['bond_slaves_options'] = $bond_slaves_options;
        $fmt_data['interface_options_html'] = $interface_options_html;
        $fmt_data['bridge_ports_options_html'] = $bridge_ports_options_html;
        $fmt_data['bond_slaves_options_noselect_html'] = $bond_slaves_options_noselect_html;
        $fmt_data['bond_slaves_options_html'] = $bond_slaves_options_html;
        $fmt_data['vrf_ports_options'] = $vrf_ports_options;
        $fmt_data['vrf_ports_options_html'] = $vrf_ports_options_html;
        $fmt_data['has_interface_list'] = $has_interface_list;
        $fmt_data['no_interfaces_msg'] = $no_interfaces_msg;

        // Bridge's own ports only (for per-port VLAN selector in edit mode).
        // The full $bridge_ports_options includes ALL interfaces; this subset
        // is limited to the interfaces actually assigned as ports of this bridge.
        $bridge_own_ports = $iface_config['ports'] ?? [];
        if (!is_array($bridge_own_ports)) {
            $bridge_own_ports = [];
        }
        $bridge_own_ports_options = [];
        $bridge_own_ports_options_html = '';
        foreach ($bridge_ports_options as $opt) {
            if ($opt['value'] !== '' && in_array($opt['value'], $bridge_own_ports, true)) {
                $bridge_own_ports_options[] = $opt;
                $bridge_own_ports_options_html .= '<option value="' . $opt['value'] . '">' . $opt['label'] . '</option>';
            }
        }
        $fmt_data['bridge_own_ports_options'] = $bridge_own_ports_options;
        $fmt_data['bridge_own_ports_options_html'] = $bridge_own_ports_options_html;

        // expose new names expected by updated templates
        $fmt_data['ports'] = $bridge_ports;
        $fmt_data['slaves'] = $bond_slaves;
        $fmt_data['vrf_ports'] = $vrf_ports;
        $fmt_data['mode'] = $bond_mode;
        $fmt_data['peer_name'] = $iface_config['peer_name'] ?? '';
        $fmt_data['pppoe'] = $iface_config['pppoe'] ?? [
            'username' => $iface_config['pppoe_user'] ?? $iface_config['pppoe_username'] ?? '',
            'password' => $iface_config['pppoe_pass'] ?? '',
            'service' => $iface_config['pppoe_service'] ?? $iface_config['service'] ?? '',
            'persist' => $iface_config['persist'] ?? null,
            'defaultroute' => $iface_config['defaultroute'] ?? null,
            'usepeerdns' => $iface_config['usepeerdns'] ?? null,
            'noauth' => $iface_config['noauth'] ?? null,
            'mru' => $iface_config['mru'] ?? null,
            'service_name' => $iface_config['service_name'] ?? null,
            'ac_name' => $iface_config['ac_name'] ?? null,
            'lcp_echo_interval' => $iface_config['lcp_echo_interval'] ?? null,
            'lcp_echo_failure' => $iface_config['lcp_echo_failure'] ?? null,
            'idle' => $iface_config['idle'] ?? null,
            'holdoff' => $iface_config['holdoff'] ?? null,
            'maxfail' => $iface_config['maxfail'] ?? null,
            'ipparam' => $iface_config['ipparam'] ?? null,
        ];

        // ensure presence of common simple keys for template
        $fmt_data['mtu_value'] = $iface_config['mtu'];
        $fmt_data['wifi_ssid'] = $iface_config['wifi_ssid'] ?? '';
        $fmt_data['wifi_pass'] = $iface_config['wifi_pass'] ?? '';

        // Inject all prepared keys back into page_data for the template to consume
        $fmt_data['action'] = $action;
        // Broad type (virtual/physical)
        $fmt_data['iface_type'] = $iface_type;
        // Specific subtype when iface_type is virtual (bridge, vlan, bond, ...)
        $fmt_data['iface_subtype'] = $iface_subtype ?? '';
        // expose normalized iface_config (no legacy iface_data preserved)
        $fmt_data['iface_config'] = $iface_config;

        // Expose resolved set objects from backend interface config (get_interface_config)
        $fmt_data['iface_config']['ipv4_resolved'] = $iface_config['ipv4_resolved'] ?? [];
        $fmt_data['iface_config']['ipv6_resolved'] = $iface_config['ipv6_resolved'] ?? [];
        $fmt_data['ipv4_resolved'] = $iface_config['ipv4_resolved'] ?? [];
        $fmt_data['ipv6_resolved'] = $iface_config['ipv6_resolved'] ?? [];

        $fmt_data['iface_name'] = $iface_name;
        $fmt_data['iface_id'] = $iface_id;
        $fmt_data['sysctl_keys'] = $sysctl_keys;
        $fmt_data['interface_list'] = $interface_list;
        $fmt_data['ip_mode'] = $ip_mode;
        $fmt_data['vlan_id'] = $vlan_id;
        $fmt_data['role'] = $role;
        $fmt_data['parent_iface'] = $parent_iface;

        // Backend returns vlan_id_display: { id, name, value }
        $vlan_label = $iface_config['vlan_id_display'] ?? null;
        $fmt_data['vlan_label'] = is_array($vlan_label) ? $vlan_label : null;

        // Resolve display fields for VTI / GRE / VXLAN picker pre-population.
        // Backend returns *_display objects matching { id, value, name } shape.
        $fmt_data['vlan_label'] = is_array($vlan_label) ? $vlan_label : null;
        $fmt_data['vti_local_display'] = is_array($iface_config['local_display'] ?? null) ? $iface_config['local_display'] : null;
        $fmt_data['vti_remote_display'] = is_array($iface_config['remote_display'] ?? null) ? $iface_config['remote_display'] : null;
        $fmt_data['vti_key_display'] = is_array($iface_config['key_display'] ?? null) ? $iface_config['key_display'] : null;
        $fmt_data['gre_local_display'] = is_array($iface_config['local_display'] ?? null) ? $iface_config['local_display'] : null;
        $fmt_data['gre_remote_display'] = is_array($iface_config['remote_display'] ?? null) ? $iface_config['remote_display'] : null;
        $fmt_data['gre_ikey_display'] = is_array($iface_config['ikey_display'] ?? null) ? $iface_config['ikey_display'] : null;
        $fmt_data['gre_okey_display'] = is_array($iface_config['okey_display'] ?? null) ? $iface_config['okey_display'] : null;
        $fmt_data['vxlan_vni_display'] = is_array($iface_config['vni_display'] ?? null) ? $iface_config['vni_display'] : null;
        $fmt_data['vxlan_local_ip_display'] = is_array($iface_config['local_ip_display'] ?? null) ? $iface_config['local_ip_display'] : null;
        $fmt_data['vxlan_dstport_display'] = is_array($iface_config['dstport_display'] ?? null) ? $iface_config['dstport_display'] : null;
        $fmt_data['xfrm_if_id_display'] = is_array($iface_config['if_id_display'] ?? null) ? $iface_config['if_id_display'] : null;
        $fmt_data['bridge_ports'] = $bridge_ports;
        $fmt_data['bond_slaves'] = $bond_slaves;
        $fmt_data['bond_mode'] = $bond_mode;
        $fmt_data['dhcp_enabled'] = $dhcp_enabled;
        $fmt_data['has_dhcp_options'] = $has_dhcp_options;
        $fmt_data['dhcp_range_start'] = $dhcp_range_start;
        $fmt_data['dhcp_range_end'] = $dhcp_range_end;
        $fmt_data['dhcp_netmask'] = $dhcp_netmask;
        $fmt_data['dhcp_gateway'] = $dhcp_gateway;
        $fmt_data['dhcp_dns'] = $dhcp_dns;
        $fmt_data['iface_config'] = $iface_config;

        return $fmt_data;
    }
}
