<?php
namespace App\Pages\Fmt;

/**
 * Minimal formatter for TC config page.
 * Produces HTML rows for qdiscs and channels and select options for qdiscs that support classes.
 */
class TsTcConfigFormatter
{
    /**
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $tc_config = $fmt_data['tc_config'] ?? [];

        // preserve backend keys and display labels in UPPERCASE (no other changes)
        $tc_qdiscs = [];
        foreach ((array)$fmt_data['tc_valid_qdisc'] as $kind) {
            if (!is_string($kind)) continue;
            $tc_qdiscs[$kind] = strtoupper($kind);
        }

        $qdisc_with_classes = ['htb', 'hfsc', 'prio'];

        // Collect per-interface warnings from backend data (keyed by UUID)
        $iface_warnings = [];
        foreach ($tc_config as $iface_uuid => $qconf) {
            if (!empty($qconf['warnings']) && is_array($qconf['warnings'])) {
                $iface_warnings[$iface_uuid] = $qconf['warnings'];
            }
        }

        // Merge command-level warnings (from $fmt_data['tc_warnings'])
        $cmd_warnings = $fmt_data['tc_warnings'] ?? [];

        /**
         * Build warning icon HTML for a row's warnings.
         */
        $buildWarnHtml = function (array $warnings): string {
            if (empty($warnings)) {
                return '';
            }
            $titles = [];
            foreach ($warnings as $w) {
                $titles[] = is_string($w) ? $w : ($w['msg'] ?? '');
            }
            $title = implode('; ', array_filter($titles));
            if ($title === '') {
                return '';
            }
            return '<span class="tc-warning-container" title="' . $title . '">'
                . '<svg class="tc-warning-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="16" height="16">'
                . '<polygon points="10,2 19,18 1,18" fill="#FFD600" stroke="#d00" stroke-width="1.5"/>'
                . '<rect x="9" y="7" width="2" height="6" rx="1" fill="#d00"/>'
                . '<circle cx="10" cy="15.5" r="1" fill="#d00"/>'
                . '</svg></span>';
        };

        $qdiscs_data = [];
        $channels_data = [];
        $qdisc_select_options = [];

        foreach ($tc_config as $iface_uuid => $qconf) {
            $iface_name = $qconf['interface_name'] ?? $iface_uuid;
            // Warnings for this interface (from backend per-interface data)
            $warnings = $iface_warnings[$iface_uuid] ?? [];

            // qdiscs table data
            if (!empty($qconf['qdiscs']) && is_array($qconf['qdiscs'])) {
                foreach ($qconf['qdiscs'] as $qdisc) {
                    $handle = $qdisc['handle'] ?? '';
                    $kind = $qdisc['kind'] ?? '';
                    $kind_label = $tc_qdiscs[$kind] ?? strtoupper($kind);

                    // build options string
                    $paramParts = [];
                    if (!empty($qdisc['options']) && is_array($qdisc['options'])) {
                        foreach ($qdisc['options'] as $k => $v) {
                            if (is_array($v)) {
                                $v = json_encode($v);
                            } elseif (is_bool($v)) {
                                $v = $v ? 'true' : 'false';
                            }
                            $paramParts[] = $k . ': ' . $v;
                        }
                    }
                    $params_str = implode(', ', $paramParts);

                    $qdiscs_data[] = [
                        'interface_uuid' => $iface_uuid,
                        'interface_name' => $iface_name,
                        'handle' => $handle,
                        'kind_label' => $kind_label,
                        'kind' => $kind,
                        'params' => $params_str,
                        'warn_html' => $buildWarnHtml($warnings),
                    ];
                }
            }

            // channels (classes) data
            if (!empty($qconf['classes']) && is_array($qconf['classes'])) {
                foreach ($qconf['classes'] as $ch) {
                    $cname = $ch['name'] ?? $ch['classname'] ?? '';
                    $ctype = $ch['class'] ?? '';
                    $handle = $ch['handle'] ?? '';
                    $parent = (isset($ch['root']) && $ch['root']) ? 'root' : ($ch['parent'] ?? '');

                    $params = [];
                    foreach (['rate', 'ceil', 'burst', 'cburst', 'prio', 'qdisc_iface'] as $paramKey) {
                        if (isset($ch[$paramKey])) {
                            $val = is_bool($ch[$paramKey]) ? ($ch[$paramKey] ? 'true' : 'false') : $ch[$paramKey];
                            $params[] = $paramKey . ': ' . $val;
                        }
                    }
                    $params_str = implode(', ', $params);

                    $channels_data[] = [
                        'classname' => $cname,
                        'interface_uuid' => $iface_uuid,
                        'interface_name' => $iface_name,
                        'class_type' => $ctype,
                        'handle' => $handle,
                        'parent' => $parent,
                        'params' => $params_str,
                        'id' => $ch['id'] ?? ($ch['handle'] ?? ''),
                        'warn_html' => $buildWarnHtml($warnings),
                    ];
                }
            }

            // select options for add-channel form: only qdiscs that support classes
            if (!empty($qconf['qdiscs']) && isset($qconf['qdiscs'][0]['kind'])) {
                $kind = $qconf['qdiscs'][0]['kind'];
                if (in_array($kind, $qdisc_with_classes, true)) {
                    $kind_label = $tc_qdiscs[$kind] ?? strtoupper($kind);
                    $qdisc_select_options[] = [
                        'value' => $iface_uuid . '|' . $kind,
                        'label' => $kind_label . ' on ' . $iface_name
                    ];
                }
            }
        }

        $fmt_data['tc_qdiscs'] = $tc_qdiscs;
        $fmt_data['qdisc_with_classes'] = $qdisc_with_classes;
        $fmt_data['qdiscs_data'] = $qdiscs_data;
        $fmt_data['channels_data'] = $channels_data;
        $fmt_data['qdisc_select_options'] = $qdisc_select_options;
        $fmt_data['cmd_warnings'] = $cmd_warnings;

        return $fmt_data;
    }
}
