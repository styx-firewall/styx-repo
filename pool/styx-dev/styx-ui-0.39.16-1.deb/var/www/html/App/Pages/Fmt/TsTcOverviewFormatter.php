<?php
namespace App\Pages\Fmt;

use App\Helpers\FormatHelper;

/**
 * Minimal formatter for the TC overview page.
 * Moves recursive link/row building out of the template.
 */
class TsTcOverviewFormatter
{
    /**
     * Recursively sum the 'packets' stat across all descendants.
     *
     * @param array<int,array<string,mixed>> $children
     * @return int
     */
    private static function sumDescendantPackets(array $children): int
    {
        $total = 0;
        foreach ($children as $child) {
            $total += (int)($child['stats']['packets'] ?? 0);
            if (!empty($child['children'])) {
                $total += self::sumDescendantPackets($child['children']);
            }
        }
        return $total;
    }

    /**
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $tc_stats = $fmt_data['tc_stats'] ?? [];
        $out = [];

        $makeLabel = function(array $child) {
            if (isset($child['name'])) {
                return $child['name'];
            }
            if (!empty($child['type']) && $child['type'] === 'tin') {
                $id = $child['tin'] ?? $child['id'] ?? '';
                return 'Tin ' . $id;
            }
            if (!empty($child['type']) && $child['type'] === 'band') {
                $id = $child['band'] ?? $child['id'] ?? '';
                return 'Band ' . $id;
            }
            return $child['id'] ?? '';
        };

        $buildLinks = function($parentLabel, $children) use (&$buildLinks, $makeLabel) {
            $links = [];
            foreach ($children as $child) {
                $packets = $child['stats']['packets'] ?? 0;
                $drops = $child['stats']['drops'] ?? 0;
                $qlen = $child['stats']['q_len'] ?? 0;

                // Skip zero-traffic leaf children in the Sankey diagram.
                // They still appear in the stats table via buildStatsRowsHtml.
                if ($packets == 0 && empty($child['children'])) {
                    continue;
                }

                $label = $makeLabel($child);
                $links[] = [$parentLabel, $label, $packets];
                $output = max(0, $packets - $drops);
                $links[] = [$label, 'OUTPUT', $output];
                if ($drops > 0) $links[] = [$label, 'DROP', $drops];
                if ($qlen > 0) $links[] = ['QUEUE', $label, $qlen];
                if (!empty($child['children'])) {
                    $links = array_merge($links, $buildLinks($label, $child['children']));
                }
            }
            return $links;
        };

        $buildStatsRowsHtml = function($children, $level = 0) use (&$buildStatsRowsHtml) {
            $html = '';
            foreach ($children as $child) {
                $padding = $level * 18;
                $name = '';
                if (!empty($child['type']) && $child['type'] === 'tin') {
                    $name = 'Tin ' . ($child['tin'] ?? '');
                } elseif (!empty($child['type']) && $child['type'] === 'band') {
                    $name = 'Band ' . ($child['band'] ?? '');
                } else {
                    $name = $child['name'] ?? ($child['id'] ?? '');
                }
                $bytes = isset($child['stats']['bytes']) ? FormatHelper::formatBytes((int)$child['stats']['bytes']) : '-';
                $packets = $child['stats']['packets'] ?? '-';
                $drops = $child['stats']['drops'] ?? '-';
                $overlimits = $child['stats']['overlimits'] ?? '-';
                $backlog = isset($child['stats']['backlog']) ? FormatHelper::formatBytes((int)$child['stats']['backlog']) : '-';
                $q_len = $child['stats']['q_len'] ?? '-';

                $html .= '<tr>';
                $html .= '<td style="padding-left:' . $padding . 'px">' . $name . '</td>';
                $html .= '<td style="text-align:left;">' . (string)$bytes . '</td>';
                $html .= '<td style="text-align:left;">' . (string)$packets . '</td>';
                $html .= '<td style="text-align:left;">' . (string)$drops . '</td>';
                $html .= '<td style="text-align:left;">' . (string)$overlimits . '</td>';
                $html .= '<td style="text-align:left;">' . (string)$backlog . '</td>';
                $html .= '<td style="text-align:left;">' . (string)$q_len . '</td>';
                $html .= '</tr>';

                if (!empty($child['children'])) {
                    $html .= $buildStatsRowsHtml($child['children'], $level + 1);
                }
            }
            return $html;
        };

        foreach ($tc_stats as $iface => $data) {
            // Skip any non-interface entries (e.g. informational keys like 'msg')
            if (!is_array($data) || !isset($data['stats'])) {
                continue;
            }
            $entry = [];
            $id_root = ($data['id_root'] ?? '') === '1:' ? '1:0' : ($data['id_root'] ?? '');
            $qdisc_label = strtoupper($data['qdisc'] ?? '') . ' (' . $id_root . ')';
            if (strpos($iface, '_ingress') !== false) {
                $iface_label = str_replace('_ingress', '', $iface) . ' (ingress)';
            } else {
                $iface_label = $iface;
            }
            $div_id = 'sankey_tc_' . $iface;

            $flows = [];
            $packets = $data['stats']['packets'] ?? 0;
            $drops = $data['stats']['drops'] ?? 0;
            $q_len = $data['stats']['q_len'] ?? 0;

            if (!empty($data['children'])) {
                $childrenPackets = self::sumDescendantPackets($data['children']);
                if ($childrenPackets > 0) {
                    $flows[] = [$iface_label, $qdisc_label, $packets];
                    $flows = array_merge($flows, $buildLinks($qdisc_label, $data['children']));
                    // Flow conservation: residual traffic that stayed on root
                    $residual = $packets - $childrenPackets;
                    if ($residual > 0) {
                        $flows[] = [$qdisc_label, 'OUTPUT', $residual];
                    }
                } else {
                    // Children exist but have zero traffic - treat as leaf
                    $output = max(0, $packets - $drops);
                    $flows[] = [$iface_label, $qdisc_label, $packets];
                    $flows[] = [$qdisc_label, 'OUTPUT', $output];
                    if ($drops > 0) {
                        $flows[] = [$qdisc_label, 'DROP', $drops];
                    }
                    if ($q_len > 0) {
                        $flows[] = ['QUEUE', $qdisc_label, $q_len];
                    }
                }
            } else {
                $output = max(0, $packets - $drops);
                $flows[] = [$iface_label, $qdisc_label, $packets];
                $flows[] = [$qdisc_label, 'OUTPUT', $output];
                if ($drops > 0) {
                    $flows[] = [$qdisc_label, 'DROP', $drops];
                }
                if ($q_len > 0) {
                    $flows[] = ['QUEUE', $qdisc_label, $q_len];
                }
            }

            $entry['div_id'] = $div_id;
            $entry['iface_label'] = $iface_label;
            $entry['qdisc_label'] = $qdisc_label;
            $entry['flows_json'] = json_encode($flows, JSON_UNESCAPED_UNICODE);

            // Pre-format root stats bytes/backlog for template display
            $raw_stats = $data['stats'] ?? [];
            $entry['root_stats'] = [
                'qdisc' => $raw_stats['qdisc'] ?? '',
                'bytes_formatted' => isset($raw_stats['bytes']) ? FormatHelper::formatBytes((int)$raw_stats['bytes']) : '-',
                'packets' => $raw_stats['packets'] ?? '-',
                'drops' => $raw_stats['drops'] ?? '-',
                'overlimits' => $raw_stats['overlimits'] ?? '-',
                'backlog_formatted' => isset($raw_stats['backlog']) ? FormatHelper::formatBytes((int)$raw_stats['backlog']) : '-',
                'q_len' => $raw_stats['q_len'] ?? '-',
            ];

            $entry['stats_rows_html'] = !empty($data['children']) ? $buildStatsRowsHtml($data['children']) : '';

            $out[$iface] = $entry;
        }

        $fmt_data['tc_stats_formatted'] = $out;
        return $fmt_data;
    }
}
