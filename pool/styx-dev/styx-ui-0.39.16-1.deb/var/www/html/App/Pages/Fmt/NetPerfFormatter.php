<?php
namespace App\Pages\Fmt;

class NetPerfFormatter
{
    /**
     * Prepare presentation keys for net-perf page.
     * @param array $fmt_data
     * @param array|null $response
     * @return array
     */
    public static function format(array $fmt_data, ?array $response = null): array
    {
        $server_status = $response['server_status'] ?? null;

        $fmt_data['server'] = [
            'running' => $server_status['running'] ?? false,
            'pid' => $server_status['pid'] ?? null,
            'port' => $server_status['port'] ?? null,
            'started_at' => $server_status['started_at'] ?? null,
        ];

        return $fmt_data;
    }
}
