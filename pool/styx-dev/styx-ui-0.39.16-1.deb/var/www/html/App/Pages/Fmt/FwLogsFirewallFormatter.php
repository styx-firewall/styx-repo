<?php
namespace App\Pages\Fmt;

class FwLogsFirewallFormatter
{
    /**
     * Prepare columns configuration for the unified firewall logs page.
     * @param array $fmt_data
     * @return array
     */
    public static function format(array $fmt_data): array
    {
        $columnsByTab = [
            'local' => [
                ['key' => 'timestamp', 'label' => 'Timestamp'],
                ['key' => 'rule', 'label' => 'Rule Name'],
                ['key' => 'src_ip', 'label' => 'Source IP'],
                ['key' => 'src_port', 'label' => 'Source Port'],
                ['key' => 'dest_ip', 'label' => 'Destination IP'],
                ['key' => 'dest_port', 'label' => 'Destination Port'],
                ['key' => 'protocol', 'label' => 'Protocol'],
                ['key' => 'iface_in', 'label' => 'Iface In'],
                ['key' => 'iface_out', 'label' => 'Iface Out'],
                ['key' => 'action', 'label' => 'Action'],
                ['key' => 'tcp.flags', 'label' => 'TCP Flags'],
                ['key' => 'uuid', 'label' => 'UUID'],
            ],
            'prerouting' => [
                ['key' => 'timestamp', 'label' => 'Timestamp'],
                ['key' => 'src_ip', 'label' => 'Source IP'],
                ['key' => 'dest_ip', 'label' => 'Destination IP'],
                ['key' => 'protocol', 'label' => 'Protocol'],
                ['key' => 'iface_in', 'label' => 'Iface In'],
                ['key' => 'iface_out', 'label' => 'Iface Out'],
                ['key' => 'action', 'label' => 'Action'],
                ['key' => 'tcp.flags', 'label' => 'TCP Flags'],
                ['key' => 'uuid', 'label' => 'UUID'],
            ],
            'postrouting' => [
                ['key' => 'timestamp', 'label' => 'Timestamp'],
                ['key' => 'src_ip', 'label' => 'Source IP'],
                ['key' => 'dest_ip', 'label' => 'Destination IP'],
                ['key' => 'protocol', 'label' => 'Protocol'],
                ['key' => 'iface_in', 'label' => 'Iface In'],
                ['key' => 'iface_out', 'label' => 'Iface Out'],
                ['key' => 'action', 'label' => 'Action'],
                ['key' => 'tcp.flags', 'label' => 'TCP Flags'],
                ['key' => 'uuid', 'label' => 'UUID'],
            ],
            'prepost' => [
                ['key' => 'timestamp', 'label' => 'Timestamp'],
                ['key' => 'hook_name', 'label' => 'Hook'],
                ['key' => 'src_ip', 'label' => 'Source IP'],
                ['key' => 'dest_ip', 'label' => 'Destination IP'],
                ['key' => 'protocol', 'label' => 'Protocol'],
                ['key' => 'iface_in', 'label' => 'Iface In'],
                ['key' => 'iface_out', 'label' => 'Iface Out'],
                ['key' => 'action', 'label' => 'Action'],
                ['key' => 'tcp.flags', 'label' => 'TCP Flags'],
                ['key' => 'uuid', 'label' => 'UUID'],
            ],
            'forward' => [
                ['key' => 'timestamp', 'label' => 'Timestamp'],
                ['key' => 'rule', 'label' => 'Rule Name'],
                ['key' => 'src_ip', 'label' => 'Source IP'],
                ['key' => 'src_port', 'label' => 'Source Port'],
                ['key' => 'dest_ip', 'label' => 'Destination IP'],
                ['key' => 'dest_port', 'label' => 'Destination Port'],
                ['key' => 'protocol', 'label' => 'Protocol'],
                ['key' => 'hook_name', 'label' => 'Hook'],
                ['key' => 'iface_in', 'label' => 'Iface In'],
                ['key' => 'iface_out', 'label' => 'Iface Out'],
                ['key' => 'action', 'label' => 'Action'],
                ['key' => 'tcp.flags', 'label' => 'TCP Flags'],
                ['key' => 'uuid', 'label' => 'UUID'],
            ],
        ];

        $fmt_data['fw_logs_columns_by_tab'] = $columnsByTab;

        $fmt_data['fw_logs_columns_by_tab_json'] = json_encode(
            $columnsByTab,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
        );

        return $fmt_data;
    }
}
