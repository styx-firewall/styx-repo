<?php
/**
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Services\GatewayService;
use App\Pages\Fmt\DashboardFormatter;

class PageDashboard
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'dash-charts',
        ];
        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'dashboard';
        }

        $page['web_main']['footer_script'][] = ['src' =>  '/scripts/thirdparty/chart.js'];
        $page['web_main']['footer_script'][] = ['src' =>  '/scripts/charts-core/reusable-charts.js'];

        $page['page'] = $section;

        if($section == 'dashboard') {
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/thirdparty/muuri.min.js'];
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/charts-core/dashboard-widgets.js'];
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/charts-core/dashboard.js'];
            $fmt = DashboardFormatter::format([
                'version' => $cfg->get('app.version'),
            ]);
        } else if ($section == 'dash-charts') {
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/charts-core/dash-charts.js'];
            $fmt = DashboardFormatter::format([]);
        }


        $page['load_tpl'][] = PageHead::get($ctx);
        $page['page_data'] = $fmt;
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar',
        ];

        return $page;
    }
}
