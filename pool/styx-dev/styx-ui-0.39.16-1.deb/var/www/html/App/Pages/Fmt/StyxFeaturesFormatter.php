<?php
/**
 * Formatter for Styx features page.
 * Moves presentation formatting out of the template.
 */
namespace App\Pages\Fmt;

class StyxFeaturesFormatter
{
    /**
     * Normalize features structure for the template and JS.
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $features = $fmt_data['features'] ?? [];
        $out = [];

        foreach ($features as $f) {
            $feature = [];
            // Accept either 'name' or 'title' from backend for human label
            $feature['key'] = $f['key'] ?? ($f['name'] ?? ($f['title'] ?? ''));
            $feature['name'] = $f['name'] ?? ($f['title'] ?? $feature['key']);
            $feature['visible'] = isset($f['visible']) ? (bool)$f['visible'] : true;
            // Default enabled to false unless explicitly provided as true
            $feature['enabled'] = array_key_exists('enabled', $f) ? (bool)$f['enabled'] : false;
            $feature['options_model'] = $f['options_model'] ?? 'single';

            $opts = [];
            $anyOptionSelected = false;
            foreach ($f['options'] ?? [] as $opt) {
                $o = [];
                $o['key'] = $opt['key'] ?? ($opt['name'] ?? '');
                // Accept 'name' or 'title' for option labels
                $o['name'] = $opt['name'] ?? ($opt['title'] ?? $o['key']);
                $o['selected'] = !empty($opt['selected']);
                if ($o['selected']) $anyOptionSelected = true;
                // Default option enabled to false unless explicitly true
                $o['enabled'] = array_key_exists('enabled', $opt) ? (bool)$opt['enabled'] : false;
                $o['description'] = $opt['description'] ?? ($opt['title'] ?? '');
                $o['packages'] = is_array($opt['packages'] ?? null) ? $opt['packages'] : [];
                $o['packages_shared'] = is_array($opt['packages_shared'] ?? null) ? $opt['packages_shared'] : [];

                // Presentation helpers for template
                $o['checked'] = (bool)$o['selected'];
                $o['checked_attr'] = $o['checked'] ? 'checked' : '';
                $o['disabled'] = !$o['enabled'];
                $o['disabled_attr'] = $o['disabled'] ? 'disabled' : '';
                $opts[] = $o;
            }

            // If feature selection wasn't explicitly set, derive it from options
            if (isset($f['selected'])) {
                $feature['selected'] = (bool)$f['selected'];
            } else {
                $feature['selected'] = $anyOptionSelected;
            }

            // Presentation helpers for template
            $feature['checked'] = (bool)$feature['selected'];
            $feature['checked_attr'] = $feature['checked'] ? 'checked' : '';
            $feature['disabled'] = !$feature['enabled'];
            $feature['disabled_attr'] = $feature['disabled'] ? 'disabled' : '';
            $feature['fieldset_class'] = $feature['selected'] ? '' : 'hidden';
            $feature['input_type'] = ($feature['options_model'] === 'multiple') ? 'checkbox' : 'radio';
            if ($feature['input_type'] === 'checkbox') {
                $feature['input_name'] = $feature['key'] . '_option[]';
            } else {
                $feature['input_name'] = $feature['key'] . '_option';
            }

            $feature['options'] = $opts;
            $out[] = $feature;
        }

        $fmt_data['features'] = $out;
        // Precompute a JSON representation for safe injection into JS in the template.
        // Use JSON_HEX_* flags to reduce XSS risk when embedding into HTML contexts.
        $fmt_data['features_json'] = json_encode(
            $out,
            JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        return $fmt_data;
    }
}
