<?php
/**
 * Formatter for Styx backups page.
 * Returns a simple list of backup type strings (fixed values).
 */
namespace App\Pages\Fmt;

class StyxBackupsFormatter
{
    /**
     * Ensure backup page data contains `backup_types` as a simple array of strings.
     *
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        // Ensure `backup_types` exists and is an array. Page should populate it.
        if (!isset($fmt_data['backup_types']) || !is_array($fmt_data['backup_types'])) {
            $fmt_data['backup_types'] = [];
        }

        return $fmt_data;
    }
}
