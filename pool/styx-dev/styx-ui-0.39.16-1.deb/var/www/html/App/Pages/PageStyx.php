<?php
/**
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Controllers\Request\StyxRequestController;
use App\Pages\Fmt\StyxEventsFormatter;
use App\Pages\Fmt\StyxFeaturesFormatter;
use App\Pages\Fmt\StyxSettingsFormatter;
use App\Constants\LogLevel;
use App\Services\LogSystemService;
use App\Pages\Fmt\StyxBackupsFormatter;
use App\Pages\Fmt\StyxLogsFormatter;
use App\Pages\Fmt\StyxRestartFormatter;
use App\Services\AuthService;
use App\Helpers\RoleHelper;

class PageStyx
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);
        $logSystem = $ctx->get(LogSystemService::class);

        $sections_array = [
            'styx-features',
            'styx-events',
            'styx-logs',
            'styx-backups',
            'styx-restart',
            'styx-licence',
        ];

        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'styx-settings';
        }

        if ($section == 'styx-settings') {
            $styxController = new StyxRequestController($ctx);
            $response = $styxController->getStyxSettings();
            $status = $response['status'] ?? 'error';
            if ($status === 'success' || $status === 'partial') {
                $fmt_data = $response['result'];
                $fmt_data['loglevel'] = LogLevel::getConstants();
                // Normalize styx settings for template convenience
                $fmt = StyxSettingsFormatter::format($fmt_data);
                if (!empty($response['response_msg'])) {
                    $fmt['response_msg'] = $response['response_msg'];
                }
                if (!empty($response['warnings'])) {
                    $fmt['warnings'] = $response['warnings'];
                }
            } else {
                $logSystem->error('Error getting Styx service settings: ' . ($response['response_msg'] ?? 'unknown'));
                $fmt = [
                    'error' => $response['response_msg'] ?? 'Failed to load Styx settings',
                ];
            }
        }

        if ($section === 'styx-events') {
            $styxController = new StyxRequestController($ctx);
            $filters = [];
            $level = Filter::getInt('level');
            if ($level !== null) {
                $filters['level'] = $level;
            }
            $limit = Filter::getInt('limit');
            if ($limit !== null) {
                $filters['limit'] = $limit;
            }

            $search = Filter::getString('search', 128);
            if (!empty($search)) {
                $filters['message_contains'] = $search;
            }
            $eventsResp = $styxController->getEvents($filters);
            $fmt_data = [];
            if (($eventsResp['status'] ?? '') === 'success') {
                $fmt_data['events'] = $eventsResp['result']['events'] ?? [];
            } else {
                $fmt_data['events'] = [];
                // Expose backend error message to template
                $fmt_data['error'] = $eventsResp['response_msg'] ?? '';
                if (isset($eventsResp['warnings']) && is_array($eventsResp['warnings'])) {
                    foreach ($eventsResp['warnings'] as $warn) {
                        $fmt_data['error'] .= ' Warning: ' . $warn;
                    }
                }
            }

            $fmt_data['filters'] = [
                'level' => $level,
                'limit' => $limit,
                'search' => $search
            ];

            $fmt_data['loglevel'] = LogLevel::getConstants();
            $fmt = StyxEventsFormatter::format($ctx, $fmt_data);
        }

        if ($section === 'styx-logs') {
            // Prepare filters from request for logs page
            $level = Filter::getString('level');
            $limit = Filter::getInt('limit');
            $fmt_data = [
                'filters' => [
                    'level' => $level ?? '',
                    'limit' => $limit ?? 50,
                ],
                'levels' => ['DEBUG','INFO','NOTICE','WARNING','ERROR','CRITICAL','ALERT','EMERGENCY'],
            ];
            $fmt = StyxLogsFormatter::format($fmt_data);
        }

        if ($section === 'styx-features') {
            $styxController = new StyxRequestController($ctx);
            $response = $styxController->getStyxFeaturesFull();
            $fmt_data = [];
            $status = $response['status'] ?? 'error';
            if ($status === 'success' || $status === 'partial') {
                $fmt_data['features'] = $response['result']['features'] ?? [];
                if (!empty($response['warnings'])) {
                    $fmt_data['warnings'] = $response['warnings'];
                }
            } else {
                $logSystem->error('Error getting Styx features: ' . ($response['response_msg'] ?? 'unknown'));
                $fmt_data['error'] = $response['response_msg'] ?? 'Failed to load Styx features';
                $fmt_data['features'] = [];
            }
            $fmt = StyxFeaturesFormatter::format($fmt_data);
        }

        if ($section === 'styx-backups') {
            $styxController = new StyxRequestController($ctx);
            $resp = $styxController->getStyxBackupTypes();
            $fmt_data = [];
            $status = $resp['status'] ?? 'error';
            if ($status === 'success' || $status === 'partial') {
                $fmt_data = $resp['result'] ?? [];
                if (!empty($resp['warnings'])) {
                    $fmt_data['warnings'] = $resp['warnings'];
                }
            } else {
                $logSystem->error('Error getting Styx backup types: ' . ($resp['response_msg'] ?? 'unknown'));
                $fmt_data['error'] = $resp['response_msg'] ?? 'Failed to load backup types';
            }
            $fmt = StyxBackupsFormatter::format($fmt_data);

            $auth = $ctx->get(AuthService::class);
            $fmt['can_restore'] = RoleHelper::hasCapability(
                $auth->getCapabilities(), 'styx:admin'
            );
        }

        if ($section === 'styx-restart') {
            $fmt = StyxRestartFormatter::format([]);

            $auth = $ctx->get(AuthService::class);
            $fmt['can_restart_gateway'] = RoleHelper::hasCapability(
                $auth->getCapabilities(), 'styx:admin'
            );
        }

        if ($section === 'styx-licence') {
            $license_text = '';
            $license_file = __DIR__ . '/../../LICENSE.md';
            if (file_exists($license_file)) {
                $license_text = trim(file_get_contents($license_file));
            } else {
                $license_text = 'License file not found.';
            }
            $fmt = ['license_text' => $license_text];
        }

        switch ($section) {
            case 'styx-restart':
                $page['web_main']['footer_script'][] = ['src' => '/scripts/styx/styx-restart.js'];
                break;
            case 'styx-features':
                $page['web_main']['footer_script'][] = ['src' => '/scripts/styx/styx-features.js'];
                break;
            case 'styx-backups':
                $page['web_main']['footer_script'][] = ['src' => '/scripts/styx/styx-backups.js'];
                break;
            case 'styx-events':
                $page['web_main']['footer_script'][] = ['src' => '/scripts/styx/styx-events.js'];
                break;
            case 'styx-logs':
                $page['web_main']['scriptlink'][] = '/scripts/core/state-storage.js';
                $page['web_main']['footer_script'][] = ['src' => '/scripts/logs/logs-parser.js'];
                break;
            case 'styx-settings':
                $page['web_main']['footer_script'][] = ['src' => '/scripts/styx/styx-settings.js'];
                break;
            case 'styx-licence':
                break;
        }

        $page['page'] = $section;
        $page['page_data'] = $fmt ?? [];
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }
}
