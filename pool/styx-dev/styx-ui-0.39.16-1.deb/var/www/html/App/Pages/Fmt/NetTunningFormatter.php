<?php
namespace App\Pages\Fmt;

class NetTunningFormatter
{
    /**
     * Prepare presentation-ready keys for net-tunning page.
     * Preserves existing semantics from previous PageNetwork logic.
     *
     * @param array $fmt_data
     * @param array $response
     * @return array
     */
    public static function format(array $fmt_data, array $response): array
    {
        $fmt_data['predefined'] = $response['predefined'] ?? [];
        $fmt_data['custom'] = $response['custom'] ?? [];

        return $fmt_data;
    }
}
