<?php

/**
 * Handle Gateway request, abstract Gateway Service from Socket mechanism
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 * v1.0
 */

/*
    Backend response format:
    array of commands with:
        "status": "success" or "error"
        "command": the name of the received command
        "response_msg": human-readable message for the user
        "result": object with the specific data returned by that command
                  (can be an empty object {} or null if no data)
    Note: callers (e.g. PHP controllers) typically read the command
    responses from the `commands` array and access the payload via
    the `result` field of each command.
*/


namespace App\Gateway;

use App\Core\AppContext;
use App\Core\Network\SocketClient;

use RuntimeException;

class GwRequest
{
    private AppContext $ctx;
    private SocketClient $socketClient;
    private string $server_ip;
    private int $server_port;

    public function __construct(AppContext $ctx, string $server_ip, int $server_port)
    {
        $this->ctx = $ctx;
        $this->server_ip = $server_ip;
        $this->server_port = $server_port;

        if (empty($this->server_ip)) {
            throw new RuntimeException('GW: Wrong or empty server IP');
        }

        if ($this->server_port < 1 || $this->server_port > 65535) {
            throw new RuntimeException('GW: Invalid server port');
        }
    }

    /**
     * Connect to the socket server and set timeout.
     *
     * @param array $timeouts
     * @return SocketClient
     * @throws RuntimeException
     */
    public function connect(array $timeouts = []): SocketClient
    {
        try {
            $this->socketClient = new SocketClient($this->server_ip, $this->server_port);
            if (isset($timeouts['timeout_write']) && is_int($timeouts['timeout_write']) && $timeouts['timeout_write'] > 0) {
                $this->socketClient->setWriteTimeout($timeouts['timeout_write']);
            }
            if (isset($timeouts['timeout_read']) && is_int($timeouts['timeout_read']) && $timeouts['timeout_read'] > 0) {
                $this->socketClient->setReadTimeout($timeouts['timeout_read']);
            }

            return $this->socketClient;
        } catch (\Throwable $e) {
            throw new RuntimeException('GW: Failed to create socket client: ' . $e->getMessage(), $e->getCode(), $e);
        }
    }

    /**
     *
     * @param array<string, mixed> $request
     * @return array<string, mixed>
     */
    public function request(array $request): array
    {
        try {
            // Request ID (unique per request): place at root as 'id'
            if (!isset($request['id'])) {
                $request['id'] = bin2hex(random_bytes(16));
            }
            // Add metadata with client IP, request_id, and timestamp if not present
            if (!isset($request['metadata']) || !is_array($request['metadata'])) {
                $request['metadata'] = [];
            }
            // Client IP
            if (!isset($request['metadata']['client_ip'])) {
                $clientIp = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? null;
                $request['metadata']['client_ip'] = $clientIp;
            }
            // Timestamp (UTC ISO8601)
            if (!isset($request['metadata']['timestamp'])) {
                $request['metadata']['timestamp'] = gmdate('c');
            }
            // SendAndReceive trigger the connection
            $responseArray = $this->socketClient->sendAndReceive($request);
            if (is_array($responseArray)) {
                return $responseArray;
            }
            return ['status' => 'error', 'response_msg' => 'Unknown error receiving gw response'];
        } catch (\Throwable $e) {
            return ['status' => 'error', 'response_msg' => $e->getMessage(), 'error_code' => 'GATEWAY_UNREACHABLE'];
        }
    }

    /**
     * Return last measured connect time in milliseconds from the underlying socket client.
     */
    public function getLastConnectMs(): ?float
    {
        return isset($this->socketClient) ? $this->socketClient->getLastConnectMs() : null;
    }
}
