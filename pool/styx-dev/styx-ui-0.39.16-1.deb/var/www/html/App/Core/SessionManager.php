<?php
/**
 *  @author diego/@/envigo.net
 *  @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 *  @dr 2026/03/17
 */


namespace App\Core;
use App\Services\LogSystemService;
use Throwable;

class SessionManager
{
    /**
     * Configure and start PHP session according to validated Config.
     *
     * @param Config $cfg
     * @return bool True if session is active or started successfully, false otherwise
     */
    public static function start(AppContext $ctx, Config $cfg): bool
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return true;
        }

        try {
            $sessionCfg = $cfg->getValidatedSession();
        } catch (Throwable $e) {
            $msg = '[SessionManager] Failed to obtain session configuration: ' . $e->getMessage();

            // Prefer using the registered LogSystemService without causing
            // additional exceptions. Use `has()` to avoid instantiating the
            // service if it's not registered.
            if ($ctx->has(LogSystemService::class)) {
                $logger = $ctx->get(LogSystemService::class);
                if ($logger instanceof LogSystemService) {
                    $logger->error($msg);
                }
            }

            return false;
        }

        $cookieName = $sessionCfg['cookie_name'] ?? 'styx_session';
        $cookieSecure = (bool)($sessionCfg['secure'] ?? true);
        $cookieHttpOnly = (bool)($sessionCfg['http_only'] ?? true);
        $cookieSameSite = $sessionCfg['samesite'] ?? 'Strict';
        $lifetime = (int)($sessionCfg['lifetime_seconds'] ?? 3600);
        $cookieDomain = $sessionCfg['cookie_domain'] ?? '';

        ini_set('session.use_strict_mode', '1');
        ini_set('session.cookie_httponly', $cookieHttpOnly ? '1' : '0');
        ini_set('session.cookie_secure', $cookieSecure ? '1' : '0');
        // Ensure server-side session storage respects the configured lifetime
        ini_set('session.gc_maxlifetime', (string)$lifetime);

        if (!empty($cookieName)) {
            session_name($cookieName);
        }

        // Use structured cookie params (PHP 7.3+)
        session_set_cookie_params([
            'lifetime' => $lifetime,
            'path' => '/',
            'domain' => $cookieDomain,
            'secure' => $cookieSecure,
            'httponly' => $cookieHttpOnly,
            'samesite' => $cookieSameSite
        ]);

        if (session_status() === PHP_SESSION_NONE) {
            if (!session_start()) {
                return false;
            }
        }

        // Implement inactivity (sliding) expiration: track last activity
        $now = time();
        $last = $_SESSION['__last_activity'] ?? null;

        if (is_int($last) && ($now - $last) > $lifetime) {
            // Session expired due to inactivity  -  destroy and start a fresh one
            self::destroy();
            // Start a new session so callers continue to have an active session
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            $_SESSION['__last_activity'] = $now;
        } else {
            // Update last activity and refresh cookie expiry on client
            $_SESSION['__last_activity'] = $now;
            if ($lifetime > 0 && ini_get('session.use_cookies')) {
                $params = session_get_cookie_params();
                $samesite = $params['samesite'] ?? $cookieSameSite;
                setcookie(session_name(), session_id(), [
                    'expires' => $now + $lifetime,
                    'path' => $params['path'] ?? '/',
                    'domain' => $params['domain'] ?? $cookieDomain,
                    'secure' => $params['secure'] ?? $cookieSecure,
                    'httponly' => $params['httponly'] ?? $cookieHttpOnly,
                    'samesite' => $samesite
                ]);
            }
        }

        return true;
    }

    /**
     * Destroy session and remove cookie.
     *
     * @return void
     */
    public static function destroy(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            return;
        }

        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            $samesite = $params['samesite'] ?? 'Strict';
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => $params['path'] ?? '/',
                'domain' => $params['domain'] ?? '',
                'secure' => $params['secure'] ?? true,
                'httponly' => $params['httponly'] ?? true,
                'samesite' => $samesite
            ]);
        }

        session_unset();
        session_destroy();
    }
}
