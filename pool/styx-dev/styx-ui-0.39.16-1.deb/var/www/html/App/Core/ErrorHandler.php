<?php

namespace App\Core;

use App\Services\LogSystemService;

class ErrorHandler
{
    /**
     * Register global exception and shutdown handlers using the provided AppContext.
     */
    public static function register(AppContext $ctx): void
    {
        set_exception_handler(function (\Throwable $e) use ($ctx) {
            $msg = sprintf(
                "[BS] Uncaught exception: %s in %s:%d\n%s",
                $e->getMessage(),
                $e->getFile(),
                $e->getLine(),
                $e->getTraceAsString()
            );

            try {
                $logger = $ctx->get(LogSystemService::class);
                if ($logger instanceof LogSystemService) {
                    $logger->error($msg);
                } else {
                    error_log($msg);
                }
            } catch (\Throwable $logEx) {
                error_log($msg);
                error_log('[BS] Also failed to log with LogSystemService: ' . $logEx->getMessage());
            }

            // Check debug mode
            $isDebug = false;
            try {
                $cfg = $ctx->get(Config::class);
                $isDebug = (bool)$cfg->get('client.debug', false);
            } catch (\Throwable $cfgEx) {
                // Ignore, use default
            }

            // Determine if request expects JSON
            $isJson = (
                (
                    !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
                    && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest'
                )
                || stripos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false
                || stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false
            );

            if (!headers_sent()) {
                http_response_code(500);
                if ($isJson) {
                    header('Content-Type: application/json; charset=utf-8');
                    $errorMsg = $isDebug
                        ? 'Internal error: ' . $e->getMessage()
                        : '[BS] Internal server error';
                    echo json_encode(['status' => 'error', 'response_msg' => $errorMsg]);
                } else {
                    header('Content-Type: text/html; charset=utf-8');
                    if ($isDebug) {
                        echo '<h1>Internal server error</h1>';
                        echo '<p><strong>Error:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
                        echo '<p><strong>File:</strong> ' . htmlspecialchars($e->getFile()) . ':' . $e->getLine() . '</p>';
                        echo '<pre>' . htmlspecialchars($e->getTraceAsString()) . '</pre>';
                    } else {
                        echo '<h1>Internal server error</h1><p>[BS] Please contact the administrator.</p>';
                    }
                }
            }

            exit(1);
        });

        register_shutdown_function(function () use ($ctx) {
            $err = error_get_last();
            if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
                $msg = sprintf(
                    "[BS] Fatal error: %s in %s:%d",
                    $err['message'],
                    $err['file'],
                    $err['line']
                );
                try {
                    $logger = $ctx->get(LogSystemService::class);
                    if ($logger instanceof LogSystemService) {
                        $logger->critical($msg);
                    } else {
                        error_log($msg);
                    }
                } catch (\Throwable $logEx) {
                    error_log($msg);
                    error_log('[BS] Also failed to log with LogSystemService: ' . $logEx->getMessage());
                }

                if (!headers_sent()) {
                    http_response_code(500);
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode(['status' => 'error', 'response_msg' => '[BS] Internal server error']);
                }
            }
        });

        // Disabled: convert warnings/notices to ErrorExceptions
        // The conversion of PHP warnings/notices into ErrorException instances
        // is useful during development and testing but should remain optional
        // in production. The handler below is provided but kept commented
        // so it can be enabled intentionally during debugging.
        /*
        set_error_handler(function (int $severity, string $message, string $file, int $line) {
            // Respect @ operator
            if (!(error_reporting() & $severity)) {
                return false;
            }
            throw new \ErrorException($message, 0, $severity, $file, $line);
        });
        */
    }
}
