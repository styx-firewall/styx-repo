<?php
/**
 * Controller for packet-marking page requests
 */
namespace App\Controllers\Request;

use App\Controllers\BaseController;
use App\Core\AppContext;

class PacketMarkingRequestController extends BaseController
{
    public function __construct(AppContext $ctx)
    {
        parent::__construct($ctx);
    }

    /**
     * Get data for the packet-marking page: rules, sets and marks
     * @return array
     */
    public function getPageData(): array
    {
        $commands = [];
        $commands[] = [
            'method' => 'packet-marking.get_rules',
            'id' => 'rules',
            'data' => (object)[],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if (($resp['status'] ?? '') === 'error') {
            return $resp;
        }

        $cmds  = $resp['commands'] ?? [];
        $rules = $cmds['rules']['result']['rules'] ?? [];

        return [
            'status'   => $resp['status'],
            'result'   => ['rules' => $rules],
            'warnings' => $resp['warnings'] ?? [],
        ];
    }
}
