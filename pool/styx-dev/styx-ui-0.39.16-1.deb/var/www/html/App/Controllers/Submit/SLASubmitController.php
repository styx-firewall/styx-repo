<?php
namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class SLASubmitController extends BaseController
{
    /**
     * Add a new SLA monitor
     * @param array $data
     * @return array
     */
    public function addMonitor($data)
    {
        // Required fields
        $name = isset($data['name']) ? trim($data['name']) : null;
        $protocol = isset($data['protocol']) ? trim($data['protocol']) : null;
        $target = isset($data['target']) ? trim($data['target']) : null;
        if ($name === null || $name === '') {
            return $this->baseError('Field "name" is required');
        }
        if ($protocol === null || $protocol === '') {
            return $this->baseError('Field "protocol" is required');
        }
        if ($protocol !== 'ping') {
            return $this->baseError('Only protocol "ping" is supported');
        }
        if ($target === null || $target === '') {
            return $this->baseError('Field "target" is required');
        }
        // Optional fields with defaults
        $interface = array_key_exists('interface', $data) ? $data['interface'] : null;
        if ($interface === '' || $interface === 'none') {
            $interface = null;
        }
        $interval_ms = (isset($data['interval_ms']) && is_numeric($data['interval_ms']))
            ? (int)$data['interval_ms']
            : 5000;
        if ($interval_ms < 500) {
            return $this->baseError('Minimum interval is 500ms');
        }
        $inactive_failures = (isset($data['inactive_failures']) && is_numeric($data['inactive_failures']))
            ? (int)$data['inactive_failures']
            : 3;
        if ($inactive_failures < 1) {
            return $this->baseError('Minimum value for inactive_failures is 1');
        }
        $restore_success = (isset($data['restore_success']) && is_numeric($data['restore_success']))
            ? (int)$data['restore_success']
            : 3;
        if ($restore_success < 1) {
            return $this->baseError('Minimum value for restore_success is 1');
        }
        $enabled = isset($data['enabled']) ? (bool)$data['enabled'] : true;
        $monitorData = [
            'name' => $name,
            'protocol' => $protocol,
            'target' => $target,
            'interface' => $interface,
            'interval_ms' => $interval_ms,
            'inactive_failures' => $inactive_failures,
            'restore_success' => $restore_success,
            'enabled' => $enabled
        ];
        // Add ping-specific optional fields
        if ($protocol === 'ping') {
            if (isset($data['latency_threshold']) && is_numeric($data['latency_threshold'])) {
                $monitorData['latency_threshold'] = (int)$data['latency_threshold'];
            }
            if (isset($data['latency_strikes']) && is_numeric($data['latency_strikes'])) {
                $monitorData['latency_strikes'] = (int)$data['latency_strikes'];
            }
            if (isset($data['jitter_threshold']) && is_numeric($data['jitter_threshold'])) {
                $monitorData['jitter_threshold'] = (int)$data['jitter_threshold'];
            }
            if (isset($data['jitter_strikes']) && is_numeric($data['jitter_strikes'])) {
                $monitorData['jitter_strikes'] = (int)$data['jitter_strikes'];
            }
        }
        $commands = [
            [
                'method' => 'sla-mgmt.add_monitor',
                'id' => 'add_monitor',
                'data' => $monitorData
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['add_monitor'] ?? $this->baseError('No response for add_monitor');
    }
    /**
     * Activate a monitor by ID
     */
    public function enableMonitor($data)
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Monitor ID is required');
        }
        $commands = [
            [
                'method' => 'sla-mgmt.enable_monitor',
                'id' => 'enable_monitor',
                'data' => [ 'monitor_id' => $id ]
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['enable_monitor'] ?? $this->baseError('No response for enable_monitor');
    }

    /**
     * Deactivate a monitor by ID
     */
    public function disableMonitor($data)
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Monitor ID is required');
        }
        $commands = [
            [
                'method' => 'sla-mgmt.disable_monitor',
                'id' => 'disable_monitor',
                'data' => [ 'monitor_id' => $id ]
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['disable_monitor'] ?? $this->baseError('No response for disable_monitor');
    }

    /**
     * Delete a monitor by ID
     */
    public function deleteMonitor($data)
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Monitor ID is required');
        }
        $commands = [
            [
                'method' => 'sla-mgmt.delete_monitor',
                'id' => 'delete_monitor',
                'data' => [ 'monitor_id' => $id ]
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['delete_monitor'] ?? $this->baseError('No response for delete_monitor');
    }
}
