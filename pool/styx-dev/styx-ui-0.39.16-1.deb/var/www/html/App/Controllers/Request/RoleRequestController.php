<?php

namespace App\Controllers\Request;

use App\Controllers\BaseController;

class RoleRequestController extends BaseController
{
    /**
     * List all role definitions with their capabilities.
     *
     * @return array{status: string, result: array, warnings: string[]}
     */
    public function getDefinitions(): array
    {
        $commands = [
            [
                'method' => 'role-mgmt.list_definitions',
                'id'     => 'list_defs',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['list_defs']['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * List all available capabilities grouped by module.
     *
     * @return array{status: string, result: array, warnings: string[]}
     */
    public function getCapabilities(): array
    {
        $commands = [
            [
                'method' => 'role-mgmt.list_capabilities',
                'id'     => 'list_caps',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['list_caps']['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }
}
