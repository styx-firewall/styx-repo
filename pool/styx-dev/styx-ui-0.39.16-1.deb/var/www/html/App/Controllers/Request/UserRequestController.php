<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class UserRequestController extends BaseController
{

    /**
     * Get user information by username
     * @param string $username
     * @return array{status: string, result: mixed, warnings: string[]}
     */
    public function getUserInfo(string $username): array
    {
        if (empty($username)) {
            return $this->baseError('No username provided');
        }
        $commands = [
            [
                'method' => 'user-mgmt.get_user_info',
                'id'     => 'user_info',
                'data'   => ['username' => $username],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['user_info']['result'] ?? null,
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get bearer tokens for the current user
     * @return array{status: string, result: array, warnings: string[]}
     */
    public function getBearerTokens(): array
    {
        $commands = [
            [
                'method' => 'auth.get_bearer_tokens',
                'id'     => 'tokens',
                'data'   => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['tokens']['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * List users
     * @return array{status: string, result: array, warnings: string[]}
     */
    public function getUsers(): array
    {
        $commands = [
            [
                'method' => 'user-mgmt.list_users',
                'id'     => 'users',
                'data'   => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['users']['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * List all users and their roles.
     * @return array{status: string, result: array, warnings: string[]}
     */
    public function getRoles(): array
    {
        $commands = [
            [
                'method' => 'user-mgmt.list_users_with_roles',
                'id'     => 'list_users_with_roles',
                'data'   => (object)[],
            ],
            [
                'method' => 'user-mgmt.list_valid_roles',
                'id'     => 'list_valid_roles',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => [
                'users'       => $resp['commands']['list_users_with_roles']['result']['users'] ?? [],
                'valid_roles' => $resp['commands']['list_valid_roles']['result']['valid_roles'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }
}
