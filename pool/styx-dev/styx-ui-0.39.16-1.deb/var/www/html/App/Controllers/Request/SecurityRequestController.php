<?php
/**
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
*/

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class SecurityRequestController extends BaseController
{
    /**
     * Get security overview data: firewall status, IDS/IPS status, failed logins, active sessions, TLS certs.
     * @return array<string, mixed>
     */
    public function getSecOverview(): array
    {
        $commands = [
            [
                'method' => 'security.get_overview',
                'id' => 'overview',
                'data' => (object)[],
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands, null, ['read_timeout' => 5]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmd = $resp['commands']['overview'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'security.get_overview command failed');
        }

        return [
            'status'   => $resp['status'],
            'result'   => [
                'sec_overview' => $cmd['result'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get security audit events.
     * @param array<string, mixed> $filters Optional filters (e.g. ['since' => '...', 'limit' => 50]).
     * @return array<string, mixed>
     */
    public function getSecAudit(): array
    {
        $commands = [
            [
                'method' => 'security.get_audit',
                'id' => 'audit',
                'data' => (object)[],
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands, null, ['read_timeout' => 8]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmd = $resp['commands']['audit'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'security.get_audit_logs command failed');
        }

        return [
            'status'   => $resp['status'],
            'result'   => [
                'sec_audit' => $cmd['result']['audit_events'] ?? $cmd['result'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get auditd status and configuration.
     * @return array<string, mixed>
     */
    public function getSecAuditd(): array
    {
        $commands = [
            [
                'method' => 'security.get_auditd_status',
                'id' => 'auditd',
                'data' => (object)[],
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands, null, ['read_timeout' => 5]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmd = $resp['commands']['auditd'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'security.get_auditd_status command failed');
        }

        return [
            'status'   => $resp['status'],
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get AIDE status and check results.
     * @return array<string, mixed>
     */
    public function getSecAide(): array
    {
        $commands = [
            [
                'method' => 'security.get_aide_status',
                'id' => 'aide',
                'data' => (object)[],
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands, null, ['read_timeout' => 5]));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmd = $resp['commands']['aide'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'security.get_aide_status command failed');
        }

        return [
            'status'   => $resp['status'],
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }
}
