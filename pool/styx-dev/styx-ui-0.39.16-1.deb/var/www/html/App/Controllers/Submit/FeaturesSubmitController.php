<?php

/**
 * Controller for handling feature option enable/disable submissions
 * dp: 20260321
 */
namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class FeaturesSubmitController extends BaseController
{
    /**
     * Enable or disable a feature option
     *
     * Expected $data keys:
     *  - feature_key: string
     *  - option_key: string
     *  - enabled: bool
     *
     * @param array<string,mixed> $data Request payload
     * @return array<string,mixed> Gateway response or error structure
     */
    public function setEnableFeature(array $data): array
    {
        $featureKey = $data['feature_key'] ?? null;
        $optionKey = $data['option_key'] ?? null;
        $enabled = $data['enabled'] ?? null;
        if ($featureKey === null || $optionKey === null || $enabled === null) {
            return $this->baseError('feature_key, option_key and enabled are required');
        }
        $commands = [
            [
                'method' => 'styx-features.set_option_enabled',
                'id' => 'set_option_enabled',
                'data' => [
                    'feature_key' => $featureKey,
                    'option_key' => $optionKey,
                    'enabled' => $enabled
                ]
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['set_option_enabled'] ?? $this->baseError('No response for set_option_enabled');
    }
}
