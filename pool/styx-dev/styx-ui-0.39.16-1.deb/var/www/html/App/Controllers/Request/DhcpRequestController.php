<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;
use App\Services\GatewayService;

class DhcpRequestController extends BaseController
{
	/**
	 * Get all DHCP server configuration (all interfaces)
	 * @return array
	 */
	public function getPageData(): array
	{
		$commands = [
			[
				'method' => 'dhcp-server.get_all_dhcp_config',
				'id' => 'all_config',
			],			
			[
				'method' => 'dhcp-server.get_dhcp_global_config',
				'id' => 'global_config',
			],
			[
				'method' => 'dhcp-server.get_dhcp_leases',
				'id' => 'leases',
			],
			[
				'method' => 'network-config.get_interfaces_config',
				'id' => 'interfaces',
				'data' => (object)[],
			],

		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		if ($resp['status'] === 'error') {
			return $resp;
		}
		$cmds = $resp['commands'];
		return [
			'status'   => $resp['status'],
			'result'   => [
				'interfaces'         => $cmds['interfaces']['result']['interfaces'] ?? [],
				'dhcp_config'        => $cmds['all_config']['result'] ?? [],
				'dhcp_global_config' => $cmds['global_config']['result'] ?? [],
				'leases'             => $cmds['leases']['result'] ?? [],
				'address_sets'       => $cmds['address_sets']['result']['address'] ?? [],
				'domain_sets'        => $cmds['domain_sets']['result']['domains'] ?? [],
			],
			'warnings' => $resp['warnings'],
		];
	}

	/**
	 * Get DHCP server configuration for a specific interface
	 * @param string $interface_id
	 * @return array
	 */
	public function getDhcpConfigByInterface($interface_id)
	{
		$commands = [
			[
				'method' => 'dhcp-server.get_dhcp_config_by_interface',
				'id' => 'iface_config',
				'data' => [
					'interface_id' => $interface_id
				]
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		if ($resp['status'] === 'error') {
			return $resp;
		}
		return [
			'status'   => $resp['status'],
			'result'   => $resp['commands']['iface_config']['result'] ?? [],
			'warnings' => $resp['warnings'],
		];
	}

	/**
	 * Get current DHCP leases (all interfaces)
	 * @return array
	 */
	public function getDhcpLeases(): array
	{
		$commands = [
			[
				'method' => 'dhcp-server.get_dhcp_leases',
				'id' => 'leases',
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		if ($resp['status'] === 'error') {
			return $resp;
		}
		return [
			'status'   => $resp['status'],
			'result'   => $resp['commands']['leases']['result'] ?? [],
			'warnings' => $resp['warnings'],
		];
	}

}
