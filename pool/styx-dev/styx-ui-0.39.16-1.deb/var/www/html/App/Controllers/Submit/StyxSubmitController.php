<?php
namespace App\Controllers\Submit;
use App\Controllers\BaseController;
use App\Services\DateFormatter;

class StyxSubmitController extends BaseController
{
	/**
	 * Restore backup wrapper - extracts payload from data
	 * @param array $data Should contain 'data' key with backup payload
	 * @return array
	 */
	public function restoreBackup($data)
	{
		$payload = $data['data'] ?? [];
		return $this->restoreBackupFromJson($payload);
	}

	/**
	 * Restore configuration from backup JSON file
	 * @param array $payload Should contain 'backup_json' (string) and 'type' (string)
	 * @return array
	 */
	public function restoreBackupFromJson($payload)
	{
		if (!is_array($payload)) {
				return $this->baseError('Payload must be an array.');
		}
		if (
			!isset($payload['backup_json']) ||
			!is_string($payload['backup_json']) ||
			trim($payload['backup_json']) === '')
		{
			return $this->baseError('Missing or empty backup_json.');
		}
		if (!isset($payload['type']) || !is_string($payload['type']) || trim($payload['type']) === '')
		{
			return $this->baseError('Missing or empty type.');
		}
		$jsonContent = $payload['backup_json'];
		$type = $payload['type'];
		$data = json_decode($jsonContent, true);
		if (!is_array($data)) {
			return $this->baseError('Invalid JSON in backup_json.');
		}
		$commands = [
			[
				'method' => 'styx-mgmt.restore_backup',
				'id' => 'restore_backup',
				'data' => [
					'type' => $type,
					'backup' => $data
				]
			]
		];
		$gwResp = $this->sendCommands($commands);
		$resp = $this->processGwResp($gwResp);
		return $resp['commands']['restore_backup'] ?? $this->baseError('Error restoring backup');
	}

	/**
	 * Get Styx logs with optional filtering
	 * @param array $payload Should contain optional 'level' and 'limit'
	 * @return array
	 */
	public function getStyxLogs($payload)
	{
		$data = [];

		if (isset($payload['level']) && !empty($payload['level'])) {
			$data['level'] = $payload['level'];
		}

		if (isset($payload['limit'])) {
			$data['limit'] = (int)$payload['limit'];
		} else {
			$data['limit'] = 50;
		}

		$commands = [
			[
				'method' => 'styx-mgmt.get_styx_logs',
				'id' => 'get_styx_logs',
				'data' => $data,
			]
		];

		$resp = $this->processGwResp($this->sendCommands($commands));
		$cmd = $resp['commands']['get_styx_logs'] ?? null;
		if (!$cmd) {
			return $this->baseError('No valid response from gateway');
		}
		if (($cmd['status'] ?? null) === 'success' && isset($cmd['result'])) {
			$result = $cmd['result'];
			// Pre-format timestamps server-side using the user's timezone and locale.
			if (!empty($result['logs']) && is_array($result['logs'])) {
				foreach ($result['logs'] as $k => $log) {
					$ts = $log['timestamp_iso'] ?? $log['date'] ?? null;
					if ($ts !== null) {
						$result['logs'][$k]['date_fmt'] = DateFormatter::fromBackend($this->ctx, (string)$ts);
					}
				}
			}
			return ['status' => 'success', 'result' => $result];
		}
		return $cmd;
	}


	/**
	 * Update web settings (Styx service)
	 * Expects ssl certificate id
	 * @param array $payload
	 * @return array
	 */
	public function updateWebSettings($payload)
	{
		if (!is_array($payload)) {
			return $this->baseError('Payload must be an array.');
		}

		$selectedId = $payload['ssl_cert_select'] ?? null;
		if (empty($selectedId)) {
			return $this->baseError('ssl_cert_select (certificate id) is required.');
		}
		$cmdData = [ 'ssl_certificate_id' => $selectedId ];
		if (isset($payload['https_port'])) {
			$cmdData['https_port'] = (int)$payload['https_port'];
		}
		if (!empty($payload['styx_branch'])) {
			$cmdData['styx_branch'] = $payload['styx_branch'];
		}
		if (!empty($payload['styx_theme'])) {
			$cmdData['styx_theme'] = $payload['styx_theme'];
		}
		if (isset($payload['styx_log_level'])) {
			$cmdData['styx_log_level'] = (int)$payload['styx_log_level'];
		}

		$commands = [
			[
				'method' => 'styx-mgmt.set_styx_settings',
				'id' => 'set_styx_settings',
				'data' => $cmdData
			]
		];

		$resp = $this->processGwResp($this->sendCommands($commands));
		$cmd = $resp['commands']['set_styx_settings'] ?? null;
		if (!$cmd) {
			return $this->baseError('Error applying web settings');
		}
		// Build a specific error message from the per-section result details
		if (($cmd['status'] ?? null) !== 'success' && isset($cmd['result']) && is_array($cmd['result'])) {
			$result = $cmd['result'];
			$parts = [];
			foreach (['certificate', 'port', 'styx_config'] as $section) {
				$sectionResult = $result[$section] ?? null;
				if (is_array($sectionResult) && ($sectionResult['ok'] ?? null) === false) {
					$reason = $sectionResult['msg'] ?? $sectionResult['error'] ?? 'unknown error';
					$parts[] = "{$section}: {$reason}";
				}
			}
			if (!empty($parts)) {
				$cmd['response_msg'] = implode('; ', $parts);
			}
		}
		return $cmd;
	}

	/**
	 * Restart the Styx UI service.
	 *
	 * @param array<string,mixed> $data Unused; no parameters needed.
	 * @return array<string,mixed>
	 */
	public function restartStyxUi(array $data = []): array
	{
		$commands = [
			[
				'method' => 'styx-mgmt.restart_styx_ui',
				'id' => 'restart_styx_ui',
				'data' => (object)[],
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		return $resp['commands']['restart_styx_ui'] ?? $this->baseError('No response for restart_styx_ui');
	}

	/**
	 * Save running configuration to startup config (persist changes).
	 *
	 * @param array<string,mixed> $data Unused; no parameters needed.
	 * @return array<string,mixed>
	 */
	public function saveConfig(array $data = []): array
	{
		$commands = [
			[
				'method' => 'styx-mgmt.save_config',
				'id' => 'save_config',
				'data' => (object)[],
			]
		];
		$resp = $this->processGwResp($this->sendCommands($commands));
		$cmd = $resp['commands']['save_config'] ?? null;
		if (!$cmd) {
			return $this->baseError('No response for save_config');
		}
		if (($cmd['status'] ?? null) === 'success') {
			return ['status' => 'success', 'response_msg' => $cmd['response_msg'] ?? 'Configuration saved'];
		}
		return $cmd;
	}
}
