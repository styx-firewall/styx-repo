<?php

namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class RoleSubmitController extends BaseController
{
    /**
     * Create a new custom role.
     */
    public function create(array $data): array
    {
        $role = $data['role'] ?? null;
        $capabilities = $data['capabilities'] ?? [];
        if (!$role) {
            return $this->baseError('Role name required');
        }
        $commands = [[
            'method' => 'role-mgmt.create',
            'id' => 'create_role',
            'data' => [
                'role'         => $role,
                'capabilities' => $capabilities,
            ],
        ]];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['create_role'] ?? $this->baseError('No response for create_role');
    }

    /**
     * Delete a custom role.
     */
    public function delete(array $data): array
    {
        $role = $data['role'] ?? null;
        if (!$role) {
            return $this->baseError('Role name required');
        }
        $commands = [[
            'method' => 'role-mgmt.delete',
            'id' => 'delete_role',
            'data' => ['role' => $role],
        ]];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['delete_role'] ?? $this->baseError('No response for delete_role');
    }

    /**
     * Update capabilities of an existing custom role.
     */
    public function update(array $data): array
    {
        $role = $data['role'] ?? null;
        $capabilities = $data['capabilities'] ?? [];
        if (!$role) {
            return $this->baseError('Role name required');
        }
        $commands = [[
            'method' => 'role-mgmt.update',
            'id' => 'update_role',
            'data' => [
                'role'         => $role,
                'capabilities' => $capabilities,
            ],
        ]];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['update_role'] ?? $this->baseError('No response for update_role');
    }
}
