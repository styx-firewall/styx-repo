<?php
/**
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 * @TODO Simplify?
 */
namespace App\Controllers;

use App\Core\AppContext;
use App\Services\GatewayService;
use App\Services\LogSystemService;
use App\Services\AuthService;

class MetricsController
{
    private AppContext $ctx;
    private GatewayService $gs;
    private LogSystemService $logService;
    private ?string $token = null;

    public function __construct(AppContext $ctx)
    {
        $this->ctx = $ctx;
        $this->gs = $ctx->get(GatewayService::class);
        $this->logService = $ctx->get(LogSystemService::class);
        $auth = $ctx->get(AuthService::class);
        $this->token = $auth->getUserToken();
    }

    /**
     * Handle metrics request for dashboard charts.
     * Expects in $inputData: 'metric' (cpu|iowait|memory|network), 'range' (e.g., '1h'),
     * 'iface' (optional for network)
     * @param array $inputData
     * @return array
     */
    public function handle(array $inputData): array
    {
        $metric = $inputData['metric'] ?? '';
        $range = $inputData['range'] ?? '1h';
        $iface = $inputData['iface'] ?? null;
        $result = [
            'status' => 'error',
            'response_msg' => 'Invalid metric',
            'metric' => $metric
        ];

        switch ($metric) {
            case 'cpu':
                $result = $this->getCpuUsage($range);
                break;
            case 'iowait':
                $result = $this->getIoWait($range);
                break;
            case 'memory':
                $result = $this->getMemoryUsage($range);
                break;
            case 'network':
                $result = $this->getNetworkUsage($range, $iface);
                break;
            case 'network_tx':
                $result = $this->getNetworkTxUsage($range, $iface);
                break;
            case 'network_rx':
                $result = $this->getNetworkRxUsage($range, $iface);
                break;
            case 'tcp_mem':
                $result = $this->getTcpMemMetrics($range);
                break;
            case 'udp_mem':
                $result = $this->getUdpMemMetrics($range);
                break;
            case 'tcp_inuse':
                $result = $this->getTcpInuseMetrics($range);
                break;
            case 'udp_inuse':
                $result = $this->getUdpInuseMetrics($range);
                break;
            case 'raw_inuse':
                $result = $this->getRawInuseMetrics($range);
                break;
            case 'fragments':
                $result = $this->getFragmentsMetrics($range);
                break;
            case 'tcp_orphan':
                $result = $this->getTcpOrphanMetrics($range);
                break;
            case 'tcp_time_wait':
                $result = $this->getTcpTimeWaitMetrics($range);
                break;
            case 'tcp_connections_established':
                $result = $this->getTcpConnectionsEstablishedMetrics($range);
                break;
            case 'tcp_connections_time_wait':
                $result = $this->getTcpConnectionsTimeWaitMetrics($range);
                break;
            case 'tcp_connections_close_wait':
                $result = $this->getTcpConnectionsCloseWaitMetrics($range);
                break;
            case 'tcp_connections_listen':
                $result = $this->getTcpConnectionsListenMetrics($range);
                break;
            case 'tcp_connections_total':
                $result = $this->getTcpConnectionsTotalMetrics($range);
                break;
            case 'udp_connections_total':
                $result = $this->getUdpConnectionsTotalMetrics($range);
                break;
            // Connection Tracking (nf_conntrack)
            case 'conntrack_count':
                $result = $this->getConntrackCountMetrics($range);
                break;
            case 'conntrack_pressure':
                $result = $this->getConntrackPressureMetrics($range);
                break;
            // Softnet (softirq per CPU)
            case 'softnet_processed':
                $result = $this->getSoftnetProcessedMetrics($range);
                break;
            case 'softnet_dropped':
                $result = $this->getSoftnetDroppedMetrics($range);
                break;
            case 'softnet_drop_pct':
                $result = $this->getSoftnetDropPctMetrics($range);
                break;
            case 'softnet_squeeze':
                $result = $this->getSoftnetSqueezeMetrics($range);
                break;
            case 'softnet_squeeze_pct':
                $result = $this->getSoftnetSqueezePctMetrics($range);
                break;
            case 'sla':
                $result = $this->getMonitorStats($inputData);
                break;
            default:
                $result['response_msg'] = 'Unknown metric type';
        }
        return $result;
    }

    private function getCpuUsage(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_cpu_metrics',
            'system-metrics',
            'cpu_metrics',
            'cpu',
            $range
        );
    }
    private function getIoWait(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_iowait_metrics',
            'system-metrics',
            'iowait_metrics',
            'iowait',
            $range
        );
    }
    private function getMemoryUsage(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_memory_metrics',
            'system-metrics',
            'memory_metrics',
            'memory',
            $range
        );
    }
    private function getNetworkUsage(string|int $range, ?string $iface = null): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_network_metrics',
            'system-metrics',
            'network_metrics',
            'network',
            $range,
            ['iface' => $iface],
            null,
            'both'
        );
    }
    // NEW FUNCTIONS FOR TX AND RX
    private function getNetworkTxUsage(string|int $range, ?string $iface = null): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_network_metrics_tx',
            'system-metrics',
            'network_metrics_tx',
            'network_tx',
            $range,
            ['iface' => $iface],
            null,
            'tx'
        );
    }
    private function getNetworkRxUsage(string|int $range, ?string $iface = null): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_network_metrics_rx',
            'system-metrics',
            'network_metrics_rx',
            'network_rx',
            $range,
            ['iface' => $iface],
            null,
            'rx'
        );
    }
    // NEW FUNCTIONS FOR SOCKET AND FRAGMENTS METRICS
    private function getTcpMemMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_tcp_mem_metrics',
            'system-metrics',
            'tcp_mem_metrics',
            'tcp_mem_reserved',
            $range,
            [],
            function (array $m) {
                return [
                    'timestamp' => $m['timestamp'] ?? null,
                    'tcp_mem_reserved' => $m['tcp_mem_reserved'] ?? null,
                ];
            }
        );
    }
    private function getUdpMemMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_udp_mem_metrics',
            'system-metrics',
            'udp_mem_metrics',
            'udp_mem_reserved',
            $range,
            [],
            function (array $m) {
                return [
                    'timestamp' => $m['timestamp'] ?? null,
                    'udp_mem_reserved' => $m['udp_mem_reserved'] ?? null,
                ];
            }
        );
    }
    private function getTcpInuseMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_tcp_inuse_metrics',
            'system-metrics',
            'tcp_inuse_metrics',
            'tcp_socket_inuse',
            $range,
            [],
            function (array $m) {
                return [
                    'timestamp' => $m['timestamp'] ?? null,
                    'tcp_socket_inuse' => $m['tcp_socket_inuse'] ?? null,
                ];
            }
        );
    }
    private function getUdpInuseMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_udp_inuse_metrics',
            'system-metrics',
            'udp_inuse_metrics',
            'udp_socket_inuse',
            $range,
            [],
            function (array $m) {
                return [
                    'timestamp' => $m['timestamp'] ?? null,
                    'udp_socket_inuse' => $m['udp_socket_inuse'] ?? null,
                ];
            }
        );
    }
    private function getRawInuseMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_raw_inuse_metrics',
            'system-metrics',
            'raw_inuse_metrics',
            'raw_sockets_inuse',
            $range,
            [],
            function (array $m) {
                return [
                    'timestamp' => $m['timestamp'] ?? null,
                    'raw_sockets_inuse' => $m['raw_sockets_inuse'] ?? null,
                ];
            }
        );
    }
    private function getFragmentsMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_fragments_metrics',
            'system-metrics',
            'fragments_metrics',
            'fragments',
            $range
        );
    }
    // Connection Tracking (nf_conntrack) metrics
    private function getConntrackCountMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_conntrack_count_metrics',
            'system-metrics',
            'conntrack_count_metrics',
            'nf_conntrack_count',
            $range
        );
    }
    private function getConntrackPressureMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_conntrack_pressure_metrics',
            'system-metrics',
            'conntrack_pressure_metrics',
            'nf_conntrack_pressure_pct',
            $range
        );
    }

    // Softnet (softirq per CPU) metrics
    private function getSoftnetProcessedMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_softnet_processed_metrics',
            'system-metrics',
            'softnet_processed_metrics',
            'softnet_processed',
            $range,
            [],
            null,
            'softnet'
        );
    }
    private function getSoftnetDroppedMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_softnet_dropped_metrics',
            'system-metrics',
            'softnet_dropped_metrics',
            'softnet_dropped',
            $range,
            [],
            null,
            'softnet'
        );
    }
    private function getSoftnetDropPctMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_softnet_drop_pct_metrics',
            'system-metrics',
            'softnet_drop_pct_metrics',
            'softnet_drop_pct',
            $range,
            [],
            null,
            'softnet'
        );
    }
    private function getSoftnetSqueezeMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_softnet_squeeze_metrics',
            'system-metrics',
            'softnet_squeeze_metrics',
            'softnet_squeeze',
            $range,
            [],
            null,
            'softnet'
        );
    }
    private function getSoftnetSqueezePctMetrics(string|int $range): array
    {
        return $this->fetchTimeSeriesMetric(
            'get_softnet_squeeze_pct_metrics',
            'system-metrics',
            'softnet_squeeze_pct_metrics',
            'softnet_squeeze_pct',
            $range,
            [],
            null,
            'softnet'
        );
    }

    private function getTcpOrphanMetrics(string|int $range): array
    {
        $res = $this->fetchTimeSeriesMetric(
            'get_tcp_orphan_metrics',
            'system-metrics',
            'tcp_orphan_metrics',
            'tcp_orphan_metrics',
            $range,
            [],
            null,
            'none'
        );
        if (($res['status'] ?? null) === 'success') {
            $metrics = $res['result']['metrics'] ?? null;
            return [
                'status' => 'success',
                'method' => 'system-metrics.get_tcp_orphan_metrics',
                'response_msg' => $res['response_msg'] ?? 'TCP orphan metrics retrieved successfully',
                'result' => ['tcp_orphan_metrics' => $metrics]
            ];
        }
        return [
            'status' => 'error',
            'method' => 'system-metrics.get_tcp_orphan_metrics',
            'response_msg' => $res['response_msg'] ?? 'No data from backend',
            'result' => null
        ];
    }
    private function getTcpTimeWaitMetrics(string|int $range): array
    {
        $res = $this->fetchTimeSeriesMetric(
            'get_tcp_time_wait_metrics',
            'system-metrics',
            'tcp_time_wait_metrics',
            'tcp_time_wait_metrics',
            $range,
            [],
            null,
            'none'
        );
        if (($res['status'] ?? null) === 'success') {
            $metrics = $res['result']['metrics'] ?? null;
            return [
                'status' => 'success',
                'method' => 'system-metrics.get_tcp_time_wait_metrics',
                'response_msg' => $res['response_msg'] ?? 'TCP time wait metrics retrieved successfully',
                'result' => ['tcp_time_wait_metrics' => $metrics]
            ];
        }
        return [
            'status' => 'error',
            'method' => 'system-metrics.get_tcp_time_wait_metrics',
            'response_msg' => $res['response_msg'] ?? 'No data from backend',
            'result' => null
        ];
    }
    private function getTcpConnectionsEstablishedMetrics(string|int $range): array
    {
        $res = $this->fetchTimeSeriesMetric(
            'get_tcp_connections_established_metrics',
            'system-metrics',
            'tcp_connections_established_metrics',
            'tcp_connections_established_metrics',
            $range,
            [],
            null,
            'none'
        );
        if (($res['status'] ?? null) === 'success') {
            $metrics = $res['result']['metrics'] ?? null;
            return [
                'status' => 'success',
                'method' => 'system-metrics.get_tcp_connections_established_metrics',
                'response_msg' => $res['response_msg'] ?? 'TCP connections ESTABLISHED metrics retrieved successfully',
                'result' => ['tcp_connections_established_metrics' => $metrics]
            ];
        }
        return [
            'status' => 'error',
            'method' => 'system-metrics.get_tcp_connections_established_metrics',
            'response_msg' => $res['response_msg'] ?? 'No data from backend',
            'result' => null
        ];
    }
    private function getTcpConnectionsCloseWaitMetrics(string|int $range): array
    {
        $res = $this->fetchTimeSeriesMetric(
            'get_tcp_connections_close_wait_metrics',
            'system-metrics',
            'tcp_connections_close_wait_metrics',
            'tcp_connections_close_wait_metrics',
            $range,
            [],
            null,
            'none'
        );
        if (($res['status'] ?? null) === 'success') {
            $metrics = $res['result']['metrics'] ?? null;
            return [
                'status' => 'success',
                'method' => 'system-metrics.get_tcp_connections_close_wait_metrics',
                'response_msg' => $res['response_msg'] ?? 'TCP connections CLOSE_WAIT metrics retrieved successfully',
                'result' => ['tcp_connections_close_wait_metrics' => $metrics]
            ];
        }
        return [
            'status' => 'error',
            'method' => 'system-metrics.get_tcp_connections_close_wait_metrics',
            'response_msg' => $res['response_msg'] ?? 'No data from backend',
            'result' => null
        ];
    }
    private function getTcpConnectionsListenMetrics(string|int $range): array
    {
        $res = $this->fetchTimeSeriesMetric(
            'get_tcp_connections_listen_metrics',
            'system-metrics',
            'tcp_connections_listen_metrics',
            'tcp_connections_listen_metrics',
            $range,
            [],
            null,
            'none'
        );
        if (($res['status'] ?? null) === 'success') {
            $metrics = $res['result']['metrics'] ?? null;
            return [
                'status' => 'success',
                'method' => 'system-metrics.get_tcp_connections_listen_metrics',
                'response_msg' => $res['response_msg'] ?? 'TCP connections LISTEN metrics retrieved successfully',
                'result' => ['tcp_connections_listen_metrics' => $metrics]
            ];
        }
        return [
            'status' => 'error',
            'method' => 'system-metrics.get_tcp_connections_listen_metrics',
            'response_msg' => $res['response_msg'] ?? 'No data from backend',
            'result' => null
        ];
    }
    private function getTcpConnectionsTotalMetrics(string|int $range): array
    {
        $res = $this->fetchTimeSeriesMetric(
            'get_tcp_connections_total_metrics',
            'system-metrics',
            'tcp_connections_total_metrics',
            'tcp_connections_total_metrics',
            $range,
            [],
            null,
            'none'
        );
        if (($res['status'] ?? null) === 'success') {
            $metrics = $res['result']['metrics'] ?? null;
            return [
                'status' => 'success',
                'method' => 'system-metrics.get_tcp_connections_total_metrics',
                'response_msg' => $res['response_msg'] ?? 'TCP connections total metrics retrieved successfully',
                'result' => ['tcp_connections_total_metrics' => $metrics]
            ];
        }
        return [
            'status' => 'error',
            'method' => 'system-metrics.get_tcp_connections_total_metrics',
            'response_msg' => $res['response_msg'] ?? 'No data from backend',
            'result' => null
        ];
    }
    private function getUdpConnectionsTotalMetrics(string|int $range): array
    {
        $res = $this->fetchTimeSeriesMetric(
            'get_udp_connections_total_metrics',
            'system-metrics',
            'udp_connections_total_metrics',
            'udp_connections_total_metrics',
            $range,
            [],
            null,
            'none'
        );
        if (($res['status'] ?? null) === 'success') {
            $metrics = $res['result']['metrics'] ?? null;
            return [
                'status' => 'success',
                'method' => 'system-metrics.get_udp_connections_total_metrics',
                'response_msg' => $res['response_msg'] ?? 'UDP connections total metrics retrieved successfully',
                'result' => ['udp_connections_total_metrics' => $metrics]
            ];
        }
        return [
            'status' => 'error',
            'method' => 'system-metrics.get_udp_connections_total_metrics',
            'response_msg' => $res['response_msg'] ?? 'No data from backend',
            'result' => null
        ];
    }

    private function getMonitorStats(array $data): array
    {
        // Convert range to seconds if present
        if (isset($data['range'])) {
            $data['range'] = $this->convertRangeToSeconds($data['range']);
        }
        $commands = [[
            'method' => 'sla-mgmt.get_monitor_stats',
            'id' => 'stats',
            'data' => $data,
        ]];

        $gw_response = $this->gs->sendCommandGW($commands, $this->token);
        $indexed = array_column($gw_response['commands'] ?? [], null, 'id');
        $cmd = $indexed['stats'] ?? [];
        if (($cmd['status'] ?? null) === 'success' && isset($cmd['result'])) {
            return [
                'status' => 'success',
                'method' => 'sla-mgmt.get_monitor_stats',
                'response_msg' => 'Monitor statistics retrieved successfully',
                'result' => $cmd['result']
            ];
        }
        return [
            'status' => 'error',
            'method' => 'sla-mgmt.get_monitor_stats',
            'response_msg' => $cmd['response_msg'] ?? 'No data from backend',
            'result' => null
        ];
    }

    /**
     * Converts a range string like '1h', '15m', '30s' to seconds (int).
     * @param string|int $range
     * @return int
     */
    private function convertRangeToSeconds(string|int $range): int
    {
        if (is_numeric($range)) {
            return (int)$range;
        }
        if (preg_match('/^(\d+)\s*h$/i', $range, $m)) {
            return (int)$m[1] * 3600;
        }
        if (preg_match('/^(\d+)\s*m$/i', $range, $m)) {
            return (int)$m[1] * 60;
        }
        if (preg_match('/^(\d+)\s*s$/i', $range, $m)) {
            return (int)$m[1];
        }
        // Default fallback: 3600s (1h)
        return 3600;
    }


    /**
     * Generic helper to fetch time-series metrics from gateway and normalize response.
     * @param string $command
     * @param string $module
     * @param string $responseKey
     * @param string $metricName
     * @param string|int $range
     * @param array $extraData
     * @param callable|null $rowTransform
     * @param string $direction 'both'|'tx'|'rx'|'none'
     * @return array
     */
    private function fetchTimeSeriesMetric(
        string $command,
        string $module,
        string $responseKey,
        string $metricName,
        string|int $range,
        array $extraData = [],
        ?callable $rowTransform = null,
        string $direction = 'both'
    ): array
    {
        $data = array_merge(['range' => $range], $extraData);
        $expectedMethod = $module . '.' . $command;
        $commands = [[
            'method' => $expectedMethod,
            'id' => 'metric',
            'data' => $data,
        ]];

        $gw_response = $this->gs->sendCommandGW($commands, $this->token);

        $indexed = array_column($gw_response['commands'] ?? [], null, 'id');
        $cmd = $indexed['metric'] ?? null;

        if ($cmd && ($cmd['status'] ?? null) === 'success' && isset($cmd['result'][$responseKey])) {
            $rows = $cmd['result'][$responseKey];
            $labels = array_column($rows, 'timestamp');

            // If iface-style metrics requested, detect interfaces and build structured metrics
            if ($direction !== 'none' && !empty($rows) && preg_match('/_(tx|rx)$/', array_keys($rows[0])[1] ?? '')) {
                $ifaces = [];
                foreach ($rows[0] as $key => $val) {
                    if (preg_match('/^(.*)_(tx|rx)$/', $key, $m)) {
                        $ifaces[$m[1]] = true;
                    }
                }
                $ifaces = array_keys($ifaces);
                $dataOut = [];
                foreach ($ifaces as $ifaceName) {
                    if ($direction === 'tx' || $direction === 'both') {
                        $tx = array_column($rows, $ifaceName . '_tx');
                    } else {
                        $tx = [];
                    }
                    if ($direction === 'rx' || $direction === 'both') {
                        $rx = array_column($rows, $ifaceName . '_rx');
                    } else {
                        $rx = [];
                    }
                    if ($direction === 'both') {
                        $dataOut[$ifaceName] = ['tx' => $tx, 'rx' => $rx];
                    } elseif ($direction === 'tx') {
                        $dataOut[$ifaceName] = $tx;
                    } else {
                        $dataOut[$ifaceName] = $rx;
                    }
                }
                return [
                    'status' => 'success',
                    'method' => $cmd['method'] ?? $expectedMethod,
                    'response_msg' => 'Metric data retrieved successfully',
                    'result' => [
                        'metric' => $metricName,
                        'range' => $range,
                        'labels' => $labels,
                        'ifaces' => $ifaces,
                        'metrics' => $dataOut
                    ]
                ];
            }

            // Softnet multiline detection: keys like cpu0_drop_pct, total_drop_pct
            if ($direction === 'softnet' && !empty($rows)) {
                $SOFTNET_SUFFIXES = ['_processed_pps', '_dropped_pps', '_drop_pct', '_squeeze_ps', '_squeeze_pct'];
                $firstRow = $rows[0];
                $suffix = null;
                foreach ($SOFTNET_SUFFIXES as $sfx) {
                    foreach ($firstRow as $key => $val) {
                        if ($key !== 'timestamp' && str_ends_with($key, $sfx)) {
                            $suffix = $sfx;
                            break 2;
                        }
                    }
                }
                if ($suffix !== null) {
                    $cpus = [];
                    foreach ($firstRow as $key => $val) {
                        if ($key !== 'timestamp' && str_ends_with($key, $suffix)) {
                            $cpus[] = substr($key, 0, -strlen($suffix));
                        }
                    }
                    // Sort: cpu0..cpuN numerically, then total last
                    usort($cpus, function (string $a, string $b) {
                        if ($a === 'total') return 1;
                        if ($b === 'total') return -1;
                        $aNum = (int) substr($a, 3);
                        $bNum = (int) substr($b, 3);
                        return $aNum - $bNum;
                    });
                    $dataOut = [];
                    foreach ($cpus as $cpu) {
                        $dataOut[$cpu] = array_column($rows, $cpu . $suffix);
                    }
                    return [
                        'status' => 'success',
                        'method' => $cmd['method'] ?? $expectedMethod,
                        'response_msg' => 'Softnet metric data retrieved successfully',
                        'result' => [
                            'metric' => $metricName,
                            'range' => $range,
                            'labels' => $labels,
                            'ifaces' => $cpus,
                            'metrics' => $dataOut
                        ]
                    ];
                }
            }

            $metrics = $rowTransform ? array_map($rowTransform, $rows) : $rows;
            return [
                'status' => 'success',
                'method' => $cmd['method'] ?? $expectedMethod,
                'response_msg' => 'Metric data retrieved successfully',
                'result' => [
                    'metric' => $metricName,
                    'range' => $range,
                    'labels' => $labels,
                    'metrics' => $metrics
                ]
            ];
        }

        return [
            'status' => 'error',
            'method' => $cmd['method'] ?? $expectedMethod,
            'response_msg' => $cmd['response_msg'] ?? $gw_response['response_msg'] ?? 'No data from backend',
            'result' => null
        ];
    }

}
