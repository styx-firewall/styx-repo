<?php

namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class BearerTokenSubmitController extends BaseController
{
    /**
     * Generate a new bearer token for API access.
     *
     * @param array $data Should contain 'name' (string) and optional 'expires_at' (string|null).
     *                    Accepted formats: full timestamp with zone, date-only (YYYY-MM-DD), or naive datetime.
     * @return array Gateway command response for `generate_bearer_token` or error array
     */
    public function generateToken(array $data): array
    {
        $name = $data['name'] ?? '';
        $expiresAt = $data['expires_at'] ?? null;

        // Normalize expires_at to UTC with trailing Z when possible.
        // Accepts:
        // - full timestamp with zone (e.g. 2026-03-01T12:00:00+01:00) -> converted to UTC Z
        // - date-only (YYYY-MM-DD) -> treated as YYYY-MM-DDT00:00:00Z
        // - naive datetime (YYYY-MM-DDTHH:MM:SS) -> assume UTC and append Z
        if (!empty($expiresAt)) {
            // If string ends with Z or an offset like +01:00/-05:00
            if (preg_match('/(?:Z|[+\-]\d{2}:?\d{2})$/', $expiresAt)) {
                try {
                    $dt = new \DateTimeImmutable($expiresAt);
                    $dtUtc = $dt->setTimezone(new \DateTimeZone('UTC'));
                    // Format as 2036-03-01T00:00:00Z
                    $expiresAt = $dtUtc->format('Y-m-d\\TH:i:s\\Z');
                } catch (\Exception $e) {
                    // If parsing fails, leave original and let backend validate
                }
            } elseif (preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiresAt)) {
                // Date-only -> midnight UTC
                $expiresAt = $expiresAt . 'T00:00:00Z';
            } else {
                // Naive datetime without timezone -> assume UTC
                $expiresAt = $expiresAt . 'Z';
            }
        }

        if (empty($name)) {
            return $this->baseError('Token name is required');
        }

        $commands = [
            [
                'method' => 'auth.generate_bearer_token',
                'id' => 'generate_bearer_token',
                'data' => [
                    'name' => $name,
                    'expires_at' => $expiresAt,
                ],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['generate_bearer_token'] ?? $this->baseError('No response for generate_bearer_token');
    }

     /**
      * Revoke an existing bearer token.
      *
      * @param array $data Should contain 'token_id' (string)
      * @return array Gateway command response for `revoke_bearer_token` or error array
      */
     public function revokeToken(array $data): array
    {
        $tokenId = $data['token_id'] ?? '';

        if (empty($tokenId)) {
            return $this->baseError('Token ID is required');
        }

        $commands = [
            [
                'method' => 'auth.revoke_bearer_token',
                'id' => 'revoke_bearer_token',
                'data' => [
                    'token_id' => $tokenId,
                ],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['revoke_bearer_token'] ?? $this->baseError('No response for revoke_bearer_token');
    }

     /**
      * List all bearer tokens for the current user.
      *
      * @param array $data (unused) kept for signature compatibility
      * @return array Gateway command response for `get_bearer_tokens` or error array
      */
     public function listTokens(array $data): array
    {
        $commands = [
            [
                'method' => 'auth.get_bearer_tokens',
                'id' => 'get_bearer_tokens',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['get_bearer_tokens'] ?? $this->baseError('No response for get_bearer_tokens');
    }
}
