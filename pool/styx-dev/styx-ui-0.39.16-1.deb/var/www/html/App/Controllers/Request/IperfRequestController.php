<?php

namespace App\Controllers\Request;

use App\Controllers\BaseController;

class IperfRequestController extends BaseController
{
    /**
     * Get iperf page data (server status)
     * @return array
     */
    public function getIperfPageData()
    {
        $commands = [
            [
                'method' => 'iperf-service.server_status',
                'id' => 'server_status',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['server_status'] ?? null;
        return [
            'status'   => $resp['status'],
            'result'   => [
                'server_status' => ($cmd && ($cmd['status'] ?? null) === 'success') ? ($cmd['result'] ?? null) : null,
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get server status and tasks in a single gateway call
     * @param array $data
     * @return array
     */
    public function getStatusAndTasks($data)
    {
        $commands = [
            [
                'method' => 'iperf-service.server_status',
                'id' => 'server_status',
                'data' => (object)[],
            ],
            [
                'method' => 'iperf-service.get_iperf_tasks',
                'id' => 'get_iperf_tasks',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $serverCmd = $resp['commands']['server_status'] ?? null;
        $tasksCmd = $resp['commands']['get_iperf_tasks'] ?? null;

        $result = [
            'server_status' => ($serverCmd && ($serverCmd['status'] ?? null) === 'success') ? ($serverCmd['result'] ?? null) : null,
            'tasks' => ($tasksCmd && ($tasksCmd['status'] ?? null) === 'success') ? ($tasksCmd['result']['tasks'] ?? []) : [],
        ];

        return [
            'status' => 'success',
            'result' => $result,
        ];
    }

    /**
     * Get iperf server status (read-only)
     * @param array $data
     * @return array
     */
    public function serverStatus($data)
    {
        $commands = [
            [
                'method' => 'iperf-service.server_status',
                'id' => 'server_status',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['server_status'] ?? $this->baseError('No response for server_status');
    }

    /**
     * Get list of iperf tasks (read-only)
     * @param array $data
     * @return array
     */
    public function getIperfTasks($data)
    {
        $commands = [
            [
                'method' => 'iperf-service.get_iperf_tasks',
                'id' => 'get_iperf_tasks',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['get_iperf_tasks'] ?? $this->baseError('No response for get_iperf_tasks');
    }

    /**
     * Get result of a specific task (read-only)
     * @param array $data
     * @return array
     */
    public function getTaskResult($data)
    {
        if (empty($data['task_id'])) {
            return $this->baseError('task_id is required');
        }

        $commands = [
            [
                'method' => 'iperf-service.get_task_result',
                'id' => 'get_task_result',
                'data' => ['task_id' => $data['task_id']],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['get_task_result'] ?? $this->baseError('No response for get_task_result');
    }
}
