<?php

namespace App\Controllers;

use App\Core\AppContext;
use App\Services\GatewayService;
use App\Services\LogSystemService;
use App\Services\AuthService;
use App\Core\Config;

/**
 * Common base controller shared by Request and Submit controllers.
 */
abstract class BaseController
{
    protected AppContext $ctx;
    protected GatewayService $gs;
    protected LogSystemService $logService;
    protected Config $cfg;
    /** @var string|null */
    protected ?string $token = null;

    protected const ERROR_UNAUTHORIZED = 'UNAUTHORIZED';
    protected const ERROR_FORBIDDEN = 'FORBIDDEN';

    public function __construct(AppContext $ctx)
    {
        $this->ctx = $ctx;
        $this->logService = $ctx->get(LogSystemService::class);
        $this->gs = $ctx->get(GatewayService::class);
        $this->cfg = $ctx->get(Config::class);
    }

    /**
     * Send commands to the gateway.
     * Accepts an optional token and optional timeouts array.
     * When token is null, uses the stored token or the AuthService to obtain one.
     */
    protected function sendCommands(array $commands, ?string $token = null, array $timeouts = []): array
    {
        $auth = $this->ctx->get(AuthService::class);
        $tokenToUse = $token ?? $this->token ?? $auth->getUserToken();
        return $this->gs->sendCommandGW($commands, $tokenToUse, $timeouts);
    }

    /**
     * Process gateway response and index commands by their `id`.
     * Returns status 'success', 'partial' or 'error'.
     */
    protected function processGwResp(array $gw_response): array
    {
        $indexed = [];
        $warnings = [];
        $total = 0;

        if (($gw_response['status'] ?? null) !== 'success') {
            $resp = $this->baseError($gw_response['response_msg'] ?? 'Gateway response error');
            if (!empty($gw_response['error_code'])) {
                $resp['error_code'] = $gw_response['error_code'];
            }
            return $resp;
        }
        if (empty($gw_response['commands']) || !is_array($gw_response['commands'])) {
            return $this->baseError('Invalid gateway response');
        }

        foreach ($gw_response['commands'] as $cmd) {
            $total++;
            if (isset($cmd['id'])) {
                $indexed[$cmd['id']] = $cmd;
            }
            if (($cmd['status'] ?? null) !== 'success') {
                $errorCode = $cmd['error_code'] ?? null;
                // UNAUTHORIZED and FORBIDDEN are backend-level access errors;
                // surface them directly so the frontend can act accordingly.
                if ($errorCode === self::ERROR_UNAUTHORIZED || $errorCode === self::ERROR_FORBIDDEN) {
                    $fallback = $errorCode === self::ERROR_UNAUTHORIZED ? 'Session expired' : 'Access denied';
                    return [
                        'status'       => 'error',
                        'error_code'   => $errorCode,
                        'response_msg' => $cmd['response_msg'] ?? $fallback,
                        'commands'     => $indexed,
                        'warnings'     => [],
                    ];
                }

                $id = $cmd['id'] ?? '(no-id)';
                $msg = 'Unknown error';
                // Prefer explicit `result.msg` returned by some backends, then `result.message`,
                // then fall back to `response_msg` for compatibility.
                if (isset($cmd['result']) && is_array($cmd['result'])) {
                    if (!empty($cmd['result']['msg']) && is_string($cmd['result']['msg'])) {
                        $msg = $cmd['result']['msg'];
                    } elseif (!empty($cmd['result']['message']) && is_string($cmd['result']['message'])) {
                        $msg = $cmd['result']['message'];
                    }
                }
                if ($msg === 'Unknown error' && !empty($cmd['response_msg']) && is_string($cmd['response_msg'])) {
                    $msg = $cmd['response_msg'];
                }
                // errorCode here is never UNAUTHORIZED/FORBIDDEN (handled above)
                if ($errorCode !== null) {
                    $msg = "[{$errorCode}] {$msg}";
                }
                $warnings[] = "{$id}: {$msg}";
                $this->logService->error('Gateway command failed: ' . ($cmd['method'] ?? '(unknown)') . " (id: {$id}) - {$msg}");
            }
        }

        if ($total === 0) {
            return $this->baseError('No commands in gateway response');
        }

        if (count($warnings) === $total) {
            $combined = implode(' | ', $warnings);
            return [
                'status' => 'error',
                'response_msg' => 'All gateway commands failed: ' . $combined,
                'commands' => $indexed,
                'warnings' => $warnings,
            ];
        }

        return [
            'status' => empty($warnings) ? 'success' : 'partial',
            'commands' => $indexed,
            'warnings' => $warnings,
        ];
    }

    /**
     * Standard error response. Optionally include extra data under `result`.
     */
    protected function baseError(string $msg, ?array $data = null): array
    {
        $this->logService->error('Request error: ' . $msg);
        $resp = [
            'status' => 'error',
            'response_msg' => $msg,
        ];
        if ($data !== null) {
            $resp['result'] = $data;
        } else {
            $resp['warnings'] = [];
        }
        return $resp;
    }

    /**
     * 
     */
    protected function setToken(string $token): void
    {
        $this->token = $token;
    }
}
