<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class TCRequestController extends BaseController
{

    /**
     * Get Traffic Control configuration from the gateway
     */
    public function getTcConfig()
    {
        $commands = [
            [
                'method' => 'tc-config.get_tc_config',
                'id' => 'config',
                'data' => (object)[]
            ]
        ];
        // also request the list of valid qdiscs from the gateway
        $commands[] = [
            'method' => 'tc-config.get_valid_qdisc',
            'id' => 'valid_qdisc',
            'data' => (object)[]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => [
                'config' => $resp['commands']['config']['result'] ?? [],
                'valid_qdisc' => $resp['commands']['valid_qdisc']['result']['valid_qdisc'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get Traffic Control statistics from the gateway
     */
    public function getTcStats()
    {
        $commands = [
            [
                'method' => 'tc-config.get_tc_stats',
                'id' => 'stats',
                'data' => (object)[]
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['stats']['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }
}
