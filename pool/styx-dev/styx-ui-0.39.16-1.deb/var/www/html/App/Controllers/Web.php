<?php

/**
 *
 *  @author diego/@/envigo.net
 *  @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 *  @dr 2025/12/22
 */

namespace App\Controllers;

use App\Core\AppContext;
use App\Core\Config;

use App\Controllers\Request\PageInitRequestController;
use App\Services\TemplateService;
use App\Services\AuthService;
use App\Services\Filter;
use App\Pages\PageDefaults;
use App\Pages\PageDashboard;
use App\Pages\PageFirewall;
use App\Pages\PageRealtime;
use App\Pages\PageSystem;
use App\Pages\PageVPN;
use App\Pages\PageIdsIps;
use App\Pages\PageNetwork;
use App\Pages\PageStyx;
use App\Pages\PageUsers;
use App\Pages\PageLogs;
use App\Pages\PageLogin;
use App\Pages\PageTs;
use App\Pages\PagePacketMarking;
use App\Pages\PageServices;
use App\Pages\PageEbpf;
use App\Pages\PageObjects;
use App\Pages\PageSecurity;
use App\Pages\PageRouting;
use App\Helpers\RoleHelper;
class Web
{

    private AppContext $ctx;
    private Config $cfg;

    public function __construct(AppContext $ctx)
    {
        $this->ctx = $ctx;
        $this->cfg = $ctx->get(Config::class);
    }

    /**
     *
     * @return void
     */
    public function run(): void
    {
        $req_page = Filter::getString('page');
        empty($req_page) ? $req_page = 'index' : null;

        // Allow free access to login and logout (logout must not block on session lock)
        if ($req_page !== 'login' && $req_page !== 'logout') {
            $auth = $this->ctx->get(AuthService::class);
            if (!($auth instanceof AuthService) || !$auth->isAuthenticated()) {
                // Redirect to login if not authenticated
                header('Location: ?page=login');
                exit;
            }
        }

        // Fetch page init data from backend and store in config
        $initResponse = [];
        if ($req_page !== 'login' && $req_page !== 'logout') {
            $pageInitController = new PageInitRequestController($this->ctx);
            $initResponse = $pageInitController->getInitData();

            $this->cfg->set('features', $initResponse['result']['features'] ?? []);
            $this->cfg->set('config_changed', (bool)($initResponse['result']['config_changed'] ?? false));
            $this->cfg->set('restart_required', (bool)($initResponse['result']['restart_required'] ?? false));
        }

        // Page-level capability gating
        if ($req_page !== 'login' && $req_page !== 'logout') {
            $auth = $this->ctx->get(AuthService::class);
            if (!$auth->hasCapabilitiesLoaded()) {
                // Stale session (pre-RBAC login): force re-authentication
                header('Location: ?page=logout');
                return;
            }
            $requiredCap = RoleHelper::getPageCapability($req_page);
            if ($requiredCap !== null && !RoleHelper::hasCapability($auth->getCapabilities(), $requiredCap)) {
                $pageData = $this->get('index');
                $pageData['page_data']['error'] = 'You do not have permission to access this page.';
                $pageData['page_data']['page'] = 'dashboard';
                $this->render($pageData);
                return;
            }
        }

        // Handle logout before get() to avoid the unnecessary PageDefaults call.
        if ($req_page === 'logout') {
            $fastLogout = Filter::getString('fast') === '1';

            if ($fastLogout) {
                // Fast path (connection-error modal): cookie-only logout.
                // session_start() would block if another request holds the session
                // file lock while waiting for the backend gateway.
                $cookieName    = $this->cfg->get('session.cookie_name', 'styx_session');
                $cookieSecure  = (bool) $this->cfg->get('session.secure', true);
                $cookieHttpOnly = (bool) $this->cfg->get('session.http_only', true);
                $cookieSameSite = $this->cfg->get('session.samesite', 'Strict');
                $cookieDomain   = $this->cfg->get('session.cookie_domain', '');

                setcookie($cookieName, '', [
                    'expires'  => time() - 42000,
                    'path'     => '/',
                    'domain'   => $cookieDomain,
                    'secure'   => $cookieSecure,
                    'httponly' => $cookieHttpOnly,
                    'samesite' => $cookieSameSite,
                ]);
            } else {
                // Normal logout: full session destroy (clears server-side session + cookie).
                $auth = $this->ctx->get(AuthService::class);
                if ($auth instanceof AuthService) {
                    $auth->logout();
                }
            }

            header('Location: ?page=login');
            exit;
        }

        $pageData = $this->get($req_page);
        if (empty($pageData)) {
            header('Location: ?page=index');
            exit;
        }
        $this->render($pageData);
    }

    /**
     *
     * @param array<string,mixed> $page_data
     *
     * @return void
     */
    public function render(array $page_data): void
    {
        $frontend = new TemplateService($this->ctx);

        // Inject sidebar visibility as a global so the sidebar partial
        // can access it via $tdata['tpl_data']['sidebar_visible'].
        if (isset($page_data['sidebar_visible']) && is_array($page_data['sidebar_visible'])) {
            $frontend->addGlobal('sidebar_visible', $page_data['sidebar_visible']);
        }

        // Fragment mode (ajax=1): return only the rendered template, no page layout.
        if (Filter::getString('ajax') === '1' && isset($page_data['fragment_template'])) {
            header('Content-Type: text/html; charset=utf-8');
            echo $frontend->getTpl($page_data['fragment_template'], $page_data);
            return;
        }

        $frontend->showPage($page_data);
    }

    /**
     * Get the data for the requested page.
     *
     * @param string $page Name of the page to retrieve
     *
     * @return array<string,mixed> Page data, merging default and page-specific data.
     */
    private function get(string $page): array
    {
        $pageDefaults = PageDefaults::get($this->ctx, $page);
        $pageData = [];

        switch ($page) {
            case 'login':
                $pageData = PageLogin::get($this->ctx);
                break;
            case 'index':
            case 'dashboard':
                $pageData = PageDashboard::get($this->ctx);
                break;
            case 'network':
                $pageData = PageNetwork::get($this->ctx);
                break;
            case 'firewall':
                $pageData = PageFirewall::get($this->ctx);
                break;
            case 'services':
                $pageData = PageServices::get($this->ctx);
                break;
            case 'traffic_shaping':
                $pageData = PageTs::get($this->ctx);
                break;
            case 'packet_marking':
                $pageData = PagePacketMarking::get($this->ctx);
                break;
            case 'system':
                $pageData = PageSystem::get($this->ctx);
                break;
            case 'vpn':
                $pageData = PageVPN::get($this->ctx);
                break;
            case 'idsips':
                $pageData = PageIdsIps::get($this->ctx);
                break;
            case 'ebpf':
                $pageData = PageEbpf::get($this->ctx);
                break;
            case 'objects':
                $pageData = PageObjects::get($this->ctx);
                break;
            case 'routing':
                $pageData = PageRouting::get($this->ctx);
                break;
            case 'styx':
                $pageData = PageStyx::get($this->ctx);
                break;
            case 'security':
                $pageData = PageSecurity::get($this->ctx);
                break;
            case 'users':
                $pageData = PageUsers::get($this->ctx);
                break;
            case 'logs':
                $pageData = PageLogs::get($this->ctx);
                break;
            default:
                return [];
        }

        return array_merge_recursive($pageDefaults, $pageData);
    }
}
