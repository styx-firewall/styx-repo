<?php
namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class TCSubmitController extends BaseController
{

    /**
     * Add a new Qdisc
     * @param array $data
     * @return array
     */
    public function addQdisc($data)
    {
        $data = $this->parseQDiscParams($data);
        $cmd = [
            'method' => 'tc-config.add_tc_qdisc',
            'id' => 'add_tc_qdisc',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_tc_qdisc'] ?? $this->baseError('No response for add_tc_qdisc');
    }

    /**
     * Delete a Qdisc
     * @param array $data
     * @return array
     */
    public function deleteQdisc($data)
    {
        $cmd = [
            'method' => 'tc-config.delete_tc_qdisc',
            'id' => 'delete_tc_qdisc',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_tc_qdisc'] ?? $this->baseError('No response for delete_tc_qdisc');
    }

    /**
     * Edit an existing Qdisc
     * @param array $data
     * @return array
     */
    public function editQdisc($data)
    {
        $data = $this->parseQdiscParams($data);
        $cmd = [
            'method' => 'tc-config.edit_tc_qdisc',
            'id' => 'edit_tc_qdisc',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['edit_tc_qdisc'] ?? $this->baseError('No response for edit_tc_qdisc');
    }
    /**
     * Remove a Qdisc (alternative to delete)
     * @param array $data
     * @return array
     */
    public function removeQdisc($data)
    {
        $cmd = [
            'method' => 'tc-config.remove_tc_qdisc',
            'id' => 'remove_tc_qdisc',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['remove_tc_qdisc'] ?? $this->baseError('No response for remove_tc_qdisc');
    }

    private const VALID_CLASS_PARAMS = [
        'rate', 'ceil', 'prio', 'burst', 'cburst', 'quantum', 'mtu',
        'rt', 'ls', 'ul', 'd', 'm1', 'd1', 'm2', 'd2',
        'bands', 'priomap',
    ];

    // Keys that are flags (no value) in tc qdisc options
    private const QDISC_FLAG_KEYS = [
        'nat', 'nonat',
        'wash', 'nowash',
        'split-gso', 'no-split-gso',
        'ack-filter', 'no-ack-filter', 'ack-filter-aggressive',
        'ecn', 'noecn',
        'raw',
        'ingress',
    ];

    /**
     * Add a new TC class (channel)
     * @param array $data
     * @return array
     */
    public function addClass($data)
    {
        if (!empty($data['params'])) {
            $parsed = $this->parseParamsToObject($data['params'], self::VALID_CLASS_PARAMS);
            if (isset($parsed['error'])) {
                return $this->baseError($parsed['error']);
            }
            foreach ($parsed as $k => $v) {
                $data[$k] = $v;
            }
            unset($data['params']);
        }
        // Parse child_qdisc params into structured options object
        if (!empty($data['child_qdisc']['params'])) {
            $childOptions = $this->parseParamsToObject($data['child_qdisc']['params'], null, true);
            if (isset($childOptions['error'])) {
                return $this->baseError('child_qdisc: ' . $childOptions['error']);
            }
            $data['child_qdisc']['options'] = $childOptions;
            unset($data['child_qdisc']['params']);
        } elseif (!empty($data['child_qdisc']) && empty($data['child_qdisc']['params'])) {
            // Child qdisc kind selected but no params: set empty options
            $data['child_qdisc']['options'] = [];
            unset($data['child_qdisc']['params']);
        }
        $cmd = [
            'method' => 'tc-config.add_class',
            'id' => 'add_class',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_class'] ?? $this->baseError('No response for add_class');
    }

    /**
     * Delete a TC class (channel)
     * @param array $data
     * @return array
     */
    public function deleteClass($data)
    {
        $cmd = [
            'method' => 'tc-config.delete_class',
            'id' => 'delete_class',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_class'] ?? $this->baseError('No response for delete_class');
    }


    /**
     * Parse a params string into an associative array.
     * Supports two formats (auto-detected, not mixed):
     *
     * 1. Comma+colon:  "key: value, key: value"
     * 2. Space-separated (native tc style):  "key value key value flag flag"
     *
     * Known flags (only in space-separated mode) become [flag => true].
     * If $validKeys is provided, unknown keys cause an error.
     *
     * @param string $paramsStr
     * @param array|null $validKeys  Known valid keys (null = no validation)
     * @param bool $allowFlags       Whether flag-only tokens are allowed (space format only)
     * @return array  Parsed pairs, or ['error' => msg] on validation failure
     */
    private function parseParamsToObject(string $paramsStr, ?array $validKeys = null, bool $allowFlags = false): array
    {
        $paramsStr = trim($paramsStr);
        if ($paramsStr === '') {
            return [];
        }

        // Detect format: if the string contains ':', use comma+colon format
        if (strpos($paramsStr, ':') !== false) {
            return $this->parseColonFormat($paramsStr, $validKeys);
        }

        // Otherwise, use the legacy space-separated format
        return $this->parseSpaceFormat($paramsStr, $validKeys, $allowFlags);
    }

    /**
     * Parse comma+colon format: "key: value, key: value"
     */
    private function parseColonFormat(string $paramsStr, ?array $validKeys = null): array
    {
        $result = [];
        $pairs = explode(',', $paramsStr);
        foreach ($pairs as $pair) {
            $pair = trim($pair);
            if ($pair === '') {
                continue;
            }
            $parts = explode(':', $pair, 2);
            if (count($parts) !== 2) {
                return ['error' => "Invalid pair format (expected 'key: value'): $pair"];
            }
            $key = trim($parts[0]);
            $value = trim($parts[1]);
            if ($key === '') {
                return ['error' => "Empty key in pair: $pair"];
            }
            if ($validKeys !== null && !in_array($key, $validKeys, true)) {
                return ['error' => "Unknown parameter: $key"];
            }
            $result[$key] = $value;
        }
        return $result;
    }

    /**
     * Parse space-separated native-tc-style format: "key value key value flag flag"
     */
    private function parseSpaceFormat(string $paramsStr, ?array $validKeys = null, bool $allowFlags = false): array
    {
        $result = [];
        $tokens = preg_split('/\s+/', $paramsStr);
        if ($tokens === false || (count($tokens) === 1 && $tokens[0] === '')) {
            return $result;
        }
        $count = count($tokens);
        for ($i = 0; $i < $count; $i++) {
            $token = $tokens[$i];
            if ($token === '') {
                continue;
            }
            $isFlag = $allowFlags && in_array($token, self::QDISC_FLAG_KEYS, true);
            if ($isFlag) {
                $result[$token] = true;
                continue;
            }
            // Key that expects a value
            if ($validKeys !== null && !in_array($token, $validKeys, true)) {
                return ['error' => "Unknown parameter: $token"];
            }
            if ($i + 1 >= $count) {
                return ['error' => "Missing value for parameter: $token"];
            }
            $next = $tokens[$i + 1];
            if ($allowFlags && in_array($next, self::QDISC_FLAG_KEYS, true)) {
                return ['error' => "Missing value for parameter: $token"];
            }
            $result[$token] = $next;
            $i++; // consume value token
        }
        return $result;
    }

    /**
     * Parse parameters for Qdisc (special logic for some keys)
     * @param array $data
     * @return array
     */
    private function parseQDiscParams($data)
    {
        if (!empty($data['params'])) {
            $paramsStr = $data['params'];
            $paramsArr = array_map('trim', explode(',', $paramsStr));
            $cleanParams = [];
            foreach ($paramsArr as $param) {
                if (strpos($param, ':') !== false) {
                    list($k, $v) = array_map('trim', explode(':', $param, 2));
                    // bandwidth: unlimited => do not include
                    if ($k === 'bandwidth' && strtolower($v) === 'unlimited') {
                        continue;
                    }
                    // nat: true|false => nat|nonat
                    if ($k === 'nat') {
                        if (strtolower($v) === 'true') {
                            $cleanParams[] = 'nat';
                        } elseif (strtolower($v) === 'false') {
                            $cleanParams[] = 'nonat';
                        } else {
                            $cleanParams[] = 'nat';
                        }
                        continue;
                    }
                    // wash: true|false => wash|nowash
                    if ($k === 'wash') {
                        if (strtolower($v) === 'true') {
                            $cleanParams[] = 'wash';
                        } elseif (strtolower($v) === 'false') {
                            $cleanParams[] = 'nowash';
                        } else {
                            $cleanParams[] = 'wash';
                        }
                        continue;
                    }
                    // split_gso: true|false => split-gso|no-split-gso
                    if ($k === 'split_gso') {
                        if (strtolower($v) === 'true') {
                            $cleanParams[] = 'split-gso';
                        } elseif (strtolower($v) === 'false') {
                            $cleanParams[] = 'no-split-gso';
                        }
                        continue;
                    }
                    // ack-filter: true|false|ack-filter-aggressive => ack-filter|no-ack-filter|ack-filter-aggressive
                    if ($k === 'ack-filter') {
                        $vLower = strtolower($v);
                        if ($vLower === 'true') {
                            $cleanParams[] = 'ack-filter';
                        } elseif ($vLower === 'false') {
                            $cleanParams[] = 'no-ack-filter';
                        } elseif ($vLower === 'ack-filter-aggressive') {
                            $cleanParams[] = 'ack-filter-aggressive';
                        }
                        continue;
                    }
                    // ecn: true|false => ecn|noecn
                    if ($k === 'ecn') {
                        if (strtolower($v) === 'true') {
                            $cleanParams[] = 'ecn';
                        } elseif (strtolower($v) === 'false') {
                            $cleanParams[] = 'noecn';
                        }
                        continue;
                    }
                    // raw: true|false => raw|do not send anything if false
                    if ($k === 'raw') {
                        if (strtolower($v) === 'true') {
                            $cleanParams[] = 'raw';
                        }
                        // If false, nothing is sent
                        continue;
                    }
                    // diffserv: send the value as-is (diffserv: value)
                    if ($k === 'diffserv') {
                        $cleanParams[] = $v;
                        continue;
                    }
                    // ingress: true|false => include only if true
                    if ($k === 'ingress') {
                        if (strtolower($v) === 'true') {
                            $cleanParams[] = 'ingress';
                        }
                        // If false, nothing is sent
                        continue;
                    }
                    if ($k === 'flowmode') {
                        $cleanParams[] = $v;
                        continue;
                    }
                    // atm: send only the value
                    if ($k === 'atm') {
                        $cleanParams[] = $v;
                        continue;
                    }
                    // The rest is left as-is
                    $cleanParams[] = $k . ':' . $v;
                } else {
                    // If only the key is provided (e.g., nat), keep it as-is
                    $cleanParams[] = trim($param);
                }
            }
            $data['params'] = implode(', ', $cleanParams);
        }
        return $data;
    }

    /**
     * Add a new TC rule (upsert by id).
     * Structured mode: classifier + classifier-specific fields with UUID pickers.
     * Custom mode: classifier + raw `filter` string.
     * @param array $data
     * @return array
     */
    public function addRule($data)
    {
        $required = ['name', 'direction', 'interface_uuid', 'classifier'];
        foreach ($required as $field) {
            if (!isset($data[$field]) || $data[$field] === '') {
                return $this->baseError("Missing required field: $field");
            }
        }
        $direction = $data['direction'] ?? '';
        if ($direction !== 'egress' && $direction !== 'ingress') {
            return $this->baseError('Invalid direction: ' . $direction);
        }
        // Strip empty optional fields so the backend can apply defaults/merge logic
        foreach ($data as $k => $v) {
            if ($v === '' && !in_array($k, $required, true)) {
                unset($data[$k]);
            }
        }
        $cmd = [
            'method' => 'tc-config.add_tc_rule',
            'id' => 'add_tc_rule',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['add_tc_rule'] ?? $this->baseError('No response for add_tc_rule');
    }

    /**
     * Edit an existing TC rule.
     * Requires `id`. Only changed fields are sent; omitted fields keep current value.
     * If the rule is active, backend does tc filter del + tc filter add.
     * @param array $data
     * @return array
     */
    public function editRule($data)
    {
        if (empty($data['id'])) {
            return $this->baseError('Missing rule id');
        }
        $cmd = [
            'method' => 'tc-config.edit_tc_rule',
            'id' => 'edit_tc_rule',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['edit_tc_rule'] ?? $this->baseError('No response for edit_tc_rule');
    }

    /**
     * Delete a TC rule permanently from datastore and OS.
     * @param array $data
     * @return array
     */
    public function deleteRule($data)
    {
        if (empty($data['id'])) {
            return $this->baseError('Missing rule id');
        }
        $cmd = [
            'method' => 'tc-config.delete_tc_rule',
            'id' => 'delete_tc_rule',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_tc_rule'] ?? $this->baseError('No response for delete_tc_rule');
    }

    /**
     * Toggle (activate/deactivate) a TC rule without deleting from datastore.
     * Requires `id`, `interface_uuid`, and `active` (boolean).
     * active=true > tc filter add + mark active=true
     * active=false > tc filter del + mark active=false
     * @param array $data
     * @return array
     */
    public function toggleRule($data)
    {
        if (empty($data['id'])) {
            return $this->baseError('Missing rule id');
        }
        if (!array_key_exists('active', $data)) {
            return $this->baseError('Missing active field');
        }
        $cmd = [
            'method' => 'tc-config.toggle_tc_rule',
            'id' => 'toggle_tc_rule',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['toggle_tc_rule'] ?? $this->baseError('No response for toggle_tc_rule');
    }

}
