<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class NatRequestController extends BaseController
{
    public function getNatRules(): array
    {
        $commands = [
            [
                'method' => 'firewall-rules.get_nat_rules',
                'id'     => 'nat_rules',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['nat_rules']['result']['nftables'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getNatPageData(): array
    {
        $commands = [
            [
                'method' => 'firewall-rules.get_nat_rules',
                'id'     => 'nat_rules',
                'data'   => (object)[],
            ],
            [
                'method' => 'sets-mgmt.get_address',
                'id'     => 'addresses',
                'data'   => ['scope' => ['network', 'host']],
            ],
            [
                'method' => 'sets-mgmt.get_ports',
                'id'     => 'ports',
                'data'   => (object)[],
            ],
            [
                'method' => 'sets-mgmt.get_interfaces_sets',
                'id'     => 'ifaces_sets',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status'   => $resp['status'],
            'result'   => [
                'nftables'    => $cmds['nat_rules']['result']['nftables'] ?? [],
                'addresses'   => $cmds['addresses']['result']['address'] ?? [],
                'ports'       => $cmds['ports']['result']['ports'] ?? [],
                'ifaces_sets' => $cmds['ifaces_sets']['result']['interfaces'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getSetsData(): array
    {
        $commands = [
            [
                'method' => 'sets-mgmt.get_address',
                'id'     => 'addresses',
                'data'   => ['scope' => ['network', 'host']],
            ],
            [
                'method' => 'sets-mgmt.get_ports',
                'id'     => 'ports',
                'data'   => (object)[],
            ],
            [
                'method' => 'sets-mgmt.get_interfaces_sets',
                'id'     => 'ifaces_sets',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status'   => $resp['status'],
            'result'   => [
                'addresses'   => $cmds['addresses']['result']['address'] ?? [],
                'ports'       => $cmds['ports']['result']['ports'] ?? [],
                'ifaces_sets' => $cmds['ifaces_sets']['result']['interfaces'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }
}
