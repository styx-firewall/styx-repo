<?php

namespace App\Controllers\Request;
use App\Controllers\BaseController;

/**
 * Request controller for strongSwan IPSec VPN read operations.
 *
 * Handles: swan_get_page_data, swan_get_status, swan_get_connections.
 * All commands use module "strongswan" in the gateway envelope.
 */
class StrongswanRequestController extends BaseController
{
    private const MODULE = 'strongswan';

    /**
     * Route an incoming request to the appropriate handler method.
     *
     * @param array<string, mixed> $inputData  Raw decoded JSON from request.php.
     * @return array<string, mixed>
     */
    public function handle(array $inputData): array
    {
        $action = $inputData['action'] ?? $inputData['command'] ?? '';

        switch ($action) {
            case 'swan_get_page_data':
                return $this->getPageData();
            case 'swan_get_status':
                return $this->getStatus();
            case 'swan_get_connections':
                return $this->getConnections();
            default:
                return $this->baseError("Unknown strongSwan action: $action");
        }
    }

    /**
     * Fetch all strongSwan page data in a single aggregated call.
     * Returns connections, users, secrets, pools, certificates, status, and global_config.
     *
     * @return array<string, mixed>
     */
    public function getPageData(): array
    {
        $commands = [
            [
                'method' => self::MODULE . '.swan_get_page_data',
                'id' => 'page_data',
                'data' => (object)[],
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['page_data']['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get live IKE SA status for all connections.
     *
     * @return array<string, mixed>
     */
    public function getStatus(): array
    {
        $commands = [
            [
                'method' => self::MODULE . '.swan_get_status',
                'id' => 'status',
                'data' => (object)[],
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['status']['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Refresh the connection list.
     *
     * @return array<string, mixed>
     */
    public function getConnections(): array
    {
        $commands = [
            [
                'method' => self::MODULE . '.swan_get_connections',
                'id' => 'connections',
                'data' => (object)[],
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['connections']['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

}
