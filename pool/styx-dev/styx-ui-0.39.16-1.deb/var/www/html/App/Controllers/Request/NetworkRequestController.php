<?php
/**
 * Controller for network-related requests, such as routing and interfaces.
 * dp: 20260407
 */
namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class NetworkRequestController extends BaseController
{
    /**
     * Get interface config (network and sysctl settings)
     * @param string $iface_id Interface id
     * @param string $iface_subtype Optional interface subtype (e.g. vlan, veth). Send empty string if not provided.
     */
    public function getInterfaceConfig(string $iface_id, string $iface_subtype = '')
    {
        $features = $this->cfg->get('features', []);

        // iface_id is mandatory for this request
        if (empty($iface_id)) {
            return $this->baseError('iface_id not provided');
        }
        $commands[] = [
            'method' => 'network-config.get_valid_parents',
            'id' => 'parents',
            'data' => ['iface_subtype' => $iface_subtype, 'id' => $iface_id],
        ];

        $commands[] = [
            'method' => 'network-config.get_interface_config',
            'id' => 'iface_config',
            'data' => ['id' => $iface_id],
        ];
        $commands[] = [
            'method' => 'system-mgmt.get_ssh_config',
            'id' => 'ssh_config',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'styx-mgmt.get_lighttpd_config',
            'id' => 'lighttpd_config',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'network-config.get_interface_roles',
            'id' => 'roles',
            'data' => (object)[],
        ];
        if (!empty($features['network_tunning'])) {
            $commands[] = [
                'method' => 'sysctl-config.get_iface_sysctl_keys',
                'id' => 'iface_sysctl_keys',
                'data' => ['iface_id' => $iface_id]
            ];
        }

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        $result = [];
        foreach (['parents','iface_config', 'ssh_config', 'lighttpd_config', 'iface_sysctl_keys', 'roles'] as $cmdId) {
            $cmd = $cmds[$cmdId] ?? null;
            if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
                continue;
            }
            switch ($cmdId) {
                case 'parents':
                    $result['parents'] = $cmd['result']['parents'] ?? [];
                    // Normalize to `interfaces` so callers can rely on a single key
                    // (getValidParents already returns `result.interfaces`).
                    $result['interfaces'] = $result['parents'];
                    break;
                case 'iface_sysctl_keys':
                    $result['iface_sysctl_keys'] = $cmd['result']['iface_sysctl_keys'] ?? [];
                    break;
                case 'iface_config':
                    $result['interface_config'] = $cmd['result'] ?? [];
                    break;
                case 'ssh_config':
                    $result['ssh_config'] = $cmd['result'] ?? [];
                    break;
                case 'lighttpd_config':
                    $result['lighttpd_config'] = $cmd['result'] ?? [];
                    break;
                case 'roles':
                    $result['roles'] = $cmd['result']['roles'] ?? [];
                    break;
            }
        }
        return [
            'status'   => $resp['status'],
            'result'   => $result,
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get list of interfaces with reference counts
     */
    public function getInterfaces()
    {
        $commands = [];
        $commands[] = [
            'method' => 'network-config.get_interfaces_config',
            'id' => 'interfaces',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $interfaces = $resp['commands']['interfaces']['result']['interfaces'] ?? [];
        foreach ($interfaces as &$iface) {
            $iface['refs_count'] = !empty($iface['refs']) ? count($iface['refs']) : 0;
        }
        unset($iface);
        return [
            'status'   => $resp['status'],
            'result'   => ['interfaces' => $interfaces],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get valid parents for creating/editing virtual interfaces.
     * Returns response in same shape as getInterfaces (status + data.interfaces).
     * @param string $iface_subtype
     * @param string|null $id
     * @return array
     */
    public function getValidParents(string $iface_subtype, ?string $id = null): array
    {
        if (empty($iface_subtype)) {
            return $this->baseError('iface_subtype is required');
        }

        $commands = [];
        $commands[] = [
            'method' => 'network-config.get_valid_parents',
            'id' => 'parents',
            'data' => ['iface_subtype' => $iface_subtype, 'id' => $id],
        ];
        $commands[] = [
            'method' => 'network-config.get_interface_roles',
            'id' => 'roles',
            'data' => (object)[],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $parentsCmd = $resp['commands']['parents'] ?? null;
        $rolesCmd = $resp['commands']['roles'] ?? null;
        return [
            'status'   => $resp['status'],
            'result'   => [
                'interfaces'  => $parentsCmd['result']['parents'] ?? [],
                'roles' => $rolesCmd['result']['roles'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get sysctl keys
     */
    public function getSysctlKeys()
    {
        $commands[] = [
            'method' => 'sysctl-config.get_sysctl_keys',
            'id' => 'sysctl_keys',
            'data' => (object)[],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $sysctlCmd = $resp['commands']['sysctl_keys'] ?? null;
        if (!$sysctlCmd || ($sysctlCmd['status'] ?? null) !== 'success') {
            $this->logService->error('sysctl_keys failed: ' . ($sysctlCmd['response_msg'] ?? json_encode($sysctlCmd)));
            return $this->baseError($sysctlCmd['response_msg'] ?? 'sysctl_keys command failed');
        }
        $data = $sysctlCmd['result']['sysctl_keys'] ?? null;
        if (!is_array($data) || empty($data)) {
            $this->logService->error('No sysctl_keys found in response: ' . json_encode($sysctlCmd));
            return $this->baseError('No sysctl_keys found');
        }
        $predefined = [];
        $custom = [];
        foreach ($data as $item) {
            $type = $item['type'] ?? 'text';
            $input_type = $type === 'int' ? 'number' : ($type === 'bool' ? 'checkbox' : 'text');
            $checked = ($type === 'bool' && ($item['value'] === '1' || $item['value'] === 'true')) ? true : false;
            $normalize = function($str) {
                return preg_replace('/[ \t]+/', ' ', trim($str));
            };
            $processed = [
                'key' => $normalize($item['key']),
                'sysctl_key' => $normalize($item['sysctl_key']),
                'value' => $normalize($item['value'] ?? ''),
                'default' => $normalize($item['default'] ?? '-'),
                'comment' => !empty($item['comment']) ? $normalize($item['comment']) : '',
                'input_type' => $input_type,
                'checked' => $checked,
                'predefined' => !empty($item['predefined']),
            ];
            if ($processed['predefined']) {
                $predefined[] = $processed;
            } else {
                $custom[] = $processed;
            }
        }
        return [
            'status'   => $resp['status'],
            'result'   => ['predefined' => $predefined, 'custom' => $custom],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get interfaces names and ids for data source (for selectors)
     */
    public function getInterfacesNamesDs()
    {
        $commands = [];
        $commands[] = [
            'method' => 'network-config.get_interfaces_names_ds',
            'id' => 'ifaces_names_ds',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['ifaces_names_ds'] ?? null;
            if (!$cmd || ($cmd['status'] ?? null) !== 'success' || empty($cmd['result']['ifaces_names_ds'])) {
            return $this->baseError('No interfaces found in response');
        }
        return [
            'status'   => $resp['status'],
            'result'   => ['ifaces_list' => $cmd['result']['ifaces_names_ds']],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get valid roles for network interfaces.
     * @return array{status: string, result: array, warnings: string[]}
     */
    public function getValidRoles(): array
    {
        $commands = [];
        $commands[] = [
            'method' => 'network-config.get_interface_roles',
            'id'     => 'roles',
            'data'   => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['roles'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'Failed to retrieve valid roles');
        }
        return [
            'status'   => $resp['status'],
            'result'   => ['roles' => $cmd['result']['roles'] ?? []],
            'warnings' => $resp['warnings'],
        ];
    }
}
