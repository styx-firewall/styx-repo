<?php
namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class TrafficStatsSubmitController extends BaseController
{
    /**
     * Reset traffic statistics counters.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function resetStats(array $data): array
    {
        $commands = [[
            'method' => 'traffic-stats.reset_stats',
            'id' => 'reset_traffic',
            'data' => (object)[],
        ]];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['reset_traffic'] ?? $this->baseError('No response for reset_traffic');
    }
}
