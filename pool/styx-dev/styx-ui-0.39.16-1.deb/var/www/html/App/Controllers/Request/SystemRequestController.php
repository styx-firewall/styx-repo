<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class SystemRequestController extends BaseController
{
    /**
     * Get list of installed system applications
     */
    public function getSystemApps()
    {
        $commands = [
            [
                'method' => 'system-packages.get_packages',
                'id' => 'get_packages',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands, null, ['read_timeout' => 5]));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => ['packages' => $resp['commands']['get_packages']['result']['packages'] ?? []],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get list of system services
     */
    public function getSystemServices()
    {
        $commands = [
            [
                'method' => 'system-services.get_services',
                'id' => 'get_services',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands, null, ['read_timeout' => 5]));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => ['services' => $resp['commands']['get_services']['result']['services'] ?? []],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get system certificates
     */
    public function getSystemCertificates()
    {
        $commands = [
            [
                'method' => 'certs-mgmt.get_sys_certificates',
                'id' => 'get_sys_certificates',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands, null, ['read_timeout' => 10]));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => ['certificates' => $resp['commands']['get_sys_certificates']['result']['certificates'] ?? []],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get list of upgradable packages.
     */
    public function getUpgradablePackages()
    {
        $commands = [
            [
                'method' => 'system-mgmt.get-upgradable-packages',
                'id' => 'get_upgradable_packages',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands, null, ['read_timeout' => 10]));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['get_upgradable_packages'] ?? [];
        return [
            'status'   => $resp['status'],
            'result'   => [
                'packages'        => $cmd['result']['packages'] ?? [],
                'count'           => $cmd['result']['count'] ?? 0,
                'security_count'  => $cmd['result']['security_count'] ?? 0,
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get system settings: collect system info, interface names, and ssh config
     */
    public function getSysSettings()
    {
        $commands = [
            [
                'method' => 'system-overview.get_system_info',
                'id' => 'get_system_info',
                'data' => (object)[]
            ],
            [
                'method' => 'network-config.get_interfaces_names_ds',
                'id' => 'get_interfaces_names_ds',
                'data' => (object)[]
            ],
            [
                'method' => 'system-mgmt.get_ssh_config',
                'id' => 'get_ssh_config',
                'data' => (object)[]
            ],
            [
                'method' => 'system-mgmt.get-dns-status',
                'id' => 'get_dns_status',
                'data' => (object)[]
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands, null, ['read_timeout' => 5]));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status'   => 'success',
            'result'   => [
                'system_info' => $cmds['get_system_info']['result'] ?? [],
                'interfaces'  => $cmds['get_interfaces_names_ds']['result'] ?? [],
                'ssh'         => $cmds['get_ssh_config']['result'] ?? [],
                'dns'         => $cmds['get_dns_status']['result'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get DNS status: current resolv.conf, active sources, and Styx desired config.
     */
    public function getDnsStatus()
    {
        $commands = [
            [
                'method' => 'system-mgmt.get-dns-status',
                'id' => 'get_dns_status',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands, null, ['read_timeout' => 5]));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['get_dns_status'] ?? null;
        if (!$cmd || ($cmd['status'] ?? 'error') !== 'success') {
            return $cmd ?: $this->baseError('No response for get_dns_status');
        }
        return [
            'status'   => 'success',
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get SSH configuration and available interfaces/listen addresses
     */
    public function getSshConfig()
    {
        $commands = [
            [
                'method' => 'system-mgmt.get_ssh_config',
                'id' => 'get_ssh_config',
                'data' => (object)[]
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands, null, ['read_timeout' => 5]));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        return [
            'status'   => $resp['status'],
            'result'   => $resp['commands']['get_ssh_config']['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }
}
