<?php

namespace App\Controllers\Submit;

/**
 * Submit controller for strongSwan IPSec VPN write operations.
 *
 * Each public method corresponds to a command registered in SubmitRegistry.
 * All commands use module "strongswan" in the gateway envelope.
 */
use App\Controllers\BaseController;

class StrongswanSubmitController extends BaseController
{
    private const MODULE = 'strongswan';

    // Connections

    /**
     * Create a new IPSec connection.
     * @param array<string, mixed> $data  Must contain 'connection' key.
     * @return array<string, mixed>
     */
    public function addConnection(array $data): array
    {
        $connection = $data['connection'] ?? null;
        if (empty($connection) || empty($connection['name'])) {
            return $this->baseError('Connection data with name is required');
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_add_connection',
                'id' => 'swan_add_connection',
                'data' => ['connection' => $connection],
            ],
        ];

        return $this->handleSingleCommand($commands, 'Connection created');
    }

    /**
     * Update an existing IPSec connection.
     * @param array<string, mixed> $data  Must contain 'connection' key with 'name'.
     * @return array<string, mixed>
     */
    public function editConnection(array $data): array
    {
        $connection = $data['connection'] ?? null;
        if (empty($connection) || empty($connection['name'])) {
            return $this->baseError('Connection data with name is required');
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_edit_connection',
                'id' => 'swan_edit_connection',
                'data' => ['connection' => $connection],
            ],
        ];

        return $this->handleSingleCommand($commands, 'Connection updated');
    }

    /**
     * Delete an IPSec connection.
     * @param array<string, mixed> $data  Must contain 'id'.
     * @return array<string, mixed>
     */
    public function deleteConnection(array $data): array
    {
        $id = $data['id'] ?? '';
        if (empty($id)) {
            return $this->baseError('Connection ID is required');
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_delete_connection',
                'id' => 'swan_delete_connection',
                'data' => ['id' => $id],
            ],
        ];

        return $this->handleSingleCommand($commands, "Connection '$id' deleted");
    }

    /**
     * Initiate (bring up) a connection.
     * @param array<string, mixed> $data  Must contain 'id'.
     * @return array<string, mixed>
     */
    public function connUp(array $data): array
    {
        $id = $data['id'] ?? '';
        if (empty($id)) {
            return $this->baseError('Connection ID is required');
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_conn_up',
                'id' => 'swan_conn_up',
                'data' => ['id' => $id],
            ],
        ];

        return $this->handleSingleCommand($commands, "Connection $id initiated");
    }

    /**
     * Tear down an active connection.
     * @param array<string, mixed> $data  Must contain 'id'.
     * @return array<string, mixed>
     */
    public function connDown(array $data): array
    {
        $id = $data['id'] ?? '';
        if (empty($id)) {
            return ['status' => 'error', 'response_msg' => 'Connection ID is required'];
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_conn_down',
                'id' => 'swan_conn_down',
                'data' => ['id' => $id],
            ],
        ];

        return $this->handleSingleCommand($commands, "Connection $id terminated");
    }

    // Pools

    /**
     * Create a new address pool.
     * @param array<string, mixed> $data  Must contain 'pool' key with 'name' and 'addrs'.
     * @return array<string, mixed>
     */
    public function addPool(array $data): array
    {
        $pool = $data['pool'] ?? null;
        if (empty($pool) || empty($pool['name']) || empty($pool['addrs'])) {
            return $this->baseError('Pool name and address range are required');
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_add_pool',
                'id' => 'swan_add_pool',
                'data' => ['pool' => $pool],
            ],
        ];

        return $this->handleSingleCommand($commands, "Pool '{$pool['name']}' created");
    }

    /**
     * Update an existing address pool.
     * @param array<string, mixed> $data  Must contain 'pool' key with 'name'.
     * @return array<string, mixed>
     */
    public function editPool(array $data): array
    {
        $pool = $data['pool'] ?? null;
        if (empty($pool) || empty($pool['name'])) {
            return $this->baseError('Pool data with name is required');
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_edit_pool',
                'id' => 'swan_edit_pool',
                'data' => ['pool' => $pool],
            ],
        ];

        return $this->handleSingleCommand($commands, "Pool '{$pool['name']}' updated");
    }

    /**
     * Delete an address pool.
     * @param array<string, mixed> $data  Must contain 'id'.
     * @return array<string, mixed>
     */
    public function deletePool(array $data): array
    {
        $id = $data['id'] ?? '';
        if (empty($id)) {
            return $this->baseError('Pool ID is required');
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_delete_pool',
                'id' => 'swan_delete_pool',
                'data' => ['id' => $id],
            ],
        ];

        return $this->handleSingleCommand($commands, "Pool '$id' deleted");
    }

    // Secrets

    /**
     * Add a new secret.
     * @param array<string, mixed> $data  Must contain 'secret' key with 'label', 'type', 'value'.
     * @return array<string, mixed>
     */
    public function addSecret(array $data): array
    {
        $secret = $data['secret'] ?? null;
        if (empty($secret) || empty($secret['label']) || empty($secret['value'])) {
            return $this->baseError('Secret label and value are required');
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_add_secret',
                'id' => 'swan_add_secret',
                'data' => ['secret' => $secret],
            ],
        ];

        return $this->handleSingleCommand($commands, "Secret '{$secret['label']}' added");
    }

    /**
     * Update an existing secret.
     * @param array<string, mixed> $data  Must contain 'secret' key with 'id'.
     * @return array<string, mixed>
     */
    public function editSecret(array $data): array
    {
        $secret = $data['secret'] ?? null;
        if (empty($secret) || empty($secret['id'])) {
            return $this->baseError('Secret ID is required');
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_edit_secret',
                'id' => 'swan_edit_secret',
                'data' => ['secret' => $secret],
            ],
        ];

        return $this->handleSingleCommand($commands, 'Secret updated');
    }

    /**
     * Delete a secret.
     * @param array<string, mixed> $data  Must contain 'id'.
     * @return array<string, mixed>
     */
    public function deleteSecret(array $data): array
    {
        $id = $data['id'] ?? '';
        if (empty($id)) {
            return $this->baseError('Secret ID is required');
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_delete_secret',
                'id' => 'swan_delete_secret',
                'data' => ['id' => $id],
            ],
        ];

        return $this->handleSingleCommand($commands, 'Secret deleted');
    }

    // Global Config

    /**
     * Save global strongSwan configuration.
     * @param array<string, mixed> $data  Must contain 'config' key.
     * @return array<string, mixed>
     */
    public function setGlobalConfig(array $data): array
    {
        $config = $data['config'] ?? null;
        if (empty($config)) {
            return $this->baseError('Configuration data is required');
        }

        $commands = [
            [
                'method' => self::MODULE . '.swan_set_global_config',
                'id' => 'swan_set_global_config',
                'data' => ['config' => $config],
            ],
        ];

        return $this->handleSingleCommand($commands, 'Global configuration saved');
    }

    /**
     * Reload all strongSwan connections.
     * @param array<string, mixed> $data  No payload required.
     * @return array<string, mixed>
     */
    public function reloadAll(array $data): array
    {
        $commands = [
            [
                'method' => self::MODULE . '.swan_reload_all',
                'id' => 'swan_reload_all',
                'data' => (object)[],
            ],
        ];

        return $this->handleSingleCommand($commands, 'All connections reloaded');
    }

    // Helper

    /**
     * Send a single command and return a normalised response.
     *
     * @param array<int, array<string, mixed>> $commands
     * @param string $defaultMsg  Fallback success message.
     * @return array<string, mixed>
     */
    private function handleSingleCommand(array $commands, string $defaultMsg): array
    {
        $cmdId = $commands[0]['id'] ?? null;
        if (!$cmdId) {
            return $this->baseError('No command id provided');
        }
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands'][$cmdId] ?? $this->baseError("No response for command $cmdId");
    }
}
