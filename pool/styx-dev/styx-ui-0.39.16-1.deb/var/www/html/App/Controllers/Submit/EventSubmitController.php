<?php

namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class EventSubmitController extends BaseController
{


    /**
     * Toggle ACK for an event by ID.
     *
    * @param array<string,mixed> $data Request payload. Expected key: `id` (string|int)
    * @return array<string,mixed> Gateway response or error structure
     */
    public function toggleAck(array $data): array
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Event ID not provided');
        }

        $commands = [
            [
                'method' => 'event-manager-service.toggle_ack',
                'id' => 'toggle_ack',
                'data' => ['event_id' => $id],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['toggle_ack'] ?? $this->baseError('No response for toggle_ack');
    }
}
