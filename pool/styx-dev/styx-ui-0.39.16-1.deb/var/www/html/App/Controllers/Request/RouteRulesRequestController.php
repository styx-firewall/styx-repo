<?php
/**
 * Controller for route-rules (ip rule) management requests.
 * dp: 20260415
 */
namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class RouteRulesRequestController extends BaseController
{
    /**
     * Get route rules for table display.
     *
     * The gateway returns rules with _display fields already resolved.
     * No additional reference data is fetched here  -  form pickers
     * (sets, labels, routing tables) make their own API requests.
     *
     * @return array  Gateway-shaped response with status / result / warnings
     */
    public function getRoutingRulesPageData(): array
    {
        $commands = [];

        $commands[] = [
            'method' => 'routing-rules.get_routing_rules',
            'id'     => 'rules',
            'data'   => (object)[],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if (($resp['status'] ?? '') === 'error') {
            return $resp;
        }

        $cmds = $resp['commands'] ?? [];

        // Route rules (with _display fields resolved by gateway)
        $rules = $cmds['rules']['result']['rules'] ?? [];

        // Normalize each rule to a consistent shape
        foreach ($rules as &$rule) {
            if (!is_array($rule)) {
                $rule = [];
            }
            $rule['uuid']     = $rule['uuid'] ?? $rule['id'] ?? '';
            $rule['name']     = $rule['name'] ?? '';
            $rule['priority'] = $rule['priority'] ?? null;
            $rule['invert']   = !empty($rule['invert']);
            $rule['mark']     = $rule['mark'] ?? null;
            $rule['src']      = $rule['src'] ?? null;
            $rule['dst']      = $rule['dst'] ?? null;
            $rule['iif']      = $rule['iif'] ?? null;
            $rule['proto']    = $rule['proto'] ?? '';
            $rule['sport']    = $rule['sport'] ?? null;
            $rule['dport']    = $rule['dport'] ?? null;
            $rule['action']   = $rule['action'] ?? 'lookup';
            $rule['table']    = $rule['table'] ?? null;
            $rule['active']   = !empty($rule['active']);
        }
        unset($rule);

        return [
            'status'   => $resp['status'],
            'warnings' => $resp['warnings'] ?? [],
            'result'   => [
                'rules' => $rules,
            ],
        ];
    }
}