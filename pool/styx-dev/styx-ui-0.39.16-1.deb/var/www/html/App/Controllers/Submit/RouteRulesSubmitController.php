<?php
/**
 * Submit controller for route-rules (ip rule) management.
 * Handles add, delete, and toggle operations.
 *
 * dp: 20260415
 */
namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class RouteRulesSubmitController extends BaseController
{
    /**
     * Add a new route rule.
     *
     * Expected $data keys:
     *   - name          (string) Rule name
     *   - priority      (int) Rule priority
     *   - invert        (bool) Invert match conditions
    *   - mark          (string|null) UUID of fwmark set (submitted as a UUID)
     *   - src           (string|null) UUID of source address set
     *   - dst           (string|null) UUID of destination address set
     *   - iif           (string|null) UUID of interface set
     *   - proto         (string) Protocol (tcp, udp, icmp, icmpv6)
     *   - sport         (string|null) UUID of source port set
     *   - dport         (string|null) UUID of destination port set
     *   - action        (string) Action type (lookup, unreachable, prohibit, blackhole)
     *   - table         (string|null) Table name/id for lookup action
     *   - active        (bool) Whether the rule is active
     *
     * @param array $data
     * @return array Gateway-shaped response
     */
    public function setRule(array $data): array
    {
        // Validate required fields
        $name = $data['name'] ?? '';
        if (empty($name)) {
            return $this->baseError('Rule name is required');
        }

        // Priority is optional for the gateway, but strongly recommended
        $priority = isset($data['priority']) ? (int)$data['priority'] : null;

        // Match conditions - all optional, but at least one should be set
        $rule_data = [
            'name'     => $name,
            'priority' => $priority,
            'invert'   => !empty($data['invert']),
            'active'   => !empty($data['active']),
        ];

        // Optional match fields  -  map form keys to gateway keys
        $optional_fields = [
            'mark'   => 'mark',
            'src'    => 'src',
            'dst'    => 'dst',
            'iif'    => 'iif',
            'proto'  => 'proto',
            'sport'  => 'sport',
            'dport'  => 'dport',
            'action' => 'action',
            'table'  => 'table',
        ];

        foreach ($optional_fields as $local => $remote) {
            if (isset($data[$local]) && $data[$local] !== '' && $data[$local] !== null) {
                $rule_data[$remote] = $data[$local];
            }
        }

        $cmd = [
            'method' => 'routing-rules.set_routing_rule',
            'id'     => 'set_routing_rule',
            'data'   => $rule_data,
        ];

        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['set_routing_rule'] ?? $this->baseError('No response for set_routing_rule');
    }

    /**
     * Preview a route rule (no persist, no OS)
     *
     * Accepts the same payload as setRule.
     *
     * @param array $data
     * @return array Gateway-shaped response
     */
    public function previewRule(array $data): array
    {
        $name = $data['name'] ?? '';
        if (empty($name)) {
            return $this->baseError('Rule name is required');
        }

        $priority = isset($data['priority']) ? (int)$data['priority'] : null;

        $rule_data = [
            'name'     => $name,
            'priority' => $priority,
            'invert'   => !empty($data['invert']),
            'active'   => !empty($data['active']),
        ];

        $optional_fields = [
            'mark'   => 'mark',
            'src'    => 'src',
            'dst'    => 'dst',
            'iif'    => 'iif',
            'proto'  => 'proto',
            'sport'  => 'sport',
            'dport'  => 'dport',
            'action' => 'action',
            'table'  => 'table',
        ];

        foreach ($optional_fields as $local => $remote) {
            if (isset($data[$local]) && $data[$local] !== '' && $data[$local] !== null) {
                $rule_data[$remote] = $data[$local];
            }
        }

        $cmd = [
            'method' => 'routing-rules.preview_routing_rule',
            'id'     => 'preview_routing_rule',
            'data'   => $rule_data,
        ];

        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['preview_routing_rule'] ?? $this->baseError('No response for preview_routing_rule');
    }

    /**
     * Delete a route rule by UUID.
     *
     * @param array $data Must contain 'id'
     * @return array Gateway-shaped response
     */
    public function deleteRule(array $data): array
    {
        $uuid = $data['id'] ?? '';
        if (empty($uuid)) {
            return $this->baseError('Rule UUID is required');
        }

        $cmd = [
            'method' => 'routing-rules.delete_routing_rule',
            'id'     => 'delete_routing_rule',
            'data'   => ['id' => $uuid],
        ];

        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_routing_rule'] ?? $this->baseError('No response for delete_routing_rule');
    }

    /**
     * Toggle a route rule active/inactive status.
     *
     * @param array $data Must contain 'id' and optionally 'active' (bool)
     * @return array Gateway-shaped response
     */
    public function toggleRule(array $data): array
    {
        $uuid = $data['id'] ?? '';
        if (empty($uuid)) {
            return $this->baseError('Rule UUID is required');
        }

        $active = !empty($data['active']);

        $cmd = [
            'method' => 'routing-rules.toggle_routing_rule',
            'id'     => 'toggle_routing_rule',
            'data'   => [
                'id'   => $uuid,
                'active' => $active,
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['toggle_routing_rule'] ?? $this->baseError('No response for toggle_routing_rule');
    }

    /**
     * Update an existing route rule.
     * TODO: Not Implemented in the gateway backend
     * @param array $data Must contain 'id' plus fields to update
     * @return array Gateway-shaped response
     */
    public function updateRule(array $data): array
    {
        if (empty($data['id'])) {
            return $this->baseError('Rule UUID is required');
        }

        $cmd = [
            'method' => 'routing-rules.update_routing_rule',
            'id'     => 'update_routing_rule',
            'data'   => $data,
        ];

        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['update_routing_rule'] ?? $this->baseError('No response for update_route_rule');
    }
}
