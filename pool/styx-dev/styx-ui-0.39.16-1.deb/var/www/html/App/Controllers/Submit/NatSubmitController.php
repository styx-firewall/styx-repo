<?php

namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class NatSubmitController extends BaseController
{
    public function setNatRule(array $data): array
    {
        if (isset($data['enabled'])) {
            $data['enabled'] = (bool) $data['enabled'];
        }
        $commands = [
            [
                'method' => 'firewall-rules.set_firewall_rule',
                'id'     => 'set_nat_rule',
                'data'   => $data,
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['set_nat_rule'] ?? $this->baseError('No response for set_nat_rule');
    }

    public function setStaticNatRule(array $data): array
    {
        if (isset($data['enabled'])) {
            $data['enabled'] = (bool) $data['enabled'];
        }
        $commands = [
            [
                'method' => 'firewall-rules.set_static_nat_rule',
                'id'     => 'set_static_nat',
                'data'   => $data,
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['set_static_nat'] ?? $this->baseError('No response for set_static_nat');
    }

    public function deleteNatRule(array $data): array
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Rule ID not provided');
        }
        $commands = [
            [
                'method' => 'firewall-rules.delete_firewall_rule',
                'id'     => 'delete_nat_rule',
                'data'   => ['id' => $id],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['delete_nat_rule'] ?? $this->baseError('No response for delete_nat_rule');
    }

    public function deleteStaticNatRule(array $data): array
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Rule ID not provided');
        }
        $commands = [
            [
                'method' => 'firewall-rules.delete_static_nat_rule',
                'id'     => 'delete_static_nat',
                'data'   => ['id' => $id],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['delete_static_nat'] ?? $this->baseError('No response for delete_static_nat');
    }

    public function setNatRuleEnabled(array $data): array
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Rule ID not provided');
        }
        $enabled = isset($data['enabled']) ? (bool) $data['enabled'] : true;
        $commands = [
            [
                'method' => 'firewall-rules.set_firewall_rule_enabled',
                'id'     => 'set_nat_enabled',
                'data'   => ['id' => $id, 'enabled' => $enabled],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['set_nat_enabled'] ?? $this->baseError('No response for set_nat_enabled');
    }
}
