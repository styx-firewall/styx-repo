<?php

/**
 * Controller for page-init backend handler.
 *
 * Provides initialization data needed when loading any frontend page.
 * The backend handler page-init.get_init_data is designed to be extended
 * by adding new keys to its result, so this controller returns the full
 * result object rather than extracting individual fields.
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 */

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class PageInitRequestController extends BaseController
{
    /**
     * Get init data from backend.
     *
     * Returns the full result from page-init.get_init_data.
     * Currently contains: features (array).
     * Will be extended with more keys in the future.
     *
     * @return array<string, mixed>
     */
    public function getInitData(): array
    {
        $commands = [
            [
                'method' => 'page-init.get_init_data',
                'id' => 'init_data',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }

        $cmd = $resp['commands']['init_data'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'page-init.get_init_data command failed');
        }

        return [
            'status'   => $resp['status'],
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }
}
