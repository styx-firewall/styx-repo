<?php
/**
 * Controller for handling sets-related requests
 * dp: 20260415
 */
namespace App\Controllers\Request;

use App\Controllers\BaseController;
use App\Core\AppContext;

class SetsRequestController extends BaseController
{
    public function __construct(AppContext $ctx)
    {
        parent::__construct($ctx);
    }

    public function getFullSets(array $scopes = [])
    {
        $commands[] = [
            'method' => 'sets-mgmt.get_ports',
            'id' => 'ports',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_address',
            'id' => 'address',
            'data' => ['scope' => $scopes],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_interfaces_sets',
            'id' => 'ifaces_sets',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_domains',
            'id' => 'domain',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'network-config.get_interfaces_names',
            'id' => 'ifaces_names',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'ports' => $cmds['ports']['result']['ports'] ?? [],
                'address' => $cmds['address']['result']['address'] ?? [],
                'interfaces_sets' => $cmds['ifaces_sets']['result']['interfaces'] ?? [],
                'domain' => $cmds['domain']['result']['domains'] ?? [],
                'ifaces_names' => $cmds['ifaces_names']['result']['ifaces_names'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getPorts(array $scopes = [])
    {
        $data = (object)[];
        if (!empty($scopes)) {
            $data = ['scope' => $scopes];
        }
        $commands[] = [
            'method' => 'sets-mgmt.get_ports',
            'id' => 'ports',
            'data' => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'ports' => $cmds['ports']['result']['ports'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getAddress(array $scopes = [], ?string $type = null)
    {
        $commands = [];
        $data = ['scope' => $scopes];
        if ($type !== null) {
            $data['type'] = $type;
        }
        $commands[] = [
            'method' => 'sets-mgmt.get_address',
            'id' => 'address',
            'data' => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
                'result' => [
                'address' => $cmds['address']['result']['address'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getInterfacesSets(?string $type = null)
    {
        $data = (object)[];
        if ($type !== null) {
            $data = ['type' => $type];
        }
        $commands[] = [
            'method' => 'sets-mgmt.get_interfaces_sets',
            'id' => 'ifaces_sets',
            'data' => $data,
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'interfaces' => $cmds['ifaces_sets']['result']['interfaces'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getDomains()
    {
        $commands[] = [
            'method' => 'sets-mgmt.get_domains',
            'id' => 'domain',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'domain' => $cmds['domain']['result']['domains'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getLabels()
    {
        $commands[] = [
            'method' => 'sets-mgmt.get_labels',
            'id' => 'labels',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'labels' => $cmds['labels']['result']['labels'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getInterfacesNames()
    {
        $commands[] = [
            'method' => 'network-config.get_interfaces_names',
            'id' => 'ifaces_names',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'ifaces_names' => $cmds['ifaces_names']['result']['ifaces_names'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }
}
