<?php
/**
 * Controller for handling SLA-related requests
 * 
 * dp: 20260415
 */
namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class SLARequestController extends BaseController
{
    /**
     * Get data for SLA management page
     */
    public function getSLAPageData()
    {
        $commands[] = [
            'method' => 'network-config.get_interfaces_names_ds',
            'id' => 'ifaces_names',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_address',
            'id' => 'addresses_host',
            'data' => ['scope' => ['host']],
        ];
        $commands[] = [
            'method' => 'sla-mgmt.get_monitors',
            'id' => 'monitors',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        $addresses_host = [];
        $addrHostCmd = $cmds['addresses_host'] ?? null;
        if ($addrHostCmd && ($addrHostCmd['status'] ?? null) === 'success') {
            $addresses_host = $addrHostCmd['result']['address'] ?? [];
        }

        return [
            'status'   => $resp['status'],
            'warnings' => $resp['warnings'],
            'result'   => [
                'ifaces_names'  => $cmds['ifaces_names']['result']['ifaces_names_ds'] ?? [],
                'monitors'      => $cmds['monitors']['result']['monitors'] ?? [],
                'addresses_host'=> $addresses_host,
            ],
        ];
    }
}
