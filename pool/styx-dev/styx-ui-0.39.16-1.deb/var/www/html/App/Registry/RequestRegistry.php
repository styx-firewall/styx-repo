<?php

namespace App\Registry;

use App\Core\AppContext;

use App\Controllers\Request\PageInitRequestController;
use App\Controllers\Request\SecurityRequestController;
use App\Controllers\Request\StyxRequestController;
use App\Controllers\Request\SetsRequestController;

/**
 * Request Registry
 * Maps request action names to [ControllerClass, methodName]
 */
class RequestRegistry
{
    /**
     * Action registry mapping
     * @var array<string, array{0: class-string, 1: string}>
     */
    private static array $actions = [
        // Metrics
        'metrics' => [\App\Controllers\MetricsController::class, 'handle'],

        // DHCP
        'dhcp_get_page_data' => [\App\Controllers\Request\DhcpRequestController::class, 'getPageData'],

        // Discovery
        'discovery_get_host'     => [\App\Controllers\Request\DiscoveryRequestController::class, 'getHost'],
        'discovery_get_overview' => [\App\Controllers\Request\DiscoveryRequestController::class, 'getOverviewData'],
        'discovery_get_settings' => [\App\Controllers\Request\DiscoveryRequestController::class, 'getSettings'],

        // eBPF
        'ebpf_get_module_list'  => [\App\Controllers\Request\EbpfRequestController::class, 'getModuleList'],
        'ebpf_get_module_info'  => [\App\Controllers\Request\EbpfRequestController::class, 'getModuleInfo'],
        'ebpf_get_telemetry'    => [\App\Controllers\Request\EbpfRequestController::class, 'getTelemetry'],
        'ebpf_get_control_map'  => [\App\Controllers\Request\EbpfRequestController::class, 'getControlMap'],
        'ebpf_get_autoload'     => [\App\Controllers\Request\EbpfRequestController::class, 'getAutoload'],
        'ebpf_get_map_source'   => [\App\Controllers\Request\EbpfRequestController::class, 'getMapSource'],

        // Firewall
        'fw_get_create_rule_form' => [\App\Controllers\Request\FirewallRequestController::class, 'getCreateRuleFormData'],
        'fw_get_edit_rule_form'   => [\App\Controllers\Request\FirewallRequestController::class, 'getEditRuleFormData'],
        'fw_get_rules_forward'    => [\App\Controllers\Request\FirewallRequestController::class, 'getFirewallRules'],
        'fw_get_rules_local'      => [\App\Controllers\Request\FirewallRequestController::class, 'getFirewallRules'],

        // Firewall Logs
        'fw_logs'     => [\App\Controllers\Request\FwLogsRequestController::class, 'handle'],
        'get_ct_logs' => [\App\Controllers\Request\CtLogsRequestController::class, 'handle'],

        // iPerf
        'iperf_get_page_data'     => [\App\Controllers\Request\IperfRequestController::class, 'getIperfPageData'],
        'iperf_get_task_result'   => [\App\Controllers\Request\IperfRequestController::class, 'getTaskResult'],
        'iperf_status_and_tasks'  => [\App\Controllers\Request\IperfRequestController::class, 'getStatusAndTasks'],

        // NAT
        'get_nat_page_data' => [\App\Controllers\Request\NatRequestController::class, 'getNatPageData'],
        'get_nat_rules'     => [\App\Controllers\Request\NatRequestController::class, 'getNatRules'],

        // Network
        'get_interface_config'     => [\App\Controllers\Request\NetworkRequestController::class, 'getInterfaceConfig'],
        'get_interface_roles'      => [\App\Controllers\Request\NetworkRequestController::class, 'getValidRoles'],
        'get_interfaces_names'     => [\App\Controllers\Request\NetworkRequestController::class, 'getInterfaces'],
        'get_interfaces_names_ds'  => [\App\Controllers\Request\NetworkRequestController::class, 'getInterfacesNamesDs'],
        'get_sysctl_keys'          => [\App\Controllers\Request\NetworkRequestController::class, 'getSysctlKeys'],
        'get_valid_parents'        => [\App\Controllers\Request\NetworkRequestController::class, 'getValidParents'],

        // Packet Marking
        'get_pm_rules' => [\App\Controllers\Request\PacketMarkingRequestController::class, 'getPageData'],

        // Page Init
        'page_init' => [\App\Controllers\Request\PageInitRequestController::class, 'getInitData'],

        // Roles
        'get_capabilities'     => [\App\Controllers\Request\RoleRequestController::class, 'getCapabilities'],
        'get_role_definitions' => [\App\Controllers\Request\RoleRequestController::class, 'getDefinitions'],

        // Route Rules
        'get_routing_rules_page_data' => [\App\Controllers\Request\RouteRulesRequestController::class, 'getRoutingRulesPageData'],

        // Routing
        'get_routing_page_data'        => [\App\Controllers\Request\RoutingRequestController::class, 'getRoutingPageData'],
        'routing_get_as_path_lists'    => [\App\Controllers\Request\RoutingRequestController::class, 'getAsPathLists'],
        'routing_get_bfd'              => [\App\Controllers\Request\RoutingRequestController::class, 'getBfdData'],
        'routing_get_bfd_profiles'     => [\App\Controllers\Request\RoutingRequestController::class, 'getBfdProfiles'],
        'routing_get_bgp'              => [\App\Controllers\Request\RoutingRequestController::class, 'getBgpData'],
        'routing_get_community_lists'  => [\App\Controllers\Request\RoutingRequestController::class, 'getCommunityLists'],
        'routing_get_evpn'             => [\App\Controllers\Request\RoutingRequestController::class, 'getEvpn'],
        'routing_get_frr_global'       => [\App\Controllers\Request\RoutingRequestController::class, 'getFrrGlobal'],
        'routing_get_frr_static'       => [\App\Controllers\Request\RoutingRequestController::class, 'getFrrStatic'],
        'routing_get_igmp_proxy'       => [\App\Controllers\Request\RoutingRequestController::class, 'getIgmpProxyData'],
        'routing_get_ospf'             => [\App\Controllers\Request\RoutingRequestController::class, 'getOspfData'],
        'routing_get_ospf6'            => [\App\Controllers\Request\RoutingRequestController::class, 'getOspf6Data'],
        'routing_get_overview'         => [\App\Controllers\Request\RoutingRequestController::class, 'getOverviewData'],
        'routing_get_peer_groups'      => [\App\Controllers\Request\RoutingRequestController::class, 'getPeerGroups'],
        'routing_get_prefix_lists'     => [\App\Controllers\Request\RoutingRequestController::class, 'getPrefixLists'],
        'routing_get_rip'              => [\App\Controllers\Request\RoutingRequestController::class, 'getRipData'],
        'routing_get_route_maps'       => [\App\Controllers\Request\RoutingRequestController::class, 'getRouteMaps'],
        'routing_get_vrrp'             => [\App\Controllers\Request\RoutingRequestController::class, 'getVrrp'],
        'routing_get_zebra'            => [\App\Controllers\Request\RoutingRequestController::class, 'getZebra'],

        // Security
        'get_sec_aide'     => [\App\Controllers\Request\SecurityRequestController::class, 'getSecAide'],
        'get_sec_audit'    => [\App\Controllers\Request\SecurityRequestController::class, 'getSecAudit'],
        'get_sec_auditd'   => [\App\Controllers\Request\SecurityRequestController::class, 'getSecAuditd'],
        'get_sec_overview' => [\App\Controllers\Request\SecurityRequestController::class, 'getSecOverview'],

        // Sets
        'get_address'               => [\App\Controllers\Request\SetsRequestController::class, 'getAddress'],
        'get_domains'               => [\App\Controllers\Request\SetsRequestController::class, 'getDomains'],
        'get_interfaces_names_sets' => [\App\Controllers\Request\SetsRequestController::class, 'getInterfacesNames'],
        'get_interfaces_sets'       => [\App\Controllers\Request\SetsRequestController::class, 'getInterfacesSets'],
        'get_labels'                => [\App\Controllers\Request\SetsRequestController::class, 'getLabels'],
        'get_ports'                 => [\App\Controllers\Request\SetsRequestController::class, 'getPorts'],
        'getFullSets'               => [\App\Controllers\Request\SetsRequestController::class, 'getFullSets'],

        // SLA
        'sla_get_page_data' => [\App\Controllers\Request\SLARequestController::class, 'getSLAPageData'],

        // StrongSwan
        'swan_get_connections' => [\App\Controllers\Request\StrongswanRequestController::class, 'handle'],
        'swan_get_page_data'   => [\App\Controllers\Request\StrongswanRequestController::class, 'handle'],
        'swan_get_status'      => [\App\Controllers\Request\StrongswanRequestController::class, 'handle'],

        // Styx
        'styx-backup-download'     => [\App\Controllers\Request\StyxRequestController::class, 'getStyxBackup'],
        'styx_get_backup_types'    => [\App\Controllers\Request\StyxRequestController::class, 'getStyxBackupTypes'],
        'styx_get_config_diff'     => [\App\Controllers\Request\StyxRequestController::class, 'getConfigDiff'],
        'styx_get_events'          => [\App\Controllers\Request\StyxRequestController::class, 'getEvents'],
        'styx_get_features_full'   => [\App\Controllers\Request\StyxRequestController::class, 'getStyxFeaturesFull'],
        'styx_get_settings'        => [\App\Controllers\Request\StyxRequestController::class, 'getStyxSettings'],
        'styx_get_watchers'        => [\App\Controllers\Request\StyxRequestController::class, 'getWatchers'],

        // System
        'get_ssh_config'              => [\App\Controllers\Request\SystemRequestController::class, 'getSshConfig'],
        'sys_get_apps'                => [\App\Controllers\Request\SystemRequestController::class, 'getSystemApps'],
        'sys_get_certs'               => [\App\Controllers\Request\SystemRequestController::class, 'getSystemCertificates'],
        'sys_get_dns'                 => [\App\Controllers\Request\SystemRequestController::class, 'getDnsStatus'],
        'sys_get_services'            => [\App\Controllers\Request\SystemRequestController::class, 'getSystemServices'],
        'sys_get_settings'            => [\App\Controllers\Request\SystemRequestController::class, 'getSysSettings'],
        'sys_get_upgradable_packages' => [\App\Controllers\Request\SystemRequestController::class, 'getUpgradablePackages'],

        // Traffic Control
        'tc_get_config' => [\App\Controllers\Request\TCRequestController::class, 'getTcConfig'],
        'tc_get_stats'  => [\App\Controllers\Request\TCRequestController::class, 'getTcStats'],

        // Traffic Stats
        'traffic-stats-get' => [\App\Controllers\Request\TrafficStatsRequestController::class, 'getStats'],

        // Users
        'get_bearer_tokens' => [\App\Controllers\Request\UserRequestController::class, 'getBearerTokens'],
        'get_roles'         => [\App\Controllers\Request\UserRequestController::class, 'getRoles'],
        'get_user_info'     => [\App\Controllers\Request\UserRequestController::class, 'getUserInfo'],
        'get_users'         => [\App\Controllers\Request\UserRequestController::class, 'getUsers'],
    ];

    public static function all(): array
    {
        return self::$actions;
    }

    public static function has(string $action): bool
    {
        return isset(self::$actions[$action]);
    }

    /**
     * Execute a mapped action.
     * This uses reflection to map $data array keys to method parameter names when possible.
     * @param AppContext $ctx
     * @param string $action
     * @param array<string,mixed> $data
     * @return array|string|mixed
     */
    public static function execute(AppContext $ctx, string $action, array $data = [])
    {
        if (!self::has($action)) {
            throw new \InvalidArgumentException("Unknown action: $action");
        }

        [$controllerClass, $method] = self::$actions[$action];
        $controller = new $controllerClass($ctx);

        try {
            $ref = new \ReflectionMethod($controllerClass, $method);
            $params = $ref->getParameters();

            if (count($params) === 0) {
                return $ref->invoke($controller);
            }

            $args = [];
            foreach ($params as $param) {
                $pname = $param->getName();
                if (array_key_exists($pname, $data)) {
                    $args[] = $data[$pname];
                    continue;
                }
                if ($param->isDefaultValueAvailable()) {
                    $args[] = $param->getDefaultValue();
                    continue;
                }
                // If single parameter and nothing matched, pass whole data array (common pattern)
                if (count($params) === 1) {
                    $args[] = $data;
                    continue;
                }
                throw new \InvalidArgumentException("Missing required parameter '$pname' for action $action");
            }

            return $ref->invokeArgs($controller, $args);
        } catch (\ReflectionException $e) {
            throw new \RuntimeException('Controller method reflection failed: ' . $e->getMessage());
        }
    }
}
