<?php
/**
 * DateFormatter
 *
 * Centralized date/time formatting for user-facing output.
 * All dates arriving from the backend are expected to be UTC.
 * A warning is logged when a date string carries an explicit non-UTC offset,
 * which indicates the backend contract is being violated.
 */

namespace App\Services;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\LogSystemService;

class DateFormatter
{
    /**
     * Returns true when the date string carries an explicit non-UTC timezone offset.
     * Bare strings like "2024-01-01 12:00:00" (no offset) return false - treated as UTC.
     * Strings with Z or +00:00 return false - explicitly UTC.
     */
    public static function isExplicitlyNonUtc(string $dateStr): bool
    {
        $trimmed = trim($dateStr);

        if (preg_match('/Z$|[+]00:00$/i', $trimmed)) {
            return false;
        }

        return (bool) preg_match('/[+\-]\d{2}:\d{2}$/', $trimmed);
    }

    /**
     * Convert a backend date string (expected UTC) to the user's timezone for display.
     *
     * Logs a warning via LogSystemService when the string carries a non-UTC offset,
     * indicating a backend contract violation.
     *
     * @param string $dateStr   Date string from backend (e.g. "2024-01-01T12:00:00Z").
     * @return string           Formatted date in user timezone, or raw $dateStr on error.
     */

    public static function fromBackend(
        AppContext $ctx,
        string $dateStr
    ): string {
        if (self::isExplicitlyNonUtc($dateStr)) {
            try {
                $logger = $ctx->get(LogSystemService::class);
                $logger->warning(
                    'DateFormatter: non-UTC date string received from backend: ' . $dateStr
                );
            } catch (\Throwable $_) {}
        }

        $cfg      = $ctx->get(Config::class);
        $timezone = $cfg->get('client.timezone', 'UTC');
        $locale   = $cfg->get('client.locale', 'en_US');

        try {
            $date = new \DateTime($dateStr, new \DateTimeZone('UTC'));
            $date->setTimezone(new \DateTimeZone($timezone));

            $formatted = self::formatWithIntl($date, $locale, $timezone);

            return $formatted !== false ? $formatted : $dateStr;

        } catch (\Throwable $_) {
            return $dateStr;
        }
    }
    /**
     * Convert a UNIX timestamp (assumed UTC epoch) to the user's timezone for display.
     *
     * @param int    $timestamp  UNIX timestamp.
     * @return string            Formatted date in user timezone, or PHP date() fallback on error.
     */
    public static function fromTimestamp(
        AppContext $ctx,
        int $timestamp,
    ): string {
        $cfg      = $ctx->get(Config::class);
        $timezone = $cfg->get('client.timezone', 'UTC');
        $locale   = $cfg->get('client.locale', 'en_US');

        try {
            $date = new \DateTime('@' . $timestamp);
            $date->setTimezone(new \DateTimeZone($timezone));
            $formatted = self::formatWithIntl($date, $locale, $timezone);
            if ($formatted !== false) {
                return $formatted;
            }

            return $date->format('Y-m-d H:i:s');
        } catch (\Throwable $_) {
            return date('Y-m-d H:i:s', $timestamp);
        }
    }

    /**
     * Internal helper to format a DateTime using IntlDateFormatter consistently.
     *
     * @return string|false  Formatted date string or false on failure (matches Intl API)
     */
    private static function formatWithIntl(\DateTime $date, string $locale, string $timezone): string|false
    {
        $formatter = new \IntlDateFormatter(
            $locale,
            \IntlDateFormatter::SHORT,
            \IntlDateFormatter::SHORT,
            $timezone
        );

        $pattern = $formatter->getPattern();
        if (!str_contains($pattern, 'ss')) {
            $pattern = str_replace('mm', 'mm:ss', $pattern);
            $formatter->setPattern($pattern);
        }

        return $formatter->format($date);
    }
}
