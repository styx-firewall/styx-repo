<?php

/**
 * Filter
 *
 * Provides utility methods for validating and sanitizing input data.
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 */

namespace App\Services;

class Filter
{
    /**
     * Retrieves an integer from $_GET and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return int|null The validated integer or null if invalid.
     */
    public static function getInt(mixed $val, int $size = PHP_INT_MAX): ?int
    {
        if (!isset($_GET[$val])) {
            return null;
        }
        return self::varInt($_GET[$val], $size);
    }

    /**
     * Retrieves an integer from $_POST and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return int|null The validated integer or null if invalid.
     */
    public static function postInt(mixed $val, int $size = PHP_INT_MAX): ?int
    {
        if (!isset($_POST[$val])) {
            return null;
        }
        return self::varInt($_POST[$val], $size);
    }

    /**
     * Validates an integer.
     *
     * @param mixed $val The value to validate.
     * @param int $size Maximum allowed size.
     * @return int|null The validated integer or null if invalid.
     */
    public static function varInt(mixed $val, int $size = PHP_INT_MAX): ?int
    {
        $tVal = trim($val);
        if (!is_numeric($tVal) || $tVal > $size) {
            return null;
        }

        return (int) $tVal;
    }

    /**
     * Validates a float.
     *
     * @param mixed $val The value to validate.
     * @param float $maxValue Maximum allowed value.
     * @return float|null The validated float or null if invalid.
     */
    public static function varFloat(mixed $val, float $maxValue = PHP_FLOAT_MAX): ?float
    {
        $tVal = trim((string)$val);

        // Check if the value is numeric and doesn't exceed the maximum allowed value.
        if (!is_numeric($tVal) || (float)$tVal > $maxValue) {
            return null;
        }

        return (float)$tVal;
    }

    /*
     * Parse get/post/var
     * Simple String words without accents or special characters
     */

    /**
     * Retrieves a string from $_GET and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return string|null The validated string or null if invalid.
     */
    public static function getString(mixed $val, int $size = PHP_INT_MAX): ?string
    {
        if (!isset($_GET[$val])) {
            return null;
        }
        return self::varString($_GET[$val], $size);
    }

    /**
     * Retrieves a string from $_POST and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return string|null The validated string or null if invalid.
     */
    public static function postString(mixed $val, int $size = PHP_INT_MAX): ?string
    {
        if (!isset($_POST[$val])) {
            return null;
        }
        return self::varString($_POST[$val], $size);
    }

    /**
     * Validates a string.
     * Not Allowed: ! @ # $ % ^ & * ( ) , . ? " : { } | < > + spaces
     * @param mixed $val The value to validate.
     * @param int $size Maximum allowed size.
     * @return string|null The validated string or null if invalid.
     */
    public static function varString(mixed $val, int $size = PHP_INT_MAX): ?string
    {
        // Validate a simple string
        if (empty($val)) {
            return null;
        }

        if (!empty($size) && strlen($val) > $size) {
            return null;
        }
        if (preg_match('/[!@#$%^&*(),.?":{}|<>]/', $val)) {
            return null;
        }

        return trim($val);
    }

    /**
     * Sanitizes an array, can be an array or string post/get value, checks to avoid JSON.
     *
     * @param mixed $input The input to sanitize.
     * @param string $method The method to use (default: 'var', 'post', or 'get').
     * @return array<mixed,mixed> The sanitized array.
     */
    public static function sanArray(mixed $input, string $method = 'var'): array
    {
        if ($method === 'var') :
            $var_ary = $input;
        elseif ($method === 'post' && isset($_POST[$input])) :
            $var_ary = $_POST[$input];
        elseif ($method === 'get' && isset($_GET[$input])) :
            $var_ary = $_GET[$input];
        else :
            return [];
        endif;
        // Here we must have an array
        if (!is_array($var_ary)) {
            return [];
        }

        foreach ($var_ary as $key => $value) {
            if (is_array($value)) {
                $var_ary[$key] = self::sanArray($value, 'var');
            } else {
                if (is_float($value)) {
                    $var_ary[$key] = (float) $value;
                } elseif (is_numeric($value)) {
                    // String float is numeric but not float is_float not work
                    if (strpos((string) $value, '.') !== false) {
                        $var_ary[$key] = (float) $value;
                    } else {
                        // Cast to int if it's a valid integer
                        $var_ary[$key] = (int) $value;
                    }
                } else {
                    // Check if the value is valid JSON
                    $decodedJson = json_decode($value, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        // If it's valid JSON, keep it as is
                        $var_ary[$key] = $value;
                    } else {
                        // If it's not JSON, sanitize as a string
                        $var_ary[$key] = filter_var($value, FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?: null;
                    }
                }
            }
        }

        return $var_ary;
    }


    /**
     * Retrieves an alphanumeric string from $_POST and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return string|false The validated alphanumeric string or false if invalid.
     */
    public static function postAzChar(mixed $val, int $size = PHP_INT_MAX): string|false
    {
        if (empty($_POST[$val])) {
            return false;
        }

        return self::varAzChar($_POST[$val], $size);
    }

    /**
     * Retrieves an alphanumeric string from $_GET and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return string|false The validated alphanumeric string or false if invalid.
     */
    public static function getAzChar(mixed $val, int $size = PHP_INT_MAX): string|false
    {
        if (empty($_GET[$val])) {
            return false;
        }

        return self::varAzChar($_GET[$val], $size);
    }

    /**
     * Validates an alphanumeric string.
     *
     * @param mixed $var The value to validate.
     * @param int|null $max_size Maximum allowed size.
     * @param int|null $min_size Minimum allowed size.
     * @return string|false The validated alphanumeric string or false if invalid.
     */
    public static function varAzChar(mixed $var, ?int $max_size = null, ?int $min_size = null): string|false
    {

        if (
            (empty($var) ) ||
            (!empty($max_size) && (strlen($var) > $max_size) ) ||
            (!empty($min_size) && (strlen($var) < $min_size))
        ) {
            return false;
        }
        if (!preg_match('/^[A-Za-z]+$/', $var)) {
            return false;
        }

        return $var;
    }

    /**
     * Retrieves an alphanumeric string from $_POST and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return string|false The validated alphanumeric string or false if invalid.
     */
    public static function postAlphanum(mixed $val, int $size = PHP_INT_MAX): string|false
    {
        if (empty($_POST[$val])) {
            return false;
        }

        return self::varAlphanum($_POST[$val], $size);
    }

    /**
     * Retrieves an alphanumeric string from $_GET and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return string|false The validated alphanumeric string or false if invalid.
     */
    public static function getAlphanum(mixed $val, int $size = PHP_INT_MAX): string|false
    {
        if (empty($_GET[$val])) {
            return false;
        }

        return self::varAlphanum($_GET[$val], $size);
    }

    /**
     * Validates an alphanumeric string.
     *
     * @param mixed $var The value to validate.
     * @param int|null $max_size Maximum allowed size.
     * @param int|null $min_size Minimum allowed size.
     * @return string|false The validated alphanumeric string or false if invalid.
     */
    public static function varAlphanum(mixed $var, ?int $max_size = null, ?int $min_size = null): string|false
    {
        $length = strlen($var);

        if (
            empty($var) || (!empty($max_size) && $length > $max_size) || (!empty($min_size) && $length < $min_size)
        ) {
            return false;
        }
        /*
            if ((empty($var) ) || (!empty($max_size) && (strlen($var) > $max_size) ) ||
            (!empty($min_size) && (strlen($var) < $min_size))
            ) {
            return false;
            }

            if (!preg_match('/^[A-Za-z0-9]+$/', $var)) {
            return false;
            }
         *
         */
        if (!ctype_alnum($var)) {
            return false;
        }


        return $var;
    }


    /**
     * Retrieves a strict alphanumeric string from $_POST and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return string|false The validated strict alphanumeric string or false if invalid.
     */
    public static function postStrict(mixed $val, int $size = PHP_INT_MAX): string|false
    {
        if (empty($_POST[$val])) {
            return false;
        }

        return self::varStrict($_POST[$val], $size);
    }

    /**
     * Retrieves a strict alphanumeric string from $_GET and validates it.
     *
     * @param string $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return string|false The validated strict alphanumeric string or false if invalid.
     */
    public static function getStrict(string $val, int $size = PHP_INT_MAX): string|false
    {
        if (empty($_GET[$val])) {
            return false;
        }

        return self::varStrict($_GET[$val], $size);
    }

    /**
     * Validates a strict alphanumeric string + _ + -.
     *
     * @param mixed $var The value to validate.
     * @param int|null $max_size Maximum allowed size.
     * @param int|null $min_size Minimum allowed size.
     * @return string|false The validated strict alphanumeric string or false if invalid.
     */
    public static function varStrict(mixed $var, ?int $max_size = null, ?int $min_size = null): string|false
    {
        $length = strlen($var);

        if (
            empty($var) || (!empty($max_size) && $length > $max_size) || (!empty($min_size) && $length < $min_size)
        ) {
            return false;
        }

        if (!preg_match('/^[A-Za-z0-9_-]+$/', $var)) {
            return false;
        }

        return $var;
    }

    /**
     * Retrieves a password from $_POST and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return string|false The validated password or false if invalid.
     */
    public static function postPassword(mixed $val, int $size = PHP_INT_MAX): string|false
    {
        if (empty($_POST[$val])) {
            return false;
        }

        return self::varPassword($_POST[$val], $size);
    }


    /**
     * Get and Validate remote addr
     * @return string
     */
    public static function getRemoteIp(): string {
        $ip = trim($_SERVER['REMOTE_ADDR']);

        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
    }

    /**
     * Retrieves a custom string from $_POST and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param string $validSpecial The valid special characters.
     * @param int $max_size Maximum allowed size.
     * @param int $min_size Minimum allowed size.
     * @return string|false The validated custom string or false if invalid.
     */
    public static function postCustomString(
        mixed $val,
        string $validSpecial,
        ?int $max_size = null,
        ?int $min_size = null
    ): string|false {
        if (empty($_POST[$val])) {
            return false;
        }

        return self::varCustomString($_POST[$val], $validSpecial, $max_size, $min_size);
    }

    /**
     * Retrieves a custom string from $_GET and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param string $validSpecial The valid special characters.
     * @param int $max_size Maximum allowed size.
     * @param int $min_size Minimum allowed size.
     * @return string|false The validated custom string or false if invalid.
     */
    public static function getCustomString(
        mixed $val,
        string $validSpecial,
        ?int $max_size = null,
        ?int $min_size = null
    ): string|false {
        if (empty($_GET[$val])) {
            return false;
        }

        return self::varCustomString($_GET[$val], $validSpecial, $max_size, $min_size);
    }

    /**
     * Validates a custom string.
     *
     * @param mixed $var The value to validate.
     * @param string $validSpecialChars The valid special characters.
     * @param int $max_size Maximum allowed size.
     * @param int $min_size Minimum allowed size.
     * @return string|false The validated custom string or false if invalid.
     */
    public static function varCustomString(
        mixed $var,
        string $validSpecialChars,
        ?int $max_size = null,
        ?int $min_size = null
    ): string|false {
        // Define the default set of characters (AZaz and numbers)
        $validChars = 'A-Za-z0-9';

        $escapedSpecial = preg_quote($validSpecialChars, '/');
        $validChars .= $escapedSpecial;

        $regex = '/^[' . $validChars . ']+$/';

        if (
            empty($var) ||
            (!empty($max_size) && strlen($var) > $max_size) ||
            (!empty($min_size) && strlen($var) < $min_size)
        ) {
            return false;
        }

        if (!preg_match($regex, $var)) {
            return false;
        }

        return $var;
    }

    /**
     * Validates a JSON string.
     *
     * @param mixed $json The JSON string to validate.
     * @return string|null The validated JSON string or null if invalid.
     */
    public static function varJson(mixed $json): ?string
    {
        return (json_decode($json) !== null || $json === 'null') ? $json : null;
    }

    /**
     * Validates a boolean value.
     *
     * @param mixed $value The value to validate.
     * @return bool|null The validated boolean or null if invalid.
     */
    public static function varBool(mixed $value): ?bool
    {
        $bool = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);

        return $bool === null ? null : $bool;
    }

    /**
     * Retrieves a string from $_COOKIE and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return string|false The validated string or false if invalid.
     */
    public static function cookieString(mixed $val, int $size = PHP_INT_MAX): string|false
    {
        if (empty($_COOKIE[$val])) {
            return false;
        }
        return self::varString($_COOKIE[$val], $size);
    }

    /**
     * Retrieves an integer from $_COOKIE and validates it.
     *
     * @param mixed $val The key to retrieve.
     * @param int $size Maximum allowed size.
     * @return int|null The validated integer or null if invalid.
     */
    public static function cookieInt(mixed $val, int $size = PHP_INT_MAX): ?int
    {
        if (empty($_COOKIE[$val])) {
            return null;
        }
        return self::varInt($_COOKIE[$val], $size);
    }

    /**
     * Validates a timezone string (must be a valid PHP timezone identifier).
     *
     * @param mixed $val The value to validate.
     * @return string|false The validated timezone or false if invalid.
     */
    public static function varTimezone(mixed $val): string|false
    {
        if (empty($val) || !in_array($val, \DateTimeZone::listIdentifiers(), true)) {
            return false;
        }
        return $val;
    }

    /**
     * Escape a string for safe HTML output.
     *
     * Converts special characters to HTML entities. Use this when rendering
     * user-controlled or network-sourced strings in HTML context (body or
     * attribute values).
     *
     * @param string|null $str The string to escape.
     * @return string The escaped string. Null or non-string values return empty string.
     */
    public static function escHtml(?string $str): string
    {
        return htmlspecialchars((string) $str, ENT_QUOTES, 'UTF-8');
    }
}
