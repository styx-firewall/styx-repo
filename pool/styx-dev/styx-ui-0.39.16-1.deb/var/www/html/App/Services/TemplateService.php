<?php

/**
 *
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 * v1.1
 */

namespace App\Services;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\AuthService;
use App\Services\UserProfileService;

class TemplateService
{
    /**
     * Globals injected into every template render (e.g. app_debug).
     * @var array<string,mixed>
     */
    private array $globals = [];
    private string $templatesPath = 'tpl/default/';
    private AppContext $ctx;
    private string $theme = 'default';
    private string $theme_css = 'default';

    public function __construct(AppContext $ctx)
    {
        $this->ctx = $ctx;
        $cfg = $ctx->get(Config::class);
        $this->theme = $cfg->get('web.theme', 'default');
        $this->theme_css = $cfg->get('web.theme_css', 'default');
        // Use theme directory for templates (keep trailing slash).
        $this->templatesPath = 'tpl/' . $this->theme . '/';
        // Inject so callers don't need to.
        try {
            $this->addGlobal('app_debug', (bool)$cfg->get('client.debug', false));
            $this->addGlobal('client_timezone', $cfg->get('client.timezone', 'UTC'));
            $this->addGlobal('client_locale', $cfg->get('client.locale', 'en-US'));
            $this->addGlobal('app_version', $cfg->get('app.version', ''));
        } catch (\Throwable $_) {
            // Non-fatal; TemplateService should still construct even if config
            // read fails for some reason.
        }
    }

    /**
     * Gets a template and renders it with the provided data.
     *
     * @param string $templateName The template name.
     * @param array<string, mixed> $data Data to render the template.
     * @return string Rendered HTML.
     */
    public function getTpl(string $templateName, array $tdata = []): string
    {
        // Merge globals into template data under 'tpl_data' so templates
        // can access them via $tdata['tpl_data'].
        $tplData = $tdata['tpl_data'] ?? [];
        $tplData = array_replace_recursive($this->globals, $tplData);
        $tdata['tpl_data'] = $tplData;

        $cfg = $this->ctx->get(Config::class);

        // Validate template name: fail-fast on suspicious characters.
        // Disallow null byte, backslashes, and parent-directory references.
        if (preg_match('/\x00|\\\\|\.\./', $templateName) || strpos($templateName, '/') === 0) {
            throw new \Exception("Invalid template name: $templateName");
        }
        // Allow only a limited character set (letters, numbers, underscore, hyphen and / for subdirs)
        if (!preg_match('/^[a-zA-Z0-9_\/-]+$/', $templateName)) {
            throw new \Exception("Invalid template name: $templateName");
        }

        // Ensure the template file exists and is inside the templates directory.
        $base = realpath($this->templatesPath);
        if ($base === false) {
            throw new \Exception("Templates base directory not found: " . $this->templatesPath);
        }

        $templatePath = $this->templatesPath . $templateName . '.tpl.php';

        // Check if file exists before attempting realpath
        if (!file_exists($templatePath)) {
            throw new \Exception(
                "Template file not found: '$templateName' " .
                "(expected: $templatePath). " .
                "Check that the template exists and matches the page/section name."
            );
        }

        $fileReal = realpath($templatePath);
        if ($fileReal === false) {
            throw new \Exception("Failed to resolve template path: $templateName");
        }

        // Security check: ensure template is inside allowed directory
        if (strpos($fileReal, $base) !== 0) {
            throw new \Exception(
                "Security violation: Template '$templateName' is outside templates directory. " .
                "Resolved path: $fileReal"
            );
        }

        // Capture the output of the template file
        ob_start();
        include $fileReal;
        $content = ob_get_clean();
        return $content;
    }

    /**
     * Add a global variable that will be present in every template's
     * `$tdata['tpl_data']` array.
     *
     * @param string $name
     * @param mixed $value
     * @return void
     */
    public function addGlobal(string $name, $value): void
    {
        $this->globals[$name] = $value;
    }

    /**
     * Returns a CSS <link> tag for the given theme and CSS file.
     *
     * @param string $css
     * @return ?string
     */
    public function cssLink(string $css): ?string
    {
        if (strpos($css, 'http') === 0) {
            $css_file = $css;
        } else {
            $css_file = 'tpl/' . $this->theme . '/css/' . $css . '.css';
            if (file_exists($css_file)) {
                if ($css === 'default') {
                    $version = $this->globals['app_version'] ?? '';
                    if ($version !== '') {
                        $css_file .= '?v=' . $version;
                    }
                }
            } else {
                return null;
            }
        }
        return '<link rel="stylesheet" href="' . $css_file . '">' . "\n";
    }

    /**
     * Returns a <script> tag for the given script file.
     *
     * @param string $scriptlink
     * @param bool $module
     * @return string
     */
    public function scriptLink(string $scriptlink, bool $module = false): string
    {
        $type = $module ? ' type="module"' : '';
        $is_local = strpos($scriptlink, 'http') !== 0;
        $version = $this->globals['app_version'] ?? '';
        if ($is_local && $version !== '') {
            $scriptlink .= '?v=' . $version;
        }
        return '<script src="' . $scriptlink . '"' . $type . '></script>' . "\n";
    }

    /**
     * Renders and outputs a complete page using the provided template data.
     *
     * @param array $tdata Template data for rendering the page.
     * @return void
     */
    public function showPage(array $tdata): void
    {
        $web['main_head'] = $this->cssLink($this->theme_css);
        $web['main_footer'] = '';
        $web['footer_script'] = '';

        // Add custom css files
        if (!empty($tdata['web_main']['cssfile']) && is_array($tdata['web_main']['cssfile'])) {
            foreach ($tdata['web_main']['cssfile'] as $cssfile) {
                $web['main_head'] .= $this->cssLink($cssfile);
            }
        }
        // Add script link (supports array of ['src' => ..., 'module' => true/false])
        if (!empty($tdata['web_main']['scriptlink']) && is_array($tdata['web_main']['scriptlink'])) {
            foreach ($tdata['web_main']['scriptlink'] as $scriptlink) {
                if (is_array($scriptlink)) {
                    $src = $scriptlink['src'] ?? '';
                    $module = !empty($scriptlink['module']);
                    $web['main_head'] .= $this->scriptLink($src, $module);
                } else {
                    $web['main_head'] .= $this->scriptLink($scriptlink, false);
                }
            }
        }
        // Footer Script (same)
        if (!empty($tdata['web_main']['footer_script']) && is_array($tdata['web_main']['footer_script'])) {
            foreach ($tdata['web_main']['footer_script'] as $scriptlink) {
                if (is_array($scriptlink)) {
                    $src = $scriptlink['src'] ?? '';
                    $module = !empty($scriptlink['module']);
                    $web['footer_script'] .= $this->scriptLink($src, $module);
                } else {
                    $web['footer_script'] .= $this->scriptLink($scriptlink, false);
                }
            }
        }

        if (!empty($tdata['web_main']['main_head'])) {
            $web['main_head'] .= $tdata['web_main']['main_head'];
        }
        if (!empty($tdata['web_main']['main_head_tpl']) && is_array($tdata['web_main']['main_head_tpl'])) {
            foreach ($tdata['web_main']['main_head_tpl'] as $head_tpl) {
                $web['main_head'] .= $this->getTpl($head_tpl, $tdata);
            }
        }

        if (!empty($tdata['web_main']['main_footer_tpl']) && is_array($tdata['web_main']['main_footer_tpl'])) {
            foreach ($tdata['web_main']['main_footer_tpl'] as $footer_tpl) {
                $web['main_footer'] .= $this->getTpl($footer_tpl, $tdata);
            }
        }

        if (!empty($tdata['web_main']['main_footer'])) {
            $web['main_footer'] .= $tdata['web_main']['main_footer'];
        }

        // Load Templates in tdata/load_tpl
        if (!empty($tdata['load_tpl']) && is_array($tdata['load_tpl'])) {
            usort($tdata['load_tpl'], function ($a, $b) {
                $weightA = $a['weight'] ?? 5;
                $weightB = $b['weight'] ?? 5;
                return $weightA <=> $weightB;
            });
            foreach ($tdata['load_tpl'] as $tpl) {
                /*
                 * Partial-specific data is passed via load_tpl['tpl_data'].
                 * getTpl() already merges system globals into tpl_data.
                */
                $tpl_data = [];
                if (!empty($tpl['tpl_data'])) {
                    $tpl_data['tpl_data'] = $tpl['tpl_data'];
                }
                if (!empty($tpl['file']) && !empty($tpl['place'])) {
                    if (empty($tdata[$tpl['place']])) {
                        $tdata[$tpl['place']] = $this->getTpl($tpl['file'], $tpl_data);
                    } else {
                        $tdata[$tpl['place']] .= $this->getTpl($tpl['file'], $tpl_data);
                    }
                }
            }
        }
        unset($tdata['load_tpl']);
        /*
            Here the main body of the page is rendered, we do not need load_tpl and the main
            body is rendered with the template name in $tdata['page'].
            The $tdata['page_data'] is passed to the template as the template data
        */

        $web['main_body'] = $this->getTpl($tdata['page'], $tdata);

        echo $this->getTpl('main', array_merge($tdata, $web));
    }
}
