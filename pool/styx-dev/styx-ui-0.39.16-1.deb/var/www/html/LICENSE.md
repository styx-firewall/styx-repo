© [2024-2026] [Diego García González]. All rights reserved.
Permission is granted **for personal or educational use only**, including students and home users.
**Redistribution, public sharing, modification, or commercial use is strictly prohibited** without express written permission.
