<?php
/**
 * Bootstrap file for the application.
 * Sets up error handling, autoloading, and session management.
 * @author diego/@/envigo.net
 * @copyright Copyright All Right Reserved @ 2024 - 2026 Diego Garcia (diego/@/envigo.net)
 */

declare(strict_types=1);

if (PHP_VERSION_ID < 70300) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Styx requires PHP 7.3 or newer. Current version: " . PHP_VERSION;
    exit(1);
}

// Autoloader
require_once __DIR__ . '/../App/Autoloader.php';
App\Autoloader::register();

use App\Core\AppContext;
use App\Core\Config;
use App\Core\SessionManager;
use App\Core\ErrorHandler;
use App\Services\LogSystemService;
use App\Services\Filter;
use App\Services\TemplateService;
use App\Services\AuthService;
use App\Services\UserProfileService;

/**
 * Return the shared AppContext instance for this request/process.
 */
try {
    $ctx = AppContext::getInstance();

    // Config creation are captured by the central logger/error handler.
    ErrorHandler::register($ctx);

    $cfg = $ctx->get(Config::class);

    // Populate client timezone into the config so downstream code can read it.
    // Priority: existing config value (if any) -> cookie `tz` (validated) -> fallback `UTC`.
    try {
        if ($cfg->get('client.timezone') === null) {
            $tz = 'UTC';
            $cookieTz = isset($_COOKIE['tz']) ? $_COOKIE['tz'] : null;
            if (!empty($cookieTz)) {
                $valid = Filter::varTimezone($cookieTz);
                if ($valid !== false) {
                    $tz = $valid;
                }
            }
            $cfg->set('client.timezone', $tz);
        }
    } catch (Throwable $_) {
        // Fail-safe: do not break bootstrap if validation or cookie access errors occur.
        try { $cfg->set('client.timezone', 'UTC'); } catch (Throwable $__) {}
    }

    // Populate client locale into the config so downstream code can read it.
    // Priority: existing config value (if any) -> cookie `tz_locale` (validated) -> fallback `en-US`.
    try {
        if ($cfg->get('client.locale') === null) {
            $locale = 'en-US';
            $cookieLocale = isset($_COOKIE['tz_locale']) ? rawurldecode($_COOKIE['tz_locale']) : null;
            if (!empty($cookieLocale)) {
                $valid = Filter::varString($cookieLocale, 20);
                if ($valid !== null) {
                    $locale = $valid;
                }
            }
            $cfg->set('client.locale', $locale);
        }
    } catch (Throwable $_) {
        try { $cfg->set('client.locale', 'en-US'); } catch (Throwable $__) {}
    }

    $cfg->applyDebugSettings();

    // Configure and start session centrally
    if (!SessionManager::start($ctx, $cfg)) {
        $msg = '[BS] Failed to start session via SessionManager';
        try {
            $logger = $ctx->get(LogSystemService::class);
            if ($logger && $logger instanceof LogSystemService) {
                $logger->error($msg);
            }
        } catch (Throwable $_) {
            // No direct error_log here; ErrorHandler handles fallback
        }
    }

    // Apply per-user profile settings (timezone, locale, debug).
    // Runs after session is started so username is readable.
    // Silently skipped if storage file is absent (no profile = use defaults).
    try {
        $auth = $ctx->get(AuthService::class);
        $sessionUsername = $auth->getUsername();
        if ($sessionUsername !== null) {
            $profile = UserProfileService::readProfile($sessionUsername);
            if (!empty($profile['timezone'])) {
                $cfg->set('client.timezone', $profile['timezone']);
            }
            if (!empty($profile['locale'])) {
                $cfg->set('client.locale', $profile['locale']);
            }
            $cfg->set('client.debug', (bool)($profile['debug'] ?? false));
            // Re-apply debug settings now that the per-user value is loaded.
            $cfg->applyDebugSettings();
        }
    } catch (Throwable $_) {
        // Non-fatal: missing file or parse error; proceed with defaults.
    }
} catch (Throwable $e) {
    // If AppContext or Config can't be created/read, this is an unrecoverable
    // bootstrap error. Use a minimal, reliable fallback logger and die miserably.
    $msg = '[BS] Failed to initialize AppContext or read Config early: ' . $e->getMessage();
    error_log($msg);
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Internal server error during bootstrap.";
    exit(1);
}
