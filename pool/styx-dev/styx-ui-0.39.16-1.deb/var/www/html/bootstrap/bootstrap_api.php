<?php
/**
 * Shared bootstrap for API endpoints (request.php, submit.php).
 * Requires the main bootstrap, sets JSON response header, parses
 * JSON input into $inputData, and exposes requireApiAuth().
 */

require __DIR__ . '/bootstrap.php';

use App\Core\AppContext;
use App\Services\AuthService;

header('Content-Type: application/json');

// Parse JSON input
$input = file_get_contents('php://input');
if (empty($input)) {
    echo json_encode(['status' => 'error', 'response_msg' => 'No input data']);
    exit();
}

try {
    $inputData = json_decode($input, true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($inputData)) {
        echo json_encode(['status' => 'error', 'response_msg' => 'Invalid JSON input (not array)']);
        exit();
    }
} catch (JsonException $e) {
    echo json_encode(['status' => 'error', 'response_msg' => 'Invalid JSON input: ' . $e->getMessage()]);
    exit();
}

/**
 * Checks authentication for the current request.
 * Supports Bearer token (forwarded to backend) and session-based auth.
 * Exits with HTTP 401 if not authenticated.
 */
function requireApiAuth(AppContext $ctx): void
{
    $auth = $ctx->get(AuthService::class);
    $authenticated = false;

    // Bearer token takes priority (API integrations); forwarded to Python backend for validation.
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/Bearer\s+(\S+)/i', $authHeader, $matches)) {
        $auth->setBearerToken($matches[1]);
        $authenticated = true;
    }

    if (!$authenticated && !$auth->isAuthenticated()) {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'response_msg' => 'Unauthorized']);
        exit();
    }
}
