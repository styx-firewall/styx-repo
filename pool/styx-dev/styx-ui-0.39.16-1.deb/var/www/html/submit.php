<?php
/**
 * Submit Entry Point
 * Handles all write operations (create, update, delete)
 * Uses Command Registry pattern for routing
 */

require __DIR__ . '/bootstrap/bootstrap_api.php';

use App\Registry\SubmitRegistry;

// Get command
$command = $inputData['command'] ?? '';
if (empty($command)) {
    echo json_encode(['status' => 'error', 'response_msg' => 'Command not specified']);
    exit();
}

// Public commands that do not require authentication
$publicCommands = [
    'login',
];

// Early authentication check (fail-fast)
if (!in_array($command, $publicCommands, true)) {
    requireApiAuth($ctx);
}

// Lookup and execute command
if (!SubmitRegistry::has($command)) {
    echo json_encode(['status' => 'error', 'response_msg' => "Unknown command: $command"]);
    exit();
}

try {
    $response = SubmitRegistry::execute($ctx, $command, $inputData);
    echo json_encode($response);
} catch (\Exception $e) {
    echo json_encode(['status' => 'error', 'response_msg' => $e->getMessage()]);
}
exit();
