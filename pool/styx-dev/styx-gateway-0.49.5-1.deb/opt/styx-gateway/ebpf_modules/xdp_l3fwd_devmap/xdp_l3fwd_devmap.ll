; ModuleID = 'xdp_l3fwd_devmap.c'
source_filename = "xdp_l3fwd_devmap.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.anon.10 = type { ptr, ptr, ptr, ptr }
%struct.anon.11 = type { ptr, ptr, ptr, ptr }
%struct.anon.12 = type { ptr, ptr, ptr, ptr }
%struct.bpf_fib_lookup = type { i8, i8, i16, i16, %union.anon.1, i32, %union.anon.2, %union.anon.3, %union.anon.4, %union.anon.5, %union.anon.7 }
%union.anon.1 = type { i16 }
%union.anon.2 = type { i32 }
%union.anon.3 = type { [4 x i32] }
%union.anon.4 = type { [4 x i32] }
%union.anon.5 = type { i32 }
%union.anon.7 = type { %struct.anon.8, [8 x i8] }
%struct.anon.8 = type { i32 }

@vlan_map = dso_local global %struct.anon.10 zeroinitializer, section ".maps", align 8, !dbg !0
@tx_port = dso_local global %struct.anon.11 zeroinitializer, section ".maps", align 8, !dbg !146
@_license = dso_local global [4 x i8] c"GPL\00", section "license", align 1, !dbg !142
@stats = dso_local global %struct.anon.12 zeroinitializer, section ".maps", align 8, !dbg !172
@llvm.compiler.used = appending global [5 x ptr] [ptr @_license, ptr @stats, ptr @tx_port, ptr @vlan_map, ptr @xdp_l3_fwd], section "llvm.metadata"

; Function Attrs: nounwind
define dso_local i32 @xdp_l3_fwd(ptr noundef %0) #0 section "xdp" !dbg !215 {
  %2 = alloca i32, align 4, !DIAssignID !278
  %3 = alloca i32, align 4, !DIAssignID !279
  %4 = alloca i32, align 4, !DIAssignID !280
  %5 = alloca i32, align 4, !DIAssignID !281
  %6 = alloca i32, align 4, !DIAssignID !282
  %7 = alloca i32, align 4, !DIAssignID !283
  %8 = alloca i32, align 4, !DIAssignID !284
  %9 = alloca i32, align 4, !DIAssignID !285
  %10 = alloca i32, align 4, !DIAssignID !286
  %11 = alloca i32, align 4, !DIAssignID !287
  %12 = alloca i32, align 4, !DIAssignID !288
  %13 = alloca i32, align 4, !DIAssignID !289
  %14 = alloca i32, align 4, !DIAssignID !290
  %15 = alloca %struct.bpf_fib_lookup, align 4, !DIAssignID !291
    #dbg_assign(i1 undef, !259, !DIExpression(), !291, ptr %15, !DIExpression(), !292)
  %16 = alloca i32, align 4, !DIAssignID !293
    #dbg_assign(i1 undef, !261, !DIExpression(), !293, ptr %16, !DIExpression(), !292)
    #dbg_value(ptr %0, !219, !DIExpression(), !292)
  %17 = getelementptr inbounds i8, ptr %0, i64 4, !dbg !294
  %18 = load i32, ptr %17, align 4, !dbg !294, !tbaa !295
  %19 = zext i32 %18 to i64, !dbg !300
  %20 = inttoptr i64 %19 to ptr, !dbg !301
    #dbg_value(ptr %20, !220, !DIExpression(), !292)
  %21 = load i32, ptr %0, align 4, !dbg !302, !tbaa !303
  %22 = zext i32 %21 to i64, !dbg !304
  %23 = inttoptr i64 %22 to ptr, !dbg !305
    #dbg_value(ptr %23, !221, !DIExpression(), !292)
    #dbg_value(ptr %23, !222, !DIExpression(), !292)
  %24 = getelementptr inbounds i8, ptr %23, i64 14, !dbg !306
  %25 = icmp ugt ptr %24, %20, !dbg !308
  br i1 %25, label %26, label %33, !dbg !309

26:                                               ; preds = %1
    #dbg_assign(i1 undef, !310, !DIExpression(), !278, ptr %2, !DIExpression(), !317)
    #dbg_value(i32 6, !315, !DIExpression(), !317)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #4, !dbg !320
  store i32 0, ptr %2, align 4, !dbg !321, !tbaa !322, !DIAssignID !323
    #dbg_assign(i32 0, !310, !DIExpression(), !323, ptr %2, !DIExpression(), !317)
  %27 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %2) #4, !dbg !324
    #dbg_value(ptr %27, !316, !DIExpression(), !317)
  %28 = icmp eq ptr %27, null, !dbg !325
  br i1 %28, label %32, label %29, !dbg !327

29:                                               ; preds = %26
  %30 = getelementptr inbounds i8, ptr %27, i64 48, !dbg !328
  %31 = atomicrmw add ptr %30, i64 1 seq_cst, align 8, !dbg !330
  br label %32, !dbg !331

32:                                               ; preds = %26, %29
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #4, !dbg !332
  br label %264, !dbg !333

33:                                               ; preds = %1
    #dbg_assign(i1 undef, !310, !DIExpression(), !279, ptr %3, !DIExpression(), !334)
    #dbg_value(i32 0, !315, !DIExpression(), !334)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %3) #4, !dbg !336
  store i32 0, ptr %3, align 4, !dbg !337, !tbaa !322, !DIAssignID !338
    #dbg_assign(i32 0, !310, !DIExpression(), !338, ptr %3, !DIExpression(), !334)
  %34 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %3) #4, !dbg !339
    #dbg_value(ptr %34, !316, !DIExpression(), !334)
  %35 = icmp eq ptr %34, null, !dbg !340
  br i1 %35, label %38, label %36, !dbg !341

36:                                               ; preds = %33
  %37 = atomicrmw add ptr %34, i64 1 seq_cst, align 8, !dbg !342
  br label %38, !dbg !343

38:                                               ; preds = %33, %36
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %3) #4, !dbg !344
  %39 = getelementptr inbounds i8, ptr %23, i64 12, !dbg !345
  %40 = load i16, ptr %39, align 1, !dbg !345, !tbaa !347
  %41 = icmp eq i16 %40, 8, !dbg !350
  br i1 %41, label %49, label %42, !dbg !351

42:                                               ; preds = %38
    #dbg_assign(i1 undef, !310, !DIExpression(), !280, ptr %4, !DIExpression(), !352)
    #dbg_value(i32 3, !315, !DIExpression(), !352)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %4) #4, !dbg !355
  store i32 0, ptr %4, align 4, !dbg !356, !tbaa !322, !DIAssignID !357
    #dbg_assign(i32 0, !310, !DIExpression(), !357, ptr %4, !DIExpression(), !352)
  %43 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %4) #4, !dbg !358
    #dbg_value(ptr %43, !316, !DIExpression(), !352)
  %44 = icmp eq ptr %43, null, !dbg !359
  br i1 %44, label %48, label %45, !dbg !360

45:                                               ; preds = %42
  %46 = getelementptr inbounds i8, ptr %43, i64 24, !dbg !361
  %47 = atomicrmw add ptr %46, i64 1 seq_cst, align 8, !dbg !362
  br label %48, !dbg !363

48:                                               ; preds = %42, %45
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %4) #4, !dbg !364
  br label %264, !dbg !365

49:                                               ; preds = %38
    #dbg_value(ptr %24, !231, !DIExpression(), !292)
  %50 = getelementptr inbounds i8, ptr %23, i64 34, !dbg !366
  %51 = icmp ugt ptr %50, %20, !dbg !368
  br i1 %51, label %52, label %59, !dbg !369

52:                                               ; preds = %49
    #dbg_assign(i1 undef, !310, !DIExpression(), !281, ptr %5, !DIExpression(), !370)
    #dbg_value(i32 6, !315, !DIExpression(), !370)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %5) #4, !dbg !373
  store i32 0, ptr %5, align 4, !dbg !374, !tbaa !322, !DIAssignID !375
    #dbg_assign(i32 0, !310, !DIExpression(), !375, ptr %5, !DIExpression(), !370)
  %53 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %5) #4, !dbg !376
    #dbg_value(ptr %53, !316, !DIExpression(), !370)
  %54 = icmp eq ptr %53, null, !dbg !377
  br i1 %54, label %58, label %55, !dbg !378

55:                                               ; preds = %52
  %56 = getelementptr inbounds i8, ptr %53, i64 48, !dbg !379
  %57 = atomicrmw add ptr %56, i64 1 seq_cst, align 8, !dbg !380
  br label %58, !dbg !381

58:                                               ; preds = %52, %55
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %5) #4, !dbg !382
  br label %264, !dbg !383

59:                                               ; preds = %49
  %60 = getelementptr inbounds i8, ptr %23, i64 22, !dbg !384
  %61 = load i8, ptr %60, align 4, !dbg !384, !tbaa !386
  %62 = icmp ult i8 %61, 2, !dbg !388
  br i1 %62, label %63, label %70, !dbg !389

63:                                               ; preds = %59
    #dbg_assign(i1 undef, !310, !DIExpression(), !282, ptr %6, !DIExpression(), !390)
    #dbg_value(i32 4, !315, !DIExpression(), !390)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %6) #4, !dbg !393
  store i32 0, ptr %6, align 4, !dbg !394, !tbaa !322, !DIAssignID !395
    #dbg_assign(i32 0, !310, !DIExpression(), !395, ptr %6, !DIExpression(), !390)
  %64 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %6) #4, !dbg !396
    #dbg_value(ptr %64, !316, !DIExpression(), !390)
  %65 = icmp eq ptr %64, null, !dbg !397
  br i1 %65, label %69, label %66, !dbg !398

66:                                               ; preds = %63
  %67 = getelementptr inbounds i8, ptr %64, i64 32, !dbg !399
  %68 = atomicrmw add ptr %67, i64 1 seq_cst, align 8, !dbg !400
  br label %69, !dbg !401

69:                                               ; preds = %63, %66
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %6) #4, !dbg !402
  br label %264, !dbg !403

70:                                               ; preds = %59
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %15) #4, !dbg !404
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(64) %15, i8 0, i64 64, i1 false), !dbg !405, !DIAssignID !406
    #dbg_assign(i8 0, !259, !DIExpression(), !406, ptr %15, !DIExpression(), !292)
  store i8 2, ptr %15, align 4, !dbg !407, !tbaa !408, !DIAssignID !410
    #dbg_assign(i8 2, !259, !DIExpression(DW_OP_LLVM_fragment, 0, 8), !410, ptr %15, !DIExpression(), !292)
  %71 = getelementptr inbounds i8, ptr %23, i64 15, !dbg !411
  %72 = load i8, ptr %71, align 1, !dbg !411, !tbaa !412
  %73 = getelementptr inbounds i8, ptr %15, i64 12, !dbg !413
  store i8 %72, ptr %73, align 4, !dbg !414, !tbaa !415, !DIAssignID !416
    #dbg_assign(i8 %72, !259, !DIExpression(DW_OP_LLVM_fragment, 96, 8), !416, ptr %73, !DIExpression(), !292)
  %74 = getelementptr inbounds i8, ptr %23, i64 23, !dbg !417
  %75 = load i8, ptr %74, align 1, !dbg !417, !tbaa !418
  %76 = getelementptr inbounds i8, ptr %15, i64 1, !dbg !419
  store i8 %75, ptr %76, align 1, !dbg !420, !tbaa !421, !DIAssignID !422
    #dbg_assign(i8 %75, !259, !DIExpression(DW_OP_LLVM_fragment, 8, 8), !422, ptr %76, !DIExpression(), !292)
  %77 = getelementptr inbounds i8, ptr %23, i64 16, !dbg !423
  %78 = load i16, ptr %77, align 2, !dbg !423, !tbaa !424
  %79 = call i16 @llvm.bswap.i16(i16 %78), !dbg !423
  %80 = getelementptr inbounds i8, ptr %15, i64 6, !dbg !425
  store i16 %79, ptr %80, align 2, !dbg !426, !tbaa !415, !DIAssignID !427
    #dbg_assign(i16 %79, !259, !DIExpression(DW_OP_LLVM_fragment, 48, 16), !427, ptr %80, !DIExpression(), !292)
  %81 = getelementptr inbounds i8, ptr %23, i64 26, !dbg !428
  %82 = load i32, ptr %81, align 4, !dbg !428, !tbaa !415
  %83 = getelementptr inbounds i8, ptr %15, i64 16, !dbg !429
  store i32 %82, ptr %83, align 4, !dbg !430, !tbaa !415, !DIAssignID !431
    #dbg_assign(i32 %82, !259, !DIExpression(DW_OP_LLVM_fragment, 128, 32), !431, ptr %83, !DIExpression(), !292)
  %84 = getelementptr inbounds i8, ptr %23, i64 30, !dbg !432
  %85 = load i32, ptr %84, align 4, !dbg !432, !tbaa !415
  %86 = getelementptr inbounds i8, ptr %15, i64 32, !dbg !433
  store i32 %85, ptr %86, align 4, !dbg !434, !tbaa !415, !DIAssignID !435
    #dbg_assign(i32 %85, !259, !DIExpression(DW_OP_LLVM_fragment, 256, 32), !435, ptr %86, !DIExpression(), !292)
  %87 = getelementptr inbounds i8, ptr %0, i64 12, !dbg !436
  %88 = load i32, ptr %87, align 4, !dbg !436, !tbaa !437
  %89 = getelementptr inbounds i8, ptr %15, i64 8, !dbg !438
  store i32 %88, ptr %89, align 4, !dbg !439, !tbaa !440, !DIAssignID !441
    #dbg_assign(i32 %88, !259, !DIExpression(DW_OP_LLVM_fragment, 64, 32), !441, ptr %89, !DIExpression(), !292)
  %90 = call i64 inttoptr (i64 69 to ptr)(ptr noundef nonnull %0, ptr noundef nonnull %15, i32 noundef 64, i32 noundef 1) #4, !dbg !442
    #dbg_value(i64 %90, !260, !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value), !292)
  %91 = and i64 %90, 4294967295, !dbg !443
  %92 = icmp eq i64 %91, 0, !dbg !443
  br i1 %92, label %100, label %93, !dbg !445

93:                                               ; preds = %70
    #dbg_assign(i1 undef, !310, !DIExpression(), !283, ptr %7, !DIExpression(), !446)
    #dbg_value(i32 3, !315, !DIExpression(), !446)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %7) #4, !dbg !449
  store i32 0, ptr %7, align 4, !dbg !450, !tbaa !322, !DIAssignID !451
    #dbg_assign(i32 0, !310, !DIExpression(), !451, ptr %7, !DIExpression(), !446)
  %94 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %7) #4, !dbg !452
    #dbg_value(ptr %94, !316, !DIExpression(), !446)
  %95 = icmp eq ptr %94, null, !dbg !453
  br i1 %95, label %99, label %96, !dbg !454

96:                                               ; preds = %93
  %97 = getelementptr inbounds i8, ptr %94, i64 24, !dbg !455
  %98 = atomicrmw add ptr %97, i64 1 seq_cst, align 8, !dbg !456
  br label %99, !dbg !457

99:                                               ; preds = %93, %96
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %7) #4, !dbg !458
  br label %262, !dbg !459

100:                                              ; preds = %70
  %101 = getelementptr inbounds i8, ptr %23, i64 24, !dbg !460
  %102 = load i16, ptr %101, align 2, !dbg !461, !tbaa !462
  %103 = add i16 %102, 1, !dbg !461
  store i16 %103, ptr %101, align 2, !dbg !461, !tbaa !462
  %104 = load i8, ptr %60, align 4, !dbg !463, !tbaa !386
  %105 = add i8 %104, -1, !dbg !463
  store i8 %105, ptr %60, align 4, !dbg !463, !tbaa !386
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %16) #4, !dbg !464
  %106 = load i32, ptr %89, align 4, !dbg !465, !tbaa !440
  store i32 %106, ptr %16, align 4, !dbg !466, !tbaa !322, !DIAssignID !467
    #dbg_assign(i32 %106, !261, !DIExpression(), !467, ptr %16, !DIExpression(), !292)
  %107 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @vlan_map, ptr noundef nonnull %16) #4, !dbg !468
    #dbg_value(ptr %107, !262, !DIExpression(), !292)
  %108 = icmp eq ptr %107, null, !dbg !469
  br i1 %108, label %109, label %148, !dbg !470

109:                                              ; preds = %100
  %110 = getelementptr inbounds i8, ptr %15, i64 52
  %111 = getelementptr inbounds i8, ptr %15, i64 58
  %112 = getelementptr inbounds i8, ptr %23, i64 6
    #dbg_value(i32 0, !276, !DIExpression(), !471)
    #dbg_value(i64 0, !276, !DIExpression(), !471)
  %113 = load i8, ptr %111, align 2, !dbg !472, !tbaa !415
  store i8 %113, ptr %23, align 1, !dbg !475, !tbaa !415
  %114 = load i8, ptr %110, align 4, !dbg !476, !tbaa !415
  store i8 %114, ptr %112, align 1, !dbg !477, !tbaa !415
    #dbg_value(i64 1, !276, !DIExpression(), !471)
  %115 = getelementptr inbounds i8, ptr %15, i64 59, !dbg !472
  %116 = load i8, ptr %115, align 1, !dbg !472, !tbaa !415
  %117 = getelementptr inbounds i8, ptr %23, i64 1, !dbg !478
  store i8 %116, ptr %117, align 1, !dbg !475, !tbaa !415
  %118 = getelementptr inbounds i8, ptr %15, i64 53, !dbg !476
  %119 = load i8, ptr %118, align 1, !dbg !476, !tbaa !415
  %120 = getelementptr inbounds i8, ptr %23, i64 7, !dbg !479
  store i8 %119, ptr %120, align 1, !dbg !477, !tbaa !415
    #dbg_value(i64 2, !276, !DIExpression(), !471)
  %121 = getelementptr inbounds i8, ptr %15, i64 60, !dbg !472
  %122 = load i8, ptr %121, align 4, !dbg !472, !tbaa !415
  %123 = getelementptr inbounds i8, ptr %23, i64 2, !dbg !478
  store i8 %122, ptr %123, align 1, !dbg !475, !tbaa !415
  %124 = getelementptr inbounds i8, ptr %15, i64 54, !dbg !476
  %125 = load i8, ptr %124, align 2, !dbg !476, !tbaa !415
  %126 = getelementptr inbounds i8, ptr %23, i64 8, !dbg !479
  store i8 %125, ptr %126, align 1, !dbg !477, !tbaa !415
    #dbg_value(i64 3, !276, !DIExpression(), !471)
  %127 = getelementptr inbounds i8, ptr %15, i64 61, !dbg !472
  %128 = load i8, ptr %127, align 1, !dbg !472, !tbaa !415
  %129 = getelementptr inbounds i8, ptr %23, i64 3, !dbg !478
  store i8 %128, ptr %129, align 1, !dbg !475, !tbaa !415
  %130 = getelementptr inbounds i8, ptr %15, i64 55, !dbg !476
  %131 = load i8, ptr %130, align 1, !dbg !476, !tbaa !415
  %132 = getelementptr inbounds i8, ptr %23, i64 9, !dbg !479
  store i8 %131, ptr %132, align 1, !dbg !477, !tbaa !415
    #dbg_value(i64 4, !276, !DIExpression(), !471)
  %133 = getelementptr inbounds i8, ptr %15, i64 62, !dbg !472
  %134 = load i8, ptr %133, align 2, !dbg !472, !tbaa !415
  %135 = getelementptr inbounds i8, ptr %23, i64 4, !dbg !478
  store i8 %134, ptr %135, align 1, !dbg !475, !tbaa !415
  %136 = getelementptr inbounds i8, ptr %15, i64 56, !dbg !476
  %137 = load i8, ptr %136, align 4, !dbg !476, !tbaa !415
  %138 = getelementptr inbounds i8, ptr %23, i64 10, !dbg !479
  store i8 %137, ptr %138, align 1, !dbg !477, !tbaa !415
    #dbg_value(i64 5, !276, !DIExpression(), !471)
  %139 = getelementptr inbounds i8, ptr %15, i64 63, !dbg !472
  %140 = load i8, ptr %139, align 1, !dbg !472, !tbaa !415
  %141 = getelementptr inbounds i8, ptr %23, i64 5, !dbg !478
  store i8 %140, ptr %141, align 1, !dbg !475, !tbaa !415
  %142 = getelementptr inbounds i8, ptr %15, i64 57, !dbg !476
  %143 = load i8, ptr %142, align 1, !dbg !476, !tbaa !415
  %144 = getelementptr inbounds i8, ptr %23, i64 11, !dbg !479
  store i8 %143, ptr %144, align 1, !dbg !477, !tbaa !415
    #dbg_value(i64 6, !276, !DIExpression(), !471)
  %145 = load i32, ptr %89, align 4, !dbg !480, !tbaa !440
  %146 = load i32, ptr %87, align 4, !dbg !482, !tbaa !437
  %147 = icmp eq i32 %145, %146, !dbg !483
  br i1 %147, label %242, label %249, !dbg !484

148:                                              ; preds = %100
  %149 = load i32, ptr %107, align 4, !dbg !485, !tbaa !486
    #dbg_value(i32 %149, !263, !DIExpression(), !488)
  %150 = getelementptr inbounds i8, ptr %107, i64 4, !dbg !489
  %151 = load i16, ptr %150, align 4, !dbg !489, !tbaa !490
    #dbg_value(i16 %151, !266, !DIExpression(), !488)
    #dbg_assign(i1 undef, !310, !DIExpression(), !284, ptr %8, !DIExpression(), !491)
    #dbg_value(i32 5, !315, !DIExpression(), !491)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %8) #4, !dbg !493
  store i32 0, ptr %8, align 4, !dbg !494, !tbaa !322, !DIAssignID !495
    #dbg_assign(i32 0, !310, !DIExpression(), !495, ptr %8, !DIExpression(), !491)
  %152 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %8) #4, !dbg !496
    #dbg_value(ptr %152, !316, !DIExpression(), !491)
  %153 = icmp eq ptr %152, null, !dbg !497
  br i1 %153, label %157, label %154, !dbg !498

154:                                              ; preds = %148
  %155 = getelementptr inbounds i8, ptr %152, i64 40, !dbg !499
  %156 = atomicrmw add ptr %155, i64 1 seq_cst, align 8, !dbg !500
  br label %157, !dbg !501

157:                                              ; preds = %148, %154
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %8) #4, !dbg !502
  %158 = call i64 inttoptr (i64 44 to ptr)(ptr noundef nonnull %0, i32 noundef -4) #4, !dbg !503
  %159 = icmp eq i64 %158, 0, !dbg !503
  br i1 %159, label %167, label %160, !dbg !505

160:                                              ; preds = %157
    #dbg_assign(i1 undef, !310, !DIExpression(), !285, ptr %9, !DIExpression(), !506)
    #dbg_value(i32 6, !315, !DIExpression(), !506)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9) #4, !dbg !509
  store i32 0, ptr %9, align 4, !dbg !510, !tbaa !322, !DIAssignID !511
    #dbg_assign(i32 0, !310, !DIExpression(), !511, ptr %9, !DIExpression(), !506)
  %161 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %9) #4, !dbg !512
    #dbg_value(ptr %161, !316, !DIExpression(), !506)
  %162 = icmp eq ptr %161, null, !dbg !513
  br i1 %162, label %166, label %163, !dbg !514

163:                                              ; preds = %160
  %164 = getelementptr inbounds i8, ptr %161, i64 48, !dbg !515
  %165 = atomicrmw add ptr %164, i64 1 seq_cst, align 8, !dbg !516
  br label %166, !dbg !517

166:                                              ; preds = %160, %163
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9) #4, !dbg !518
  br label %260, !dbg !519

167:                                              ; preds = %157
  %168 = load i32, ptr %0, align 4, !dbg !520, !tbaa !303
  %169 = zext i32 %168 to i64, !dbg !521
  %170 = inttoptr i64 %169 to ptr, !dbg !522
    #dbg_value(ptr %170, !221, !DIExpression(), !292)
  %171 = load i32, ptr %17, align 4, !dbg !523, !tbaa !295
  %172 = zext i32 %171 to i64, !dbg !524
  %173 = inttoptr i64 %172 to ptr, !dbg !525
    #dbg_value(ptr %173, !220, !DIExpression(), !292)
    #dbg_value(ptr %170, !267, !DIExpression(), !488)
  %174 = getelementptr inbounds i8, ptr %170, i64 18, !dbg !526
  %175 = icmp ugt ptr %174, %173, !dbg !528
  br i1 %175, label %218, label %176, !dbg !529

176:                                              ; preds = %167
  %177 = getelementptr inbounds i8, ptr %170, i64 14, !dbg !530
  %178 = getelementptr inbounds i8, ptr %15, i64 52
  %179 = getelementptr inbounds i8, ptr %15, i64 58
  %180 = getelementptr inbounds i8, ptr %170, i64 6
    #dbg_value(i32 0, !268, !DIExpression(), !531)
    #dbg_value(i64 0, !268, !DIExpression(), !531)
  %181 = load i8, ptr %179, align 2, !dbg !532, !tbaa !415
  store i8 %181, ptr %170, align 1, !dbg !535, !tbaa !415
  %182 = load i8, ptr %178, align 4, !dbg !536, !tbaa !415
  store i8 %182, ptr %180, align 1, !dbg !537, !tbaa !415
    #dbg_value(i64 1, !268, !DIExpression(), !531)
  %183 = getelementptr inbounds i8, ptr %15, i64 59, !dbg !532
  %184 = load i8, ptr %183, align 1, !dbg !532, !tbaa !415
  %185 = getelementptr inbounds i8, ptr %170, i64 1, !dbg !538
  store i8 %184, ptr %185, align 1, !dbg !535, !tbaa !415
  %186 = getelementptr inbounds i8, ptr %15, i64 53, !dbg !536
  %187 = load i8, ptr %186, align 1, !dbg !536, !tbaa !415
  %188 = getelementptr inbounds i8, ptr %170, i64 7, !dbg !539
  store i8 %187, ptr %188, align 1, !dbg !537, !tbaa !415
    #dbg_value(i64 2, !268, !DIExpression(), !531)
  %189 = getelementptr inbounds i8, ptr %15, i64 60, !dbg !532
  %190 = load i8, ptr %189, align 4, !dbg !532, !tbaa !415
  %191 = getelementptr inbounds i8, ptr %170, i64 2, !dbg !538
  store i8 %190, ptr %191, align 1, !dbg !535, !tbaa !415
  %192 = getelementptr inbounds i8, ptr %15, i64 54, !dbg !536
  %193 = load i8, ptr %192, align 2, !dbg !536, !tbaa !415
  %194 = getelementptr inbounds i8, ptr %170, i64 8, !dbg !539
  store i8 %193, ptr %194, align 1, !dbg !537, !tbaa !415
    #dbg_value(i64 3, !268, !DIExpression(), !531)
  %195 = getelementptr inbounds i8, ptr %15, i64 61, !dbg !532
  %196 = load i8, ptr %195, align 1, !dbg !532, !tbaa !415
  %197 = getelementptr inbounds i8, ptr %170, i64 3, !dbg !538
  store i8 %196, ptr %197, align 1, !dbg !535, !tbaa !415
  %198 = getelementptr inbounds i8, ptr %15, i64 55, !dbg !536
  %199 = load i8, ptr %198, align 1, !dbg !536, !tbaa !415
  %200 = getelementptr inbounds i8, ptr %170, i64 9, !dbg !539
  store i8 %199, ptr %200, align 1, !dbg !537, !tbaa !415
    #dbg_value(i64 4, !268, !DIExpression(), !531)
  %201 = getelementptr inbounds i8, ptr %15, i64 62, !dbg !532
  %202 = load i8, ptr %201, align 2, !dbg !532, !tbaa !415
  %203 = getelementptr inbounds i8, ptr %170, i64 4, !dbg !538
  store i8 %202, ptr %203, align 1, !dbg !535, !tbaa !415
  %204 = getelementptr inbounds i8, ptr %15, i64 56, !dbg !536
  %205 = load i8, ptr %204, align 4, !dbg !536, !tbaa !415
  %206 = getelementptr inbounds i8, ptr %170, i64 10, !dbg !539
  store i8 %205, ptr %206, align 1, !dbg !537, !tbaa !415
    #dbg_value(i64 5, !268, !DIExpression(), !531)
  %207 = getelementptr inbounds i8, ptr %15, i64 63, !dbg !532
  %208 = load i8, ptr %207, align 1, !dbg !532, !tbaa !415
  %209 = getelementptr inbounds i8, ptr %170, i64 5, !dbg !538
  store i8 %208, ptr %209, align 1, !dbg !535, !tbaa !415
  %210 = getelementptr inbounds i8, ptr %15, i64 57, !dbg !536
  %211 = load i8, ptr %210, align 1, !dbg !536, !tbaa !415
  %212 = getelementptr inbounds i8, ptr %170, i64 11, !dbg !539
  store i8 %211, ptr %212, align 1, !dbg !537, !tbaa !415
    #dbg_value(i64 6, !268, !DIExpression(), !531)
  %213 = getelementptr inbounds i8, ptr %170, i64 12, !dbg !540
  store i16 129, ptr %213, align 1, !dbg !541, !tbaa !347
    #dbg_value(ptr %177, !270, !DIExpression(), !488)
  %214 = call i16 @llvm.bswap.i16(i16 %151), !dbg !542
  store i16 %214, ptr %177, align 2, !dbg !543, !tbaa !544
  %215 = getelementptr inbounds i8, ptr %170, i64 16, !dbg !546
  store i16 8, ptr %215, align 2, !dbg !547, !tbaa !548
  %216 = load i32, ptr %87, align 4, !dbg !549, !tbaa !437
  %217 = icmp eq i32 %149, %216, !dbg !551
  br i1 %217, label %225, label %232, !dbg !552

218:                                              ; preds = %167
    #dbg_assign(i1 undef, !310, !DIExpression(), !286, ptr %10, !DIExpression(), !553)
    #dbg_value(i32 6, !315, !DIExpression(), !553)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10) #4, !dbg !556
  store i32 0, ptr %10, align 4, !dbg !557, !tbaa !322, !DIAssignID !558
    #dbg_assign(i32 0, !310, !DIExpression(), !558, ptr %10, !DIExpression(), !553)
  %219 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %10) #4, !dbg !559
    #dbg_value(ptr %219, !316, !DIExpression(), !553)
  %220 = icmp eq ptr %219, null, !dbg !560
  br i1 %220, label %224, label %221, !dbg !561

221:                                              ; preds = %218
  %222 = getelementptr inbounds i8, ptr %219, i64 48, !dbg !562
  %223 = atomicrmw add ptr %222, i64 1 seq_cst, align 8, !dbg !563
  br label %224, !dbg !564

224:                                              ; preds = %218, %221
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10) #4, !dbg !565
  br label %260, !dbg !566

225:                                              ; preds = %176
    #dbg_assign(i1 undef, !310, !DIExpression(), !287, ptr %11, !DIExpression(), !567)
    #dbg_value(i32 1, !315, !DIExpression(), !567)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %11) #4, !dbg !570
  store i32 0, ptr %11, align 4, !dbg !571, !tbaa !322, !DIAssignID !572
    #dbg_assign(i32 0, !310, !DIExpression(), !572, ptr %11, !DIExpression(), !567)
  %226 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %11) #4, !dbg !573
    #dbg_value(ptr %226, !316, !DIExpression(), !567)
  %227 = icmp eq ptr %226, null, !dbg !574
  br i1 %227, label %231, label %228, !dbg !575

228:                                              ; preds = %225
  %229 = getelementptr inbounds i8, ptr %226, i64 8, !dbg !576
  %230 = atomicrmw add ptr %229, i64 1 seq_cst, align 8, !dbg !577
  br label %231, !dbg !578

231:                                              ; preds = %225, %228
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %11) #4, !dbg !579
  br label %260, !dbg !580

232:                                              ; preds = %176
    #dbg_assign(i1 undef, !310, !DIExpression(), !288, ptr %12, !DIExpression(), !581)
    #dbg_value(i32 2, !315, !DIExpression(), !581)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %12) #4, !dbg !583
  store i32 0, ptr %12, align 4, !dbg !584, !tbaa !322, !DIAssignID !585
    #dbg_assign(i32 0, !310, !DIExpression(), !585, ptr %12, !DIExpression(), !581)
  %233 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %12) #4, !dbg !586
    #dbg_value(ptr %233, !316, !DIExpression(), !581)
  %234 = icmp eq ptr %233, null, !dbg !587
  br i1 %234, label %238, label %235, !dbg !588

235:                                              ; preds = %232
  %236 = getelementptr inbounds i8, ptr %233, i64 16, !dbg !589
  %237 = atomicrmw add ptr %236, i64 1 seq_cst, align 8, !dbg !590
  br label %238, !dbg !591

238:                                              ; preds = %232, %235
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %12) #4, !dbg !592
  %239 = zext i32 %149 to i64, !dbg !593
  %240 = call i64 inttoptr (i64 51 to ptr)(ptr noundef nonnull @tx_port, i64 noundef %239, i64 noundef 0) #4, !dbg !594
  %241 = trunc i64 %240 to i32, !dbg !594
  br label %260, !dbg !595

242:                                              ; preds = %109
    #dbg_assign(i1 undef, !310, !DIExpression(), !289, ptr %13, !DIExpression(), !596)
    #dbg_value(i32 1, !315, !DIExpression(), !596)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %13) #4, !dbg !599
  store i32 0, ptr %13, align 4, !dbg !600, !tbaa !322, !DIAssignID !601
    #dbg_assign(i32 0, !310, !DIExpression(), !601, ptr %13, !DIExpression(), !596)
  %243 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %13) #4, !dbg !602
    #dbg_value(ptr %243, !316, !DIExpression(), !596)
  %244 = icmp eq ptr %243, null, !dbg !603
  br i1 %244, label %248, label %245, !dbg !604

245:                                              ; preds = %242
  %246 = getelementptr inbounds i8, ptr %243, i64 8, !dbg !605
  %247 = atomicrmw add ptr %246, i64 1 seq_cst, align 8, !dbg !606
  br label %248, !dbg !607

248:                                              ; preds = %242, %245
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %13) #4, !dbg !608
  br label %260, !dbg !609

249:                                              ; preds = %109
    #dbg_assign(i1 undef, !310, !DIExpression(), !290, ptr %14, !DIExpression(), !610)
    #dbg_value(i32 2, !315, !DIExpression(), !610)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %14) #4, !dbg !612
  store i32 0, ptr %14, align 4, !dbg !613, !tbaa !322, !DIAssignID !614
    #dbg_assign(i32 0, !310, !DIExpression(), !614, ptr %14, !DIExpression(), !610)
  %250 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %14) #4, !dbg !615
    #dbg_value(ptr %250, !316, !DIExpression(), !610)
  %251 = icmp eq ptr %250, null, !dbg !616
  br i1 %251, label %255, label %252, !dbg !617

252:                                              ; preds = %249
  %253 = getelementptr inbounds i8, ptr %250, i64 16, !dbg !618
  %254 = atomicrmw add ptr %253, i64 1 seq_cst, align 8, !dbg !619
  br label %255, !dbg !620

255:                                              ; preds = %249, %252
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %14) #4, !dbg !621
  %256 = load i32, ptr %89, align 4, !dbg !622, !tbaa !440
  %257 = zext i32 %256 to i64, !dbg !623
  %258 = call i64 inttoptr (i64 51 to ptr)(ptr noundef nonnull @tx_port, i64 noundef %257, i64 noundef 0) #4, !dbg !624
  %259 = trunc i64 %258 to i32, !dbg !624
  br label %260, !dbg !625

260:                                              ; preds = %166, %231, %238, %224, %255, %248
  %261 = phi i32 [ 3, %248 ], [ %259, %255 ], [ 0, %166 ], [ 0, %224 ], [ 3, %231 ], [ %241, %238 ], !dbg !292
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %16) #4, !dbg !626
  br label %262

262:                                              ; preds = %260, %99
  %263 = phi i32 [ 2, %99 ], [ %261, %260 ], !dbg !292
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %15) #4, !dbg !626
  br label %264

264:                                              ; preds = %58, %69, %262, %48, %32
  %265 = phi i32 [ 0, %32 ], [ 2, %48 ], [ 0, %58 ], [ 1, %69 ], [ %263, %262 ], !dbg !292
  ret i32 %265, !dbg !626
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

attributes #0 = { nounwind "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!208, !209, !210, !211, !212, !213}
!llvm.ident = !{!214}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "vlan_map", scope: !2, file: !3, line: 78, type: !196, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Debian clang version 19.1.7 (3+b1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !34, globals: !41, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "xdp_l3fwd_devmap.c", directory: "/opt/styx-gateway/ebpf_modules/xdp_l3fwd_devmap", checksumkind: CSK_MD5, checksum: "ac6b59a29ff33391bbf24c37ca6e1d4a")
!4 = !{!5, !14, !22}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "xdp_action", file: !6, line: 6449, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "/usr/include/linux/bpf.h", directory: "", checksumkind: CSK_MD5, checksum: "62c7f09341fb12dc06cafad5394e5c39")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13}
!9 = !DIEnumerator(name: "XDP_ABORTED", value: 0)
!10 = !DIEnumerator(name: "XDP_DROP", value: 1)
!11 = !DIEnumerator(name: "XDP_PASS", value: 2)
!12 = !DIEnumerator(name: "XDP_TX", value: 3)
!13 = !DIEnumerator(name: "XDP_REDIRECT", value: 4)
!14 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 7149, baseType: !7, size: 32, elements: !15)
!15 = !{!16, !17, !18, !19, !20, !21}
!16 = !DIEnumerator(name: "BPF_FIB_LOOKUP_DIRECT", value: 1)
!17 = !DIEnumerator(name: "BPF_FIB_LOOKUP_OUTPUT", value: 2)
!18 = !DIEnumerator(name: "BPF_FIB_LOOKUP_SKIP_NEIGH", value: 4)
!19 = !DIEnumerator(name: "BPF_FIB_LOOKUP_TBID", value: 8)
!20 = !DIEnumerator(name: "BPF_FIB_LOOKUP_SRC", value: 16)
!21 = !DIEnumerator(name: "BPF_FIB_LOOKUP_MARK", value: 32)
!22 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 7158, baseType: !7, size: 32, elements: !23)
!23 = !{!24, !25, !26, !27, !28, !29, !30, !31, !32, !33}
!24 = !DIEnumerator(name: "BPF_FIB_LKUP_RET_SUCCESS", value: 0)
!25 = !DIEnumerator(name: "BPF_FIB_LKUP_RET_BLACKHOLE", value: 1)
!26 = !DIEnumerator(name: "BPF_FIB_LKUP_RET_UNREACHABLE", value: 2)
!27 = !DIEnumerator(name: "BPF_FIB_LKUP_RET_PROHIBIT", value: 3)
!28 = !DIEnumerator(name: "BPF_FIB_LKUP_RET_NOT_FWDED", value: 4)
!29 = !DIEnumerator(name: "BPF_FIB_LKUP_RET_FWD_DISABLED", value: 5)
!30 = !DIEnumerator(name: "BPF_FIB_LKUP_RET_UNSUPP_LWT", value: 6)
!31 = !DIEnumerator(name: "BPF_FIB_LKUP_RET_NO_NEIGH", value: 7)
!32 = !DIEnumerator(name: "BPF_FIB_LKUP_RET_FRAG_NEEDED", value: 8)
!33 = !DIEnumerator(name: "BPF_FIB_LKUP_RET_NO_SRC_ADDR", value: 9)
!34 = !{!35, !36, !37, !40}
!35 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!36 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!37 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u16", file: !38, line: 24, baseType: !39)
!38 = !DIFile(filename: "/usr/include/asm-generic/int-ll64.h", directory: "", checksumkind: CSK_MD5, checksum: "b810f270733e106319b67ef512c6246e")
!39 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!40 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!41 = !{!42, !111, !119, !134, !142, !146, !0, !172}
!42 = !DIGlobalVariableExpression(var: !43, expr: !DIExpression())
!43 = distinct !DIGlobalVariable(name: "bpf_fib_lookup", scope: !2, file: !44, line: 1875, type: !45, isLocal: true, isDefinition: true)
!44 = !DIFile(filename: "/usr/include/bpf/bpf_helper_defs.h", directory: "", checksumkind: CSK_MD5, checksum: "a5a8a4f934aa5711dec23fec645c4001")
!45 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !46)
!46 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !47, size: 64)
!47 = !DISubroutineType(types: !48)
!48 = !{!36, !35, !49, !40, !66}
!49 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !50, size: 64)
!50 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_fib_lookup", file: !6, line: 7171, size: 512, elements: !51)
!51 = !{!52, !55, !56, !59, !60, !65, !67, !74, !82, !87, !96}
!52 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !50, file: !6, line: 7175, baseType: !53, size: 8)
!53 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u8", file: !38, line: 21, baseType: !54)
!54 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!55 = !DIDerivedType(tag: DW_TAG_member, name: "l4_protocol", scope: !50, file: !6, line: 7178, baseType: !53, size: 8, offset: 8)
!56 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !50, file: !6, line: 7179, baseType: !57, size: 16, offset: 16)
!57 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be16", file: !58, line: 32, baseType: !37)
!58 = !DIFile(filename: "/usr/include/linux/types.h", directory: "", checksumkind: CSK_MD5, checksum: "c0ade1a1a309d6896ce6080a51a2d105")
!59 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !50, file: !6, line: 7180, baseType: !57, size: 16, offset: 32)
!60 = !DIDerivedType(tag: DW_TAG_member, scope: !50, file: !6, line: 7182, baseType: !61, size: 16, align: 16, offset: 48)
!61 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !50, file: !6, line: 7182, size: 16, align: 16, elements: !62)
!62 = !{!63, !64}
!63 = !DIDerivedType(tag: DW_TAG_member, name: "tot_len", scope: !61, file: !6, line: 7184, baseType: !37, size: 16)
!64 = !DIDerivedType(tag: DW_TAG_member, name: "mtu_result", scope: !61, file: !6, line: 7187, baseType: !37, size: 16)
!65 = !DIDerivedType(tag: DW_TAG_member, name: "ifindex", scope: !50, file: !6, line: 7192, baseType: !66, size: 32, offset: 64)
!66 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !38, line: 27, baseType: !7)
!67 = !DIDerivedType(tag: DW_TAG_member, scope: !50, file: !6, line: 7194, baseType: !68, size: 32, offset: 96)
!68 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !50, file: !6, line: 7194, size: 32, elements: !69)
!69 = !{!70, !71, !73}
!70 = !DIDerivedType(tag: DW_TAG_member, name: "tos", scope: !68, file: !6, line: 7196, baseType: !53, size: 8)
!71 = !DIDerivedType(tag: DW_TAG_member, name: "flowinfo", scope: !68, file: !6, line: 7197, baseType: !72, size: 32)
!72 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be32", file: !58, line: 34, baseType: !66)
!73 = !DIDerivedType(tag: DW_TAG_member, name: "rt_metric", scope: !68, file: !6, line: 7200, baseType: !66, size: 32)
!74 = !DIDerivedType(tag: DW_TAG_member, scope: !50, file: !6, line: 7206, baseType: !75, size: 128, offset: 128)
!75 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !50, file: !6, line: 7206, size: 128, elements: !76)
!76 = !{!77, !78}
!77 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_src", scope: !75, file: !6, line: 7207, baseType: !72, size: 32)
!78 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_src", scope: !75, file: !6, line: 7208, baseType: !79, size: 128)
!79 = !DICompositeType(tag: DW_TAG_array_type, baseType: !66, size: 128, elements: !80)
!80 = !{!81}
!81 = !DISubrange(count: 4)
!82 = !DIDerivedType(tag: DW_TAG_member, scope: !50, file: !6, line: 7215, baseType: !83, size: 128, offset: 256)
!83 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !50, file: !6, line: 7215, size: 128, elements: !84)
!84 = !{!85, !86}
!85 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_dst", scope: !83, file: !6, line: 7216, baseType: !72, size: 32)
!86 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_dst", scope: !83, file: !6, line: 7217, baseType: !79, size: 128)
!87 = !DIDerivedType(tag: DW_TAG_member, scope: !50, file: !6, line: 7220, baseType: !88, size: 32, offset: 384)
!88 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !50, file: !6, line: 7220, size: 32, elements: !89)
!89 = !{!90, !95}
!90 = !DIDerivedType(tag: DW_TAG_member, scope: !88, file: !6, line: 7221, baseType: !91, size: 32)
!91 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !88, file: !6, line: 7221, size: 32, elements: !92)
!92 = !{!93, !94}
!93 = !DIDerivedType(tag: DW_TAG_member, name: "h_vlan_proto", scope: !91, file: !6, line: 7223, baseType: !57, size: 16)
!94 = !DIDerivedType(tag: DW_TAG_member, name: "h_vlan_TCI", scope: !91, file: !6, line: 7224, baseType: !57, size: 16, offset: 16)
!95 = !DIDerivedType(tag: DW_TAG_member, name: "tbid", scope: !88, file: !6, line: 7230, baseType: !66, size: 32)
!96 = !DIDerivedType(tag: DW_TAG_member, scope: !50, file: !6, line: 7233, baseType: !97, size: 96, offset: 416)
!97 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !50, file: !6, line: 7233, size: 96, elements: !98)
!98 = !{!99, !103}
!99 = !DIDerivedType(tag: DW_TAG_member, scope: !97, file: !6, line: 7235, baseType: !100, size: 32)
!100 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !97, file: !6, line: 7235, size: 32, elements: !101)
!101 = !{!102}
!102 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !100, file: !6, line: 7236, baseType: !66, size: 32)
!103 = !DIDerivedType(tag: DW_TAG_member, scope: !97, file: !6, line: 7241, baseType: !104, size: 96)
!104 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !97, file: !6, line: 7241, size: 96, elements: !105)
!105 = !{!106, !110}
!106 = !DIDerivedType(tag: DW_TAG_member, name: "smac", scope: !104, file: !6, line: 7242, baseType: !107, size: 48)
!107 = !DICompositeType(tag: DW_TAG_array_type, baseType: !53, size: 48, elements: !108)
!108 = !{!109}
!109 = !DISubrange(count: 6)
!110 = !DIDerivedType(tag: DW_TAG_member, name: "dmac", scope: !104, file: !6, line: 7243, baseType: !107, size: 48, offset: 48)
!111 = !DIGlobalVariableExpression(var: !112, expr: !DIExpression())
!112 = distinct !DIGlobalVariable(name: "bpf_map_lookup_elem", scope: !2, file: !44, line: 64, type: !113, isLocal: true, isDefinition: true)
!113 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !114)
!114 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !115, size: 64)
!115 = !DISubroutineType(types: !116)
!116 = !{!35, !35, !117}
!117 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !118, size: 64)
!118 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!119 = !DIGlobalVariableExpression(var: !120, expr: !DIExpression())
!120 = distinct !DIGlobalVariable(name: "bpf_xdp_adjust_head", scope: !2, file: !44, line: 1144, type: !121, isLocal: true, isDefinition: true)
!121 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !122)
!122 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !123, size: 64)
!123 = !DISubroutineType(types: !124)
!124 = !{!36, !125, !40}
!125 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !126, size: 64)
!126 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "xdp_md", file: !6, line: 6460, size: 192, elements: !127)
!127 = !{!128, !129, !130, !131, !132, !133}
!128 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !126, file: !6, line: 6461, baseType: !66, size: 32)
!129 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !126, file: !6, line: 6462, baseType: !66, size: 32, offset: 32)
!130 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !126, file: !6, line: 6463, baseType: !66, size: 32, offset: 64)
!131 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !126, file: !6, line: 6465, baseType: !66, size: 32, offset: 96)
!132 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_index", scope: !126, file: !6, line: 6466, baseType: !66, size: 32, offset: 128)
!133 = !DIDerivedType(tag: DW_TAG_member, name: "egress_ifindex", scope: !126, file: !6, line: 6468, baseType: !66, size: 32, offset: 160)
!134 = !DIGlobalVariableExpression(var: !135, expr: !DIExpression())
!135 = distinct !DIGlobalVariable(name: "bpf_redirect_map", scope: !2, file: !44, line: 1333, type: !136, isLocal: true, isDefinition: true)
!136 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !137)
!137 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !138, size: 64)
!138 = !DISubroutineType(types: !139)
!139 = !{!36, !35, !140, !140}
!140 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !38, line: 31, baseType: !141)
!141 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!142 = !DIGlobalVariableExpression(var: !143, expr: !DIExpression())
!143 = distinct !DIGlobalVariable(name: "_license", scope: !2, file: !3, line: 226, type: !144, isLocal: false, isDefinition: true)
!144 = !DICompositeType(tag: DW_TAG_array_type, baseType: !145, size: 32, elements: !80)
!145 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!146 = !DIGlobalVariableExpression(var: !147, expr: !DIExpression())
!147 = distinct !DIGlobalVariable(name: "tx_port", scope: !2, file: !3, line: 71, type: !148, isLocal: false, isDefinition: true)
!148 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 62, size: 256, elements: !149)
!149 = !{!150, !155, !160, !162}
!150 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !148, file: !3, line: 63, baseType: !151, size: 64)
!151 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !152, size: 64)
!152 = !DICompositeType(tag: DW_TAG_array_type, baseType: !40, size: 800, elements: !153)
!153 = !{!154}
!154 = !DISubrange(count: 25)
!155 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !148, file: !3, line: 64, baseType: !156, size: 64, offset: 64)
!156 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !157, size: 64)
!157 = !DICompositeType(tag: DW_TAG_array_type, baseType: !40, size: 8192, elements: !158)
!158 = !{!159}
!159 = !DISubrange(count: 256)
!160 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !148, file: !3, line: 65, baseType: !161, size: 64, offset: 128)
!161 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !66, size: 64)
!162 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !148, file: !3, line: 70, baseType: !163, size: 64, offset: 192)
!163 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !164, size: 64)
!164 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_devmap_val", file: !6, line: 6476, size: 64, elements: !165)
!165 = !{!166, !167}
!166 = !DIDerivedType(tag: DW_TAG_member, name: "ifindex", scope: !164, file: !6, line: 6477, baseType: !66, size: 32)
!167 = !DIDerivedType(tag: DW_TAG_member, name: "bpf_prog", scope: !164, file: !6, line: 6481, baseType: !168, size: 32, offset: 32)
!168 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !164, file: !6, line: 6478, size: 32, elements: !169)
!169 = !{!170, !171}
!170 = !DIDerivedType(tag: DW_TAG_member, name: "fd", scope: !168, file: !6, line: 6479, baseType: !40, size: 32)
!171 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !168, file: !6, line: 6480, baseType: !66, size: 32)
!172 = !DIGlobalVariableExpression(var: !173, expr: !DIExpression())
!173 = distinct !DIGlobalVariable(name: "stats", scope: !2, file: !3, line: 101, type: !174, isLocal: false, isDefinition: true)
!174 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 96, size: 256, elements: !175)
!175 = !{!176, !179, !184, !185}
!176 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !174, file: !3, line: 97, baseType: !177, size: 64)
!177 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !178, size: 64)
!178 = !DICompositeType(tag: DW_TAG_array_type, baseType: !40, size: 192, elements: !108)
!179 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !174, file: !3, line: 98, baseType: !180, size: 64, offset: 64)
!180 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !181, size: 64)
!181 = !DICompositeType(tag: DW_TAG_array_type, baseType: !40, size: 32, elements: !182)
!182 = !{!183}
!183 = !DISubrange(count: 1)
!184 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !174, file: !3, line: 99, baseType: !161, size: 64, offset: 128)
!185 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !174, file: !3, line: 100, baseType: !186, size: 64, offset: 192)
!186 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !187, size: 64)
!187 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "stats_t", file: !3, line: 86, size: 448, elements: !188)
!188 = !{!189, !190, !191, !192, !193, !194, !195}
!189 = !DIDerivedType(tag: DW_TAG_member, name: "packets_processed", scope: !187, file: !3, line: 87, baseType: !140, size: 64)
!190 = !DIDerivedType(tag: DW_TAG_member, name: "packets_forwarded", scope: !187, file: !3, line: 88, baseType: !140, size: 64, offset: 64)
!191 = !DIDerivedType(tag: DW_TAG_member, name: "packets_redirected", scope: !187, file: !3, line: 89, baseType: !140, size: 64, offset: 128)
!192 = !DIDerivedType(tag: DW_TAG_member, name: "packets_passed", scope: !187, file: !3, line: 90, baseType: !140, size: 64, offset: 192)
!193 = !DIDerivedType(tag: DW_TAG_member, name: "packets_dropped", scope: !187, file: !3, line: 91, baseType: !140, size: 64, offset: 256)
!194 = !DIDerivedType(tag: DW_TAG_member, name: "packets_vlan", scope: !187, file: !3, line: 92, baseType: !140, size: 64, offset: 320)
!195 = !DIDerivedType(tag: DW_TAG_member, name: "errors", scope: !187, file: !3, line: 93, baseType: !140, size: 64, offset: 384)
!196 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 73, size: 256, elements: !197)
!197 = !{!198, !199, !200, !201}
!198 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !196, file: !3, line: 74, baseType: !180, size: 64)
!199 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !196, file: !3, line: 75, baseType: !156, size: 64, offset: 64)
!200 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !196, file: !3, line: 76, baseType: !161, size: 64, offset: 128)
!201 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !196, file: !3, line: 77, baseType: !202, size: 64, offset: 192)
!202 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !203, size: 64)
!203 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "vlan_info", file: !3, line: 49, size: 64, elements: !204)
!204 = !{!205, !206, !207}
!205 = !DIDerivedType(tag: DW_TAG_member, name: "parent_ifindex", scope: !203, file: !3, line: 50, baseType: !66, size: 32)
!206 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_id", scope: !203, file: !3, line: 51, baseType: !37, size: 16, offset: 32)
!207 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !203, file: !3, line: 52, baseType: !37, size: 16, offset: 48)
!208 = !{i32 7, !"Dwarf Version", i32 5}
!209 = !{i32 2, !"Debug Info Version", i32 3}
!210 = !{i32 1, !"wchar_size", i32 4}
!211 = !{i32 8, !"PIC Level", i32 2}
!212 = !{i32 7, !"PIE Level", i32 2}
!213 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!214 = !{!"Debian clang version 19.1.7 (3+b1)"}
!215 = distinct !DISubprogram(name: "xdp_l3_fwd", scope: !3, file: !3, line: 122, type: !216, scopeLine: 123, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !218)
!216 = !DISubroutineType(types: !217)
!217 = !{!40, !125}
!218 = !{!219, !220, !221, !222, !231, !259, !260, !261, !262, !263, !266, !267, !268, !270, !276}
!219 = !DILocalVariable(name: "ctx", arg: 1, scope: !215, file: !3, line: 122, type: !125)
!220 = !DILocalVariable(name: "data_end", scope: !215, file: !3, line: 124, type: !35)
!221 = !DILocalVariable(name: "data", scope: !215, file: !3, line: 125, type: !35)
!222 = !DILocalVariable(name: "eth", scope: !215, file: !3, line: 127, type: !223)
!223 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !224, size: 64)
!224 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ethhdr", file: !225, line: 173, size: 112, elements: !226)
!225 = !DIFile(filename: "/usr/include/linux/if_ether.h", directory: "", checksumkind: CSK_MD5, checksum: "163f54fb1af2e21fea410f14eb18fa76")
!226 = !{!227, !229, !230}
!227 = !DIDerivedType(tag: DW_TAG_member, name: "h_dest", scope: !224, file: !225, line: 174, baseType: !228, size: 48)
!228 = !DICompositeType(tag: DW_TAG_array_type, baseType: !54, size: 48, elements: !108)
!229 = !DIDerivedType(tag: DW_TAG_member, name: "h_source", scope: !224, file: !225, line: 175, baseType: !228, size: 48, offset: 48)
!230 = !DIDerivedType(tag: DW_TAG_member, name: "h_proto", scope: !224, file: !225, line: 176, baseType: !57, size: 16, offset: 96)
!231 = !DILocalVariable(name: "iph", scope: !215, file: !3, line: 139, type: !232)
!232 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !233, size: 64)
!233 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iphdr", file: !234, line: 87, size: 160, elements: !235)
!234 = !DIFile(filename: "/usr/include/linux/ip.h", directory: "", checksumkind: CSK_MD5, checksum: "149778ace30a1ff208adc8783fd04b29")
!235 = !{!236, !237, !238, !239, !240, !241, !242, !243, !244, !246}
!236 = !DIDerivedType(tag: DW_TAG_member, name: "ihl", scope: !233, file: !234, line: 89, baseType: !53, size: 4, flags: DIFlagBitField, extraData: i64 0)
!237 = !DIDerivedType(tag: DW_TAG_member, name: "version", scope: !233, file: !234, line: 90, baseType: !53, size: 4, offset: 4, flags: DIFlagBitField, extraData: i64 0)
!238 = !DIDerivedType(tag: DW_TAG_member, name: "tos", scope: !233, file: !234, line: 97, baseType: !53, size: 8, offset: 8)
!239 = !DIDerivedType(tag: DW_TAG_member, name: "tot_len", scope: !233, file: !234, line: 98, baseType: !57, size: 16, offset: 16)
!240 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !233, file: !234, line: 99, baseType: !57, size: 16, offset: 32)
!241 = !DIDerivedType(tag: DW_TAG_member, name: "frag_off", scope: !233, file: !234, line: 100, baseType: !57, size: 16, offset: 48)
!242 = !DIDerivedType(tag: DW_TAG_member, name: "ttl", scope: !233, file: !234, line: 101, baseType: !53, size: 8, offset: 64)
!243 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !233, file: !234, line: 102, baseType: !53, size: 8, offset: 72)
!244 = !DIDerivedType(tag: DW_TAG_member, name: "check", scope: !233, file: !234, line: 103, baseType: !245, size: 16, offset: 80)
!245 = !DIDerivedType(tag: DW_TAG_typedef, name: "__sum16", file: !58, line: 38, baseType: !37)
!246 = !DIDerivedType(tag: DW_TAG_member, scope: !233, file: !234, line: 104, baseType: !247, size: 64, offset: 96)
!247 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !233, file: !234, line: 104, size: 64, elements: !248)
!248 = !{!249, !254}
!249 = !DIDerivedType(tag: DW_TAG_member, scope: !247, file: !234, line: 104, baseType: !250, size: 64)
!250 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !247, file: !234, line: 104, size: 64, elements: !251)
!251 = !{!252, !253}
!252 = !DIDerivedType(tag: DW_TAG_member, name: "saddr", scope: !250, file: !234, line: 104, baseType: !72, size: 32)
!253 = !DIDerivedType(tag: DW_TAG_member, name: "daddr", scope: !250, file: !234, line: 104, baseType: !72, size: 32, offset: 32)
!254 = !DIDerivedType(tag: DW_TAG_member, name: "addrs", scope: !247, file: !234, line: 104, baseType: !255, size: 64)
!255 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !247, file: !234, line: 104, size: 64, elements: !256)
!256 = !{!257, !258}
!257 = !DIDerivedType(tag: DW_TAG_member, name: "saddr", scope: !255, file: !234, line: 104, baseType: !72, size: 32)
!258 = !DIDerivedType(tag: DW_TAG_member, name: "daddr", scope: !255, file: !234, line: 104, baseType: !72, size: 32, offset: 32)
!259 = !DILocalVariable(name: "fib", scope: !215, file: !3, line: 150, type: !50)
!260 = !DILocalVariable(name: "rc", scope: !215, file: !3, line: 159, type: !40)
!261 = !DILocalVariable(name: "egress_ifindex", scope: !215, file: !3, line: 168, type: !66)
!262 = !DILocalVariable(name: "vi", scope: !215, file: !3, line: 169, type: !202)
!263 = !DILocalVariable(name: "parent_ifindex", scope: !264, file: !3, line: 174, type: !66)
!264 = distinct !DILexicalBlock(scope: !265, file: !3, line: 173, column: 10)
!265 = distinct !DILexicalBlock(scope: !215, file: !3, line: 173, column: 6)
!266 = !DILocalVariable(name: "vlan_id", scope: !264, file: !3, line: 175, type: !37)
!267 = !DILocalVariable(name: "new_eth", scope: !264, file: !3, line: 187, type: !223)
!268 = !DILocalVariable(name: "i", scope: !269, file: !3, line: 194, type: !40)
!269 = distinct !DILexicalBlock(scope: !264, file: !3, line: 194, column: 3)
!270 = !DILocalVariable(name: "vh", scope: !264, file: !3, line: 200, type: !271)
!271 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !272, size: 64)
!272 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "vlanhdr", file: !3, line: 44, size: 32, elements: !273)
!273 = !{!274, !275}
!274 = !DIDerivedType(tag: DW_TAG_member, name: "h_vlan_TCI", scope: !272, file: !3, line: 45, baseType: !57, size: 16)
!275 = !DIDerivedType(tag: DW_TAG_member, name: "h_vlan_encapsulated_proto", scope: !272, file: !3, line: 46, baseType: !57, size: 16, offset: 16)
!276 = !DILocalVariable(name: "i", scope: !277, file: !3, line: 213, type: !40)
!277 = distinct !DILexicalBlock(scope: !215, file: !3, line: 213, column: 2)
!278 = distinct !DIAssignID()
!279 = distinct !DIAssignID()
!280 = distinct !DIAssignID()
!281 = distinct !DIAssignID()
!282 = distinct !DIAssignID()
!283 = distinct !DIAssignID()
!284 = distinct !DIAssignID()
!285 = distinct !DIAssignID()
!286 = distinct !DIAssignID()
!287 = distinct !DIAssignID()
!288 = distinct !DIAssignID()
!289 = distinct !DIAssignID()
!290 = distinct !DIAssignID()
!291 = distinct !DIAssignID()
!292 = !DILocation(line: 0, scope: !215)
!293 = distinct !DIAssignID()
!294 = !DILocation(line: 124, column: 38, scope: !215)
!295 = !{!296, !297, i64 4}
!296 = !{!"xdp_md", !297, i64 0, !297, i64 4, !297, i64 8, !297, i64 12, !297, i64 16, !297, i64 20}
!297 = !{!"int", !298, i64 0}
!298 = !{!"omnipotent char", !299, i64 0}
!299 = !{!"Simple C/C++ TBAA"}
!300 = !DILocation(line: 124, column: 27, scope: !215)
!301 = !DILocation(line: 124, column: 19, scope: !215)
!302 = !DILocation(line: 125, column: 38, scope: !215)
!303 = !{!296, !297, i64 0}
!304 = !DILocation(line: 125, column: 27, scope: !215)
!305 = !DILocation(line: 125, column: 19, scope: !215)
!306 = !DILocation(line: 128, column: 19, scope: !307)
!307 = distinct !DILexicalBlock(scope: !215, file: !3, line: 128, column: 6)
!308 = !DILocation(line: 128, column: 24, scope: !307)
!309 = !DILocation(line: 128, column: 6, scope: !215)
!310 = !DILocalVariable(name: "zero", scope: !311, file: !3, line: 105, type: !66)
!311 = distinct !DISubprogram(name: "stats_inc", scope: !3, file: !3, line: 103, type: !312, scopeLine: 104, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !314)
!312 = !DISubroutineType(types: !313)
!313 = !{null, !66}
!314 = !{!315, !310, !316}
!315 = !DILocalVariable(name: "field", arg: 1, scope: !311, file: !3, line: 103, type: !66)
!316 = !DILocalVariable(name: "s", scope: !311, file: !3, line: 106, type: !186)
!317 = !DILocation(line: 0, scope: !311, inlinedAt: !318)
!318 = distinct !DILocation(line: 129, column: 3, scope: !319)
!319 = distinct !DILexicalBlock(scope: !307, file: !3, line: 128, column: 36)
!320 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !318)
!321 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !318)
!322 = !{!297, !297, i64 0}
!323 = distinct !DIAssignID()
!324 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !318)
!325 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !318)
!326 = distinct !DILexicalBlock(scope: !311, file: !3, line: 108, column: 6)
!327 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !318)
!328 = !DILocation(line: 117, column: 35, scope: !329, inlinedAt: !318)
!329 = distinct !DILexicalBlock(scope: !311, file: !3, line: 110, column: 17)
!330 = !DILocation(line: 117, column: 10, scope: !329, inlinedAt: !318)
!331 = !DILocation(line: 117, column: 47, scope: !329, inlinedAt: !318)
!332 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !318)
!333 = !DILocation(line: 130, column: 3, scope: !319)
!334 = !DILocation(line: 0, scope: !311, inlinedAt: !335)
!335 = distinct !DILocation(line: 132, column: 2, scope: !215)
!336 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !335)
!337 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !335)
!338 = distinct !DIAssignID()
!339 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !335)
!340 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !335)
!341 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !335)
!342 = !DILocation(line: 111, column: 10, scope: !329, inlinedAt: !335)
!343 = !DILocation(line: 111, column: 58, scope: !329, inlinedAt: !335)
!344 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !335)
!345 = !DILocation(line: 134, column: 11, scope: !346)
!346 = distinct !DILexicalBlock(scope: !215, file: !3, line: 134, column: 6)
!347 = !{!348, !349, i64 12}
!348 = !{!"ethhdr", !298, i64 0, !298, i64 6, !349, i64 12}
!349 = !{!"short", !298, i64 0}
!350 = !DILocation(line: 134, column: 19, scope: !346)
!351 = !DILocation(line: 134, column: 6, scope: !215)
!352 = !DILocation(line: 0, scope: !311, inlinedAt: !353)
!353 = distinct !DILocation(line: 135, column: 3, scope: !354)
!354 = distinct !DILexicalBlock(scope: !346, file: !3, line: 134, column: 43)
!355 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !353)
!356 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !353)
!357 = distinct !DIAssignID()
!358 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !353)
!359 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !353)
!360 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !353)
!361 = !DILocation(line: 114, column: 35, scope: !329, inlinedAt: !353)
!362 = !DILocation(line: 114, column: 10, scope: !329, inlinedAt: !353)
!363 = !DILocation(line: 114, column: 55, scope: !329, inlinedAt: !353)
!364 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !353)
!365 = !DILocation(line: 136, column: 3, scope: !354)
!366 = !DILocation(line: 140, column: 19, scope: !367)
!367 = distinct !DILexicalBlock(scope: !215, file: !3, line: 140, column: 6)
!368 = !DILocation(line: 140, column: 24, scope: !367)
!369 = !DILocation(line: 140, column: 6, scope: !215)
!370 = !DILocation(line: 0, scope: !311, inlinedAt: !371)
!371 = distinct !DILocation(line: 141, column: 3, scope: !372)
!372 = distinct !DILexicalBlock(scope: !367, file: !3, line: 140, column: 36)
!373 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !371)
!374 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !371)
!375 = distinct !DIAssignID()
!376 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !371)
!377 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !371)
!378 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !371)
!379 = !DILocation(line: 117, column: 35, scope: !329, inlinedAt: !371)
!380 = !DILocation(line: 117, column: 10, scope: !329, inlinedAt: !371)
!381 = !DILocation(line: 117, column: 47, scope: !329, inlinedAt: !371)
!382 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !371)
!383 = !DILocation(line: 142, column: 3, scope: !372)
!384 = !DILocation(line: 145, column: 11, scope: !385)
!385 = distinct !DILexicalBlock(scope: !215, file: !3, line: 145, column: 6)
!386 = !{!387, !298, i64 8}
!387 = !{!"iphdr", !298, i64 0, !298, i64 0, !298, i64 1, !349, i64 2, !349, i64 4, !349, i64 6, !298, i64 8, !298, i64 9, !349, i64 10, !298, i64 12}
!388 = !DILocation(line: 145, column: 15, scope: !385)
!389 = !DILocation(line: 145, column: 6, scope: !215)
!390 = !DILocation(line: 0, scope: !311, inlinedAt: !391)
!391 = distinct !DILocation(line: 146, column: 3, scope: !392)
!392 = distinct !DILexicalBlock(scope: !385, file: !3, line: 145, column: 21)
!393 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !391)
!394 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !391)
!395 = distinct !DIAssignID()
!396 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !391)
!397 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !391)
!398 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !391)
!399 = !DILocation(line: 115, column: 35, scope: !329, inlinedAt: !391)
!400 = !DILocation(line: 115, column: 10, scope: !329, inlinedAt: !391)
!401 = !DILocation(line: 115, column: 56, scope: !329, inlinedAt: !391)
!402 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !391)
!403 = !DILocation(line: 147, column: 3, scope: !392)
!404 = !DILocation(line: 150, column: 2, scope: !215)
!405 = !DILocation(line: 150, column: 24, scope: !215)
!406 = distinct !DIAssignID()
!407 = !DILocation(line: 151, column: 18, scope: !215)
!408 = !{!409, !298, i64 0}
!409 = !{!"bpf_fib_lookup", !298, i64 0, !298, i64 1, !349, i64 2, !349, i64 4, !298, i64 6, !297, i64 8, !298, i64 12, !298, i64 16, !298, i64 32, !298, i64 48, !298, i64 52}
!410 = distinct !DIAssignID()
!411 = !DILocation(line: 152, column: 25, scope: !215)
!412 = !{!387, !298, i64 1}
!413 = !DILocation(line: 152, column: 6, scope: !215)
!414 = !DILocation(line: 152, column: 18, scope: !215)
!415 = !{!298, !298, i64 0}
!416 = distinct !DIAssignID()
!417 = !DILocation(line: 153, column: 25, scope: !215)
!418 = !{!387, !298, i64 9}
!419 = !DILocation(line: 153, column: 6, scope: !215)
!420 = !DILocation(line: 153, column: 18, scope: !215)
!421 = !{!409, !298, i64 1}
!422 = distinct !DIAssignID()
!423 = !DILocation(line: 154, column: 20, scope: !215)
!424 = !{!387, !349, i64 2}
!425 = !DILocation(line: 154, column: 6, scope: !215)
!426 = !DILocation(line: 154, column: 18, scope: !215)
!427 = distinct !DIAssignID()
!428 = !DILocation(line: 155, column: 25, scope: !215)
!429 = !DILocation(line: 155, column: 6, scope: !215)
!430 = !DILocation(line: 155, column: 18, scope: !215)
!431 = distinct !DIAssignID()
!432 = !DILocation(line: 156, column: 25, scope: !215)
!433 = !DILocation(line: 156, column: 6, scope: !215)
!434 = !DILocation(line: 156, column: 18, scope: !215)
!435 = distinct !DIAssignID()
!436 = !DILocation(line: 157, column: 25, scope: !215)
!437 = !{!296, !297, i64 12}
!438 = !DILocation(line: 157, column: 6, scope: !215)
!439 = !DILocation(line: 157, column: 18, scope: !215)
!440 = !{!409, !297, i64 8}
!441 = distinct !DIAssignID()
!442 = !DILocation(line: 159, column: 11, scope: !215)
!443 = !DILocation(line: 160, column: 9, scope: !444)
!444 = distinct !DILexicalBlock(scope: !215, file: !3, line: 160, column: 6)
!445 = !DILocation(line: 160, column: 6, scope: !215)
!446 = !DILocation(line: 0, scope: !311, inlinedAt: !447)
!447 = distinct !DILocation(line: 161, column: 3, scope: !448)
!448 = distinct !DILexicalBlock(scope: !444, file: !3, line: 160, column: 38)
!449 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !447)
!450 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !447)
!451 = distinct !DIAssignID()
!452 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !447)
!453 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !447)
!454 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !447)
!455 = !DILocation(line: 114, column: 35, scope: !329, inlinedAt: !447)
!456 = !DILocation(line: 114, column: 10, scope: !329, inlinedAt: !447)
!457 = !DILocation(line: 114, column: 55, scope: !329, inlinedAt: !447)
!458 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !447)
!459 = !DILocation(line: 162, column: 3, scope: !448)
!460 = !DILocation(line: 165, column: 7, scope: !215)
!461 = !DILocation(line: 165, column: 13, scope: !215)
!462 = !{!387, !349, i64 10}
!463 = !DILocation(line: 166, column: 10, scope: !215)
!464 = !DILocation(line: 168, column: 2, scope: !215)
!465 = !DILocation(line: 168, column: 29, scope: !215)
!466 = !DILocation(line: 168, column: 8, scope: !215)
!467 = distinct !DIAssignID()
!468 = !DILocation(line: 169, column: 25, scope: !215)
!469 = !DILocation(line: 173, column: 6, scope: !265)
!470 = !DILocation(line: 173, column: 6, scope: !215)
!471 = !DILocation(line: 0, scope: !277)
!472 = !DILocation(line: 214, column: 22, scope: !473)
!473 = distinct !DILexicalBlock(scope: !474, file: !3, line: 213, column: 37)
!474 = distinct !DILexicalBlock(scope: !277, file: !3, line: 213, column: 2)
!475 = !DILocation(line: 214, column: 20, scope: !473)
!476 = !DILocation(line: 215, column: 22, scope: !473)
!477 = !DILocation(line: 215, column: 20, scope: !473)
!478 = !DILocation(line: 214, column: 3, scope: !473)
!479 = !DILocation(line: 215, column: 3, scope: !473)
!480 = !DILocation(line: 218, column: 10, scope: !481)
!481 = distinct !DILexicalBlock(scope: !215, file: !3, line: 218, column: 6)
!482 = !DILocation(line: 218, column: 26, scope: !481)
!483 = !DILocation(line: 218, column: 18, scope: !481)
!484 = !DILocation(line: 218, column: 6, scope: !215)
!485 = !DILocation(line: 174, column: 30, scope: !264)
!486 = !{!487, !297, i64 0}
!487 = !{!"vlan_info", !297, i64 0, !349, i64 4, !349, i64 6}
!488 = !DILocation(line: 0, scope: !264)
!489 = !DILocation(line: 175, column: 30, scope: !264)
!490 = !{!487, !349, i64 4}
!491 = !DILocation(line: 0, scope: !311, inlinedAt: !492)
!492 = distinct !DILocation(line: 177, column: 3, scope: !264)
!493 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !492)
!494 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !492)
!495 = distinct !DIAssignID()
!496 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !492)
!497 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !492)
!498 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !492)
!499 = !DILocation(line: 116, column: 35, scope: !329, inlinedAt: !492)
!500 = !DILocation(line: 116, column: 10, scope: !329, inlinedAt: !492)
!501 = !DILocation(line: 116, column: 53, scope: !329, inlinedAt: !492)
!502 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !492)
!503 = !DILocation(line: 179, column: 7, scope: !504)
!504 = distinct !DILexicalBlock(scope: !264, file: !3, line: 179, column: 7)
!505 = !DILocation(line: 179, column: 7, scope: !264)
!506 = !DILocation(line: 0, scope: !311, inlinedAt: !507)
!507 = distinct !DILocation(line: 180, column: 4, scope: !508)
!508 = distinct !DILexicalBlock(scope: !504, file: !3, line: 179, column: 63)
!509 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !507)
!510 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !507)
!511 = distinct !DIAssignID()
!512 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !507)
!513 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !507)
!514 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !507)
!515 = !DILocation(line: 117, column: 35, scope: !329, inlinedAt: !507)
!516 = !DILocation(line: 117, column: 10, scope: !329, inlinedAt: !507)
!517 = !DILocation(line: 117, column: 47, scope: !329, inlinedAt: !507)
!518 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !507)
!519 = !DILocation(line: 181, column: 4, scope: !508)
!520 = !DILocation(line: 184, column: 33, scope: !264)
!521 = !DILocation(line: 184, column: 22, scope: !264)
!522 = !DILocation(line: 184, column: 14, scope: !264)
!523 = !DILocation(line: 185, column: 33, scope: !264)
!524 = !DILocation(line: 185, column: 22, scope: !264)
!525 = !DILocation(line: 185, column: 14, scope: !264)
!526 = !DILocation(line: 188, column: 29, scope: !527)
!527 = distinct !DILexicalBlock(scope: !264, file: !3, line: 188, column: 7)
!528 = !DILocation(line: 188, column: 54, scope: !527)
!529 = !DILocation(line: 188, column: 7, scope: !264)
!530 = !DILocation(line: 188, column: 24, scope: !527)
!531 = !DILocation(line: 0, scope: !269)
!532 = !DILocation(line: 195, column: 27, scope: !533)
!533 = distinct !DILexicalBlock(scope: !534, file: !3, line: 194, column: 38)
!534 = distinct !DILexicalBlock(scope: !269, file: !3, line: 194, column: 3)
!535 = !DILocation(line: 195, column: 25, scope: !533)
!536 = !DILocation(line: 196, column: 27, scope: !533)
!537 = !DILocation(line: 196, column: 25, scope: !533)
!538 = !DILocation(line: 195, column: 4, scope: !533)
!539 = !DILocation(line: 196, column: 4, scope: !533)
!540 = !DILocation(line: 198, column: 12, scope: !264)
!541 = !DILocation(line: 198, column: 20, scope: !264)
!542 = !DILocation(line: 201, column: 34, scope: !264)
!543 = !DILocation(line: 201, column: 32, scope: !264)
!544 = !{!545, !349, i64 0}
!545 = !{!"vlanhdr", !349, i64 0, !349, i64 2}
!546 = !DILocation(line: 202, column: 7, scope: !264)
!547 = !DILocation(line: 202, column: 33, scope: !264)
!548 = !{!545, !349, i64 2}
!549 = !DILocation(line: 204, column: 30, scope: !550)
!550 = distinct !DILexicalBlock(scope: !264, file: !3, line: 204, column: 7)
!551 = !DILocation(line: 204, column: 22, scope: !550)
!552 = !DILocation(line: 204, column: 7, scope: !264)
!553 = !DILocation(line: 0, scope: !311, inlinedAt: !554)
!554 = distinct !DILocation(line: 189, column: 4, scope: !555)
!555 = distinct !DILexicalBlock(scope: !527, file: !3, line: 188, column: 66)
!556 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !554)
!557 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !554)
!558 = distinct !DIAssignID()
!559 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !554)
!560 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !554)
!561 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !554)
!562 = !DILocation(line: 117, column: 35, scope: !329, inlinedAt: !554)
!563 = !DILocation(line: 117, column: 10, scope: !329, inlinedAt: !554)
!564 = !DILocation(line: 117, column: 47, scope: !329, inlinedAt: !554)
!565 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !554)
!566 = !DILocation(line: 190, column: 4, scope: !555)
!567 = !DILocation(line: 0, scope: !311, inlinedAt: !568)
!568 = distinct !DILocation(line: 205, column: 4, scope: !569)
!569 = distinct !DILexicalBlock(scope: !550, file: !3, line: 204, column: 47)
!570 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !568)
!571 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !568)
!572 = distinct !DIAssignID()
!573 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !568)
!574 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !568)
!575 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !568)
!576 = !DILocation(line: 112, column: 35, scope: !329, inlinedAt: !568)
!577 = !DILocation(line: 112, column: 10, scope: !329, inlinedAt: !568)
!578 = !DILocation(line: 112, column: 58, scope: !329, inlinedAt: !568)
!579 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !568)
!580 = !DILocation(line: 206, column: 4, scope: !569)
!581 = !DILocation(line: 0, scope: !311, inlinedAt: !582)
!582 = distinct !DILocation(line: 208, column: 3, scope: !264)
!583 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !582)
!584 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !582)
!585 = distinct !DIAssignID()
!586 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !582)
!587 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !582)
!588 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !582)
!589 = !DILocation(line: 113, column: 35, scope: !329, inlinedAt: !582)
!590 = !DILocation(line: 113, column: 10, scope: !329, inlinedAt: !582)
!591 = !DILocation(line: 113, column: 59, scope: !329, inlinedAt: !582)
!592 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !582)
!593 = !DILocation(line: 209, column: 37, scope: !264)
!594 = !DILocation(line: 209, column: 10, scope: !264)
!595 = !DILocation(line: 209, column: 3, scope: !264)
!596 = !DILocation(line: 0, scope: !311, inlinedAt: !597)
!597 = distinct !DILocation(line: 219, column: 3, scope: !598)
!598 = distinct !DILexicalBlock(scope: !481, file: !3, line: 218, column: 43)
!599 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !597)
!600 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !597)
!601 = distinct !DIAssignID()
!602 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !597)
!603 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !597)
!604 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !597)
!605 = !DILocation(line: 112, column: 35, scope: !329, inlinedAt: !597)
!606 = !DILocation(line: 112, column: 10, scope: !329, inlinedAt: !597)
!607 = !DILocation(line: 112, column: 58, scope: !329, inlinedAt: !597)
!608 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !597)
!609 = !DILocation(line: 220, column: 3, scope: !598)
!610 = !DILocation(line: 0, scope: !311, inlinedAt: !611)
!611 = distinct !DILocation(line: 222, column: 2, scope: !215)
!612 = !DILocation(line: 105, column: 2, scope: !311, inlinedAt: !611)
!613 = !DILocation(line: 105, column: 8, scope: !311, inlinedAt: !611)
!614 = distinct !DIAssignID()
!615 = !DILocation(line: 106, column: 22, scope: !311, inlinedAt: !611)
!616 = !DILocation(line: 108, column: 7, scope: !326, inlinedAt: !611)
!617 = !DILocation(line: 108, column: 6, scope: !311, inlinedAt: !611)
!618 = !DILocation(line: 113, column: 35, scope: !329, inlinedAt: !611)
!619 = !DILocation(line: 113, column: 10, scope: !329, inlinedAt: !611)
!620 = !DILocation(line: 113, column: 59, scope: !329, inlinedAt: !611)
!621 = !DILocation(line: 119, column: 1, scope: !311, inlinedAt: !611)
!622 = !DILocation(line: 223, column: 40, scope: !215)
!623 = !DILocation(line: 223, column: 36, scope: !215)
!624 = !DILocation(line: 223, column: 9, scope: !215)
!625 = !DILocation(line: 223, column: 2, scope: !215)
!626 = !DILocation(line: 224, column: 1, scope: !215)
