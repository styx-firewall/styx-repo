# ebpf_modules/xdp_l3fwd_devmap/xdp_l3fwd_devmap_companion.py
#
# Companion for xdp_l3fwd_devmap (ported from xdp-fwd's src/bpf/xdp-l3fwd-devmap.c,
# which is AGPL-3.0-or-later, Copyright (C) 2026 Alexandre Cassen). This file is
# ours, including the DEVMAP population that upstream does in its C loader
# (populate_devmap, which writes the ifindex from the -o flags).

import ctypes
import socket

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import aggregate_percpu

# Companion API


def _vlan_parts(item):
    """The three fields of a `vlan_map` entry, from either accepted item shape."""
    if not isinstance(item, dict):
        raise ValueError(f"a vlan_map entry must be an object, got {item!r}")

    value = item.get("value")
    if isinstance(value, dict):  # the key/value editor shape
        key = item.get("key")
        ifindex = key.get("ifindex") if isinstance(key, dict) else key
        return ifindex, value.get("parent_ifindex"), value.get("vlan_id")
    return item.get("ifindex"), item.get("parent_ifindex"), item.get("vlan_id")


def serialize_vlan(item):
    """`vlan_map` entry -> `(c_uint32 egress ifindex, VlanInfo)`.

    The key is the ifindex the FIB resolved for the egress (what the datapath looks up) and the value
    carries the port the tagged frame leaves through plus the tag. The parent is not checked here
    (that needs the map, not the entry): the usage says it, and a parent missing from `tx_port` is a
    dropped packet, not a rejected push.
    """
    ifindex, parent_ifindex, vlan_id = _vlan_parts(item)
    for name, idx in (("ifindex", ifindex), ("parent_ifindex", parent_ifindex)):
        if not isinstance(idx, int) or isinstance(idx, bool) or idx <= 0:
            raise ValueError(f"'{name}' must be a positive ifindex, got {idx!r}")
    if not isinstance(vlan_id, int) or isinstance(vlan_id, bool) or not 0 <= vlan_id <= 4095:
        raise ValueError(f"'vlan_id' must be a VLAN id (0-4095), got {vlan_id!r}")
    return (ctypes.c_uint32(ifindex), VlanInfo(parent_ifindex=parent_ifindex, vlan_id=vlan_id, pad=0))


def format_vlan(key, value):
    """`vlan_map` raw bytes -> `(egress ifindex, {"parent_ifindex": ..., "vlan_id": ...})`."""
    raw = bytes(value)
    info = VlanInfo.from_buffer_copy(raw)
    return int.from_bytes(bytes(key)[:4], "little"), {"parent_ifindex": info.parent_ifindex, "vlan_id": info.vlan_id}


def format_tx_port(key, value):
    """`tx_port` raw bytes -> `(egress ifindex, {"ifindex": ..., "name": ...})`.

    The map's value is the egress ifindex itself (4 bytes, what the BPF program declares and what
    upstream's loader writes). The name is a convenience for the UI and is absent when the index no
    longer belongs to an interface.
    """
    ifindex = BpfDevmapVal.from_buffer_copy(bytes(value)).ifindex
    entry = {"ifindex": ifindex}
    try:
        entry["name"] = socket.if_indextoname(ifindex)
    except OSError:
        entry["name"] = None
    return int.from_bytes(bytes(key)[:4], "little"), entry


_SERIALIZERS = {"vlan_map": serialize_vlan}
_FORMATTERS = {"vlan_map": format_vlan, "tx_port": format_tx_port}


def _key_only(item):
    """The map key of an item that only names one (a delete)."""
    if isinstance(item, int) and not isinstance(item, bool):
        return item
    if isinstance(item, dict):
        key = item.get("key", item.get("ifindex"))
        return key.get("ifindex") if isinstance(key, dict) else key
    return None


def serialize_entry(items, map_name, op):
    try:
        handler = _SERIALIZERS[map_name]
    except KeyError:
        raise ValueError(f"Map '{map_name}' does not support push")
    if op == "delete":
        # A delete only carries the key: the kernel does not look at a value when removing, so the
        # entry does not have to repeat the parent and the tag.
        out = []
        for item in items:
            ifindex = _key_only(item)
            if not isinstance(ifindex, int) or isinstance(ifindex, bool) or ifindex <= 0:
                raise ValueError(f"a delete needs the 'ifindex' key, got {item!r}")
            out.append((ctypes.c_uint32(ifindex), VlanInfo()))
        return out
    return [handler(item) for item in items]


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# C struct mirrors (keep in sync with xdp_l3fwd_devmap.c)


class BpfDevmapVal(ctypes.Structure):
    """`struct bpf_devmap_val`: what a DEVMAP_HASH entry takes (ifindex + an optional program).

    The kernel requires this shape (8 bytes) for the hash variant, and the program behind it is the
    one that would run on the destination CPU: this module leaves it at 0.
    """

    _fields_ = [
        ("ifindex", ctypes.c_uint32),
        ("bpf_prog_id", ctypes.c_int32),
    ]


class VlanInfo(ctypes.Structure):
    """`struct vlan_info { __u32 parent_ifindex; __u16 vlan_id; __u16 pad; }` -- 8 bytes."""

    _fields_ = [
        ("parent_ifindex", ctypes.c_uint32),
        ("vlan_id", ctypes.c_uint16),
        ("pad", ctypes.c_uint16),
    ]


class StatsT(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("packets_processed", ctypes.c_uint64),
        ("packets_forwarded", ctypes.c_uint64),
        ("packets_redirected", ctypes.c_uint64),
        ("packets_passed", ctypes.c_uint64),
        ("packets_dropped", ctypes.c_uint64),
        ("packets_vlan", ctypes.c_uint64),
        ("errors", ctypes.c_uint64),
    ]


# init hook: the DEVMAP the datapath steers through


def populate_init_maps(mod, descriptor):
    """Fill `tx_port` with the ifindexes of *egress_ifaces*.

    The DEVMAP is what `bpf_redirect_map` resolves the egress through, and a miss there is the
    redirect's fallback action, which this program sets to 0 (drop). So the set has to be complete
    **before** the first packet: the interfaces are resolved here, and a name that does not exist in
    this namespace raises `ValueError`, which rolls the load back (a module that loaded with a
    half-filled DEVMAP would drop traffic instead of forwarding it).

    What is not checked is whether an egress interface is up, or whether the FIB will actually pick
    it: that is the kernel's business at packet time.
    """
    raw = getattr(descriptor, "egress_ifaces", "") or ""
    names = [name.strip() for name in raw.split(",") if name.strip()]
    if not names:
        raise ValueError(
            "egress_ifaces is required: it is the list of interfaces the DEVMAP sends through, and "
            "without it every redirect is a drop"
        )

    resolved: list[int] = []
    missing: list[str] = []
    for name in names:
        try:
            idx = socket.if_nametoindex(name)
        except OSError:
            missing.append(name)
            continue
        if idx not in resolved:  # a repeated name is one entry
            resolved.append(idx)
    if missing:
        raise ValueError(
            f"egress_ifaces names interfaces that do not exist in this namespace: {missing}. "
            f"Fix the parameter (and the interface) before loading: a missing egress is a dropped "
            f"packet, not a passed one"
        )

    tx_port = mod.control_maps.get("tx_port")
    if tx_port is None:
        raise ValueError("tx_port map not available in this instance")

    for idx in resolved:
        tx_port[ctypes.c_uint32(idx)] = BpfDevmapVal(ifindex=idx, bpf_prog_id=0)


# Telemetry deserializer


@register_deserializer("xdp_l3fwd_devmap", "stats")
class StatsDeserializer(FeedbackDeserializer):
    """Aggregate the per-CPU counters into one dict."""

    _FIELDS = [
        "packets_processed",
        "packets_forwarded",
        "packets_redirected",
        "packets_passed",
        "packets_dropped",
        "packets_vlan",
        "errors",
    ]
    _FMTS = ["<Q"] * 7

    def from_map(self, raw, spec, key=None) -> dict:
        totals = aggregate_percpu(raw, self._FIELDS, self._FMTS)
        return {field: totals[field] for field in self._FIELDS}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")
