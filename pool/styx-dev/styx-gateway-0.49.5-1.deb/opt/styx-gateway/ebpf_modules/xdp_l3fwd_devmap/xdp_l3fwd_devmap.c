/* SPDX-License-Identifier: AGPL-3.0-or-later */
/*
 * Soft:        This XDP program performs IPv4 layer-3 forwarding. FDB (route_map)
 *              is populated by userspace loader with prefix entries derived from
 *              the kernel routing table ("ip route show"). Each entry stores the
 *              pre-resolved next-hop information so that no further lookups are
 *              needed at packet time. If the resolved egress ifindex equals the
 *              ingress ifindex the packet is sent back out the same interface with
 *              XDP_TX (hairpin). Otherwise bpf_redirect() is used to steer the
 *              packet to the egress interface.
 *
 * Authors:     Alexandre Cassen, <acassen@gmail.com>
 *
 *              This program is free software; you can redistribute it and/or
 *              modify it under the terms of the GNU Affero General Public
 *              License Version 3.0 as published by the Free Software Foundation;
 *              either version 3.0 of the License, or (at your option) any later
 *              version.
 *
 * Copyright (C) 2026 Alexandre Cassen, <acassen@gmail.com>
 *
 *              Modified by Styx (2026-10-02): added the per-CPU `stats` map and
 *              its increments in the datapath, so the module has telemetry like
 *              the rest of the tree. Forwarding behaviour is unchanged; the
 *              original copyright and license above are retained. Note that the
 *              "Soft:" paragraph above describes the route_map sibling
 *              (xdp-l3fwd.c): this file forwards off the live kernel FIB
 *              (bpf_fib_lookup) and steers with the tx_port DEVMAP.
 */

#define KBUILD_MODNAME "xdp_l3_fwd_devmap"

#include <linux/if_ether.h>
#include <linux/ip.h>
#include <linux/in.h>
#include <linux/if_packet.h>
#include <linux/if_vlan.h>
#include <linux/types.h>
#include <sys/socket.h>
#include <linux/bpf.h>
#include <bpf/bpf_endian.h>
#include <bpf/bpf_helpers.h>

struct vlanhdr {
	__be16 h_vlan_TCI;
	__be16 h_vlan_encapsulated_proto;
};

struct vlan_info {
	__u32 parent_ifindex;
	__u16 vlan_id;
	__u16 pad;
};


/* DEVMAP_HASH and not DEVMAP, and that is a fix, not a preference (measured): the plain DEVMAP is
 * an array indexed by the key, so its key has to be smaller than max_entries, and this map is keyed
 * by ifindex. With `BPF_MAP_TYPE_DEVMAP` and max_entries 64 every interface whose ifindex is 64 or
 * above is unaddressable: writing its entry fails (E2BIG, silently swallowed by the loader) and the
 * redirect's fallback action of 0 turns that into dropped traffic. ifindexes grow as interfaces are
 * created and removed, so a box reaches that on its own. The hash variant takes any u32 key. */
struct {
	__uint(type, BPF_MAP_TYPE_DEVMAP_HASH);
	__uint(max_entries, 256);
	__type(key, __u32);
	/* The value a DEVMAP_HASH takes is `struct bpf_devmap_val` (from linux/bpf.h, which this file
	 * includes): the kernel requires that shape for the hash variant, unlike the array DEVMAP
	 * which accepts a bare __u32. Its `bpf_prog` is the optional program to run on the
	 * destination CPU, and this module leaves it at 0. */
	__type(value, struct bpf_devmap_val);
} tx_port SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_HASH);
	__uint(max_entries, 256);
	__type(key, __u32);
	__type(value, struct vlan_info);
} vlan_map SEC(".maps");

/* Telemetry (added by Styx): what the program did with the packets it saw.
 *
 * `processed` counts every packet past the Ethernet bounds check, so a packet that
 * ends up in `errors` was counted there first. `redirected` counts the steering
 * attempt, and a miss in tx_port is a DROP (the redirect's fallback action is 0):
 * the counter does not tell the two apart, the map does. */
struct stats_t {
	__u64 packets_processed;
	__u64 packets_forwarded;
	__u64 packets_redirected;
	__u64 packets_passed;
	__u64 packets_dropped;
	__u64 packets_vlan;
	__u64 errors;
};

struct {
	__uint(type, BPF_MAP_TYPE_PERCPU_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, struct stats_t);
} stats SEC(".maps");

static __always_inline void stats_inc(__u32 field)
{
	__u32 zero = 0;
	struct stats_t *s = bpf_map_lookup_elem(&stats, &zero);

	if (!s)
		return;
	switch (field) {
	case 0: __sync_fetch_and_add(&s->packets_processed, 1); break;
	case 1: __sync_fetch_and_add(&s->packets_forwarded, 1); break;
	case 2: __sync_fetch_and_add(&s->packets_redirected, 1); break;
	case 3: __sync_fetch_and_add(&s->packets_passed, 1); break;
	case 4: __sync_fetch_and_add(&s->packets_dropped, 1); break;
	case 5: __sync_fetch_and_add(&s->packets_vlan, 1); break;
	case 6: __sync_fetch_and_add(&s->errors, 1); break;
	}
}

SEC("xdp")
int xdp_l3_fwd(struct xdp_md *ctx)
{
	void *data_end = (void *)(long)ctx->data_end;
	void *data     = (void *)(long)ctx->data;

	struct ethhdr *eth = data;
	if ((void *)(eth + 1) > data_end) {
		stats_inc(6);
		return XDP_ABORTED;
	}
	stats_inc(0);

	if (eth->h_proto != bpf_htons(ETH_P_IP)) {
		stats_inc(3);
		return XDP_PASS;
	}

	struct iphdr *iph = (void *)(eth + 1);
	if ((void *)(iph + 1) > data_end) {
		stats_inc(6);
		return XDP_ABORTED;
	}

	if (iph->ttl <= 1) {
		stats_inc(4);
		return XDP_DROP;
	}

	struct bpf_fib_lookup fib = {};
	fib.family      = AF_INET;
	fib.tos         = iph->tos;
	fib.l4_protocol = iph->protocol;
	fib.tot_len     = bpf_ntohs(iph->tot_len);
	fib.ipv4_src    = iph->saddr;
	fib.ipv4_dst    = iph->daddr;
	fib.ifindex     = ctx->ingress_ifindex;

	int rc = bpf_fib_lookup(ctx, &fib, sizeof(fib), BPF_FIB_LOOKUP_DIRECT);
	if (rc != BPF_FIB_LKUP_RET_SUCCESS) {
		stats_inc(3);
		return XDP_PASS;
	}

	iph->check += bpf_htons(0x0100);
	iph->ttl--;

	__u32 egress_ifindex = fib.ifindex;
	struct vlan_info *vi = bpf_map_lookup_elem(&vlan_map, &egress_ifindex);
//	bpf_printk("egress: ifindex=%u vlan_present=%d vlan_id=%u",
//		   egress_ifindex, vi != NULL, vi ? vi->vlan_id : 0);

	if (vi) {
		__u32 parent_ifindex = vi->parent_ifindex;
		__u16 vlan_id        = vi->vlan_id;

		stats_inc(5);

		if (bpf_xdp_adjust_head(ctx, -(int)sizeof(struct vlanhdr))) {
			stats_inc(6);
			return XDP_ABORTED;
		}

		data     = (void *)(long)ctx->data;
		data_end = (void *)(long)ctx->data_end;

		struct ethhdr *new_eth = data;
		if ((void *)(new_eth + 1) + sizeof(struct vlanhdr) > data_end) {
			stats_inc(6);
			return XDP_ABORTED;
		}

#pragma unroll
		for (int i = 0; i < ETH_ALEN; i++) {
			new_eth->h_dest[i]   = fib.dmac[i];
			new_eth->h_source[i] = fib.smac[i];
		}
		new_eth->h_proto = bpf_htons(ETH_P_8021Q);

		struct vlanhdr *vh = (void *)(new_eth + 1);
		vh->h_vlan_TCI               = bpf_htons(vlan_id);
		vh->h_vlan_encapsulated_proto = bpf_htons(ETH_P_IP);

		if (parent_ifindex == ctx->ingress_ifindex) {
			stats_inc(1);
			return XDP_TX;
		}
		stats_inc(2);
		return bpf_redirect_map(&tx_port, parent_ifindex, 0);
	}

#pragma unroll
	for (int i = 0; i < ETH_ALEN; i++) {
		eth->h_dest[i]   = fib.dmac[i];
		eth->h_source[i] = fib.smac[i];
	}

	if (fib.ifindex == ctx->ingress_ifindex) {
		stats_inc(1);
		return XDP_TX;
	}
	stats_inc(2);
	return bpf_redirect_map(&tx_port, fib.ifindex, 0);
}

char _license[] SEC("license") = "GPL";
