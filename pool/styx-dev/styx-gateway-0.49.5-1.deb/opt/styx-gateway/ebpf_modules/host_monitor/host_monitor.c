// SPDX-License-Identifier: GPL-2.0
// host_monitor.c - per-host IPv4 accounting on the TC egress hook
//
// Counts what leaves the interface, per source host, and never decides over the
// traffic: every path returns TC_ACT_UNSPEC, which in tcx is TCX_NEXT, so the rest
// of the chain runs as if this module were not there. What it is for is visibility
// (which host is talking, how much, since when) and, being the only tc_* module
// that observes instead of filtering, to have something that fills itself with the
// traffic that is already flowing.

// 1. CO-RE headers
// The BccBackend passes -DBCC_COMPILE and BCC provides its own helpers with
// different signatures, so the block is guarded.
#ifndef BCC_COMPILE
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_endian.h>

// vmlinux.h carries BTF types only, not macros - define TC constants manually.
// UNSPEC is "this module has no verdict": the same number as TCX_NEXT (-1), and the
// hook keeps running the chain behind it. An observing module must never return OK:
// it would cut that chain in silence without filtering anything, and, in ingress,
// would skip the classic chain tc_service writes to.
#ifndef TC_ACT_UNSPEC
#define TC_ACT_UNSPEC (-1)
#endif
#ifndef ETH_P_IP
#define ETH_P_IP 0x0800
#endif
#endif  // BCC_COMPILE

// 2. Data structs
// Struct and field names must match module.toml and the companion: the companion
// mirrors the structs by hand, and the app reads the toml names.

// Value of the stats map (toml: value_type = "struct stats_t")
struct stats_t {
    __u64 packets;     // every frame seen, ARP included
    __u64 bytes;
    __u64 ipv4;        // of those, how many were IPv4. This is the counter to read
    __u64 tcp;         //   behind a filter: a counter of everything cannot tell
    __u64 udp;         //   "the module in front let it through" from "the ARP kept
    __u64 icmp;        //   arriving"
    __u64 other;
    __u64 ring_drops;  // events lost to a full ring (reserve returned NULL)
};  // not packed: all fields are __u64, so there is no padding to hide

// Value of the hosts table (toml: value_schema = "struct host_stats").
// One entry per source address seen on this hook.
struct host_stats {
    __u64 packets;
    __u64 bytes;
    __u64 first_seen_ns;
    __u64 last_seen_ns;
};  // not packed: all fields are __u64

// Event emitted to the ring buffer (toml: buffer_type = "ring_buffer")
struct event_t {
    __u64 ts_ns;    // bpf_type="u64" unit="ns"
    __u32 src_ip;   // bpf_type="u32" unit="ipv4"
    __u32 dst_ip;   // bpf_type="u32" unit="ipv4"
    __u16 dport;    // bpf_type="u16" unit="port"
    __u8  proto;    // bpf_type="u8"
    __u8  reason;   // bpf_type="u8" 0 = a source was seen for the first time
} __attribute__((packed));  // 1 = the periodic sample asked for by cfg key 1

// Which protocol bucket a frame lands in, for the split counters.
#define BUCKET_NONE (-1)  // not IPv4: counted, not split
#define BUCKET_OTHER 0
#define BUCKET_TCP 1
#define BUCKET_UDP 2
#define BUCKET_ICMP 3

// The cfg keys, and the value that means "as declared here" for each:
// ARRAY maps are zero-filled, so 0 is what an operator who never pushed anything
// leaves in the map, and the datapath has to read something sensible out of it.
#define CFG_SILENT_NEW_HOSTS 0  // 0 = emit an event per new source, 1 = quiet
#define CFG_SAMPLE_EVERY 1      // 0 = no periodic events, N = one every N frames

// 3. Map definitions
// The C variable name is the name in module.toml: libbpf identifies maps by name.

// control_map: name="hosts" direction="output" editor="table"
// LRU and not a plain hash: the table is bounded by max_entries and evicts the
// least recently seen source instead of failing the insert when it is full.
struct {
    __uint(type,        BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, 4096);
    __type(key,         __u32);              // source IPv4 address
    __type(value,       struct host_stats);
} hosts SEC(".maps");

// control_map: name="cfg" direction="input" editor="keyvalue"
struct {
    __uint(type,        BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 4);
    __type(key,         __u32);
    __type(value,       __u32);
} cfg SEC(".maps");

// telemetry_map: name="stats" value_type="struct stats_t"
// PERCPU: each CPU keeps its own counters, so the datapath needs no lock and the
// app sums the slices.
struct {
    __uint(type,        BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key,         __u32);
    __type(value,       struct stats_t);
} stats SEC(".maps");

// event: name="mon_events" buffer_type="ring_buffer"
struct {
    __uint(type,        BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);
} mon_events SEC(".maps");

// 4. Internal helpers

static __always_inline __u32 cfg_get(__u32 key) {
    __u32 *val = bpf_map_lookup_elem(&cfg, &key);
    return val ? *val : 0;
}

// Counts an event lost because the ring is full (per-CPU: no atomic).
// libbpf does not report ringbuf losses to userspace, so this counter is the only
// record that they happened; it is exposed through the "stats" telemetry map.
static __always_inline void count_ring_drop(void) {
    __u32 idx = 0;
    struct stats_t *s = bpf_map_lookup_elem(&stats, &idx);
    if (s)
        s->ring_drops++;
}

static __always_inline void emit_event(__u32 src, __u32 dst, __u16 dport,
                                        __u8 proto, __u8 reason) {
    struct event_t *e = bpf_ringbuf_reserve(&mon_events, sizeof(struct event_t), 0);
    if (!e) {   // ring full: the event is lost and counted, never the packet
        count_ring_drop();
        return;
    }

    e->ts_ns  = bpf_ktime_get_ns();
    e->src_ip = src;
    e->dst_ip = dst;
    e->dport  = dport;
    e->proto  = proto;
    e->reason = reason;

    bpf_ringbuf_submit(e, 0);
}

// Every frame is counted; only the IPv4 ones are split by protocol.
// bucket is BUCKET_NONE for anything that is not IPv4.
static __always_inline void count_frame(__u64 bytes, int bucket) {
    __u32 idx = 0;
    struct stats_t *s = bpf_map_lookup_elem(&stats, &idx);
    if (!s)
        return;

    __sync_fetch_and_add(&s->packets, 1);
    __sync_fetch_and_add(&s->bytes, bytes);

    if (bucket == BUCKET_NONE)
        return;

    __sync_fetch_and_add(&s->ipv4, 1);
    if (bucket == BUCKET_TCP)
        __sync_fetch_and_add(&s->tcp, 1);
    else if (bucket == BUCKET_UDP)
        __sync_fetch_and_add(&s->udp, 1);
    else if (bucket == BUCKET_ICMP)
        __sync_fetch_and_add(&s->icmp, 1);
    else
        __sync_fetch_and_add(&s->other, 1);
}

// One row of the hosts table. The first frame of a source is what the "new source"
// event is about, so the event is emitted only by the update that actually created
// the entry: with two CPUs racing on the same new source, one wins BPF_NOEXIST and
// only that one announces it.
static __always_inline void account_host(__u32 src_ip, __u64 bytes) {
    __u64 now = bpf_ktime_get_ns();

    struct host_stats *h = bpf_map_lookup_elem(&hosts, &src_ip);
    if (h) {
        __sync_fetch_and_add(&h->packets, 1);
        __sync_fetch_and_add(&h->bytes, bytes);
        h->last_seen_ns = now;
        return;
    }

    struct host_stats fresh = {
        .packets = 1,
        .bytes = bytes,
        .first_seen_ns = now,
        .last_seen_ns = now,
    };
    if (bpf_map_update_elem(&hosts, &src_ip, &fresh, BPF_NOEXIST) == 0) {
        if (cfg_get(CFG_SILENT_NEW_HOSTS) == 0)
            emit_event(src_ip, 0, 0, 0, 0);
    }
}

// The periodic sample, for watching the events path on an interface whose sources
// are all known already. 0 turns it off.
static __always_inline void maybe_sample(__u32 src, __u32 dst, __u16 dport, __u8 proto) {
    __u32 every = cfg_get(CFG_SAMPLE_EVERY);
    if (every == 0)
        return;

    __u32 idx = 0;
    struct stats_t *s = bpf_map_lookup_elem(&stats, &idx);
    if (s && (s->packets % every) == 0)
        emit_event(src, dst, dport, proto, 1);
}

// 5. Main program
// SEC("tcx/egress") -> hook_type = "tc_egress" in module.toml. The section declares
// the attach mechanism and the direction: the tcx attach reads them from the
// program's expected_attach_type at load time, and a program built with a bare "tc"
// section loads with attach type 0 and cannot be attached as tcx at all.

SEC("tcx/egress")
int host_monitor(struct __sk_buff *skb) {
    void *data     = (void *)(long)skb->data;
    void *data_end = (void *)(long)skb->data_end;
    __u64 pkt_bytes = skb->len;

    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end) {
        count_frame(pkt_bytes, BUCKET_NONE);
        return TC_ACT_UNSPEC;
    }

    if (eth->h_proto != bpf_htons(ETH_P_IP)) {
        count_frame(pkt_bytes, BUCKET_NONE);
        return TC_ACT_UNSPEC;
    }

    struct iphdr *ip = (void *)(eth + 1);
    if ((void *)(ip + 1) > data_end) {
        count_frame(pkt_bytes, BUCKET_NONE);
        return TC_ACT_UNSPEC;
    }

    __u32 src_ip = ip->saddr;
    __u32 dst_ip = ip->daddr;
    __u8  proto  = ip->protocol;
    __u16 dport  = 0;

    int bucket = BUCKET_OTHER;
    if (proto == IPPROTO_TCP)
        bucket = BUCKET_TCP;
    else if (proto == IPPROTO_UDP)
        bucket = BUCKET_UDP;
    else if (proto == IPPROTO_ICMP)
        bucket = BUCKET_ICMP;

    if (proto == IPPROTO_TCP || proto == IPPROTO_UDP) {
        void *transport = (void *)ip + (ip->ihl * 4);
        if (transport + 4 <= data_end)
            dport = bpf_ntohs(*(__u16 *)(transport + 2));
    }

    count_frame(pkt_bytes, bucket);
    account_host(src_ip, pkt_bytes);
    maybe_sample(src_ip, dst_ip, dport, proto);

    return TC_ACT_UNSPEC;
}

char _license[] SEC("license") = "GPL";
