# host_monitor/host_monitor_companion.py
#
# Companion for host_monitor: the deserializers for its stats telemetry map and its
# event ring, and the formatters for the two control maps (the cfg it reads and the
# hosts table the datapath fills).

import ctypes
import struct

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import (
    aggregate_percpu,
    format_uint32,
    ktime_to_epoch,
    serialize_uint32,
    u32_to_ip,
    unpack_struct,
)

# Companion API


_SERIALIZERS = {"cfg": serialize_uint32}


def serialize_entry(items, map_name, op):
    try:
        handler = _SERIALIZERS[map_name]
    except KeyError:
        raise ValueError(f"Map '{map_name}' does not support push")
    return [handler(item) for item in items]


# The hosts table (output): one row per source address seen on the hook.


# Mirrors struct host_stats in host_monitor.c
_HOST_STATS_FIELDS = ["packets", "bytes", "first_seen_ns", "last_seen_ns"]


def _format_host(key, value):
    """A row of the hosts table: the source address and what it sent."""
    # The key is the address as it sits in the packet, which is what u32_to_ip undoes.
    # hosts is a shared LRU_HASH and not a PERCPU map, so the value is a single slice:
    # aggregating it across CPUs would only hide that.
    key_repr = {"ip": u32_to_ip(key)}
    val_repr = None
    if value:
        val_repr = unpack_struct(value, _HOST_STATS_FIELDS, ["<Q", "Q", "Q", "Q"])
        val_repr["first_seen"] = ktime_to_epoch(val_repr.pop("first_seen_ns", 0))
        val_repr["last_seen"] = ktime_to_epoch(val_repr.pop("last_seen_ns", 0))
    return key_repr, val_repr


_FORMATTERS = {"cfg": format_uint32, "hosts": _format_host}


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# Telemetry / Event deserializers


# Mirrors struct stats_t in host_monitor.c. Field order and types are the contract
# with the .c: a drift here does not raise, it yields garbage numbers.
class StatsT(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("packets", ctypes.c_uint64),
        ("bytes", ctypes.c_uint64),
        ("ipv4", ctypes.c_uint64),
        ("tcp", ctypes.c_uint64),
        ("udp", ctypes.c_uint64),
        ("icmp", ctypes.c_uint64),
        ("other", ctypes.c_uint64),
        ("ring_drops", ctypes.c_uint64),
    ]


_STATS_FIELDS = ["packets", "bytes", "ipv4", "tcp", "udp", "icmp", "other", "ring_drops"]


@register_deserializer("host_monitor", "stats")
class StatsDeserializer(FeedbackDeserializer):
    """Sums the per-CPU slices: what the hook saw, split by protocol."""

    def from_map(self, raw, spec, key=None) -> dict:
        return aggregate_percpu(raw, _STATS_FIELDS, ["<Q"] * len(_STATS_FIELDS))

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")


# Mirrors struct event_t in host_monitor.c (packed: 8 + 4 + 4 + 2 + 1 + 1)
_EVENT_FORMAT = "<QIIHBB"


@register_deserializer("host_monitor", "mon_events")
class MonitorEventDeserializer(FeedbackDeserializer):
    """A source seen for the first time, or a sample the cfg asked for."""

    def from_map(self, raw, spec, key=None) -> dict:
        raise NotImplementedError("mon_events is an event buffer, not a telemetry map")

    def from_event(self, data: bytes, size: int, spec) -> dict:
        ts_ns, src_ip, dst_ip, dport, proto, reason = struct.unpack(_EVENT_FORMAT, data[:20])
        src = u32_to_ip(src_ip)
        dst = u32_to_ip(dst_ip)
        what = "new host" if reason == 0 else "sample"
        return {
            "ts_ns": ts_ns,
            "src_ip": src,
            "dst_ip": dst,
            "dport": dport,
            "proto": proto,
            "reason": what,
            "summary": f"{what} on egress: {src} -> {dst} (proto {proto})",
        }
