# ebpf_modules/xdp_l2fwd/xdp_l2fwd_companion.py
#
# Companion for xdp_l2fwd (ported from xdp-fwd's src/bpf/xdp-l2fwd.c, which is
# AGPL-3.0-or-later, Copyright (C) 2026 Alexandre Cassen). This file is ours.

import ctypes

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import aggregate_percpu, bytes_to_mac, mac_to_bytes

# Companion API

_SERIALIZERS = {"l2_map": None}  # filled in below, once the value struct exists
_FORMATTERS = {"l2_map": None}


def _l2_parts(item):
    """The three fields of one `l2_map` entry, from either accepted item shape.

    `{"vlan_id": 100, "dest_mac": "02:..", "new_vlan_id": 200}` is what the usage documents. The
    `{"key": ..., "value": {...}}` shape is accepted too, because that is how the key/value editor
    of the UI sends every map, and a module that only took one of the two would refuse the other
    with a message about the map not supporting push.
    """
    if not isinstance(item, dict):
        raise ValueError(f"an l2_map entry must be an object with vlan_id/dest_mac/new_vlan_id, got {item!r}")

    value = item.get("value")
    if isinstance(value, dict):  # the key/value editor shape
        key = item.get("key")
        vlan_id = key.get("vlan_id") if isinstance(key, dict) else key
        return vlan_id, value.get("dest_mac"), value.get("new_vlan_id")
    return item.get("vlan_id"), item.get("dest_mac"), item.get("new_vlan_id")


def serialize_l2(item):
    """`l2_map` entry -> `(c_uint16 ingress vlan, L2Info)`.

    The key is the **ingress** VLAN (what the datapath looks up) and the value carries the
    destination MAC plus the VLAN written into the frame on the way out. Both ids are 12 bits in
    802.1Q, so anything above 4095 is refused here rather than truncated in the TCI.
    """
    vlan_id, dest_mac, new_vlan_id = _l2_parts(item)
    if vlan_id is None or new_vlan_id is None:
        raise ValueError("an l2_map entry needs 'vlan_id' (the ingress one) and 'new_vlan_id'")
    for name, vid in (("vlan_id", vlan_id), ("new_vlan_id", new_vlan_id)):
        if not isinstance(vid, int) or isinstance(vid, bool) or not 0 <= vid <= 4095:
            raise ValueError(f"'{name}' must be a VLAN id (0-4095), got {vid!r}")
    mac = mac_to_bytes(dest_mac)  # raises ValueError on a malformed address
    return (ctypes.c_uint16(vlan_id), L2Info(h_dest=(ctypes.c_uint8 * 6)(*mac), vlan_id=new_vlan_id))


def format_l2(key, value):
    """`l2_map` raw bytes -> `(ingress vlan, {"dest_mac": ..., "new_vlan_id": ...})`.

    Without this the API would show the entry as hex, and the MAC and the egress VLAN are exactly
    what an operator wants to read back after a push.
    """
    ingress = int.from_bytes(bytes(key)[:2], "little")
    raw = bytes(value)
    return ingress, {"dest_mac": bytes_to_mac(raw[:6]), "new_vlan_id": int.from_bytes(raw[6:8], "little")}


_SERIALIZERS["l2_map"] = serialize_l2
_FORMATTERS["l2_map"] = format_l2


def _key_only(item):
    """The map key of an item that only names one (a delete)."""
    if isinstance(item, int) and not isinstance(item, bool):
        return item
    if isinstance(item, dict):
        key = item.get("key", item.get("vlan_id"))
        return key.get("vlan_id") if isinstance(key, dict) else key
    return None


def serialize_entry(items, map_name, op):
    try:
        handler = _SERIALIZERS[map_name]
    except KeyError:
        raise ValueError(f"Map '{map_name}' does not support push")
    if op == "delete":
        # A delete only carries the key: the kernel does not look at a value when removing, so the
        # entry does not have to repeat the MAC and the egress VLAN.
        out = []
        for item in items:
            vlan_id = _key_only(item)
            if not isinstance(vlan_id, int) or isinstance(vlan_id, bool) or not 0 <= vlan_id <= 4095:
                raise ValueError(f"a delete needs the 'vlan_id' key, got {item!r}")
            out.append((ctypes.c_uint16(vlan_id), L2Info()))
        return out
    return [handler(item) for item in items]


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# C struct mirrors (keep in sync with xdp_l2fwd.c)


class L2Info(ctypes.Structure):
    """`struct l2_info { __u8 h_dest[6]; __u16 vlan_id; }` -- 8 bytes, no padding."""

    _fields_ = [
        ("h_dest", ctypes.c_uint8 * 6),
        ("vlan_id", ctypes.c_uint16),
    ]


class StatsT(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("packets_processed", ctypes.c_uint64),
        ("packets_passed", ctypes.c_uint64),
        ("packets_hairpin_miss", ctypes.c_uint64),
        ("packets_translated", ctypes.c_uint64),
        ("errors", ctypes.c_uint64),
    ]


# Telemetry deserializer


@register_deserializer("xdp_l2fwd", "stats")
class StatsDeserializer(FeedbackDeserializer):
    """Aggregate the per-CPU counters into one dict."""

    _FIELDS = ["packets_processed", "packets_passed", "packets_hairpin_miss", "packets_translated", "errors"]
    _FMTS = ["<Q"] * 5

    def from_map(self, raw, spec, key=None) -> dict:
        totals = aggregate_percpu(raw, self._FIELDS, self._FMTS)
        return {field: totals[field] for field in self._FIELDS}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")
