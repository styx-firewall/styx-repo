; ModuleID = 'xdp_l2fwd.c'
source_filename = "xdp_l2fwd.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.anon = type { ptr, ptr, ptr, ptr }
%struct.anon.0 = type { ptr, ptr, ptr, ptr }
%struct.anon.1 = type { ptr, ptr }

@l2_map = dso_local global %struct.anon zeroinitializer, section ".maps", align 8, !dbg !0
@_license = dso_local global [4 x i8] c"GPL\00", section "license", align 1, !dbg !37
@stats = dso_local global %struct.anon.0 zeroinitializer, section ".maps", align 8, !dbg !43
@_xdp_l2_fwd = dso_local global %struct.anon.1 zeroinitializer, section ".xdp_run_config", align 8, !dbg !72
@llvm.compiler.used = appending global [5 x ptr] [ptr @_license, ptr @_xdp_l2_fwd, ptr @l2_map, ptr @stats, ptr @xdp_l2_fwd], section "llvm.metadata"

; Function Attrs: nounwind
define dso_local range(i32 0, 4) i32 @xdp_l2_fwd(ptr nocapture noundef readonly %0) #0 section "xdp" !dbg !108 {
  %2 = alloca i32, align 4, !DIAssignID !138
  %3 = alloca i32, align 4, !DIAssignID !139
  %4 = alloca i32, align 4, !DIAssignID !140
  %5 = alloca i32, align 4, !DIAssignID !141
  %6 = alloca i32, align 4, !DIAssignID !142
  %7 = alloca i32, align 4, !DIAssignID !143
  %8 = alloca i32, align 4, !DIAssignID !144
  %9 = alloca i16, align 2, !DIAssignID !145
    #dbg_assign(i1 undef, !135, !DIExpression(), !145, ptr %9, !DIExpression(), !146)
    #dbg_value(ptr %0, !121, !DIExpression(), !146)
  %10 = getelementptr inbounds i8, ptr %0, i64 4, !dbg !147
  %11 = load i32, ptr %10, align 4, !dbg !147, !tbaa !148
  %12 = zext i32 %11 to i64, !dbg !153
  %13 = inttoptr i64 %12 to ptr, !dbg !154
    #dbg_value(ptr %13, !122, !DIExpression(), !146)
  %14 = load i32, ptr %0, align 4, !dbg !155, !tbaa !156
  %15 = zext i32 %14 to i64, !dbg !157
  %16 = inttoptr i64 %15 to ptr, !dbg !158
    #dbg_value(ptr %16, !123, !DIExpression(), !146)
    #dbg_value(ptr %16, !124, !DIExpression(), !146)
  call void @llvm.lifetime.start.p0(i64 2, ptr nonnull %9) #3, !dbg !159
  %17 = getelementptr inbounds i8, ptr %16, i64 14, !dbg !160
  %18 = icmp ugt ptr %17, %13, !dbg !162
  br i1 %18, label %19, label %26, !dbg !163

19:                                               ; preds = %1
    #dbg_assign(i1 undef, !164, !DIExpression(), !138, ptr %2, !DIExpression(), !171)
    #dbg_value(i32 4, !169, !DIExpression(), !171)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #3, !dbg !174
  store i32 0, ptr %2, align 4, !dbg !175, !tbaa !176, !DIAssignID !177
    #dbg_assign(i32 0, !164, !DIExpression(), !177, ptr %2, !DIExpression(), !171)
  %20 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %2) #3, !dbg !178
    #dbg_value(ptr %20, !170, !DIExpression(), !171)
  %21 = icmp eq ptr %20, null, !dbg !179
  br i1 %21, label %25, label %22, !dbg !181

22:                                               ; preds = %19
  %23 = getelementptr inbounds i8, ptr %20, i64 32, !dbg !182
  %24 = atomicrmw add ptr %23, i64 1 seq_cst, align 8, !dbg !184
  br label %25, !dbg !185

25:                                               ; preds = %19, %22
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #3, !dbg !186
  br label %113, !dbg !187

26:                                               ; preds = %1
    #dbg_assign(i1 undef, !164, !DIExpression(), !139, ptr %3, !DIExpression(), !188)
    #dbg_value(i32 0, !169, !DIExpression(), !188)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %3) #3, !dbg !190
  store i32 0, ptr %3, align 4, !dbg !191, !tbaa !176, !DIAssignID !192
    #dbg_assign(i32 0, !164, !DIExpression(), !192, ptr %3, !DIExpression(), !188)
  %27 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %3) #3, !dbg !193
    #dbg_value(ptr %27, !170, !DIExpression(), !188)
  %28 = icmp eq ptr %27, null, !dbg !194
  br i1 %28, label %31, label %29, !dbg !195

29:                                               ; preds = %26
  %30 = atomicrmw add ptr %27, i64 1 seq_cst, align 8, !dbg !196
  br label %31, !dbg !197

31:                                               ; preds = %26, %29
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %3) #3, !dbg !198
  %32 = getelementptr inbounds i8, ptr %16, i64 12, !dbg !199
  %33 = load i16, ptr %32, align 1, !dbg !199, !tbaa !201
  %34 = icmp eq i16 %33, 129, !dbg !204
  br i1 %34, label %42, label %35, !dbg !205

35:                                               ; preds = %31
    #dbg_assign(i1 undef, !164, !DIExpression(), !140, ptr %4, !DIExpression(), !206)
    #dbg_value(i32 1, !169, !DIExpression(), !206)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %4) #3, !dbg !209
  store i32 0, ptr %4, align 4, !dbg !210, !tbaa !176, !DIAssignID !211
    #dbg_assign(i32 0, !164, !DIExpression(), !211, ptr %4, !DIExpression(), !206)
  %36 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %4) #3, !dbg !212
    #dbg_value(ptr %36, !170, !DIExpression(), !206)
  %37 = icmp eq ptr %36, null, !dbg !213
  br i1 %37, label %41, label %38, !dbg !214

38:                                               ; preds = %35
  %39 = getelementptr inbounds i8, ptr %36, i64 8, !dbg !215
  %40 = atomicrmw add ptr %39, i64 1 seq_cst, align 8, !dbg !216
  br label %41, !dbg !217

41:                                               ; preds = %35, %38
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %4) #3, !dbg !218
  br label %113, !dbg !219

42:                                               ; preds = %31
    #dbg_value(ptr %17, !133, !DIExpression(), !146)
  %43 = getelementptr inbounds i8, ptr %16, i64 18, !dbg !220
  %44 = icmp ugt ptr %43, %13, !dbg !222
  br i1 %44, label %45, label %52, !dbg !223

45:                                               ; preds = %42
    #dbg_assign(i1 undef, !164, !DIExpression(), !141, ptr %5, !DIExpression(), !224)
    #dbg_value(i32 4, !169, !DIExpression(), !224)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %5) #3, !dbg !227
  store i32 0, ptr %5, align 4, !dbg !228, !tbaa !176, !DIAssignID !229
    #dbg_assign(i32 0, !164, !DIExpression(), !229, ptr %5, !DIExpression(), !224)
  %46 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %5) #3, !dbg !230
    #dbg_value(ptr %46, !170, !DIExpression(), !224)
  %47 = icmp eq ptr %46, null, !dbg !231
  br i1 %47, label %51, label %48, !dbg !232

48:                                               ; preds = %45
  %49 = getelementptr inbounds i8, ptr %46, i64 32, !dbg !233
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8, !dbg !234
  br label %51, !dbg !235

51:                                               ; preds = %45, %48
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %5) #3, !dbg !236
  br label %113, !dbg !237

52:                                               ; preds = %42
  %53 = getelementptr inbounds i8, ptr %16, i64 16, !dbg !238
  %54 = load i16, ptr %53, align 2, !dbg !238, !tbaa !240
  switch i16 %54, label %55 [
    i16 8, label %62
    i16 -8826, label %62
  ], !dbg !242

55:                                               ; preds = %52
    #dbg_assign(i1 undef, !164, !DIExpression(), !142, ptr %6, !DIExpression(), !243)
    #dbg_value(i32 1, !169, !DIExpression(), !243)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %6) #3, !dbg !246
  store i32 0, ptr %6, align 4, !dbg !247, !tbaa !176, !DIAssignID !248
    #dbg_assign(i32 0, !164, !DIExpression(), !248, ptr %6, !DIExpression(), !243)
  %56 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %6) #3, !dbg !249
    #dbg_value(ptr %56, !170, !DIExpression(), !243)
  %57 = icmp eq ptr %56, null, !dbg !250
  br i1 %57, label %61, label %58, !dbg !251

58:                                               ; preds = %55
  %59 = getelementptr inbounds i8, ptr %56, i64 8, !dbg !252
  %60 = atomicrmw add ptr %59, i64 1 seq_cst, align 8, !dbg !253
  br label %61, !dbg !254

61:                                               ; preds = %55, %58
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %6) #3, !dbg !255
  br label %113, !dbg !256

62:                                               ; preds = %52, %52
  %63 = load i16, ptr %17, align 2, !dbg !257, !tbaa !258
  %64 = and i16 %63, -241, !dbg !259
  %65 = call i16 @llvm.bswap.i16(i16 %64), !dbg !259
  store i16 %65, ptr %9, align 2, !dbg !260, !tbaa !261, !DIAssignID !262
    #dbg_assign(i16 %65, !135, !DIExpression(), !262, ptr %9, !DIExpression(), !146)
  %66 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @l2_map, ptr noundef nonnull %9) #3, !dbg !263
    #dbg_value(ptr %66, !134, !DIExpression(), !146)
  %67 = icmp eq ptr %66, null, !dbg !264
  br i1 %67, label %68, label %75, !dbg !266

68:                                               ; preds = %62
    #dbg_assign(i1 undef, !164, !DIExpression(), !143, ptr %7, !DIExpression(), !267)
    #dbg_value(i32 2, !169, !DIExpression(), !267)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %7) #3, !dbg !270
  store i32 0, ptr %7, align 4, !dbg !271, !tbaa !176, !DIAssignID !272
    #dbg_assign(i32 0, !164, !DIExpression(), !272, ptr %7, !DIExpression(), !267)
  %69 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %7) #3, !dbg !273
    #dbg_value(ptr %69, !170, !DIExpression(), !267)
  %70 = icmp eq ptr %69, null, !dbg !274
  br i1 %70, label %74, label %71, !dbg !275

71:                                               ; preds = %68
  %72 = getelementptr inbounds i8, ptr %69, i64 16, !dbg !276
  %73 = atomicrmw add ptr %72, i64 1 seq_cst, align 8, !dbg !277
  br label %74, !dbg !278

74:                                               ; preds = %68, %71
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %7) #3, !dbg !279
  br label %113, !dbg !280

75:                                               ; preds = %62
  %76 = getelementptr inbounds i8, ptr %66, i64 6, !dbg !281
  %77 = load i16, ptr %76, align 2, !dbg !281, !tbaa !282
  %78 = call i16 @llvm.bswap.i16(i16 %77), !dbg !281
  store i16 %78, ptr %17, align 2, !dbg !284, !tbaa !258
    #dbg_value(i32 0, !136, !DIExpression(), !285)
  %79 = getelementptr inbounds i8, ptr %16, i64 6
    #dbg_value(i32 0, !136, !DIExpression(), !285)
    #dbg_value(i64 0, !136, !DIExpression(), !285)
  %80 = load i8, ptr %16, align 1, !dbg !286, !tbaa !289
  store i8 %80, ptr %79, align 1, !dbg !290, !tbaa !289
  %81 = load i8, ptr %66, align 1, !dbg !291, !tbaa !289
  store i8 %81, ptr %16, align 1, !dbg !292, !tbaa !289
    #dbg_value(i64 1, !136, !DIExpression(), !285)
  %82 = getelementptr inbounds i8, ptr %16, i64 1, !dbg !286
  %83 = load i8, ptr %82, align 1, !dbg !286, !tbaa !289
  %84 = getelementptr inbounds i8, ptr %16, i64 7, !dbg !293
  store i8 %83, ptr %84, align 1, !dbg !290, !tbaa !289
  %85 = getelementptr inbounds i8, ptr %66, i64 1, !dbg !291
  %86 = load i8, ptr %85, align 1, !dbg !291, !tbaa !289
  store i8 %86, ptr %82, align 1, !dbg !292, !tbaa !289
    #dbg_value(i64 2, !136, !DIExpression(), !285)
  %87 = getelementptr inbounds i8, ptr %16, i64 2, !dbg !286
  %88 = load i8, ptr %87, align 1, !dbg !286, !tbaa !289
  %89 = getelementptr inbounds i8, ptr %16, i64 8, !dbg !293
  store i8 %88, ptr %89, align 1, !dbg !290, !tbaa !289
  %90 = getelementptr inbounds i8, ptr %66, i64 2, !dbg !291
  %91 = load i8, ptr %90, align 1, !dbg !291, !tbaa !289
  store i8 %91, ptr %87, align 1, !dbg !292, !tbaa !289
    #dbg_value(i64 3, !136, !DIExpression(), !285)
  %92 = getelementptr inbounds i8, ptr %16, i64 3, !dbg !286
  %93 = load i8, ptr %92, align 1, !dbg !286, !tbaa !289
  %94 = getelementptr inbounds i8, ptr %16, i64 9, !dbg !293
  store i8 %93, ptr %94, align 1, !dbg !290, !tbaa !289
  %95 = getelementptr inbounds i8, ptr %66, i64 3, !dbg !291
  %96 = load i8, ptr %95, align 1, !dbg !291, !tbaa !289
  store i8 %96, ptr %92, align 1, !dbg !292, !tbaa !289
    #dbg_value(i64 4, !136, !DIExpression(), !285)
  %97 = getelementptr inbounds i8, ptr %16, i64 4, !dbg !286
  %98 = load i8, ptr %97, align 1, !dbg !286, !tbaa !289
  %99 = getelementptr inbounds i8, ptr %16, i64 10, !dbg !293
  store i8 %98, ptr %99, align 1, !dbg !290, !tbaa !289
  %100 = getelementptr inbounds i8, ptr %66, i64 4, !dbg !291
  %101 = load i8, ptr %100, align 1, !dbg !291, !tbaa !289
  store i8 %101, ptr %97, align 1, !dbg !292, !tbaa !289
    #dbg_value(i64 5, !136, !DIExpression(), !285)
  %102 = getelementptr inbounds i8, ptr %16, i64 5, !dbg !286
  %103 = load i8, ptr %102, align 1, !dbg !286, !tbaa !289
  %104 = getelementptr inbounds i8, ptr %16, i64 11, !dbg !293
  store i8 %103, ptr %104, align 1, !dbg !290, !tbaa !289
  %105 = getelementptr inbounds i8, ptr %66, i64 5, !dbg !291
  %106 = load i8, ptr %105, align 1, !dbg !291, !tbaa !289
  store i8 %106, ptr %102, align 1, !dbg !292, !tbaa !289
    #dbg_value(i64 6, !136, !DIExpression(), !285)
    #dbg_assign(i1 undef, !164, !DIExpression(), !144, ptr %8, !DIExpression(), !294)
    #dbg_value(i32 3, !169, !DIExpression(), !294)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %8) #3, !dbg !296
  store i32 0, ptr %8, align 4, !dbg !297, !tbaa !176, !DIAssignID !298
    #dbg_assign(i32 0, !164, !DIExpression(), !298, ptr %8, !DIExpression(), !294)
  %107 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @stats, ptr noundef nonnull %8) #3, !dbg !299
    #dbg_value(ptr %107, !170, !DIExpression(), !294)
  %108 = icmp eq ptr %107, null, !dbg !300
  br i1 %108, label %112, label %109, !dbg !301

109:                                              ; preds = %75
  %110 = getelementptr inbounds i8, ptr %107, i64 24, !dbg !302
  %111 = atomicrmw add ptr %110, i64 1 seq_cst, align 8, !dbg !303
  br label %112, !dbg !304

112:                                              ; preds = %75, %109
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %8) #3, !dbg !305
  br label %113, !dbg !306

113:                                              ; preds = %112, %74, %61, %51, %41, %25
  %114 = phi i32 [ 0, %25 ], [ 2, %41 ], [ 0, %51 ], [ 2, %61 ], [ 3, %112 ], [ 3, %74 ], !dbg !146
  call void @llvm.lifetime.end.p0(i64 2, ptr nonnull %9) #3, !dbg !307
  ret i32 %114, !dbg !307
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

attributes #0 = { nounwind "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!101, !102, !103, !104, !105, !106}
!llvm.ident = !{!107}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "l2_map", scope: !2, file: !3, line: 51, type: !82, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Debian clang version 19.1.7 (3+b1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !14, globals: !27, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "xdp_l2fwd.c", directory: "/opt/styx-gateway/ebpf_modules/xdp_l2fwd", checksumkind: CSK_MD5, checksum: "f437ec9a50045dbd276e0ee36187b8ae")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "xdp_action", file: !6, line: 6449, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "/usr/include/linux/bpf.h", directory: "", checksumkind: CSK_MD5, checksum: "62c7f09341fb12dc06cafad5394e5c39")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13}
!9 = !DIEnumerator(name: "XDP_ABORTED", value: 0)
!10 = !DIEnumerator(name: "XDP_DROP", value: 1)
!11 = !DIEnumerator(name: "XDP_PASS", value: 2)
!12 = !DIEnumerator(name: "XDP_TX", value: 3)
!13 = !DIEnumerator(name: "XDP_REDIRECT", value: 4)
!14 = !{!15, !16, !17, !20}
!15 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!16 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!17 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u16", file: !18, line: 24, baseType: !19)
!18 = !DIFile(filename: "/usr/include/asm-generic/int-ll64.h", directory: "", checksumkind: CSK_MD5, checksum: "b810f270733e106319b67ef512c6246e")
!19 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!20 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !21, size: 64)
!21 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "vlanhdr", file: !3, line: 36, size: 32, elements: !22)
!22 = !{!23, !26}
!23 = !DIDerivedType(tag: DW_TAG_member, name: "h_vlan_TCI", scope: !21, file: !3, line: 37, baseType: !24, size: 16)
!24 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be16", file: !25, line: 32, baseType: !17)
!25 = !DIFile(filename: "/usr/include/linux/types.h", directory: "", checksumkind: CSK_MD5, checksum: "c0ade1a1a309d6896ce6080a51a2d105")
!26 = !DIDerivedType(tag: DW_TAG_member, name: "h_vlan_encapsulated_proto", scope: !21, file: !3, line: 38, baseType: !24, size: 16, offset: 16)
!27 = !{!28, !37, !0, !43, !72}
!28 = !DIGlobalVariableExpression(var: !29, expr: !DIExpression())
!29 = distinct !DIGlobalVariable(name: "bpf_map_lookup_elem", scope: !2, file: !30, line: 64, type: !31, isLocal: true, isDefinition: true)
!30 = !DIFile(filename: "/usr/include/bpf/bpf_helper_defs.h", directory: "", checksumkind: CSK_MD5, checksum: "a5a8a4f934aa5711dec23fec645c4001")
!31 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !32)
!32 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !33, size: 64)
!33 = !DISubroutineType(types: !34)
!34 = !{!15, !15, !35}
!35 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !36, size: 64)
!36 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!37 = !DIGlobalVariableExpression(var: !38, expr: !DIExpression())
!38 = distinct !DIGlobalVariable(name: "_license", scope: !2, file: !3, line: 148, type: !39, isLocal: false, isDefinition: true)
!39 = !DICompositeType(tag: DW_TAG_array_type, baseType: !40, size: 32, elements: !41)
!40 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!41 = !{!42}
!42 = !DISubrange(count: 4)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "stats", scope: !2, file: !3, line: 70, type: !45, isLocal: false, isDefinition: true)
!45 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 65, size: 256, elements: !46)
!46 = !{!47, !53, !58, !61}
!47 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !45, file: !3, line: 66, baseType: !48, size: 64)
!48 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64)
!49 = !DICompositeType(tag: DW_TAG_array_type, baseType: !50, size: 192, elements: !51)
!50 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!51 = !{!52}
!52 = !DISubrange(count: 6)
!53 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !45, file: !3, line: 67, baseType: !54, size: 64, offset: 64)
!54 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !55, size: 64)
!55 = !DICompositeType(tag: DW_TAG_array_type, baseType: !50, size: 32, elements: !56)
!56 = !{!57}
!57 = !DISubrange(count: 1)
!58 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !45, file: !3, line: 68, baseType: !59, size: 64, offset: 128)
!59 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !60, size: 64)
!60 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !18, line: 27, baseType: !7)
!61 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !45, file: !3, line: 69, baseType: !62, size: 64, offset: 192)
!62 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !63, size: 64)
!63 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "stats_t", file: !3, line: 57, size: 320, elements: !64)
!64 = !{!65, !68, !69, !70, !71}
!65 = !DIDerivedType(tag: DW_TAG_member, name: "packets_processed", scope: !63, file: !3, line: 58, baseType: !66, size: 64)
!66 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !18, line: 31, baseType: !67)
!67 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!68 = !DIDerivedType(tag: DW_TAG_member, name: "packets_passed", scope: !63, file: !3, line: 59, baseType: !66, size: 64, offset: 64)
!69 = !DIDerivedType(tag: DW_TAG_member, name: "packets_hairpin_miss", scope: !63, file: !3, line: 60, baseType: !66, size: 64, offset: 128)
!70 = !DIDerivedType(tag: DW_TAG_member, name: "packets_translated", scope: !63, file: !3, line: 61, baseType: !66, size: 64, offset: 192)
!71 = !DIDerivedType(tag: DW_TAG_member, name: "errors", scope: !63, file: !3, line: 62, baseType: !66, size: 64, offset: 256)
!72 = !DIGlobalVariableExpression(var: !73, expr: !DIExpression())
!73 = distinct !DIGlobalVariable(name: "_xdp_l2_fwd", scope: !2, file: !3, line: 78, type: !74, isLocal: false, isDefinition: true)
!74 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 75, size: 128, elements: !75)
!75 = !{!76, !81}
!76 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !74, file: !3, line: 76, baseType: !77, size: 64)
!77 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !78, size: 64)
!78 = !DICompositeType(tag: DW_TAG_array_type, baseType: !50, size: 320, elements: !79)
!79 = !{!80}
!80 = !DISubrange(count: 10)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "XDP_PASS", scope: !74, file: !3, line: 77, baseType: !54, size: 64, offset: 64)
!82 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 46, size: 256, elements: !83)
!83 = !{!84, !85, !90, !92}
!84 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !82, file: !3, line: 47, baseType: !54, size: 64)
!85 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !82, file: !3, line: 48, baseType: !86, size: 64, offset: 64)
!86 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !87, size: 64)
!87 = !DICompositeType(tag: DW_TAG_array_type, baseType: !50, size: 131072, elements: !88)
!88 = !{!89}
!89 = !DISubrange(count: 4096)
!90 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !82, file: !3, line: 49, baseType: !91, size: 64, offset: 128)
!91 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !17, size: 64)
!92 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !82, file: !3, line: 50, baseType: !93, size: 64, offset: 192)
!93 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !94, size: 64)
!94 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "l2_info", file: !3, line: 41, size: 64, elements: !95)
!95 = !{!96, !100}
!96 = !DIDerivedType(tag: DW_TAG_member, name: "h_dest", scope: !94, file: !3, line: 42, baseType: !97, size: 48)
!97 = !DICompositeType(tag: DW_TAG_array_type, baseType: !98, size: 48, elements: !51)
!98 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u8", file: !18, line: 21, baseType: !99)
!99 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_id", scope: !94, file: !3, line: 43, baseType: !17, size: 16, offset: 48)
!101 = !{i32 7, !"Dwarf Version", i32 5}
!102 = !{i32 2, !"Debug Info Version", i32 3}
!103 = !{i32 1, !"wchar_size", i32 4}
!104 = !{i32 8, !"PIC Level", i32 2}
!105 = !{i32 7, !"PIE Level", i32 2}
!106 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!107 = !{!"Debian clang version 19.1.7 (3+b1)"}
!108 = distinct !DISubprogram(name: "xdp_l2_fwd", scope: !3, file: !3, line: 97, type: !109, scopeLine: 98, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !120)
!109 = !DISubroutineType(types: !110)
!110 = !{!50, !111}
!111 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !112, size: 64)
!112 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "xdp_md", file: !6, line: 6460, size: 192, elements: !113)
!113 = !{!114, !115, !116, !117, !118, !119}
!114 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !112, file: !6, line: 6461, baseType: !60, size: 32)
!115 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !112, file: !6, line: 6462, baseType: !60, size: 32, offset: 32)
!116 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !112, file: !6, line: 6463, baseType: !60, size: 32, offset: 64)
!117 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !112, file: !6, line: 6465, baseType: !60, size: 32, offset: 96)
!118 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_index", scope: !112, file: !6, line: 6466, baseType: !60, size: 32, offset: 128)
!119 = !DIDerivedType(tag: DW_TAG_member, name: "egress_ifindex", scope: !112, file: !6, line: 6468, baseType: !60, size: 32, offset: 160)
!120 = !{!121, !122, !123, !124, !133, !134, !135, !136}
!121 = !DILocalVariable(name: "ctx", arg: 1, scope: !108, file: !3, line: 97, type: !111)
!122 = !DILocalVariable(name: "data_end", scope: !108, file: !3, line: 99, type: !15)
!123 = !DILocalVariable(name: "data", scope: !108, file: !3, line: 100, type: !15)
!124 = !DILocalVariable(name: "eth", scope: !108, file: !3, line: 101, type: !125)
!125 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !126, size: 64)
!126 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ethhdr", file: !127, line: 173, size: 112, elements: !128)
!127 = !DIFile(filename: "/usr/include/linux/if_ether.h", directory: "", checksumkind: CSK_MD5, checksum: "163f54fb1af2e21fea410f14eb18fa76")
!128 = !{!129, !131, !132}
!129 = !DIDerivedType(tag: DW_TAG_member, name: "h_dest", scope: !126, file: !127, line: 174, baseType: !130, size: 48)
!130 = !DICompositeType(tag: DW_TAG_array_type, baseType: !99, size: 48, elements: !51)
!131 = !DIDerivedType(tag: DW_TAG_member, name: "h_source", scope: !126, file: !127, line: 175, baseType: !130, size: 48, offset: 48)
!132 = !DIDerivedType(tag: DW_TAG_member, name: "h_proto", scope: !126, file: !127, line: 176, baseType: !24, size: 16, offset: 96)
!133 = !DILocalVariable(name: "vh", scope: !108, file: !3, line: 102, type: !20)
!134 = !DILocalVariable(name: "info", scope: !108, file: !3, line: 103, type: !93)
!135 = !DILocalVariable(name: "vlan_id", scope: !108, file: !3, line: 104, type: !17)
!136 = !DILocalVariable(name: "i", scope: !137, file: !3, line: 139, type: !50)
!137 = distinct !DILexicalBlock(scope: !108, file: !3, line: 139, column: 2)
!138 = distinct !DIAssignID()
!139 = distinct !DIAssignID()
!140 = distinct !DIAssignID()
!141 = distinct !DIAssignID()
!142 = distinct !DIAssignID()
!143 = distinct !DIAssignID()
!144 = distinct !DIAssignID()
!145 = distinct !DIAssignID()
!146 = !DILocation(line: 0, scope: !108)
!147 = !DILocation(line: 99, column: 38, scope: !108)
!148 = !{!149, !150, i64 4}
!149 = !{!"xdp_md", !150, i64 0, !150, i64 4, !150, i64 8, !150, i64 12, !150, i64 16, !150, i64 20}
!150 = !{!"int", !151, i64 0}
!151 = !{!"omnipotent char", !152, i64 0}
!152 = !{!"Simple C/C++ TBAA"}
!153 = !DILocation(line: 99, column: 27, scope: !108)
!154 = !DILocation(line: 99, column: 19, scope: !108)
!155 = !DILocation(line: 100, column: 38, scope: !108)
!156 = !{!149, !150, i64 0}
!157 = !DILocation(line: 100, column: 27, scope: !108)
!158 = !DILocation(line: 100, column: 19, scope: !108)
!159 = !DILocation(line: 104, column: 2, scope: !108)
!160 = !DILocation(line: 106, column: 19, scope: !161)
!161 = distinct !DILexicalBlock(scope: !108, file: !3, line: 106, column: 6)
!162 = !DILocation(line: 106, column: 24, scope: !161)
!163 = !DILocation(line: 106, column: 6, scope: !108)
!164 = !DILocalVariable(name: "zero", scope: !165, file: !3, line: 82, type: !60)
!165 = distinct !DISubprogram(name: "stats_inc", scope: !3, file: !3, line: 80, type: !166, scopeLine: 81, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !168)
!166 = !DISubroutineType(types: !167)
!167 = !{null, !60}
!168 = !{!169, !164, !170}
!169 = !DILocalVariable(name: "field", arg: 1, scope: !165, file: !3, line: 80, type: !60)
!170 = !DILocalVariable(name: "s", scope: !165, file: !3, line: 83, type: !62)
!171 = !DILocation(line: 0, scope: !165, inlinedAt: !172)
!172 = distinct !DILocation(line: 107, column: 3, scope: !173)
!173 = distinct !DILexicalBlock(scope: !161, file: !3, line: 106, column: 36)
!174 = !DILocation(line: 82, column: 2, scope: !165, inlinedAt: !172)
!175 = !DILocation(line: 82, column: 8, scope: !165, inlinedAt: !172)
!176 = !{!150, !150, i64 0}
!177 = distinct !DIAssignID()
!178 = !DILocation(line: 83, column: 22, scope: !165, inlinedAt: !172)
!179 = !DILocation(line: 85, column: 7, scope: !180, inlinedAt: !172)
!180 = distinct !DILexicalBlock(scope: !165, file: !3, line: 85, column: 6)
!181 = !DILocation(line: 85, column: 6, scope: !165, inlinedAt: !172)
!182 = !DILocation(line: 92, column: 35, scope: !183, inlinedAt: !172)
!183 = distinct !DILexicalBlock(scope: !165, file: !3, line: 87, column: 17)
!184 = !DILocation(line: 92, column: 10, scope: !183, inlinedAt: !172)
!185 = !DILocation(line: 92, column: 47, scope: !183, inlinedAt: !172)
!186 = !DILocation(line: 94, column: 1, scope: !165, inlinedAt: !172)
!187 = !DILocation(line: 108, column: 3, scope: !173)
!188 = !DILocation(line: 0, scope: !165, inlinedAt: !189)
!189 = distinct !DILocation(line: 110, column: 2, scope: !108)
!190 = !DILocation(line: 82, column: 2, scope: !165, inlinedAt: !189)
!191 = !DILocation(line: 82, column: 8, scope: !165, inlinedAt: !189)
!192 = distinct !DIAssignID()
!193 = !DILocation(line: 83, column: 22, scope: !165, inlinedAt: !189)
!194 = !DILocation(line: 85, column: 7, scope: !180, inlinedAt: !189)
!195 = !DILocation(line: 85, column: 6, scope: !165, inlinedAt: !189)
!196 = !DILocation(line: 88, column: 10, scope: !183, inlinedAt: !189)
!197 = !DILocation(line: 88, column: 58, scope: !183, inlinedAt: !189)
!198 = !DILocation(line: 94, column: 1, scope: !165, inlinedAt: !189)
!199 = !DILocation(line: 112, column: 11, scope: !200)
!200 = distinct !DILexicalBlock(scope: !108, file: !3, line: 112, column: 6)
!201 = !{!202, !203, i64 12}
!202 = !{!"ethhdr", !151, i64 0, !151, i64 6, !203, i64 12}
!203 = !{!"short", !151, i64 0}
!204 = !DILocation(line: 112, column: 19, scope: !200)
!205 = !DILocation(line: 112, column: 6, scope: !108)
!206 = !DILocation(line: 0, scope: !165, inlinedAt: !207)
!207 = distinct !DILocation(line: 113, column: 3, scope: !208)
!208 = distinct !DILexicalBlock(scope: !200, file: !3, line: 112, column: 46)
!209 = !DILocation(line: 82, column: 2, scope: !165, inlinedAt: !207)
!210 = !DILocation(line: 82, column: 8, scope: !165, inlinedAt: !207)
!211 = distinct !DIAssignID()
!212 = !DILocation(line: 83, column: 22, scope: !165, inlinedAt: !207)
!213 = !DILocation(line: 85, column: 7, scope: !180, inlinedAt: !207)
!214 = !DILocation(line: 85, column: 6, scope: !165, inlinedAt: !207)
!215 = !DILocation(line: 89, column: 35, scope: !183, inlinedAt: !207)
!216 = !DILocation(line: 89, column: 10, scope: !183, inlinedAt: !207)
!217 = !DILocation(line: 89, column: 55, scope: !183, inlinedAt: !207)
!218 = !DILocation(line: 94, column: 1, scope: !165, inlinedAt: !207)
!219 = !DILocation(line: 114, column: 3, scope: !208)
!220 = !DILocation(line: 118, column: 18, scope: !221)
!221 = distinct !DILexicalBlock(scope: !108, file: !3, line: 118, column: 6)
!222 = !DILocation(line: 118, column: 23, scope: !221)
!223 = !DILocation(line: 118, column: 6, scope: !108)
!224 = !DILocation(line: 0, scope: !165, inlinedAt: !225)
!225 = distinct !DILocation(line: 119, column: 3, scope: !226)
!226 = distinct !DILexicalBlock(scope: !221, file: !3, line: 118, column: 35)
!227 = !DILocation(line: 82, column: 2, scope: !165, inlinedAt: !225)
!228 = !DILocation(line: 82, column: 8, scope: !165, inlinedAt: !225)
!229 = distinct !DIAssignID()
!230 = !DILocation(line: 83, column: 22, scope: !165, inlinedAt: !225)
!231 = !DILocation(line: 85, column: 7, scope: !180, inlinedAt: !225)
!232 = !DILocation(line: 85, column: 6, scope: !165, inlinedAt: !225)
!233 = !DILocation(line: 92, column: 35, scope: !183, inlinedAt: !225)
!234 = !DILocation(line: 92, column: 10, scope: !183, inlinedAt: !225)
!235 = !DILocation(line: 92, column: 47, scope: !183, inlinedAt: !225)
!236 = !DILocation(line: 94, column: 1, scope: !165, inlinedAt: !225)
!237 = !DILocation(line: 120, column: 3, scope: !226)
!238 = !DILocation(line: 123, column: 10, scope: !239)
!239 = distinct !DILexicalBlock(scope: !108, file: !3, line: 123, column: 6)
!240 = !{!241, !203, i64 2}
!241 = !{!"vlanhdr", !203, i64 0, !203, i64 2}
!242 = !DILocation(line: 123, column: 59, scope: !239)
!243 = !DILocation(line: 0, scope: !165, inlinedAt: !244)
!244 = distinct !DILocation(line: 125, column: 3, scope: !245)
!245 = distinct !DILexicalBlock(scope: !239, file: !3, line: 124, column: 62)
!246 = !DILocation(line: 82, column: 2, scope: !165, inlinedAt: !244)
!247 = !DILocation(line: 82, column: 8, scope: !165, inlinedAt: !244)
!248 = distinct !DIAssignID()
!249 = !DILocation(line: 83, column: 22, scope: !165, inlinedAt: !244)
!250 = !DILocation(line: 85, column: 7, scope: !180, inlinedAt: !244)
!251 = !DILocation(line: 85, column: 6, scope: !165, inlinedAt: !244)
!252 = !DILocation(line: 89, column: 35, scope: !183, inlinedAt: !244)
!253 = !DILocation(line: 89, column: 10, scope: !183, inlinedAt: !244)
!254 = !DILocation(line: 89, column: 55, scope: !183, inlinedAt: !244)
!255 = !DILocation(line: 94, column: 1, scope: !165, inlinedAt: !244)
!256 = !DILocation(line: 126, column: 3, scope: !245)
!257 = !DILocation(line: 129, column: 12, scope: !108)
!258 = !{!241, !203, i64 0}
!259 = !DILocation(line: 129, column: 38, scope: !108)
!260 = !DILocation(line: 129, column: 10, scope: !108)
!261 = !{!203, !203, i64 0}
!262 = distinct !DIAssignID()
!263 = !DILocation(line: 131, column: 9, scope: !108)
!264 = !DILocation(line: 132, column: 7, scope: !265)
!265 = distinct !DILexicalBlock(scope: !108, file: !3, line: 132, column: 6)
!266 = !DILocation(line: 132, column: 6, scope: !108)
!267 = !DILocation(line: 0, scope: !165, inlinedAt: !268)
!268 = distinct !DILocation(line: 133, column: 3, scope: !269)
!269 = distinct !DILexicalBlock(scope: !265, file: !3, line: 132, column: 13)
!270 = !DILocation(line: 82, column: 2, scope: !165, inlinedAt: !268)
!271 = !DILocation(line: 82, column: 8, scope: !165, inlinedAt: !268)
!272 = distinct !DIAssignID()
!273 = !DILocation(line: 83, column: 22, scope: !165, inlinedAt: !268)
!274 = !DILocation(line: 85, column: 7, scope: !180, inlinedAt: !268)
!275 = !DILocation(line: 85, column: 6, scope: !165, inlinedAt: !268)
!276 = !DILocation(line: 90, column: 35, scope: !183, inlinedAt: !268)
!277 = !DILocation(line: 90, column: 10, scope: !183, inlinedAt: !268)
!278 = !DILocation(line: 90, column: 61, scope: !183, inlinedAt: !268)
!279 = !DILocation(line: 94, column: 1, scope: !165, inlinedAt: !268)
!280 = !DILocation(line: 134, column: 3, scope: !269)
!281 = !DILocation(line: 137, column: 19, scope: !108)
!282 = !{!283, !203, i64 6}
!283 = !{!"l2_info", !151, i64 0, !203, i64 6}
!284 = !DILocation(line: 137, column: 17, scope: !108)
!285 = !DILocation(line: 0, scope: !137)
!286 = !DILocation(line: 140, column: 22, scope: !287)
!287 = distinct !DILexicalBlock(scope: !288, file: !3, line: 139, column: 37)
!288 = distinct !DILexicalBlock(scope: !137, file: !3, line: 139, column: 2)
!289 = !{!151, !151, i64 0}
!290 = !DILocation(line: 140, column: 20, scope: !287)
!291 = !DILocation(line: 141, column: 22, scope: !287)
!292 = !DILocation(line: 141, column: 20, scope: !287)
!293 = !DILocation(line: 140, column: 3, scope: !287)
!294 = !DILocation(line: 0, scope: !165, inlinedAt: !295)
!295 = distinct !DILocation(line: 144, column: 2, scope: !108)
!296 = !DILocation(line: 82, column: 2, scope: !165, inlinedAt: !295)
!297 = !DILocation(line: 82, column: 8, scope: !165, inlinedAt: !295)
!298 = distinct !DIAssignID()
!299 = !DILocation(line: 83, column: 22, scope: !165, inlinedAt: !295)
!300 = !DILocation(line: 85, column: 7, scope: !180, inlinedAt: !295)
!301 = !DILocation(line: 85, column: 6, scope: !165, inlinedAt: !295)
!302 = !DILocation(line: 91, column: 35, scope: !183, inlinedAt: !295)
!303 = !DILocation(line: 91, column: 10, scope: !183, inlinedAt: !295)
!304 = !DILocation(line: 91, column: 59, scope: !183, inlinedAt: !295)
!305 = !DILocation(line: 94, column: 1, scope: !165, inlinedAt: !295)
!306 = !DILocation(line: 145, column: 2, scope: !108)
!307 = !DILocation(line: 146, column: 1, scope: !108)
