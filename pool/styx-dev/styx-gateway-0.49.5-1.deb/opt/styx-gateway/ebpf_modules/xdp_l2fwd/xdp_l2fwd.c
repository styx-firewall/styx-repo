/* SPDX-License-Identifier: AGPL-3.0-or-later */
/*
 * Soft:        XDP L2 hairpin forwarder with 802.1Q VLAN translation.
 *              Non-VLAN frames and non-IP frames go to XDP_PASS. For
 *              IPv4/IPv6-over-802.1Q frames the ingress VLAN ID is looked up
 *              in l2_map; on a hit the TCI and MACs are rewritten in-place
 *              and the frame is hairpinned (XDP_TX). No entry: XDP_TX
 *              unmodified.
 *
 * Authors:     Alexandre Cassen, <acassen@gmail.com>
 *
 *              This program is free software; you can redistribute it and/or
 *              modify it under the terms of the GNU Affero General Public
 *              License Version 3.0 as published by the Free Software Foundation;
 *              either version 3.0 of the License, or (at your option) any later
 *              version.
 *
 * Copyright (C) 2026 Alexandre Cassen, <acassen@gmail.com>
 *
 *              Modified by Styx (2026-10-02): added the per-CPU `stats` map and
 *              its increments in the datapath, so the module has telemetry like
 *              the rest of the tree. Forwarding behaviour is unchanged; the
 *              original copyright and license above are retained.
 */

#define KBUILD_MODNAME "xdp_l2_fwd"

#include <linux/if_ether.h>
#include <linux/types.h>
#include <sys/socket.h>
#include <linux/bpf.h>
#include <bpf/bpf_endian.h>
#include <bpf/bpf_helpers.h>
#include <xdp/xdp_helpers.h>

struct vlanhdr {
	__be16 h_vlan_TCI;
	__be16 h_vlan_encapsulated_proto;
};

struct l2_info {
	__u8  h_dest[ETH_ALEN];
	__u16 vlan_id;
};

struct {
	__uint(type, BPF_MAP_TYPE_HASH);
	__uint(max_entries, 4096);
	__type(key, __u16);
	__type(value, struct l2_info);
} l2_map SEC(".maps");

/* Telemetry (added by Styx): what the program did with the frames it saw.
 * `processed` counts every frame that got past the Ethernet bounds check, and
 * the two hairpins are told apart because they mean very different things: a
 * miss is a frame sent back untouched, a hit is a translated one. */
struct stats_t {
	__u64 packets_processed;
	__u64 packets_passed;
	__u64 packets_hairpin_miss;
	__u64 packets_translated;
	__u64 errors;
};

struct {
	__uint(type, BPF_MAP_TYPE_PERCPU_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, struct stats_t);
} stats SEC(".maps");

/* Dispatcher metadata: only XDP_PASS needs the chain-call, because XDP_TX (the
 * hairpin) is terminal. The priority here is the intent; the runtime one comes
 * from the module's `priority` pre-attach param. */
struct {
	__uint(priority, 10);
	__uint(XDP_PASS, 1);
} XDP_RUN_CONFIG(xdp_l2_fwd);

static __always_inline void stats_inc(__u32 field)
{
	__u32 zero = 0;
	struct stats_t *s = bpf_map_lookup_elem(&stats, &zero);

	if (!s)
		return;
	switch (field) {
	case 0: __sync_fetch_and_add(&s->packets_processed, 1); break;
	case 1: __sync_fetch_and_add(&s->packets_passed, 1); break;
	case 2: __sync_fetch_and_add(&s->packets_hairpin_miss, 1); break;
	case 3: __sync_fetch_and_add(&s->packets_translated, 1); break;
	case 4: __sync_fetch_and_add(&s->errors, 1); break;
	}
}

SEC("xdp")
int xdp_l2_fwd(struct xdp_md *ctx)
{
	void *data_end = (void *)(long)ctx->data_end;
	void *data     = (void *)(long)ctx->data;
	struct ethhdr *eth = data;
	struct vlanhdr *vh;
	struct l2_info *info;
	__u16 vlan_id;

	if ((void *)(eth + 1) > data_end) {
		stats_inc(4);
		return XDP_ABORTED;
	}
	stats_inc(0);

	if (eth->h_proto != bpf_htons(ETH_P_8021Q)) {
		stats_inc(1);
		return XDP_PASS;
	}

	vh = (struct vlanhdr *)(eth + 1);
	if ((void *)(vh + 1) > data_end) {
		stats_inc(4);
		return XDP_ABORTED;
	}

	if (vh->h_vlan_encapsulated_proto != bpf_htons(ETH_P_IP) &&
	    vh->h_vlan_encapsulated_proto != bpf_htons(ETH_P_IPV6)) {
		stats_inc(1);
		return XDP_PASS;
	}

	vlan_id = bpf_ntohs(vh->h_vlan_TCI) & 0x0FFF;

	info = bpf_map_lookup_elem(&l2_map, &vlan_id);
	if (!info) {
		stats_inc(2);
		return XDP_TX;
	}

	vh->h_vlan_TCI = bpf_htons(info->vlan_id);
#pragma unroll
	for (int i = 0; i < ETH_ALEN; i++) {
		eth->h_source[i] = eth->h_dest[i];
		eth->h_dest[i]   = info->h_dest[i];
	}

	stats_inc(3);
	return XDP_TX;
}

char _license[] SEC("license") = "GPL";
