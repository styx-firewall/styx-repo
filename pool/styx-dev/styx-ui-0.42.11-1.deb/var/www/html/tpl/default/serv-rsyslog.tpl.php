<?php
/**
 * Rsyslog (log forwarding) page shell.
 *
 * The two tabs are rendered from named places injected by PageServices:
 *   serv_rsyslog_status        - serv-rsyslog-status.tpl.php
 *   serv_rsyslog_destinations  - serv-rsyslog-destinations.tpl.php
 *
 * Tab switching is handled by the global std-tabs handler (no JS needed).
 * js: scripts/rsyslog/rsyslog.js
 */
$pagep = $tdata['page_data'] ?? [];
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>Rsyslog</h1>
        <p>Forward the system journal to a remote syslog collector managed by rsyslog.</p>

        <script>
        window.rsyslogCanEdit = <?= !empty($pagep['can_write']) ? 'true' : 'false' ?>;
        </script>

        <?php if (!empty($pagep['load_error'])): ?>
        <section class="content-box">
            <div class="std-error-box">
                <strong>Error:</strong> <?= $pagep['load_error'] ?>
            </div>
        </section>
        <?php else: ?>

        <section class="content-box">
            <div class="std-tabs" id="rsyslog-tabs">
                <button class="std-tab-btn active" data-tab="status">Status</button>
                <button class="std-tab-btn" data-tab="destinations">Destinations</button>
            </div>
            <div class="std-tab-panel active" id="tab-status">
                <?= $tdata['serv_rsyslog_status'] ?? '' ?>
            </div>
            <div class="std-tab-panel" id="tab-destinations">
                <?= $tdata['serv_rsyslog_destinations'] ?? '' ?>
            </div>
        </section>

        <?php endif; ?>
    </main>
</div>
