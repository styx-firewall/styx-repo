<?php
/**
 * Rsyslog fragment: Status.
 *
 * Echo-only. All derived text/badges come pre-escaped from the formatter ($pd).
 * js: scripts/rsyslog/rsyslog.js (Refresh status button)
 */
$pd = $tdata['tpl_data'] ?? [];
?>
<?php if (!empty($pd['st_load_error'])): ?>
    <div class="std-error-box">
        <strong>Error:</strong> <?= $pd['st_load_error'] ?>
    </div>
<?php else: ?>

    <div class="rsyslog-status-card">
        <h2>Rsyslog Service</h2>
        <div class="std-form form-compact">
            <div class="form-row">
                <div class="form-col">
                    <label>Package</label>
                    <span class="std-badge <?= $pd['st_installed_badge'] ?? '' ?>"><?= $pd['st_installed_text'] ?></span>
                </div>
                <div class="form-col">
                    <label>Service</label>
                    <span class="std-badge <?= $pd['st_active_badge'] ?? '' ?>"><?= $pd['st_active_text'] ?></span>
                </div>
                <div class="form-col">
                    <label>Forwarding drop-in</label>
                    <span class="std-badge <?= $pd['st_dropin_badge'] ?? '' ?>"><?= $pd['st_dropin_text'] ?></span>
                </div>
                <div class="form-col">
                    <label>Active destination</label>
                    <span><?= $pd['cfg_active_dest_label'] ?? '' ?></span>
                </div>
            </div>
            <div class="form-row">
                <div class="form-col" style="flex:0 0 100%">
                    <label>Drop-in path</label>
                    <span class="rsyslog-path"><?= $pd['st_dropin_path'] ?></span>
                </div>
            </div>
        </div>

        <?php if (!empty($pd['st_installed_note'])): ?>
        <p class="text-muted"><?= $pd['st_installed_note'] ?></p>
        <?php endif; ?>
    </div>

    <div class="rsyslog-status-card" style="margin-top:16px;">
        <button type="button" class="std-btn" data-js="rsyslog-refresh-status">Refresh status</button>
    </div>

<?php endif; ?>
