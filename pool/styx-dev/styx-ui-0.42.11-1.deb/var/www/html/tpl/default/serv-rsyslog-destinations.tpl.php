<?php
/**
 * Rsyslog fragment: Destinations.
 *
 * Echo-only; all derived values come from the formatter ($pd).
 * The card markup is rendered once here, by a closure used both for the stored
 * destinations and for the <template> that JS clones for a new one, so the two
 * can never drift apart.
 *
 * js: scripts/rsyslog/rsyslog.js
 */
$pd = $tdata['tpl_data'] ?? [];
$da = $pd['disabled_attr'] ?? 'disabled';

$renderCard = function (array $row) use ($pd, $da): string {
    ob_start(); ?>
    <div class="rsyslog-dest-card<?= !empty($row['is_active']) ? ' rsyslog-dest-card--active' : '' ?>" data-id="<?= $row['id_esc'] ?>">
        <div class="rsyslog-dest-head">
            <div class="rsyslog-dest-field rsyslog-dest-name-wrap">
                <label>Name</label>
                <input type="text" class="rsyslog-dest-name" maxlength="64" value="<?= $row['name_esc'] ?>" placeholder="otel-collector" <?= $da ?>>
            </div>
            <div class="rsyslog-dest-field rsyslog-dest-enabled-wrap">
                <label>Enabled</label>
                <label class="std-switch">
                    <input type="checkbox" class="rsyslog-dest-enabled" <?= $row['enabled_checked'] ?> <?= $da ?>>
                    <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                </label>
                <span class="std-badge <?= $row['enabled_badge'] ?> rsyslog-dest-state"><?= $row['enabled_text'] ?></span>
            </div>
            <div class="rsyslog-dest-actions">
                <button type="button" class="std-btn rsyslog-dest-remove" <?= $da ?>>Remove</button>
            </div>
        </div>

        <div class="rsyslog-dest-row">
            <div class="rsyslog-dest-field rsyslog-dest-host-wrap">
                <label>Host</label>
                <input type="text" class="rsyslog-dest-host" maxlength="255" value="<?= $row['host_esc'] ?>" placeholder="192.0.2.10 or collector.example" <?= $da ?>>
            </div>
            <div class="rsyslog-dest-field rsyslog-dest-port-wrap">
                <label>Port</label>
                <input type="number" class="rsyslog-dest-port" min="1" max="65535" step="1" value="<?= $row['port_val'] ?>" placeholder="<?= $row['port_placeholder'] ?>" <?= $da ?>>
            </div>
            <div class="rsyslog-dest-field">
                <label>Protocol</label>
                <select class="std-select rsyslog-dest-protocol" <?= $da ?>>
                    <?php foreach ($row['protocol_opts'] as $o): ?>
                    <option value="<?= $o['value'] ?>"<?= $o['selected'] ?>><?= $o['value'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="rsyslog-dest-field">
                <label>Framing (TCP)</label>
                <select class="std-select rsyslog-dest-framing" <?= $da ?>>
                    <?php foreach ($row['framing_opts'] as $o): ?>
                    <option value="<?= $o['value'] ?>"<?= $o['selected'] ?>><?= $o['value'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="rsyslog-dest-field">
                <label>Format</label>
                <select class="std-select rsyslog-dest-format" <?= $da ?>>
                    <?php foreach ($row['format_opts'] as $o): ?>
                    <option value="<?= $o['value'] ?>"<?= $o['selected'] ?>><?= $o['value'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <details class="rsyslog-dest-advanced">
            <summary>Advanced (message filter and queue)</summary>

            <div class="rsyslog-advanced-grid">
                <div class="rsyslog-dest-field">
                    <label>Facilities (none = all)</label>
                    <select class="std-select rsyslog-dest-facilities" multiple size="6" <?= $da ?>>
                        <?php foreach ($row['facility_opts'] as $o): ?>
                        <option value="<?= $o['value'] ?>"<?= $o['selected'] ?>><?= $o['value'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="rsyslog-dest-field rsyslog-dest-programs-wrap">
                    <label>Programs (one per line, empty = all)</label>
                    <textarea class="rsyslog-dest-programs" rows="6" placeholder="sshd&#10;kernel" <?= $da ?>><?= $row['programs_text'] ?></textarea>
                </div>
                <div class="rsyslog-dest-field">
                    <label>Severity</label>
                    <select class="std-select rsyslog-dest-severity" <?= $da ?>>
                        <?php foreach ($row['severity_opts'] as $o): ?>
                        <option value="<?= $o['value'] ?>"<?= $o['selected'] ?>><?= $o['value'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <h3>Queue</h3>
            <div class="rsyslog-advanced-grid">
                <div class="rsyslog-dest-field">
                    <label>Type</label>
                    <select class="std-select rsyslog-dest-qtype" <?= $da ?>>
                        <?php foreach ($row['queue_type_opts'] as $o): ?>
                        <option value="<?= $o['value'] ?>"<?= $o['selected'] ?>><?= $o['value'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="rsyslog-dest-field">
                    <label>Max disk space</label>
                    <input type="text" class="rsyslog-dest-qmaxdisk" value="<?= $row['max_disk_space_val'] ?>" placeholder="1g" <?= $da ?>>
                </div>
                <div class="rsyslog-dest-field rsyslog-dest-boolean">
                    <label>Save on shutdown</label>
                    <label class="std-switch">
                        <input type="checkbox" class="rsyslog-dest-qsave" <?= $row['save_on_shutdown_checked'] ?> <?= $da ?>>
                        <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                    </label>
                </div>
                <div class="rsyslog-dest-field">
                    <label>Resume retry count (-1 = forever)</label>
                    <input type="number" class="rsyslog-dest-qretry" step="1" value="<?= $row['resume_retry_count_val'] ?>" <?= $da ?>>
                </div>
                <div class="rsyslog-dest-field">
                    <label>High watermark</label>
                    <input type="number" class="rsyslog-dest-qhigh" min="0" step="1" value="<?= $row['high_watermark_val'] ?>" <?= $da ?>>
                </div>
                <div class="rsyslog-dest-field">
                    <label>Low watermark</label>
                    <input type="number" class="rsyslog-dest-qlow" min="0" step="1" value="<?= $row['low_watermark_val'] ?>" <?= $da ?>>
                </div>
            </div>
        </details>
    </div>
    <?php return ob_get_clean();
};
?>
<?php if (!empty($pd['cfg_settings_error'])): ?>
    <div class="std-error-box">
        <strong>Error:</strong> <?= $pd['cfg_settings_error'] ?>
    </div>
<?php else: ?>

    <div class="rsyslog-dest-section">
        <h2>Destinations</h2>
        <p class="text-muted">The list replaces the stored one entirely on save. Only one destination may be enabled at a time; the rest are kept ready but inactive.</p>

        <div id="rsyslog-destinations">
            <?php foreach (($pd['cfg_dest_rows'] ?? []) as $row): ?>
                <?= $renderCard($row) ?>
            <?php endforeach; ?>
        </div>

        <?php if (!empty($pd['cfg_dest_empty_note'])): ?>
        <p class="text-muted" id="rsyslog-dest-empty"><?= $pd['cfg_dest_empty_note'] ?></p>
        <?php endif; ?>

        <div class="form-row rsyslog-dest-add-row">
            <?= $pd['add_button_html'] ?? '' ?>
        </div>

        <div class="form-row rsyslog-dest-save-row">
            <?= $pd['buttons_html'] ?? '' ?>
        </div>

        <!-- Skeleton for JS-added destination cards (scripts/rsyslog/rsyslog.js
             clones this; values are assigned via DOM properties, never innerHTML). -->
        <template id="rsyslog-dest-tpl">
            <?= $renderCard($pd['cfg_new_row']) ?>
        </template>
    </div>

<?php endif; ?>
