<?php
/**
 * ServRsyslogFormatter - presentation helpers for the rsyslog service pane.
 *
 * Templates are echo-only: every derived text, badge class, selected/checked
 * token, attribute value and the action button HTML is computed here.
 *
 * Input (from PageServices):
 *   - settings        rsyslog.get_settings result: {settings, rsyslog_installed}
 *   - status          rsyslog.get_status result
 *   - settings_error  string|null   load error of rsyslog.get_settings
 *   - status_error    string|null   load error of rsyslog.get_status
 *   - load_error      string|null   permission / whole-page error
 *   - can_write       bool          has system:admin
 *
 * @see App\Controllers\PageServices
 * @see api/handlers/rsyslog.md
 */
namespace App\Pages\Fmt;

class ServRsyslogFormatter
{
    /** Facilities offered in the filter (without '*': empty list = all). */
    private const FACILITIES = [
        'auth', 'authpriv', 'cron', 'daemon', 'kern', 'lpr', 'mail', 'mark',
        'news', 'syslog', 'user', 'uucp',
        'local0', 'local1', 'local2', 'local3', 'local4', 'local5', 'local6', 'local7',
    ];

    private const SEVERITIES = ['*', 'emerg', 'alert', 'crit', 'err', 'warning', 'notice', 'info', 'debug'];

    private const PROTOCOLS = ['udp', 'tcp'];

    private const FRAMINGS = ['traditional', 'octet-counted'];

    private const FORMATS = ['rfc5424', 'rfc3164'];

    private const QUEUE_TYPES = ['LinkedList', 'FixedArray', 'Direct', 'Disk'];

    /** Backend defaults, mirrored so new rows start from a valid, known state. */
    private const QUEUE_DEFAULT = [
        'type'              => 'LinkedList',
        'max_disk_space'    => '1g',
        'save_on_shutdown'  => true,
        'resume_retry_count' => -1,
        'high_watermark'    => 8000,
        'low_watermark'     => 2000,
    ];

    private const DEFAULT_PORT = ['udp' => 514, 'tcp' => 6514];

    /**
     * @param array<string,mixed> $fmt_data
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $loadError = self::strOrNull($fmt_data['load_error'] ?? null);
        $canWrite  = !empty($fmt_data['can_write']);

        $fmt = [];
        $fmt['load_error'] = $loadError === null ? null : self::esc($loadError);
        $fmt['can_write']  = $canWrite;
        $fmt['disabled_attr'] = $canWrite ? '' : 'disabled';
        $fmt['buttons_html'] = $canWrite
            ? '<button type="button" class="std-btn" data-js="rsyslog-save">Save Destinations</button> '
                . '<button type="button" class="std-btn std-btn--secondary" data-js="rsyslog-discard">Discard Changes</button>'
            : '';
        $fmt['add_button_html'] = $canWrite
            ? '<button type="button" class="std-btn" data-js="rsyslog-add">Add destination</button>'
            : '';

        // ---------------- Status fragment (st_*) ----------------
        $status = is_array($fmt_data['status'] ?? null) ? $fmt_data['status'] : [];
        $fmt['st_load_error'] = self::escOrNull($fmt_data['status_error'] ?? null);

        $installed = !empty($status['rsyslog_installed']);
        $fmt['st_installed']      = $installed;
        $fmt['st_installed_text'] = $installed ? 'Installed' : 'Not installed';
        $fmt['st_installed_badge'] = $installed
            ? 'std-badge--success std-badge--dot'
            : 'std-badge--warning std-badge--dot';
        $fmt['st_installed_note'] = $installed
            ? null
            : self::esc('rsyslog is not installed on this host: destinations are stored but nothing is forwarded.');

        $active = !empty($status['rsyslog_active']);
        $fmt['st_active_text']  = $active ? 'Active' : 'Stopped';
        $fmt['st_active_badge'] = $active
            ? 'std-badge--success std-badge--dot'
            : 'std-badge--danger std-badge--dot';

        $dropin = !empty($status['dropin_present']);
        $fmt['st_dropin_text']  = $dropin ? 'Present' : 'Absent';
        $fmt['st_dropin_badge'] = $dropin
            ? 'std-badge--success std-badge--dot'
            : 'std-badge--info std-badge--dot';
        $fmt['st_dropin_path'] = self::esc($status['dropin_path'] ?? '');

        // ---------------- Destinations fragment (cfg_*) ----------------
        $env = is_array($fmt_data['settings'] ?? null) ? $fmt_data['settings'] : [];
        $settings = is_array($env['settings'] ?? null) ? $env['settings'] : [];
        $destinations = is_array($settings['destinations'] ?? null) ? $settings['destinations'] : [];

        $installedSettings = $env['rsyslog_installed'] ?? null;
        $fmt['cfg_installed'] = is_bool($installedSettings) ? $installedSettings : $installed;

        $fmt['cfg_settings_error'] = self::escOrNull($fmt_data['settings_error'] ?? null);

        $activeId = self::strOrNull($status['active_destination_id'] ?? null);

        $rows = [];
        foreach ($destinations as $dest) {
            if (!is_array($dest)) {
                continue;
            }
            $rows[] = self::buildRow($dest, $activeId);
        }
        $fmt['cfg_dest_rows'] = $rows;
        $fmt['cfg_dest_count'] = count($rows);
        $fmt['cfg_dest_empty_note'] = count($rows) === 0
            ? self::esc('No destinations yet. Add one to start forwarding the journal.')
            : null;

        $fmt['cfg_active_dest_label'] = self::activeDestLabel($destinations, $activeId);

        // Static defaults for a JS-added row (rendered into the <template>).
        $fmt['cfg_new_row'] = self::buildRow(self::defaultDestination(), null);

        return $fmt;
    }

    /**
     * Build one destination card's echo-ready values.
     *
     * @param array<string,mixed> $d
     * @return array<string,mixed>
     */
    private static function buildRow(array $d, ?string $activeId): array
    {
        $protocol = in_array($d['protocol'] ?? null, self::PROTOCOLS, true) ? $d['protocol'] : 'udp';
        $framing  = in_array($d['framing'] ?? null, self::FRAMINGS, true) ? $d['framing'] : 'traditional';
        $format   = in_array($d['format'] ?? null, self::FORMATS, true) ? $d['format'] : 'rfc5424';

        // Port: shown empty when it is the protocol default, so an untouched
        // field is omitted on save and the backend re-derives it (this is what
        // lets a protocol switch move the port to the new default).
        $port = $d['port'] ?? null;
        $portVal = (is_int($port) && $port !== self::DEFAULT_PORT[$protocol]) ? (string)$port : '';

        $filter = is_array($d['filter'] ?? null) ? $d['filter'] : [];
        $facilities = is_array($filter['facilities'] ?? null) ? $filter['facilities'] : [];
        $programs   = is_array($filter['programs'] ?? null) ? $filter['programs'] : [];
        $severity   = in_array($filter['severity'] ?? null, self::SEVERITIES, true) ? $filter['severity'] : '*';

        $queue = is_array($d['queue'] ?? null) ? $d['queue'] : [];
        $qType = in_array($queue['type'] ?? null, self::QUEUE_TYPES, true) ? $queue['type'] : 'LinkedList';

        $id = self::strOrNull($d['id'] ?? null);
        $enabled = !empty($d['enabled']);
        $isActive = $enabled && $activeId !== null && $id === $activeId;

        return [
            'id_esc'      => self::esc($id ?? ''),
            'name_esc'    => self::esc($d['name'] ?? ''),
            'host_esc'    => self::esc($d['host'] ?? ''),
            'port_val'    => self::esc($portVal),
            'port_placeholder' => (string)self::DEFAULT_PORT[$protocol],
            'enabled_checked'  => $enabled ? 'checked' : '',
            'enabled_text'     => $enabled ? 'Enabled' : 'Disabled',
            'enabled_badge'    => $enabled
                ? 'std-badge--success std-badge--dot'
                : 'std-badge--info std-badge--dot',
            'is_active'   => $isActive,

            'protocol_opts' => self::opts(self::PROTOCOLS, $protocol),
            'framing_opts'  => self::opts(self::FRAMINGS, $framing),
            'format_opts'   => self::opts(self::FORMATS, $format),
            'facility_opts' => self::multiOpts(self::FACILITIES, $facilities),
            'severity_opts' => self::opts(self::SEVERITIES, $severity),
            'programs_text' => self::esc(implode("\n", array_map('strval', $programs))),

            'queue_type_opts'      => self::opts(self::QUEUE_TYPES, $qType),
            'max_disk_space_val'   => self::esc($queue['max_disk_space'] ?? self::QUEUE_DEFAULT['max_disk_space']),
            'save_on_shutdown_checked' => !empty($queue['save_on_shutdown']) ? 'checked' : '',
            'resume_retry_count_val'   => self::numVal($queue['resume_retry_count'] ?? self::QUEUE_DEFAULT['resume_retry_count']),
            'high_watermark_val'       => self::numVal($queue['high_watermark'] ?? self::QUEUE_DEFAULT['high_watermark']),
            'low_watermark_val'        => self::numVal($queue['low_watermark'] ?? self::QUEUE_DEFAULT['low_watermark']),
        ];
    }

    /** A brand-new destination, with the backend's defaults. */
    private static function defaultDestination(): array
    {
        return [
            'id'       => '',
            'name'     => '',
            'enabled'  => false,
            'host'     => '',
            'port'     => self::DEFAULT_PORT['udp'],
            'protocol' => 'udp',
            'framing'  => 'traditional',
            'format'   => 'rfc5424',
            'filter'   => ['facilities' => [], 'programs' => [], 'severity' => '*'],
            'queue'    => self::QUEUE_DEFAULT,
        ];
    }

    /**
     * Selected token per option value (single-select).
     *
     * @param string[] $values
     * @return array<int,array{value:string, selected:string}>
     */
    private static function opts(array $values, string $current): array
    {
        $out = [];
        foreach ($values as $v) {
            $out[] = [
                'value'    => self::esc($v),
                'selected' => $v === $current ? ' selected' : '',
            ];
        }
        return $out;
    }

    /**
     * Selected token per option value (multi-select).
     *
     * @param string[] $values
     * @param array<int,mixed> $current
     * @return array<int,array{value:string, selected:string}>
     */
    private static function multiOpts(array $values, array $current): array
    {
        $set = array_flip(array_map('strval', $current));
        $out = [];
        foreach ($values as $v) {
            $out[] = [
                'value'    => self::esc($v),
                'selected' => isset($set[$v]) ? ' selected' : '',
            ];
        }
        return $out;
    }

    /**
     * Label of the destination that is currently applied, by name then id.
     *
     * @param array<int,mixed> $destinations
     */
    private static function activeDestLabel(array $destinations, ?string $activeId): string
    {
        if ($activeId === null) {
            return self::esc('None');
        }
        foreach ($destinations as $d) {
            if (!is_array($d) || ($d['id'] ?? null) !== $activeId) {
                continue;
            }
            $name = self::strOrNull($d['name'] ?? null);
            $host = self::strOrNull($d['host'] ?? null);
            if ($name !== null) {
                return self::esc($name);
            }
            if ($host !== null) {
                return self::esc($host);
            }
        }
        return self::esc($activeId);
    }

    private static function esc(mixed $v): string
    {
        return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    }

    private static function escOrNull(mixed $v): ?string
    {
        $s = self::strOrNull($v);
        return $s === null ? null : self::esc($s);
    }

    private static function strOrNull(mixed $v): ?string
    {
        return (is_string($v) && $v !== '') ? $v : null;
    }

    private static function numVal(mixed $v): string
    {
        return is_int($v) ? (string)$v : '';
    }
}
