<?php
/**
 * Rsyslog write path.
 *
 * Registered command (SubmitRegistry):
 *   rsyslog.set_settings -> setSettings()
 *
 * The payload is `{ destinations: [...] }`: the list replaces the stored one
 * wholesale (it is not a per-destination merge). The backend validates every
 * destination and returns a ready-to-show message, so nothing is type-checked
 * here beyond the envelope. The two cross-field rules and the "rsyslog not
 * installed" refusal are the backend's too and are surfaced unchanged.
 *
 * `tls` is deliberately not sent: it is reserved for phase 2 and the backend
 * normalizes its absence to `enabled:false`.
 */
namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class RsyslogSubmitController extends BaseController
{
    /**
     * Replace the destination list.
     *
     * @param array<string,mixed> $data request body (command/metadata are ignored)
     * @return array<string,mixed>
     */
    public function setSettings(array $data = []): array
    {
        $unknown = $this->unknownFields($data, ['destinations']);
        if (!empty($unknown)) {
            return $this->baseError('unknown field(s): ' . implode(', ', $unknown));
        }

        if (!array_key_exists('destinations', $data) || !is_array($data['destinations'])) {
            return $this->baseError("'destinations' must be a list");
        }

        // array_values() so an empty or non-sequential list still serializes as a
        // JSON array and not as an object.
        $payload = ['destinations' => array_values($data['destinations'])];

        $commands = [
            [
                'method' => 'rsyslog.set_settings',
                'id'     => 'set_settings',
                'data'   => (object)$payload,
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'set_settings');
    }
}
