<?php
/**
 * Rsyslog read path.
 *
 * Thin envelopes over the gateway rsyslog.get_settings / rsyslog.get_status
 * commands. Responses go through BaseController::singleCommand()
 * (canonical result.msg).
 *
 * Registered actions (RequestRegistry):
 *   rsyslog.get_settings -> getSettings()
 *   rsyslog.get_status   -> getStatus()
 *
 * getPageData() is NOT registered; PageServices calls it directly to assemble
 * the initial render in a single gateway round-trip.
 */
namespace App\Controllers\Request;

use App\Controllers\BaseController;

class RsyslogRequestController extends BaseController
{
    /**
     * The destination list plus whether this host can forward at all.
     *
     * @return array<string,mixed>
     */
    public function getSettings(): array
    {
        $commands = [
            [
                'method' => 'rsyslog.get_settings',
                'id'     => 'settings',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'settings');
    }

    /**
     * rsyslog presence, drop-in state and the active destination.
     *
     * @return array<string,mixed>
     */
    public function getStatus(): array
    {
        $commands = [
            [
                'method' => 'rsyslog.get_status',
                'id'     => 'status',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'status');
    }

    /**
     * Assemble settings + status for the page render in one round-trip.
     *
     * @return array{status:string, warnings:array, result:array}
     */
    public function getPageData(): array
    {
        $commands = [
            [
                'method' => 'rsyslog.get_settings',
                'id'     => 'settings',
                'data'   => (object)[],
            ],
            [
                'method' => 'rsyslog.get_status',
                'id'     => 'status',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));

        // Framework / access error (FORBIDDEN, gateway unreachable) - no commands
        // indexed. Surface the whole page as an error.
        if (($resp['status'] ?? '') !== 'success' && empty($resp['commands'])) {
            $msg = $resp['response_msg'] ?? 'Rsyslog load failed';
            return [
                'status'   => 'error',
                'warnings' => $resp['warnings'] ?? [],
                'result'   => [
                    'settings'       => [],
                    'status'         => [],
                    'settings_error' => $msg,
                    'status_error'   => $msg,
                ],
            ];
        }

        $cmds        = $resp['commands'];
        $settingsCmd = $cmds['settings'] ?? ['status' => 'error', 'result' => []];
        $statusCmd   = $cmds['status'] ?? ['status' => 'error', 'result' => []];

        return [
            'status'   => ($resp['status'] ?? '') === 'success' ? 'success' : 'partial',
            'warnings' => $resp['warnings'] ?? [],
            'result'   => [
                // result shapes: {settings, rsyslog_installed} and the status fields.
                'settings'       => $settingsCmd['result'] ?? [],
                'status'         => $statusCmd['result'] ?? [],
                'settings_error' => $settingsCmd['status'] === 'error'
                    ? ($settingsCmd['result']['msg'] ?? 'Rsyslog settings load failed')
                    : null,
                'status_error'   => $statusCmd['status'] === 'error'
                    ? ($statusCmd['result']['msg'] ?? 'Rsyslog status load failed')
                    : null,
            ],
        ];
    }
}
