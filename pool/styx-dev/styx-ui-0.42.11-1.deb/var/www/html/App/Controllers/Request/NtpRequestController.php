<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

/**
 * NTP (chrony) read path.
 *
 * Thin envelopes over the gateway ntp.get_config / ntp.get_status commands.
 * Responses go through BaseController::singleCommand() (canonical result.msg).
 *
 * Registered actions (RequestRegistry):
 *   ntp.get_config -> getConfig()
 *   ntp.get_status -> getStatus()
 *
 * getPageData() is NOT registered; PageServices calls it directly to assemble
 * the initial render in a single gateway round-trip.
 */
class NtpRequestController extends BaseController
{
    /**
     * Full NTP configuration (defaults merged).
     * @return array
     */
    public function getConfig(): array
    {
        $commands = [
            [
                'method' => 'ntp.get_config',
                'id'     => 'config',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'config');
    }

    /**
     * NTP runtime status.
     * @return array
     */
    public function getStatus(): array
    {
        $commands = [
            [
                'method' => 'ntp.get_status',
                'id'     => 'status',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $this->singleCommand($resp, 'status');
    }

    /**
     * Assemble config + status for the page render in one round-trip.
     *
     * @return array{status:string, warnings:array, result:array}
     */
    public function getPageData(): array
    {
        $commands = [
            [
                'method' => 'ntp.get_config',
                'id'     => 'config',
                'data'   => (object)[],
            ],
            [
                'method' => 'ntp.get_status',
                'id'     => 'status',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));

        // Framework / access error (FORBIDDEN, gateway unreachable) - no commands
        // indexed. Surface the whole page as an error (canonical result.msg).
        if (($resp['status'] ?? '') !== 'success' && empty($resp['commands'])) {
            $out = $this->baseError($resp['response_msg'] ?? 'NTP load failed');
            if (!empty($resp['error_code'])) {
                $out['error_code'] = $resp['error_code'];
            }
            return $out;
        }

        $cmds   = $resp['commands'];
        $cfgCmd = $cmds['config'] ?? ['status' => 'error', 'result' => []];
        $stCmd  = $cmds['status'] ?? ['status' => 'error', 'result' => []];

        // With per-command info available, PageServices should render the
        // specific config_error/status_error boxes even when both reads failed
        // (processGwResp would otherwise collapse them into a generic error).
        return [
            'status'   => ($resp['status'] ?? '') === 'success' ? 'success' : 'partial',
            'warnings' => $resp['warnings'] ?? [],
            'result'   => [
                'config'       => self::modelData($cfgCmd),
                'status'       => self::modelData($stCmd),
                'config_error' => $cfgCmd['status'] === 'error' ? ($cfgCmd['result']['msg'] ?? 'NTP config load failed') : null,
                'status_error' => $stCmd['status'] === 'error'  ? ($stCmd['result']['msg'] ?? 'NTP status load failed')  : null,
            ],
        ];
    }

    /**
     * The ntp backend appends a `msg` key to the result of get_config /
     * get_status. That key is a transport message, not part of the model -
     * strip it before it reaches templates / window.ntpConfig.
     *
     * @param array<string,mixed> $normalized a gateway command response
     * @return array<string,mixed>
     */
    private static function modelData(array $normalized): array
    {
        $data = $normalized['result'] ?? [];
        if (is_array($data)) {
            unset($data['msg']);
        }
        return $data;
    }
}
