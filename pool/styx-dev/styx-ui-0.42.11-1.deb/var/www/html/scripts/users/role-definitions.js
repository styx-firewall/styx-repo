document.addEventListener('DOMContentLoaded',()=>{const tmpl=document.getElementById('edit-role-tmpl');function gatherCaps(container){const checked=container.querySelectorAll('input[type="checkbox"]:checked');return Array.from(checked).map(cb=>cb.value);}
function preCheckCaps(container,caps){const capSet=new Set(caps);container.querySelectorAll('input[type="checkbox"]').forEach(cb=>{cb.checked=capSet.has(cb.value);});}
const createForm=document.querySelector('[data-js="create-role-form"]');if(createForm){createForm.addEventListener('submit',(e)=>{e.preventDefault();const form=e.target;const msgEl=document.getElementById('create-role-msg');const role=form.role.value.trim();if(!role){msgEl.textContent='Role name is required';return;}
const capabilities=gatherCaps(form);window.apiClient.submit('create_role',{role,capabilities}).then((resp)=>{if(resp.status==='error'){msgEl.textContent=resp.response_msg||'Error';return;}
location.reload();}).catch(()=>{msgEl.textContent='Request failed';});});}
document.addEventListener('click',(e)=>{const editBtn=e.target.closest('[data-js="edit-role-def"]');const deleteBtn=e.target.closest('[data-js="delete-role-def"]');const saveBtn=e.target.closest('[data-js="save-role-def"]');const cancelBtn=e.target.closest('[data-js="cancel-edit-role"]');if(editBtn){e.preventDefault();const role=editBtn.dataset.role;const row=document.querySelector(`[data-role-row="${role}"]`);if(!row||!tmpl){return;}
const existing=document.querySelector('.edit-row');if(existing){existing.remove();}
const clone=(tmpl.content.firstElementChild.cloneNode(true));clone.querySelector('legend').innerHTML=clone.querySelector('legend').innerHTML.replace('__ROLE__',role);let currentCaps=[];try{currentCaps=JSON.parse(editBtn.dataset.caps||'[]');}catch(_){}
preCheckCaps(clone,currentCaps);row.insertAdjacentElement('afterend',clone);}
if(saveBtn){e.preventDefault();const editRow=(saveBtn.closest('.edit-row'));const role=editRow.querySelector('legend').textContent.replace('Edit ','').trim();const capabilities=gatherCaps(editRow);window.apiClient.submit('update_role',{role,capabilities}).then((resp)=>{if(resp.status==='error'){alert(resp.response_msg||'Error updating role');return;}
location.reload();}).catch(()=>{alert('Request failed');});}
if(cancelBtn){e.preventDefault();const editRow=cancelBtn.closest('.edit-row');if(editRow){editRow.remove();}}
if(deleteBtn){e.preventDefault();const role=deleteBtn.dataset.role;if(!confirm(`Delete role "${role}"?`)){return;}
window.apiClient.submit('delete_role',{role}).then((resp)=>{if(resp.status==='error'){alert(resp.response_msg||'Error deleting role');return;}
location.reload();}).catch(()=>{alert('Request failed');});}});});