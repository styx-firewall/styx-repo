class LogTable{constructor({tableId,columns,onRowClick,rowClass}){this.table=document.getElementById(tableId);this.columns=columns;this.onRowClick=onRowClick;this.rowClass=rowClass;this.selectedRowId=null;this.rows=new Map();this.renderHeader();}
renderHeader(){if(this.table.querySelector('thead'))return;const thead=document.createElement('thead');const tr=document.createElement('tr');this.columns.forEach(col=>{const th=document.createElement('th');th.textContent=col.label;if(col.visible===false){th.style.display='none';}
tr.appendChild(th);});thead.appendChild(tr);this.table.appendChild(thead);if(!this.table.querySelector('tbody')){this.table.appendChild(document.createElement('tbody'));}}
addRows(logs,highlightNew=false){logs.forEach(log=>this.addRow(log,highlightNew));const tbody=this.table.querySelector('tbody');const maxRows=window.currentLimit||200;while(tbody.children.length>maxRows){tbody.removeChild(tbody.lastChild);}}
addRow(log,highlightNew=false){const tbody=this.table.querySelector('tbody');const tr=document.createElement('tr');if(typeof this.rowClass==='function'){const cls=this.rowClass(log);if(cls)tr.classList.add(cls);}
if(highlightNew){tr.classList.add('log-row-new');}
this.columns.forEach(col=>{const td=document.createElement('td');const raw=log[col.key]??'';const rendered=(typeof col.render==='function')?col.render(raw,log):raw;try{if(rendered instanceof Node){td.appendChild(rendered);}else if(col.html===true&&typeof rendered==='string'){td.innerHTML=rendered;}else{td.textContent=rendered;}}catch(e){td.textContent=String(rendered);}
if(col.visible===false){td.style.display='none';}
tr.appendChild(td);});if(typeof this.onRowClick==='function'){tr.addEventListener('click',()=>{this.onRowClick(log);});tr.style.cursor='pointer';}
tbody.insertBefore(tr,tbody.firstChild);}
updateRow(uuid,newData){if(!this.rows.has(uuid))return;this.rows.set(uuid,newData);const tbody=this.table.querySelector('tbody');const tr=tbody.querySelector(`tr[data-uuid='${uuid}']`);if(tr){this.columns.forEach((col,idx)=>{if(col.visible!==false){tr.children[idx].textContent=newData[col.key]??'';}});}}
removeRow(uuid){this.rows.delete(uuid);const tbody=this.table.querySelector('tbody');const tr=tbody.querySelector(`tr[data-uuid='${uuid}']`);if(tr)tbody.removeChild(tr);}
clearRows(){this.rows.clear();const tbody=this.table.querySelector('tbody');tbody.innerHTML='';}
selectRow(uuid){const tbody=this.table.querySelector('tbody');Array.from(tbody.children).forEach(tr=>tr.classList.remove('selected-row'));const tr=tbody.querySelector(`tr[data-uuid='${uuid}']`);if(tr)tr.classList.add('selected-row');this.selectedRowId=uuid;}
getSelectedRow(){return this.rows.get(this.selectedRowId);}
getAllRows(){return Array.from(this.rows.values());}}
window.LogTable=LogTable;