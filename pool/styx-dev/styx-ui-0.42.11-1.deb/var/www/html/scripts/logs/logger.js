class Logger{constructor(options={}){this.endpoint=options.endpoint||'/api/log';this.defaultLevel=options.defaultLevel||'info';this.buffer=[];this.flushInterval=options.flushInterval||5000;this.maxBuffer=options.maxBuffer||10;this.timer=null;this.enabled=true;this.init();}
init(){this.timer=setInterval(()=>this.flush(),this.flushInterval);window.addEventListener('beforeunload',()=>this.flush(true));}
log({level,message,context={},stack='',timestamp=null}){if(!this.enabled)return;const entry={level:level||this.defaultLevel,message,context,stack,timestamp:timestamp||new Date().toISOString()};this.buffer.push(entry);if(this.buffer.length>=this.maxBuffer){this.flush();}}
info(message,context={}){this.log({level:'info',message,context});}
warn(message,context={}){this.log({level:'warn',message,context});}
error(message,context={},stack=''){this.log({level:'error',message,context,stack});}
debug(message,context={}){this.log({level:'debug',message,context});}
async flush(force=false){if(!this.enabled||this.buffer.length===0)return;const logsToSend=this.buffer.splice(0,this.buffer.length);try{await apiClient.postJson(this.endpoint,logsToSend.length===1?logsToSend[0]:logsToSend);}catch(e){if(!force)this.buffer.unshift(...logsToSend);}}
disable(){this.enabled=false;clearInterval(this.timer);}
enable(){if(!this.enabled){this.enabled=true;this.init();}}}