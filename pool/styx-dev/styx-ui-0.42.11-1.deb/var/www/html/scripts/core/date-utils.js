(function(window){'use strict';function getCookie(name){var parts=document.cookie.split(';');for(var i=0;i<parts.length;i++){var part=parts[i].trim();if(part.indexOf(name+'=')===0){return decodeURIComponent(part.substring(name.length+1));}}
return null;}
function getUserTz(){var meta=document.querySelector('meta[name="app-tz"]');if(meta){return meta.getAttribute('content')||'UTC';}
return getCookie('tz')||'UTC';}
function getUserLocale(){var meta=document.querySelector('meta[name="app-locale"]');if(meta){return meta.getAttribute('content')||'en-US';}
return getCookie('tz_locale')||'en-US';}
function isExplicitlyNonUtc(str){if(typeof str!=='string')return false;var trimmed=str.trim();if(/Z$|[+]00:00$/i.test(trimmed))return false;return/[+\-]\d{2}:\d{2}$/.test(trimmed);}
function formatTimestamp(ts,opts){var num=typeof ts==='string'?Number(ts):ts;if(isNaN(num)||!num)return'';var ms;if(num>1e13){ms=Math.floor(num/1000);}else if(num>1e10){ms=num;}else{ms=num*1000;}
return _formatMs(ms,opts);}
function formatString(str,opts){if(!str)return'';if(isExplicitlyNonUtc(str)){if(typeof appLog!=='undefined'){appLog.warn('[date-utils] Non-UTC date string from backend: '+str);}}
var normalized=str.trim();if(/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}$/.test(normalized)){normalized=normalized.replace(' ','T')+'Z';}
var d=new Date(normalized);if(isNaN(d.getTime()))return str;return _formatMs(d.getTime(),opts);}
function _formatMs(ms,opts){opts=opts||{};var tz=opts.tz||getUserTz();var locale=opts.locale||getUserLocale();try{return new Intl.DateTimeFormat(locale,{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(new Date(ms));}catch(e){var d=new Date(ms);if(isNaN(d.getTime()))return'';var pad=function(n){return String(n).padStart(2,'0');};return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+' '+pad(d.getHours())+':'+pad(d.getMinutes())+':'+pad(d.getSeconds());}}
function formatShortTime(ts,opts){opts=opts||{};var num=typeof ts==='string'?Number(ts):ts;var ms;if(isFinite(num)){ms=num>1e13?Math.floor(num/1000):(num>1e10?num:num*1000);}else{ms=Date.parse(String(ts));}
if(!isFinite(ms)||isNaN(ms))return'';var tz=opts.tz||getUserTz();var locale=opts.locale||getUserLocale();var fmtOpts={timeZone:tz,hour:'2-digit',minute:'2-digit',hour12:false};if(opts.includeSeconds)fmtOpts.second='2-digit';try{return new Intl.DateTimeFormat(locale,fmtOpts).format(new Date(ms));}catch(e){var d=new Date(ms);if(isNaN(d.getTime()))return'';var pad=function(n){return String(n).padStart(2,'0');};var res=pad(d.getHours())+':'+pad(d.getMinutes());if(opts.includeSeconds)res+=':'+pad(d.getSeconds());return res;}}
window.dateUtils={formatTimestamp:formatTimestamp,formatString:formatString,isExplicitlyNonUtc:isExplicitlyNonUtc,getUserTz:getUserTz,getUserLocale:getUserLocale,formatShortTime:formatShortTime};})(window);