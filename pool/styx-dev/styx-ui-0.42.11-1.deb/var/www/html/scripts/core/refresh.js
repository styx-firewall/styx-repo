import{sendRefreshRequest}from'../refresh/refreshDispatcher.js';function init(){sendRefreshRequest();setInterval(sendRefreshRequest,20*1000);}
document.addEventListener('DOMContentLoaded',init);