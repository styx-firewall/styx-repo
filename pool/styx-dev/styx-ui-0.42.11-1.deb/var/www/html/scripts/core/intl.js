(function(){'use strict';var COOKIE_NAME='tz';var LOCALE_COOKIE_NAME='tz_locale';var COOKIE_DAYS=365;function getCookie(name){var parts=document.cookie.split(';').map(function(p){return p.trim();});for(var i=0;i<parts.length;i++){if(parts[i].indexOf(name+'=')===0){return decodeURIComponent(parts[i].substring(name.length+1));}}
return null;}
function setCookie(name,value,days){var expires='';if(typeof days==='number'){var date=new Date();date.setTime(date.getTime()+days*24*60*60*1000);expires='; expires='+date.toUTCString();}
var secure=location.protocol==='https:'?'; Secure':'';var sameSite='; SameSite=Lax';var cookieValue;if(name===COOKIE_NAME||name===LOCALE_COOKIE_NAME){var raw=String(value);if(/^[A-Za-z0-9_\/-]+$/.test(raw)){cookieValue=raw;}else{cookieValue=encodeURIComponent(raw);}}else{cookieValue=encodeURIComponent(value);}
document.cookie=name+'='+cookieValue+expires+'; path=/'+sameSite+secure;}
function detectTimezone(){try{if(typeof Intl!=='undefined'&&Intl.DateTimeFormat){var tz=Intl.DateTimeFormat().resolvedOptions().timeZone;if(tz)return tz;}}catch(e){}
return null;}
function detectLocale(){try{if(typeof Intl!=='undefined'&&Intl.DateTimeFormat){var locale=Intl.DateTimeFormat().resolvedOptions().locale;if(locale)return locale;}}catch(e){}
try{if(navigator&&navigator.languages&&navigator.languages.length)return navigator.languages[0];if(navigator&&navigator.language)return navigator.language;}catch(e){}
return null;}
function init(){try{try{if(!getCookie(COOKIE_NAME)){var tz=detectTimezone();if(!tz)tz='UTC';setCookie(COOKIE_NAME,tz,COOKIE_DAYS);}}catch(e){try{setCookie(COOKIE_NAME,'UTC',COOKIE_DAYS);}catch(ignore){}}
try{if(!getCookie(LOCALE_COOKIE_NAME)){var locale=detectLocale();if(!locale)locale='en-US';setCookie(LOCALE_COOKIE_NAME,locale,COOKIE_DAYS);}}catch(e){}}catch(e){try{setCookie(COOKIE_NAME,'UTC',COOKIE_DAYS);}catch(ignore){}}}
if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',init);}else{init();}})();