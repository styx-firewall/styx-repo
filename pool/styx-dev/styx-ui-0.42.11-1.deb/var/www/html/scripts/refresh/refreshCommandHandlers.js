import{getUrlParams}from'./utils.js';import{updateGatewayLed}from'./gatewayLed.js';import{updateLoadLed}from'./loadLed.js';import{updateTasks}from'./updateTasks.js';import{updatePeriodicTasks}from'./updatePeriodicTasks.js';import{updateNotifications}from'./updateNotifications.js';function getAppVersion(){const meta=document.querySelector('meta[name="app-version"]');return meta?meta.content:'0';}
export const refreshCommandHandlers=[async function(cmd){const params=getUrlParams();if(cmd.method==='gateway-daemon.ping'){updateGatewayLed(cmd);updateLoadLed(cmd);if(cmd.result&&cmd.result.tasks){updateTasks(cmd.result.tasks);const taskIds=Object.keys(cmd.result.tasks);if(taskIds.length>0){window.lastTaskId=taskIds[taskIds.length-1];}
if(!window.pendingTaskIds){window.pendingTaskIds=[];}
const stillPending=[];const noLongerPending=[];for(const[id,rawTask]of Object.entries(cmd.result.tasks)){let task;if(rawTask&&rawTask.task_info){task=rawTask.task_info;}else{task=rawTask;}
let status='unknown';if(task&&typeof task.status==='string'&&task.status.trim().length>0){status=task.status;}
if(status==='pending'){stillPending.push(id);}else{noLongerPending.push(id);}}
const keepMissing=window.pendingTaskIds.filter(id=>!(id in cmd.result.tasks));window.pendingTaskIds=[...stillPending,...keepMissing];}
if(cmd.result&&cmd.result.notifications){updateNotifications(cmd.result.notifications);}
if(cmd.result&&cmd.result.periodic_tasks){updatePeriodicTasks(cmd.result.periodic_tasks);}}
if(cmd.method==='system-overview.get_system_info'){const mod=await import('./systemOverview.js?v='+getAppVersion());mod.getSystemOverview(cmd);}}];