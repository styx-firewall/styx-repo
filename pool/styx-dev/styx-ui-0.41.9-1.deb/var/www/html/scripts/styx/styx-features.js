document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('input[type=checkbox][data-feature-key]').forEach(function(chk) {
        var key = chk.getAttribute('data-feature-key');
        var fieldset = document.getElementById(key + '_fieldset');
        if (fieldset) {
            function toggleBlock() { fieldset.classList.toggle('hidden', !chk.checked); }
            chk.addEventListener('change', toggleBlock);
            toggleBlock();
        }
    });
    document.querySelectorAll('.feature-label').forEach(function(lbl) {
        // Remove modal show event for main features
        lbl.removeEventListener('click', function(){});
    });
    document.querySelectorAll('.feature-option-label').forEach(function(lbl) {
        lbl.addEventListener('click', function(e) {
            var input = lbl.querySelector('input');
            if (!input || input.disabled) return;
            e.preventDefault();
            var featureKey = lbl.getAttribute('data-feature-key');
            var optionKey = lbl.getAttribute('data-option-key');
            // The template injects the sections of the features page as a list
            // (see StyxFeaturesFormatter::format). Use it as the source for the
            // labels, descriptions and packages instead of scraping the DOM.
            var sections = Array.isArray(window.styxFeaturesData) ? window.styxFeaturesData : [];
            var section = sections.find(s => s.key === featureKey);
            if (!section) return;
            var opt = (section.options || []).find(o => o.key === optionKey);
            var isActivating = !input.checked;
            var html = `<h2>${section.name} - ${opt ? opt.name : ''}</h2>`;

            html += `<div style='margin-bottom:1em;'>${opt && opt.description ? opt.description : ''}</div>`;
            var packages = (opt && opt.packages) || [];
            if (packages.length > 0) {
                html += '<strong>Packages:</strong><ul style="margin-top:0.5em;">';
                packages.forEach(function(pkg) {
                    html += `<li>${pkg}</li>`;
                });
                html += '</ul>';
            }
            var sharedPackages = (opt && opt.packages_shared) || [];
            if (sharedPackages.length > 0) {
                html += '<strong>Shared packages:</strong><ul style="margin-top:0.5em;">';
                sharedPackages.forEach(function(pkg) {
                    html += `<li>${pkg}</li>`;
                });
                html += '</ul>';
            }
            html += `<div style='margin:1em 0;font-weight:bold;'>` +
                `Are you sure you want to ${isActivating ? 'activate' : 'deactivate'} this option?` +
                `</div>`;
            html += `<button id='feature-apply-btn' style='padding:0.5em 1.5em;font-size:1em;'>Apply</button>`;
            document.getElementById('feature-info-content').innerHTML = html;
            document.getElementById('feature-info-modal').style.display = 'flex';

            // Restore listener (in case modal is closed)
            var closeBtn = document.querySelector('#feature-info-modal button');
            if (closeBtn) {
                if (closeBtn._restoreSwitchListener) {
                    closeBtn.removeEventListener('click', closeBtn._restoreSwitchListener);
                }
                var restoreSwitch = function() {
                    document.getElementById('feature-info-modal').style.display = 'none';
                    closeBtn.removeEventListener('click', restoreSwitch);
                    closeBtn._restoreSwitchListener = null;
                };
                closeBtn.addEventListener('click', restoreSwitch);
                closeBtn._restoreSwitchListener = restoreSwitch;
            }

            // Apply button
            setTimeout(function() {
                var btn = document.getElementById('feature-apply-btn');
                if (btn) {
                    btn.onclick = function() {
                        console.log('[FEATURES] Apply clicked, sending:', { featureKey, optionKey, isActivating });
                        btn.disabled = true;
                        btn.textContent = 'Applying...';
                        apiClient.submit('set_enable_feature', {
                            feature_key: featureKey,
                            option_key: optionKey,
                            enabled: isActivating
                        })
                        .then(data => {
                            console.log('[FEATURES] submit response data:', JSON.stringify(data));
                            let msg = (data && data.response_msg) || 'Invalid server response';
                            console.log('[FEATURES] msg:', msg);
                            btn.textContent = 'Apply';
                            btn.disabled = false;
                            let success = data && (data.status === 'success' || (data.result && data.result.success));
                            console.log('[FEATURES] data.status:', data && data.status);
                            console.log('[FEATURES] data.result:', data && data.result);
                            console.log('[FEATURES] success:', success);
                            let msgClass = success ? 'success' : 'error';
                            document.getElementById('feature-info-content').innerHTML +=
                                `<div style='margin-top:1em;font-weight:bold;color:${success ? 'inherit' : '#cc0000'};' data-status="${msgClass}">${msg}</div>`;
                            if (success) {
                                input.checked = isActivating;
                                var event = new Event('change', { bubbles: true });
                                input.dispatchEvent(event);
                                // If applied, remove the restore listener and close the modal
                                var closeBtn = document.querySelector('#feature-info-modal button');
                                if (closeBtn && closeBtn._restoreSwitchListener) {
                                    closeBtn.removeEventListener('click', closeBtn._restoreSwitchListener);
                                    closeBtn._restoreSwitchListener = null;
                                }
                                document.getElementById('feature-info-modal').style.display = 'none';
                            }
                        })
                        .catch(err => {
                            console.error('[FEATURES] .catch triggered:', err);
                            btn.textContent = 'Apply';
                            btn.disabled = false;
                            document.getElementById('feature-info-content').innerHTML +=
                                `<div style='margin-top:1em;font-weight:bold;color:#cc0000;'>Request failed: ${err.message || err}</div>`;
                        });
                    }
                }
            }, 100);
        });
    });
});
