// Modal and user actions for create/edit/delete/lock/unlock
document.addEventListener('DOMContentLoaded', function () {
    var btn = document.getElementById('addUserBtn');

    function buildUserForm(user, isEdit) {
        var tmpl = document.getElementById('tmpl-user-form');
        if (!tmpl) return null;
        var frag = tmpl.content.cloneNode(true);

        frag.querySelector('[data-js="user-form-title"]').textContent =
            isEdit ? 'Edit Linux user' : 'Create Linux user';

        var usernameEl = frag.querySelector('[name="username"]');
        if (usernameEl) {
            usernameEl.value = user.username || '';
            if (isEdit) usernameEl.setAttribute('readonly', '');
        }

        var gecosEl = frag.querySelector('[name="gecos"]');
        if (gecosEl) gecosEl.value = user.gecos || '';

        var passEl = frag.querySelector('[name="password"]');
        if (passEl && !isEdit) passEl.setAttribute('required', '');
        if (passEl && isEdit) passEl.removeAttribute('required');

        var nologinEl = frag.querySelector('[name="nologin"]');
        if (nologinEl) nologinEl.checked = (user.shell === '/usr/sbin/nologin');

        var submitBtn = frag.querySelector('[data-js="user-form-submit"]');
        submitBtn.textContent = isEdit ? 'Save changes' : 'Create user';
        submitBtn.setAttribute('data-mode', isEdit ? 'edit' : 'create');

        return frag;
    }

    // Open modal for create
    if (btn) {
        btn.onclick = function () {
            var frag = buildUserForm({}, false);
            if (!frag) return;
            showModal(frag, {
                onClose: function () { /* noop */ },
                boxStyle: { background: '#181a1b', color: '#e3e6eb', width: '340px', margin: 'auto', display: 'block' }
            });
            setTimeout(bindFormEvents, 100);
        };
    }

    function bindFormEvents() {
        var form = document.getElementById('userForm');
        if (!form) return;
        form.onsubmit = function (e) {
            e.preventDefault();
            var data = {
                username: form.username.value.trim(),
                gecos: form.gecos.value.trim(),
                nologin: form.nologin.checked ? 1 : 0,
                groups: Array.from(form.groups.selectedOptions).map(function (opt) { return opt.value; })
            };
            var submitBtn = form.querySelector('[data-js="user-form-submit"]');
            var isEdit = submitBtn && submitBtn.getAttribute('data-mode') === 'edit';
            if (!isEdit) {
                data.password = form.password.value;
            } else {
                if (form.password.value) data.password = form.password.value;
            }
            var payload = Object.assign({}, data, { command: isEdit ? 'edit_user' : 'add_user' });
            apiClient.submit(payload.command, payload)
                .then(function (resp) {
                    showApiResult(resp, { closeText: 'Close', reloadOnOk: true, boxStyle: { margin: 'auto', display: 'block' } });
                })
                .catch(function () {
                    showApiResult({ status: 'error', response_msg: 'Connection error.' }, { title: 'Error', closeText: 'Close' });
                });
            hideModal();
        };
    }

    // Edit user button
    var editButtons = document.querySelectorAll('button[data-edit-user]');
    editButtons.forEach(function (editBtn) {
        editBtn.onclick = function () {
            var user = null;
            try {
                user = JSON.parse(this.getAttribute('data-edit-user'));
            } catch (e) { user = null; }
            if (!user || !user.username) {
                showModal('<p>Could not get user identifier.</p>', { boxStyle: { margin: 'auto', display: 'block' } });
                return;
            }
            apiClient.request('get_user_info', { module: 'user-mgmt', username: user.username })
                .then(function (data) {
                    if (data.status === 'success' && data.result) {
                        var u = data.result;
                        var frag = buildUserForm(u, true);
                        if (!frag) return;
                        showModal(frag, {
                            onClose: function () { /* noop */ },
                            boxStyle: { background: '#181a1b', color: '#e3e6eb', width: '340px', margin: 'auto', display: 'block' }
                        });
                        setTimeout(bindFormEvents, 100);
                    } else {
                        showModal('<p>Could not get user data.</p>', { boxStyle: { margin: 'auto', display: 'block' } });
                    }
                })
                .catch(function () {
                    showModal('<p>Connection error while getting user data.</p>', { boxStyle: { margin: 'auto', display: 'block' } });
                });
        };
    });

    // Delete user button
    var deleteButtons = document.querySelectorAll('button[data-delete-user]');
    deleteButtons.forEach(function (delBtn) {
        delBtn.onclick = function () {
            var tr = delBtn.closest('tr');
            var username = tr && tr.querySelector('td') ? tr.querySelector('td').textContent.trim() : null;
            if (!username) return;
            showModal(
                '<p>Delete user <b>' + username + '</b>?</p>' +
                '<div style="margin-top:1em;">' +
                    '<button id="confirmDelUser" class="std-btn">Delete</button> ' +
                    '<button id="cancelDelUser" class="std-btn">Cancel</button>' +
                '</div>',
                { boxStyle: { margin: 'auto', display: 'block' } }
            );
            setTimeout(function () {
                var confirmBtn = document.getElementById('confirmDelUser');
                var cancelBtn = document.getElementById('cancelDelUser');
                if (confirmBtn) {
                    confirmBtn.onclick = function () {
                        apiClient.submit('delete_user', { username: username })
                            .then(function (resp) {
                                showApiResult(resp, { closeText: 'Close', reloadOnOk: true, boxStyle: { margin: 'auto', display: 'block' } });
                            })
                            .catch(function () {
                                showApiResult({ status: 'error', response_msg: 'Connection error.' }, { title: 'Error', closeText: 'Close' });
                            });
                    };
                }
                if (cancelBtn) cancelBtn.onclick = hideModal;
            }, 100);
        };
    });

    // Lock/Unlock user button
    var lockButtons = Array.from(document.querySelectorAll('button'))
        .filter(function (b) {
            return b.title && (b.title.indexOf('Lock') !== -1 || b.title.indexOf('Unlock') !== -1);
        });
    lockButtons.forEach(function (lockBtn) {
        lockBtn.onclick = function () {
            var tr = lockBtn.closest('tr');
            var username = tr && tr.querySelector('td') ? tr.querySelector('td').textContent.trim() : null;
            if (!username) return;
            var isLocked = lockBtn.getAttribute('data-locked') === '1';
            var cmd = isLocked ? 'unlock_user' : 'lock_user';
            apiClient.submit(cmd, { username: username })
                .then(function (resp) {
                    showModal(
                        '<p>' + (resp.response_msg || (isLocked ? 'User unlocked.' : 'User locked.')) + '</p>',
                        {
                            onClose: function () { if (resp.status === 'success') location.reload(); },
                            boxStyle: { margin: 'auto', display: 'block' }
                        }
                    );
                })
                .catch(function () {
                    showModal('<p>Connection error.</p>', { boxStyle: { margin: 'auto', display: 'block' } });
                });
        };
    });
});
