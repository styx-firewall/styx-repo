/**
 * Painter for the scheduled-tasks table in the fixed TASKS panel.
 *
 * Deliberately separate from updateTasks.js: that one keeps the whole payload on its tbody
 * (`tbody._currentTasks = tasks`) for the Details modal, so feeding it a second data set
 * would clobber the activity rows. Different tbody, different renderer.
 *
 * The data is the `periodic_tasks` snapshot that travels in `gateway-daemon.ping`: one row
 * per registered task -- not per execution -- already ordered by group and name.
 */

// Small copies of the helpers in updateTasks.js, which does not export them.
function formatTime(t) {
    if (!t) return '';
    const match = t.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/);
    return match ? match[0].replace('T', ' ') : t;
}

function createCell(val, className) {
    const td = document.createElement('td');
    if (className) td.className = className;
    td.textContent = val ?? '';
    return td;
}

/** State of the last run, with the skip count when the task could not keep up. */
function stateText(task) {
    let state;
    if (task.state === 'running') {
        state = 'running';
    } else if (task.overdue) {
        state = 'overdue';
    } else if (task.last_status) {
        state = task.last_status;
    } else {
        state = 'idle';
    }
    if (task.enabled === false) state += ' (disabled)';
    const skipped = Number(task.skipped) || 0;
    if (skipped > 0) state += ` (${skipped} skipped)`;
    return state;
}

function durationText(ms) {
    if (ms === null || ms === undefined) return '';
    return ms >= 1000 ? (ms / 1000).toFixed(2) + ' s' : ms + ' ms';
}

export function updatePeriodicTasks(tasks) {
    if (!Array.isArray(tasks)) return;
    const tbody = document.getElementById('periodic-tasks-tbody');
    if (!tbody) return;

    const seen = new Set();

    tasks.forEach(task => {
        if (!task || typeof task !== 'object') return;
        const key = task.key || `${task.group}:${task.name}`;
        seen.add(key);

        let row = tbody.querySelector(`tr[data-ptask-key="${key}"]`);
        if (!row) {
            row = document.createElement('tr');
            row.setAttribute('data-ptask-key', key);
        }

        const cells = [
            createCell(task.group ?? '', 'task-td'),
            createCell(task.name ?? '', 'task-td'),
            createCell(task.interval_label ?? '', 'task-td'),
            createCell(stateText(task), 'task-td'),
            createCell(formatTime(task.last_end ?? task.last_start ?? ''), 'task-td'),
            createCell(durationText(task.last_duration_ms), 'task-td'),
            createCell(String(task.runs ?? 0), 'task-td'),
            createCell(String(task.failures ?? 0), 'task-td'),
            createCell(formatTime(task.next_run ?? ''), 'task-td'),
        ];

        const msgCell = document.createElement('td');
        msgCell.className = 'task-td';
        msgCell.textContent = task.last_error ?? '';
        if (task.last_error) msgCell.title = task.last_error;
        cells.push(msgCell);

        row.replaceChildren(...cells);
        // Always append: appending an existing row moves it, which keeps the table in the
        // payload's order (group, then name) instead of leaving new tasks at the end.
        tbody.appendChild(row);
    });

    // Drop rows for tasks that are gone: a feature disabled, a monitor removed.
    tbody.querySelectorAll('tr[data-ptask-key]').forEach(row => {
        if (!seen.has(row.getAttribute('data-ptask-key'))) row.remove();
    });
}
