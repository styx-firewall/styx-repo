// web-filter.js
// Content filter: what the web filter does with the shared policy.
//
//   save   -> apiClient.submit('web-filter.set_settings', payload)
//   switch -> apiClient.submit('web-filter.set_active', {active: bool})
//
// Which categories are blocked is not decided here: that is the catalogue's
// (categories.set_posture), because the DNS filter cuts first and a divergent
// web filter would only be heard on the flows DNS did not see. What this pane
// saves is how a blocked flow is cut and which categories derive a DSCP.
//
// Saving APPLIES: the gateway regenerates the nft rules and repoints the running
// engine before answering, so an error can mean the settings were stored but
// could not be put in force. result.msg says which, and showApiResult() reads
// exactly that - the page is only reloaded on success, so a failure leaves the
// form the operator just filled in on screen.
//
// Flags come from the DOM: the page is rendered by the backend, so the render
// already knows whether this user may write.

/** Said where the operator reads the result, when the reload was skipped. */
const UNSAVED_SWITCH_NOTE = 'This card still shows the state from before the switch: your unsaved edits are in '
    + 'the form, so the page was not reloaded. Save them (or reload) to see the state in force.';

document.addEventListener('DOMContentLoaded', () => {
    const root = document.querySelector('.cf-page');
    if (!root || root.dataset.canEdit !== '1') return;
    // What the server rendered, as a string to compare against: the switch must not
    // reload the page on top of edits its own call did not save.
    const rendered = policyKey(root);
    bindSave(root);
    bindSwitch(root, rendered);
});

/**
 * The form's payload as one string, to tell an edited form from an untouched one.
 *
 * Built by the same function the save sends, so what is compared is what would be
 * written - and a field the operator touched and put back reads as untouched, which
 * is what it is.
 */
function policyKey(root) {
    return JSON.stringify(buildWebPolicy(root));
}

/**
 * Build this filter's settings from the form.
 *
 * No `posture`: what is blocked is the catalogue's decision, and the backend
 * refuses a posture sent here rather than accepting a change that will not
 * happen. `dscp` is replaced wholesale, so the complete map is sent - a category
 * with no entry means "no marking", and leaving one out would silently reset it.
 */
function buildWebPolicy(root) {
    const dscp = {};

    document.querySelectorAll('.cf-dscp').forEach((input) => {
        const category = input.getAttribute('data-category') || '';
        const value = input.value.trim();
        if (category === '' || value === '') return;
        dscp[category] = value;
    });

    const modeEl = document.getElementById('cf-block-mode');
    return {
        dscp,
        // The select is always rendered next to the Save button; data-block-mode
        // is what the backend says is in force, used only if it is not there.
        block_mode: modeEl ? modeEl.value : (root.dataset.blockMode || 'reject'),
    };
}

function bindSave(root) {
    const btn = document.querySelector('[data-js="cf-save-web"]');
    if (!btn) return;

    btn.addEventListener('click', async () => {
        try {
            const result = await apiClient.submit('web-filter.set_settings', buildWebPolicy(root));
            showApiResult(result, { title: 'Web Filter', closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult(
                { status: 'error', result: { msg: err.message } },
                { title: 'Web Filter', closeText: 'Close' }
            );
        }
    });
}

/**
 * The filter's own on/off.
 *
 * Being ENABLED is not being switched on: the feature gives this pane and its
 * settings, and this switch is what puts the filter to work. It is persisted, so a
 * filter left switched on comes back switched on after a restart.
 *
 * Switching on is atomic on the gateway side: an error means nothing was armed and
 * the filter is off, so the switch goes back where it was and the message says why.
 *
 * On success the page reloads, because the badge, the warning and the counters are
 * all rendered by the backend from the state this just changed - but only when the
 * form is untouched. This switch saves one boolean; the form next to it holds the
 * DSCP policy and the block mode, and reloading on top of what the operator typed
 * and had not saved yet would throw it away with nothing said. Edited: no reload,
 * and the message says that what is on screen is the state from before.
 *
 * No switch is rendered when the gateway could not be asked about the state (the
 * position would be a guess), so this can find nothing to bind.
 */
function bindSwitch(root, rendered) {
    const toggle = document.querySelector('[data-js="cf-web-active"]');
    if (!toggle) return;

    toggle.addEventListener('change', async () => {
        const wanted = toggle.checked;
        toggle.disabled = true;
        try {
            const result = await apiClient.submit('web-filter.set_active', { active: wanted });
            const untouched = policyKey(root) === rendered;
            if ((result.status || '') !== 'success') {
                toggle.checked = !wanted;
            }
            showApiResult(
                untouched ? result : apiResultWithNote(result, UNSAVED_SWITCH_NOTE),
                { title: 'Web Filter', closeText: 'Close', reloadOnOk: untouched }
            );
        } catch (err) {
            toggle.checked = !wanted;
            showApiResult(
                { status: 'error', result: { msg: err.message } },
                { title: 'Web Filter', closeText: 'Close' }
            );
        } finally {
            toggle.disabled = false;
        }
    });
}
