// dns-filter.js
// Content filter: what the DNS filter does with the shared policy.
//
//   save   -> apiClient.submit('dns-filter.set_settings', payload)
//   switch -> apiClient.submit('dns-filter.set_active', {active: bool})
//
// Which categories are blocked is not decided here: that is the catalogue's
// (categories.set_posture), because this filter cuts first and a divergent web
// filter would only be heard on the flows this one did not see. What this pane
// saves is where a blocked name is sent and what happens when the filter is not
// there.
//
// Saving APPLIES while the filter is switched on (rules regenerated, engine
// repointed, live decider updated in place) and is only STORED while it is off -
// the backend says so in result.msg and returns apply: null, which is why the page
// reloads on success either way and lets the notice speak for itself.
//
// Nothing is sent for a field left empty: empty IS the setting (the clean cut,
// NXDOMAIN), not "unset", so it has to be sent explicitly rather than omitted.
//
// Flags come from the DOM: the page is rendered by the backend, so the render
// already knows whether this user may write.

/** Said where the operator reads the result, when the reload was skipped. */
const UNSAVED_SWITCH_NOTE = 'This card still shows the state from before the switch: your unsaved edits are in '
    + 'the form, so the page was not reloaded. Save them (or reload) to see the state in force.';

document.addEventListener('DOMContentLoaded', () => {
    const root = document.querySelector('.cf-page');
    if (!root || root.dataset.canEdit !== '1') return;
    // What the server rendered, as a string to compare against: the switch must not
    // reload the page on top of edits its own call did not save.
    const rendered = policyKey();
    bindSave();
    bindSwitch(rendered);
});

/**
 * The form's payload as one string, to tell an edited form from an untouched one.
 *
 * Built by the same function the save sends, so what is compared is what would be
 * written - and a field the operator touched and put back reads as untouched, which
 * is what it is.
 */
function policyKey() {
    return JSON.stringify(buildDnsPolicy());
}

function dnsValue(id) {
    const el = document.getElementById(id);
    return el ? el.value.trim() : '';
}

function buildDnsPolicy() {
    const chains = [];
    document.querySelectorAll('.cf-chain').forEach((box) => {
        if (box.checked) chains.push(box.value);
    });

    const failEl = document.getElementById('cf-fail-mode');

    return {
        sinkhole_address: dnsValue('cf-address'),
        sinkhole_address6: dnsValue('cf-address6'),
        fail_mode: failEl ? failEl.value : 'bypass',
        chains,
    };
}

function bindSave() {
    const btn = document.querySelector('[data-js="cf-save-dns"]');
    if (!btn) return;

    btn.addEventListener('click', async () => {
        try {
            const result = await apiClient.submit('dns-filter.set_settings', buildDnsPolicy());
            showApiResult(result, { title: 'DNS Filter', closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            showApiResult(
                { status: 'error', result: { msg: err.message } },
                { title: 'DNS Filter', closeText: 'Close' }
            );
        }
    });
}

/**
 * The filter's own on/off.
 *
 * Being ENABLED is not being switched on: the feature gives this pane and its
 * settings, and this switch is what puts the filter to work - it puts the queue
 * rule in the kernel and starts the reader that answers for it. It is persisted,
 * so a filter left switched on comes back switched on after a restart.
 *
 * The separation is the dangerous case written down: a queue rule with no reader
 * holds the traffic it matches, and with fail_mode strict that is every DNS
 * response dropped, which is why the gateway arms both together or neither.
 *
 * Switching on is atomic on the gateway side: an error means nothing was armed and
 * the filter is off, so the switch goes back where it was and the message says why.
 *
 * On success the page reloads, because the badge, the warning and the counters are
 * all rendered by the backend from the state this just changed - but only when the
 * form is untouched. This switch saves one boolean; the same page holds the targets,
 * the failure mode and the chains, and reloading on top of what the operator typed
 * and had not saved yet would throw it away with nothing said. Edited: no reload,
 * and the message says that what is on screen is the state from before.
 *
 * No switch is rendered when the gateway could not be asked about the state (the
 * position would be a guess), so this can find nothing to bind.
 */
function bindSwitch(rendered) {
    const toggle = document.querySelector('[data-js="cf-dns-active"]');
    if (!toggle) return;

    toggle.addEventListener('change', async () => {
        const wanted = toggle.checked;
        toggle.disabled = true;
        try {
            const result = await apiClient.submit('dns-filter.set_active', { active: wanted });
            const untouched = policyKey() === rendered;
            if ((result.status || '') !== 'success') {
                toggle.checked = !wanted;
            }
            showApiResult(
                untouched ? result : apiResultWithNote(result, UNSAVED_SWITCH_NOTE),
                { title: 'DNS Filter', closeText: 'Close', reloadOnOk: untouched }
            );
        } catch (err) {
            toggle.checked = !wanted;
            showApiResult(
                { status: 'error', result: { msg: err.message } },
                { title: 'DNS Filter', closeText: 'Close' }
            );
        } finally {
            toggle.disabled = false;
        }
    });
}
