// categories.js
// Content filter catalogue: the shared domain -> category entries, and the policy.
//
//   add / remove entry -> apiClient.submit('categories.add_entry'|'categories.remove_entry', payload)
//   policy             -> apiClient.submit('categories.set_posture', { posture })
//
// The page is rendered from the backend on load and refreshed by reload: the
// catalogue decides what the two filters match against, and showing a local guess
// would be showing something that is not in force. showApiResult(reloadOnOk: true)
// surfaces result.msg first (validation errors and FORBIDDEN both arrive there)
// and reloads only on success.
//
// Every block carries its own target, so the add row knows which category it
// belongs to without a hidden field: the button's data-target, and the input
// beside it in the same block.

document.addEventListener('DOMContentLoaded', () => {
    const root = document.querySelector('.cf-page');

    // Non-writers see a read-only page: never bind editing.
    if (!root || root.dataset.canEdit !== '1') return;

    bindAddEntry();
    bindRemoveEntry();
    bindSavePosture();
});

/** The message shown for a failure that never reached the backend. */
function cfLocalError(title, msg) {
    showApiResult({ status: 'error', result: { msg } }, { title, closeText: 'Close' });
}

function bindAddEntry() {
    document.querySelectorAll('[data-js="cf-add-entry"]').forEach((btn) => {
        btn.addEventListener('click', async () => {
            const target = btn.getAttribute('data-target') || '';
            const block = btn.closest('.cf-block');
            const input = block ? block.querySelector('.cf-pattern') : null;
            const pattern = input ? input.value.trim() : '';

            if (pattern === '' || target === '') {
                cfLocalError('Catalogue', 'Enter a domain first.');
                return;
            }
            try {
                const result = await apiClient.submit('categories.add_entry', { pattern, target });
                showApiResult(result, { title: 'Catalogue', closeText: 'Close', reloadOnOk: true });
            } catch (err) {
                cfLocalError('Catalogue', err.message);
            }
        });
    });
}

/**
 * Build the policy from the form.
 *
 * `posture` is replaced wholesale by the backend, so the complete map is sent:
 * a category with no entry means "monitor" on the other side, and leaving one
 * out would silently reset it rather than keep it.
 */
function buildPosture() {
    const posture = {};
    document.querySelectorAll('.cf-action').forEach((select) => {
        const category = select.getAttribute('data-category') || '';
        if (category === '') return;
        posture[category] = select.value;
    });
    return { posture };
}

/**
 * Save the policy.
 *
 * One save reaches **every** filter that is on - the gateway regenerates both
 * rule sets and repoints both decision engines - so there are three answers and
 * all three have to reach the operator:
 *   - applied to both (or to the one that is running);
 *   - stored but nothing is on, so it is not in force yet;
 *   - stored, but one of the two did not take it. That one is a hole in the
 *     policy until it is fixed, and result.msg names it.
 */
function bindSavePosture() {
    const btn = document.querySelector('[data-js="cf-save-posture"]');
    if (!btn) return;

    btn.addEventListener('click', async () => {
        try {
            const result = await apiClient.submit('categories.set_posture', buildPosture());
            showApiResult(result, { title: 'Policy', closeText: 'Close', reloadOnOk: true });
        } catch (err) {
            cfLocalError('Policy', err.message);
        }
    });
}

function bindRemoveEntry() {
    document.querySelectorAll('[data-js="cf-remove-entry"]').forEach((btn) => {
        btn.addEventListener('click', () => {
            const pattern = btn.getAttribute('data-pattern') || '';
            if (pattern === '') return;
            showModal('Remove the entry for ' + pattern + '?', {
                title: 'Confirm Removal',
                closeText: 'Cancel',
                showConfirm: true,
                confirmText: 'Remove',
                onConfirm: async () => {
                    try {
                        const result = await apiClient.submit('categories.remove_entry', { pattern });
                        showApiResult(result, { title: 'Catalogue', closeText: 'Close', reloadOnOk: true });
                    } catch (err) {
                        cfLocalError('Catalogue', err.message);
                    }
                },
            });
        });
    });
}
