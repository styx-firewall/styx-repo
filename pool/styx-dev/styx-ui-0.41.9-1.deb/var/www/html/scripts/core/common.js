/*
 * Small, delegated info popup handler (compact):
 * - Use elements with class `js-info-icon`.
  */
(function(){
    let popup = null;
    function ensurePopup(){
        if (popup) return popup;
        popup = document.createElement('div');
        popup.id = 'global-info-popup';
        // Styling moved to CSS: tpl/default/css/default-main.css (uses CSS variables)
        document.body.appendChild(popup);
        return popup;
    }
    function showFor(el, html){
        const p = ensurePopup();
        p.innerHTML = html;
        const r = el.getBoundingClientRect();
        p.style.left = Math.max(8, Math.min(window.innerWidth-380, r.left + window.scrollX)) + 'px';
        p.style.top = (r.bottom + window.scrollY + 6) + 'px';
        p.style.display = 'block';
    }
    function hide(){ if (popup) popup.style.display='none'; }
    document.addEventListener('click', function(e){
        const icon = e.target.closest ? e.target.closest('.js-info-icon, .js-info-icon-red') : null;
        if (icon){
            // Prevent label from toggling its associated input (checkbox, etc.)
            e.preventDefault();
            e.stopPropagation();

            const mid = icon.getAttribute('data-info-modal');
            const txt = icon.getAttribute('data-info-text');

            if (mid) { const el = document.getElementById(mid); if (el) { showFor(icon, el.innerHTML); } }
            else if (txt) { showFor(icon, txt); }
            else { const title = icon.getAttribute('title'); if (title) { showFor(icon, title); } }
            return;
        }
        if (popup && popup.style.display === 'block' && !popup.contains(e.target)) hide();
    });
})();

// Inject standard SVG icon into empty .js-info-icon elements so templates stay minimal
(function(){
    const svg = '<svg class="info-svg" width="14" height="14" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><circle cx="8" cy="8" r="7" fill="currentColor" opacity="0.08"/><text x="8" y="11" text-anchor="middle" font-size="10" fill="currentColor" font-family="Arial">i</text></svg>';
    function inject() {
        document.querySelectorAll('.js-info-icon, .js-info-icon-red').forEach(el => {
            if (!el.innerHTML.trim()) el.innerHTML = svg;
            if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex','0');
            // Apply optional presentation classes based on data attributes so markup can pick
            // an alternate style when the field is required or marked 'danger'.
            const state = el.getAttribute('data-info-state');
            if (state === 'danger' || el.hasAttribute('data-required')) {
                el.classList.add('info-danger');
            }
            // If the icon sits inside a label that targets a required control, mark the
            // icon with the red variant so templates don't need to hardcode it.
            try {
                let label = el.closest ? el.closest('label') : null;
                if (!label) {
                    const parent = el.parentElement;
                    if (parent && parent.tagName === 'LABEL') label = parent;
                }
                if (label) {
                    const requiredInside = label.querySelector && label.querySelector('[required]');
                    const forAttr = label.getAttribute && label.getAttribute('for');
                    let targetRequired = false;
                    if (requiredInside) targetRequired = true;
                    else if (forAttr) {
                        const target = document.getElementById(forAttr);
                        if (target && target.required) targetRequired = true;
                    }
                    if (targetRequired) el.classList.add('js-info-icon-red');
                }
            } catch (e) { /* no-op */ }
            // Allow arbitrary classes via `data-info-class` (space-separated)
            const infoClass = el.getAttribute('data-info-class');
            if (infoClass) {
                infoClass.split(/\s+/).forEach(c => { if (c) el.classList.add(c); });
            }
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', inject); else inject();
})();

// Reusable standard modal for the entire app
//
// Basic usage:
// import { showModal, hideModal } from './common.js';
// showModal('<h2>Hello</h2><p>Modal content</p>');
//
// Advanced options:
// showModal('<b>Custom</b>', {
//   modalStyle: { background: 'rgba(0,0,0,0.8)' }, // Background style
//   boxStyle: { minWidth: '500px', color: '#ff0' }, // Box style
//   contentStyle: { fontSize: '1.2em' }, // Content style
//   onClose: function() { console.log('Modal closed'); }
// });
//
// To close manually:
// hideModal();

// Centralized logging helper
// appLog.setEnabled(true); // type in console to enable logs
// appLog('This is a log message');
// appLog.warn('This is a warning');
// appLog.error('This is an error message');
//

(function(window) {
    window.APP_LOG = window.APP_LOG || {};
    const STORAGE_KEY = 'APP_LOG.enabled';

    // internal enabled state (backed by localStorage when available)
    // Default: disabled. If a stored preference exists it will override this.
    let _enabled = false;
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored !== null) {
            _enabled = (stored === '1' || stored === 'true');
        }
    } catch (e) {
        // localStorage may be unavailable (privacy mode)-fall back to default
    }

    // Define a readable getter/setter pair for `window.APP_LOG.enabled`.
    function getAppLogEnabled() {
        return _enabled;
    }

    function setAppLogEnabled(value) {
        _enabled = Boolean(value);
        try {
            // store as '1' or '0'
            localStorage.setItem(STORAGE_KEY, _enabled ? '1' : '0');
        } catch (err) {
            // Ignore storage errors (privacy mode, blocked storage, etc.)
        }
    }

    Object.defineProperty(window.APP_LOG, 'enabled', {
        get: getAppLogEnabled,
        set: setAppLogEnabled,
        configurable: true,
        enumerable: true
    });

    function safeApply(consoleFn, args) {
        try {
            if (consoleFn && consoleFn.apply) {
                consoleFn.apply(console, args);
            } else if (consoleFn) {
                consoleFn(args);
            }
        } catch (e) {
            try { console.log(args); } catch (ee) { /* noop */ }
        }
    }

    function appLog() {
        if (!window.APP_LOG.enabled) return;
        if (typeof console === 'undefined') return;
        safeApply(console.log, Array.prototype.slice.call(arguments));
    }

    appLog.warn = function() {
        if (!window.APP_LOG.enabled) return;
        if (typeof console === 'undefined') return;
        safeApply(console.warn || console.log, Array.prototype.slice.call(arguments));
    };

    appLog.error = function() {
        if (!window.APP_LOG.enabled) return;
        if (typeof console === 'undefined') return;
        safeApply(console.error || console.log, Array.prototype.slice.call(arguments));
    };

    appLog.info = function() {
        if (!window.APP_LOG.enabled) return;
        if (typeof console === 'undefined') return;
        safeApply(console.info || console.log, Array.prototype.slice.call(arguments));
    };

    // Programmatic helper to set the enabled flag (persists to localStorage)
    appLog.setEnabled = function(value) {
        window.APP_LOG.enabled = !!value;
    };

    appLog.isEnabled = function() {
        return !!window.APP_LOG.enabled;
    };

    // Expose
    window.appLog = appLog;
})(window);

// Sync appLog enabled state with server-provided debug flag from meta tag.
// Must run on DOMContentLoaded because common.js is loaded in <head> but the
// meta tag is rendered inside the body-it does not exist in the DOM yet at
// script parse/execute time.
(function() {
    window.addEventListener('DOMContentLoaded', function() {
        try {
            var meta = document.querySelector('meta[name="app-debug"]');
            var debug = meta ? meta.getAttribute('content') === '1' : false;
            window.APP_DEBUG = debug;
            if (window.appLog && typeof window.appLog.setEnabled === 'function') {
                window.appLog.setEnabled(debug);
            }
        } catch (e) {}
    }, { once: true });
})();

appLog('App Log is enabled:', window.APP_LOG.enabled);

function showModal(contentHtml, options = {}) {
    // NOTE: There is a page-specific modal with id "feature-info-modal"
    // used by `scripts/styx-features.js`. Do NOT modify that modal's
    // markup here or change its `style.display` from other modules.
    // Prefer toggling the `hidden` class on page-specific modals so
    // global CSS rules like `.hidden { display: none !important; }`
    // are respected.
    try { if (window.hideLoader) window.hideLoader(); } catch (e) { /* noop */ }
    let modal = document.getElementById('std-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'std-modal';
        document.body.appendChild(modal);
    }
    // Build modal DOM nodes without using innerHTML
    const box = document.createElement('div');
    box.id = 'std-modal-box';

    const modalBar = document.createElement('div');
    modalBar.id = 'std-modal-bar';
    modalBar.className = 'std-modal-bar';

    const titleSpan = document.createElement('span');
    titleSpan.id = 'std-modal-title';
    titleSpan.className = 'std-modal-title';

    const closeBtn = document.createElement('button');
    closeBtn.id = 'close-std-modal';
    closeBtn.className = 'std-modal-close';

    modalBar.appendChild(titleSpan);
    modalBar.appendChild(closeBtn);

    const contentDiv = document.createElement('div');
    contentDiv.id = 'std-modal-content';
    contentDiv.className = 'std-modal-content';

    const actionsDiv = document.createElement('div');
    actionsDiv.id = 'std-modal-actions';
    actionsDiv.className = 'std-modal-actions';

    box.appendChild(modalBar);
    box.appendChild(contentDiv);
    box.appendChild(actionsDiv);

    // Clear any previous content and append built nodes
    modal.textContent = '';
    modal.appendChild(box);
    // Clear any inline display setting (some modules set `style.display='none'`)
    // and then show modal via class (CSS controls layout).
    modal.style.display = '';
    modal.classList.add('std-modal-visible');
    // Title options
    const title = options.title || '';
    const titleElem = modal.querySelector('#std-modal-title');
    if (titleElem) {
        titleElem.textContent = title;
        titleElem.classList.toggle('im-hide', !title);
    }
    // Close button options
    const closeBtnEl = modal.querySelector('#close-std-modal');
    if (closeBtnEl) {
        closeBtnEl.textContent = options.closeText || 'Close';
        closeBtnEl.onclick = function() {
            modal.classList.remove('std-modal-visible');
            if (options.onClose) options.onClose();
        };
    }
    // Confirmation button
    const actionsDivEl = modal.querySelector('#std-modal-actions');
    // Clear existing actions
    while (actionsDivEl.firstChild) actionsDivEl.removeChild(actionsDivEl.firstChild);
    if (options.showConfirm && typeof options.onConfirm === 'function') {
        // Confirm button
        const confirmBtn = document.createElement('button');
        confirmBtn.textContent = options.confirmText || 'Confirm';
        // confirmClass is a colour variant (e.g. ebpf-btn-danger, which only sets
        // background): keep the std-btn base for shape and padding and add it on
        // top. Cancel stays plain std-btn so the two never look alike.
        confirmBtn.className = 'std-btn' + (options.confirmClass ? ' ' + options.confirmClass : '');
        confirmBtn.onclick = function() {
            modal.classList.remove('std-modal-visible');
            options.onConfirm();
        };
        actionsDivEl.appendChild(confirmBtn);
        // Close / cancel button
        const cancelBtn = document.createElement('button');
        cancelBtn.textContent = options.closeText || 'Cancel';
        cancelBtn.className = 'std-btn';
        cancelBtn.onclick = function() {
            modal.classList.remove('std-modal-visible');
            if (options.onClose) options.onClose();
        };
        actionsDivEl.appendChild(cancelBtn);
        actionsDivEl.classList.add('visible');
    } else {
        actionsDivEl.classList.remove('visible');
    }
    // Adaptive sizing and scroll
    if (options.modalStyle) {
        Object.assign(modal.style, options.modalStyle);
    }
    if (options.boxStyle) {
        const safeBoxStyle = { ...options.boxStyle };
        delete safeBoxStyle.padding;
        Object.assign(modal.querySelector('#std-modal-box').style, safeBoxStyle);
    }
    if (options.contentStyle) {
        Object.assign(modal.querySelector('#std-modal-content').style, options.contentStyle);
    }

    // Support applying CSS classes instead of inline styles (preferred)
    if (options.modalClass) {
        try {
            // record added class so hideModal can remove it
            modal.dataset._addedModalClass = options.modalClass;
            modal.classList.add(options.modalClass);
        } catch (e) { /* noop */ }
    }
    if (options.boxClass) {
        try {
            const box = modal.querySelector('#std-modal-box');
            box.dataset._addedBoxClass = options.boxClass;
            box.classList.add(options.boxClass);
        } catch (e) { /* noop */ }
    }
    if (options.contentClass) {
        try {
            const content = modal.querySelector('#std-modal-content');
            content.dataset._addedContentClass = options.contentClass;
            content.classList.add(options.contentClass);
        } catch (e) { /* noop */ }
    }
    // Accessibility: focus and close with ESC
    setTimeout(() => {
        closeBtn && closeBtn.focus();
    }, 10);
    modal.tabIndex = -1;
    modal.onkeydown = function(e) {
        if (e.key === 'Escape') {
            modal.classList.remove('std-modal-visible');
            if (options.onClose) options.onClose();
        }
    };
    // Content: insert HTML safely via Range.createContextualFragment (avoids innerHTML)
    const contentEl = modal.querySelector('#std-modal-content');
    while (contentEl.firstChild) contentEl.removeChild(contentEl.firstChild);
    if (contentHtml && typeof contentHtml === 'string') {
        try {
            const frag = document.createRange().createContextualFragment(contentHtml);
            contentEl.appendChild(frag);
        } catch (e) {
            // Fallback: treat as text
            contentEl.textContent = contentHtml;
        }
    } else if (contentHtml instanceof Node) {
        contentEl.appendChild(contentHtml);
    }
}

function hideModal() {
    let modal = document.getElementById('std-modal');
    if (modal) modal.classList.remove('std-modal-visible');
    // Remove any classes added via showModal
    try {
        if (modal) {
            const added = modal.dataset._addedModalClass;
            if (added) modal.classList.remove(added);
            const box = modal.querySelector('#std-modal-box');
            if (box) {
                const addedBox = box.dataset._addedBoxClass;
                if (addedBox) box.classList.remove(addedBox);
            }
            const content = modal.querySelector('#std-modal-content');
            if (content) {
                const addedContent = content.dataset._addedContentClass;
                if (addedContent) content.classList.remove(addedContent);
            }
        }
    } catch (e) { /* noop */ }
}

document.addEventListener('DOMContentLoaded', function() {
    var bell = document.getElementById('notif-bell');
    var dropdown = document.getElementById('notif-dropdown');
    // Show/hide when clicking the icon
    // Scroll to bottom initially
    var panelScroll = document.getElementById('panel-scroll');
    if (panelScroll) {
        panelScroll.scrollTop = panelScroll.scrollHeight;
    }
    if (bell && dropdown) {
        bell.addEventListener('click', function(e) {
            dropdown.classList.toggle('show');
            e.stopPropagation();
        });
        bell.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                dropdown.classList.toggle('show');
                e.preventDefault();
            }
        });
    // Hide when clicking outside the icon or dropdown
        document.addEventListener('click', function(e) {
            if (!bell.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.classList.remove('show');
            }
        });
    }
});

// Expose functions globally
// TODO: Migrate `showModal` / `hideModal` to ES modules and import where needed?
// Once migrated, remove these global assignments to avoid global namespace pollution
// and redeclaration problems when modules are loaded.
window.showModal = showModal;
window.hideModal = hideModal;

// Loading overlay helpers
(function () {
    /*
     * Global loading overlay (implementation notes)
     * ---------------------------------------------
     * Purpose
     * - Provide a single, global page-level loading overlay that is shown
     *   only when explicitly requested (opt-in) to avoid spurious flashes.
     *
     * Opt-in behavior
     * - Navigation links or forms that should display the overlay must include
     *   the attribute `data-force-loader` on the element. Example:
     *     <a href="/some/page" data-force-loader>Go</a>
     *     <form action="/do" method="post" data-force-loader>...</form>
     *
     * - Programmatic (JS) usage: call `window.showLoader()` / `window.hideLoader()`
     *   around long-running operations. For convenience use `window.withLoading(promise)`
     *   which shows the loader, awaits the promise, and hides it in `finally`.
     *
     * API
     * - `window.showLoader(immediate = false)`
     *     Show the overlay. If `immediate` is true, the overlay is shown without
     *     CSS transition to avoid flicker on navigation.
     * - `window.hideLoader()`
     *     Hide the overlay.
     * - `window.withLoading(promise)`
     *     Convenience helper: `await window.withLoading(fetch(...))` will show the
     *     loader and ensure it's hidden when the promise settles.
     *
     * Notes for implementors
     * - The overlay starts hidden by default in templates. When a navigation with
     *   `data-force-loader` occurs the overlay will be shown before the navigation
     *   and the destination page's `common.js` will hide it on `DOMContentLoaded`
     *   (and on `load`) to restore the normal state.
     * - For AJAX flows you must call `window.hideLoader()` (or use `withLoading`) to
     *   hide the loader when your work completes-the framework will not try to
     *   infer that for you.
     */
    const CLICK_BLOCK_MS = 800;
    let clickBlocked = false;
    let loader = null;

    const getEl = () => (loader ??= document.getElementById('loading_wrap'));

    const show = (immediate = false) => {
        const l = getEl();
        if (!l) return;
        if (immediate) {
            l.style.transition = 'none';
            l.classList.remove('hidden');
            void l.offsetHeight; // force reflow
            requestAnimationFrame(() => { l.style.transition = ''; });
        } else {
            l.classList.remove('hidden');
        }
        l.setAttribute('aria-hidden', 'false');
    };

    const hide = () => {
        const l = getEl();
        if (!l) return;
        l.classList.add('hidden');
        l.setAttribute('aria-hidden', 'true');
    };

    document.addEventListener('DOMContentLoaded', () => {
        const l = getEl();
        if (l) {
            l.setAttribute('role', l.getAttribute('role') || 'status');
            l.setAttribute('aria-live', l.getAttribute('aria-live') || 'polite');
        }
        setTimeout(hide, 200);
    }, { once: true });

    // Show loader only for explicit opt-in via `data-force-loader`.
    // Button clicks and UI toggles should not trigger the global loader.
    document.addEventListener('click', (ev) => {
        try {
            if (clickBlocked) return;
            const a = ev.target.closest('a[href]');
            if (!a) return;
            if (a.closest('#std-modal, #loading_wrap')) return;
            const href = (a.getAttribute('href') || '').trim();
            if (!href || href === '#' || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:') || href.startsWith('#')) return;
            // At this point it's a navigation link-show loader unless opted out.
            // Only show the loader for explicit opt-in via `data-force-loader`.
            if (a.hasAttribute('data-force-loader')) {
                show(true);
                clickBlocked = true;
                setTimeout(() => { clickBlocked = false; }, CLICK_BLOCK_MS);
            }
        } catch (e) { /* noop */ }
    }, true);

    // Show loader for form submissions only when `data-force-loader` is present.
    document.addEventListener('submit', (ev) => {
        try {
            const form = ev.target;
            if (!(form instanceof HTMLFormElement)) return;
            if (form.closest('#std-modal, #loading_wrap')) return;
            if (form.hasAttribute('data-force-loader')) {
                show(true);
            }
        } catch (e) { /* noop */ }
    }, true);

    // Show loader when user triggers a full page reload (F5 or Ctrl/Cmd+R)
    // or when the page is unloading. This provides immediate feedback to the
    // user that a reload/navigation is in progress. Note: some browsers may
    // ignore DOM updates during `beforeunload`, but many will render the
    // overlay when shown just prior to navigation.
    window.addEventListener('keydown', function (e) {
        try {
            const isF5 = e.key === 'F5';
            const isCtrlR = (e.key === 'r' || e.key === 'R') && (e.ctrlKey || e.metaKey);
            if (isF5 || isCtrlR) {
                show(true);
            }
        } catch (err) { /* noop */ }
    });

    window.addEventListener('beforeunload', function () {
        try { show(true); } catch (err) { /* noop */ }
    });

    window.showLoader = (immediate) => show(!!immediate);
    window.hideLoader = hide;
    window.withLoading = async (p) => { show(); try { return await p; } finally { hide(); } };
    window.addEventListener('load', hide, { once: true });
})();

/**
 * showApiResult(res, opts)
 * Generic helper to display an API response via showModal, available globally.
 *
 * Response shape accepted (any backend convention):
 *   { ok: true/false, msg: '...' }
 *   { status: 'success'|'error'|'ok', response_msg: '...' }
 *
 * opts mirrors showModal options, plus:
 *   opts.title     -modal title (defaults to 'Success' or 'Error')
 *   opts.closeText -close button label
 *   opts.reloadOnOk-reload page when result is ok
 *   opts.boxStyle  -forwarded to showModal
 *
 * apiResultWithNote(res, note) returns a copy of a response whose message carries
 * one more sentence, for the callers that show a result through showApiResult and
 * have something of their own to say about it. `_msg` reads `msg` first, then
 * `response_msg`, then `result.msg`, so the note is written into the first two and
 * the original text is kept in front of it.
 */
(function (window) {
    function _isOk(res) {
        if (!res) return false;
        if (res.ok === true)  return true;
        if (res.ok === false) return false;
        return res.status === 'success' || res.status === 'ok' || res.code === 0;
    }

    function _msg(res) {
        if (!res) return '';
        return res.msg || res.response_msg || res.result?.msg || res.result?.response_msg
            || (typeof res === 'string' ? res : JSON.stringify(res));
    }

    window.apiResultWithNote = function apiResultWithNote(res, note) {
        const original = _msg(res);
        const text = original ? original + ' ' + note : note;
        return Object.assign({}, res, { msg: text, response_msg: text });
    };

    window.showApiResult = function showApiResult(res, opts) {
        opts = opts || {};
        const ok  = _isOk(res);
        const msg = _msg(res) || (ok ? 'Success' : 'Error');
        const title = opts.title || (ok ? 'Success' : 'Error');

        const body = '<pre style="white-space:pre-wrap;word-break:break-word;">'
            + String(msg).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            + '</pre>';

        const modalOpts = Object.assign({}, opts, { title: title });
        delete modalOpts.reloadOnOk;
        if (opts.reloadOnOk && ok) {
            modalOpts.onClose = () => window.location.reload();
        }
        showModal(body, modalOpts);
    };
})(window);

/**
 * showError(msg, title)
 * Centralized error display: showModal with alert() fallback.
 * Available globally for any script loaded after common.js.
 */
window.showError = function showError(msg, title) {
    if (typeof showModal === 'function') {
        showModal('<p>' + msg + '</p>', { title: title || 'Error' });
    } else {
        alert(msg);
    }
};

/**
 * formatBytes(bytes)
 * Format a number of bytes to a human-readable string (e.g. "1.2 MB").
 * Available globally for any script loaded after common.js.
 *
 * @param {number} bytes
 * @returns {string}
 */
window.formatBytes = function formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    const val = bytes / Math.pow(1024, i);
    return val.toFixed(i > 0 ? 1 : 0) + ' ' + units[i];
};

// Global std-tabs handler
// Any .std-tabs container with .std-tab-btn[data-tab="X"] switches
// .std-tab-panel#tab-X. Works across all pages without per-page JS.
//
// Buttons without `data-tab` are left untouched (they have their own custom
// handler, e.g. routing-routes which uses onclick + showTab()).
(function () {
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.std-tab-btn');
        if (!btn) return;
        var tabs = btn.closest('.std-tabs');
        if (!tabs) return;

        // Skip if the button has no data-tab-it uses a custom handler
        var tabName = btn.getAttribute('data-tab');
        if (!tabName) return;

        tabs.querySelectorAll('.std-tab-btn').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');

        // Scope panel toggling to the parent container so we don't clobber
        // other tab systems or custom implementations on the same page.
        var container = tabs.parentElement;
        container.querySelectorAll('.std-tab-panel').forEach(function (p) { p.classList.remove('active'); });

        var panel = document.getElementById('tab-' + tabName);
        if (panel) panel.classList.add('active');
    });
})();

// Config-change banner-Save Configuration button
(function () {
    document.addEventListener('DOMContentLoaded', function () {
        var saveBtn = document.getElementById('config-change-save');
        if (!saveBtn) return;
        saveBtn.addEventListener('click', async function () {
            var origText = saveBtn.textContent;
            saveBtn.disabled = true;
            saveBtn.textContent = 'Saving...';
            try {
                var result = await apiClient.submit('save_config', {});
                if (result && result.status === 'success') {
                    var banner = document.getElementById('config-change-banner');
                    if (!banner) return;
                    // If restart is also required, keep the banner but remove only the config section
                    if (banner.getAttribute('data-restart-required') === '1') {
                        banner.setAttribute('data-config-changed', '0');
                        var configSection = document.getElementById('banner-section-config');
                        if (configSection) configSection.style.display = 'none';
                    } else {
                        banner.style.display = 'none';
                    }
                } else {
                    showError((result && result.response_msg) || 'Failed to save configuration', 'Save Error');
                }
            } catch (err) {
                showError(err.message || 'Unknown error', 'Save Error');
            } finally {
                saveBtn.disabled = false;
                saveBtn.textContent = origText;
            }
        });
    });
})();

// Config-change banner-View Changes button
(function () {
    document.addEventListener('DOMContentLoaded', function () {
        var diffBtn = document.getElementById('config-change-diff');
        if (!diffBtn) return;
        diffBtn.addEventListener('click', async function () {
            var origText = diffBtn.textContent;
            diffBtn.disabled = true;
            diffBtn.textContent = 'Loading...';
            try {
                var result = await apiClient.request('styx_get_config_diff', {});
                if (result && result.status === 'success') {
                    var res = result.result || {};
                    var html = '';
                    // Build summary section
                    if (res.summary) {
                        var s = res.summary;
                        html += '<div style="margin-bottom:12px;font-size:13px;">';
                        html += '<strong>Summary:</strong> ';
                        var parts = [];
                        if (s.added && s.added.length) parts.push('<span style="color:#4caf50">+' + s.added.length + ' added</span>');
                        if (s.removed && s.removed.length) parts.push('<span style="color:#f44336">-' + s.removed.length + ' removed</span>');
                        if (s.modified && s.modified.length) parts.push('<span style="color:#ff9800">~' + s.modified.length + ' modified</span>');
                        html += parts.join(', ') || 'no changes';
                        html += '</div>';
                        // Detail lists
                        if (s.added && s.added.length) {
                            html += '<div style="margin-bottom:4px"><span style="color:#4caf50">Added:</span> ' + s.added.join(', ') + '</div>';
                        }
                        if (s.removed && s.removed.length) {
                            html += '<div style="margin-bottom:4px"><span style="color:#f44336">Removed:</span> ' + s.removed.join(', ') + '</div>';
                        }
                        if (s.modified && s.modified.length) {
                            html += '<div style="margin-bottom:4px"><span style="color:#ff9800">Modified:</span> ' + s.modified.join(', ') + '</div>';
                        }
                    }
                    // Diff content with line highlighting
                    if (res.diff) {
                        var lines = res.diff.split('\n');
                        var diffHtml = '';
                        for (var i = 0; i < lines.length; i++) {
                            var line = lines[i];
                            var escaped = line.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
                            var bg = '';
                            if (line.charAt(0) === '+') {
                                bg = 'background:rgba(76,175,80,0.2);';
                            } else if (line.charAt(0) === '-') {
                                bg = 'background:rgba(244,67,54,0.25);';
                            } else if (line.substring(0, 3) === '@@ ') {
                                bg = 'background:rgba(0,150,199,0.2);color:#00bcd4;';
                            }
                            diffHtml += '<span style="display:block;' + bg + '">' + (escaped || '&nbsp;') + '</span>';
                        }
                        html += '<pre style="background:#1e1e1e;color:#d4d4d4;padding:0;border-radius:4px;font-size:12px;line-height:1.5;white-space:pre-wrap;word-break:break-all;margin-top:8px;">' + diffHtml + '</pre>';
                    } else if (res.identical) {
                        html += '<p style="color:#4caf50;margin-top:8px;">&#10003; Configuration is identical &mdash; no changes to display.</p>';
                    } else {
                        html += '<p style="margin-top:8px;">No diff data available.</p>';
                    }
                    showModal(html, { title: 'Configuration Changes' });
                } else {
                    showError((result && result.response_msg) || 'Failed to retrieve configuration diff', 'Error');
                }
            } catch (err) {
                showError(err.message || 'Unknown error', 'Error');
            } finally {
                diffBtn.disabled = false;
                diffBtn.textContent = origText;
            }
        });
    });
})();

// Config-change banner-Restart Gateway button
(function () {
    document.addEventListener('DOMContentLoaded', function () {
        var restartBtn = document.getElementById('config-change-restart');
        if (!restartBtn) return;
        restartBtn.addEventListener('click', function () {
            if (typeof showModal !== 'function') {
                if (confirm('Restart the gateway service now?')) {
                    doRestart(restartBtn);
                }
                return;
            }
            showModal(
                '<p>The gateway service will be restarted to apply the update. The management UI will be briefly unavailable.</p>' +
                '<p><strong>Restart the gateway now?</strong></p>',
                {
                    title: 'Restart Service',
                    closeText: 'Cancel',
                    showConfirm: true,
                    confirmText: 'Restart',
                    onConfirm: function () { doRestart(restartBtn); }
                }
            );
        });

        async function doRestart(btn) {
            var origText = btn.textContent;
            btn.disabled = true;
            btn.textContent = 'Restarting...';
            try {
                var result = await apiClient.submit('restart-daemon', {});
                if (result && result.status === 'success') {
                    btn.textContent = 'Restarting...';
                } else {
                    showError((result && result.response_msg) || 'Failed to restart gateway service', 'Restart Error');
                    btn.disabled = false;
                    btn.textContent = origText;
                }
            } catch (err) {
                showError(err.message || 'Unknown error', 'Restart Error');
                btn.disabled = false;
                btn.textContent = origText;
            }
        }
    });
})();



