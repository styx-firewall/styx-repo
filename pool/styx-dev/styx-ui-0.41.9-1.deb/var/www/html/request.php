<?php
/**
 * Request entry point
 * Handles AJAX requests and routes to appropriate controllers
 */

require __DIR__ . '/bootstrap/bootstrap_api.php';

use App\Registry\RequestRegistry;

$action = $inputData['action'] ?? $inputData['command'] ?? '';

// Public actions that do not require authentication
$publicActions = [
];

// Early authentication (fail-fast)
if (!in_array($action, $publicActions, true)) {
    requireApiAuth($ctx);
}

try {

// === REGISTRY ROUTING (same pattern as submit.php) ===
if (!RequestRegistry::has($action)) {
    echo json_encode(['status' => 'error', 'response_msg' => 'Invalid request action']);
    exit();
}

    $response = RequestRegistry::execute($ctx, $action, $inputData);
    echo json_encode($response);

} catch (\Exception $e) {
    echo json_encode(['status' => 'error', 'response_msg' => $e->getMessage()]);
}

exit();
