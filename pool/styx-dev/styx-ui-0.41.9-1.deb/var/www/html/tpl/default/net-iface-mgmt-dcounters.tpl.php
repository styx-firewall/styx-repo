<?php
/**
 * Fragment: NIC driver counters (ethtool -S) for the interface being edited
 * (net-iface-mgmt), in the right column under "NIC tuning (ethtool)".
 *
 * Presentation data prepared by NetIfaceCountersFormatter::formatDriver() - all
 * dynamic text is pre-escaped, and the counter keys are the driver's own (this
 * template never names one). Echo-only.
 *
 * Closed by default: this is the long one (a virtio NIC publishes fifty keys) and the
 * least often read of the two.
 */
$t = $tdata['tpl_data'] ?? [];
?>
<div id="iface-dcounters-collapse-box" class="std-collapse-box">
    <div class="std-collapse-header" onclick="this.parentNode.classList.toggle('open')">
        NIC counters (ethtool -S)
        <?php if ($t['nc_iface_name_esc'] !== ''): ?>
        <span class="std-badge std-badge--muted"><?= $t['nc_iface_name_esc'] ?></span>
        <?php endif; ?>
        <?php if (empty($t['nc_load_error_esc']) && !empty($t['nc_row_count'])): ?>
        <span class="text-muted">(<?= $t['nc_row_count'] ?>)</span>
        <?php endif; ?>
        <?php if (!empty($t['nc_flagged'])): ?>
        <span class="std-badge std-badge--warning"><?= $t['nc_flagged'] ?> to look at</span>
        <?php endif; ?>
    </div>
    <div class="std-collapse-content">
        <?php if (!empty($t['nc_load_error_esc'])): ?>
        <div class="et-error"><?= $t['nc_load_error_esc'] ?></div>
        <?php else: ?>
        <?php if (!empty($t['nc_state_html'])): ?>
        <div class="et-state"><?= $t['nc_state_html'] ?></div>
        <?php endif; ?>

        <?php if (empty($t['nc_groups'])): ?>
        <p class="text-muted"><?= $t['nc_empty_note_esc'] ?></p>
        <?php else: ?>
        <?php foreach ($t['nc_groups'] as $group): ?>
        <?php if ($group['ncg_title_esc'] !== ''): ?>
        <div class="et-group-title"><?= $group['ncg_title_esc'] ?></div>
        <?php endif; ?>
        <dl class="nc-counters">
            <?php foreach ($group['ncg_rows'] as $row): ?>
            <div class="<?= $row['ncr_class'] ?>">
                <dt><?= $row['ncr_name_esc'] ?></dt>
                <dd><?= $row['ncr_value_esc'] ?></dd>
            </div>
            <?php endforeach; ?>
        </dl>
        <?php endforeach; ?>
        <p class="text-muted nc-legend">The driver's own registers, named by the driver: what the NIC counts, which is
            not what the kernel counts. <span class="nc-legend-crit">Red</span> is a failure, <span
                class="nc-legend-warn">amber</span> is worth a look - the drops counters of a NIC running an XDP
            program are that program at work, not lost traffic. Cumulative, as they were when this page was
            rendered.</p>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
