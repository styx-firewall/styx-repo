<?php
/**
 * TemplateService->getTpl()
 *
 * Telemetry -- raw inspector for the Styx TelemetryBus, whatever subsystem
 * produced the points.
 *
 * Everything below is pre-computed by TelemetryFormatter: values ending in
 * `_html` are ready to echo, values ending in `_attr` are ready to drop into an
 * attribute, and numbers arrive already cast to strings. This file holds no
 * escaping and no casting.
 *
 * Structure of $tdata['page_data']:
 *   scope_options|source_options|schema_options: array<array{value_attr,label_html,selected}>
 *   instance_options: array<array{value_attr,label_html,selected,scope_attr}>
 *                     label is the backend's instance_display; scope lets the
 *                     client narrow the list when a species is selected.
 *   n_options:     array<array{value_attr,label_html,selected}>
 *   sources_rows:  array<array{scope_html,source_html,schemas_html}>
 *   has_inventory: bool
 *   stats:         array{available:bool,gauges:array,drop_rows:array,has_drops:bool,
 *                        total_dropped_html:string,dropped_class_attr:string,
 *                        eviction_rows:array,has_evictions:bool,
 *                        total_evictions_html:string,evictions_class_attr:string,
 *                        delivered_html:string,has_bus:bool}
 *   error_html:    string  (only on failure)
 *   denied:        bool    (only when telemetry:read is missing)
 *
 * The points table is filled client-side by telemetry.js, which polls
 * telemetry_query -- hence the empty tbody.
 *
 * Included JS: scripts/telemetry/telemetry.js
 * Included CSS: default-telemetry.css
 *
 * @var array<mixed> $tdata
 */
$pd = $tdata['page_data'];
$stats = $pd['stats'] ?? ['available' => false];
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Telemetry</h1>

        <?php if (!empty($pd['denied'])): ?>
            <div class="content-box">
                <div class="std-error-box">
                    <strong>Error:</strong>
                    <div><?= $pd['error_html'] ?? '' ?></div>
                </div>
            </div>
        <?php else: ?>

        <?php if (!empty($pd['error_html'])): ?>
            <div class="std-error-box">
                <strong>Error:</strong>
                <div><?= $pd['error_html'] ?></div>
            </div>
        <?php endif; ?>
        <?php if (!empty($pd['warnings_html'])): ?>
            <div class="std-error-box">
                <strong>Warning:</strong>
                <div><?= $pd['warnings_html'] ?></div>
            </div>
        <?php endif; ?>

        <div class="telemetry-tabs">
            <div class="std-tabs" id="telemetry-tabs">
                <button class="std-tab-btn active" data-tab="telemetry-live">Live</button>
                <button class="std-tab-btn" data-tab="telemetry-stats">Stats</button>
            </div>

            <div id="telemetry-tab-panels">
                <div class="std-tab-panel active" id="tab-telemetry-live">
                    <div class="content-box">
                        <form class="std-form" id="telemetry-filter-form">
                            <div class="form-row">
                                <div class="form-col">
                                    <label>Scope
                                        <select name="scope" class="std-select">
                                            <?php foreach (($pd['scope_options'] ?? []) as $opt): ?>
                                                <option
                                                    value="<?= $opt['value_attr'] ?>"
                                                    <?php if (!empty($opt['selected'])): ?>selected<?php endif; ?>
                                                ><?= $opt['label_html'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label>Source
                                        <select name="source" class="std-select">
                                            <?php foreach (($pd['source_options'] ?? []) as $opt): ?>
                                                <option
                                                    value="<?= $opt['value_attr'] ?>"
                                                    <?php if (!empty($opt['selected'])): ?>selected<?php endif; ?>
                                                ><?= $opt['label_html'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label>Instance
                                        <select name="instance" class="std-select">
                                            <?php foreach (($pd['instance_options'] ?? []) as $opt): ?>
                                                <option
                                                    value="<?= $opt['value_attr'] ?>"
                                                    data-scope="<?= $opt['scope_attr'] ?>"
                                                    <?php if (!empty($opt['selected'])): ?>selected<?php endif; ?>
                                                ><?= $opt['label_html'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label>Schema type
                                        <select name="schema_type" class="std-select">
                                            <?php foreach (($pd['schema_options'] ?? []) as $opt): ?>
                                                <option
                                                    value="<?= $opt['value_attr'] ?>"
                                                    <?php if (!empty($opt['selected'])): ?>selected<?php endif; ?>
                                                ><?= $opt['label_html'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label>Points per bucket
                                        <select name="n" class="std-select">
                                            <?php foreach (($pd['n_options'] ?? []) as $opt): ?>
                                                <option
                                                    value="<?= $opt['value_attr'] ?>"
                                                    <?php if (!empty($opt['selected'])): ?>selected<?php endif; ?>
                                                ><?= $opt['label_html'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-col">
                                    <label>From
                                        <input type="datetime-local" name="from_ts" class="std-input" step="1">
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label>To
                                        <input type="datetime-local" name="to_ts" class="std-input" step="1">
                                    </label>
                                </div>
                                <div class="form-col align-self-end">
                                    <button
                                        type="button"
                                        class="std-btn"
                                        id="telemetry-clear-dates"
                                    >Clear dates</button>
                                </div>
                                <div class="form-col align-self-end">
                                    <button type="submit" class="std-btn" id="telemetry-query-btn">Query</button>
                                </div>
                            </div>
                            <div class="form-row telemetry-options-row">
                                <div class="form-col">
                                    <label class="telemetry-option-label">
                                        <input type="checkbox" id="telemetry-autopoll">
                                        Auto-refresh every
                                        <select
                                            id="telemetry-poll-interval"
                                            class="std-select telemetry-poll-interval"
                                        >
                                            <option value="2000">2s</option>
                                            <option value="5000" selected>5s</option>
                                            <option value="10000">10s</option>
                                            <option value="30000">30s</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label class="telemetry-option-label">
                                        <input type="checkbox" id="telemetry-expand-all">
                                        Expand every payload
                                    </label>
                                </div>
                            </div>
                        </form>

                        <div class="telemetry-status" id="telemetry-status"></div>

                        <table class="std-table telemetry-points-table">
                            <thead>
                                <tr>
                                    <th class="telemetry-caret-col"></th>
                                    <th>Time</th>
                                    <th>Scope</th>
                                    <th>Instance</th>
                                    <th>Source</th>
                                    <th>Schema</th>
                                    <th>Kind</th>
                                    <th>Severity</th>
                                </tr>
                            </thead>
                            <tbody id="telemetry-points-body">
                                <tr>
                                    <td colspan="8" class="text-center">Loading&hellip;</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="std-tab-panel" id="tab-telemetry-stats">
                    <div class="content-box">
                        <?php if (empty($stats['available'])): ?>
                            <p class="text-center">No storage stats available.</p>
                        <?php else: ?>

                        <div class="telemetry-gauges">
                            <?php foreach (($stats['gauges'] ?? []) as $gauge): ?>
                                <div class="telemetry-gauge">
                                    <div class="telemetry-gauge-head">
                                        <span class="telemetry-gauge-label"><?= $gauge['label_html'] ?></span>
                                        <span class="telemetry-gauge-value">
                                            <?= $gauge['value_html'] ?>
                                            <span class="telemetry-gauge-cap"><?= $gauge['cap_html'] ?></span>
                                        </span>
                                    </div>
                                    <?php if (!empty($gauge['has_bar'])): ?>
                                        <div class="std-progress std-progress--grow">
                                            <div
                                                class="std-progress-fill <?= $gauge['tone'] ?>"
                                                style="width:<?= $gauge['pct_attr'] ?>%"
                                            ></div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="telemetry-stat-meta">
                            <?php if (!empty($stats['has_bus'])): ?>
                                <span>Delivered by the bus: <strong><?= $stats['delivered_html'] ?></strong></span>
                            <?php endif; ?>
                            <span>
                                Dropped:
                                <strong
                                    class="<?= $stats['dropped_class_attr'] ?>"
                                ><?= $stats['total_dropped_html'] ?></strong>
                            </span>
                            <span>
                                Evicted since start:
                                <strong
                                    class="<?= $stats['evictions_class_attr'] ?>"
                                ><?= $stats['total_evictions_html'] ?></strong>
                            </span>
                        </div>

                        <h2 class="telemetry-h2">Evictions</h2>
                        <?php if (empty($stats['has_evictions'])): ?>
                            <p class="text-center">No producer is over budget.</p>
                        <?php else: ?>
                            <table class="std-table">
                                <thead>
                                    <tr><th>Scope</th><th>Instance</th><th>Evicted</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach (($stats['eviction_rows'] ?? []) as $row): ?>
                                        <tr>
                                            <td><?= $row['scope_html'] ?></td>
                                            <td><?= $row['instance_html'] ?></td>
                                            <td class="<?= $row['class_attr'] ?>"><?= $row['count_html'] ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>

                        <h2 class="telemetry-h2">Drops</h2>
                        <?php if (empty($stats['has_drops'])): ?>
                            <p class="text-center">No drop counters reported.</p>
                        <?php else: ?>
                            <table class="std-table">
                                <thead>
                                    <tr><th>Reason</th><th>Dropped</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach (($stats['drop_rows'] ?? []) as $row): ?>
                                        <tr>
                                            <td><?= $row['key_html'] ?></td>
                                            <td class="<?= $row['class_attr'] ?>"><?= $row['count_html'] ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>

                        <h2 class="telemetry-h2">Sources in storage</h2>
                        <?php if (empty($pd['has_inventory'])): ?>
                            <p class="text-center">Nothing in storage yet.</p>
                        <?php else: ?>
                            <table class="std-table">
                                <thead>
                                    <tr><th>Scope</th><th>Source</th><th>Schema types</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach (($pd['sources_rows'] ?? []) as $row): ?>
                                        <tr>
                                            <td><?= $row['scope_html'] ?></td>
                                            <td><?= $row['source_html'] ?></td>
                                            <td><?= $row['schemas_html'] ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php endif; ?>
    </main>
</div>
