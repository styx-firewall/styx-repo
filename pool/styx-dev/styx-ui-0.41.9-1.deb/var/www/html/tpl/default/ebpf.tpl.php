<?php
/**
 * eBPF Module Management  -  main template.
 *
 * Fragments are loaded via load_tpl in PageEbpf and rendered into named places.
 * JS reads all data from DOM dataset attributes  -  no JSON injection needed.
 *
 * @var array $tdata
 */
$pd = $tdata['page_data'] ?? [];
$api_ok = $pd['api_ok'] ?? false;
?>

<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>eBPF Modules</h1>
        <div class="content-box">

            <?php if (!$api_ok): ?>
            <div class="ebpf-error-banner">
                <p><b>eBPF Service Unavailable</b></p>
                <p><?= $pd['error_html'] ?? '' ?></p>
            </div>
            <?php else: ?>

            <!-- Answer to the last action. Filled and toggled by
                 scripts/ebpf/ebpf.js (showStatus), never by a reload: this page
                 reloads on every successful action, so the message lives here
                 and a toast does not survive it. -->
            <div id="ebpf-status-bar" class="ebpf-status-bar hidden" role="status" aria-live="polite">
                <span class="ebpf-status-bar-text"></span>
                <button class="ebpf-status-bar-close" type="button"
                        title="Dismiss" aria-label="Dismiss">&#10005;</button>
            </div>

            <?= $tdata['ebpf_list'] ?? '' ?>
            <?= $tdata['ebpf_kernel'] ?? '' ?>
            <?= $tdata['ebpf_available'] ?? '' ?>
            <?= $tdata['ebpf_detail'] ?? '' ?>

            <?php endif; ?>

        </div>
    </main>
</div>
