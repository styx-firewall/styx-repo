<?php
/**
 * Fragment: kernel counters for the interface being edited (net-iface-mgmt), in the
 * right column above "Interface Sysctl".
 *
 * Presentation data prepared by NetIfaceCountersFormatter::formatKernel() - all
 * dynamic text is pre-escaped, and the counter keys are whatever the kernel reported
 * (this template never names one). Echo-only.
 *
 * Open by default: these are the numbers an operator reaches for when an interface
 * behaves strangely, and the box is at the top of the column for that.
 */
$t = $tdata['tpl_data'] ?? [];
?>
<div id="iface-kcounters-collapse-box" class="std-collapse-box im-margin-top0 open">
    <div class="std-collapse-header" onclick="this.parentNode.classList.toggle('open')">
        Kernel counters
        <?php if ($t['nc_iface_name_esc'] !== ''): ?>
        <span class="std-badge std-badge--muted"><?= $t['nc_iface_name_esc'] ?></span>
        <?php endif; ?>
        <?php if (empty($t['nc_load_error_esc']) && !empty($t['nc_row_count'])): ?>
        <span class="text-muted">(<?= $t['nc_row_count'] ?>)</span>
        <?php endif; ?>
        <?php if (!empty($t['nc_flagged'])): ?>
        <span class="std-badge std-badge--warning"><?= $t['nc_flagged'] ?> to look at</span>
        <?php endif; ?>
    </div>
    <div class="std-collapse-content">
        <?php if (!empty($t['nc_load_error_esc'])): ?>
        <div class="et-error"><?= $t['nc_load_error_esc'] ?></div>
        <?php else: ?>
        <?php if (!empty($t['nc_state_html'])): ?>
        <div class="et-state"><?= $t['nc_state_html'] ?></div>
        <?php endif; ?>

        <?php if (empty($t['nc_groups'])): ?>
        <p class="text-muted"><?= $t['nc_empty_note_esc'] ?></p>
        <?php else: ?>
        <?php foreach ($t['nc_groups'] as $group): ?>
        <?php if ($group['ncg_title_esc'] !== ''): ?>
        <div class="et-group-title"><?= $group['ncg_title_esc'] ?></div>
        <?php endif; ?>
        <dl class="nc-counters">
            <?php foreach ($group['ncg_rows'] as $row): ?>
            <div class="<?= $row['ncr_class'] ?>">
                <dt><?= $row['ncr_name_esc'] ?></dt>
                <dd><?= $row['ncr_value_esc'] ?></dd>
            </div>
            <?php endforeach; ?>
        </dl>
        <?php endforeach; ?>
        <p class="text-muted nc-legend">A counter that is not zero and counts something <em>not</em> happening is
            marked: <span class="nc-legend-crit">red</span> when it is a failure, <span
                class="nc-legend-warn">amber</span> when it is worth a look. Cumulative, as the kernel had them when
            this page was rendered - take two readings to see a rate.</p>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
