<?php
/**
 * Content Filter page shell: the shared catalogue and the policy.
 *
 * Echo-only; every derived value comes from the formatter ($pd) - including the
 * count labels, the badge classes, the selected tokens and the tooltips.
 * js: scripts/content-filter/categories.js
 * css: default-content-filter.css
 *
 * One block per category, each holding the three things asked about it together:
 * what is done with it, the field that adds a domain to it, and the entries it
 * holds. The catalogue is what a domain IS and both filters read it, so it is
 * edited once, here - and the policy is here for the same reason: the DNS filter
 * cuts first, so a filter keeping a different one would only be heard on the
 * flows the other did not see.
 */
$pd = $tdata['page_data'] ?? [];
$da = $pd['disabled_attr'] ?? 'disabled';
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content cf-page" data-can-edit="<?= !empty($pd['can_edit']) ? '1' : '0' ?>">
        <h1>Content Filter</h1>
        <?php if (!empty($pd['error_html'])): ?>
            <div class="std-error-box"><strong>Error:</strong> <?= $pd['error_html'] ?></div>
        <?php else: ?>

        <div class="section-full">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-heading">Catalogue</h2>
                    <span class="std-badge std-badge--danger"><?= $pd['blocked_count'] ?> blocked</span>
                </div>
                <div class="card-body">
                    <div class="cf-badges">
                        <span class="std-badge std-badge--chain"><?= $pd['stats']['entries'] ?> entries</span>
                        <span class="std-badge std-badge--info"><?= $pd['stats']['builtin'] ?> built-in</span>
                        <span class="std-badge std-badge--success"><?= $pd['stats']['operator'] ?> operator</span>
                        <span class="std-badge std-badge--muted"><?= $pd['stats']['cached'] ?> cached lookups</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="section-full">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-heading">Categories and entries</h2>
                </div>
                <div class="card-body">
                    <p class="text-muted">Matching is by <strong>suffix</strong>: an entry for
                        <code>example.com</code> also covers <code>a.example.com</code>. A category with no entry in
                        the policy is <strong>monitor</strong> - classified and counted, and nothing done about it -
                        which is why a new category never starts blocking anything on its own. Adding an entry takes 
                        effect at once, the action select is only in force after <strong>Save policy</strong></p>
                    <?php foreach (($pd['sections'] ?? []) as $section): ?>
                    <?php if (!empty($section['heading_html'])): ?>
                    <h3 class="cf-group-title"><?= $section['heading_html'] ?></h3>
                    <?php endif; ?>
                    <div class="cf-blocks">
                        <?php foreach ($section['blocks'] as $block): ?>
                        <div class="cf-block <?= $block['variant_class'] ?>">
                            <div class="cf-block-head">
                                <h4 class="cf-block-title" title="<?= $block['bit_title_attr'] ?>"><?= $block['label_html'] ?></h4>
                                <span class="cf-block-count"><?= $block['count_label'] ?></span>
                            </div>

                            <?php if (!empty($block['note_html'])): ?>
                            <p class="cf-block-note"><?= $block['note_html'] ?></p>
                            <?php endif; ?>

                            <?php if (!empty($block['has_actions'])): ?>
                            <div class="cf-block-row">
                                <select class="std-select cf-action" data-category="<?= $block['id_attr'] ?>"
                                    aria-label="<?= $block['action_aria_attr'] ?>" <?= $block['disabled_attr'] ?>>
                                    <?php foreach ($block['actions'] as $option): ?>
                                    <option value="<?= $option['value_attr'] ?>" <?= $option['selected'] ?>><?= $option['label_html'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>

                            <?php if (!empty($block['has_add'])): ?>
                            <div class="cf-block-row">
                                <input class="std-input cf-pattern" type="text" placeholder="domain to add"
                                    aria-label="<?= $block['add_aria_attr'] ?>" <?= $block['disabled_attr'] ?>>
                                <button class="std-btn cf-add-btn" type="button" data-js="cf-add-entry"
                                    data-target="<?= $block['add_target_attr'] ?>" <?= $block['disabled_attr'] ?>>Add</button>
                            </div>
                            <?php endif; ?>

                            <div class="cf-entries">
                                <?php if (empty($block['has_entries'])): ?>
                                <div class="cf-entry-empty">No entries.</div>
                                <?php else: ?>
                                <?php foreach ($block['entries'] as $entry): ?>
                                <div class="cf-entry">
                                    <span class="cf-entry-pattern" title="<?= $entry['pattern_attr'] ?>"><?= $entry['pattern_html'] ?></span>
                                    <span class="std-badge <?= $entry['source_class'] ?>"><?= $entry['source_label_html'] ?></span>
                                    <?php if (!empty($entry['removable'])): ?>
                                    <button class="std-btn std-btn-delete cf-entry-remove" type="button"
                                        data-js="cf-remove-entry" data-pattern="<?= $entry['pattern_attr'] ?>"
                                        aria-label="<?= $entry['remove_aria_attr'] ?>">Remove</button>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endforeach; ?>

                    <div class="form-row">
                        <div class="form-col cf-actions">
                            <button class="std-btn" type="button" data-js="cf-save-posture" <?= $da ?>>Save policy</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php endif; ?>
    </main>
</div>
