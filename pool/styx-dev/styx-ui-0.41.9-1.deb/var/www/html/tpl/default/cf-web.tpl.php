<?php
/**
 * Content Filter page shell: the web filter.
 *
 * Echo-only; every derived value comes from the formatter ($pd).
 * js: scripts/content-filter/web-filter.js
 * css: default-content-filter.css
 *
 * The web filter reads the domain off the flow itself (HTTP Host, TLS SNI) and
 * blocks what the shared policy says to block. What this pane holds is only what
 * this mechanism decides: how a blocked flow is cut, and which categories derive
 * a DSCP. What it is doing comes first - a filter that is off explains the rest
 * of the pane better than the pane explains it.
 */
$pd = $tdata['page_data'] ?? [];
$da = $pd['disabled_attr'] ?? 'disabled';
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content cf-page" data-can-edit="<?= !empty($pd['can_edit']) ? '1' : '0' ?>"
        data-block-mode="<?= $pd['block_mode'] ?>">
        <h1>Web Filter</h1>
        <?php if (!empty($pd['error_html'])): ?>
            <div class="std-error-box"><strong>Error:</strong> <?= $pd['error_html'] ?></div>
        <?php else: ?>

        <?php if ($pd['state'] === 'feature_off'): ?>
            <div class="std-error-box std-warning-box">The web filter is <strong>off</strong>. Settings saved here are
                stored and will take effect when it is enabled, but nothing is being inspected right now.</div>
        <?php elseif ($pd['state'] === 'unknown'): ?>
            <div class="std-error-box std-warning-box">The state of the web filter <strong>could not be read</strong>:
                the gateway did not report its switch. Nothing on this page says whether it is inspecting, so the switch
                is not shown - a position for it would be a guess. Reload to ask again.</div>
        <?php elseif ($pd['state'] === 'off'): ?>
            <div class="std-error-box std-warning-box">The web filter is <strong>switched off</strong>: its rules are
                not in the kernel and nothing is being inspected. Use the switch below to put it to work; settings
                saved here are stored and take effect when it is switched on.</div>
        <?php elseif ($pd['state'] === 'on_not_running'): ?>
            <div class="std-error-box std-warning-box">The web filter is <strong>switched on but not running</strong>:
                its pieces are not up, so no flow is being inspected right now. The gateway log says what the last
                attempt ran into.</div>
        <?php endif; ?>

        <div class="section-full">
            <div class="card">
                <div class="card-header cf-card-head">
                    <h2 class="card-heading">In force</h2>
                    <div class="cf-state">
                        <?php if ($pd['state'] === 'running'): ?>
                        <span class="std-badge std-badge--success">Running</span>
                        <?php elseif ($pd['state'] === 'on'): ?>
                        <span class="std-badge std-badge--info">Switched on</span>
                        <?php elseif ($pd['state'] === 'on_not_running'): ?>
                        <span class="std-badge std-badge--warning">Switched on, not running</span>
                        <?php elseif ($pd['state'] === 'unknown'): ?>
                        <span class="std-badge std-badge--muted">Unknown</span>
                        <?php elseif ($pd['state'] === 'off' || $pd['state'] === 'feature_off'): ?>
                        <span class="std-badge std-badge--muted">Off</span>
                        <?php endif; ?>
                        <?php if (!empty($pd['switch_visible'])): ?>
                        <div class="setting-toggle">
                            <label class="std-switch">
                                <input type="checkbox" data-js="cf-web-active"
                                    aria-label="Switch the web filter on or off"
                                    <?= $pd['switch_on'] ? 'checked' : '' ?> <?= $da ?>>
                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!empty($pd['status_error_html'])): ?>
                        <div class="std-error-box"><strong>Error:</strong> <?= $pd['status_error_html'] ?></div>
                    <?php else: ?>
                        <h3>Blocked</h3>
                        <div class="cf-badges">
                            <?php if (empty($pd['blocked'])): ?>
                                <span class="text-muted">No category is set to block.</span>
                            <?php else: ?>
                                <?php foreach ($pd['blocked'] as $item): ?>
                                <span class="std-badge std-badge--danger"><?= $item['label_html'] ?></span>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>

                        <h3>Marked for QoS</h3>
                        <div class="cf-badges">
                            <?php if (empty($pd['qos'])): ?>
                                <span class="text-muted">No category derives a DSCP.</span>
                            <?php else: ?>
                                <?php foreach ($pd['qos'] as $item): ?>
                                <span class="std-badge std-badge--info"><?= $item['label_html'] ?></span>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>

                        <details class="cf-fold">
                            <summary class="cf-fold-summary">Counters
                                <span class="cf-fold-hint">(<?= $pd['counters_count'] ?>)</span>
                                <?php if (!empty($pd['counters_flagged'])): ?>
                                <span class="std-badge std-badge--warning"><?= $pd['counters_flagged'] ?> to look
                                    at</span>
                                <?php endif; ?>
                            </summary>
                            <?php if (empty($pd['counter_groups'])): ?>
                            <span class="text-muted">The filter is not running, so there is nothing to count.</span>
                            <?php else: ?>
                            <p class="cf-counter-legend">The counters are cumulative, so a value on its own says
                                little: <strong>zero</strong> rows are dimmed, and a counter that is not zero and
                                counts something <em>not</em> happening is marked <span class="cf-legend-tri">&#9650;</span>
                                and counted in its group's heading. Start there.</p>
                            <div class="cf-counter-groups">
                                <?php foreach ($pd['counter_groups'] as $group): ?>
                                <div class="cf-counter-group">
                                    <div class="cf-counter-head">
                                        <h4 class="cf-group-title"><?= $group['title_html'] ?></h4>
                                        <?php if ($group['flagged'] > 0): ?>
                                        <span class="std-badge std-badge--warning"><?= $group['flagged'] ?> to look
                                            at</span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($group['hint_html'] !== ''): ?>
                                    <p class="cf-counter-hint"><?= $group['hint_html'] ?></p>
                                    <?php endif; ?>
                                    <div class="cf-counter-rows">
                                        <?php foreach ($group['rows'] as $row): ?>
                                        <div class="<?= $row['class_attr'] ?>" title="<?= $row['title_attr'] ?>">
                                            <span class="cf-counter-name"><?php if ($row['path_html'] !== ''): ?><span class="cf-counter-path"><?= $row['path_html'] ?></span><?php endif; ?><?= $row['label_html'] ?></span>
                                            <span class="cf-counter-value"><?= $row['value_html'] ?></span>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <details class="cf-fold cf-fold--raw">
                                <summary class="cf-fold-summary">Raw status</summary>
                                <p class="text-muted">The status as the gateway sent it. The counters above are these
                                    numbers, grouped and marked - this is what to paste into a support thread.</p>
                                <pre class="cf-raw"><?= $pd['status_json_html'] ?></pre>
                            </details>
                            <?php endif; ?>
                        </details>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="section-full">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-heading">QoS (DSCP)</h2>
                    <span class="std-badge std-badge--info"><?= $pd['marked_count'] ?> marked</span>
                </div>
                <div class="card-body">
                    <p class="text-muted">What is <strong>blocked</strong> is decided in
                        <a href="?page=content_filter&amp;section=cf-categories">the catalogue</a>, once for every
                        mechanism. Here is only what <strong>this</strong> filter does with a category: mark it.</p>
                    <p class="text-muted">A DSCP value turns the category into a QoS marking: the flow is marked for
                        traffic control and is not blocked by it.</p>

                    <?php if (empty($pd['has_policy'])): ?>
                        <p class="text-muted">The catalogue has no categories to mark.</p>
                    <?php else: ?>
                    <div class="cf-policy-grid">
                        <?php foreach ($pd['policy_rows'] as $row): ?>
                        <div class="cf-policy-item">
                            <label class="cf-policy-label" for="<?= $row['input_id_attr'] ?>"
                                title="<?= $row['group_attr'] ?>"><?= $row['label_html'] ?></label>
                            <input class="std-input cf-dscp" type="text" id="<?= $row['input_id_attr'] ?>"
                                data-category="<?= $row['id_attr'] ?>" value="<?= $row['value_attr'] ?>"
                                placeholder="-" <?= $row['disabled_attr'] ?>>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="section-full">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-heading">How a blocked flow is stopped</h2>
                </div>
                <div class="card-body">
                    <p class="text-muted">Neither is the hardened one: <strong>reject</strong> tells the client at once,
                        <strong>drop</strong> leaves it waiting for its own timeout. Pick what this network wants.</p>
                    <div class="std-form std-form--compact">
                        <div class="form-row">
                            <div class="form-col">
                                <select class="std-select" id="cf-block-mode"
                                    aria-label="<?= $pd['block_mode_aria_attr'] ?>" <?= $da ?>>
                                    <?php foreach (($pd['block_modes'] ?? []) as $mode): ?>
                                    <option value="<?= $mode['value_attr'] ?>" <?= $mode['selected'] ?>><?= $mode['label_html'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-col cf-actions">
                                <button class="std-btn" type="button" data-js="cf-save-web" <?= $da ?>>Save</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php endif; ?>
    </main>
</div>
