<?php
/**
 * eBPF fragment: the modules on disk, ready to load.
 *
 * A section of its own, and at the end, on purpose: it is a catalogue, not a
 * state of the box. It used to be a block of rows inside the "Managed by Styx"
 * table, behind an uppercase separator, which made it read as one more status
 * section and left it sitting between the alarms (Foreign, Stale, Not Attached,
 * Unmanaged). Those sections only render when they have something to report, so
 * the block of alarms is what should be together and high up.
 *
 * Open by default, unlike the kernel sections: this is the one the operator acts
 * on, and in a healthy box the others are empty.
 *
 * The Interface and Autoload columns the instance rows carry are not here: a
 * module on disk has neither, and they were two permanent dashes.
 *
 * @var array $tdata - $tdata['tpl_data'] contains the full formatted page data
 */
$pd = $tdata['tpl_data'] ?? [];
?>
<?php if ($pd['has_available'] ?? false): ?>
<div id="ebpf-available-section" class="ebpf-section ebpf-collapsible-section">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-available-body">
        <span class="ebpf-section-title">Available to Load</span>
        <span id="ebpf-available-count" class="ebpf-count-badge"><?= $pd['available_count'] ?></span>
        <span class="ebpf-collapse-arrow">&#9650;</span>
    </div>
    <div id="ebpf-available-body" class="ebpf-collapse-body">
        <table id="ebpf-available-table" class="ebpf-module-table">
            <thead>
                <tr>
                    <th>Module</th><th>Status</th><th>Type</th><th>Hook</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pd['available_rows'] as $row): ?>
                <tr class="ebpf-module-row"
                    data-module="<?= $row['name_attr'] ?>"
                    data-instance-id=""
                    data-status="<?= $row['status_attr'] ?>"
                    data-attach-target="<?= $row['attach_target_attr'] ?>"
                    data-version="<?= $row['version_attr'] ?>"
                    data-hook-type="<?= $row['hook_type_attr'] ?>"
                    data-mode="<?= $row['mode_attr'] ?>"
                    data-pre-attach-params="<?= $row['pre_attach_params_json'] ?>">
                    <td>
                        <b><?= $row['name_attr'] ?></b>
                        <span class="ebpf-version-tag">v<?= $row['version_attr'] ?></span>
                    </td>
                    <td><?= $row['status_html'] ?></td>
                    <td><?= $row['type_html'] ?></td>
                    <td><span class="ebpf-info-tag"><?= $row['hook_type_attr'] ?></span></td>
                    <td>
                        <button class="std-btn ebpf-info-btn"
                                data-identifier="<?= $row['identifier_attr'] ?>"
                                data-is-instance="0">Info</button>
                        <?php if ($row['loadable']): ?>
                        <button class="std-btn ebpf-btn-action ebpf-load-btn-js"
                                data-module="<?= $row['name_attr'] ?>">Load</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
