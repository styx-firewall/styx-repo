<?php
/**
 * eBPF fragment: foreign programs, conflicts, coexisting sections.
 *
 * @var array $tdata - $tdata['tpl_data'] contains the full formatted page data
 */
$pd = $tdata['tpl_data'] ?? [];
$hasNewForeign = $pd['has_new_foreign'] ?? false;
$canWrite = $pd['can_write'] ?? false;
?>

<!-- Styx Internal Programs -->
<?php if ($pd['has_internal'] ?? false): ?>
<div id="ebpf-internal-section" class="ebpf-section ebpf-collapsible-section">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-internal-body">
        <span class="ebpf-section-title">Styx Internal</span>
        <span id="ebpf-internal-count" class="ebpf-count-badge"><?= $pd['internal_count'] ?></span>
        <span class="ebpf-collapse-arrow">▼</span>
    </div>
    <div id="ebpf-internal-body" class="ebpf-collapse-body hidden">
        <table id="ebpf-internal-table" class="ebpf-module-table">
            <thead><tr><th>ID</th><th>Type</th><th>Name</th><th>Tag</th><th>Loaded At</th><th>UID</th></tr></thead>
            <tbody>
                <?php foreach ($pd['internal_rows'] as $ir): ?>
                <tr>
                    <td><?= $ir['id_html'] ?></td>
                    <td><?= $ir['type_html'] ?></td>
                    <td><?= $ir['name_html'] ?></td>
                    <td class="ebpf-mono"><?= $ir['tag_html'] ?></td>
                    <td><?= $ir['loaded_at_html'] ?></td>
                    <td><?= $ir['uid_html'] ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Foreign Programs -->
<?php if ($pd['has_foreign'] ?? false): ?>
<div id="ebpf-foreign-section" class="ebpf-section ebpf-collapsible-section">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-foreign-body">
        <span class="ebpf-section-title">Foreign Programs</span>
        <span id="ebpf-foreign-count" class="ebpf-count-badge"><?= $pd['foreign_count'] ?></span>
        <?php if ($hasNewForeign): ?>
        <span id="ebpf-foreign-new-badge" class="ebpf-new-badge--warn">WARNING</span>
        <?php endif; ?>
        <span class="ebpf-collapse-arrow">▼</span>
    </div>
    <div id="ebpf-foreign-body" class="ebpf-collapse-body hidden">
        <?php if ($hasNewForeign): ?>
        <div id="ebpf-foreign-ack-bar" class="ebpf-ack-bar">
            <span class="ebpf-ack-bar-text">⚠ Unrecognized BPF programs detected</span>
            <button id="ebpf-ack-all-btn" class="std-btn ebpf-btn-ack-all" type="button">Acknowledge All</button>
        </div>
        <?php endif; ?>
        <table id="ebpf-foreign-table" class="ebpf-module-table">
            <thead><tr><th>ID</th><th>Type</th><th>Name</th><th>Tag</th><th>Loaded At</th><th>UID</th><?php if ($canWrite): ?><th>Actions</th><?php endif; ?></tr></thead>
            <tbody>
                <?php foreach ($pd['foreign_rows'] as $fr): ?>
                <tr<?= $fr['row_class_attr'] ?>>
                    <td><?= $fr['id_html'] ?></td>
                    <td><?= $fr['type_html'] ?></td>
                    <td><?= $fr['name_html'] ?></td>
                    <td class="ebpf-mono"><?= $fr['tag_html'] ?></td>
                    <td><?= $fr['loaded_at_html'] ?></td>
                    <td><?= $fr['uid_html'] ?></td>
                    <?php if ($canWrite): ?>
                    <td>
                        <?php if ($fr['detachable'] ?? false): ?>
                        <button class="std-btn ebpf-detach-btn"
                                data-program-id="<?= $fr['id_attr'] ?>"
                                data-program-name="<?= $fr['name_attr'] ?>"
                                data-program-type="<?= $fr['type_attr'] ?>"
                                data-is-xdp="<?= $fr['is_xdp_attr'] ?>"
                                type="button">Detach</button>
                        <?php else: ?>
                        <button class="std-btn ebpf-detach-btn ebpf-detach-btn--disabled"
                                title="Manual detach required - use bpftool"
                                disabled
                                type="button">Detach</button>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Stale Components -->
<?php if ($pd['has_stale'] ?? false): ?>
<div id="ebpf-stale-section" class="ebpf-section ebpf-collapsible-section">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-stale-body">
        <span class="ebpf-section-title ebpf-section-title--warn">&#9888; Stale Components</span>
        <span id="ebpf-stale-count" class="ebpf-count-badge ebpf-count-badge--warn"><?= $pd['stale_count'] ?></span>
        <span class="ebpf-collapse-arrow">&#9660;</span>
    </div>
    <div id="ebpf-stale-body" class="ebpf-collapse-body hidden">
        <div class="ebpf-ack-bar">
            <span class="ebpf-ack-bar-text">
                Leftovers from an earlier generation of a Styx module: they still run on the
                interface next to the current program, and no instance owns them.
                They are removed automatically on the next restart.
            </span>
        </div>
        <table id="ebpf-stale-table" class="ebpf-module-table">
            <thead><tr><th>ID</th><th>Name</th><th>Interface</th><th>Priority</th><th>Current ID</th><?php if ($canWrite): ?><th>Actions</th><?php endif; ?></tr></thead>
            <tbody>
                <?php foreach ($pd['stale_rows'] as $sr): ?>
                <tr>
                    <td><?= $sr['id_html'] ?></td>
                    <td><?= $sr['name_html'] ?></td>
                    <td><?= $sr['interface_html'] ?></td>
                    <td><?= $sr['prio_html'] ?></td>
                    <td><?= $sr['current_id_html'] ?></td>
                    <?php if ($canWrite): ?>
                    <td>
                        <button class="std-btn ebpf-stale-detach-btn"
                                data-program-id="<?= $sr['id_attr'] ?>"
                                data-program-name="<?= $sr['name_attr'] ?>"
                                data-iface="<?= $sr['interface_attr'] ?>"
                                type="button">Detach</button>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Loaded instances with no program on the interface -->
<?php if ($pd['has_missing'] ?? false): ?>
<div id="ebpf-missing-section" class="ebpf-section ebpf-collapsible-section">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-missing-body">
        <span class="ebpf-section-title ebpf-section-title--warn">&#9888; Not Attached</span>
        <span id="ebpf-missing-count" class="ebpf-count-badge ebpf-count-badge--warn"><?= $pd['missing_count'] ?></span>
        <span class="ebpf-collapse-arrow">&#9660;</span>
    </div>
    <div id="ebpf-missing-body" class="ebpf-collapse-body hidden">
        <div class="ebpf-ack-bar">
            <span class="ebpf-ack-bar-text">
                Loaded instances whose program is not on its interface: the datastore says
                they are loaded and they filter nothing. The gateway puts them back by
                itself, at boot and after every load; to do it right now, open the
                instance's Info panel above and use Reload. An interface that no longer
                exists is reported and left alone.
            </span>
        </div>
        <table id="ebpf-missing-table" class="ebpf-module-table">
            <thead><tr><th>Module</th><th>Interface</th><th>Program ID</th><th>Reason</th><th>Instance</th></tr></thead>
            <tbody>
                <?php foreach ($pd['missing_rows'] as $mr): ?>
                <tr>
                    <td><?= $mr['module_html'] ?></td>
                    <td><?= $mr['interface_html'] ?></td>
                    <td><?= $mr['program_id_html'] ?></td>
                    <td><?= $mr['reason_html'] ?></td>
                    <td class="ebpf-mono"><?= $mr['instance_html'] ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Unmanaged Programs -->
<?php if ($pd['has_unmanaged'] ?? false): ?>
<div id="ebpf-unmanaged-section" class="ebpf-section ebpf-collapsible-section">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-unmanaged-body">
        <span class="ebpf-section-title ebpf-section-title--warn">&#9888; Unmanaged Programs</span>
        <span id="ebpf-unmanaged-count" class="ebpf-count-badge ebpf-count-badge--warn"><?= $pd['unmanaged_count'] ?></span>
        <span class="ebpf-collapse-arrow">&#9660;</span>
    </div>
    <div id="ebpf-unmanaged-body" class="ebpf-collapse-body hidden">
        <div class="ebpf-ack-bar">
            <span class="ebpf-ack-bar-text">
                Carry a Styx module's name and no instance owns them: what that proves is
                ownership, not attachment, so a leftover may still be filtering. Detaching
                one follows the same per-type path as a foreign program, and the
                confirmation says what each type removes. Seeing any usually means a
                duplicated load left a leftover behind, so treat it as a regression alarm
                and check the log around this event.
            </span>
        </div>
        <table id="ebpf-unmanaged-table" class="ebpf-module-table">
            <thead><tr><th>ID</th><th>Type</th><th>Name</th><th>Tag</th><th>Loaded At</th><th>UID</th><?php if ($canWrite): ?><th>Actions</th><?php endif; ?></tr></thead>
            <tbody>
                <?php foreach ($pd['unmanaged_rows'] as $ur): ?>
                <tr>
                    <td><?= $ur['id_html'] ?></td>
                    <td><?= $ur['type_html'] ?></td>
                    <td><?= $ur['name_html'] ?></td>
                    <td class="ebpf-mono"><?= $ur['tag_html'] ?></td>
                    <td><?= $ur['loaded_at_html'] ?></td>
                    <td><?= $ur['uid_html'] ?></td>
                    <?php if ($canWrite): ?>
                    <td>
                        <?php if ($ur['detachable'] ?? false): ?>
                        <button class="std-btn ebpf-detach-btn"
                                data-program-id="<?= $ur['id_attr'] ?>"
                                data-program-name="<?= $ur['name_attr'] ?>"
                                data-program-type="<?= $ur['type_attr'] ?>"
                                data-is-xdp="<?= $ur['is_xdp_attr'] ?>"
                                type="button">Detach</button>
                        <?php else: ?>
                        <button class="std-btn ebpf-detach-btn ebpf-detach-btn--disabled"
                                title="Manual detach required - use bpftool"
                                disabled
                                type="button">Detach</button>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Conflicts -->
<?php if ($pd['has_conflicts'] ?? false): ?>
<div id="ebpf-conflicts-section" class="ebpf-section ebpf-collapsible-section">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-conflicts-body">
        <span class="ebpf-section-title ebpf-section-title--warn">⚠ Conflicts</span>
        <span id="ebpf-conflicts-count" class="ebpf-count-badge ebpf-count-badge--warn"><?= $pd['conflict_count'] ?></span>
        <span class="ebpf-collapse-arrow">▼</span>
    </div>
    <div id="ebpf-conflicts-body" class="ebpf-collapse-body hidden">
        <table id="ebpf-conflicts-table" class="ebpf-module-table">
            <thead><tr><th>Interface</th><th>Hook</th><th>Styx Module</th><th>Occupied By</th></tr></thead>
            <tbody>
                <?php foreach ($pd['conflict_rows'] as $cr): ?>
                <tr>
                    <td><?= $cr['interface_html'] ?></td>
                    <td><?= $cr['hook_html'] ?></td>
                    <td><?= $cr['styx_module_html'] ?></td>
                    <td><?= $cr['occupied_by_html'] ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Coexisting -->
<?php if ($pd['has_coexisting'] ?? false): ?>
<div id="ebpf-coexisting-section" class="ebpf-section ebpf-collapsible-section">
    <div class="ebpf-section-header ebpf-collapse-toggle" data-target="ebpf-coexisting-body">
        <span class="ebpf-section-title">Coexisting</span>
        <span id="ebpf-coexisting-count" class="ebpf-count-badge"><?= $pd['coexisting_count'] ?></span>
        <span class="ebpf-collapse-arrow">▼</span>
    </div>
    <div id="ebpf-coexisting-body" class="ebpf-collapse-body hidden">
        <table id="ebpf-coexisting-table" class="ebpf-module-table">
            <thead><tr><th>Interface</th><th>Hook</th><th>Styx Module</th><th>Other Programs</th></tr></thead>
            <tbody>
                <?php foreach ($pd['coexisting_rows'] as $cr): ?>
                <tr>
                    <td><?= $cr['interface_html'] ?></td>
                    <td><?= $cr['hook_html'] ?></td>
                    <td><?= $cr['styx_module_html'] ?></td>
                    <td><?= $cr['others_html'] ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php
// Client-side <template> blocks for the modal bodies: cloned and filled via
// textContent in scripts/ebpf/ebpf.js (no string-built HTML, so a program or
// module name can never be parsed as markup).
?>
<template id="ebpf-foreign-detach-tpl">
    <p>Detach BPF program <b class="js-program-name"></b> (id=<span class="js-program-id"></span>, type=<span class="js-program-type"></span>)?</p>
    <p class="ebpf-info-text hidden js-msg-xdp">This will remove the XDP program from the interface.</p>
</template>

<template id="ebpf-stale-detach-tpl">
    <p>Remove stale component <b class="js-program-name"></b> (id=<span class="js-program-id"></span>) from <b class="js-iface"></b>?</p>
    <p class="ebpf-info-text">Only this leftover is removed. The current program and every other module keep running.</p>
</template>

<template id="ebpf-module-action-tpl">
    <p><span class="js-verb"></span> <b class="js-module-name"></b>?</p>
</template>
