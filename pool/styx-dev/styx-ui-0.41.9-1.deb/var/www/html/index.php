<?php
['ctx' => $ctx, 'cfg' => $cfg] = require __DIR__ . '/bootstrap/bootstrap.php';

use App\Core\AppContext;
use App\Controllers\Web;

$web = new Web($ctx);
$web->run();