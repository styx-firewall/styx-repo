#!/usr/bin/env python3
"""Upgrade packages, reboot, and verify the target is back online.

Per target the flow is:

  1. request("sys_get_apps")                 -- installed apps list
  2. request("sys_get_upgradable_packages")  -- upgrade-candidate list
  3. submit("upgrade-packages", run_update_first=True)   # async: returns task_id
  4. submit("system-reboot")                  # "System is rebooting"
  5. sleep 20 s and then ping every 5 s (action `ping`) until the target answers,
     for at most 60 s: it is "online" when a ping gets a `pong` back (with
     `client_timestamp` echoed and, when `uptime=true`, both system/styx
     uptimes). If the window closes without a pong, the target is marked FAIL.
     Each attempt prints how long it has been waiting.

Step 5 only runs if every prior step succeeded for that target; a failure
at any step stops that target and it is marked FAIL.

``--target`` is required, but the pseudo-value ``all`` means "every target in
the config's ``targets`` map". It is implemented here without touching the
apicore library: the script just iterates ``targets(cfg)`` and reuses
``resolve_target(cfg, name)`` per target (``resolve_target`` only handles a
single name, so the ``all`` expansion lives in this script).

Usage:
    python api_test/deploy/upgrade_and_reboot.py --target NAME
    python api_test/deploy/upgrade_and_reboot.py --target all
"""

import argparse
import os
import sys
import time

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiClient, ApiError, get, load_config, resolve_target, targets as target_names

# The wait after the reboot request: a floor before the first ping (the machine is
# always still down right after), then a bounded window of pings.
PING_WAIT_MIN = 20.0     # seconds before the first ping
PING_WAIT_WINDOW = 60.0  # seconds of pinging after that floor
PING_INTERVAL = 5.0      # seconds between pings


def _require(resp, step):
    """Assert resp is a success dict and move on; raise with a useful body otherwise."""
    if not isinstance(resp, dict) or resp.get("status") != "success":
        raise AssertionError(
            f"{step} failed: status={resp.get('status') if isinstance(resp, dict) else resp!r}, "
            f"msg={resp.get('response_msg') if isinstance(resp, dict) else None!r}"
        )
    return resp


def _summarise_apps(resp):
    """`sys_get_apps` returns `result.packages`, each item keyed by `package`."""
    packages = get(resp, "result.packages") or []
    names = [p.get("package") for p in packages if p.get("package")]
    # Sample only a few: this is an inventory of ~1000 packages, and the point
    # here is "the read answered", not the list itself (unlike the upgradable
    # list below, which is short and actionable).
    shown = ", ".join(names[:8]) + (", ..." if len(names) > 8 else "")
    return f"{len(packages)} installed" + (f" ({shown})" if shown else "")


def run_target(profile):
    """Run steps 1..5 against one target; raise on the first step that fails."""
    client = ApiClient(
        profile["base_url"],
        profile["bearer_token"],
        verify_tls=profile["verify_tls"],
        timeout=profile["timeout"],
    )
    resp = client.request("sys_get_apps")
    _require(resp, "sys_get_apps")
    print(f"  apps:            {_summarise_apps(resp)}")

    resp = client.request("sys_get_upgradable_packages")
    _require(resp, "sys_get_upgradable_packages")
    upgradable = get(resp, "result.packages") or []
    count = get(resp, "result.count")
    sec_count = get(resp, "result.security_count")
    total = count if count is not None else len(upgradable)
    sec = sec_count if sec_count is not None else 0
    samples = [p.get("name") for p in upgradable if p.get("name")]
    shown = ", ".join(samples[:40])
    print(f"  upgradable:      {total} total, security {sec}" + (f" ({shown})" if samples else ""))

    resp = client.submit("upgrade-packages", {"run_update_first": True})
    _require(resp, "upgrade-packages")
    task_id = get(resp, "result.task_id")
    print(f"  upgrade:         task={task_id} (run_update_first=True; async)")

    resp = client.submit("system-reboot", {})
    _require(resp, "system-reboot")
    print(f"  reboot:          {resp.get('response_msg', '')}")

    print(f"  waiting {PING_WAIT_MIN:.0f} s before first ping ({PING_WAIT_WINDOW:.0f} s window)...")
    pong = _wait_online(client)
    if pong is None:
        raise AssertionError(f"no pong within {PING_WAIT_MIN + PING_WAIT_WINDOW:.0f} s of the reboot")
    up = get(pong, "result.uptime") or {}
    sys_up, styx_up = up.get("system"), up.get("styx")
    print(f"  online:          pong (version={get(pong, 'result.version')}, "
          f"cpu_load={get(pong, 'result.cpu_load')}, "
          f"uptime system={sys_up}s, styx={styx_up}s)")
    return True


def _wait_online(client, minimum_wait=PING_WAIT_MIN, window=PING_WAIT_WINDOW, interval=PING_INTERVAL):
    """Sleep a floor of minimum_wait, then ping every ``interval`` seconds for at most
    ``window`` seconds, until the gateway answers with a pong; returns that first
    pong resp, or None if the window closed without one.

    The window is what bounds the verdict: the machine is normally still down
    when the first ping goes out, and the script has to answer "came back" or
    "did not" rather than hang. A request already in flight when the window
    closes can push the last attempt past it (by up to the client timeout).
    Each attempt prints the elapsed time since the reboot was submitted, so a
    run shows how much of the window the machine used.

    ``simple=True``  -> only liveness data (no tasks / no events);
    ``uptime=True``  -> include system/styx uptimes in the pong.
    """
    started = time.time()
    deadline = started + minimum_wait + window
    time.sleep(minimum_wait)
    attempt = 0
    while time.time() < deadline:
        attempt += 1
        elapsed = time.time() - started
        try:
            resp = client.request("ping", {"client_timestamp": time.time(), "simple": True, "uptime": True})
        except ApiError as e:
            print(f"    ping {attempt} (+{elapsed:.1f}s): no answer yet: {e}")
        else:
            status = get(resp, "status")
            if status == "success" and get(resp, "result.client_timestamp") is not None:
                print(f"    ping {attempt} (+{elapsed:.1f}s): pong")
                return resp
            print(f"    ping {attempt} (+{elapsed:.1f}s): no pong (status={status!r})")

        remaining = deadline - time.time()
        if remaining <= 0:
            break
        time.sleep(min(interval, remaining))
    return None


def resolve_names(cfg, target):
    """Expand 'all' to every target in the config; any other value must be an existing name."""
    names = target_names(cfg)
    if target == "all":
        if not names:
            raise ValueError("No targets in config; nothing to run.")
        return list(names)
    if target not in names:
        raise ValueError(f"Unknown target {target!r}. Available targets: {', '.join(names) or '-'}")
    return [target]


def main():
    p = argparse.ArgumentParser(
        description="Upgrade packages and reboot (list -> upgrade -> reboot), per target."
    )
    p.add_argument("--config", default=None, help="Path to config file (default: api_test/config.json)")
    p.add_argument("--target", required=True, help="Target name, or 'all' for every target in the config.")
    args = p.parse_args()

    cfg = load_config(args.config)
    names = resolve_names(cfg, args.target)

    failures = 0
    for name in names:
        try:
            profile = resolve_target(cfg, name)
        except ValueError as e:
            print(f"  FAIL  {name}: {e}")
            failures += 1
            continue
        print(f"Target: {name}")
        try:
            run_target(profile)
        except (ApiError, AssertionError) as e:
            failures += 1
            print(f"  FAIL  {name}: {e}")
    print(f"Done. {len(names) - failures} ok, {failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
