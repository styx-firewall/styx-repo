#!/usr/bin/env python3
"""Bad input must not be silently accepted by /request.php.

The counterpart to verify_readonly.py. That one asserts that every valid payload
succeeds; this one asserts that invalid input is answered with something that
says so. Both halves are needed: with only the success side, a required-key or
type check that gets deleted leaves the suite green.

Two lists, because the endpoints answer differently:

- ``REJECTS`` -- invalid payloads (a missing required key, a value of the wrong
  shape, a value out of range). The endpoint must refuse, naming the problem.
- ``ABSENT`` -- an identity that does not exist, of the right kind for each
  endpoint. Most refuse with a not-found message, but the two aggregating ones
  answer "partial": only the lookup command fails while the rest of the form data
  still comes back. Either way the outcome pins the payload key, because a
  renamed key means the value is never read and the outcome changes.

The ``REJECTS`` cases are all answered before the gateway is contacted. The
``ABSENT`` ones do reach it (a lookup that finds nothing); none of them writes
anything, so the run is read-only.

Usage:
    python api_test/consistency/verify_rejects.py --target NAME
"""

import os
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_fails, require_status
from api_test.apicore.verify_common import build_parser, build_client, finish

# Each entry: (label, action, data, substring the refusal message must contain)
REJECTS = [
    # Required payload keys left out
    ("network.get_valid_parents.no_subtype", "get_valid_parents", {}, "iface_subtype is required"),
    ("network.get_interface_config.no_iface", "get_interface_config", {}, "iface_id not provided"),
    ("ebpf.module_info.no_module", "ebpf_get_module_info", {}, "module is required"),
    ("ebpf.control_map.no_map", "ebpf_get_control_map", {"module": "m"}, "module and map are required"),
    ("discovery.get_host.no_ip", "discovery_get_host", {}, "ip is required"),
    (
        "dhcp.config_by_interface.no_iface",
        "dhcp-server.get_dhcp_config_by_interface",
        {},
        "interface_id is required",
    ),
    ("ethtool.iface_settings.no_iface", "ethtool-config.get_iface_settings", {}, "iface_id is required"),
    ("system.get_certificate.no_id", "get_certificate", {}, "id is required"),
    ("iperf.task_result.no_task", "iperf_get_task_result", {}, "task_id is required"),
    ("user.get_user_info.no_username", "get_user_info", {}, "No username provided"),
    ("firewall.edit_rule_form.no_rule", "fw_get_edit_rule_form", {}, "ruleId is required"),
    # Values of the wrong shape
    ("sets.ports.scopes_not_array", "get_ports", {"scopes": "ports"}, "scopes must be an array"),
    ("sets.full_sets.scopes_not_array", "getFullSets", {"scopes": "all"}, "scopes must be an array"),
    ("sets.address.scopes_not_array", "get_address", {"scopes": "all"}, "scopes must be an array"),
    (
        "firewall.rules.tableFilters_not_array",
        "fw_get_rules_forward",
        {"tableFilters": "filter"},
        "tableFilters must be an array",
    ),
    ("styx.events.filters_not_array", "styx_get_events", {"filters": "x"}, "filters must be an array"),
    ("traffic_stats.params_not_array", "traffic-stats-get", {"params": "summary"}, "params must be an array"),
    # Value ranges the endpoint restates on the backend's behalf
    ("telemetry.query.n_not_integer", "telemetry_query", {"n": "abc"}, "Invalid 'n'"),
    ("telemetry.query.n_not_positive", "telemetry_query", {"n": 0}, "Invalid 'n'"),
    (
        "telemetry.query.range_half_set",
        "telemetry_query",
        {"from_ts": 1},
        "from_ts and to_ts must be provided together",
    ),
    (
        "telemetry.query.range_inverted",
        "telemetry_query",
        {"from_ts": 2, "to_ts": 1},
        "from_ts must not be later than to_ts",
    ),
]

# An identity that does not exist, of the right kind for each endpoint. A fixed
# well-formed UUID, so the value is deterministic and cannot start existing.
ABSENT_UUID = "00000000-0000-4000-8000-000000000000"

# Each entry: (label, action, data, expected status, substring of the message)
#
# This is the coverage the success-only list cannot give these endpoints: they
# need a real object to be exercised, so they went unchecked, and they are the
# ones the API proxy consumes. An absent identity pins the payload key instead --
# rename the key and the value is never read, so the lookup never runs and the
# outcome changes -- without depending on any object existing.
ABSENT = [
    ("certs.get_certificate.unknown", "get_certificate", {"id": ABSENT_UUID}, "error", "Certificate not found"),
    ("ebpf.module_info.unknown", "ebpf_get_module_info", {"module": ABSENT_UUID}, "error", "Instance or module"),
    ("ebpf.telemetry.unknown", "ebpf_get_telemetry", {"module": ABSENT_UUID}, "error", "Instance"),
    (
        "ebpf.control_map.unknown",
        "ebpf_get_control_map",
        {"module": ABSENT_UUID, "map": "no-such-map"},
        "error",
        "Instance",
    ),
    (
        "ebpf.map_source.unknown",
        "ebpf_get_map_source",
        {"module": ABSENT_UUID, "map": "no-such-map"},
        "error",
        "Instance",
    ),
    (
        "dhcp.config_by_interface.unknown",
        "dhcp-server.get_dhcp_config_by_interface",
        {"interface_id": ABSENT_UUID},
        "error",
        "No DHCP config found",
    ),
    ("iperf.task_result.unknown", "iperf_get_task_result", {"task_id": ABSENT_UUID}, "error", "task not found"),
    # Existence here is decided by the interface inventory, not by the ethtool
    # store: an unknown id is an error with no iface object. A *real* interface
    # with no ethtool entry is a different case and stays success (managed: false,
    # families read from the NIC) -- that is legitimate information, and it used to
    # be indistinguishable from this one.
    (
        "ethtool.iface_settings.unknown_iface",
        "ethtool-config.get_iface_settings",
        {"iface_id": ABSENT_UUID},
        "error",
        "not found in configuration",
    ),
    # The message already said "not found"; what did not was the status.
    ("discovery.get_host.unknown_ip", "discovery_get_host", {"ip": "203.0.113.99"}, "error", "not found"),
    # These two aggregate several commands, so only the lookup fails: the status
    # is "partial", not "error", and the rest of the form data still arrives.
    ("firewall.edit_rule_form.unknown", "fw_get_edit_rule_form", {"ruleId": ABSENT_UUID}, "partial", None),
    ("network.get_interface_config.unknown", "get_interface_config", {"iface_id": ABSENT_UUID}, "partial", None),
]


def run(client, continue_on_fail):
    # Normalise both lists into (label, action, data, assertion) so the loop below
    # stays a single shape; the default args bind the values per iteration.
    cases = [
        (label, action, data, lambda r, s=sub: require_fails(r, s))
        for label, action, data, sub in REJECTS
    ] + [
        (label, action, data, lambda r, st=status, s=sub: require_status(r, st, s))
        for label, action, data, status, sub in ABSENT
    ]

    failures = 0
    for label, action, data, assertion in cases:
        try:
            assertion(client.request(action, data))
            print(f"  OK   {label}")
        except (ApiError, AssertionError) as e:
            print(f"  FAIL {label}: {e}")
            failures += 1
            if not continue_on_fail:
                break
    return failures


def main():
    p = build_parser("Refusal checks against /request.php")
    p.add_argument("--continue-on-fail", action="store_true", help="Keep going after a check fails")
    args = p.parse_args()
    client = build_client(args)
    failures = run(client, args.continue_on_fail)
    finish(failures)


if __name__ == "__main__":
    main()
