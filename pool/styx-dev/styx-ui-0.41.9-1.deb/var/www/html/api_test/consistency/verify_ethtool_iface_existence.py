#!/usr/bin/env python3
"""Existence for the ethtool settings endpoint is decided by the interface inventory.

`ethtool-config.get_iface_settings` takes an `iface_id`, and an id that is not in
`config_interfaces` is refused -- that side is pinned by verify_rejects.py. This
covers the other side, which a single-payload check cannot: an interface that
*does* exist but has no ethtool entry is legitimate information (`managed: false`,
its families read from the NIC), so it must be accepted. Deciding existence by the
ethtool store instead of by the inventory would refuse every interface nobody has
put under ethtool control -- the majority of them, not an edge case.

Cross-checks two endpoints, which is why it is a script and not a list entry: the
inventory defines what the settings endpoint must accept. Read-only.

Usage:
    python api_test/consistency/verify_ethtool_iface_existence.py --target NAME
"""

import os
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import build_parser, build_client, finish

SETTINGS_ACTION = "ethtool-config.get_iface_settings"
# The refusal that means "not in config_interfaces". Substring, not equality: the
# message carries the id, so it cannot be compared whole.
NOT_IN_CONFIG = "not found in configuration"


def run(client):
    inventory = require_ok(client.request("get_interfaces_names"), "result.interfaces")
    # Entries without an id are live kernel interfaces that are not configured
    # (the default gre/erspan/gretap/vti tunnels), so there is no id to send them.
    ifaces = [i for i in (inventory["result"].get("interfaces") or []) if i.get("id")]
    if not ifaces:
        raise AssertionError("no interface in the inventory carries an id; nothing to check")
    print(f"  OK   inventory returned {len(ifaces)} interface(s) with an id")

    managed = {True: 0, False: 0}
    for iface in ifaces:
        name, iface_id = iface.get("interface"), iface["id"]
        resp = client.request(SETTINGS_ACTION, {"iface_id": iface_id})
        if NOT_IN_CONFIG in str(resp.get("response_msg") or ""):
            raise AssertionError(
                f"{name} ({iface_id}) is in the inventory but was refused with "
                f"'{NOT_IN_CONFIG}': existence is being decided by the ethtool "
                f"store instead of by the interface inventory"
            )
        # Any other error is kept as-is: the id came from the inventory, so the
        # endpoint has no grounds to refuse it.
        require_ok(resp)
        managed[(resp.get("result") or {}).get("managed") is True] += 1

    # Reported, not asserted: the point is that an unmanaged interface is accepted,
    # and this is how much of that case the run actually exercised.
    print(
        f"  OK   all {len(ifaces)} accepted "
        f"(managed: {managed[True]} true, {managed[False]} false)"
    )


def main():
    args = build_parser("Verify that the interface inventory decides ethtool existence").parse_args()
    client = build_client(args)
    try:
        run(client)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
