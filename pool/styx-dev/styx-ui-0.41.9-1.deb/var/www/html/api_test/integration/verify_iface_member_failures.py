#!/usr/bin/env python3
"""Member-apply failures on virtual interfaces (bridges and bonds).

Verifies what the gateway does when the kernel refuses a member, and what it
does NOT do: the datastore entry must stay as it was, and the operation must
fail with a message naming the member. Covers the two behaviours:

  - create: a refused port aborts the creation and the device is removed again
  - in-place update: a refused port / a slave held by another master fails the
    update instead of being recorded as applied

How the refusal is provoked (probed on a live box, 2 kinds):
  - a bridge as the port of another bridge: the kernel answers
    "Can not enslave a bridge to a bridge"
  - a slave that is already a port of a bridge: the gateway itself refuses to
    steal it ("already enslaved to <master>")

All members are dummy interfaces created here and deleted at the end (undo log),
so no interface carrying traffic is touched. Safe to run repeatedly.

Note on the payloads: set_iface_config is called with the gateway's field name
("id"); the frontend accepts "iface_id" too and normalizes to a single "id"
before forwarding.

Usage:
    python api_test/integration/verify_iface_member_failures.py --target NAME
"""

import os
import secrets
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish


def run(client):
    tracker = ResourceTracker()
    sid = secrets.token_hex(3)
    remember = tracker.remember
    forget = tracker.forget
    failures = []

    def check(label, condition, detail=""):
        if condition:
            print(f"  OK   {label}")
        else:
            print(f"  FAIL {label} {detail}")
            failures.append(label)

    def create_iface(label, data):
        resp = require_ok(client.submit("create_virtual_interface", data), "result.id")
        rid = resp["result"]["id"]
        remember("delete_virtual_interface", {"id": rid})
        print(f"  OK   {label} (id={rid})")
        return rid

    def del_iface(label, rid):
        data = {"id": rid}
        require_ok(client.submit("delete_virtual_interface", data))
        forget("delete_virtual_interface", data)
        print(f"  OK   {label}")

    def entry(rid):
        """Datastore entry of one interface (raises if it is gone)."""
        resp = require_ok(client.request("get_interface_config", {"iface_id": rid}), "result.interface_config")
        return resp["result"]["interface_config"]

    def ds_names():
        """Interfaces known to the datastore only."""
        resp = require_ok(client.request("get_interfaces_names_ds"), "result.ifaces_list")
        return [i.get("interface") for i in resp["result"]["ifaces_list"]]

    def all_names():
        """Datastore entries plus OS virtual interfaces not in the datastore.

        The gateway appends the latter when listing interfaces, so absence here
        means the interface is neither configured nor present in the kernel.
        """
        resp = require_ok(client.request("get_interfaces_names"), "result.interfaces")
        return [i.get("interface") for i in resp["result"]["interfaces"]]

    def expect_error(label, resp, *needles):
        """The command must fail and say why, naming the member."""
        if resp.get("status") == "success":
            reason = f"(unexpected success: {resp.get('result')})"
            check(label, False, reason)
            return
        msg = str(resp.get("response_msg") or "")
        missing = [n for n in needles if n not in msg]
        check(label, not missing, f"(msg={msg!r} missing={missing})")

    d_port = f"vdp{sid}"  # dummy used as a bridge port (held by a master)
    d_free = f"vdf{sid}"  # dummy left free
    br_a = f"vba{sid}"  # bridge holding d_port
    br_b = f"vbb{sid}"  # bridge used for the in-place update test
    br_c = f"vbc{sid}"  # bridge whose creation must abort
    bond_x = f"vbo{sid}"

    try:
        # --- members that attach fine (control) ------------------------------
        d_port_id = create_iface(
            "create dummy (bridge port)", {"iface_subtype": "dummy", "iface_name": d_port, "status": "up"}
        )
        d_free_id = create_iface(
            "create dummy (free)", {"iface_subtype": "dummy", "iface_name": d_free, "status": "up"}
        )

        br_a_id = create_iface(
            "create bridge A with a dummy port",
            {"iface_subtype": "bridge", "iface_name": br_a, "status": "up", "ports": [d_port_id]},
        )
        br_b_id = create_iface(
            "create bridge B with a dummy port",
            {"iface_subtype": "bridge", "iface_name": br_b, "status": "up", "ports": [d_free_id]},
        )

        # --- create: a bridge cannot be a bridge port ------------------------
        resp = client.submit(
            "create_virtual_interface",
            {"iface_subtype": "bridge", "iface_name": br_c, "status": "up", "ports": [br_a_id]},
        )
        expect_error("create bridge C is refused (bridge as port)", resp, br_a)
        check(f"create aborted: {br_c} is not in the datastore", br_c not in ds_names())
        check(f"create aborted: {br_c} is not in the kernel either", br_c not in all_names())

        # --- in-place update: same refusal, entry must not change -----------
        before = entry(br_b_id)
        resp = client.submit(
            "set_iface_config", {"id": br_b_id, "ports": [d_free_id, br_a_id]}
        )
        expect_error("update bridge B is refused (bridge as port)", resp, br_a)
        after = entry(br_b_id)
        check(
            "update refused: bridge B ports unchanged",
            after.get("ports") == before.get("ports"),
            f"(before={before.get('ports')} after={after.get('ports')})",
        )
        check(
            "update refused: bridge B effective_ports unchanged",
            after.get("effective_ports") == before.get("effective_ports"),
            f"(before={before.get('effective_ports')} after={after.get('effective_ports')})",
        )
        br_a_now = entry(br_a_id)
        check(
            "update refused: the port was not stolen from bridge A",
            br_a_now.get("effective_ports") == [d_port],
            f"(bridge A effective_ports={br_a_now.get('effective_ports')})",
        )

        # --- bond update: a slave already held by another master ------------
        bond_id = create_iface(
            "create bond with a free slave",
            {"iface_subtype": "bond", "iface_name": bond_x, "status": "up", "slaves": [d_free_id]},
        )
        before = entry(bond_id)
        resp = client.submit(
            "set_iface_config", {"id": bond_id, "slaves": [d_free_id, d_port_id]}
        )
        expect_error("update bond is refused (slave held by a bridge)", resp, d_port, br_a)
        after = entry(bond_id)
        check(
            "update refused: bond slaves unchanged",
            after.get("slaves") == before.get("slaves"),
            f"(before={before.get('slaves')} after={after.get('slaves')})",
        )

        # --- control: a member-free update still applies and persists -------
        # (status, not mtu: an interface stored without an mtu ignores mtu
        # updates, which is a pre-existing behaviour unrelated to members)
        resp = client.submit("set_iface_config", {"id": bond_id, "status": "down"})
        check("control: a member-free update still succeeds", resp.get("status") == "success", f"({resp})")
        check("control: the update was persisted", entry(bond_id).get("status") == "down")

        # cleanup (children before parents: the undo log handles the order)
        del_iface("delete bond", bond_id)
        del_iface("delete bridge B", br_b_id)
        del_iface("delete bridge A", br_a_id)
        del_iface("delete dummy (free)", d_free_id)
        del_iface("delete dummy (bridge port)", d_port_id)

    finally:
        tracker.cleanup(client)
    return failures


def main():
    args = build_parser("Verify member-apply failures on bridges and bonds").parse_args()
    client = build_client(args)
    failures = []
    try:
        failures = run(client)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(len(failures))


if __name__ == "__main__":
    main()
