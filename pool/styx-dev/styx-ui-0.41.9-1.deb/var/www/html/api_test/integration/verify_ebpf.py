#!/usr/bin/env python3
"""Lifecycle verification for the eBPF modules, with the leftover invariant.

Flow: discover the interface -> snapshot the module list -> load a passive module
-> check it comes up attached -> deactivate and activate it -> unload it -> assert
that nothing of ours was left behind in the kernel.

The deactivate/activate pair covers the two commands the UI uses to stop and
resume an instance, RBAC included: they used to answer "Command not registered in
RBAC capability map" to everyone because they were missing from the capability
map.

The last step is the reason this exists. The interesting failure is not that load
or unload returns success, it is that a module can be reported as loaded while
its program is not on the interface, or that unloading leaves a program nobody
owns holding its maps. Both are invisible unless someone looks at the kernel, and
the module list already reports both over HTTP, so no shell on the target is
needed:

  * `unmanaged_programs` and `stale_components` must be exactly as they were
    before the load (a leftover of ours shows up in one of the two);
  * `missing_components` must not name the instance we just loaded, which is what
    would mean a module that loaded and did not attach;
  * `styx_program_count` must come back to its baseline.

The counters are not the whole net, so the last assertion is doubled by name. A
program of ours whose instance is gone is outside the ownership index, reads as a
stranger's and lands in `foreign_programs`, where it moves none of the counters
above -- and the baseline gate only rejects unmanaged/stale, so a leftover that was
already on the box before this run passes it too. Both the name check and every
counter are therefore read against the baseline: what fails the run is what this
run left behind, not what it found.

It also goes through submit.php and the registries, so it covers the frontend
path: a command can work at the gateway and still be unreachable from the UI
until it is registered.

What this does NOT cover: a detach done from outside the gateway (an `ip link set
xdp off` by hand, a driver reset), which is the other way a program of ours ends
up unowned. That needs a shell on the target and stays a manual check.

Caveats before pointing it at a box:
  * it mutates real kernel state, so run it on a lab;
  * attaching an XDP costs receive throughput on a virtio interface (measured
    around a third), so do not run it on a box that is passing traffic;
  * the module is passive on purpose: ddos_protect drops traffic while loaded.

Usage:
    python api_test/integration/verify_ebpf.py --target NAME [--interface if0]
"""

import os
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish

DEFAULT_INTERFACE = "if0"
MODULE = "ping_monitor"  # passive: an active module would drop traffic while loaded


def _snapshot(resp):
    """The four numbers the invariant is stated in."""
    result = resp["result"]
    return {
        "unmanaged": len(result.get("unmanaged_programs") or []),
        "stale": len(result.get("stale_components") or []),
        "missing": len(result.get("missing_components") or []),
        "styx_programs": result.get("styx_program_count", 0),
    }


def _our_kernel_names(client, available):
    """The kernel program names our modules use.

    Not `available[].name`: that is the module name, and the kernel entry carries
    the BPF function name, which differs for half the catalogue (net_block ->
    net_block_egress, mac_sniffer -> sniff_macs, bcc_counter -> count_packets,
    bcc_drop -> xdp_drop_ip). Intersecting against the module names would match
    nothing for those and report a green run. `module-info` is what exposes
    `bpf_fn_name`, and it answers for a module on disk whether or not it is
    loaded.

    A module whose descriptor cannot be read is skipped, not fatal: this is a
    detection net, and failing to *look* at one module must not fail the run.
    """
    names = set()
    for entry in available:
        module = entry.get("name") if isinstance(entry, dict) else None
        if not module:
            continue
        info = client.request("ebpf_get_module_info", {"module": module})
        if not isinstance(info, dict) or info.get("status") != "success":
            continue
        result = info.get("result") or {}
        names.add(result.get("bpf_fn_name") or module)
    return names


def _named_like_a_module(resp, catalogue):
    """Kernel programs named after one of our modules.

    The counters are not enough on their own. A program of ours whose instance is
    gone is no longer in the ownership index, so the scan cannot tell it apart
    from a stranger's and it lands in `foreign_programs` (or in
    `unmanaged_programs` if it has no owner at all): the counts move against a
    baseline that also includes systemd's cgroup programs, and a real leftover
    hides behind that noise. The name is what does not lie -- no other
    application names a program `ping_monitor`.
    """
    result = resp["result"]
    kernel = {p.get("name") for p in (result.get("foreign_programs") or []) if isinstance(p, dict)}
    kernel |= {p.get("name") for p in (result.get("unmanaged_programs") or []) if isinstance(p, dict)}
    # A program with no name in the payload is not a match, and None has to stay
    # out of the set: `{None} & catalogue` would fail the run with "the kernel
    # still holds a program of ours: [None]".
    kernel.discard(None)
    return sorted(kernel & catalogue)


def run(client, iface_name):
    tracker = ResourceTracker()

    def step(label, fn):
        fn()
        print(f"  OK   {label}")

    def module_list():
        return require_ok(client.request("ebpf_get_module_list"), "result.instances")

    try:
        # The load command takes an interface UUID, not a name.
        resp = require_ok(client.request("get_interfaces_names_ds"), "result.ifaces_list")
        iface_uuid = None
        for item in resp["result"]["ifaces_list"]:
            if item.get("interface") == iface_name and item.get("id"):
                iface_uuid = item["id"]
                break
        if iface_uuid is None:
            raise AssertionError(f"interface {iface_name} not found in get_interfaces_names_ds")
        print(f"  OK   {iface_name} = {iface_uuid}")

        before_list = module_list()
        before = _snapshot(before_list)
        print(f"  OK   baseline: {before}")
        if before["unmanaged"] or before["stale"]:
            # A dirty box says nothing about this test, and failing later with a
            # number that did not move is more confusing than saying it here.
            raise AssertionError(
                f"the box is not clean to start with ({before['unmanaged']} unmanaged, "
                f"{before['stale']} stale); clean those first, see api_test/consistency"
            )

        loaded = require_ok(
            client.submit("ebpf_load_module", {"module": MODULE, "interface": iface_uuid}),
            "result.instance_ids",
        )
        instance_ids = loaded["result"]["instance_ids"]
        if not instance_ids:
            raise AssertionError(f"load succeeded but returned no instance id: {loaded}")
        instance_id = instance_ids[0]
        # Undo by instance UUID: that is what unload takes, and it has to be armed
        # before the checks below so a failure still leaves the box clean.
        tracker.remember("ebpf_unload_module", {"module": instance_id})
        print(f"  OK   loaded {MODULE} as {instance_id}")

        after_load = module_list()
        listed = [i for i in after_load["result"]["instances"] if i.get("instance_id") == instance_id]
        if not listed:
            raise AssertionError(f"the instance is not in the module list: {instance_id}")
        if listed[0].get("status") != "loaded":
            raise AssertionError(f"the instance is listed as {listed[0].get('status')!r}, not 'loaded'")
        print("  OK   the instance is listed as loaded")

        missing_ids = {m.get("instance_id") for m in after_load["result"].get("missing_components") or []}
        if instance_id in missing_ids:
            raise AssertionError(
                "the module loaded and its program is not on the interface: this is the "
                "condition missing_components reports, and it means the box filters nothing"
            )
        print("  OK   the instance's program is attached")

        # Deactivate/activate: the pair the UI uses to stop and resume an instance.
        # It also covers the RBAC path of both commands, which is where they used to
        # answer "Command not registered in RBAC capability map" to everyone.
        step("deactivate", lambda: require_ok(client.submit("ebpf_deactivate_module", {"module": instance_id})))
        after_deactivate = module_list()
        suspended = [i for i in after_deactivate["result"]["instances"] if i.get("instance_id") == instance_id]
        if not suspended or suspended[0].get("status") != "suspended":
            raise AssertionError(
                f"a deactivated instance must stay in the list as 'suspended' (it keeps its "
                f"data and its UUID), got {suspended[0].get('status') if suspended else 'no entry'}"
            )
        if after_deactivate["result"].get("styx_program_count") != before["styx_programs"]:
            raise AssertionError(
                "deactivating must take the program out of the kernel: styx_program_count did not "
                "come back to its baseline"
            )
        print("  OK   deactivated: listed as suspended and its program is gone")

        step("activate", lambda: require_ok(client.submit("ebpf_activate_module", {"module": instance_id})))
        after_activate = module_list()
        reloaded = [i for i in after_activate["result"]["instances"] if i.get("instance_id") == instance_id]
        if not reloaded or reloaded[0].get("status") != "loaded":
            raise AssertionError(
                f"activating must bring the instance back in the same UUID, got "
                f"{reloaded[0].get('status') if reloaded else 'no entry'}"
            )
        missing_ids = {m.get("instance_id") for m in after_activate["result"].get("missing_components") or []}
        if instance_id in missing_ids:
            raise AssertionError("the instance came back as loaded but its program is not attached")
        print("  OK   activated: loaded again with its program attached")

        step("unload", lambda: require_ok(client.submit("ebpf_unload_module", {"module": instance_id})))
        tracker.forget("ebpf_unload_module", {"module": instance_id})

        after_list = module_list()
        after = _snapshot(after_list)
        print(f"  OK   after unload: {after}")
        for key in ("unmanaged", "stale", "missing", "styx_programs"):
            if after[key] != before[key]:
                raise AssertionError(
                    f"unload left something behind: {key} went from {before[key]} to {after[key]}. "
                    f"A program of ours with no owner shows up in unmanaged_programs or "
                    f"stale_components, and it keeps its maps until something releases it."
                )
        # By function name, not by module name: `available[].name` is the module
        # (net_block), the kernel entry carries its BPF function name
        # (net_block_egress), and the check must not go blind on the difference.
        catalogue = _our_kernel_names(client, after_list["result"].get("available") or [])
        if not catalogue:
            raise AssertionError(
                "no module answered with a bpf_fn_name, so the name check below can see nothing "
                "and would report a green run: check that ebpf_get_module_info answers (ebpf:read)."
            )
        # Relative to the baseline, like the counters above. A leftover of ours whose
        # instance is gone reads as a stranger's -- that is precisely the case this net
        # exists to catch -- so it sits in `foreign_programs`, which the baseline gate
        # does not look at: that one only rejects unmanaged/stale. Failing on it here
        # would blame this run for something it did not do, and no action in it could
        # have cleaned it up.
        already = _named_like_a_module(before_list, catalogue)
        if already:
            print(
                f"  WARN the box already held programs of ours outside the ownership index: "
                f"{already}. Nothing in this run caused that, and the check below is relative to it."
            )
        named = [
            name for name in _named_like_a_module(after_list, catalogue) if name not in already
        ]
        if named:
            raise AssertionError(
                f"the kernel still holds a program of ours after unloading: {named}. It is not in "
                f"unmanaged_programs or stale_components because the ownership index is built from "
                f"the loaded instances, so a leftover of an unloaded module reads as a stranger's "
                f"(foreign_programs). Check with `bpftool link show` / `bpftool prog show`."
            )
        print("  OK   nothing of ours was left behind")

    finally:
        tracker.cleanup(client)


def main():
    parser = build_parser("Verify eBPF module load/unload and that unload leaves no leftover")
    parser.add_argument(
        "--interface",
        default=DEFAULT_INTERFACE,
        help=f"interface to load on (default: {DEFAULT_INTERFACE})",
    )
    args = parser.parse_args()
    client = build_client(args)
    try:
        run(client, args.interface)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
