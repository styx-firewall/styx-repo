#!/usr/bin/env python3
"""Lifecycle verification for the users module (create → verify → delete).

Real flow against the HTTP API: creates a user account for real (unique
username per run, random password), verifies the account shows up in
``get_users`` and that ``get_user_info`` returns its data (gecos/shell),
then deletes it and asserts it is gone. Leaves no residual state.

Username rules enforced by the backend: starts with a letter, letters/
numbers/underscores/hyphens, max 32 chars; reserved system usernames are
rejected (vt-* names are safe).

Usage:
    python api_test/integration/verify_users.py --target NAME
"""

import os
import secrets
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish


def _username_in_list(action, users, username):
    return any(u.get("username") == username for u in users or [])


def run(client):
    tracker = ResourceTracker()  # undo log: borra pase lo que pase
    suffix = secrets.token_hex(4)
    username = f"vt-user-{suffix}"
    gecos = f"VT api test {suffix}"
    password = secrets.token_urlsafe(18)

    # create
    require_ok(client.submit("add_user", {
        "username": username,
        "password": password,
        "gecos": gecos,
        "nologin": 0,
    }))
    tracker.remember("delete_user", {"username": username})
    print(f"  OK   add_user {username}")

    # verify: appears in get_users with the gecos we set
    resp = require_ok(client.request("get_users"), "result.users")
    users = resp["result"]["users"]
    if not _username_in_list("get_users", users, username):
        raise AssertionError(f"{username} not in get_users result.users")
    print("  OK   get_users lists the created user")

    # verify: get_user_info returns its data
    resp = require_ok(client.request("get_user_info", {"username": username}))
    info = resp.get("result")
    if info.get("username") != username:
        raise AssertionError(f"get_user_info username mismatch: {info!r}")
    if info.get("gecos") != gecos:
        raise AssertionError(f"get_user_info gecos mismatch: {info!r}")
    print("  OK   get_user_info (username/gecos match)")

    # delete + verify it is gone
    require_ok(client.submit("delete_user", {"username": username}))
    tracker.forget("delete_user", {"username": username})
    resp = require_ok(client.request("get_users"), "result.users")
    if _username_in_list("get_users", resp["result"]["users"], username):
        raise AssertionError(f"{username} still in get_users after delete_user")
    print(f"  OK   delete_user {username}")


def main():
    args = build_parser("Verify users module: add_user → get_users/get_user_info → delete_user").parse_args()
    client = build_client(args)
    try:
        run(client)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(0)


if __name__ == "__main__":
    main()
