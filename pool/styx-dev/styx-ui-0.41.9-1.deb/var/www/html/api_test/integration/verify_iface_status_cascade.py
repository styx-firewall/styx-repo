#!/usr/bin/env python3
"""Status cascade: bringing a parent up restores its children, and reports what
it could not restore.

The kernel does not bring virtual children back when a parent comes up, so the
gateway cascades: for every child configured as 'up' whose parent just came up,
it sets the child up. That cascade is best effort -- the parent's own status
change succeeds either way -- so a child left down must be reported in the
response, or the divergence is only visible in the log.

Requires the kernel and the datastore to disagree, which the API cannot produce
on its own (both sides are updated together): the divergence is forced here
out-of-band with `ip link` calls. Therefore this script MUST run ON the target
(not against a remote --target over HTTP) and it checks that before touching
anything: it creates the parent through the API and then verifies the device
shows up locally.

What it checks, with a dummy parent and two macvlan children (the parent must
be up to have macvlan children, so the cascade is triggered by a down -> up
cycle):
  - child A: device present but down  -> the cascade brings it up, no warning
  - child B: device deleted out-of-band -> the cascade fails, and the response
    names B (and only B) in its `children` warning

Leaves no residual state.

Usage (on the gateway box):
    python api_test/integration/verify_iface_status_cascade.py --target NAME
"""

import os
import secrets
import subprocess
import sys

if __package__ is None:  # run as a file (not via python -m): make api_test importable
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from api_test.apicore.api_client import ApiError, require_ok
from api_test.apicore.verify_common import ResourceTracker, build_parser, build_client, finish


def _ip(*args):
    """Run an `ip` command locally, returning (returncode, output)."""
    r = subprocess.run(["ip", *args], capture_output=True, text=True)
    return r.returncode, (r.stdout + r.stderr).strip()


def _link_exists(name):
    return _ip("link", "show", name)[0] == 0


def _link_is_up(name):
    """True when the device exists and is administratively up."""
    rc, out = _ip("link", "show", name)
    if rc != 0 or "<" not in out:
        return False
    # Flags are printed between < and >, e.g. <BROADCAST,MULTICAST,UP,LOWER_UP>
    flags = out.splitlines()[0].split("<", 1)[1].split(">", 1)[0].split(",")
    return "UP" in flags


def run(client):
    tracker = ResourceTracker()
    sid = secrets.token_hex(3)
    remember = tracker.remember
    forget = tracker.forget
    failures = []

    def check(label, condition, detail=""):
        if condition:
            print(f"  OK   {label}")
        else:
            print(f"  FAIL {label} {detail}")
            failures.append(label)

    def create_iface(label, data):
        resp = require_ok(client.submit("create_virtual_interface", data), "result.id")
        rid = resp["result"]["id"]
        remember("delete_virtual_interface", {"id": rid})
        print(f"  OK   {label} (id={rid})")
        return rid

    def del_iface(label, rid):
        data = {"id": rid}
        require_ok(client.submit("delete_virtual_interface", data))
        forget("delete_virtual_interface", data)
        print(f"  OK   {label}")

    def children_warning(resp):
        """The `children` warning of a set_iface_config response, or None.

        The frontend returns the gateway's per-command result nested under the
        command name, so the interface result is what carries the warnings.
        """
        cmd = (resp.get("result") or {}).get("set_iface_config") or {}
        warnings = (cmd.get("result") or {}).get("warnings") or []
        for w in warnings:
            if w.get("key") == "children":
                return w
        return None

    parent = f"cdp{sid}"
    child_ok = f"cdk{sid}"
    child_gone = f"cdg{sid}"

    try:
        # --- the divergence is forced locally: make sure we are on the target
        parent_id = create_iface(
            "create dummy parent", {"iface_subtype": "dummy", "iface_name": parent, "status": "up"}
        )
        if not _link_exists(parent):
            print(f"  FAIL cannot see {parent} in the local kernel: run this script ON the target")
            return ["not-on-target"]

        ok_id = create_iface(
            "create child A (macvlan, present)",
            {
                "iface_subtype": "macvlan",
                "iface_name": child_ok,
                "parent_iface": parent_id,
                "macvlan_mode": "bridge",
                "status": "up",
            },
        )
        gone_id = create_iface(
            "create child B (macvlan, to lose its device)",
            {
                "iface_subtype": "macvlan",
                "iface_name": child_gone,
                "parent_iface": parent_id,
                "macvlan_mode": "bridge",
                "status": "up",
            },
        )
        check("both children have a device", _link_exists(child_ok) and _link_exists(child_gone))

        # --- force the two divergences out-of-band --------------------------
        rc, out = _ip("link", "set", "dev", child_ok, "down")
        check("child A device set down locally", rc == 0, f"({out})")
        rc, out = _ip("link", "del", child_gone)
        check("child B device deleted locally", rc == 0 and not _link_exists(child_gone), f"({out})")

        # --- bounce the parent (down -> up): the cascade must report what it
        # could not do. The down step is needed because the cascade only runs on
        # a real transition, and the parent must be up to have macvlan children.
        down = client.submit("set_iface_config", {"id": parent_id, "status": "down"})
        check("parent can be brought down", down.get("status") == "success", f"({down})")
        resp = client.submit("set_iface_config", {"id": parent_id, "status": "up"})
        check("parent update succeeds (the cascade is best effort)", resp.get("status") == "success", f"({resp})")

        warning = children_warning(resp)
        if warning is None:
            check("the response carries a children warning", False, f"({resp})")
        else:
            check("the response carries a children warning", True)
            check(
                "the warning names child B only",
                warning.get("children") == [child_gone],
                f"(children={warning.get('children')} expected=[{child_gone}])",
            )
        check("the cascade did bring child A up", _link_is_up(child_ok))
        check("child B is still absent (nothing was invented)", not _link_exists(child_gone))

        # cleanup: B has no device, so it is deleted as an orphan entry
        del_iface("delete child B (orphan entry)", gone_id)
        del_iface("delete child A", ok_id)
        del_iface("delete dummy parent", parent_id)

    finally:
        tracker.cleanup(client)
    return failures


def main():
    args = build_parser("Verify the parent status cascade warning").parse_args()
    client = build_client(args)
    failures = []
    try:
        failures = run(client)
    except (ApiError, AssertionError) as e:
        print(f"FAIL: {e}")
        finish(1)
    finish(len(failures))


if __name__ == "__main__":
    main()
