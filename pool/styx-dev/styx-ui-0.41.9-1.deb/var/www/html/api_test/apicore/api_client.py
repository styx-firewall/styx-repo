#!/usr/bin/env python3
"""Common API client for the Styx HTTP API (request.php / submit.php).

Python mirror of the frontend's scripts/core/api-client.js. Pure stdlib, no
external dependencies (no requests, no curl, no jmespath).

Handles: config loading, JSON encoding, bearer auth, TLS, timeouts, a unified
error shape, and dry-run flag injection for submit commands.

The config uses named targets; each run selects one by name via
resolve_target() — there is no implicit default. Typical usage (run the api_test
scripts with `python -m` from the repo root so the package resolves):

    from api_test.apicore.api_client import load_config, resolve_target, ApiClient, require_ok, dump

    cfg = load_config()                          # api_test/config.json (gitignored)
    profile = resolve_target(cfg, "maquina2")    # {base_url, bearer_token, timeout, verify_tls}
    api = ApiClient(profile["base_url"], profile["bearer_token"],
                    verify_tls=profile["verify_tls"], timeout=profile["timeout"])

    resp = api.request("get_interfaces_sets")         # POST /request.php
    require_ok(resp, "result.interfaces")             # raises if status != success or key missing

    created = api.submit("set_port", {"name": "p1", "type": "single", "value_single": 443})
    preview = api.preview("set_port", {...})          # dry-run: validates, no real change
"""

import json
import os
import ssl
import urllib.error
import urllib.request


class ApiError(Exception):
    """Raised on network/timeout/transport failures. Carries HTTP status + raw body."""

    def __init__(self, message, status=None, body=None):
        super().__init__(message)
        self.status = status
        self.body = body


REQUIRED_KEYS = ("base_url", "bearer_token")
PLACEHOLDER_TOKEN = "REPLACE_WITH_TOKEN"


def _default_config_path():
    """Path to api_test/config.json — one level up from this module (api_test/apicore)."""
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(os.path.dirname(here), "config.json")


def load_config(path=None):
    """Load the raw API config. Defaults to config.json next to the api_test root.

    The config must use the named-target form: a ``targets`` map of
    name -> {base_url, bearer_token, ...}. Selecting and validating a specific
    target happens later in resolve_target(), so a config holding a target that
    is not yet filled in loads fine here.

    Raises FileNotFoundError if the file is missing and ValueError if it is
    malformed (not a JSON object) or has no non-empty ``targets`` map.
    """
    if path is None:
        path = _default_config_path()
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Config not found: {path}\n" "Copy config.example.json to config.json and fill in its targets."
        )
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    if not isinstance(cfg, dict):
        raise ValueError(f"Config {path} is not a JSON object (expected key/value pairs).")
    if not isinstance(cfg.get("targets"), dict) or not cfg["targets"]:
        raise ValueError(
            f"Config {path} has no non-empty 'targets' map.\n"
            'Expected: {"targets": {"<name>": {"base_url": ..., "bearer_token": ...}, ...}}\n'
            "See config.example.json for the expected shape."
        )
    return cfg


def targets(cfg):
    """Sorted target names from a loaded config (for messages / introspection)."""
    return sorted(cfg["targets"])


def _validate_profile(profile, label):
    """Raise ValueError if a selected target profile is unusable.

    Checks the required connection keys and the placeholder token from
    config.example.json. ``label`` scopes the message (e.g. "Target 'lab'").
    """
    missing = [k for k in REQUIRED_KEYS if not profile.get(k)]
    if missing:
        raise ValueError(
            f"{label} is missing required key(s): {', '.join(missing)}\n"
            "See config.example.json for the expected shape."
        )
    if profile["bearer_token"] == PLACEHOLDER_TOKEN:
        raise ValueError(
            f"{label} still has the placeholder bearer_token ({PLACEHOLDER_TOKEN!r}).\n"
            "Replace it with a real token (see config.example.json)."
        )


def resolve_target(cfg, name=None):
    """Resolve a config target by name into a usable ApiClient profile.

    Requires an explicit ``name`` — there is no implicit default. Returns a dict
    with base_url, bearer_token, timeout (default 15) and verify_tls
    (default False), validating only the selected target.

    Raises ValueError if no name is given, the name is unknown, or the selected
    target profile is unusable (missing keys / placeholder token).
    """
    available = targets(cfg)
    if name is None:
        raise ValueError("No target specified: pass --target <name>.\n" f"Available targets: {', '.join(available)}")
    if name not in cfg["targets"]:
        raise ValueError(f"Unknown target {name!r}. Available targets: {', '.join(available)}")
    profile = dict(cfg["targets"][name])
    profile.setdefault("timeout", 15)
    profile.setdefault("verify_tls", False)
    _validate_profile(profile, f"Target {name!r}")
    return profile


def _unverified_context():
    """SSL context that skips certificate validation (self-signed appliance)."""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


class ApiClient:
    """Minimal POST-only client for the Styx JSON API."""

    def __init__(self, base_url, bearer_token="", verify_tls=False, timeout=15):
        self.base_url = base_url.rstrip("/")
        self.bearer_token = bearer_token
        self.verify_tls = verify_tls
        self.timeout = timeout

    # transport

    def _post(self, endpoint, payload):
        req = urllib.request.Request(
            self.base_url + endpoint,
            data=json.dumps(payload).encode("utf-8"),
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.bearer_token}",
            },
        )
        context = None if self.verify_tls else _unverified_context()
        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=context) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                status = getattr(resp, "status", 200)
        except urllib.error.HTTPError as e:
            # The API returns JSON error envelopes even on HTTP errors
            raw = e.read().decode("utf-8", errors="replace")
            status = e.code
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                raise ApiError(f"HTTP {status} from {endpoint}", status=status, body=raw)
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise ApiError(f"Request to {self.base_url + endpoint} failed: {e}")

        if not raw:
            return {"status": "error", "response_msg": "Empty response"}
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            raise ApiError(f"Invalid JSON from {endpoint}", status=status, body=raw)

    # public API

    def request(self, action, data=None):
        """Query a read action on /request.php."""
        payload = dict(data or {})
        payload["action"] = action
        return self._post("/request.php", payload)

    def submit(self, command, data=None, dry_run=False):
        """Run a write command on /submit.php.

        dry_run=True injects ``"dry-run": true`` so the gateway validates the
        command (schema/logic) without applying real changes. Not every command
        supports it; see handlers/handler_client.py in the gateway.
        """
        payload = dict(data or {})
        payload["command"] = command
        if dry_run:
            payload["dry-run"] = True
        return self._post("/submit.php", payload)

    def preview(self, command, data=None):
        """Dry-run wrapper around submit(): validate without applying."""
        return self.submit(command, data, dry_run=True)

# assertion helpers


def get(resp, dotted):
    """Resolve a dotted path into the response dict (no jmespath needed)."""
    cur = resp
    for part in dotted.split("."):
        if isinstance(cur, dict) and part in cur and cur[part] is not None:
            cur = cur[part]
        else:
            return None
    return cur


def ok(resp, *keys):
    """True if resp has status 'success' and every dotted key is present (not None).

    Empty collections (``[]``, ``{}``, ``""``) count as present: an endpoint that
    returns an empty list is healthy. Scripts that need a non-empty value check it
    explicitly.
    """
    if not isinstance(resp, dict) or resp.get("status") != "success":
        return False
    return all(get(resp, k) is not None for k in keys)


def require_ok(resp, *keys):
    """Like ok() but raises AssertionError with the response body on failure."""
    if ok(resp, *keys):
        return resp
    raise AssertionError(
        "assertion failed (status=%r, keys=%r): %s"
        % (
            resp.get("status") if isinstance(resp, dict) else resp,
            keys,
            json.dumps(resp, ensure_ascii=False, indent=2),
        )
    )


def fails(resp, substring):
    """True if resp is a refusal whose ``response_msg`` contains ``substring``.

    The counterpart to ok(): that one asserts a request succeeded, this one
    asserts it was refused. Asserting the message, not just the status, is the
    point -- a refusal that does not say what is wrong is not much better than
    no refusal at all.
    """
    if not isinstance(resp, dict) or resp.get("status") != "error":
        return False
    return substring in str(resp.get("response_msg") or "")


def require_fails(resp, substring):
    """Like fails() but raises AssertionError with the response body on failure."""
    if fails(resp, substring):
        return resp
    raise AssertionError(
        "expected a refusal containing %r, got (status=%r, msg=%r)"
        % (
            substring,
            resp.get("status") if isinstance(resp, dict) else resp,
            resp.get("response_msg") if isinstance(resp, dict) else resp,
        )
    )


def require_status(resp, status, substring=None):
    """Assert resp carries ``status``, optionally with a message substring.

    For the endpoints whose correct answer to absent input is neither success nor
    a plain error: the aggregating ones return "partial" when the command that
    looks up the missing object fails while the rest of the form data still comes
    back. Asserting the status is what pins the payload key there -- a renamed key
    changes which commands fail, and with it the status.
    """
    if isinstance(resp, dict) and resp.get("status") == status:
        if substring is None or substring in str(resp.get("response_msg") or ""):
            return resp
    raise AssertionError(
        "expected status %r%s, got (status=%r, msg=%r)"
        % (
            status,
            "" if substring is None else " with msg containing %r" % substring,
            resp.get("status") if isinstance(resp, dict) else resp,
            resp.get("response_msg") if isinstance(resp, dict) else resp,
        )
    )


def dump(resp, indent=2):
    """Pretty-print a JSON response (handy for probing)."""
    print(json.dumps(resp, indent=indent, ensure_ascii=False))
