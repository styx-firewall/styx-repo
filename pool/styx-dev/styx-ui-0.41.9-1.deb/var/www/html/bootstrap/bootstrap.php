<?php
/**
 * Bootstrap file for the application.
 * Sets up error handling, autoloading, and session management.
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */

declare(strict_types=1);

if (PHP_VERSION_ID < 70300) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Styx requires PHP 7.3 or newer. Current version: " . PHP_VERSION;
    exit(1);
}

// Autoloader
require_once __DIR__ . '/../App/Autoloader.php';
App\Autoloader::register();

use App\Core\AppContext;
use App\Core\Config;
use App\Core\SessionManager;
use App\Core\ErrorHandler;
use App\Services\LogSystemService;
use App\Services\Filter;
use App\Services\TemplateService;
use App\Services\AuthService;
use App\Services\UserProfileService;

/**
 * Bootstrap the request and return what the entry points need.
 *
 * The body runs inside this closure so none of it leaks into the caller's scope:
 * as a plain script it used to drop its internals ($tz, $locale, $valid, $auth,
 * $profile, $msg, ...) into the global scope of whoever required it, and a name
 * collision there silently replaced the caller's variable with the bootstrap's —
 * that is what made the timezone/locale probes print the bootstrap's own values.
 * Requiring this file now only ever exports the array below.
 *
 * @return array{ctx: AppContext, cfg: Config}
 */
return (static function (): array {
    try {
        $ctx = AppContext::getInstance();

        // Config creation are captured by the central logger/error handler.
        ErrorHandler::register($ctx);

        $cfg = $ctx->get(Config::class);

        // Populate client timezone into the config so downstream code can read it.
        // Priority here: existing config value (if any) -> cookie `tz` (validated) -> fallback `UTC`.
        // This only fills the value when the config has none: the per-user profile
        // overrides it further down, once the session is started and the user is known.
        try {
            if ($cfg->get('client.timezone') === null) {
                $tz = 'UTC';
                $cookieTz = isset($_COOKIE['tz']) ? $_COOKIE['tz'] : null;
                if (!empty($cookieTz)) {
                    $valid = Filter::varTimezone($cookieTz);
                    if ($valid !== false) {
                        $tz = $valid;
                    }
                }
                $cfg->set('client.timezone', $tz);
            }
        } catch (Throwable $_) {
            // Fail-safe: do not break bootstrap if validation or cookie access errors occur.
            try { $cfg->set('client.timezone', 'UTC'); } catch (Throwable $__) {}
        }

        // Populate client locale into the config so downstream code can read it.
        // Priority here: existing config value (if any) -> cookie `tz_locale` (validated
        // against the ICU catalogue, not just its shape) -> fallback `en-US`.
        // Overridden by the per-user profile further down, like the timezone.
        try {
            if ($cfg->get('client.locale') === null) {
                $locale = 'en-US';
                $cookieLocale = isset($_COOKIE['tz_locale']) ? rawurldecode($_COOKIE['tz_locale']) : null;
                if (!empty($cookieLocale)) {
                    $valid = Filter::varLocale($cookieLocale);
                    if ($valid !== false) {
                        $locale = $valid;
                    }
                }
                $cfg->set('client.locale', $locale);
            }
        } catch (Throwable $_) {
            try { $cfg->set('client.locale', 'en-US'); } catch (Throwable $__) {}
        }

        $cfg->applyDebugSettings();

        // Configure and start session centrally
        if (!SessionManager::start($ctx, $cfg)) {
            $msg = '[BS] Failed to start session via SessionManager';
            try {
                $logger = $ctx->get(LogSystemService::class);
                if ($logger && $logger instanceof LogSystemService) {
                    $logger->error($msg);
                }
            } catch (Throwable $_) {
                // No direct error_log here; ErrorHandler handles fallback
            }
        }

        // Apply per-user profile settings (timezone, locale, debug).
        // Runs after session is started so username is readable.
        // Silently skipped if storage file is absent (no profile = use defaults).
        // The profile is a stored value, not a trusted one: timezone and locale are
        // validated exactly like the cookies above, and an unusable value is ignored
        // rather than written, which leaves the cookie/config value in place.
        try {
            $auth = $ctx->get(AuthService::class);
            $sessionUsername = $auth->getUsername();
            if ($sessionUsername !== null) {
                $profile = UserProfileService::readProfile($sessionUsername);
                if (!empty($profile['timezone'])) {
                    $validTz = Filter::varTimezone($profile['timezone']);
                    if ($validTz !== false) {
                        $cfg->set('client.timezone', $validTz);
                    }
                }
                if (!empty($profile['locale'])) {
                    $validLocale = Filter::varLocale($profile['locale']);
                    if ($validLocale !== false) {
                        $cfg->set('client.locale', $validLocale);
                    }
                }
                // `debug` is the one setting whose default is global: the config
                // says whether the app runs in debug, and the profile overrides it.
                // Hence array_key_exists() and not `?? false`: absent means "keep
                // the global", and collapsing it into false would switch debug off
                // for every user who ever saved a profile — the form always sends
                // the key, so even an untouched checkbox would disable it.
                if (array_key_exists('debug', $profile)) {
                    $cfg->set('client.debug', (bool)$profile['debug']);
                }
                // Re-apply debug settings now that the per-user value is loaded.
                $cfg->applyDebugSettings();
            }
        } catch (Throwable $_) {
            // Non-fatal: missing file or parse error; proceed with defaults.
        }

        return ['ctx' => $ctx, 'cfg' => $cfg];
    } catch (Throwable $e) {
        // If AppContext or Config can't be created/read, this is an unrecoverable
        // bootstrap error. Use a minimal, reliable fallback logger and die miserably.
        $msg = '[BS] Failed to initialize AppContext or read Config early: ' . $e->getMessage();
        error_log($msg);
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
        echo "Internal server error during bootstrap.";
        exit(1);
    }
})();
