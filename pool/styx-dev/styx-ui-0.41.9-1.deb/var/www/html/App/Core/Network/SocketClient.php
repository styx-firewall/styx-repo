<?php

/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 * v1.0
 */

/**
 * Communication protocol header (8 bytes, big-endian):
 * - Bytes 0-3: Payload length (uint32, big-endian)
 * - Byte 4: API version (uint8)  -  1..255
 * - Byte 5: Serialization format (uint8): 0 = JSON (UTF-8), 1 = MessagePack
 * - Bytes 6-7: Reserved / padding (uint16)  -  set to 0 for forward compatibility
 *
 * Receiver MUST read exactly 8 header bytes, then read `length` bytes of payload.
 * Payload interpretation depends on `format`. Operational max length defaults to 8388608 (8 MiB)
 * and MUST match config/styx_config.py in the backend. On oversized payloads the server sends an
 * immediate JSON error. Decoding errors must be returned using the same serialization format
 * received.
 */

namespace App\Core\Network;

class SocketClient
{
    private const API_VERSION = 1; // protocol API version (fits in uint8)
    private const MAX_PAYLOAD = 8388608; // 8 MiB -- must match config/styx_config.py (backend)
    private const CHUNK_SIZE = 4096;
    private string $host;
    private int $port;
    private ?\Socket $socket = null;
    private int $readTimeout = 10;
    private int $writeTimeout = 4;

    /** Last measured connect time in milliseconds (rounded), or null if not measured */
    private ?float $lastConnectMs = null;

    public function __construct(string $host, int $port)
    {
        if (!filter_var($host, FILTER_VALIDATE_IP) && !filter_var($host, FILTER_VALIDATE_DOMAIN)) {
            throw new \InvalidArgumentException('Invalid host format');
        }
        if ($port < 1 || $port > 65535) {
            throw new \InvalidArgumentException('Port must be between 1 and 65535');
        }

        $this->host = $host;
        $this->port = $port;
    }

    /**
     * Return last measured connect time in milliseconds, or null if not measured.
     */
    public function getLastConnectMs(): ?float
    {
        return $this->lastConnectMs;
    }

    /**
     * Set write timeout for socket write operations.
     *
     * @param int $seconds
     * @return self
     */
    public function setWriteTimeout(int $seconds): self
    {
        $this->writeTimeout = $seconds;
        return $this;
    }

    /**
     * Set read timeout for socket operations.
     *
     * @param int $seconds
     * @return self
     */
    public function setReadTimeout(int $seconds): self
    {
        $this->readTimeout = $seconds;
        return $this;
    }

    /**
     * Connect to the socket server
     *
     * @throws \Exception
     */
    public function connect(): void
    {
        try {
            $connectStart = microtime(true);

            $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
            if ($this->socket === false) {
                $error = socket_strerror(socket_last_error());
                throw new \RuntimeException('Socket creation failed: ' . $error, socket_last_error());
            }

            // Set socket timeouts: read and write operations
            // Read timeout (SO_RCVTIMEO) limits blocking time for socket_read
            socket_set_option($this->socket, SOL_SOCKET, SO_RCVTIMEO, [
                'sec' => $this->readTimeout,
                'usec' => 0
            ]);
            // Write timeout (SO_SNDTIMEO) limits blocking time for socket_write
            socket_set_option($this->socket, SOL_SOCKET, SO_SNDTIMEO, [
                'sec' => $this->writeTimeout,
                'usec' => 0
            ]);

            // Temporarily convert PHP warnings to ErrorException for this call only
            set_error_handler(function ($errno, $errstr, $errfile, $errline) {
                throw new \ErrorException($errstr, 0, $errno, $errfile, $errline);
            });
            try {
                $result = socket_connect($this->socket, $this->host, $this->port);
            } finally {
                restore_error_handler();
                $connectEnd = microtime(true);
                $this->lastConnectMs = round(($connectEnd - $connectStart) * 1000, 2);
            }

            if ($result === false) {
                $errNo = socket_last_error($this->socket);
                $error = socket_strerror($errNo);
                throw new \RuntimeException('Socket connection failed: ' . $error, $errNo);
            }
        } catch (\Throwable $e) {
            $this->disconnect();
            throw new \RuntimeException('Socket connection exception: ' . $e->getMessage(), $e->getCode(), $e);
        }
    }

    public function sendAndReceive(array $data, string $format = 'json'): array {
        try {
            $this->connect();

            // Serialize data according to the format
            if ($format === 'msgpack') {
                $payload = msgpack_pack($data);
                $formatByte = 0x01; // MessagePack
            } else {
                $payload = json_encode($data);
                if ($payload === false) {
                    throw new \InvalidArgumentException('Invalid JSON encoding: ' . json_last_error_msg());
                }
                $formatByte = 0x00; // JSON
            }

            // Header: 8 bytes (4 bytes length BE, 1 byte version, 1 byte format, 2 bytes reserved)
            $length = strlen($payload);
            if ($length > self::MAX_PAYLOAD) {
                throw new \RuntimeException('Payload exceeds maximum allowed length: ' . self::MAX_PAYLOAD);
            }

            $version = self::API_VERSION; // current API version
            $reserved = 0; // 2 bytes
            $header = pack('NCCn', $length, $version, $formatByte, $reserved);

            // Send header + payload
            if (socket_write($this->socket, $header . $payload) === false) {
                $err = socket_strerror(socket_last_error($this->socket));
                throw new \RuntimeException('Socket write failed: ' . $err);
            }

            // Read response
            $response = $this->readResponse();
            return $response;

        } catch (\Throwable $e) {
            throw new \RuntimeException('Socket sendAndReceive failed: ' . $e->getMessage(), $e->getCode(), $e);
        } finally {
            $this->disconnect();
        }
    }

    private function readResponse(): array {
        // Read 8-byte header: length (4 BE) | version (1) | format (1) | reserved (2)
        $header = $this->readSocket(8);
        if (strlen($header) < 8) {
            throw new \RuntimeException('Invalid header length or missing header. Communication rejected.');
        }

        $unpacked = unpack('Nlength/Cversion/Cformat/nreserved', $header);
        $length = $unpacked['length'];
        $version = $unpacked['version'];
        $format = $unpacked['format'];
        $reserved = $unpacked['reserved'];

        // Validate version is a valid uint8 API version (1..255)
        if ($version < 1 || $version > 255) {
            throw new \RuntimeException('Unsupported API version: ' . $version);
        }

        // Validate format supported
        if ($format !== 0x00 && $format !== 0x01) {
            throw new \RuntimeException('Invalid format byte in header. Communication rejected.');
        }

        // Validate reserved (must be 0 for forward compatibility)
        if ($reserved !== 0) {
            throw new \RuntimeException('Invalid reserved bytes in header. Communication rejected.');
        }

        // Enforce operational max length
        if ($length > self::MAX_PAYLOAD) {
            throw new \RuntimeException('Payload length exceeds configured maximum: ' . self::MAX_PAYLOAD);
        }

        // Read payload
        $payload = $this->readSocket($length);

        // Deserialize according to format
        if ($format === 0x01) { // MessagePack
            $data = @msgpack_unpack($payload);
            if ($data === null && $payload !== '') {
                throw new \UnexpectedValueException('MessagePack decode error');
            }
        } else { // JSON
            $data = json_decode($payload, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new \UnexpectedValueException('JSON decode error: ' . json_last_error_msg());
            }
        }

        return $data;
    }

    private function readSocket(int $length): string {
        $data = '';
        $remaining = $length;

        while ($remaining > 0) {
            $chunk = socket_read($this->socket, min($remaining, self::CHUNK_SIZE));
            if ($chunk === false) {
                throw new \RuntimeException('Socket read error: ' . socket_strerror(socket_last_error($this->socket)));
            }
            if ($chunk === '') {
                throw new \RuntimeException('Socket disconnected');
            }

            $data .= $chunk;
            $remaining -= strlen($chunk);
        }

        return $data;
    }

    /**
     * @return void
     */
    public function disconnect(): void
    {
        if ($this->socket !== null) {
            if (is_resource($this->socket) || $this->socket instanceof \Socket) {
                socket_close($this->socket);
            }
            $this->socket = null;
        }
    }

    public function __destruct()
    {
        $this->disconnect();
    }
}
