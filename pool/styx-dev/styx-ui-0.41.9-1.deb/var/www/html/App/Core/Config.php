<?php

namespace App\Core;

/**
 * Configuration loader and accessor.
 *
 * Formats accepted and behavior:
 * - Defaults: JSON file `config/config.defaults.json` contains the default
 *   configuration as a JSON object (nested structure is recommended).
 * - Override: a single JSON file `/etc/styx/styx-ui.json` may be present and,
 *   when readable, will be decoded and deep-merged over the defaults using
 *   `array_replace_recursive` (override wins).
 *
 * Notes:
 * - If the override file is absent, defaults remain in effect.
 * - Read/parse errors now throw exceptions so they are handled centrally
 *   by the application's `ErrorHandler`.
 * - `get($key, $default)` supports dot-notation for nested keys (recommended).
 *
 * State keys (computed per request, not configuration): they are written with
 * `set()` in just two places, and every reader relies on that having happened:
 * - `features`, `hostname`, `config_changed`, `restart_required` — written by
 *   `Web::run()` from the gateway's page-init response. They therefore exist on
 *   the HTML path only; on the API path the need has its own action (e.g.
 *   `get_sysctl_keys`), which is why readers there use a `?? []` default.
 * - `client.timezone`, `client.locale` — written by `bootstrap/bootstrap.php`
 *   from the cookie, then overridden by the per-user profile when it has them.
 * - `client.debug` — same, except the config value is its global default and the
 *   profile overrides it only when the profile carries the key.
 *
 * Usage examples:
 * - Nested key (recommended): `$cfg->get('gateway.host')` returns the value at
 *   `gateway -> host` in the merged configuration.
 * - Provide a default: `$cfg->get('gateway.timeout', 5)` returns `5` if missing.
 *
 * Example `config/config.defaults.json`
 */
class Config
{
    private AppContext $ctx;
    /*
    * @var array<string, mixed>
    */
    private array $config = [];
    /**
     * Default session configuration used to validate/merge user overrides.
     * @var array<string, mixed>
     */
    private array $defaultSession = [
        'cookie_name' => 'styx_session',
        'secure' => true,
        'http_only' => true,
        'samesite' => 'Lax',
        'lifetime_seconds' => 1800,
        'cookie_domain' => ''
    ];

    public function __construct(AppContext $ctx, $configPath = null)
    {
        $this->ctx = $ctx;
        // Determine defaults JSON file path (config/config.defaults.json)
        if ($configPath === null) {
            $configPath = dirname(__DIR__, 2) . '/config/config.defaults.json';
        }

        $defaults = [];
        if (is_file($configPath) && is_readable($configPath)) {
            $raw = @file_get_contents($configPath);
            if ($raw !== false) {
                $decoded = @json_decode($raw, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                    $defaults = $decoded;
                } else {
                    throw new \RuntimeException('[Config] JSON parse error in defaults file: ' . json_last_error_msg());
                }
            } else {
                throw new \RuntimeException('[Config] Failed to read defaults file: ' . $configPath);
            }
        } else {
            throw new \RuntimeException('[Config] Defaults file missing or unreadable: ' . $configPath);
        }

        // Optional system-wide JSON override. Default path is /etc/styx/styx-ui.json
        $overridePath = '/etc/styx/styx-ui.json';
        $overrides = [];
        if (is_file($overridePath) && is_readable($overridePath)) {
            $raw = @file_get_contents($overridePath);
            if ($raw !== false) {
                $decoded = @json_decode($raw, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                    $overrides = $decoded;
                } else {
                    throw new \RuntimeException('[Config] JSON parse error in ' . $overridePath . ': ' . json_last_error_msg());
                }
            } else {
                throw new \RuntimeException('[Config] Failed to read override file: ' . $overridePath);
            }
        }

        // Merge defaults and overrides (deep merge where overrides replace defaults)
        if (!empty($overrides)) {
            $this->config = array_replace_recursive($defaults, $overrides);
        } else {
            $this->config = $defaults;
        }

        // Validate and normalize configuration (will throw on critical problems)
        $this->validateAndNormalize();
    }

    /**
     * Validate and normalize configuration values, modifying $this->config in place.
     * This enforces expected keys/types for `session` and other obvious fields.
     * Throws InvalidArgumentException on unrecoverable configuration errors.
     *
     * @return void
     */
    private function validateAndNormalize(): void
    {
        // Ensure session section exists and is an array
        $session = $this->config['session'] ?? [];
        if (!is_array($session)) {
            throw new \InvalidArgumentException('Configuration `session` must be an object/array');
        }

        // Merge with defaults (override wins)
        $session = array_replace_recursive($this->defaultSession, $session);

        // Coerce types
        $session['secure'] = (bool)$session['secure'];
        $session['http_only'] = (bool)($session['http_only'] ?? true);
        $session['lifetime_seconds'] = (int)($session['lifetime_seconds'] ?? $this->defaultSession['lifetime_seconds']);

        // Normalize samesite to one of: Lax, Strict, None
        $s = strtolower((string)($session['samesite'] ?? $this->defaultSession['samesite']));
        if (!in_array($s, ['lax', 'strict', 'none'], true)) {
            throw new \InvalidArgumentException('Configuration `session.samesite` must be one of: Lax, Strict, None');
        }
        $session['samesite'] = ucfirst($s);

        // Ensure cookie_name is a non-empty string
        $session['cookie_name'] = (string)($session['cookie_name'] ?? $this->defaultSession['cookie_name']);
        if ($session['cookie_name'] === '') {
            throw new \InvalidArgumentException('Configuration `session.cookie_name` must be a non-empty string');
        }

        // cookie_domain may be empty string => treat as empty
        $session['cookie_domain'] = is_string($session['cookie_domain']) ? $session['cookie_domain'] : '';

        // Save back
        $this->config['session'] = $session;
    }

    public function get($key, $default = null)
    {
        // Support dot notation for nested keys: 'gateway.host'
        if (is_string($key) && strpos($key, '.') !== false) {
            $parts = explode('.', $key);
            $v = $this->config;
            foreach ($parts as $p) {
                if (!is_array($v) || !array_key_exists($p, $v)) {
                    return $default;
                }
                $v = $v[$p];
            }
            return $v;
        }

        return $this->config[$key] ?? $default;
    }

    /**
     * Return the validated session configuration as an array.
     * @return array<string,mixed>
     */
    public function getValidatedSession(): array
    {
        return $this->config['session'] ?? $this->defaultSession;
    }

    public function set($key, $value)
    {
        // Support dot-notation for nested keys when setting values, e.g. 'client.timezone'
        if (is_string($key) && strpos($key, '.') !== false) {
            $parts = explode('.', $key);
            $ref = &$this->config;
            foreach ($parts as $p) {
                if (!isset($ref[$p]) || !is_array($ref[$p])) {
                    $ref[$p] = [];
                }
                $ref = &$ref[$p];
            }
            $ref = $value;
            return;
        }

        $this->config[$key] = $value;
    }

    /**
     * Apply debug-related PHP settings according to `client.debug` config.
     * That value is the global default; the per-user profile overrides it in
     * bootstrap. Keeps decision logic centralized in the Config class so
     * bootstrap can remain concise.
     *
     * @return void
     */
    public function applyDebugSettings(): void
    {
        $isDebug = (bool)$this->get('client.debug', false);

        if ($isDebug) {
            ini_set('display_errors', '1');
            ini_set('display_startup_errors', '1');
            error_reporting(E_ALL);
        } else {
            ini_set('display_errors', '0');
            ini_set('display_startup_errors', '0');
            error_reporting(E_ALL);
        }
    }
}