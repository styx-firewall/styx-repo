<?php

namespace App\Helpers;

/**
 * Role-based access control helpers for the frontend.
 *
 * Capabilities follow the format "module:action" with glob-style wildcards:
 *   "firewall:*"    -  all actions on firewall
 *   "*:*"           -  everything (admin)
 *   "*:read"        -  read-only on all modules
 */
class RoleHelper
{
    /**
     * Check if a set of user capabilities satisfies a required capability.
     *
     * @param string[] $userCaps Capabilities assigned to the user (from login).
     * @param string   $required Single capability string (e.g. "firewall:write").
     * @return bool
     */
    public static function hasCapability(array $userCaps, string $required): bool
    {
        foreach ($userCaps as $cap) {
            if (self::matchCapability($cap, $required)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Match a user's capability glob against a required capability.
     *
     * @param string $userCap  Glob pattern (e.g. "firewall:*", "*:read").
     * @param string $required Exact capability (e.g. "firewall:write").
     * @return bool
     */
    public static function matchCapability(string $userCap, string $required): bool
    {
        $partsUser = explode(':', $userCap, 2);
        $partsReq  = explode(':', $required, 2);

        $userMod = $partsUser[0] ?? '';
        $userAct = $partsUser[1] ?? '';
        $reqMod  = $partsReq[0]  ?? '';
        $reqAct  = $partsReq[1]  ?? '';

        $modMatch = ($userMod === '*' || $userMod === $reqMod);
        $actMatch = ($userAct === '*' || $userAct === $reqAct);

        return $modMatch && $actMatch;
    }

    /**
     * Page required capability mapping.
     * Every page except login/logout must be listed here.
     */
    public const PAGE_CAPABILITIES = [
        'index'           => 'dashboard:read',
        'dashboard'       => 'dashboard:read',
        'network'         => 'network:read',
        'firewall'        => 'firewall:read',
        'vpn'             => 'vpn:read',
        'routing'         => 'routing:read',
        'traffic_shaping' => 'traffic_shaping:read',
        'packet_marking'  => 'packet_marking:read',
        'content_filter'  => 'content_filter:read',
        'services'        => 'services:read',
        'ha'              => 'ha:read',
        'objects'         => 'objects:read',
        'idsips'          => 'idsips:read',
        'ebpf'            => 'ebpf:read',
        'system'          => 'system:read',
        'styx'            => 'styx:read',
        'security'        => 'security:read',
        'users'           => 'users:read',
        'logs'            => 'logs:read',
    ];

    /**
     * Get the required capability for a page route.
     *
     * @param string $page Page route name.
     * @return string|null Required capability, or null if no restriction.
     */
    public static function getPageCapability(string $page): ?string
    {
        return self::PAGE_CAPABILITIES[$page] ?? null;
    }
}
