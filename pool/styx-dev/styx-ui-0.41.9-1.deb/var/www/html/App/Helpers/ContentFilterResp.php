<?php
/**
 * ContentFilterResp - canonical response shaping for the content filter modules.
 *
 * Shared by the `categories` and `web-filter` controllers: they are two gateway
 * modules (and two RBAC resources) but one UI group, and the shaping is identical.
 *
 * Both backends put the human message explicitly in `result.msg` (canonical
 * contract for new modules). The top-level `response_msg` is a legacy bridge
 * that is being removed, so this module never relies on it.
 *
 * @see api/handlers/categories.md
 * @see api/handlers/web_filter.md
 */
namespace App\Helpers;

class ContentFilterResp
{
    /**
     * Normalize a single per-command gateway response.
     *
     * Output: `{ status: success|error, result: <backend result + msg>, error_code? }`.
     * Never emits a top-level `response_msg`.
     *
     * @param array<string,mixed> $cmd
     * @return array<string,mixed>
     */
    public static function command(array $cmd): array
    {
        $ok  = ($cmd['status'] ?? '') === 'success';
        $res = is_array($cmd['result'] ?? null) ? $cmd['result'] : [];
        // Defensive fallback for central errors (FORBIDDEN/UNAUTHORIZED) that do
        // not originate in the handler; the canonical source is result.msg.
        if (!array_key_exists('msg', $res) && is_string($cmd['response_msg'] ?? null)) {
            $res['msg'] = $cmd['response_msg'];
        }
        $out = ['status' => $ok ? 'success' : 'error', 'result' => $res];
        if (!$ok && !empty($cmd['error_code'])) {
            $out['error_code'] = $cmd['error_code'];
        }
        return $out;
    }

    /**
     * Translate a framework/gateway/access error (no indexed command available)
     * into the same canonical shape.
     *
     * @return array<string,mixed>
     */
    public static function error(string $msg, ?string $errorCode = null): array
    {
        $out = ['status' => 'error', 'result' => ['msg' => $msg]];
        if ($errorCode !== null) {
            $out['error_code'] = $errorCode;
        }
        return $out;
    }

    /**
     * Resolve a single-command exchange: when processGwResp failed at framework
     * level (no commands indexed) use error(); when the command itself failed
     * (validation) use command() over the indexed response.
     *
     * @param array<string,mixed> $resp  result of BaseController::processGwResp()
     * @return array<string,mixed>
     */
    public static function single(array $resp, string $id): array
    {
        if (($resp['status'] ?? '') !== 'success') {
            return !empty($resp['commands'][$id])
                ? self::command($resp['commands'][$id])
                : self::error($resp['response_msg'] ?? 'Request failed', $resp['error_code'] ?? null);
        }
        $cmd = $resp['commands'][$id] ?? null;
        return $cmd ? self::command($cmd) : self::error('No response for ' . $id);
    }
}
