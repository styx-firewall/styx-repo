<?php
/**
 * NetIfaceCountersFormatter - the two per-interface counter panels of the interface
 * editor: what the KERNEL counts for the interface
 * (network-config.get_iface_counters) and what the NIC DRIVER publishes
 * (ethtool-config.get_iface_stats, `ethtool -S`).
 *
 * Both are **raw snapshots**: the cumulative counters as they arrived, no rates and no
 * refresh button. Rates are served elsewhere on purpose
 * (system-metrics.get_network_metrics samples them over a range with retention), and
 * the driver registers are a third accounting point which does not have to agree with
 * the kernel's - see api_front/network.md and api_front/ethtool.md.
 *
 * **The keys are not ours to know.** The kernel block is whatever `ip -j -s -s link
 * show` printed (nested `rx`/`tx` today, and the kernel is free to add to it), and the
 * driver's names are the NIC's own: virtio publishes `rx_kicks` / `rx_xdp_packets` /
 * `rx0_drops`, igb and mlx publish CRC, phy and per-queue counters. Nothing here is
 * matched against a fixed list, and **no key is ever dropped**: a counter that vanishes
 * from the panel in silence is the one failure this panel cannot afford, because the
 * operator opens it precisely when something looks wrong. The grouping is derived from
 * what arrived - nested keys for the kernel, the token before the first `_` for the
 * driver - and degrades to a single flat list when there is nothing to derive.
 *
 * One formatter for both panels, because everything below the envelope is the same
 * walk: the two answers differ in `present` vs `supported`/`read_error` and in the
 * pre-processing of the dictionary, and in nothing else.
 *
 * What is deliberately **not** here is a failure mark. Marking a non-zero `dropped` or
 * `crc_errors` would be right, and marking `rx_drops` on a virtio NIC (non-zero and
 * climbing on a healthy box) would teach the operator to ignore the mark - the same
 * reason the content filter's marks are a curated list. A zero is only dimmed.
 *
 * Templates are echo-only: every derived text, class and attribute is computed here.
 *
 * @see \App\Pages\PageNetwork
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class NetIfaceCountersFormatter
{
    /** The token a flat driver counter can be grouped by, before its first `_`. */
    private const PREFIX_RE = '/^[a-z]+\d*$/';

    /**
     * Names that count a **failure**: something the interface tried to do and could not.
     *
     * A pattern and not a list, because the driver's names are the driver's own - the
     * only thing that can travel across NICs is what the words mean. `error` covers
     * `rx_errors`, `rx_length_errors` and `over_errors`; `crc`/`frame`/`fifo`/`missed`
     * are the kernel's standard receive-failure counters; `discard` and `truncat` are
     * the driver saying it threw work away.
     */
    private const TONE_CRIT_RE = '/error|crc|fifo|frame|missed|discard|fail|truncat|no_buf|nobuf/i';

    /**
     * Names that are **worth a look**, not a verdict.
     *
     * `drop` is the word that made this distinction necessary: a non-zero `rx_dropped`
     * means the host could not take the packet on one driver and that an XDP program
     * decided to drop it on another, and the name does not say which. On the box this
     * was written against, a virtio NIC under an XDP program reports `rx_xdp_drops`
     * equal to `rx_drops` - the filter at work, on a healthy interface. A mark that is
     * red when nothing is wrong is a mark the operator learns to ignore.
     */
    private const TONE_WARN_RE = '/drop|collision/i';

    /** The heading for counters that arrive flat and cannot be split by prefix. */
    private const FLAT_TITLE = 'Counters';

    /** Where the numbers would be, when the interface has no place to count. */
    private const NOT_PRESENT = 'This interface is not present in the operating system, so it has no counters.';

    private const NO_COUNTERS = 'The kernel reported no counters for this interface.';

    /** The answer did not carry the interface that was asked for. */
    private const NOT_REPORTED = 'No counters were reported for this interface.';

    private const NO_DRIVER_STATS = 'This NIC publishes no driver counters.';

    /**
     * The kernel's answer: one interface entry, which counters, and whether the OS has
     * it at all.
     *
     * @param array<string,mixed> $result the `result` of the read
     * @param string              $ifaceId the interface asked for
     * @return array<string,mixed>
     */
    public static function formatKernel(array $result, string $ifaceId): array
    {
        $entries = [];
        foreach (is_array($result['ifaces'] ?? null) ? $result['ifaces'] : [] as $entry) {
            if (is_array($entry)) {
                $entries[] = $entry;
            }
        }

        // The read is asked for one interface, but the endpoint answers for every
        // interface when it is not: take the one that was asked for, never the first
        // one that happens to be in the list.
        $entry = null;
        foreach ($entries as $candidate) {
            if ((string)($candidate['iface_id'] ?? '') === $ifaceId) {
                $entry = $candidate;
                break;
            }
        }
        // An interface the datastore knows by name only carries no id to match on, and
        // a single-entry answer is that interface.
        if ($entry === null && count($entries) === 1) {
            $entry = $entries[0];
        }
        if ($entry === null) {
            return self::payload('', [], '', '', self::NOT_REPORTED);
        }

        $counters = is_array($entry['counters'] ?? null) ? $entry['counters'] : [];
        $name     = (string)($entry['iface_name'] ?? '');
        $mtu      = $entry['mtu'] ?? null;
        // The parts the answer did not carry are skipped: an absent interface has no
        // operstate and no MTU to report, and the line is then its name alone.
        $state = self::line([
            $name,
            (string)($entry['operstate'] ?? ''),
            is_numeric($mtu) ? 'MTU ' . $mtu : '',
        ]);

        // Read strictly: an answer that does not carry `present` has not said the
        // interface is absent, and what it did send is shown instead of a claim.
        if (array_key_exists('present', $entry) && empty($entry['present'])) {
            return self::payload($name, [], $state, '', self::NOT_PRESENT);
        }

        $groups = self::kernelGroups($counters);
        return self::payload($name, $groups, $state, '', $groups === [] ? self::NO_COUNTERS : '');
    }

    /**
     * The driver's answer: the NIC's own counters, or the reason it publishes none.
     *
     * `supported: false` is not an error - a bridge, a VLAN or a NIC whose driver
     * exposes nothing under `ethtool -S` answers that way - so it reads as a sentence,
     * with the driver's own `read_error` after it when there is one.
     *
     * @param array<string,mixed> $iface the read's `result` (the report, unwrapped)
     * @return array<string,mixed>
     */
    public static function formatDriver(array $iface): array
    {
        $name  = (string)($iface['iface_name'] ?? '');
        $state = self::line([$name, (string)($iface['type'] ?? '')]);

        if (empty($iface['supported'])) {
            $why = (string)($iface['read_error'] ?? '');
            return self::payload(
                $name,
                [],
                $state,
                '',
                $why !== '' ? self::NO_DRIVER_STATS . ' ' . $why : self::NO_DRIVER_STATS
            );
        }

        $counters = is_array($iface['counters'] ?? null) ? $iface['counters'] : [];
        $groups   = self::driverGroups($counters);
        return self::payload($name, $groups, $state, '', $groups === [] ? self::NO_DRIVER_STATS : '');
    }

    /**
     * A read that failed, as the message the panel shows instead of its table.
     *
     * One builder for both panels: the payload is the same shape and the panel is what
     * says which read it was.
     */
    public static function error(string $msg): array
    {
        return self::payload('', [], '', $msg, '');
    }

    /**
     * The usable sentence out of a failed single-command read.
     *
     * The gateway's own message arrives nested in `commands.<id>`, and the envelope's
     * `response_msg` prefixes it with "All gateway commands failed: <id>: " - which is
     * the right thing in a log and the wrong thing in a panel.
     *
     * @param array<string,mixed> $resp
     */
    public static function errorMessage(array $resp, string $cmdId, string $fallback): string
    {
        $commands = $resp['commands'] ?? null;
        $inner    = is_array($commands) ? ($commands[$cmdId]['response_msg'] ?? null) : null;
        if (is_string($inner) && $inner !== '') {
            return $inner;
        }
        $outer = $resp['response_msg'] ?? null;
        return is_string($outer) && $outer !== '' ? $outer : $fallback;
    }

    /**
     * The shape both panels' templates echo.
     *
     * @param array<int,array<string,mixed>> $groups
     * @return array<string,mixed>
     */
    private static function payload(string $ifaceName, array $groups, string $state, string $error, string $empty): array
    {
        $rows    = 0;
        $flagged = 0;
        foreach ($groups as $group) {
            foreach ($group['ncg_rows'] ?? [] as $row) {
                $rows++;
                if (!empty($row['ncr_flagged'])) {
                    $flagged++;
                }
            }
        }
        return [
            'nc_iface_name_esc' => self::esc($ifaceName),
            'nc_row_count'      => $rows,
            // Counted here, not in the template: with the box folded, this is the only
            // thing that says whether opening it is worth the click.
            'nc_flagged'        => $flagged,
            'nc_state_html'     => self::esc($state),
            'nc_load_error_esc' => self::esc($error),
            'nc_empty_note_esc' => self::esc($empty),
            'nc_groups'         => $groups,
        ];
    }

    /**
     * The kernel's block, as groups: one per nested piece (`rx`, `tx`), and a trailing
     * group for anything that arrived as a bare number.
     *
     * @param array<string,mixed> $counters
     * @return array<int,array<string,mixed>>
     */
    private static function kernelGroups(array $counters): array
    {
        $groups = [];
        $flat   = [];
        foreach ($counters as $key => $value) {
            $key = (string)$key;
            if (is_array($value) && $value !== [] && !array_is_list($value)) {
                $rows = [];
                self::collect($value, '', $rows);
                if ($rows !== []) {
                    $groups[] = self::group($key, $rows);
                }
                continue;
            }
            // A bare number, an empty block or a list: it still counts, so it goes to
            // the trailing group rather than nowhere.
            $flat[$key] = is_array($value) ? self::joined($value) : $value;
        }
        if ($flat !== []) {
            $groups[] = self::group(self::FLAT_TITLE, $flat);
        }
        return $groups;
    }

    /**
     * The driver's flat block, grouped by the token before the first `_`.
     *
     * `rx_drops`/`rx_kicks` land under `rx`, `rx0_drops`/`rx0_kicks` under `rx0`, and a
     * set that cannot be split (one prefix, or names that are not prefixed) stays as a
     * single flat list: a heading over one group is noise.
     *
     * @param array<string,mixed> $counters
     * @return array<int,array<string,mixed>>
     */
    private static function driverGroups(array $counters): array
    {
        $byPrefix = [];
        $other    = [];
        foreach ($counters as $name => $value) {
            $name    = (string)$name;
            $parts   = explode('_', $name, 2);
            $prefix  = count($parts) === 2 ? $parts[0] : '';
            if ($prefix !== '' && preg_match(self::PREFIX_RE, $prefix) === 1) {
                $byPrefix[$prefix][$name] = $value;
                continue;
            }
            $other[$name] = $value;
        }

        if (count($byPrefix) < 2) {
            $rows = [];
            self::collect($counters, '', $rows);
            return $rows === [] ? [] : [self::group('', $rows)];
        }

        $groups = [];
        foreach ($byPrefix as $prefix => $rows) {
            $groups[] = self::group($prefix, $rows);
        }
        if ($other !== []) {
            $groups[] = self::group(self::FLAT_TITLE, $other);
        }
        return $groups;
    }

    /**
     * One group: its heading (escaped; empty means the template draws none) and its
     * display rows.
     *
     * @param array<string,mixed> $rows raw name => value, in the order to show
     * @return array<string,mixed>
     */
    private static function group(string $title, array $rows): array
    {
        return [
            'ncg_title_esc' => self::esc($title),
            'ncg_rows'      => self::displayRows($rows),
        ];
    }

    /**
     * A block's leaves, in arrival order, nested pieces flattened with their path
     * (`rx / errors`) so that a deeper answer than expected loses no key.
     *
     * @param array<string,mixed> $data
     * @param array<string,mixed> $rows collected by reference
     */
    private static function collect(array $data, string $path, array &$rows): void
    {
        foreach ($data as $key => $value) {
            $key  = (string)$key;
            $leaf = $path === '' ? $key : $path . ' / ' . $key;
            if (is_array($value)) {
                if ($value === [] || array_is_list($value)) {
                    $rows[$leaf] = self::joined($value);
                    continue;
                }
                self::collect($value, $leaf, $rows);
                continue;
            }
            $rows[$leaf] = $value;
        }
    }

    /**
     * A list's scalars, joined into one cell: a list is a set of things the piece is
     * working with, not a measurement, but dropping it would hide a key.
     *
     * @param array<int,mixed> $values
     */
    private static function joined(array $values): string
    {
        $out = [];
        foreach ($values as $value) {
            if (is_array($value)) {
                return count($values) . ' items';
            }
            $out[] = self::cell($value);
        }
        return implode(', ', $out);
    }

    /**
     * One counter as the operator reads it: a number with its thousands separated, a
     * flag said out loud, `-` for a value that is not there, and the raw text for
     * anything else. Bytes are **not** scaled: the operator comparing two samples of
     * `bytes` wants the number, and scaling one counter of forty would be worse than
     * scaling none.
     *
     * @param mixed $value
     */
    private static function cell($value): string
    {
        if (is_bool($value)) {
            return $value ? 'on' : 'off';
        }
        if ($value === null) {
            return '-';
        }
        if (is_int($value)) {
            return number_format($value);
        }
        if (is_float($value)) {
            return (string)$value;
        }
        return is_scalar($value) ? (string)$value : '';
    }

    /**
     * @param array<string,mixed> $rows
     * @return array<int,array<string,string>>
     */
    private static function displayRows(array $rows): array
    {
        $out = [];
        foreach ($rows as $name => $value) {
            $text  = self::cell($value);
            // Both marks are decided on the **raw** value, never on the formatted cell:
            // "15,630" is not numeric to PHP, so testing the text would mark the small
            // numbers and miss exactly the big ones worth looking at.
            $number = is_int($value) || is_float($value) ? (float)$value : null;
            $tone   = $number === null ? '' : self::tone((string)$name, $number);
            $class  = 'nc-counter';
            if ($tone !== '') {
                $class .= ' nc-counter--' . $tone;
            } elseif ($number === 0.0) {
                // A zero is not news: on a wall of counters the ones that are moving are
                // the ones worth the ink. A marked counter is never zero, so the two
                // marks cannot collide.
                $class .= ' nc-counter--zero';
            }
            $out[] = [
                'ncr_name_esc'  => self::esc($name),
                'ncr_value_esc' => self::esc($text),
                // The complete class string, so the template writes it whole.
                'ncr_class'     => $class,
                'ncr_flagged'   => $tone !== '',
            ];
        }
        return $out;
    }

    /**
     * How loudly a counter is asking for attention: 'crit', 'warn', or '' for a number
     * that is only a number.
     *
     * A name has to mean something for this to say anything, and a number has to be
     * **not zero**: a zero `crc_errors` is the news that nothing failed.
     */
    private static function tone(string $name, float $number): string
    {
        if ($number == 0.0) {
            return '';
        }
        if (preg_match(self::TONE_CRIT_RE, $name) === 1) {
            return 'crit';
        }
        return preg_match(self::TONE_WARN_RE, $name) === 1 ? 'warn' : '';
    }

    /**
     * One quiet line of facts about the interface the numbers belong to, skipping the
     * parts the answer did not carry. Same shape as the ethtool panel's state line,
     * which sits in the same column.
     *
     * @param array<int,string> $parts
     */
    private static function line(array $parts): string
    {
        $out = [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part !== '') {
                $out[] = $part;
            }
        }
        return implode(' — ', $out);
    }

    /** Escaped text; a bool is said and anything else is not text at all. */
    private static function esc($value): string
    {
        if (is_bool($value)) {
            $value = $value ? 'true' : 'false';
        } elseif (!is_scalar($value)) {
            $value = '';
        }
        return Filter::escHtml((string)$value);
    }
}
