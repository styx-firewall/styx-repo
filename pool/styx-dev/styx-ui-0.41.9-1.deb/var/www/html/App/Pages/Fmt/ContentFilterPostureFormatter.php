<?php
/**
 * ContentFilterPostureFormatter - shared presentation helpers for the content
 * filter panes.
 *
 * The catalogue, the web filter and the DNS filter all render the same three
 * things: a category by name, the policy as one of three actions, and the
 * runtime counters. Building them once here is what keeps the three panes
 * saying the same words about the same policy.
 *
 * That policy is **one**, and it is decided in the catalogue
 * (categories.set_posture). The DNS filter cuts first, so a filter that kept a
 * different one would only be heard on the flows the other did not see: a hole
 * in the policy, not a second policy. Neither filter's own pane edits it.
 *
 * Templates are echo-only: every derived text, badge class and selected token is
 * computed in this class.
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class ContentFilterPostureFormatter
{
    /** The actions a policy can hold, in menu order. */
    public const ACTIONS = ['monitor', 'allow', 'block'];

    /** Action -> the word the operator reads. */
    private const ACTION_LABELS = [
        'monitor' => 'Monitor',
        'allow'   => 'Allow',
        'block'   => 'Block',
    ];

    /**
     * The status keys that are NOT counters.
     *
     * The status carries the running counters nesting one level down, and next
     * to them a few things that are not numbers at all: the two decision lists
     * (already shown as badges) and the resolved targets (already shown in the
     * target cards). Flattening those into label/value pairs would print
     * "Blocked_categories / 0 = adult", which reads like a measurement and is
     * not one.
     */
    private const NOT_COUNTERS = ['blocked_categories', 'qos_categories', 'resolved'];

    /**
     * Classifier name -> the word the operator reads.
     *
     * The backend sends the observer's own `name` in its status, and this is
     * where it becomes a heading: `http-observer` says what the code calls it,
     * "HTTP (Host header)" says what it reads.
     */
    private const OBSERVER_LABELS = [
        'http-observer' => 'HTTP (Host header)',
        'sni-observer'  => 'TLS (SNI)',
    ];

    /**
     * Group key -> [heading, the one line that says what the piece is].
     *
     * The backend names the thread it reports from (`core`, `labeler`, `capture`),
     * which says which part of the code counted, not what was counted. A heading
     * that keeps the code's word and a line that says what the word means is what
     * lets the pane be read without the source open.
     */
    private const GROUP_LABELS = [
        'core' => [
            'Core',
            'The thread that owns the flows: what it classified, what it applied to the kernel and what it dropped.',
        ],
        'labeler' => [
            'Labeler',
            'What it wrote to the kernel as conntrack labels, and what it could not write.',
        ],
        'capture' => [
            'Capture',
            'The sockets that read frames off the interfaces. The capture is shared with the network discovery, so these count every consumer, not only this filter.',
        ],
        'catalogue' => [
            'Catalogue',
            'The shared catalogue this filter decides with: the domains, the taxonomy and how much of it is cached.',
        ],
        'queue' => [
            'Queue',
            'The kernel side: what it handed to userspace, and what userspace did with it.',
        ],
        'decider' => [
            'Decider',
            'What it read in the answers, and what it decided about them.',
        ],
        'watchdog' => [
            'Watchdog',
            'The supervisor that restarts the reader. With gave_up on it has stopped trying: a reader that keeps dying shows up here.',
        ],
    ];

    /** The hint for a group that came from a list: each classifier's own numbers. */
    private const LIST_HINT = 'What this classifier read off the flows, and the flows it left unclassified.';

    /**
     * The counters that mean something when they are **not** zero.
     *
     * A cumulative counter cannot be read on its own: 0 and 4,000 look alike until
     * one of them is a failure. These are the ones that count something not
     * happening, so a non-zero value is marked and the reader has an entry point --
     * what is broken, before what is merely running.
     *
     * `critical` is "something did not happen": a label that was never written, a
     * verdict that never reached the kernel, a frame that could not be decoded.
     * `warning` is "worth a look": traffic dropped, an answer that arrived damaged.
     *
     * What is deliberately **not** here matters as much. `blocked_no_address` is the
     * clean cut (NXDOMAIN), which is the documented default when no target is
     * configured, and `not_dns` is traffic this filter is right to ignore: neither is
     * a fault, and marking them would teach the operator to ignore the marks. The one
     * case that is a pair -- `blocked` moving while `rewritten_records` stays at zero
     * -- now reads on its own, since the zero is dimmed and the live number is not.
     */
    private const FLAG_CRITICAL = [
        'no_label_zone', 'stale_bit', 'errors', 'gave_up', 'undecodable',
        'subscriber_errors', 'loop_errors', 'send_errors', 'kernel_errors',
        'kernel_dropped', 'kernel_user_dropped', 'decider_errors', 'unreadable',
        'flows_broken', 'nxdomain_unreadable', 'nxdomain_malformed_record',
    ];

    private const FLAG_WARNING = ['dropped', 'truncated'];

    /** Families that carry a failure and a reason in the same name (`block_failed_error`). */
    private const FLAG_PREFIXES = ['block_failed', 'unblock_failed'];

    /** A running flag that says "off" inside a group: the leg that is not up. */
    private const RUNNING_KEY = 'running';

    /**
     * The three actions as <option> rows for one category, the current one
     * selected.
     *
     * A category with no entry in the policy is `monitor`: that is what the
     * backend does with an absent key, and showing it as anything else would
     * misrepresent what the filter is doing.
     *
     * @return array<int,array<string,string>>
     */
    public static function actions(string $current): array
    {
        $out = [];
        foreach (self::ACTIONS as $value) {
            $out[] = [
                'value_attr' => Filter::escHtml($value),
                'label_html' => Filter::escHtml(self::ACTION_LABELS[$value] ?? $value),
                'selected'   => $value === $current ? 'selected' : '',
            ];
        }
        return $out;
    }

    /**
     * The filter's own switch and what it is doing, from the status the gateway
     * answered: the one place the two filter panes read their state from.
     *
     * Both panes ask the same three questions -- whether the FEATURE is enabled
     * (the panes and the settings exist), whether the filter's own SWITCH is on,
     * and whether it is actually running -- and the three disagree on purpose.
     * Being enabled arms nothing; a filter that is switched on can have its pieces
     * down, which is a state of its own and not something the switch fixes. Building
     * the answer once, here, is what keeps the two panes saying the same words about
     * the same gateway answer.
     *
     * **"Off" and "I could not look" are different answers**, and the three ways the
     * switch can arrive unreadable all land in `unknown`, which claims nothing: no Off
     * badge, no switch position for the operator to read, and a line saying so.
     * `PageContentFilter` passes an empty status when the status read itself failed;
     * the gateway answers `active: null` when the switch is there but its own read
     * failed (its doctrine: `services/content_filter/run_state.py`, an unknown state
     * must not be read as "nobody is here"); and a status that omits the key says
     * nothing either. Reading any of the three as "off" is the direction that can be
     * actively wrong, and with `fail_mode: strict` it is the worst one: a filter
     * reported as off while it is armed and dropping every DNS answer the operator was
     * told was being served.
     *
     * So the comparisons are strict, and only an exact answer is a position: `true` is
     * on, `false` is off, and everything else -- `null`, a missing key, a type that is
     * neither -- is `unknown`. `empty()` would read `null` as off, which is the whole
     * mistake; `!empty()` would read it as on, which is the same mistake mirrored. It
     * is deliberately not "off unless true": claiming a filter is filtering when the
     * answer never said so is what puts an operator's trust in the wrong place.
     *
     * `switch_visible` is false when there is no switch to draw: with the feature off
     * there is nothing to arm, and with the state unknown a checkbox has two
     * positions and drawing either of them would be an answer.
     *
     * @param array<string,mixed> $status the status as it arrived; [] when unreadable
     * @return array{state: string, switch_on: bool, switch_visible: bool}
     *         state: feature_off | unknown | off | on | running | on_not_running
     */
    public static function posture(array $status, bool $featureOn): array
    {
        if (!$featureOn) {
            return ['state' => 'feature_off', 'switch_on' => false, 'switch_visible' => false];
        }
        $active = array_key_exists('active', $status) ? $status['active'] : null;
        if ($active !== true && $active !== false) {
            return ['state' => 'unknown', 'switch_on' => false, 'switch_visible' => false];
        }
        if ($active === false) {
            return ['state' => 'off', 'switch_on' => false, 'switch_visible' => true];
        }
        // The switch is on; whether the pieces are up is a second answer, and one the
        // gateway may not have given (`running: null` for the same reason as `active`,
        // or a server too old to report it). That state claims the switch and nothing
        // about running -- it neither says "Running" nor raises the alarm of a filter
        // that came up broken.
        $running = array_key_exists('running', $status) ? $status['running'] : null;
        if ($running !== true && $running !== false) {
            return ['state' => 'on', 'switch_on' => true, 'switch_visible' => true];
        }
        return [
            'state'          => $running ? 'running' : 'on_not_running',
            'switch_on'      => true,
            'switch_visible' => true,
        ];
    }

    /**
     * Category id -> human label, for showing a policy or a status by name.
     *
     * Raw on purpose: this is the lookup the callers below index into, not a
     * field that reaches a template.
     *
     * @param array<int,array<string,mixed>> $categories
     * @return array<string,string>
     */
    public static function labels(array $categories): array
    {
        $out = [];
        foreach ($categories as $category) {
            if (!is_array($category)) {
                continue;
            }
            $id = (string)($category['id'] ?? '');
            if ($id !== '') {
                $out[$id] = (string)($category['label'] ?? $id);
            }
        }
        return $out;
    }

    /**
     * Resolve a list of category ids to display rows, keeping unknown ids
     * visible: a policy naming a category this build no longer ships is a fact
     * the operator needs to see, not one to hide.
     *
     * @param array<int,string>    $ids
     * @param array<string,string> $labels
     * @return array<int,array<string,string>>
     */
    public static function named(array $ids, array $labels): array
    {
        $out = [];
        foreach ($ids as $id) {
            $key = (string)$id;
            $out[] = [
                'id_attr'    => Filter::escHtml($key),
                'label_html' => Filter::escHtml($labels[$key] ?? $key),
            ];
        }
        return $out;
    }

    /**
     * The runtime counters, grouped by the piece they came from.
     *
     * Grouped, and not one flat list, because the pieces answer different
     * questions: "applied" in the core and "flows_written" in the labeler are not
     * comparable, and a flat list makes the reader hold all of them at once. Each
     * group carries a heading and the line that says what the piece is, and each
     * row carries what it needs to be read: the leaf name, the path it was nested
     * under, the tone when the value is asking for attention, and the full path for
     * a tooltip.
     *
     * What becomes a row, and what does not:
     *
     * - **A number** is one, formatted as an operator reads it (thousands
     *   separated) and marked when it counts a failure and is not zero.
     * - **A boolean** is one, said as on/off. A running flag that is off inside a
     *   group is the only place this pane can say *which* leg is down: the line at
     *   the top of the pane only ever says whether the filter as a whole is up.
     * - **A string** is a name, not a measurement, and "unknown: 1" reads like one:
     *   strings are left out.
     * - **A keyed array** is flattened into its group, keeping the leaf as the name
     *   and the path it came from beside it ("source" over "delivered"). Dropping a
     *   level in silence is how a counter stops being visible at all, which is the
     *   one failure this pane cannot afford: it exists to be read when something
     *   looks wrong.
     * - **A list of scalars** is one row with the values joined: the interfaces
     *   being captured, the ports a classifier reads. A list is a set of things
     *   the piece is working on, not a measurement of it.
     * - **A list of keyed arrays** is a group per item, titled with the item's own
     *   name, because each classifier has its own numbers and the counters alone
     *   do not say whose they are.
     *
     * @param array<string,mixed> $status
     * @return array<int,array<string,mixed>> [['title_html' => string, 'hint_html' => string,
     *                                         'flagged' => int, 'rows' => [['label_html' =>
     *                                         string, 'path_html' => string, 'value_html' =>
     *                                         string, 'class_attr' => string, 'title_attr' =>
     *                                         string]]]]
     */
    public static function counterGroups(array $status): array
    {
        $out = [];
        foreach ($status as $key => $value) {
            $key = (string)$key;
            if (in_array($key, self::NOT_COUNTERS, true) || !is_array($value)) {
                continue;
            }
            if (array_is_list($value)) {
                $position = 0;
                foreach ($value as $item) {
                    if (!is_array($item) || array_is_list($item)) {
                        continue;
                    }
                    $rows = self::counterRows($item);
                    if ($rows === []) {
                        continue;
                    }
                    $position++;
                    $out[] = self::group(self::groupTitle($item, $key, $position), self::LIST_HINT, $rows);
                }
                continue;
            }
            $rows = self::counterRows($value);
            if ($rows !== []) {
                $label = self::GROUP_LABELS[$key] ?? [ucfirst($key), ''];
                $out[] = self::group($label[0], $label[1], $rows);
            }
        }
        return $out;
    }

    /**
     * How many counter rows the groups hold: what the folded summary counts.
     *
     * @param array<int,array<string,mixed>> $groups
     */
    public static function counterCount(array $groups): int
    {
        $total = 0;
        foreach ($groups as $group) {
            $total += count($group['rows'] ?? []);
        }
        return $total;
    }

    /**
     * How many rows across all groups are asking for attention: counted in the
     * folded summary, so a closed fold still says whether opening it is worth it.
     *
     * @param array<int,array<string,mixed>> $groups
     */
    public static function flagCount(array $groups): int
    {
        $total = 0;
        foreach ($groups as $group) {
            $total += (int)($group['flagged'] ?? 0);
        }
        return $total;
    }

    /**
     * The status exactly as the gateway sent it, escaped for a <pre>.
     *
     * The counters above are these numbers, grouped and marked; this is the raw
     * answer, which is what a support thread or an issue wants pasted. Empty when
     * there is no status to show, so the template can ask instead of printing {}.
     *
     * @param array<string,mixed> $status
     */
    public static function statusJson(array $status): string
    {
        if ($status === []) {
            return '';
        }
        $json = json_encode($status, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        return is_string($json) ? Filter::escHtml($json) : '';
    }

    /**
     * One group: its heading, the line that says what the piece is, its rows, and
     * how many of those rows are marked.
     *
     * @param string                             $title raw: escaped here
     * @param array<int,array<string,mixed>>     $rows
     */
    private static function group(string $title, string $hint, array $rows): array
    {
        $flagged = 0;
        foreach ($rows as $row) {
            if (!empty($row['flagged'])) {
                $flagged++;
            }
        }
        return [
            'title_html' => Filter::escHtml($title),
            'hint_html'  => Filter::escHtml($hint),
            'flagged'    => $flagged,
            'rows'       => $rows,
        ];
    }

    /**
     * One group's rows, from the status the piece itself reported.
     *
     * @param array<string,mixed> $data
     * @param string              $path the path already walked, for nested keys
     * @return array<int,array<string,string>>
     */
    private static function counterRows(array $data, string $path = ''): array
    {
        $rows = [];
        foreach ($data as $name => $value) {
            $name = (string)$name;
            $here = $path === '' ? $name : $path . ' / ' . $name;
            if (is_array($value)) {
                if (array_is_list($value)) {
                    $joined = self::joinedScalars($value);
                    if ($joined !== '') {
                        $rows[] = self::row($name, $path, $joined);
                    }
                    continue;
                }
                foreach (self::counterRows($value, $here) as $row) {
                    $rows[] = $row;
                }
                continue;
            }
            if (is_bool($value)) {
                $rows[] = self::row($name, $path, $value ? 'on' : 'off', self::tone($name, $value));
                continue;
            }
            if (!is_int($value) && !is_float($value)) {
                continue;
            }
            $rows[] = self::row($name, $path, self::number($value), self::tone($name, $value));
        }
        return $rows;
    }

    /**
     * A counter as the operator reads it: thousands separated, because these are
     * cumulative and pass four digits within a day. A float keeps what it carries.
     *
     * @param int|float $value
     */
    private static function number($value): string
    {
        return is_int($value) ? number_format($value) : (string)$value;
    }

    /**
     * How loudly a counter is asking for attention: 'crit', 'warn', or '' for a
     * value that is simply a number.
     *
     * A number has to be **not zero** to say anything; a flag is the other way
     * round and only bites when it is set. A running flag is the exception with a
     * word of its own: `off` inside a group is the leg that is down.
     *
     * @param int|float|bool $value
     */
    private static function tone(string $name, $value): string
    {
        if (is_bool($value)) {
            if ($name === self::RUNNING_KEY) {
                return $value ? '' : 'warn';
            }
            if (!$value) {
                return '';
            }
        } elseif ($value == 0) {
            return '';
        }
        if (in_array($name, self::FLAG_CRITICAL, true)) {
            return 'crit';
        }
        foreach (self::FLAG_PREFIXES as $prefix) {
            if (str_starts_with($name, $prefix)) {
                return 'crit';
            }
        }
        return in_array($name, self::FLAG_WARNING, true) ? 'warn' : '';
    }

    /**
     * A list's scalars, joined for one row, or '' when there is nothing to join.
     *
     * A list holding a structure is not a value -- that shape is a group, and it
     * is handled as one.
     *
     * @param array<int,mixed> $values
     */
    private static function joinedScalars(array $values): string
    {
        $out = [];
        foreach ($values as $value) {
            if ($value === null || is_bool($value) || is_array($value)) {
                return '';
            }
            $out[] = (string)$value;
        }
        return implode(', ', $out);
    }

    /**
     * The title of a group that came from a list: the item's own name when it
     * carries one, so an observer's numbers are attributed by the observer.
     *
     * Raw, not escaped: the caller escapes the heading once, with the rest.
     *
     * @param array<string,mixed> $item
     */
    private static function groupTitle(array $item, string $key, int $position): string
    {
        $name = is_scalar($item['name'] ?? null) ? (string)$item['name'] : '';
        if ($name !== '') {
            return self::OBSERVER_LABELS[$name] ?? ucfirst(str_replace('-', ' ', $name));
        }
        return ucfirst($key) . ' ' . $position;
    }

    /**
     * One counter row: the leaf name, the path it was nested under, the value, and
     * the classes that mark it. Escaped here, because templates only echo.
     *
     * A zero carries `--zero` so the stylesheet can dim it: on a wall of counters,
     * the numbers that are moving are the ones worth the ink.
     */
    private static function row(string $name, string $path, string $value, string $tone = ''): array
    {
        $classes = 'cf-counter-row';
        if ($tone !== '') {
            $classes .= ' cf-counter-row--' . $tone;
        } elseif (self::isZero($value)) {
            $classes .= ' cf-counter-row--zero';
        }
        $full = $path === '' ? $name : $path . ' / ' . $name;
        return [
            'label_html' => Filter::escHtml($name),
            // The path as a prefix the leaf reads after ("source / delivered"),
            // said in the quiet voice: the leaf is what the eye scans, the path is
            // where it came from, and the full path is in the tooltip.
            'path_html'  => $path === '' ? '' : Filter::escHtml($path . ' /'),
            'value_html' => Filter::escHtml($value),
            // Built from the constants above, never from the status.
            'class_attr' => $classes,
            'title_attr' => Filter::escHtml($full),
            'flagged'    => $tone !== '',
        ];
    }

    /** Whether an already-formatted value reads as zero ("0", "0.0", not "off"). */
    private static function isZero(string $value): bool
    {
        return $value !== '' && is_numeric($value) && (float)$value == 0.0;
    }
}
