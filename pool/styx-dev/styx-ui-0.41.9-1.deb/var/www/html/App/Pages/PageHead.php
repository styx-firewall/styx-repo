<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;

class PageHead
{
    /**
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $cfg = $ctx->get(Config::class);

        $led_status = 'led-red-on';
        $blink_status = '';
        $gw_latency = 'N/A';
        $gw_version = 'N/A';


        $data = [
            'head_menu' => [
                'web_legend' => $cfg->get('web.legend'),
            ],
            'pong_gateway' => [
                'status' => $led_status,
                'blink' => $blink_status,
                'latency' => $gw_latency,
                'version' => $gw_version,
            ],
            'config_changed' => (bool)$cfg->get('config_changed', false),
            'restart_required' => (bool)$cfg->get('restart_required', false),
            'client_timezone' => $cfg->get('client.timezone', 'UTC'),
            'client_locale' => $cfg->get('client.locale', 'en-US'),
        ];
        return [
            'file' => 'head',
            'place' => 'page_head',
            'tpl_data' => $data,
        ];
    }
}
