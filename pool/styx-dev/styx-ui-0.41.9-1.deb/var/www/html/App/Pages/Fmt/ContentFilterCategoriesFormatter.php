<?php
/**
 * ContentFilterCategoriesFormatter - presentation helpers for the catalogue pane.
 *
 * The pane is built as one block per category, and each block holds the three
 * things the operator asks about it together: what is done with it (the shared
 * policy), adding a domain to it, and the entries it holds. That is deliberate -
 * the question arrives as "is this category blocked?" or "what is in it?", and
 * answering it used to mean reading three separate lists on three screens' worth
 * of scroll.
 *
 * The **policy** is edited here because it is the one the whole group reads: the
 * DNS filter cuts first, so a filter that kept a different one would only be
 * heard on the flows the other missed - a hole in the policy, not a second one.
 *
 * Input (from PageContentFilter):
 *   - entries    [{pattern, target, source}]  every entry, built-in and operator
 *   - categories [{id, label, group, bit}]    the taxonomy
 *   - groups     [{id, label}]                group order and names
 *   - posture    {category id: action}        the shared policy
 *   - stats      {entries, builtin, operator, cached}
 *
 * Output: `sections` (a heading plus the blocks under it) in display order -
 * exemptions, the taxonomy group by group, then anything the catalogue no longer
 * names - so the template only has to loop.
 *
 * Templates are echo-only: every derived text, badge class, attribute, note and
 * count label is computed here.
 *
 * @see App\Pages\PageContentFilter
 * @see api/handlers/categories.md
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class ContentFilterCategoriesFormatter
{
    /** Where an entry came from -> badge variant (std-badge--*) and word. */
    private const SOURCE_BADGES = [
        'builtin'  => 'std-badge--info',
        'operator' => 'std-badge--success',
    ];
    private const SOURCE_LABELS = [
        'builtin'  => 'Built-in',
        'operator' => 'Operator',
    ];

    /** The special target that exempts a domain from every category. */
    private const TARGET_ALLOW = 'allow';

    private const EXEMPT_LABEL = 'Exemptions (Allow)';

    private const EXEMPT_NOTE = 'A domain listed here is exempt from every category, whatever the policy says. '
        . 'It is also how a domain inside a built-in category is carved out, since built-in entries come from code, '
        . 'cannot be removed, and would come back on the next load.';

    private const STALE_LABEL = 'Not in the catalogue';

    private const STALE_NOTE = 'These entries point at a target this build does not name. They are kept and shown '
        . 'rather than hidden: a rule that is still in the file is still in force.';

    private const UNGROUPED_LABEL = 'Ungrouped';

    private const UNNAMED_LABEL = 'Unnamed target';

    /**
     * @param array<string,mixed> $data entries, categories, groups, posture, stats
     * @return array<string,mixed>
     */
    public static function format(array $data, bool $canEdit, bool $canDelete): array
    {
        $categories = is_array($data['categories'] ?? null) ? $data['categories'] : [];
        $groups     = is_array($data['groups'] ?? null) ? $data['groups'] : [];
        $stats      = is_array($data['stats'] ?? null) ? $data['stats'] : [];
        $posture    = is_array($data['posture'] ?? null) ? $data['posture'] : [];

        // Entries bucketed by what they point at: each list is read next to the
        // category it decides about, not in one global table.
        $byTarget = [];
        $total    = 0;
        $builtin  = 0;
        foreach ((array)($data['entries'] ?? []) as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $total++;
            if ((string)($entry['source'] ?? '') === 'builtin') {
                $builtin++;
            }
            $byTarget[(string)($entry['target'] ?? '')][] = self::entry($entry, $canDelete);
        }

        $sections = [];

        // 1. The exemptions first: they are the one block that acts on every
        //    category at once, and the answer to "how do I let this through?".
        $exempt = $byTarget[self::TARGET_ALLOW] ?? [];
        unset($byTarget[self::TARGET_ALLOW]);
        $sections[] = [
            'heading_html' => '',
            'blocks'       => [
                self::block([
                    'id'      => self::TARGET_ALLOW,
                    'label'   => self::EXEMPT_LABEL,
                    'variant' => 'cf-block--exempt',
                    'note'    => self::EXEMPT_NOTE,
                    'entries' => $exempt,
                    'actions' => false,
                    'add'     => true,
                    'bit'     => null,
                ], $posture, $canEdit),
            ],
        ];

        // 2. The taxonomy, group by group, in the group order the catalogue gives.
        $placed = [];
        foreach ($groups as $group) {
            if (!is_array($group)) {
                continue;
            }
            $groupId = (string)($group['id'] ?? '');
            $blocks  = [];
            foreach ($categories as $category) {
                if (!is_array($category) || (string)($category['group'] ?? '') !== $groupId) {
                    continue;
                }
                $block = self::categoryBlock($category, $posture, $byTarget, $canEdit);
                if ($block === null) {
                    continue;
                }
                $blocks[] = $block;
                $placed[(string)($category['id'] ?? '')] = true;
            }
            if (empty($blocks)) {
                continue;
            }
            $sections[] = [
                'heading_html' => Filter::escHtml((string)($group['label'] ?? $groupId)),
                'blocks'       => $blocks,
            ];
        }

        // A category whose group is not in the list - or a catalogue that ships
        // no group list at all - must still be editable, or the operator cannot
        // decide about it anywhere.
        $unlisted = [];
        foreach ($categories as $category) {
            if (!is_array($category)) {
                continue;
            }
            $id = (string)($category['id'] ?? '');
            if ($id === '' || isset($placed[$id])) {
                continue;
            }
            $block = self::categoryBlock($category, $posture, $byTarget, $canEdit);
            if ($block !== null) {
                $unlisted[(string)($category['group'] ?? '')][] = $block;
                $placed[$id] = true;
            }
        }
        foreach ($unlisted as $groupId => $blocks) {
            $sections[] = [
                'heading_html' => Filter::escHtml($groupId === '' ? self::UNGROUPED_LABEL : $groupId),
                'blocks'       => $blocks,
            ];
        }

        // 3. Whatever is left points at a target no category names. A category
        //    that was placed has already shown its entries; skipping it here is
        //    what keeps them from being listed twice.
        $stale = [];
        foreach ($byTarget as $target => $rows) {
            if (empty($rows) || isset($placed[(string)$target])) {
                continue;
            }
            $stale[] = self::block([
                'id'      => $target,
                'label'   => $target === '' ? self::UNNAMED_LABEL : $target,
                'variant' => 'cf-block--stale',
                'note'    => self::STALE_NOTE,
                'entries' => $rows,
                'actions' => false,
                'add'     => false,
                'bit'     => null,
            ], $posture, $canEdit);
        }
        if (!empty($stale)) {
            $sections[] = [
                'heading_html' => Filter::escHtml(self::STALE_LABEL),
                'blocks'       => $stale,
            ];
        }

        return [
            'stats' => [
                'entries'  => (int)($stats['entries'] ?? $total),
                'builtin'  => (int)($stats['builtin'] ?? $builtin),
                'operator' => (int)($stats['operator'] ?? ($total - $builtin)),
                'cached'   => (int)($stats['cached'] ?? 0),
            ],
            'sections'      => $sections,
            'blocked_count' => count(array_filter($posture, static function ($action) {
                return $action === 'block';
            })),
            'can_edit'      => $canEdit,
            'disabled_attr' => $canEdit ? '' : 'disabled',
        ];
    }

    /**
     * The pane when the catalogue could not be read: the message, escaped.
     *
     * Static and public because there is nothing to format in that case - the
     * page has a message and no catalogue - and the message still has to reach
     * the template escaped, since the template does not escape.
     *
     * @return array<string,mixed>
     */
    public static function error(string $msg): array
    {
        return ['error_html' => Filter::escHtml($msg)];
    }

    /**
     * One category as a block: its policy, its add row and its entries.
     *
     * @param array<string,mixed>            $category
     * @param array<string,string>           $posture
     * @param array<string,array<int,array<string,mixed>>> $byTarget
     * @return array<string,mixed>|null null when the category has no id to key on
     */
    private static function categoryBlock(array $category, array $posture, array $byTarget, bool $canEdit): ?array
    {
        $id = (string)($category['id'] ?? '');
        if ($id === '') {
            return null;
        }
        return self::block([
            'id'      => $id,
            'label'   => (string)($category['label'] ?? $id),
            'variant' => '',
            'note'    => '',
            'entries' => $byTarget[$id] ?? [],
            'actions' => true,
            'add'     => true,
            'bit'     => $category['bit'] ?? null,
        ], $posture, $canEdit);
    }

    /**
     * Assemble a block in the shape the template renders, whichever kind it is.
     *
     * The action select and the add row are separate rows on purpose: the select
     * is only in force once the page's Save button is pressed, the add row acts at
     * once. Nothing else in the layout can say that, so the layout has to.
     *
     * @param array<string,mixed>  $spec
     * @param array<string,string> $posture
     * @return array<string,mixed>
     */
    private static function block(array $spec, array $posture, bool $canEdit): array
    {
        $entries = $spec['entries'];
        $builtin = 0;
        foreach ($entries as $row) {
            if (!empty($row['is_builtin'])) {
                $builtin++;
            }
        }
        $total    = count($entries);
        $operator = $total - $builtin;
        $id       = (string)$spec['id'];
        $label    = (string)$spec['label'];

        return [
            'id_attr'          => Filter::escHtml($id),
            'label_html'       => Filter::escHtml($label),
            // The bit is the conntrack label position, and the order of the
            // taxonomy is the bit order: worth showing, not worth a column.
            'bit_title_attr'   => $spec['bit'] === null ? '' : Filter::escHtml('label bit ' . (string)$spec['bit']),
            'variant_class'    => (string)$spec['variant'],
            'note_html'        => $spec['note'] === '' ? '' : Filter::escHtml((string)$spec['note']),
            'has_actions'      => (bool)$spec['actions'],
            'actions'          => $spec['actions']
                ? ContentFilterPostureFormatter::actions((string)($posture[$id] ?? 'monitor'))
                : [],
            'action_aria_attr' => Filter::escHtml('What to do with ' . $label),
            'has_add'          => (bool)$spec['add'],
            'add_target_attr'  => Filter::escHtml($id),
            'add_aria_attr'    => Filter::escHtml('Add a domain to ' . $label),
            'disabled_attr'    => $canEdit ? '' : 'disabled',
            'entries'          => $entries,
            'has_entries'      => $total > 0,
            'count_label'      => self::countLabel($total, $operator),
        ];
    }

    /**
     * How much the block holds, said plainly: "1 entry", "14 entries (3 by the
     * operator)". An operator can tell at a glance whether they have touched the
     * category at all.
     */
    private static function countLabel(int $total, int $operator): string
    {
        $label = $total . ' ' . ($total === 1 ? 'entry' : 'entries');
        if ($operator > 0) {
            $label .= ' (' . $operator . ' by the operator)';
        }
        return $label;
    }

    /**
     * One entry row.
     *
     * A built-in entry cannot be removed: it comes from code and would come back
     * on the next load. Carving a domain out of one is done with an `allow` entry,
     * which is what the exemptions block is for.
     *
     * @param array<string,mixed> $entry
     * @return array<string,mixed>
     */
    private static function entry(array $entry, bool $canDelete): array
    {
        $pattern   = (string)($entry['pattern'] ?? '');
        $source    = (string)($entry['source'] ?? '');
        $isBuiltin = $source === 'builtin';

        return [
            'pattern_html'      => Filter::escHtml($pattern),
            'pattern_attr'      => Filter::escHtml($pattern),
            'source_class'      => self::SOURCE_BADGES[$source] ?? 'std-badge--info',
            'source_label_html' => Filter::escHtml(self::SOURCE_LABELS[$source] ?? $source),
            'remove_aria_attr'  => Filter::escHtml('Remove the entry for ' . $pattern),
            // Internal: counted, never echoed.
            'is_builtin'        => $isBuiltin,
            'removable'         => !$isBuiltin && $canDelete,
        ];
    }
}
