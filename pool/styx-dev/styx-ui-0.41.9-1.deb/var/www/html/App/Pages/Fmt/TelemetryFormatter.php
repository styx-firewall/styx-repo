<?php
/**
 * Formatter for the Telemetry section (Styx page).
 *
 * Pre-computes the static shell of the page: the filter dropdowns built from
 * telemetry.sources, and the storage/bus counters from telemetry.stats. The
 * points themselves are fetched and rendered client-side by
 * scripts/telemetry/telemetry.js, because they are polled.
 *
 * Everything the template prints is escaped and cast here, following the house
 * convention: a key holding ready-to-echo markup ends in `_html`, one holding an
 * attribute value ends in `_attr`, and the template only echoes. Instance and
 * scope values are escaped for the attribute context but stay intact for the
 * DOM: the client reads `option.value` and `option.dataset.scope` back, and the
 * browser un-escapes them when parsing.
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class TelemetryFormatter
{
    /** Bar tone thresholds, as a fraction of the cap. Must match the classes in default-telemetry.css. */
    private const WARN_AT = 0.70;
    private const CRIT_AT = 0.90;

    /**
     * @param array<string,mixed> $fmt_data ['sources' => array, 'instances' => array,
     *                                      'stats' => array, 'error' => string, 'warnings' => array]
     * @return array<string,mixed>
     */
    public static function format(array $fmt_data): array
    {
        $sources   = $fmt_data['sources'] ?? [];
        $instances = $fmt_data['instances'] ?? [];
        $stats     = $fmt_data['stats'] ?? [];

        [$scope_options, $source_options, $schema_options, $sources_rows] = self::buildInventory($sources);

        $fmt_data['scope_options']    = $scope_options;
        $fmt_data['source_options']   = $source_options;
        $fmt_data['schema_options']   = $schema_options;
        $fmt_data['sources_rows']     = $sources_rows;
        $fmt_data['has_inventory']    = !empty($sources_rows);
        $fmt_data['instance_options'] = self::buildInstances($instances);
        $fmt_data['stats']            = self::buildStats($stats);

        // Points per bucket. 10000 is the handler's own ceiling
        // (MAX_QUERY_POINTS); asking for more is refused, not clamped.
        $fmt_data['n_options'] = [];
        foreach ([50, 100, 200, 500, 1000, 5000, 10000] as $qty) {
            $fmt_data['n_options'][] = [
                'value_attr' => (string)$qty,
                'label_html' => (string)$qty,
                'selected'   => ($qty === 50),
            ];
        }

        if (isset($fmt_data['error'])) {
            $fmt_data['error_html'] = Filter::escHtml((string)$fmt_data['error']);
        }
        if (!empty($fmt_data['warnings'])) {
            $fmt_data['warnings_html'] = Filter::escHtml(implode(' | ', (array)$fmt_data['warnings']));
        }

        return $fmt_data;
    }

    /**
     * Flatten the inventory into filter options and tree rows.
     *
     * Shape of telemetry.sources result:
     *   ['scopes' => ['<scope>' => ['<source>' => ['metric', ...], ...], ...]]
     *
     * @param array<string,mixed> $sources
     * @return array{0: array<int,array<string,mixed>>, 1: array<int,array<string,mixed>>,
     *               2: array<int,array<string,mixed>>, 3: array<int,array<string,mixed>>}
     *               Options for scope, source and schema; then the inventory rows.
     */
    private static function buildInventory(array $sources): array
    {
        $scope_options  = [self::option('*', 'All scopes', true)];
        $source_options = [self::option('*', 'All sources', true)];
        $schema_options = [self::option('*', 'All schema types', true)];

        $seen_sources = [];
        $seen_schemas = [];
        $sources_rows = [];

        $scopes = $sources['scopes'] ?? [];
        if (!is_array($scopes)) {
            $scopes = [];
        }
        ksort($scopes);

        foreach ($scopes as $scope => $scope_sources) {
            if (!is_array($scope_sources)) {
                continue;
            }
            ksort($scope_sources);

            foreach ($scope_sources as $source => $schemas) {
                $schemas = is_array($schemas) ? array_values(array_filter($schemas, 'is_string')) : [];

                $sources_rows[] = [
                    'scope_html'   => Filter::escHtml((string)$scope),
                    'source_html'  => Filter::escHtml((string)$source),
                    'schemas_html' => Filter::escHtml(implode(', ', $schemas)),
                ];

                if (!isset($seen_sources[$source])) {
                    $seen_sources[$source] = true;
                    $source_options[] = self::option((string)$source, (string)$source, false);
                }
                foreach ($schemas as $schema) {
                    if (!isset($seen_schemas[$schema])) {
                        $seen_schemas[$schema] = true;
                        $schema_options[] = self::option($schema, $schema, false);
                    }
                }
            }

            $scope_options[] = self::option((string)$scope, (string)$scope, false);
        }

        return [$scope_options, $source_options, $schema_options, $sources_rows];
    }

    /**
     * Flatten telemetry.instances into filter options.
     *
     * Shape of the result:
     *   ['scopes' => ['<species>' => [['instance' => .., 'labels' => [..],
     *                                  'instance_display' => ..], ...]]]
     *
     * The label is the backend's own `instance_display`, the very string the
     * points carry -- so the dropdown and a row's Instance cell cannot disagree,
     * and neither side has to interpret the `labels` dict.
     *
     * Each option carries the species it belongs to, so the client can narrow
     * the list when a scope is selected without another round trip.
     *
     * @param array<string,mixed> $instances
     * @return array<int,array<string,mixed>>
     */
    private static function buildInstances(array $instances): array
    {
        // "*" is always first and always kept by the client-side narrowing.
        $all = ['value_attr' => '*', 'label_html' => 'All instances', 'selected' => true, 'scope_attr' => '*'];

        $scopes = $instances['scopes'] ?? [];
        if (!is_array($scopes)) {
            $scopes = [];
        }

        $rest = [];
        foreach ($scopes as $scope => $rows) {
            if (!is_array($rows)) {
                continue;
            }
            foreach ($rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $instance = (string)($row['instance'] ?? '');
                if ($instance === '') {
                    // A single-instance producer: its identity IS the species, so
                    // there is nothing to pick here -- the scope filter already
                    // covers it. Emitting it would also be a lie: the controller
                    // drops empty filters, so choosing it would widen the query
                    // to every instance instead of narrowing it.
                    continue;
                }
                $rest[] = [
                    'value_attr' => Filter::escHtml($instance),
                    'label_html' => Filter::escHtml((string)($row['instance_display'] ?? $instance)),
                    'selected'   => false,
                    'scope_attr' => Filter::escHtml((string)$scope),
                ];
            }
        }

        // Stable order whatever order the storage handed back, so the list does
        // not reshuffle between two loads with the same data.
        usort($rest, function (array $a, array $b): int {
            return [$a['scope_attr'], $a['label_html']] <=> [$b['scope_attr'], $b['label_html']];
        });

        return array_merge([$all], $rest);
    }

    /**
     * Turn telemetry.stats into labelled gauges, a drop table and an eviction
     * table.
     *
     * A null cap means "unlimited": the gauge renders as text with no bar,
     * because a bar against no cap would be a made-up percentage. The two
     * storage counters have lost their caps, so they render plain; only the
     * bus queue still has a cap (queue_max) and keeps its bar. A gauge for a
     * value that is itself a limit passes its own unit through $cap_text
     * rather than borrowing the "of unlimited" suffix.
     *
     * @param array<string,mixed> $stats
     * @return array<string,mixed>
     */
    private static function buildStats(array $stats): array
    {
        if (empty($stats) || !is_array($stats)) {
            return ['available' => false];
        }

        $bus = is_array($stats['bus'] ?? null) ? $stats['bus'] : null;

        $gauges = [
            self::gauge('Points stored', $stats['total_points'] ?? null, null),
            self::gauge('Buckets', $stats['total_buckets'] ?? null, null),
            // Default series budget a producer holds before its coldest series
            // is evicted. Shown for reference, not a live gauge: it is the limit
            // itself, so it carries its own unit rather than the "of unlimited"
            // suffix that a measurement against no cap would get.
            self::gauge('Producer budget', $stats['producer_budget'] ?? null, null, 'series per producer'),
        ];
        if ($bus !== null) {
            $gauges[] = self::gauge('Bus queue', $bus['pending'] ?? null, $bus['queue_max'] ?? null);
        }

        // The storage no longer refuses a point, so its drop counts are gone:
        // drops are now the bus queue's own (queue_full / bus_stopped). Any
        // non-zero entry means data was refused, which is why they keep their
        // own table -- and with the bus as the only origin left, there is no
        // Origin column to fill, so the key is the row's reason.
        $drop_rows = [];
        if ($bus !== null && is_array($bus['drop_counts'] ?? null)) {
            foreach ($bus['drop_counts'] as $key => $count) {
                $drop_rows[] = self::dropRow((string)$key, $count);
            }
        }

        $total_dropped = 0;
        foreach ($drop_rows as $row) {
            $total_dropped += $row['count'];
        }

        // Evictions are the new signal (where drops used to be): a producer
        // evicting its coldest series to keep a new one inside its budget.
        // Counted per instance, so they get their own table and total.
        //
        // The two do not answer the same question, and the storage makes them
        // diverge on purpose: a producer's entry is pruned by the GC sweep once
        // it holds no series, while the running total is never decremented. So
        // the table is "who was shedding at the last sweep" and the total is
        // "how many series shed since start" -- the template labels it as such.
        // Neither is derived from the other, and no clamping is needed: every
        // per-producer increment raises both, the prune only lowers one, so the
        // rows always sum to <= the total.
        $eviction_rows = is_array($stats['evictions'] ?? null) ? self::evictionRows($stats['evictions']) : [];
        $total_evictions = is_numeric($stats['total_evictions'] ?? null) ? (int)$stats['total_evictions'] : 0;

        return [
            'available'              => true,
            'gauges'                => $gauges,
            'drop_rows'             => $drop_rows,
            'has_drops'             => !empty($drop_rows),
            'total_dropped_html'    => (string)$total_dropped,
            // The highlight is the formatter's call, so the template does not
            // carry the comparison.
            'dropped_class_attr'    => $total_dropped > 0 ? 'telemetry-drop-crit' : '',
            // Evictions are a separate signal (a producer shedding its oldest
            // series to fit a new one), so they get their own count and class.
            'eviction_rows'         => $eviction_rows,
            // Drives an empty state worded about producers, not about all time:
            // with the total above being since-start, "no series evicted" would
            // contradict it the moment a producer's last series is pruned.
            'has_evictions'         => !empty($eviction_rows),
            'total_evictions_html'  => (string)$total_evictions,
            'evictions_class_attr'  => $total_evictions > 0 ? 'telemetry-drop-crit' : '',
            'delivered_html'        => self::countText($bus['delivered'] ?? null),
            'has_bus'               => $bus !== null,
        ];
    }

    /**
     * @param mixed $value
     * @param mixed $cap
     * @param string|null $cap_text Unit to print in place of the "of N" /
     *   "of unlimited" suffix, for a value that is itself a limit rather than a
     *   measurement against one.
     * @return array<string,mixed>
     */
    private static function gauge(string $label, $value, $cap, ?string $cap_text = null): array
    {
        $value = is_numeric($value) ? (int)$value : null;
        $cap   = is_numeric($cap) ? (int)$cap : null;

        $pct = null;
        $tone = 'ok';
        if ($cap !== null && $cap > 0 && $value !== null) {
            $pct = min(100, (int)round($value * 100 / $cap));
            $tone = self::tone($value / $cap);
        }

        return [
            'label_html' => Filter::escHtml($label),
            'value_html' => self::countText($value),
            // The caller's own unit wins: "of unlimited" is a lie for a field
            // that is itself the limit.
            'cap_html'   => $cap_text !== null
                ? Filter::escHtml($cap_text)
                : ($cap === null ? 'of unlimited' : 'of ' . $cap),
            'has_bar'    => ($pct !== null),
            'pct_attr'   => $pct === null ? '' : (string)$pct,
            'tone'       => $tone,
        ];
    }

    /**
     * @param mixed $count
     * @return array<string,mixed>
     */
    private static function dropRow(string $key, $count): array
    {
        $count = is_numeric($count) ? (int)$count : 0;
        return [
            // The bus is the only origin there is left, so the key is the whole
            // row: what refused the point.
            'key_html'   => Filter::escHtml($key),
            'count'      => $count,
            'count_html' => (string)$count,
            // 0 is the healthy value; anything else means points were refused,
            // which is the only thing on this page allowed to shout.
            'class_attr' => $count > 0 ? 'telemetry-drop-crit' : '',
        ];
    }

    /**
     * Flatten telemetry.stats['evictions'] into one row per evicted series.
     *
     * Shape: ['<scope>' => ['<instance>' => int, ...], ...] -- per instance the
     * running count of series evicted to keep that producer inside its budget.
     *
     * @param array<string,mixed> $evictions
     * @return array<int,array<string,mixed>>
     */
    private static function evictionRows(array $evictions): array
    {
        // Stable order whatever order the storage handed back, so the table
        // does not reshuffle between two loads with the same data. Both levels:
        // the scope order is the backend dict's insertion order, which producers
        // entering and leaving change.
        $rows = [];
        ksort($evictions);
        foreach ($evictions as $scope => $instances) {
            if (!is_array($instances)) {
                continue;
            }
            ksort($instances);
            foreach ($instances as $instance => $count) {
                $count = is_numeric($count) ? (int)$count : 0;
                $rows[] = [
                    'scope_html'      => Filter::escHtml((string)$scope),
                    'instance_html'  => Filter::escHtml((string)$instance),
                    'count'           => $count,
                    'count_html'      => (string)$count,
                    // 0 is the healthy value; anything else means data was
                    // shed, which is the only thing on this page allowed to
                    // shout -- here too.
                    'class_attr'      => $count > 0 ? 'telemetry-drop-crit' : '',
                ];
            }
        }
        return $rows;
    }

    /** A number, or an em dash when there is nothing to show. */
    private static function countText(?int $value): string
    {
        return $value === null ? '<span class="text-muted">&mdash;</span>' : (string)$value;
    }

    /**
     * A ready-to-echo <option>. The value is escaped for the attribute context;
     * the DOM hands the unescaped value back to the client.
     *
     * @return array<string,mixed>
     */
    private static function option(string $value, string $label, bool $selected): array
    {
        return [
            'value_attr' => Filter::escHtml($value),
            'label_html' => Filter::escHtml($label),
            'selected'   => $selected,
        ];
    }

    private static function tone(float $ratio): string
    {
        if ($ratio >= self::CRIT_AT) {
            return 'crit';
        }
        if ($ratio >= self::WARN_AT) {
            return 'warn';
        }
        return 'ok';
    }
}
