<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

class RoutingFrrFormatter
{
    /** @param array<string,mixed> $data */
    public static function format(array $data): array
    {
        $overview = $data['frr_overview'] ?? [];

        $labels = [
            'bgpd'      => 'BGP daemon',
            'ospfd'     => 'OSPF daemon',
            'ripd'      => 'RIP daemon',
            'bfdd'      => 'BFD daemon',
            'staticd'   => 'Static daemon',
            'vrrpd'     => 'VRRP daemon',
        ];
        $daemons = $overview['daemons'] ?? [];
        foreach ($daemons as &$d) {
            $name = $d['name'] ?? '';
            if (isset($d['display'])) {
                $d['display_name'] = $d['display'];
            } elseif (isset($labels[$name])) {
                $d['display_name'] = $labels[$name];
            } else {
                $d['display_name'] = $name !== '' ? ucfirst($name) : '';
            }
            $d['status_badge_class'] = ($d['status'] ?? '') === 'running' ? ' std-badge--success std-badge--dot' : ' std-badge--danger std-badge--dot';
        }
        unset($d);

        // Routes by protocol: pre-cast counts + family labels.
        $routes = $overview['routes'] ?? [];
        foreach (['ipv4', 'ipv6'] as $family) {
            if (isset($routes[$family])) {
                $routes[$family]['_label'] = strtoupper($family);
            }
        }
        $routeRows = [];
        foreach (['ipv4', 'ipv6'] as $family) {
            $r = $routes[$family] ?? [];
            $routeRows[] = [
                'family_label' => $r['_label'] ?? strtoupper($family),
                'bgp'  => (int)($r['bgp'] ?? 0),
                'ospf' => (int)($r['ospf'] ?? 0),
                'rip'  => (int)($r['rip'] ?? 0),
            ];
        }

        $data['frr_overview'] = [
            'enabled'    => !empty($overview['enabled']),
            'daemons'    => $daemons,
            'routes'     => $routes,
            'route_rows' => $routeRows,
        ];

        // Global select display state (null/true/false -> selected).
        $profile = $data['frr_profile'] ?? null;
        $data['profile_selected_default']    = $profile === null ? 'selected' : '';
        $data['profile_selected_traditional'] = $profile === 'traditional' ? 'selected' : '';
        $data['profile_selected_datacenter'] = $profile === 'datacenter' ? 'selected' : '';
        $noRoot = $data['frr_no_root'] ?? null;
        $data['no_root_selected_default'] = $noRoot === null ? 'selected' : '';
        $data['no_root_selected_yes']     = $noRoot === true ? 'selected' : '';
        $data['no_root_selected_no']      = $noRoot === false ? 'selected' : '';

        return $data;
    }
}
