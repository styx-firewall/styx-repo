<?php
/**
 * Formatter for eBPF module management page.
 *
 * Transforms raw API responses into template-ready arrays with pre-computed
 * HTML, CSS classes, and display values. The template only loops and echoes.
 */
namespace App\Pages\Fmt;

use App\Services\Filter;

class EbpfFormatter
{
    /** @var array<string, string> */
    private const STATUS_BADGE = [
        'loaded'        => 'ebpf-status-loaded',
        'suspended'     => 'ebpf-status-suspended',
        'inactive'      => 'ebpf-status-inactive',
        'available'     => 'ebpf-status-available',
        'incompatible'  => 'ebpf-status-incompatible',
        'error'         => 'ebpf-status-error',
    ];

    /** @var array<string, string> */
    private const MISSING_REASON = [
        'no_dispatcher'     => 'Nothing of ours on the interface',
        'legacy_program'    => 'A single program attached outside the dispatcher',
        'not_a_component'   => 'Another generation is the component',
        'interface_missing' => 'The interface does not exist',
    ];

    private const STATUS_LABEL = [
        'loaded'        => '● Loaded',
        'suspended'     => '◐ Suspended',
        'inactive'      => '○ Inactive',
        'available'     => '○ Available',
        'incompatible'  => '✗ Incompatible',
        'error'         => '⚠ Error',
    ];

    /** @var array<string, string> */
    private const TYPE_BADGE = [
        'core' => 'ebpf-type-core',
        'bcc'  => 'ebpf-type-bcc',
    ];

    //
    // PUBLIC API
    //

    /**
     * Format the module-list response for template consumption.
     *
     * @param array<string,mixed> $data Raw result from ebpf.module-list
     * @return array<string,mixed>
     */
    public static function formatModuleList(array $data): array
    {
        $instances = $data['instances'] ?? [];
        $available = $data['available'] ?? [];

        // Instances rows
        $instancesRows = [];
        foreach ($instances as $mod) {
            $instancesRows[] = self::buildModuleRow($mod, true);
        }

        // Available rows
        $availableRows = [];
        foreach ($available as $mod) {
            $availableRows[] = self::buildModuleRow($mod, false);
        }

        // New foreign tags (programs not yet acknowledged)
        // Match by tag  -  the stable identity (SHA hash of BPF instructions).
        // Kernel IDs are ephemeral and change on every load; never match by id.
        $newForeignTags = [];
        foreach ($data['new_foreign_programs'] ?? [] as $nfp) {
            if (!empty($nfp['tag'])) {
                $newForeignTags[(string)$nfp['tag']] = true;
            }
        }

        // Detachable types (backend can safely detach these)
        $detachableTypes = ['xdp' => true, 'sched_cls' => true, 'sched_act' => true];

        // Internal programs (Styx infrastructure, e.g. xdp_dispatcher)
        $internalRows = [];
        foreach ($data['internal_programs'] ?? [] as $ip) {
            $internalRows[] = [
                // Pre-escaped values so the template only echoes.
                'id_html'        => self::esc((string)($ip['id'] ?? ' - ')),
                'type_html'      => self::esc((string)($ip['type'] ?? ' - ')),
                'name_html'      => self::esc((string)($ip['name'] ?? ' - ')),
                'tag_html'       => self::esc(isset($ip['tag']) ? substr((string)$ip['tag'], 0, 16) : ' - '),
                'loaded_at_html' => self::esc(isset($ip['loaded_at']) ? date('Y-m-d H:i:s', (int)$ip['loaded_at']) : ' - '),
                'uid_html'       => self::esc((string)($ip['uid'] ?? ' - ')),
            ];
        }

        // Foreign programs
        $foreignRows = [];
        foreach ($data['foreign_programs'] ?? [] as $fp) {
            $fpTag = isset($fp['tag']) ? (string)$fp['tag'] : null;
            $fpType = $fp['type'] ?? '';
            $isXdp = $fpType === 'xdp';
            $fpId = (string)($fp['id'] ?? '-');
            $fpName = (string)($fp['name'] ?? '-');
            $fpTypeLabel = $fpType !== '' ? $fpType : '-';
            $foreignRows[] = self::kernelProgramCells($fp) + [
                // Whole class attribute: new programs get the highlight row.
                'row_class_attr'      => ($fpTag !== null && isset($newForeignTags[$fpTag]))
                    ? ' class="ebpf-foreign-new-row"'
                    : '',
                // data-* of the detach button, pre-escaped for the template.
                'id_attr'             => self::esc($fpId),
                'name_attr'           => self::esc($fpName),
                'type_attr'           => self::esc($fpTypeLabel),
                'is_xdp_attr'         => $isXdp ? '1' : '0',
                'detachable'          => isset($detachableTypes[$fpType]),
            ];
        }

        // Stale dispatcher components: leftovers from an older generation of a
        // module we manage. They belong to no instance (so they never appear in
        // instances_rows) and they are not foreign either (they carry our own
        // program name, which is why the kernel scan cannot call them foreign),
        // so they need a section of their own. The gateway reports exactly the
        // list its startup reconciler sweeps.
        $staleRows = [];
        foreach ($data['stale_components'] ?? [] as $sc) {
            // Pre-escaped values so the template only echoes: *_html for text
            // cells, *_attr for the data-* attributes of the detach button.
            $scId   = (string)($sc['id'] ?? '-');
            $scName = (string)($sc['name'] ?? '-');
            $scIface = (string)($sc['iface'] ?? '-');
            $staleRows[] = [
                'id_html'         => self::esc($scId),
                'name_html'       => '<b>' . self::esc($scName) . '</b>',
                'interface_html'  => self::esc($scIface),
                'prio_html'       => self::esc((string)($sc['prio'] ?? '-')),
                'current_id_html' => self::esc((string)($sc['current_id'] ?? '-')),
                'id_attr'         => self::esc($scId),
                'name_attr'       => self::esc($scName),
                'interface_attr'  => self::esc($scIface),
            ];
        }

        // Unmanaged programs: carry a managed module's name and no instance owns
        // them. Not foreign (the foreign flow asks the operator to ack by tag,
        // which means nothing for a program with our own name) and not stale
        // components either (those are linked and the startup sweep removes
        // them). They can be removed, but not all through the same path: a
        // dispatcher component goes by program id, an XDP leftover by device
        // (the whole interface, dispatcher included) and a TC one by filter.
        // So they get the foreign row's action cell and gate, which is what the
        // backend does with them: the types it cannot address stay disabled
        // instead of offering a button that can only fail. And no per-row claim
        // of safety: what the gateway guarantees here is ownership, not
        // attachment, so a leftover may still be filtering.
        $unmanagedRows = [];
        foreach ($data['unmanaged_programs'] ?? [] as $up) {
            $upType = (string)($up['type'] ?? '');
            $isXdp  = $upType === 'xdp';
            $unmanagedRows[] = self::kernelProgramCells($up) + [
                'id_attr'             => self::esc((string)($up['id'] ?? '')),
                'name_attr'           => self::esc((string)($up['name'] ?? '')),
                'type_attr'           => self::esc($upType !== '' ? $upType : '-'),
                'is_xdp_attr'         => $isXdp ? '1' : '0',
                'detachable'          => isset($detachableTypes[$upType]),
            ];
        }

        // Loaded instances whose program is not attached to its interface: a
        // detach from outside the gateway, or an attach that did not survive the
        // boot. The datastore keeps saying they are loaded. Informational: the
        // gateway re-attaches them by itself (at boot, and after every load),
        // and the remedy by hand -- reload the module -- is a row away in the
        // instances table.
        $missingRows = [];
        foreach ($data['missing_components'] ?? [] as $mc) {
            $reason = (string)($mc['reason'] ?? '');
            $missingRows[] = [
                'module_html'     => '<b>' . self::esc((string)($mc['module'] ?? '-')) . '</b>',
                'interface_html'  => self::esc((string)($mc['iface'] ?? '-')),
                'program_id_html' => self::esc((string)($mc['program_id'] ?? '-')),
                'reason_html'     => self::esc(self::MISSING_REASON[$reason] ?? ($reason !== '' ? $reason : '-')),
                // Same abbreviated form (with the full value in the tooltip) as
                // the instances table this section points the operator at, so
                // the two can be matched on what is displayed.
                'instance_html'   => !empty($mc['instance_id']) ? self::uuidLabel((string)$mc['instance_id']) : '-',
            ];
        }

        // Conflicts
        $conflictRows = [];
        foreach ($data['conflicts'] ?? [] as $c) {
            $occupied = [];
            foreach ($c['occupied_by'] ?? [] as $o) {
                $occupied[] = ($o['name'] ?? '?') . ' (id=' . ($o['id'] ?? '?') . ')';
            }
            $conflictRows[] = [
                'interface_html'   => self::esc((string)($c['interface'] ?? '-')),
                'hook_html'        => self::esc((string)($c['hook'] ?? '-')),
                'styx_module_html' => '<b>' . self::esc((string)($c['styx_module'] ?? '-')) . '</b>',
                'occupied_by_html' => self::esc(implode(', ', $occupied) ?: '-'),
            ];
        }

        // Coexisting
        $coexistingRows = [];
        foreach ($data['coexisting'] ?? [] as $c) {
            $other = [];
            foreach ($c['other_programs'] ?? [] as $o) {
                $other[] = ($o['name'] ?? '?') . ' (id=' . ($o['id'] ?? '?') . ')';
            }
            $coexistingRows[] = [
                'interface_html'   => self::esc((string)($c['interface'] ?? '-')),
                'hook_html'        => self::esc((string)($c['hook'] ?? '-')),
                'styx_module_html' => '<b>' . self::esc((string)($c['styx_module'] ?? '-')) . '</b>',
                'others_html'      => self::esc(implode(', ', $other) ?: '-'),
            ];
        }

        return [
            'instances_rows'    => $instancesRows,
            'available_rows'    => $availableRows,
            'available_count'   => count($availableRows),
            'has_available'     => !empty($availableRows),
            'internal_rows'     => $internalRows,
            'internal_count'    => count($internalRows),
            'has_internal'      => !empty($internalRows),
            'foreign_rows'      => $foreignRows,
            'foreign_count'     => count($foreignRows),
            'has_foreign'       => !empty($foreignRows),
            'has_new_foreign'   => !empty($newForeignTags),
            'stale_rows'        => $staleRows,
            'stale_count'       => count($staleRows),
            'has_stale'         => !empty($staleRows),
            'unmanaged_rows'    => $unmanagedRows,
            'unmanaged_count'   => count($unmanagedRows),
            'has_unmanaged'     => !empty($unmanagedRows),
            'missing_rows'      => $missingRows,
            'missing_count'     => count($missingRows),
            'has_missing'       => !empty($missingRows),
            'conflict_rows'     => $conflictRows,
            'conflict_count'    => count($conflictRows),
            'has_conflicts'     => !empty($conflictRows),
            'coexisting_rows'   => $coexistingRows,
            'coexisting_count'  => count($coexistingRows),
            'has_coexisting'    => !empty($coexistingRows),
            'counts_html'       => self::countsHtml(
                (int)($data['styx_program_count'] ?? 0),
                (int)($data['total_kernel_programs'] ?? 0)
            ),
            'api_ok'            => true,
        ];
    }

    //
    // HELPERS
    //

    public static function statusBadge(string $status): string
    {
        $cls  = self::STATUS_BADGE[$status] ?? 'ebpf-status-available';
        $label = self::STATUS_LABEL[$status] ?? '○ Available';
        return '<span class="ebpf-status-badge ' . $cls . '">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</span>';
    }

    public static function typeBadge(string $mode): string
    {
        $cls = self::TYPE_BADGE[$mode] ?? '';
        return '<span class="ebpf-info-tag ' . $cls . '">' . htmlspecialchars($mode, ENT_QUOTES, 'UTF-8') . '</span>';
    }

    public static function shortUuid(?string $uuid): string
    {
        if (empty($uuid)) return '-';
        if (strlen($uuid) > 12) return substr($uuid, 0, 8) . '...' . substr($uuid, -4);
        return $uuid;
    }

    public static function uuidLabel(?string $uuid): string
    {
        if (empty($uuid)) return '';
        return '<span class="ebpf-uuid" title="' . htmlspecialchars($uuid, ENT_QUOTES, 'UTF-8') . '">'
            . self::shortUuid($uuid) . '</span>';
    }

    //
    // PRIVATE
    //

    /** Escape a value for use inside a double-quoted HTML attribute. */
    private static function esc(?string $value): string
    {
        return Filter::escHtml($value);
    }

    /** Pre-escaped JSON string for a data-* attribute (quotes would break it raw). */
    private static function jsonAttr(array $value): string
    {
        return Filter::escHtml((string) json_encode($value, JSON_UNESCAPED_SLASHES));
    }

    /**
     * The display cells every kernel program row shares (foreign, unmanaged: the
     * gateway builds both from the same program dict). Pre-escaped values so the
     * template only echoes.
     *
     * @param array<string,mixed> $p A program as the kernel scan reports it
     * @return array<string,string>
     */
    private static function kernelProgramCells(array $p): array
    {
        return [
            'id_html'        => self::esc((string)($p['id'] ?? '-')),
            'type_html'      => self::esc(isset($p['type']) && $p['type'] !== '' ? (string)$p['type'] : '-'),
            'name_html'      => self::esc((string)($p['name'] ?? '-')),
            'tag_html'       => self::esc(isset($p['tag']) ? substr((string)$p['tag'], 0, 16) : '-'),
            'loaded_at_html' => self::esc(isset($p['loaded_at']) ? date('Y-m-d H:i:s', (int)$p['loaded_at']) : '-'),
            'uid_html'       => self::esc((string)($p['uid'] ?? '-')),
        ];
    }

    /** Pre-built header counts (Styx / Kernel) so the template only echoes. */
    private static function countsHtml(int $styxCount, int $kernelCount): string
    {
        return '<span class="ebpf-counts">Styx: <b>' . $styxCount . '</b>'
            . '&nbsp;|&nbsp; Kernel: <b>' . $kernelCount . '</b></span>';
    }

    private static function buildModuleRow(array $mod, bool $isInstance): array
    {
        $status = $mod['status'] ?? ($isInstance ? 'loaded' : 'available');
        $interface = $mod['interface'] ?? '';
        $name = $mod['name'] ?? '-';
        $version = $mod['version'] ?? '';
        $mode = $mod['mode'] ?? '';
        $hookType = $mod['hook_type'] ?? '-';
        $instanceId = $mod['instance_id'] ?? null;
        $preAttachParams = $mod['pre_attach_params'] ?? [];

        // Every value the template needs is pre-escaped here (echo-only template),
        // so the row carries the *_html / *_attr projections and nothing else.
        return [
            'uuid_html'     => self::uuidLabel($instanceId),
            'status_html'   => self::statusBadge($status),
            'type_html'     => self::typeBadge($mode),
            'name_attr'             => self::esc($name),
            'version_attr'          => self::esc($version),
            'mode_attr'             => self::esc($mode),
            'hook_type_attr'        => self::esc($hookType),
            'interface_attr'        => self::esc($interface !== '' ? $interface : '-'),
            'instance_id_attr'      => self::esc((string)$instanceId),
            'identifier_attr'       => self::esc((string)($instanceId ?: $name)),
            'pre_attach_params_json' => self::jsonAttr($preAttachParams),
            'status_attr'           => self::esc($status),
            'attach_target_attr'    => self::esc((string)($mod['attach_target'] ?? 'interface')),
            'is_instance_attr'      => !empty($instanceId) ? '1' : '0',
            'autoload_attr'         => ($mod['autoload'] ?? false) ? 'checked' : '',
            'has_autoload'          => $isInstance && !empty($instanceId),
            // Capability flags: the template branches on these, not on the status.
            'activatable'           => $status === 'inactive' || $status === 'suspended',
            'loadable'              => $status !== 'incompatible',
        ];
    }
}
