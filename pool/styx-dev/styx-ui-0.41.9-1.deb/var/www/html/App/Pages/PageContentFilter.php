<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Services\AuthService;
use App\Helpers\RoleHelper;
use App\Controllers\Request\CategoriesRequestController;
use App\Controllers\Request\DnsFilterRequestController;
use App\Controllers\Request\WebFilterRequestController;
use App\Pages\Fmt\ContentFilterCategoriesFormatter;
use App\Pages\Fmt\ContentFilterDnsFormatter;
use App\Pages\Fmt\ContentFilterWebFormatter;

/**
 * Content Filter: the catalogue and the two mechanisms that act on it.
 *
 * Three sections, one per module of the same API group:
 *   cf-categories - the shared catalogue (what a domain IS)
 *   cf-web        - the web filter (blocks on the flow's own Host/SNI)
 *   cf-dns        - the DNS filter (rewrites or cuts the answer)
 *
 * The catalogue is **shared** and is edited once: what a domain is does not
 * depend on which mechanism looks at it. What to DO with a category is each
 * filter's own policy (design doc, decision 1), which is why there are two
 * separate policy panes and neither of them owns the taxonomy.
 *
 * A section whose feature is off is still rendered, but the pane says so: its
 * settings would be stored and never applied, and showing a form that cannot
 * take effect is exactly the choice the design refuses to offer.
 */
class PageContentFilter
{
    /** Sections in menu order. */
    private const SECTIONS = ['cf-categories', 'cf-web', 'cf-dns'];

    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);
        $features = $cfg->get('features', []);

        $section = Filter::getString('section');
        if (empty($section) || !in_array($section, self::SECTIONS)) {
            $section = 'cf-categories';
        }

        $auth    = $ctx->get(AuthService::class);
        $caps    = $auth->getCapabilities();
        $canEdit = RoleHelper::hasCapability($caps, 'content_filter:write');
        $canDelete = RoleHelper::hasCapability($caps, 'content_filter:delete');

        $fmt = [];
        if ($section === 'cf-categories') {
            $fmt = self::categories($ctx, $canEdit, $canDelete);
            $page['web_main']['footer_script'][] = ['src' => '/scripts/content-filter/categories.js'];
        } elseif ($section === 'cf-web') {
            $fmt = self::web($ctx, $features, $canEdit);
            $page['web_main']['footer_script'][] = ['src' => '/scripts/content-filter/web-filter.js'];
        } elseif ($section === 'cf-dns') {
            $fmt = self::dns($ctx, $features, $canEdit);
            $page['web_main']['footer_script'][] = ['src' => '/scripts/content-filter/dns-filter.js'];
        }
        $page['web_main']['cssfile'][] = 'default-content-filter';

        $page['page'] = $section;
        $page['page_data'] = $fmt;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $features],
            'place' => 'sidebar'
        ];

        return $page;
    }

    /**
     * The shared catalogue: taxonomy by group, entries and counters.
     *
     * @return array<string,mixed>
     */
    private static function categories(AppContext $ctx, bool $canEdit, bool $canDelete): array
    {
        $controller = new CategoriesRequestController($ctx);
        $response = $controller->getCatalog();
        if (($response['status'] ?? '') === 'error') {
            return ContentFilterCategoriesFormatter::error(
                (string)($response['result']['msg'] ?? 'Could not load the catalogue')
            );
        }

        $result = $response['result'] ?? [];
        return ContentFilterCategoriesFormatter::format(
            [
                'entries'    => $result['entries'] ?? [],
                'categories' => $result['categories'] ?? [],
                'groups'     => $result['groups'] ?? [],
                'posture'    => $result['posture'] ?? [],
                'stats'      => $result['stats'] ?? [],
            ],
            $canEdit,
            $canDelete
        );
    }

    /**
     * The taxonomy alone: the categories and their groups, no entries.
     *
     * The policy panes need it to offer a category to decide about. A failure
     * here is not fatal for those panes - they render the policy they could read
     * and say the taxonomy is missing - so it returns empty instead of an error.
     *
     * @return array{categories: array<int,mixed>, groups: array<int,mixed>}
     */
    private static function taxonomy(AppContext $ctx): array
    {
        $controller = new CategoriesRequestController($ctx);
        $response = $controller->getCatalog();
        $result = ($response['status'] ?? '') === 'success' ? ($response['result'] ?? []) : [];
        return [
            'categories' => $result['categories'] ?? [],
            'groups'     => $result['groups'] ?? [],
        ];
    }

    /**
     * The web filter: its policy and what it is doing.
     *
     * @param array<string,mixed> $features
     * @return array<string,mixed>
     */
    private static function web(AppContext $ctx, array $features, bool $canEdit): array
    {
        $controller = new WebFilterRequestController($ctx);
        $settings = $controller->getSettings();
        $status   = $controller->getStatus();
        // The posture editor picks a category, and the taxonomy lives in the
        // shared catalogue - not in this filter's settings, which only carry the
        // ones already decided.
        $catalogue = self::taxonomy($ctx);

        return ContentFilterWebFormatter::format(
            [
                'settings' => ($settings['status'] ?? '') === 'success' ? ($settings['result'] ?? []) : [],
                'status'   => ($status['status'] ?? '') === 'success' ? ($status['result'] ?? []) : [],
                'categories' => $catalogue['categories'],
                'groups'     => $catalogue['groups'],
                'error'    => ($settings['status'] ?? '') === 'success'
                    ? null
                    : ($settings['result']['msg'] ?? 'Could not load the web filter settings'),
                'status_error' => ($status['status'] ?? '') === 'success'
                    ? null
                    : ($status['result']['msg'] ?? 'Could not load the web filter status'),
            ],
            $canEdit,
            !empty($features['web_filter'])
        );
    }

    /**
     * The DNS filter: its policy and what it is doing.
     *
     * @param array<string,mixed> $features
     * @return array<string,mixed>
     */
    private static function dns(AppContext $ctx, array $features, bool $canEdit): array
    {
        $controller = new DnsFilterRequestController($ctx);
        $settings = $controller->getSettings();
        $status   = $controller->getStatus();
        $catalogue = self::taxonomy($ctx);

        return ContentFilterDnsFormatter::format(
            [
                'settings' => ($settings['status'] ?? '') === 'success' ? ($settings['result'] ?? []) : [],
                'status'   => ($status['status'] ?? '') === 'success' ? ($status['result'] ?? []) : [],
                'categories' => $catalogue['categories'],
                'groups'     => $catalogue['groups'],
                'error'    => ($settings['status'] ?? '') === 'success'
                    ? null
                    : ($settings['result']['msg'] ?? 'Could not load the DNS filter settings'),
                'status_error' => ($status['status'] ?? '') === 'success'
                    ? null
                    : ($status['result']['msg'] ?? 'Could not load the DNS filter status'),
            ],
            $canEdit,
            !empty($features['dns_filter'])
        );
    }
}
