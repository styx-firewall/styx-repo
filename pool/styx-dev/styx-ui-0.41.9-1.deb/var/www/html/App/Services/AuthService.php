<?php
/**
 *
 *  @author STYX FLF
 *  @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 *  @dr 2026/03/17
 */

namespace App\Services;

use App\Core\AppContext;
use App\Core\Config;
use App\Core\SessionManager;
use App\Services\LogSystemService;

class AuthService
{
    private AppContext $ctx;
    private ?string $bearerToken = null;

    public function __construct(AppContext $ctx)
    {
        $this->ctx = $ctx;
    }

    /**
     * Start the session if it is not already active
     *
     * @return bool True if session is active or started successfully, false otherwise
     */
    private function ensureSessionStarted(): bool
    {
        // Delegate to SessionManager: true if active.
        try {
            return SessionManager::start($this->ctx, $this->ctx->get(Config::class));
        } catch (\Throwable $e) {
            // Log the failure and avoid starting a session with unknown configuration.
            // This prevents creating sessions that bypass SessionManager's settings.
            $logger = null;
            try {
                $logger = $this->ctx->get(LogSystemService::class);
            } catch (Throwable $_) {
                $logger = null;
            }
            if ($logger !== null) {
                $logger->warning('SessionManager::start failed', ['exception' => $e]);
            }
            return false;
        }
    }

    /**
     * Store the user token in the session and regenerate the session id
     * to prevent session fixation attacks.
     *
     * @param string $token
     * @return bool True if token was stored, false if session failed
     */
    public function setUserToken(string $token): bool
    {
        if (!$this->ensureSessionStarted()) {
            return false;
        }
        // Regenerate session id to prevent fixation
        if (function_exists('session_regenerate_id')) {
            session_regenerate_id(true);
        }
        $_SESSION['user_token'] = $token;
        return true;
    }

    /**
     * Perform a secure logout: clear the session data, remove the session
     * cookie if present, and destroy the session on the server.
     *
     * @return bool True if logout succeeded, false if session failed
     */
    public function logout(): bool
    {
        if (!$this->ensureSessionStarted()) {
            return false;
        }

        // Delegate destruction and cookie removal to SessionManager
        SessionManager::destroy();
        return true;
    }

    /**
     * Check if the user is authenticated (presence of token in session)
     *
     * @return bool True if authenticated, false otherwise (including session failure)
     */
    public function isAuthenticated(): bool
    {
        if (!$this->ensureSessionStarted()) {
            return false;
        }
        return !empty($_SESSION['user_token']);
    }

    /**
     * Get the user token from the session, or the bearer token if set.
     * Bearer token takes precedence - it is forwarded to the Python backend,
     * which validates it automatically via handler_client.py.
     *
     * @return string|null
     */
    public function getUserToken(): ?string
    {
        if ($this->bearerToken !== null) {
            return $this->bearerToken;
        }
        if (!$this->ensureSessionStarted()) {
            return null;
        }
        return $_SESSION['user_token'] ?? null;
    }

    /**
     * Store a bearer token for the current request.
     * The real validation happens at the Python backend automatically.
     */
    public function setBearerToken(string $token): void
    {
        $this->bearerToken = $token;
    }

    /**
     * Store the authenticated username in the session.
     *
     * @param string $username
     * @return bool
     */
    public function setUsername(string $username): bool
    {
        if (!$this->ensureSessionStarted()) {
            return false;
        }
        $_SESSION['username'] = $username;
        return true;
    }

    /**
     * Get the authenticated username from the session.
     *
     * @return string|null
     */
    public function getUsername(): ?string
    {
        if (!$this->ensureSessionStarted()) {
            return null;
        }
        $u = $_SESSION['username'] ?? null;
        return is_string($u) && $u !== '' ? $u : null;
    }

    /**
     * Store the user's role in session.
     *
     * @param string $role
     * @return bool
     */
    public function setRole(string $role): bool
    {
        if (!$this->ensureSessionStarted()) {
            return false;
        }
        $_SESSION['role'] = $role;
        return true;
    }

    /**
     * Get the user's role from session.
     *
     * @return string|null
     */
    public function getRole(): ?string
    {
        if (!$this->ensureSessionStarted()) {
            return null;
        }
        $r = $_SESSION['role'] ?? null;
        return is_string($r) && $r !== '' ? $r : null;
    }

    /**
     * Store the user's capabilities in session.
     *
     * @param string[] $capabilities
     * @return bool
     */
    public function setCapabilities(array $capabilities): bool
    {
        if (!$this->ensureSessionStarted()) {
            return false;
        }
        $_SESSION['capabilities'] = $capabilities;
        return true;
    }

    /**
     * Get the user's capabilities from session.
     *
     * @return string[]
     */
    public function getCapabilities(): array
    {
        if (!$this->ensureSessionStarted()) {
            return [];
        }
        $caps = $_SESSION['capabilities'] ?? [];
        return is_array($caps) ? $caps : [];
    }

    /**
     * Whether capabilities have been stored in session (even if empty).
     * Returns false for stale sessions that pre-date RBAC.
     *
     * @return bool
     */
    public function hasCapabilitiesLoaded(): bool
    {
        if (!$this->ensureSessionStarted()) {
            return false;
        }
        return isset($_SESSION['capabilities']) && is_array($_SESSION['capabilities']);
    }
}
