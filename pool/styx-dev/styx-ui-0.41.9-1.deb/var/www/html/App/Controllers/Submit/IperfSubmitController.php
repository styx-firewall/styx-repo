<?php

namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class IperfSubmitController extends BaseController
{

    /**
     * Start an iperf3 server
     * @param array $data
     * @return array
     */
    public function startServer(array $data)
    {
        $allowed_fields = [
            'port', 'one_off', 'udp', 'bind_address', 'window', 'tos',
            'forceflush', 'username', 'password'
        ];
        $integer_fields = ['port', 'tos'];
        $bool_fields = ['one_off', 'udp', 'forceflush'];

        $request_data = [];
        foreach ($allowed_fields as $field) {
            if (!array_key_exists($field, $data)) {
                continue;
            }
            if (in_array($field, $integer_fields, true)) {
                $request_data[$field] = (int)$data[$field];
            } elseif (in_array($field, $bool_fields, true)) {
                $request_data[$field] = (bool)$data[$field];
            } else {
                $request_data[$field] = $data[$field];
            }
        }

        $commands = [
            [
                'method' => 'iperf-service.start_server',
                'id' => 'start_server',
                'data' => $request_data,
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['start_server'] ?? $this->baseError('No response for start_server');
    }

    /**
     * Stop the iperf3 server
     * @param array $data
     * @return array
     */
    public function stopServer(array $data)
    {
        $commands = [
            [
                'method' => 'iperf-service.stop_server',
                'id' => 'stop_server',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['stop_server'] ?? $this->baseError('No response for stop_server');
    }

    /**
     * Get iperf3 server status
     * @param array $data
     * @return array
     */
    public function serverStatus($data)
    {
        $commands = [
            [
                'method' => 'iperf-service.server_status',
                'id' => 'server_status',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['server_status'] ?? $this->baseError('No response for server_status');
    }
    /**
     * Start an iperf3 client test (async via TaskManager)
     * @param array $data
     * @return array
     */
    public function startClientTest(array $data)
    {
        $allowed_fields = [
            'server_ip', 'port', 'duration', 'parallel', 'bandwidth', 'udp',
            'reverse', 'interval', 'window', 'tos', 'omit', 'forceflush',
            'get_server_output', 'verbose', 'username', 'password'
        ];
        $integer_fields = ['port', 'duration', 'parallel', 'interval', 'tos', 'omit'];
        $bool_fields = ['udp', 'reverse', 'forceflush', 'get_server_output', 'verbose'];

        $request_data = [];
        foreach ($allowed_fields as $field) {
            if (!array_key_exists($field, $data)) {
                continue;
            }
            if (in_array($field, $integer_fields, true)) {
                $request_data[$field] = (int)$data[$field];
            } elseif (in_array($field, $bool_fields, true)) {
                $request_data[$field] = (bool)$data[$field];
            } else {
                $request_data[$field] = $data[$field];
            }
        }

        $commands = [
            [
                'method' => 'iperf-service.start_client_test',
                'id' => 'start_client_test',
                'data' => $request_data,
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['start_client_test'] ?? $this->baseError('No response for start_client_test');
    }

    /**
     * Get list of iperf tasks
     * @param array $data
     * @return array
     */
    public function getIperfTasks($data)
    {
        $commands = [
            [
                'method' => 'iperf-service.get_iperf_tasks',
                'id' => 'get_iperf_tasks',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['get_iperf_tasks'] ?? $this->baseError('No response for get_iperf_tasks');
    }

    /**
     * Get result of a specific task
     * @param array $data
     * @return array
     */
    public function getTaskResult($data)
    {
        if (empty($data['task_id'])) {
            return $this->baseError('task_id is required');
        }

        $commands = [
            [
                'method' => 'iperf-service.get_task_result',
                'id' => 'get_task_result',
                'data' => ['task_id' => $data['task_id']],
            ]
        ];
            $resp = $this->processGwResp($this->sendCommands($commands));
            return $resp['commands']['get_task_result'] ?? $this->baseError('No response for get_task_result');
    }
}
