<?php

namespace App\Controllers\Submit;

use App\Controllers\BaseController;
use App\Helpers\ContentFilterResp;

/**
 * DNS filter write path.
 *
 * Registered commands (SubmitRegistry):
 *   dns-filter.set_settings -> setSettings()
 *   dns-filter.set_active   -> setActive()
 *
 * Responses are canonicalized through App\Helpers\ContentFilterResp: messages
 * always come from result.msg (the top-level response_msg legacy bridge is
 * ignored). RBAC is enforced by the backend (content_filter:write).
 *
 * No `posture` here: the policy is the catalogue's (categories.set_posture),
 * because this filter cuts first and a divergent web filter would only be heard
 * on the flows this one did not see. `DATA_KEYS` is what keeps a posture out of
 * the call: this endpoint changes what this mechanism does with the policy, not
 * what the policy is.
 *
 * Saving **applies**, and only while the filter is switched on: the gateway
 * regenerates the nft rules, repoints the running engine at the shared policy and
 * updates the live decider. When the filter is off the settings are still stored,
 * but the response says so (`apply` is null and the message says they take effect
 * when it is switched on) - the UI must surface that rather than report a plain
 * success.
 *
 * An error can therefore mean the settings were stored but could not be put in
 * force; result.msg says which, and the UI must surface it.
 *
 * `set_active` is not a setting: it is the filter's own on/off, and being
 * ENABLED (the feature) is not being switched on. Here the separation is the
 * dangerous case written down: a queue rule with no reader holds the traffic it
 * matches, so the gateway arms both together or neither.
 */
class DnsFilterSubmitController extends BaseController
{
    /** Top-level keys accepted by the partial settings payload. */
    private const DATA_KEYS = [
        'sinkhole_address',
        'sinkhole_address6',
        'fail_mode',
        'chains',
    ];

    /** The on/off payload: one key, and it is not merged with the settings. */
    private const ACTIVE_KEYS = ['active'];

    /**
     * Save a (partial) set of this filter's settings. Omitted keys keep their
     * current value; `chains` is replaced wholesale, so the frontend always
     * sends the complete list.
     *
     * @param array<string,mixed> $data request body (command/metadata are ignored)
     * @return array<string,mixed>
     */
    public function setSettings(array $data = []): array
    {
        $unknown = $this->unknownFields($data, self::DATA_KEYS);
        if (!empty($unknown)) {
            return ContentFilterResp::error('unknown field(s): ' . implode(', ', $unknown));
        }
        $payload  = array_intersect_key($data, array_flip(self::DATA_KEYS));
        $commands = [
            [
                'method' => 'dns-filter.set_settings',
                'id'     => 'set_settings',
                'data'   => $payload,
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return ContentFilterResp::single($resp, 'set_settings');
    }

    /**
     * Switch the filter on or off. The switch is persisted by the gateway, so a
     * filter left switched on comes back switched on after a restart.
     *
     * The gateway refuses a switch-on while the feature is off, and switching on
     * is atomic there: an error means nothing was armed and the filter is off, so
     * the UI reverts the switch and shows result.msg. With this filter that is the
     * point of the atomicity: a queue rule whose reader did not come up would hold
     * - and with `strict`, drop - every DNS response it matches.
     *
     * @param array<string,mixed> $data request body (command/metadata are ignored)
     * @return array<string,mixed>
     */
    public function setActive(array $data = []): array
    {
        $unknown = $this->unknownFields($data, self::ACTIVE_KEYS);
        if (!empty($unknown)) {
            return ContentFilterResp::error('unknown field(s): ' . implode(', ', $unknown));
        }
        if (!is_bool($data['active'] ?? null)) {
            // Not coerced: `"false"` is a truthy string, and guessing which one the client
            // meant is how a switch ends up doing the opposite of what was asked.
            return ContentFilterResp::error('active must be true or false');
        }
        $commands = [
            [
                'method' => 'dns-filter.set_active',
                'id'     => 'set_active',
                'data'   => ['active' => $data['active']],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return ContentFilterResp::single($resp, 'set_active');
    }
}
