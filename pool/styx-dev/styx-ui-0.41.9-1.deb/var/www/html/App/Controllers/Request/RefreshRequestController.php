<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class RefreshRequestController extends BaseController
{
    public function __construct(AppContext $ctx)
    {
        parent::__construct($ctx);
    }

    /**
     * Processes the refresh action and returns a response array.
     * The commands sent to the gateway are based on the page and section.
     * The client body is not a source of gateway commands: a `commands` key
     * in the body is ignored, so this endpoint cannot be used as a pass-through
     * for arbitrary gateway methods (see GatewayService: the payload here is
     * the only one this action forwards).
     *
     * The response always carries `action => 'refreshed'` (success and error
     * alike); the client uses it to identify the reply.
     *
     * @param array $data
     * @return array
     */
    public function refreshPage(array $data): array
    {
        $page = $data['page'] ?? '';
        $section = $data['section'] ?? '';
        $commands = [];
        $create = $data['create'] ?? false;
        $modify = $data['modify'] ?? false;
        $firstRefresh = $data['firstRefresh'] ?? false;

        $pages_with_ping = [
            'dashboard', 'index', 'network', 'firewall', 'system', 'vpn', 'idsips',
            'styx','users', 'logs', 'packet_marking', 'traffic_shaping', 'services',
            'ebpf', 'objects', 'routing', 'security', 'content_filter', 'ha'
        ];

        if (in_array($page, $pages_with_ping, true)) {
            $pingData = [
                'client_timestamp' => $data['client_timestamp'] ?? microtime(true),
            ];
            if (isset($data['last_task_id'])) {
                $pingData['last_task_id'] = $data['last_task_id'];
            }
            if (isset($data['pending_task_ids'])) {
                $pingData['pending_task_ids'] = $data['pending_task_ids'];
            }
            $commands[] = [
                'method' => 'gateway-daemon.ping',
                'id' => 'ping',
                'data' => $pingData,
            ];
        }

        if ($page === 'dashboard' || $page === 'index') {
            if (empty($section) && $firstRefresh) {
                $commands[] = [
                    'method' => 'system-overview.get_system_info',
                    'id' => 'sys_info',
                    'data' => (object)[],
                ];
            }
        }

        if (empty($commands)) {
            return [
                'status'   => 'success',
                'commands' => [],
                'metadata' => ['recv_timestamp' => microtime(true)],
                'action'   => 'refreshed',
            ];
        }

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            $result = [
                'status'       => 'error',
                'response_msg' => $resp['response_msg'] ?? 'Unknown error',
                'commands'     => array_values($resp['commands'] ?? []),
                'warnings'     => $resp['warnings'] ?? [],
                'metadata'     => ['recv_timestamp' => microtime(true)],
            ];
            if (!empty($resp['error_code'])) {
                $result['error_code'] = $resp['error_code'];
            }
            $result['action'] = 'refreshed';
            return $result;
        }
        // Commands returned are not fixed and depend on the request, so we return them as an array
        // with their original keys (not indexed by id)
        return [
            'status'   => $resp['status'],
            'commands' => array_values($resp['commands']),
            'warnings' => $resp['warnings'],
            'metadata' => ['recv_timestamp' => microtime(true)],
            'action'   => 'refreshed',
        ];
    }
}
