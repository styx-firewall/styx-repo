<?php

namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class FirewallSubmitController extends BaseController
{

    public function deleteFirewallRule(array $data)
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Firewall rule ID not provided');
        }
        $commands = [
            [
                'method' => 'firewall-rules.delete_firewall_rule',
                'id' => 'delete_firewall_rule',
                'data' => ['id' => $id],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['delete_firewall_rule'] ?? $this->baseError('No response for delete_firewall_rule');
    }

    /**
     * Update the firewall settings (conntrack bypass / drop invalid toggles)
     * @param array $data
     * @return array
     */
    public function setFirewallSettings(array $data)
    {
        $commands = [
            [
                'method' => 'firewall-settings.set_firewall_settings',
                'id'     => 'set_firewall_settings',
                'data'   => $data,
            ]
        ];
        $response = $this->sendCommands($commands);
        $resp = $this->processGwResp($response);
        return $resp['commands']['set_firewall_settings'] ?? $this->baseError('No response for set_firewall_settings');
    }

    /**
     * Sets a firewall rule
     * @param array $data
     * @return array
     */
    public function setFirewallRule(array $data)
    {
        $data = self::normalizeFlags($data);
        $commands = [
            [
                'method' => 'firewall-rules.set_firewall_rule',
                'id' => 'set_firewall_rule',
                'data' => $data,
            ]
        ];
        $response = $this->sendCommands($commands);
        $resp = $this->processGwResp($response);
        return $resp['commands']['set_firewall_rule'] ?? $this->baseError('No response for set_firewall_rule');
    }

    /**
     * Updates an existing firewall rule
     * @param array $data
     * @return array
     */
    public function updateRule(array $data)
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Firewall rule ID not provided');
        }

        $data = self::normalizeFlags($data);

        $commands = [
            [
                'method' => 'firewall-rules.update_firewall_rule',
                'id' => 'update_firewall_rule',
                'data' => $data,
            ]
        ];
        $response = $this->sendCommands($commands);
        $resp = $this->processGwResp($response);
        return $resp['commands']['update_firewall_rule'] ?? $this->baseError('No response for update_firewall_rule');
    }

    public function moveRule(array $data)
    {
        $id = $data['id'] ?? null;
        $ref_id = $data['ref_id'] ?? null;
        $position = $data['position'] ?? null;

        $gw_data = ['id' => $id];

        if ($ref_id !== null && $ref_id !== '') {
            if (!in_array($position, ['before', 'after'])) {
                return $this->baseError('Invalid position: must be "before" or "when" ref_id is provided');
            }
            $gw_data['ref_id'] = $ref_id;
            $gw_data['position'] = $position;
        }

        if (empty($id)) {
            return $this->baseError('Firewall rule ID not provided');
        }

        $commands = [
            [
                'method' => 'firewall-rules.move_firewall_rule',
                'id' => 'move_firewall_rule',
                'data' => $gw_data,
            ]
        ];

        $response = $this->sendCommands($commands);
        $resp = $this->processGwResp($response);
        return $resp['commands']['move_firewall_rule'] ?? $this->baseError('No response for move_firewall_rule');
    }

    /**
     * Enable/disable a firewall rule by id (backend: set_firewall_rule_enabled).
     *
     * @param array $data Fields: id (required), enabled (bool, default true).
     * @return array Gateway-shaped response
     */
    public function setFirewallRuleEnabled(array $data)
    {
        $id = $data['id'] ?? null;
        if (!$id) {
            return $this->baseError('Firewall rule ID not provided');
        }
        $enabled = isset($data['enabled']) ? (bool) $data['enabled'] : true;
        $commands = [
            [
                'method' => 'firewall-rules.set_firewall_rule_enabled',
                'id'     => 'set_firewall_rule_enabled',
                'data'   => ['id' => $id, 'enabled' => $enabled],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['set_firewall_rule_enabled'] ?? $this->baseError('No response for set_firewall_rule_enabled');
    }

    /**
     * Reload all firewall rules from the datastore (backend: firewall_reload).
     *
     * @param array $data Ignored.
     * @return array Gateway-shaped response
     */
    public function reloadFirewallRules(array $data)
    {
        $commands = [
            [
                'method' => 'firewall-rules.firewall_reload',
                'id'     => 'firewall_reload',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return $resp['commands']['firewall_reload'] ?? $this->baseError('No response for firewall_reload');
    }

    /**
     * Preview a firewall rule (no persist, no OS)
     *
     * Accepts the same payload as setFirewallRule.
     *
     * @param array $data
     * @return array Gateway-shaped response
     */
    public function previewRule(array $data)
    {
        // Basic validation consistent with the frontend checks
        $name = $data['name'] ?? '';
        if (empty($name)) {
            return $this->baseError('Rule name is required');
        }

        $family = $data['family'] ?? '';
        if (empty($family)) {
            return $this->baseError('Family is required');
        }

        $action = $data['action'] ?? '';
        if (empty($action)) {
            return $this->baseError('Action is required');
        }

        $data = self::normalizeFlags($data);

        $cmd = [
            'method' => 'firewall-rules.preview_firewall_rule',
            'id' => 'preview_firewall_rule',
            'data' => $data,
        ];

        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['preview_firewall_rule'] ?? $this->baseError('No response for preview_firewall_rule');
    }

    /**
     * Normalize common flag fields to booleans as required by the backend schema.
     *
     * @param array $data
     * @return array
     */
    private static function normalizeFlags(array $data): array
    {
        foreach (['enabled', 'nat', 'log'] as $flag) {
            if (isset($data[$flag])) {
                $data[$flag] = (bool) $data[$flag];
            }
        }
        return $data;
    }

}
