<?php

namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class NetTunningSubmitController extends BaseController
{
    /**
     * Saves sysctl changes for a specific interface
     * @param array $data
     * @return array
     */
    public function saveIfaceSysctl(array $data)
    {
        $iface_id = $data['iface_id'] ?? '';
        $sysctl_keys = $data['sysctl_keys'] ?? [];
        $values = $data['value'] ?? [];
        if ($iface_id === '' || empty($sysctl_keys) || empty($values) || count($sysctl_keys) !== count($values)) {
            return $this->baseError('Interface id (iface_id), keys and values are required and must match in length');
        }
        $pairs = [];
        foreach ($sysctl_keys as $i => $key) {
            if ($key === '' || $values[$i] === '') {
                return $this->baseError('All keys and values must be complete: ' . $key . ' => ' . $values[$i]);
            }
            $pairs[] = [
                'sysctl_key' => $key,
                'value' => $values[$i],
            ];
        }
        $command = [
            'method' => 'sysctl-config.set_iface_sysctl_keys_bulk',
            'id' => 'set_iface_sysctl_keys_bulk',
            'data' => [
                'iface_id' => $iface_id,
                'sysctl_keys' => $pairs,
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands([$command]));
        return $resp['commands']['set_iface_sysctl_keys_bulk'] ?? $this->baseError('No response for set_iface_sysctl_keys_bulk');
    }
    /**
     * Saves sysctl tuning changes
     * @param array $data
     * @return array
     */
    public function saveSysctlTunning(array $data)
    {
        $pairs = [];
        foreach ($data['sysctl_keys'] as $item) {
            $key = $item['sysctl_key'] ?? '';
            $value = $item['value'] ?? '';
            if ($key === '' || $value === '') {
                return $this->baseError('All keys and values must be complete');
            }
            $pairs[] = [
                'sysctl_key' => $key,
                'value' => $value,
            ];
        }
        if (empty($pairs)) {
            return $this->baseError('No changes provided to save');
        }
        $command = [
            'method' => 'sysctl-config.set_sysctl_keys_bulk',
            'id' => 'set_sysctl_keys_bulk',
            'data' => [
                'sysctl_keys' => $pairs,
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands([$command]));
        return $resp['commands']['set_sysctl_keys_bulk'] ?? $this->baseError('No response for set_sysctl_keys_bulk');
    }
}
