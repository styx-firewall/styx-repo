<?php

namespace App\Controllers\Submit;

use App\Controllers\BaseController;
use App\Helpers\ContentFilterResp;

/**
 * Content filter catalogue write path.
 *
 * Registered commands (SubmitRegistry):
 *   categories.add_entry    -> addEntry()
 *   categories.remove_entry -> removeEntry()
 *   categories.set_posture  -> setPosture()
 *
 * Responses are canonicalized through App\Helpers\ContentFilterResp: messages
 * always come from result.msg (the top-level response_msg legacy bridge is
 * ignored). RBAC is enforced by the backend (content_filter:write / :delete);
 * the UI gates the controls separately.
 *
 * A body carrying a field the command does not accept is **refused**, not partly
 * applied. Forwarding the keys that are recognised and dropping the rest would
 * let a typo (`patterns` for `pattern`) pass as success, and the gateway would
 * have nothing to complain about: it only ever sees what survived the filter.
 *
 * The **posture** is written here and not in either filter: it is the shared
 * policy, and the gateway applies one save to every mechanism that is on.
 */
class CategoriesSubmitController extends BaseController
{
    /** Top-level keys accepted by the add-entry payload. */
    private const ADD_KEYS = ['pattern', 'target'];

    /** Top-level keys accepted by the remove-entry payload. */
    private const REMOVE_KEYS = ['pattern'];

    /** Top-level keys accepted by the set-posture payload. */
    private const POSTURE_KEYS = ['posture'];

    /**
     * Add or replace an operator entry. Matching is by suffix, so `example.com`
     * also covers `a.example.com`; `target` is a category id or `allow` to
     * exempt the domain.
     *
     * @param array<string,mixed> $data request body (command/metadata are ignored)
     * @return array<string,mixed>
     */
    public function addEntry(array $data = []): array
    {
        $unknown = $this->unknownFields($data, self::ADD_KEYS);
        if (!empty($unknown)) {
            return ContentFilterResp::error('unknown field(s): ' . implode(', ', $unknown));
        }
        $payload  = array_intersect_key($data, array_flip(self::ADD_KEYS));
        $commands = [
            [
                'method' => 'categories.add_entry',
                'id'     => 'add_entry',
                'data'   => $payload,
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return ContentFilterResp::single($resp, 'add_entry');
    }

    /**
     * Remove an operator entry. A shipped (built-in) entry cannot be removed:
     * it comes from code and would come back on the next load. To carve a
     * domain out of a built-in category, add an `allow` entry for it instead.
     *
     * @param array<string,mixed> $data request body (command/metadata are ignored)
     * @return array<string,mixed>
     */
    public function removeEntry(array $data = []): array
    {
        $unknown = $this->unknownFields($data, self::REMOVE_KEYS);
        if (!empty($unknown)) {
            return ContentFilterResp::error('unknown field(s): ' . implode(', ', $unknown));
        }
        $payload  = array_intersect_key($data, array_flip(self::REMOVE_KEYS));
        $commands = [
            [
                'method' => 'categories.remove_entry',
                'id'     => 'remove_entry',
                'data'   => $payload,
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return ContentFilterResp::single($resp, 'remove_entry');
    }

    /**
     * Replace the policy: category id -> block/allow/monitor.
     *
     * Replaced **wholesale**, so the complete map is sent; a category left out
     * goes back to monitor.
     *
     * Saving **applies**, to every filter that is on: the gateway regenerates
     * both rule sets and repoints both decision engines before answering. Three
     * answers are possible and the UI must surface all three:
     *   - success, `apply.applied` naming the filters it reached;
     *   - success with `apply` null, when no filter is on (stored, not in force);
     *   - error, when it was stored but could not be put in force, or when only
     *     one of the two took it. A filter that failed is a hole in the policy
     *     until it is fixed, so it is never rounded up to success.
     *
     * @param array<string,mixed> $data request body (command/metadata are ignored)
     * @return array<string,mixed>
     */
    public function setPosture(array $data = []): array
    {
        $unknown = $this->unknownFields($data, self::POSTURE_KEYS);
        if (!empty($unknown)) {
            return ContentFilterResp::error('unknown field(s): ' . implode(', ', $unknown));
        }
        $payload  = array_intersect_key($data, array_flip(self::POSTURE_KEYS));
        $commands = [
            [
                'method' => 'categories.set_posture',
                'id'     => 'set_posture',
                'data'   => $payload,
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return ContentFilterResp::single($resp, 'set_posture');
    }
}
