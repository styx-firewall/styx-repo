<?php

namespace App\Controllers\Request;

use App\Controllers\BaseController;
use App\Helpers\ContentFilterResp;

/**
 * Content filter catalogue read path.
 *
 * Thin envelope over the gateway `categories.get_catalog` command, shaped by
 * App\Helpers\ContentFilterResp (canonical result.msg).
 *
 * Registered actions (RequestRegistry):
 *   categories.get_catalog -> getCatalog()
 *
 * The catalogue is what the web filter and the DNS filter share: the taxonomy
 * and the domain -> category entries. What to *do* with a category is each
 * filter's own business (see WebFilterRequestController).
 */
class CategoriesRequestController extends BaseController
{
    /**
     * The whole catalogue: entries, taxonomy, groups and counters.
     *
     * @return array<string,mixed>
     */
    public function getCatalog(): array
    {
        $commands = [
            [
                'method' => 'categories.get_catalog',
                'id'     => 'catalog',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        return ContentFilterResp::single($resp, 'catalog');
    }
}
