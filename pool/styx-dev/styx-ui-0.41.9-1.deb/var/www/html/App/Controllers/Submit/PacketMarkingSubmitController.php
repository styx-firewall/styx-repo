<?php
namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class PacketMarkingSubmitController extends BaseController
{
    /**
     * Add a packet-marking rule
     * @param array $data
     * @return array
     */
    public function setRule(array $data)
    {
        // Basic validation consistent with the frontend checks
        $required = ['name', 'mark', 'family', 'mark_target'];
        foreach ($required as $f) {
            if (!isset($data[$f]) || $data[$f] === '') {
                return $this->baseError("Missing required field: $f");
            }
        }

        // Enforce family is ip or ip6
        if (!in_array($data['family'], ['ip', 'ip6'], true)) {
            return $this->baseError('Invalid family, expected "ip" or "ip6"');
        }

        // Enforce mark_target
        if (!in_array($data['mark_target'], ['meta', 'ct'], true)) {
            return $this->baseError('Invalid mark_target, expected "meta" or "ct"');
        }

        // The command is a single 'set' operation. Backend should treat presence of
        // an 'id' field as an edit, otherwise create a new rule.
        $cmd = [
            'method' => 'packet-marking.set_pm_rule',
            'id' => 'set_pm_rule',
            'data' => $data
        ];

        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['set_pm_rule'] ?? $this->baseError('No response for set_pm_rule');
    }

    /**
     * Preview a packet-marking rule (no persist, no OS)
     * @param array $data
     * @return array
     */
    public function previewRule(array $data)
    {
        $required = ['name', 'mark', 'family', 'mark_target'];
        foreach ($required as $f) {
            if (!isset($data[$f]) || $data[$f] === '') {
                return $this->baseError("Missing required field: $f");
            }
        }

        if (!in_array($data['family'], ['ip', 'ip6'], true)) {
            return $this->baseError('Invalid family, expected "ip" or "ip6"');
        }

        if (!in_array($data['mark_target'], ['meta', 'ct'], true)) {
            return $this->baseError('Invalid mark_target, expected "meta" or "ct"');
        }

        $cmd = [
            'method' => 'packet-marking.preview_pm_rule',
            'id' => 'preview_pm_rule',
            'data' => $data
        ];

        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['preview_pm_rule'] ?? $this->baseError('No response for preview_pm_rule');
    }

    /**
     * Delete a packet-marking rule
     * @param array $data
     * @return array
     */
    public function deleteRule(array $data)
    {
        if (empty($data['id'])) {
            return $this->baseError('Missing rule id');
        }
        $cmd = [
            'method' => 'packet-marking.delete_pm_rule',
            'id' => 'delete_pm_rule',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['delete_pm_rule'] ?? $this->baseError('No response for delete_pm_rule');
    }

    /**
     * Toggle (activate/deactivate) a packet-marking rule
     * @param array $data
     * @return array
     */
    public function toggleRule(array $data)
    {
        if (empty($data['id'])) {
            return $this->baseError('Missing rule id');
        }
        $cmd = [
            'method' => 'packet-marking.toggle_pm_rule',
            'id' => 'toggle_pm_rule',
            'data' => $data
        ];
        $resp = $this->processGwResp($this->sendCommands([$cmd]));
        return $resp['commands']['toggle_pm_rule'] ?? $this->baseError('No response for toggle_pm_rule');
    }

}
