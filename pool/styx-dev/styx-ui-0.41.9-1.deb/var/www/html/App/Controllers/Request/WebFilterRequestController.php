<?php

namespace App\Controllers\Request;

use App\Controllers\BaseController;
use App\Helpers\ContentFilterResp;

/**
 * Web filter read path.
 *
 * Thin envelopes over the gateway `web-filter.get_settings` and
 * `web-filter.get_status` commands, shaped by App\Helpers\ContentFilterResp
 * (canonical result.msg).
 *
 * Registered actions (RequestRegistry):
 *   web-filter.get_settings -> getSettings()
 *   web-filter.get_status   -> getStatus()
 */
class WebFilterRequestController extends BaseController
{
    /**
     * Model keys, stripped of the transport `msg` before they reach templates.
     *
     * `posture` is not among them on purpose: the policy is the catalogue's
     * (categories.set_posture) - one for every mechanism - so this filter does
     * not carry one of its own.
     */
    private const SETTINGS_KEYS = ['block_mode', 'dscp'];

    /**
     * What this filter does with the shared policy: how it cuts, and its DSCP map.
     *
     * @return array<string,mixed>
     */
    public function getSettings(): array
    {
        $commands = [
            [
                'method' => 'web-filter.get_settings',
                'id'     => 'settings',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $out  = ContentFilterResp::single($resp, 'settings');
        if (($out['status'] ?? '') === 'success') {
            $out['result'] = self::modelData($out['result'] ?? []);
        }
        return $out;
    }

    /**
     * What the filter is doing right now: which categories are blocked, which
     * derive a DSCP, and the runtime counters while it is running.
     *
     * @return array<string,mixed>
     */
    public function getStatus(): array
    {
        $commands = [
            [
                'method' => 'web-filter.get_status',
                'id'     => 'status',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $out  = ContentFilterResp::single($resp, 'status');
        if (($out['status'] ?? '') === 'success') {
            unset($out['result']['msg']);
        }
        return $out;
    }

    /**
     * The backend appends a `msg` key to the result. That key is a transport
     * message, not part of the model - strip it before it reaches templates or
     * window state, and keep only the settings object.
     *
     * @param array<string,mixed> $result
     * @return array<string,mixed>
     */
    private static function modelData(array $result): array
    {
        $settings = is_array($result['settings'] ?? null) ? $result['settings'] : [];
        $out      = [];
        foreach (self::SETTINGS_KEYS as $key) {
            $out[$key] = $settings[$key] ?? null;
        }
        return $out;
    }
}
