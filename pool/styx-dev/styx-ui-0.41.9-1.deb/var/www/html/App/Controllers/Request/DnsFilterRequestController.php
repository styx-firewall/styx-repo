<?php

namespace App\Controllers\Request;

use App\Controllers\BaseController;
use App\Helpers\ContentFilterResp;

/**
 * DNS filter read path.
 *
 * Thin envelopes over the gateway `dns-filter.get_settings` and
 * `dns-filter.get_status` commands, shaped by App\Helpers\ContentFilterResp
 * (canonical result.msg).
 *
 * Registered actions (RequestRegistry):
 *   dns-filter.get_settings -> getSettings()
 *   dns-filter.get_status   -> getStatus()
 *
 * The catalogue (which domain is which category) is NOT here: it is shared with
 * the web filter and read through CategoriesRequestController. What lives here
 * is only this filter's own policy: what to do with a category, where a blocked
 * name is sent, and what happens when the filter is not running.
 */
class DnsFilterRequestController extends BaseController
{
    /**
     * Model keys, stripped of the transport `msg` before they reach templates.
     *
     * `posture` is not among them on purpose: the policy is the catalogue's
     * (categories.set_posture) - one for every mechanism - so this filter does
     * not carry one of its own.
     *
     * `sinkhole_address` / `sinkhole_address6` accept an IP **or a hostname**;
     * the gateway resolves a name when the filter is armed, so the stored value
     * is what the operator typed, not what it resolved to. The resolved form is
     * in the status, next to it, on purpose: "I set a name and it did not
     * resolve" and "I set nothing" are different answers.
     */
    private const SETTINGS_KEYS = [
        'sinkhole_address',
        'sinkhole_address6',
        'fail_mode',
        'chains',
    ];

    /**
     * The DNS filter's policy: the sinkhole targets, the failure mode and the
     * chains it is applied to.
     *
     * @return array<string,mixed>
     */
    public function getSettings(): array
    {
        $commands = [
            [
                'method' => 'dns-filter.get_settings',
                'id'     => 'settings',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $out  = ContentFilterResp::single($resp, 'settings');
        if (($out['status'] ?? '') === 'success') {
            $out['result'] = self::modelData($out['result'] ?? []);
        }
        return $out;
    }

    /**
     * What the filter is doing right now: which categories are blocked, what the
     * configured targets resolved to, whether the page is being served here, and
     * the runtime counters while the queue is running.
     *
     * @return array<string,mixed>
     */
    public function getStatus(): array
    {
        $commands = [
            [
                'method' => 'dns-filter.get_status',
                'id'     => 'status',
                'data'   => (object)[],
            ],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        $out  = ContentFilterResp::single($resp, 'status');
        if (($out['status'] ?? '') === 'success') {
            unset($out['result']['msg']);
        }
        return $out;
    }

    /**
     * The backend appends a `msg` key to the result. That key is a transport
     * message, not part of the model - strip it before it reaches templates or
     * window state, and keep only the settings object.
     *
     * @param array<string,mixed> $result
     * @return array<string,mixed>
     */
    private static function modelData(array $result): array
    {
        $settings = is_array($result['settings'] ?? null) ? $result['settings'] : [];
        $out      = [];
        foreach (self::SETTINGS_KEYS as $key) {
            $out[$key] = $settings[$key] ?? null;
        }
        return $out;
    }
}
