<?php
/**
 * Controller for handling sets-related requests
 * dp: 20260415
 */
namespace App\Controllers\Request;

use App\Controllers\BaseController;
use App\Core\AppContext;

class SetsRequestController extends BaseController
{
    public function __construct(AppContext $ctx)
    {
        parent::__construct($ctx);
    }

    /**
     * @param array<string,mixed> $data wire key: `scopes` (optional, defaults to all)
     */
    public function getFullSets(array $data)
    {
        $scopes = $data['scopes'] ?? [];
        if (!is_array($scopes)) {
            return $this->baseError('scopes must be an array');
        }

        $commands[] = [
            'method' => 'sets-mgmt.get_ports',
            'id' => 'ports',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_address',
            'id' => 'address',
            'data' => ['scope' => $scopes],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_interfaces_sets',
            'id' => 'ifaces_sets',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_domains',
            'id' => 'domain',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'network-config.get_interfaces_names',
            'id' => 'ifaces_names',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'ports' => $cmds['ports']['result']['ports'] ?? [],
                'address' => $cmds['address']['result']['address'] ?? [],
                'interfaces_sets' => $cmds['ifaces_sets']['result']['interfaces'] ?? [],
                'domain' => $cmds['domain']['result']['domains'] ?? [],
                'ifaces_names' => $cmds['ifaces_names']['result']['ifaces_names'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * @param array<string,mixed> $data wire key: `scopes` (optional, defaults to all)
     */
    public function getPorts(array $data)
    {
        $scopes = $data['scopes'] ?? [];
        if (!is_array($scopes)) {
            return $this->baseError('scopes must be an array');
        }

        $gwData = (object)[];
        if (!empty($scopes)) {
            $gwData = ['scope' => $scopes];
        }
        $commands[] = [
            'method' => 'sets-mgmt.get_ports',
            'id' => 'ports',
            'data' => $gwData,
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'ports' => $cmds['ports']['result']['ports'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * @param array<string,mixed> $data wire keys: `scopes` (optional), `type` (optional)
     */
    public function getAddress(array $data)
    {
        $scopes = $data['scopes'] ?? [];
        if (!is_array($scopes)) {
            return $this->baseError('scopes must be an array');
        }
        $type = isset($data['type']) ? (string) $data['type'] : null;

        $commands = [];
        $gwData = ['scope' => $scopes];
        if ($type !== null) {
            $gwData['type'] = $type;
        }
        $commands[] = [
            'method' => 'sets-mgmt.get_address',
            'id' => 'address',
            'data' => $gwData,
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
                'result' => [
                'address' => $cmds['address']['result']['address'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * @param array<string,mixed> $data wire key: `type` (optional)
     */
    public function getInterfacesSets(array $data)
    {
        $type = isset($data['type']) ? (string) $data['type'] : null;

        $gwData = (object)[];
        if ($type !== null) {
            $gwData = ['type' => $type];
        }
        $commands[] = [
            'method' => 'sets-mgmt.get_interfaces_sets',
            'id' => 'ifaces_sets',
            'data' => $gwData,
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'interfaces' => $cmds['ifaces_sets']['result']['interfaces'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getDomains()
    {
        $commands[] = [
            'method' => 'sets-mgmt.get_domains',
            'id' => 'domain',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'domain' => $cmds['domain']['result']['domains'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getLabels()
    {
        $commands[] = [
            'method' => 'sets-mgmt.get_labels',
            'id' => 'labels',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'labels' => $cmds['labels']['result']['labels'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getAllowedLabels()
    {
        $commands[] = [
            'method' => 'sets-mgmt.get_allowed_labels',
            'id' => 'label_types',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'label_types' => $cmds['label_types']['result']['label_types'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getLabelsWithTypes()
    {
        $commands[] = [
            'method' => 'sets-mgmt.get_labels',
            'id' => 'labels',
            'data' => (object)[],
        ];
        $commands[] = [
            'method' => 'sets-mgmt.get_allowed_labels',
            'id' => 'label_types',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'labels' => $cmds['labels']['result']['labels'] ?? [],
                'label_types' => $cmds['label_types']['result']['label_types'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }

    public function getInterfacesNames()
    {
        $commands[] = [
            'method' => 'network-config.get_interfaces_names',
            'id' => 'ifaces_names',
            'data' => (object)[],
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        return [
            'status' => $resp['status'],
            'result' => [
                'ifaces_names' => $cmds['ifaces_names']['result']['ifaces_names'] ?? [],
            ],
            'warnings' => $resp['warnings'],
        ];
    }
}
