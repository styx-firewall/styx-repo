<?php
/**
 * Controller for network discovery requests.
 * Communicates with the backend discovery handler (discovery.*).
 */
namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class DiscoveryRequestController extends BaseController
{
    /**
     * Retrieve a single host by IP.
     *
     * @param string $ip
     * @return array<string, mixed>
     */
    public function getHost(array $data): array
    {
        $ip = (string) ($data['ip'] ?? '');
        if ($ip === '') {
            return $this->baseError('ip is required');
        }

        $commands = [[
            'method' => 'discovery.get_host',
            'id'     => 'get_host',
            'data'   => ['ip' => $ip],
        ]];

        $gw_response = $this->sendCommands($commands);
        $indexed = array_column($gw_response['commands'] ?? [], null, 'id');
        $cmd = $indexed['get_host'] ?? [];

        if (($cmd['status'] ?? null) === 'success') {
            return ['status' => 'success', 'result' => ['host' => $cmd['result']['host'] ?? null]];
        }

        return ['status' => 'error', 'response_msg' => $cmd['response_msg'] ?? 'Failed to retrieve host'];
    }

    /**
     * Retrieve all discovered hosts, host stats, topology and service status
     * in a single batched gateway call for the overview page.
     *
     * @return array<string, mixed>
     */
    public function getOverviewData(): array
    {
        $commands = [
            ['method' => 'discovery.get_host_stats',     'id' => 'stats',    'data' => null],
            ['method' => 'discovery.get_topology_graph', 'id' => 'graph',    'data' => null],
            ['method' => 'discovery.get_status',         'id' => 'status',   'data' => null],
            ['method' => 'discovery.get_settings',       'id' => 'settings', 'data' => null],
        ];

        $gw_response = $this->sendCommands($commands);
        $indexed = array_column($gw_response['commands'] ?? [], null, 'id');

        $result = [];

        $statsCmd = $indexed['stats'] ?? [];
        if (($statsCmd['status'] ?? null) === 'success') {
            $result['stats'] = $statsCmd['result']['stats'] ?? [];
        } else {
            $result['stats'] = [];
        }

        $graphCmd = $indexed['graph'] ?? [];
        if (($graphCmd['status'] ?? null) === 'success') {
            $result['graph'] = $graphCmd['result']['graph'] ?? [];
        } else {
            $result['graph'] = [];
        }

        $statusCmd = $indexed['status'] ?? [];
        if (($statusCmd['status'] ?? null) === 'success') {
            $result['service_status'] = $statusCmd['result'] ?? [];
        } else {
            $result['service_status'] = ['running' => false, 'paused' => false, 'packet_count' => 0];
        }

        $settingsCmd = $indexed['settings'] ?? [];
        if (($settingsCmd['status'] ?? null) === 'success') {
            $result['settings'] = $settingsCmd['result']['settings'] ?? $settingsCmd['result'] ?? [];
        } else {
            $result['settings'] = [];
        }

        return ['status' => 'success', 'result' => $result];
    }

    /**
     * Retrieve current discovery settings from the backend.
     *
     * @return array<string, mixed>
     */
    public function getSettings(): array
    {
        $commands = [[
            'method' => 'discovery.get_settings',
            'id'     => 'get_settings',
            'data'   => null,
        ]];

        $gw_response = $this->sendCommands($commands);
        $indexed = array_column($gw_response['commands'] ?? [], null, 'id');
        $cmd = $indexed['get_settings'] ?? [];

        if (($cmd['status'] ?? null) === 'success') {
            return ['status' => 'success', 'result' => $cmd['result'] ?? []];
        }

        return ['status' => 'error', 'response_msg' => $cmd['response_msg'] ?? 'Failed to retrieve discovery settings'];
    }
}
