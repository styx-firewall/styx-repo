<?php
namespace App\Controllers\Submit;
use App\Controllers\BaseController;

class InterfaceSubmitController extends BaseController
{

	/**
	 * Validate a string is a UUID (basic pattern check).
	 * @param mixed $v
	 * @return bool
	 */
	private function isUuid($v): bool
	{
		if (!is_string($v) || $v === '') return false;
		return (bool)preg_match('/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/', $v);
	}


	/**
	 * Set interface configuration
	 * @param array $data
	 * @return array
	 */
    public function setIfaceConfig(array $data)
	{
		// The UI posts `iface_id`, the gateway command takes `id`: accept either
		// name here (delete_virtual_interface does the same) so a caller that
		// follows the gateway API is not rejected for using its field name.
		$iface_id = $data['iface_id'] ?? $data['id'] ?? null;
		if (!$iface_id || !$this->isUuid($iface_id)) {
			return $this->baseError('Interface identifier (iface_id or id) must be a valid UUID');
		}

		// Extract service binding flags from the incoming data and convert
		// them into separate service commands so bindings are handled
		// independently from the interface configuration itself.
		$extraCmds = [];
		// SSH binding flag -> service 'ssh' (requires iface_id)
		if (isset($data['listen_ssh'])) {
			if (!$iface_id) {
				return $this->baseError('Service binding (listen_ssh) requires iface_id');
			}
			$val = $data['listen_ssh'];
			if (is_string($val)) {
				$enabled = in_array(strtolower($val), ['1', 'on', 'true'], true);
			} else {
				$enabled = (bool)$val;
			}
			$extraCmds[] = [
				'method' => 'service-control.set_service_binding',
				'id' => 'set_ssh_binding',
				'data' => [
					'service' => 'sshd',
					'id' => $iface_id,
					'enabled' => $enabled,
				],
			];
			unset($data['listen_ssh']);
		}
		// Styx UI / lighttp binding flag -> service 'lighttp'
		if (isset($data['listen_styx_ui'])) {
			if (!$iface_id) {
				return $this->baseError('Service binding (listen_styx_ui) requires iface_id');
			}
			$val = $data['listen_styx_ui'];
			if (is_string($val)) {
				$enabled = in_array(strtolower($val), ['1', 'on', 'true'], true);
			} else {
				$enabled = (bool)$val;
			}
			$extraCmds[] = [
				'method' => 'service-control.set_service_binding',
				'id' => 'set_styx_binding',
				'data' => [
					'service' => 'lighttpd',
					'id' => $iface_id,
					'enabled' => $enabled,
				],
			];
			unset($data['listen_styx_ui']);
		}

		// Frontend uses `iface_id`; the gateway command takes `id`. Leave exactly
		// one of them in the payload: any extra identifier key is noise the
		// gateway ignores today and a strict schema would reject tomorrow.
		if (!isset($data['id'])) {
			$data['id'] = $data['iface_id'] ?? null;
		}
		unset($data['iface_id']);

		// Normalize and coerce common fields
		$data = $this->normalizeIfacePayload($data);

		$cmd = [
			[
				'method' => 'network-config.set_iface_config',
				'id' => 'set_iface_config',
				'data' => $data,
			]
		];
		if (!empty($extraCmds)) {
			foreach ($extraCmds as $ec) {
				$cmd[] = $ec;
			}
		}

		$gwResp = $this->sendCommands($cmd);
		$resp = $this->processGwResp($gwResp);

		if ($resp['status'] === 'error') {
		    return $resp;
		}

		return [
		    'status'   => $resp['status'],
		    'result'   => $resp['commands'],
		    'warnings' => $resp['warnings'],
		];
	}
	/**
	 * Create a virtual interface by sending the command to the backend
	 * @param array $data
	 * @return array
	 */
	public function createVirtualInterface(array $data)
	{
		$iface = $data['iface_name'] ?? null;
		$iface_subtype = $data['iface_subtype'] ?? null;
		if (!$iface && $iface_subtype !== 'vlan') {
			return $this->baseError('Interface name not provided');
		}

		// Normalize and coerce common fields
		$data = $this->normalizeIfacePayload($data);

		// Basic validation for VLAN-specific requirements (server-side)
		// Require explicit `iface_subtype` from the UI.
		$iface_subtype = $data['iface_subtype'] ?? null;
		if ($iface_subtype === 'vlan') {
			if (empty($data['parent_iface']) || (!isset($data['vlan_id']) || $data['vlan_id'] === '')) {
				return $this->baseError('VLAN creation requires parent_iface and vlan_id');
			}
			if (!$this->isUuid($data['parent_iface'])) {
				return $this->baseError('parent_iface must be a backend id (UUID)');
			}
			if (!$this->isUuid($data['vlan_id'])) {
				return $this->baseError('vlan_id must be a label-set UUID (scope: vlan)');
			}
		}

		// Validate tunnel-specific UUID fields (vxlan, gre, vti)
		// These reference address-sets or label-sets, never raw values.
		$tunnel_uuid_fields = ['vni', 'local_ip', 'dstport']; // vxlan
		$gre_uuid_fields = ['local', 'remote', 'ikey', 'okey']; // gre
		$vti_uuid_fields = ['local', 'remote', 'key']; // vti
		foreach (array_merge($tunnel_uuid_fields, $gre_uuid_fields, $vti_uuid_fields) as $field) {
			if (isset($data[$field]) && $data[$field] !== '' && !$this->isUuid($data[$field])) {
				return $this->baseError("$field must be a UUID (address-set or label-set)");
			}
		}

		// Strictly validate any interface references are UUIDs  -  fail explicitly.
		if (isset($data['parent_iface']) && $data['parent_iface'] !== '' && !$this->isUuid($data['parent_iface'])) {
			return $this->baseError('parent_iface must be a backend id (UUID)');
		}
		if (isset($data['ports']) && is_array($data['ports'])) {
			foreach ($data['ports'] as $p) {
				if (!is_string($p) || $p === '' || !$this->isUuid($p)) {
					return $this->baseError('ports entries must be backend ids (UUID)');
				}
			}
		}
		if (isset($data['slaves']) && is_array($data['slaves'])) {
			foreach ($data['slaves'] as $s) {
				if (!is_string($s) || $s === '' || !$this->isUuid($s)) {
					return $this->baseError('slaves entries must be backend ids (UUID)');
				}
			}
		}
		if (isset($data['refs']) && is_array($data['refs'])) {
			foreach ($data['refs'] as $r) {
				if (!is_string($r) || $r === '' || !$this->isUuid($r)) {
					return $this->baseError('refs entries must be backend ids (UUID)');
				}
			}
		}
		if (isset($data['bridge_vlans']) && is_array($data['bridge_vlans'])) {
			foreach ($data['bridge_vlans'] as $bv) {
				if (is_array($bv) && isset($bv['vlan_id']) && $bv['vlan_id'] !== '' && !$this->isUuid($bv['vlan_id'])) {
					return $this->baseError('bridge_vlans.vlan_id must be a VLAN label UUID');
				}
				if (is_array($bv) && isset($bv['port']) && $bv['port'] !== '' && !$this->isUuid($bv['port'])) {
					return $this->baseError('bridge_vlans.port must be a backend id (UUID)');
				}
			}
		}

		$cmd = [
			[
				'method' => 'network-config.create_virtual_interface',
				'id' => 'create_virtual_interface',
				'data' => $data,
			]
		];

		$gwResp = $this->sendCommands($cmd);
		$resp = $this->processGwResp($gwResp);
		return $resp['commands']['create_virtual_interface'] ?? $this->baseError('Error creating virtual interface');
	}

	/**
	 * Delete a virtual interface by id
	 * @param array $data
	 * @return array
	 */
	public function deleteVirtualInterface(array $data)
	{
		$id = $data['id'] ?? $data['iface_id'] ?? null;
		if (!$id) {
			return $this->baseError('Interface id (id) is required.');
		}

		$cmd = [
			[
				'method' => 'network-config.delete_virtual_interface',
				'id' => 'delete_virtual_interface',
				'data' => ['id' => $id],
			]
		];

		$gwResp = $this->sendCommands($cmd);
		$resp = $this->processGwResp($gwResp);
		return $resp['commands']['delete_virtual_interface'] ?? $this->baseError('Error deleting virtual interface');
	}

	/**
	 * Normalize/cleanup fields commonly used in interface payloads.
	 * - Coerce numeric values to ints where appropriate
	 * - Normalize status to 'up'|'down'
	 * - Log resulting payload at debug level
	 *
	 * @param array $data
	 * @return array
	 */
	private function normalizeIfacePayload(array $data): array
	{
		if (isset($data['mtu']) && is_numeric($data['mtu'])) {
			$data['mtu'] = (int)$data['mtu'];
		}
		if (isset($data['ipv4']) && is_array($data['ipv4'])) {
			foreach ($data['ipv4'] as $k => $ipEntry) {
				if (isset($ipEntry['netmask']) && is_numeric($ipEntry['netmask'])) {
					$data['ipv4'][$k]['netmask'] = (int)$ipEntry['netmask'];
				}
			}
		}
		if (isset($data['ipv6']) && is_array($data['ipv6'])) {
			foreach ($data['ipv6'] as $k => $ipEntry) {
				if (isset($ipEntry['prefix']) && is_numeric($ipEntry['prefix'])) {
					$data['ipv6'][$k]['prefix'] = (int)$ipEntry['prefix'];
				}
			}
		}

		if (isset($data['status'])) {
			$s = strtolower((string)$data['status']);
			if ($s !== 'up' && $s !== 'down') {
				$data['status'] = in_array($s, ['1', 'on', 'true'], true) ? 'up' : 'down';
			} else {
				$data['status'] = $s;
			}
		}

		// Single debug entry for normalized payload
		$this->logService->debug(['iface.payload.normalized' => $data]);

		return $data;
	}
}
