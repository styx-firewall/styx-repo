<?php
/**
 * TemplateService->getTpl()
 *
 * @var array<mixed> $tdata
 *
 * Example content for $predefined and $custom (NetTunningFormatter
 * additionally computes `differs` and the highlight class `hl_class`):
 * $predefined = [
 *   [
 *     'key' => 'rp_filter',
 *     'sysctl_key' => 'net.ipv4.conf.all.rp_filter',
 *     'value' => '1',
 *     'default' => '0',
 *     'comment' => 'IP packet filtering',
 *     'input_type' => 'number',
 *     'checked' => false,
 *     'predefined' => true
 *   ],
 *   ...
 * ];
 * $custom = [
 *   [
 *     'key' => 'custom_param',
 *     'sysctl_key' => 'net.custom.param',
 *     'value' => 'foo',
 *     'default' => '-',
 *     'comment' => 'Custom parameter',
 *     'input_type' => 'text',
 *     'checked' => false,
 *     'predefined' => false
 *   ],
 *   ...
 * ];
 */
$predefined = $tdata['page_data']['predefined'] ?? [];
$custom = $tdata['page_data']['custom'] ?? [];
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <aside><?= $tdata['sidebar'] ?></aside>
    <main class="page-content">
        <h1>Sysctl Network Tuning</h1>
        <div class="content-box">
            <div class="std-tabs">
                <button type="button" class="std-tab-btn active" data-tab="tunning">Tuning</button>
                <button type="button" class="std-tab-btn" data-tab="adv-tunning">Advanced Raw Tuning</button>
            </div>
            <div class="std-tab-panel active" data-tab="tunning">
                <form id="sysctl-tunning-form" method="post" autocomplete="off">
                    <div class="std-grid-type1" data-js="sysctl-tunning-fields">
                    <?php foreach ($predefined as $item): ?>
                        <div class="form-col std-grid-item-type1 sysctl-grid-item<?= $item['hl_class'] ?>">
                            <label for="value-<?= $item['key'] ?>" class="sysctl-label"><?= $item['sysctl_key'] ?></label>
                            <input type="hidden" name="sysctl_keys[]" value="<?= $item['sysctl_key'] ?>">
                            <?php if ($item['input_type'] === 'number'): ?>
                            <input type="number" name="value[]" id="value-<?= $item['key'] ?>"
                                value="<?= $item['value'] ?>"
                                data-original="<?= $item['value'] ?>"
                                data-sysctl-key="<?= $item['sysctl_key'] ?>"
                                class="js-sysctl-value std-grid-input" autocomplete="off">
                            <?php elseif ($item['input_type'] === 'checkbox'): ?>
                            <label class="std-switch">
                                <input type="checkbox" name="value[]" id="value-<?= $item['key'] ?>" value="1"
                                    data-original="<?= $item['checked'] ? '1' : '0' ?>"
                                    data-sysctl-key="<?= $item['sysctl_key'] ?>"
                                    class="js-sysctl-value std-grid-input" <?= $item['checked'] ? 'checked' : '' ?>>
                                <span class="std-switch-slider" data-off="No" data-on="Yes"></span>
                            </label>
                            <?php else: ?>
                            <input type="text" name="value[]" id="value-<?= $item['key'] ?>"
                                value="<?= $item['value'] ?>"
                                data-original="<?= $item['value'] ?>"
                                data-sysctl-key="<?= $item['sysctl_key'] ?>"
                                class="js-sysctl-value std-grid-input" autocomplete="off">
                            <?php endif; ?>
                            <?php if ($item['comment']): ?>
                            <div class="sysctl-comment"><?= $item['comment'] ?></div>
                            <?php endif; ?>
                            <div class="sysctl-default">Default: <span id="default-<?= $item['key'] ?>"><?= $item['default'] ?></span></div>
                        </div>
                    <?php endforeach; ?>
                    </div>
                    <button type="submit" id="sysctl-tunning-submit">Save changes</button>
                </form>
            </div>
            <div class="std-tab-panel" data-tab="adv-tunning">
                <form id="sysctl-adv-tunning-form" method="post" autocomplete="off">
                    <div class="std-grid-type1" data-js="sysctl-adv-tunning-fields">
                    <?php foreach ($custom as $item): ?>
                        <div class="form-col std-grid-item-type1 sysctl-grid-item<?= $item['hl_class'] ?>">
                            <label for="value-<?= $item['key'] ?>" class="sysctl-label"><?= $item['sysctl_key'] ?></label>
                            <input type="hidden" name="sysctl_keys[]" value="<?= $item['sysctl_key'] ?>">
                            <?php if ($item['input_type'] === 'number'): ?>
                            <input type="number" name="value[]" id="value-<?= $item['key'] ?>"
                                value="<?= $item['value'] ?>"
                                data-original="<?= $item['value'] ?>"
                                data-sysctl-key="<?= $item['sysctl_key'] ?>"
                                class="js-sysctl-value std-grid-input" autocomplete="off">
                            <?php elseif ($item['input_type'] === 'checkbox'): ?>
                            <label class="std-switch">
                                <input type="checkbox" name="value[]" id="value-<?= $item['key'] ?>" value="1"
                                    data-original="<?= $item['checked'] ? '1' : '0' ?>"
                                    data-sysctl-key="<?= $item['sysctl_key'] ?>"
                                    class="js-sysctl-value std-grid-input" <?= $item['checked'] ? 'checked' : '' ?>>
                                <span class="std-switch-slider" data-off="No" data-on="Yes"></span>
                            </label>
                            <?php else: ?>
                            <input type="text" name="value[]" id="value-<?= $item['key'] ?>"
                                value="<?= $item['value'] ?>"
                                data-original="<?= $item['value'] ?>"
                                data-sysctl-key="<?= $item['sysctl_key'] ?>"
                                class="js-sysctl-value std-grid-input" autocomplete="off">
                            <?php endif; ?>
                            <?php if ($item['comment']): ?>
                            <div class="sysctl-comment"><?= $item['comment'] ?></div>
                            <?php endif; ?>
                            <div class="sysctl-default">Default: <span id="default-<?= $item['key'] ?>"><?= $item['default'] ?></span></div>
                        </div>
                    <?php endforeach; ?>
                    </div>
                    <button type="submit" id="sysctl-adv-tunning-submit">Save changes</button>
                </form>

            </div>
        </div>
    </main>
</div>
