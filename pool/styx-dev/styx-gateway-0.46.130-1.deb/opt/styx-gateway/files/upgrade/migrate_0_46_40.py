"""
Migration script: -> 0.46.40

Backfills config_interfaces refs for strongSwan:

  1. strongswan_global_config (singleton): ensures a UUID ``id`` and
     registers it as a ref on the config_interfaces entries named by
     ``install_virtual_ip_on`` (single UUID) and ``interfaces_use``
     (list of UUIDs).
  2. strongswan_connections (list): registers each connection's ``id``
     as a ref on the config_interfaces entry named by its ``interface_id``.

From 0.46.40 on, StrongSwanService keeps these refs in sync on save/delete,
so InterfaceLifecycleService's delete guard is consistent for pre-existing
configs. Pool refs (by name) are intentionally out of scope.
"""

import uuid

from constants.datastore_keys import (
    DS_KEY_CONFIG_INTERFACES,
    DS_KEY_STRONGSWAN_CONNECTIONS,
    DS_KEY_STRONGSWAN_GLOBAL_CONFIG,
)
from core.app_context import AppContext

TAG = "[MIGRATE 0.46.40]"
STORE = "startup-config"

_GCONF_IFACE_FIELDS = ("install_virtual_ip_on", "interfaces_use")


def _tokens(value):
    """Normalize a field value to interface-UUID tokens (str or list)."""
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    if isinstance(value, list):
        return [t.strip() for t in value if isinstance(t, str) and t.strip()]
    return []


def run(ctx: AppContext) -> bool:
    """Backfill config_interfaces refs for strongSwan global config and connections."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    ds = ctx.get_datastore()

    # 1. Ensure the global config singleton carries a UUID id.
    gcfg = ds.get_data(DS_KEY_STRONGSWAN_GLOBAL_CONFIG, store=STORE)
    if gcfg is not None and not isinstance(gcfg, dict):
        logger.warning(
            f"{TAG} {DS_KEY_STRONGSWAN_GLOBAL_CONFIG} is not a dict "
            f"({type(gcfg).__name__}) -- skipping id/ref backfill."
        )
        gcfg = None
    if isinstance(gcfg, dict):
        if not gcfg.get("id") or not isinstance(gcfg.get("id"), str):
            gcfg["id"] = str(uuid.uuid4())
            if not ds.replace_data(DS_KEY_STRONGSWAN_GLOBAL_CONFIG, gcfg, store=STORE):
                logger.error(f"{TAG} Failed to persist {DS_KEY_STRONGSWAN_GLOBAL_CONFIG} with new UUID id.")
                return False
            logger.info(f"{TAG} Added id={gcfg['id']} to {DS_KEY_STRONGSWAN_GLOBAL_CONFIG}")

    config_ifaces = ds.get_data(DS_KEY_CONFIG_INTERFACES, store=STORE) or []
    if not isinstance(config_ifaces, list) or not config_ifaces:
        logger.info(f"{TAG} No config_interfaces found -- nothing to migrate.")
        return True

    by_id = {item.get("id"): item for item in config_ifaces if isinstance(item, dict)}
    modified = False

    def _register(iface_uuid, ref_id):
        nonlocal modified
        if not iface_uuid or not ref_id:
            return
        item = by_id.get(iface_uuid)
        if item is None:
            # Interface deleted: nothing to anchor a ref on.
            return
        refs = item.get("refs") if isinstance(item.get("refs"), list) else []
        if ref_id not in refs:
            refs.append(ref_id)
            item["refs"] = refs
            modified = True
            logger.info(f"{TAG} Registered ref {ref_id} on interface '{iface_uuid}'")

    # 2. Global config refs (both interface-reference fields).
    if isinstance(gcfg, dict):
        gid = gcfg.get("id")
        for field in _GCONF_IFACE_FIELDS:
            for tok in _tokens(gcfg.get(field)):
                _register(tok, gid)

    # 3. Connection refs (interface_id per connection).
    conns = ds.get_data(DS_KEY_STRONGSWAN_CONNECTIONS, store=STORE) or []
    if isinstance(conns, list):
        for conn in conns:
            if not isinstance(conn, dict) or not conn.get("id"):
                continue
            for tok in _tokens(conn.get("interface_id")):
                _register(tok, conn["id"])
    else:
        logger.warning(
            f"{TAG} {DS_KEY_STRONGSWAN_CONNECTIONS} is not a list "
            f"({type(conns).__name__}) -- skipping conn ref backfill."
        )

    if modified:
        if not ds.replace_data(DS_KEY_CONFIG_INTERFACES, config_ifaces, store=STORE):
            logger.error(f"{TAG} Failed to persist config_interfaces with backfilled refs.")
            return False
        logger.info(f"{TAG} Persisted config_interfaces with backfilled refs.")

    logger.notice(f"{TAG} Migration completed successfully.")
    return True
