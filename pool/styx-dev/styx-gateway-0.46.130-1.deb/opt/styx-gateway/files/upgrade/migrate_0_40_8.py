"""
Migration script: -> 0.40.8

Adds an ``id`` (UUID) field to the lighttpd SSL and SSH config datastore
entries that were bootstrapped before this field was introduced. This UUID is
used as the reference key in certificate refs so the IntegrityRefsChecker can
validate that certificates in use by lighttpd/SSH are not accidentally deleted.
"""

import uuid

from constants.datastore_keys import DS_KEY_LIGHTTPD_SSL, DS_KEY_SSH_CONFIG
from core.app_context import AppContext


def _ensure_id(datastore, store_key: str, log) -> bool:
    """Add an ``id`` UUID to a datastore dict entry if missing."""
    entry = datastore.get_data(store_key)
    if not entry or not isinstance(entry, dict):
        return False
    if entry.get("id"):
        return False
    entry["id"] = str(uuid.uuid4())
    ok = datastore.replace_data(store_key, entry)
    if ok:
        log.notice(f"[MIGRATE 0.40.8] Added id={entry['id']} to {store_key}")
    return bool(ok)


def run(ctx: AppContext) -> bool:
    """Add UUID id to lighttpd SSL and SSH config entries that lack one."""
    logger = ctx.get_logger()
    logger.notice("[MIGRATE 0.40.8] Migration started.")

    ds = ctx.get_datastore()

    _ensure_id(ds, DS_KEY_LIGHTTPD_SSL, logger)
    _ensure_id(ds, DS_KEY_SSH_CONFIG, logger)

    logger.notice("[MIGRATE 0.40.8] Migration completed.")
    return True
