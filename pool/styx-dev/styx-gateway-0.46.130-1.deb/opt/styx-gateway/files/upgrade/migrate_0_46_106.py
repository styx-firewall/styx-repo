"""
Migration script: -> 0.46.106

Re-deploys the lr-styx logrotate template so existing installations pick up
rotation for /var/log/styx/styx.log, which was not covered by any logrotate
stanza (only *.json was rotated) and grew unbounded.
"""

import os
import shutil

from core.app_context import AppContext
from services.system_services import SystemServices

TAG = "[MIGRATE 0.46.106]"

TEMPLATES = {
    "lr-styx": ("/etc/logrotate.d/styx", 0o644),
}


def run(ctx: AppContext) -> bool:
    """Force-copy the lr-styx template to /etc/logrotate.d/styx and apply it."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started.")

    src_dir = "/opt/styx-gateway/files/cfg-tpl"
    ok = True

    for filename, (dest, mode) in TEMPLATES.items():
        src = os.path.join(src_dir, filename)
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            os.chmod(dest, mode)
            logger.notice(f"{TAG} Deployed {filename} -> {dest} (mode {oct(mode)})")
        except Exception as e:
            logger.error(f"{TAG} Failed to deploy {filename} -> {dest}: {e}")
            ok = False

    # Apply the new config immediately: logrotate is not a daemon (runs via
    # logrotate.timer / cron.daily), so triggering the logrotate.service
    # oneshot picks up the new stanza now instead of waiting for the next
    # scheduled pass. styx.log has no entry in the logrotate state file, so
    # this run rotates it right away.
    result = SystemServices.reload_or_restart(ctx, "logrotate", skip_reload=True, non_blocking=True)
    if result.ok:
        logger.notice(f"{TAG} logrotate.service triggered.")
    else:
        logger.error(f"{TAG} Failed to trigger logrotate.service: {result.msg}")
        ok = False

    if ok:
        logger.notice(f"{TAG} Migration completed successfully.")
    else:
        logger.notice(f"{TAG} Migration completed with errors (check logs).")
    return ok
