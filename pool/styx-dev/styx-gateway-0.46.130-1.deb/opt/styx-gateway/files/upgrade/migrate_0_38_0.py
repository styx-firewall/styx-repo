"""
Migration script: -> 0.38.0

This script runs once when the gateway upgrades from any version below 0.38.0
to 0.38.0 or higher. Update GW_VERSION / GW_VERSION_MINOR in config/styx_config.py
to 0.38.0 to trigger this migration on the next startup.

Add datastore transformations here as needed.
"""

from core.app_context import AppContext


def run(ctx: AppContext) -> bool:
    """Apply datastore migrations required for version 0.38.0.

    Returns:
        True on success, False on failure.
    """
    logger = ctx.get_logger()
    logger.notice("[MIGRATE 0.38.0] Migration started.")

    # TODO: add datastore transformations here.

    logger.notice("[MIGRATE 0.38.0] Migration completed.")
    return True
