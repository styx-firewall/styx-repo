"""Helper library for eBPF module companions.

Module authors import the functions they need instead of reimplementing
common BPF map type conversions in every companion.

Usage::

    from _helpers import serialize_ipv4, serialize_cidr, serialize_uint32
    from _helpers import format_ipv4, format_cidr, format_uint32
    from _helpers import ktime_to_epoch

    _SERIALIZERS = {"blocklist": serialize_ipv4, "cidr_rules": serialize_cidr}
    _FORMATTERS = {"blocklist": format_ipv4, "cidr_rules": format_cidr}

    def serialize_entry(items, map_name, op):
        return [_SERIALIZERS[map_name](item) for item in items]

    def format_map_entry(key, value, map_name):
        return _FORMATTERS[map_name](key, value)
"""

import ctypes
import ipaddress
import struct as _struct
import time as _time
from typing import Any

# bpf_ktime_get_ns() returns nanoseconds since boot (CLOCK_MONOTONIC).
# Convert to Unix epoch so frontends can display relative times correctly.
_BOOT_EPOCH_S = _time.time() - _time.CLOCK_MONOTONIC


def ktime_to_epoch(ktime_ns: int) -> float | None:
    """Convert ``bpf_ktime_get_ns()`` to Unix epoch seconds, or ``None`` if zero."""
    if ktime_ns == 0:
        return None
    return _BOOT_EPOCH_S + (ktime_ns / 1_000_000_000.0)


#
# High-level serializers  (Python value → (key_ctypes, value_ctypes) tuple)
#


def serialize_ipv4(item: Any) -> tuple[ctypes.Structure, ctypes.Structure]:
    """``"1.2.3.4"`` or ``{"ip": "1.2.3.4"}`` → ``(c_uint32, c_uint8)``."""
    if isinstance(item, dict):
        item = item.get("ip", item)
    return (ctypes.c_uint32(int(ipaddress.IPv4Address(item))), ctypes.c_uint8(1))


def serialize_uint32(item: Any) -> tuple[ctypes.Structure, ctypes.Structure]:
    """``100``, ``{"value": 100}`` or ``{"key": 0, "value": 100}`` → ``(c_uint32, c_uint32)``."""
    if isinstance(item, dict) and "value" in item:
        return (ctypes.c_uint32(item.get("key", 0)), ctypes.c_uint32(item["value"]))
    val = int(item)
    return (ctypes.c_uint32(val), ctypes.c_uint32(val))


# CIDR helpers


class _LpmKey(ctypes.Structure):
    """ctypes mirror of ``struct lpm_key { u32 prefixlen; u32 addr; }``."""

    _fields_ = [("prefixlen", ctypes.c_uint32), ("addr", ctypes.c_uint32)]


def serialize_cidr(item: Any) -> tuple[ctypes.Structure, ctypes.Structure]:
    """``"10.0.0.0/8"`` or ``{"cidr": "10.0.0.0/8"}`` → ``(_LpmKey, c_uint8)``."""
    if isinstance(item, dict):
        item = item.get("cidr", item)
    net = ipaddress.IPv4Network(item, strict=False)
    return (_LpmKey(prefixlen=net.prefixlen, addr=int(net.network_address)), ctypes.c_uint8(1))


#
# High-level formatters  (raw bytes → (key_repr, value_repr) JSON-safe)
#


def format_ipv4(key: bytes, value: Any) -> tuple[str, Any]:
    """u32 bytes + u8 bytes → ``("1.2.3.4", 1)``."""
    if isinstance(key, bytes):
        key = _struct.unpack("<I", key)[0]
    return (str(ipaddress.IPv4Address(key)), int(value) if value is not None else None)


def format_uint32(key: bytes, value: Any) -> tuple[int, Any]:
    """u32 bytes + u32 bytes → ``(0, 100)``."""
    k = _struct.unpack("<I", key)[0] if isinstance(key, bytes) else int(key)
    v = _struct.unpack("<I", value)[0] if isinstance(value, bytes) else int(value) if value is not None else None
    return (k, v)


def format_cidr(key: bytes, value: Any) -> tuple[str, Any]:
    """``struct lpm_key`` bytes + u8 → ``("10.0.0.0/8", 1)``."""
    if isinstance(key, bytes):
        prefixlen = _struct.unpack("<I", key[:4])[0]
        addr = _struct.unpack("<I", key[4:8])[0]
    else:
        prefixlen, addr = key.prefixlen, key.addr
    return (str(ipaddress.IPv4Network((addr, prefixlen), strict=False)), int(value) if value is not None else None)


#
# Low-level helpers  (for custom types that need manual assembly)
#


def u32_to_ip(raw: bytes) -> str:
    """4-byte u32 (big-endian, kernel-written) → dotted-quad string."""
    return str(ipaddress.IPv4Address(_struct.unpack(">I", raw)[0]))


def ip_to_u32(ip_str: str) -> int:
    """Dotted-quad string → host-byte-order u32."""
    return int(ipaddress.IPv4Address(ip_str))


def ip_to_u32_be(ip_str: str) -> bytes:
    """Dotted-quad string → 4-byte big-endian (network byte order)."""
    return _struct.pack(">I", int(ipaddress.IPv4Address(ip_str)))


def unpack_struct(raw: bytes, field_names: list[str], field_formats: list[str]) -> dict[str, Any]:
    """Unpack raw bytes into a dict using struct format strings.

    Only the first format needs a byte-order prefix (``<`` or ``>``); subsequent
    prefixes are stripped automatically.
    """
    fmt = field_formats[0]
    for f in field_formats[1:]:
        fmt += f.lstrip("<>@=!")
    values = _struct.unpack(fmt, raw)
    return dict(zip(field_names, values))


def pack_struct(fields: dict[str, Any], field_names: list[str], field_formats: list[str]) -> bytes:
    """Pack a dict of values into raw bytes using struct format strings."""
    fmt = field_formats[0]
    for f in field_formats[1:]:
        fmt += f.lstrip("<>@=!")
    return _struct.pack(fmt, *(fields[n] for n in field_names))


def bytes_to_int(raw: bytes, byte_order: str = "little") -> int:
    """1/2/4/8-byte buffer → integer."""
    return int.from_bytes(raw, byte_order)


def int_to_bytes(val: int, size: int, byte_order: str = "little") -> bytes:
    """Integer → byte buffer."""
    return val.to_bytes(size, byte_order)


def aggregate_percpu(per_cpu_values, field_names: list[str], field_formats: list[str]) -> dict[str, int]:
    """Sum struct fields across per-CPU slices.

    BPF PERCPU maps return one raw byte slice per CPU. This helper unpacks
    each slice and sums every field, returning a single dict of totals.
    """
    slices = per_cpu_values if isinstance(per_cpu_values, list) else [per_cpu_values]
    totals: dict[str, int] = {name: 0 for name in field_names}
    for s in slices:
        cpu = unpack_struct(s, field_names, field_formats)
        for name in field_names:
            totals[name] += cpu[name]
    return totals


def raw_to_hex(raw: Any) -> Any:
    """Convert raw bytes to hex string or list of ints (JSON-safe fallback)."""
    if raw is None:
        return None
    if isinstance(raw, (int, float, str, bool)):
        return raw
    if isinstance(raw, bytes):
        return raw.hex() if len(raw) <= 32 else list(raw)
    return str(raw)
