# xdp_cpu_redirect/xdp_cpu_redirect_companion.py
#
# Companion for xdp_cpu_redirect.
#
# Provides:
#   - serialize_entry / format_map_entry for cfg_map (reuses _helpers.py)
#   - populate_init_maps() to populate CPUMAP from pre-attach params
#   - Telemetry deserializer for stats PERCPU_ARRAY

import ctypes

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import serialize_uint32, format_uint32, aggregate_percpu

# ── ctypes mirror of struct bpf_cpumap_val (kernel UAPI) ──────────────────


class BpfCpumapVal(ctypes.Structure):
    """Mirror of kernel struct bpf_cpumap_val (8 bytes, natural alignment).

    The union in the kernel struct contains either a bpf_prog fd (if
    non-zero) or the qsize field. We use the union field name 'bpf_prog'
    from the kernel UAPI but treat it as opaque — setting bpf_prog.fd = 0
    means "no chained program."
    """

    _fields_ = [
        ("qsize", ctypes.c_uint32),
        ("bpf_prog_fd", ctypes.c_int32),  # 0 = no chained program
    ]


# ── Stats ctypes mirror ───────────────────────────────────────────────────


class StatsT(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("packets_processed", ctypes.c_uint64),
        ("packets_redirected", ctypes.c_uint64),
        ("packets_passed", ctypes.c_uint64),
        ("errors", ctypes.c_uint64),
    ]


# ── Control map serializers / formatters ───────────────────────────────────

_SERIALIZERS = {"cfg_map": serialize_uint32}
_FORMATTERS = {"cfg_map": format_uint32}


def serialize_entry(items, map_name, op):
    try:
        handler = _SERIALIZERS[map_name]
    except KeyError:
        raise ValueError(f"Map '{map_name}' does not support push")
    return [handler(item) for item in items]


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# ── CPU validation helpers ────────────────────────────────────────────


def _read_online_cpus():
    """Return the set of online CPU indices from sysfs."""
    with open("/sys/devices/system/cpu/online") as f:
        parts = f.read().strip().split(",")
    cpus = set()
    for part in parts:
        if not part:
            continue
        if "-" in part:
            lo, hi = part.split("-")
            cpus.update(range(int(lo), int(hi) + 1))
        else:
            cpus.add(int(part))
    return cpus


# ── Init maps hook (declared via init_hook in module.toml) ────────────────


def populate_init_maps(mod, descriptor):
    """Populate cpu_map (CPUMAP), cpus_available, and cpus_count
    from pre-attach params at module load time.

    Called by EbpfService.load_module() after backend.load() + attach()
    and after static [[control_map.entry]] seeding.

    Validates that every CPU in cpu_list is online before touching any BPF map.
    Raises ValueError with a clear message listing invalid CPUs.

    Args:
        mod: LoadedModule — provides mod.control_maps dict of _BpfMap objects
        descriptor: ModuleDescriptor — pre-attach params already applied as attributes
    """
    cpu_list_str = getattr(descriptor, "cpu_list", "0")
    cpu_queue_size = getattr(descriptor, "cpu_queue_size", 2048)

    # Parse CPU list (comma-separated integers)
    cpu_indices = []
    for part in cpu_list_str.split(","):
        part = part.strip()
        if part:
            cpu_indices.append(int(part))
    if not cpu_indices:
        cpu_indices = [0]

    # Validate all CPUs are online before writing to any BPF map
    online = _read_online_cpus()
    invalid = sorted(c for c in cpu_indices if c not in online)
    if invalid:
        raise ValueError(
            f"CPUs {invalid} are not online. "
            f"Available CPUs: {sorted(online)}. "
            f"Adjust cpu_list ('{cpu_list_str}') and retry."
        )

    cpu_count = len(cpu_indices)

    # 1. cpus_count — single entry: total number of available CPUs
    cpus_count_map = mod.control_maps.get("cpus_count")
    if cpus_count_map is not None:
        cpus_count_map[ctypes.c_uint32(0)] = ctypes.c_uint32(cpu_count)

    # 2. cpus_available — hash index → real CPU number lookup table
    cpus_avail_map = mod.control_maps.get("cpus_available")
    if cpus_avail_map is not None:
        for idx, cpu in enumerate(cpu_indices):
            cpus_avail_map[ctypes.c_uint32(idx)] = ctypes.c_uint32(cpu)

    # 3. cpu_map — CPUMAP: real CPU number → bpf_cpumap_val (qsize + no chained prog)
    cpu_map = mod.control_maps.get("cpu_map")
    if cpu_map is not None:
        val = BpfCpumapVal(qsize=cpu_queue_size, bpf_prog_fd=0)
        for cpu in cpu_indices:
            cpu_map[ctypes.c_uint32(cpu)] = val


# ── Telemetry deserializer ────────────────────────────────────────────────


@register_deserializer("xdp_cpu_redirect", "stats")
class StatsDeserializer(FeedbackDeserializer):
    """Aggregate per-CPU stats counters into a single dict."""

    _FIELDS = ["packets_processed", "packets_redirected", "packets_passed", "errors"]
    _FMTS = ["<Q", "<Q", "<Q", "<Q"]

    def from_map(self, raw, spec, key=None) -> dict:
        totals = aggregate_percpu(raw, self._FIELDS, self._FMTS)
        return {
            "packets_processed": totals["packets_processed"],
            "packets_redirected": totals["packets_redirected"],
            "packets_passed": totals["packets_passed"],
            "errors": totals["errors"],
        }

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")
