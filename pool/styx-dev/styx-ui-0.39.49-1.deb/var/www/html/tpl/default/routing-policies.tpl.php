<?php
/**
 * FRR Policies  -  Prefix Lists, Route Maps, AS Path Lists, Community Lists
 * @var array<mixed> $tdata
 * js: scripts/routing/routing-policies.js
 */
$page_data       = $tdata['page_data'];
$prefix_lists    = $page_data['prefix_lists'] ?? [];
$route_maps      = $page_data['route_maps'] ?? [];
$as_path_lists   = $page_data['as_path_lists'] ?? [];
$community_lists = $page_data['community_lists'] ?? [];
$can_add         = !empty($page_data['can_add']);
?>
<script>
window.__policiesData = {
    prefix_list:    <?= json_encode($prefix_lists) ?>,
    route_map:      <?= json_encode($route_maps) ?>,
    as_path_list:   <?= json_encode($as_path_lists) ?>,
    community_list: <?= json_encode($community_lists) ?>
};
</script>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>FRR Policies</h1>

        <section class="content-box">
            <div class="std-tabs" id="policies-tabs">
                <button class="std-tab-btn active" data-tab="prefix-lists">Prefix Lists</button>
                <button class="std-tab-btn" data-tab="route-maps">Route Maps</button>
                <button class="std-tab-btn" data-tab="as-path-lists">AS Path Lists</button>
                <button class="std-tab-btn" data-tab="community-lists">Community Lists</button>
            </div>

            <!-- Prefix Lists -->
            <div class="std-tab-panel active" id="tab-prefix-lists">
                <details class="nat-help">
                    <summary>Help - Prefix Lists</summary>
                    <div class="nat-help-content">
                        <p><strong>Prefix lists</strong> filter IP prefixes by exact match or range (ge/le). More efficient and flexible than ACLs for route filtering.</p>
                        <ul>
                            <li><strong>Action:</strong> permit or deny matching prefixes.</li>
                            <li><strong>Network:</strong> Address set UUID (network scope) for the base prefix.</li>
                            <li><strong>GE / LE:</strong> Optional prefix length range. Example: <code>10.0.0.0/8 ge 16 le 24</code> matches 10.x.x.x with mask between /16 and /24.</li>
                            <li><strong>Usage:</strong> Referenced by route-maps (match) or directly in BGP neighbor distribute-list, OSPF filter-list, etc.</li>
                        </ul>
                    </div>
                </details>
                <div class="content-box-header">
                    <h2>Prefix Lists</h2>
                    <?php if ($can_add): ?>
                    <button type="button" class="std-btn" data-js="policies-toggle-form"
                        data-target="prefix-list-add-form">+ Add</button>
                    <?php endif; ?>
                </div>

                <div class="content-box" id="prefix-list-add-form" style="display:none;">
                    <h3 id="prefix-list-form-title">Add Prefix List</h3>
                    <form class="std-form form-compact" data-js="policy-add-form" data-policy="prefix_list">
                        <input type="hidden" class="js-policy-id" value="">
                        <div class="form-row">
                            <div class="form-col">
                                <label for="pl-name">Name</label>
                                <input type="text" id="pl-name" class="std-input js-policy-name" required
                                    placeholder="e.g. RFC1918">
                            </div>
                            <div class="form-col">
                                <label for="pl-desc">Description</label>
                                <input type="text" id="pl-desc" class="std-input js-policy-desc"
                                    placeholder="Optional">
                            </div>
                        </div>
                        <div class="js-entries-container"></div>
                        <div class="form-row">
                            <button type="button" class="std-btn std-btn--sm" data-js="policy-entry-row-add">+ Entry</button>
                        </div>
                        <div class="form-row">
                            <button type="button" class="std-btn js-policy-submit" id="prefix-list-submit-btn">Create</button>
                            <button type="button" class="std-btn std-btn--secondary"
                                data-js="policies-toggle-form"
                                data-target="prefix-list-add-form">Cancel</button>
                        </div>
                        <template class="js-entry-block-template">
                            <div class="js-entry-block">
                                <div class="policy-entry-head">
                                    <strong>Entry <span class="js-entry-block-idx">1</span></strong>
                                    <button type="button"
                                        class="std-btn std-btn--sm std-btn--secondary js-entry-remove">Remove</button>
                                </div>
                                <div class="form-row">
                                    <div class="form-col form-col--tight">
                                        <label>Seq</label>
                                        <input type="number" class="std-input js-entry-seq" value="10" min="1">
                                    </div>
                                    <div class="form-col form-col--tight">
                                        <label>Action</label>
                                        <select class="std-input js-entry-action">
                                            <option value="permit">permit</option>
                                            <option value="deny">deny</option>
                                        </select>
                                    </div>
                                    <div class="form-col">
                                        <label>Network (address set)</label>
                                        <div class="set-picker-field" data-js="set-picker-field"
                                             data-set-type="address" data-max-select="1"
                                             data-filter-scope="network">
                                            <input type="hidden" class="js-entry-prefix-set" value="">
                                            <button type="button"
                                                class="std-btn-picker set-picker-trigger js-set-picker-open"
                                                data-placeholder="Select network">
                                                <span class="js-set-picker-label">Select network</span>
                                            </button>
                                            <button type="button"
                                                class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                                title="Clear">&#215;</button>
                                        </div>
                                    </div>
                                    <div class="form-col form-col--tight">
                                        <label>GE (min)</label>
                                        <input type="number" class="std-input js-entry-ge"
                                            min="0" max="32" placeholder="any">
                                    </div>
                                    <div class="form-col form-col--tight">
                                        <label>LE (max)</label>
                                        <input type="number" class="std-input js-entry-le"
                                            min="0" max="32" placeholder="any">
                                    </div>
                                </div>
                            </div>
                        </template>
                    </form>
                </div>

                <table class="std-table">
                    <thead>
                        <tr><th>Name</th><th>Description</th><th>Entries</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                    <?php if (empty($prefix_lists)): ?>
                        <tr class="std-table-empty"><td colspan="4">No prefix lists configured.</td></tr>
                    <?php else: ?>
                        <?php foreach ($prefix_lists as $pl): ?>
                        <tr data-policy-id="<?= $pl['id'] ?>">
                            <td><strong><?= $pl['name'] ?></strong></td>
                            <td><?= $pl['description'] ?? '-' ?></td>
                            <td><?= count($pl['entries'] ?? []) ?></td>
                            <td>
                                <?php if (!empty($pl['can_delete'])): ?>
                                <button type="button" class="std-btn std-btn--sm"
                                    data-js="policy-edit" data-policy="prefix_list"
                                    data-id="<?= $pl['id'] ?>"
                                    data-target="prefix-list-add-form"
                                    data-title="prefix-list-form-title"
                                    data-submit-btn="prefix-list-submit-btn">Edit</button>
                                <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                    data-js="policies-delete" data-policy="prefix_list"
                                    data-id="<?= $pl['id'] ?>">Delete</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Route Maps -->
            <div class="std-tab-panel" id="tab-route-maps">
                <details class="nat-help">
                    <summary>Help - Route Maps</summary>
                    <div class="nat-help-content">
                        <p><strong>Route maps</strong> define match conditions and set actions to filter or modify routes. They are the policy engine of FRR.</p>
                        <ul>
                            <li><strong>Seq / Action:</strong> Entries evaluated in order. First match wins (permit) or rejects (deny).</li>
                            <li><strong>Match:</strong> Filter by prefix-list, AS-path list, community list, or exact community match.</li>
                            <li><strong>Set:</strong> Modify route attributes - local preference, metric, community, next-hop, origin, weight, AS-path prepend.</li>
                            <li><strong>Usage:</strong> Apply as route-map in/out on BGP neighbors, redistribute filters, or OSPF route injection.</li>
                        </ul>
                    </div>
                </details>
                <div class="content-box-header">
                    <h2>Route Maps</h2>
                    <?php if ($can_add): ?>
                    <button type="button" class="std-btn" data-js="policies-toggle-form"
                        data-target="route-map-add-form">+ Add</button>
                    <?php endif; ?>
                </div>

                <div class="content-box" id="route-map-add-form" style="display:none;">
                    <h3 id="route-map-form-title">Add Route Map</h3>
                    <form class="std-form form-compact" data-js="policy-add-form" data-policy="route_map">
                        <input type="hidden" class="js-policy-id" value="">
                        <div class="form-row">
                            <div class="form-col">
                                <label for="rm-name">Name</label>
                                <input type="text" id="rm-name" class="std-input js-policy-name" required
                                    placeholder="e.g. SET-LOCAL-PREF">
                            </div>
                            <div class="form-col">
                                <label for="rm-desc">Description</label>
                                <input type="text" id="rm-desc" class="std-input js-policy-desc"
                                    placeholder="Optional">
                            </div>
                        </div>
                        <div class="js-entries-container"></div>
                        <div class="form-row">
                            <button type="button" class="std-btn std-btn--sm" data-js="policy-entry-row-add">+ Entry</button>
                        </div>
                        <div class="form-row">
                            <button type="button" class="std-btn js-policy-submit" id="route-map-submit-btn">Create</button>
                            <button type="button" class="std-btn std-btn--secondary"
                                data-js="policies-toggle-form"
                                data-target="route-map-add-form">Cancel</button>
                        </div>
                        <template class="js-entry-block-template">
                            <div class="js-entry-block">
                                <div class="policy-entry-head">
                                    <strong>Entry <span class="js-entry-block-idx">1</span></strong>
                                    <button type="button"
                                        class="std-btn std-btn--sm std-btn--secondary js-entry-remove">Remove</button>
                                </div>
                                <fieldset class="std-fieldset">
                                    <legend class="std-fieldset-legend">Entry</legend>
                                    <div class="form-row">
                                        <div class="form-col form-col--tight">
                                            <label>Seq</label>
                                            <input type="number" class="std-input js-entry-seq" value="10" min="1">
                                        </div>
                                        <div class="form-col form-col--tight">
                                            <label>Action</label>
                                            <select class="std-input js-entry-action">
                                                <option value="permit">permit</option>
                                                <option value="deny">deny</option>
                                            </select>
                                        </div>
                                        <div class="form-col">
                                            <label>Entry Description</label>
                                            <input type="text" class="std-input js-entry-desc"
                                                placeholder="Optional">
                                        </div>
                                    </div>
                                </fieldset>
                                <fieldset class="std-fieldset">
                                    <legend class="std-fieldset-legend">Match</legend>
                                    <div class="form-row">
                                        <div class="form-col">
                                            <label>Prefix List</label>
                                            <select class="std-input js-match-prefix-list">
                                                <option value="">- None -</option>
                                                <?php foreach ($prefix_lists as $pl): ?>
                                                <option value="<?= $pl['id'] ?>"><?= $pl['name'] ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="form-col">
                                            <label>AS Path List</label>
                                            <select class="std-input js-match-as-path-list">
                                                <option value="">- None -</option>
                                                <?php foreach ($as_path_lists as $aspl): ?>
                                                <option value="<?= $aspl['id'] ?>"><?= $aspl['name'] ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="form-col">
                                            <label>Community List</label>
                                            <select class="std-input js-match-community-list">
                                                <option value="">- None -</option>
                                                <?php foreach ($community_lists as $cl): ?>
                                                <option value="<?= $cl['id'] ?>"><?= $cl['name'] ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="form-col form-col--tight">
                                            <label>Community Exact Match</label>
                                            <label class="std-switch">
                                                <input type="checkbox" class="js-match-community-exact">
                                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                                            </label>
                                        </div>
                                    </div>
                                </fieldset>
                                <fieldset class="std-fieldset">
                                    <legend class="std-fieldset-legend">Set</legend>
                                    <div class="form-row">
                                        <div class="form-col form-col--tight">
                                            <label>Local Preference</label>
                                            <input type="number" class="std-input js-set-local-pref"
                                                min="0" max="4294967295" placeholder="none">
                                        </div>
                                        <div class="form-col form-col--tight">
                                            <label>Metric</label>
                                            <input type="number" class="std-input js-set-metric"
                                                min="0" placeholder="none">
                                        </div>
                                        <div class="form-col">
                                            <label>Community</label>
                                            <div class="set-picker-field" data-js="label-picker-field"
                                                 data-set-type="community" data-max-select="1">
                                                <input type="hidden" class="js-set-community" value="">
                                                <button type="button"
                                                    class="std-btn-picker set-picker-trigger js-set-picker-open"
                                                    data-placeholder="Select community label">
                                                    <span class="js-set-picker-label">None</span>
                                                </button>
                                                <button type="button"
                                                    class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                                    title="Clear">&#215;</button>
                                            </div>
                                        </div>
                                        <div class="form-col form-col--tight">
                                            <label>Community Additive</label>
                                            <label class="std-switch">
                                                <input type="checkbox" class="js-set-community-additive">
                                                <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-col">
                                            <label>Next Hop (address set)</label>
                                            <div class="set-picker-field" data-js="set-picker-field"
                                                 data-set-type="address" data-max-select="1"
                                                 data-filter-scope="host">
                                                <input type="hidden" class="js-set-ip-next-hop" value="">
                                                <button type="button"
                                                    class="std-btn-picker set-picker-trigger js-set-picker-open"
                                                    data-placeholder="Optional">
                                                    <span class="js-set-picker-label">Optional - next hop</span>
                                                </button>
                                                <button type="button"
                                                    class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                                    title="Clear">&#215;</button>
                                            </div>
                                        </div>
                                        <div class="form-col form-col--tight">
                                            <label>Origin</label>
                                            <select class="std-input js-set-origin">
                                                <option value="">- None -</option>
                                                <option value="igp">igp</option>
                                                <option value="egp">egp</option>
                                                <option value="incomplete">incomplete</option>
                                            </select>
                                        </div>
                                        <div class="form-col form-col--tight">
                                            <label>Weight</label>
                                            <input type="number" class="std-input js-set-weight"
                                                min="0" placeholder="none">
                                        </div>
                                        <div class="form-col">
                                            <label>AS Path Prepend</label>
                                            <div class="set-picker-field" data-js="label-picker-field"
                                                 data-set-type="as_path_prepend" data-max-select="1">
                                                <input type="hidden" class="js-set-as-prepend" value="">
                                                <button type="button"
                                                    class="std-btn-picker set-picker-trigger js-set-picker-open"
                                                    data-placeholder="Select prepend label">
                                                    <span class="js-set-picker-label">None</span>
                                                </button>
                                                <button type="button"
                                                    class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                                    title="Clear">&#215;</button>
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>
                            </div>
                        </template>
                    </form>
                </div>

                <table class="std-table">
                    <thead>
                        <tr><th>Name</th><th>Description</th><th>Entries</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                    <?php if (empty($route_maps)): ?>
                        <tr class="std-table-empty"><td colspan="4">No route maps configured.</td></tr>
                    <?php else: ?>
                        <?php foreach ($route_maps as $rm): ?>
                        <tr data-policy-id="<?= $rm['id'] ?>">
                            <td><strong><?= $rm['name'] ?></strong></td>
                            <td><?= $rm['description'] ?? '-' ?></td>
                            <td><?= count($rm['entries'] ?? []) ?></td>
                            <td>
                                <?php if (!empty($rm['can_delete'])): ?>
                                <button type="button" class="std-btn std-btn--sm"
                                    data-js="policy-edit" data-policy="route_map"
                                    data-id="<?= $rm['id'] ?>"
                                    data-target="route-map-add-form"
                                    data-title="route-map-form-title"
                                    data-submit-btn="route-map-submit-btn">Edit</button>
                                <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                    data-js="policies-delete" data-policy="route_map"
                                    data-id="<?= $rm['id'] ?>">Delete</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- AS Path Lists -->
            <div class="std-tab-panel" id="tab-as-path-lists">
                <details class="nat-help">
                    <summary>Help - AS Path Lists</summary>
                    <div class="nat-help-content">
                        <p><strong>AS path lists</strong> filter BGP routes based on the AS_PATH attribute using regular expressions.</p>
                        <ul>
                            <li><strong>Regex:</strong> BGP regular expression. <code>^$</code> matches local routes, <code>_65001_</code> matches routes traversing AS 65001, <code>.*</code> matches everything.</li>
                            <li><strong>Usage:</strong> Referenced by route-maps (match as-path). Typical use: deny private ASNs, prefer customer routes, filter transit paths.</li>
                        </ul>
                    </div>
                </details>
                <div class="content-box-header">
                    <h2>AS Path Lists</h2>
                    <?php if ($can_add): ?>
                    <button type="button" class="std-btn" data-js="policies-toggle-form"
                        data-target="as-path-list-add-form">+ Add</button>
                    <?php endif; ?>
                </div>

                <div class="content-box" id="as-path-list-add-form" style="display:none;">
                    <h3 id="as-path-list-form-title">Add AS Path List</h3>
                    <form class="std-form form-compact" data-js="policy-add-form" data-policy="as_path_list">
                        <input type="hidden" class="js-policy-id" value="">
                        <div class="form-row">
                            <div class="form-col">
                                <label for="aspl-name">Name</label>
                                <input type="text" id="aspl-name" class="std-input js-policy-name" required
                                    placeholder="e.g. DENY-PRIVATE-AS">
                            </div>
                            <div class="form-col">
                                <label for="aspl-desc">Description</label>
                                <input type="text" id="aspl-desc" class="std-input js-policy-desc"
                                    placeholder="Optional">
                            </div>
                        </div>
                        <div class="js-entries-container"></div>
                        <div class="form-row">
                            <button type="button" class="std-btn std-btn--sm" data-js="policy-entry-row-add">+ Entry</button>
                        </div>
                        <div class="form-row">
                            <button type="button" class="std-btn js-policy-submit" id="as-path-list-submit-btn">Create</button>
                            <button type="button" class="std-btn std-btn--secondary"
                                data-js="policies-toggle-form"
                                data-target="as-path-list-add-form">Cancel</button>
                        </div>
                        <template class="js-entry-block-template">
                            <div class="js-entry-block">
                                <div class="policy-entry-head">
                                    <strong>Entry <span class="js-entry-block-idx">1</span></strong>
                                    <button type="button"
                                        class="std-btn std-btn--sm std-btn--secondary js-entry-remove">Remove</button>
                                </div>
                                <div class="form-row">
                                    <div class="form-col form-col--tight">
                                        <label>Seq</label>
                                        <input type="number" class="std-input js-entry-seq" value="10" min="1">
                                    </div>
                                    <div class="form-col form-col--tight">
                                        <label>Action</label>
                                        <select class="std-input js-entry-action">
                                            <option value="permit">permit</option>
                                            <option value="deny">deny</option>
                                        </select>
                                    </div>
                                    <div class="form-col">
                                        <label>Regex</label>
                                        <div class="set-picker-field" data-js="label-picker-field"
                                             data-set-type="as_path_regex" data-max-select="1">
                                            <input type="hidden" class="js-entry-regex" value="">
                                            <button type="button"
                                                class="std-btn-picker set-picker-trigger js-set-picker-open"
                                                data-placeholder="Select regex label">
                                                <span class="js-set-picker-label">Select regex</span>
                                            </button>
                                            <button type="button"
                                                class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                                title="Clear">&#215;</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </form>
                </div>

                <table class="std-table">
                    <thead>
                        <tr><th>Name</th><th>Description</th><th>Entries</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                    <?php if (empty($as_path_lists)): ?>
                        <tr class="std-table-empty"><td colspan="4">No AS path lists configured.</td></tr>
                    <?php else: ?>
                        <?php foreach ($as_path_lists as $aspl): ?>
                        <tr data-policy-id="<?= $aspl['id'] ?>">
                            <td><strong><?= $aspl['name'] ?></strong></td>
                            <td><?= $aspl['description'] ?? '-' ?></td>
                            <td><?= count($aspl['entries'] ?? []) ?></td>
                            <td>
                                <?php if (!empty($aspl['can_delete'])): ?>
                                <button type="button" class="std-btn std-btn--sm"
                                    data-js="policy-edit" data-policy="as_path_list"
                                    data-id="<?= $aspl['id'] ?>"
                                    data-target="as-path-list-add-form"
                                    data-title="as-path-list-form-title"
                                    data-submit-btn="as-path-list-submit-btn">Edit</button>
                                <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                    data-js="policies-delete" data-policy="as_path_list"
                                    data-id="<?= $aspl['id'] ?>">Delete</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Community Lists -->
            <div class="std-tab-panel" id="tab-community-lists">
                <details class="nat-help">
                    <summary>Help - Community Lists</summary>
                    <div class="nat-help-content">
                        <p><strong>Community lists</strong> match BGP community values - 32-bit tags attached to routes for policy control.</p>
                        <ul>
                            <li><strong>Standard:</strong> Match exact community values (e.g. <code>65001:100</code>, <code>no-export</code>).</li>
                            <li><strong>Expanded:</strong> Match communities using regular expressions.</li>
                            <li><strong>Usage:</strong> Referenced by route-maps (match community). Used to tag routes at ingress and filter at egress, or to implement hierarchical routing policies.</li>
                        </ul>
                    </div>
                </details>
                <div class="content-box-header">
                    <h2>Community Lists</h2>
                    <?php if ($can_add): ?>
                    <button type="button" class="std-btn" data-js="policies-toggle-form"
                        data-target="community-list-add-form">+ Add</button>
                    <?php endif; ?>
                </div>

                <div class="content-box" id="community-list-add-form" style="display:none;">
                    <h3 id="community-list-form-title">Add Community List</h3>
                    <form class="std-form form-compact" data-js="policy-add-form" data-policy="community_list">
                        <input type="hidden" class="js-policy-id" value="">
                        <div class="form-row">
                            <div class="form-col">
                                <label for="cl-name">Name</label>
                                <input type="text" id="cl-name" class="std-input js-policy-name" required
                                    placeholder="e.g. CUSTOMER-ROUTES">
                            </div>
                            <div class="form-col">
                                <label for="cl-desc">Description</label>
                                <input type="text" id="cl-desc" class="std-input js-policy-desc"
                                    placeholder="Optional">
                            </div>
                            <div class="form-col form-col--tight">
                                <label for="cl-type">List Type</label>
                                <select id="cl-type" class="std-input js-list-type">
                                    <option value="standard">standard</option>
                                    <option value="expanded">expanded</option>
                                </select>
                            </div>
                        </div>
                        <div class="js-entries-container"></div>
                        <div class="form-row">
                            <button type="button" class="std-btn std-btn--sm" data-js="policy-entry-row-add">+ Entry</button>
                        </div>
                        <div class="form-row">
                            <button type="button" class="std-btn js-policy-submit" id="community-list-submit-btn">Create</button>
                            <button type="button" class="std-btn std-btn--secondary"
                                data-js="policies-toggle-form"
                                data-target="community-list-add-form">Cancel</button>
                        </div>
                        <template class="js-entry-block-template">
                            <div class="js-entry-block">
                                <div class="policy-entry-head">
                                    <strong>Entry <span class="js-entry-block-idx">1</span></strong>
                                    <button type="button"
                                        class="std-btn std-btn--sm std-btn--secondary js-entry-remove">Remove</button>
                                </div>
                                <div class="form-row">
                                    <div class="form-col form-col--tight">
                                        <label>Seq</label>
                                        <input type="number" class="std-input js-entry-seq" value="10" min="1">
                                    </div>
                                    <div class="form-col form-col--tight">
                                        <label>Action</label>
                                        <select class="std-input js-entry-action">
                                            <option value="permit">permit</option>
                                            <option value="deny">deny</option>
                                        </select>
                                    </div>
                                    <div class="form-col">
                                        <label>Community</label>
                                        <div class="set-picker-field" data-js="label-picker-field"
                                             data-set-type="community" data-max-select="1">
                                            <input type="hidden" class="js-entry-community" value="">
                                            <button type="button"
                                                class="std-btn-picker set-picker-trigger js-set-picker-open"
                                                data-placeholder="Select community label">
                                                <span class="js-set-picker-label">Select community</span>
                                            </button>
                                            <button type="button"
                                                class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                                title="Clear">&#215;</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </form>
                </div>

                <table class="std-table">
                    <thead>
                        <tr><th>Name</th><th>Type</th><th>Description</th><th>Entries</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                    <?php if (empty($community_lists)): ?>
                        <tr class="std-table-empty"><td colspan="5">No community lists configured.</td></tr>
                    <?php else: ?>
                        <?php foreach ($community_lists as $cl): ?>
                        <tr data-policy-id="<?= $cl['id'] ?>">
                            <td><strong><?= $cl['name'] ?></strong></td>
                            <td><span class="std-badge"><?= $cl['list_type'] ?? 'standard' ?></span></td>
                            <td><?= $cl['description'] ?? '-' ?></td>
                            <td><?= count($cl['entries'] ?? []) ?></td>
                            <td>
                                <?php if (!empty($cl['can_delete'])): ?>
                                <button type="button" class="std-btn std-btn--sm"
                                    data-js="policy-edit" data-policy="community_list"
                                    data-id="<?= $cl['id'] ?>"
                                    data-target="community-list-add-form"
                                    data-title="community-list-form-title"
                                    data-submit-btn="community-list-submit-btn">Edit</button>
                                <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                    data-js="policies-delete" data-policy="community_list"
                                    data-id="<?= $cl['id'] ?>">Delete</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>
