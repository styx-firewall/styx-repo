<?php
/**
 * @var array<mixed> $tdata
 * js: scripts/routing/routing-igmp-proxy.js
 */
$page_data   = $tdata['page_data'];
$igmp_config = $page_data['igmp_config'] ?? [];
$interfaces  = $page_data['interfaces'] ?? [];
$upstream    = $page_data['upstream'] ?? [];
$downstream  = $page_data['downstream'] ?? [];
$igmp_ifaces = $page_data['igmp_ifaces'] ?? [];
?>
<div><?= $tdata['page_head'] ?? '' ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?? '' ?></div>
    <main class="page-content">
        <h1>IGMP Proxy</h1>

        <details class="nat-help">
            <summary>Help</summary>
            <div class="nat-help-content">
                <p><strong>IGMP Proxy</strong> forwards multicast group membership requests between interfaces. Used to enable IPTV or multicast streaming across routed segments without a full multicast routing protocol like PIM.</p>
                <ul>
                    <li><strong>Upstream:</strong> Interface facing the multicast source/router (e.g. WAN).</li>
                    <li><strong>Downstream:</strong> Interface(s) facing clients (e.g. LAN). Optionally restrict allowed groups with a whitelist address set.</li>
                </ul>
            </div>
        </details>

        <!-- Global config -->
        <div class="content-box">
            <h2>IGMP Proxy Configuration</h2>
            <form id="igmp-config-form" class="std-form" data-js="igmp-config-form">
                <div class="form-row">
                    <div class="form-col">
                        <label for="igmp_enabled">Enabled</label>
                        <label class="std-switch">
                            <input type="checkbox" id="igmp_enabled" name="enabled"
                                <?= !empty($igmp_config['enabled']) ? 'checked' : '' ?>>
                            <span class="std-switch-slider" data-on="ON" data-off="OFF"></span>
                        </label>
                    </div>
                </div>
                <div class="form-row">
                    <button type="button" class="std-btn" data-js="igmp-save-config">Save Configuration</button>
                </div>
            </form>
        </div>

        <!-- Upstream interface -->
        <div class="content-box">
            <div class="content-box-header">
                <h2>Upstream Interface</h2>
                <?php if (empty($upstream)): ?>
                <button type="button" class="std-btn" data-js="igmp-add-iface-open" data-role="upstream">
                    + Set Upstream
                </button>
                <?php endif; ?>
            </div>
            <table class="std-table" id="igmp-upstream-table">
                <thead>
                    <tr>
                        <th>Interface</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="igmp-upstream-tbody">
                <?php if (empty($upstream)): ?>
                    <tr class="std-table-empty"><td colspan="2">No upstream interface configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($upstream as $iface): ?>
                    <?php $ifaceDisplay = $iface['iface_display'] ?? null; ?>
                    <tr data-iface-id="<?= $iface['id'] ?>">
                        <td>
                            <?php if ($ifaceDisplay): ?>
                                <?= $ifaceDisplay['name'] ?? $ifaceDisplay['interface'] ?? $iface['iface'] ?>
                            <?php else: ?>
                                <?= $iface['iface'] ?? '-' ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="igmp-delete-iface" data-id="<?= $iface['id'] ?>">Remove</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody> 
            </table>
        </div>

        <!-- Downstream interfaces -->
        <div class="content-box">
            <div class="content-box-header">
                <h2>Downstream Interfaces</h2>
                <button type="button" class="std-btn" data-js="igmp-add-iface-open" data-role="downstream">
                    + Add Downstream
                </button>
            </div>
            <table class="std-table" id="igmp-downstream-table">
                <thead>
                    <tr>
                        <th>Interface</th>
                        <th>Whitelist</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="igmp-downstream-tbody">
                <?php if (empty($downstream)): ?>
                    <tr class="std-table-empty"><td colspan="3">No downstream interfaces configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($downstream as $iface): ?>
                    <?php $ifaceDisplay = $iface['iface_display'] ?? null; ?>
                    <?php $wlDisplay = $iface['whitelist_display'] ?? null; ?>
                    <tr data-iface-id="<?= $iface['id'] ?>">
                        <td>
                            <?php if ($ifaceDisplay): ?>
                                <?= $ifaceDisplay['name'] ?? $ifaceDisplay['interface'] ?? $iface['iface'] ?>
                            <?php else: ?>
                                <?= $iface['iface'] ?? '-' ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($wlDisplay): ?>
                                <span class="set-ref" title="<?= !empty($wlDisplay['value']) ? $wlDisplay['value'] : $wlDisplay['name'] ?>">
                                    <span class="set-name"><?= $wlDisplay['name'] ?></span>
                                </span>
                            <?php else: ?>
                                <span class="text-dim">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button type="button" class="std-btn std-btn--danger std-btn--sm"
                                data-js="igmp-delete-iface" data-id="<?= $iface['id'] ?>">Remove</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Add interface form (hidden by default) -->
        <div class="content-box" id="igmp-add-iface-form" style="display:none;">
            <h2 id="igmp-add-iface-title">Add Interface</h2>
            <form class="std-form" data-js="igmp-iface-form">
                <input type="hidden" id="igmp_iface_role" name="role" value="">
                <div class="form-row">
                    <div class="form-col">
                        <label for="igmp_iface">Interface</label>
                        <select id="igmp_iface" class="std-input" required>
                            <option value="">Select an interface...</option>
                            <?php foreach ($igmp_ifaces as $iface): ?>
                            <option value="<?= $iface['id'] ?>"><?= $iface['interface'] ?? $iface['name'] ?? $iface['id'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row" id="igmp-whitelist-row" style="display:none;">
                    <div class="form-col">
                        <label>Whitelist (address set)</label>
                        <div class="set-picker-field" data-js="set-picker-field" data-set-type="address"
                             data-max-select="1" data-filter-type="single" data-filter-scope="network">
                            <input type="hidden" id="igmp_whitelist" name="whitelist" value="">
                            <button type="button" class="std-btn-picker set-picker-trigger js-set-picker-open"
                                data-placeholder="Select address set...">
                                <span class="js-set-picker-label">None (all groups allowed)</span>
                            </button>
                            <button type="button" class="std-btn-picker set-picker-clear js-set-picker-clear sets-hidden"
                                title="Clear selection">&#215;</button>
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <button type="button" class="std-btn" data-js="igmp-iface-save">Save Interface</button>
                    <button type="button" class="std-btn std-btn--secondary" data-js="igmp-add-iface-cancel">Cancel</button>
                </div>
            </form>
        </div>

    </main>
</div>
