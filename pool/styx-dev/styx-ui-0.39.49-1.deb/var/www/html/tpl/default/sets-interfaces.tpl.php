<?php
/**
 * Fragment: Interface sets - unified panel.
 * mode=mgmt   : accordion panel on Objects page (headings + text filter)
 * mode=picker : selection modal - CRUD available + checkbox column + confirm button
 * Expects $tdata['tpl_data']['interfaces_sets'], $tdata['tpl_data']['ifaces_names'],
 *         $tdata['tpl_data']['mode']
 */
$interfaces_sets = $tdata['tpl_data']['interfaces_sets'] ?? [];
$ifaces_names = $tdata['tpl_data']['ifaces_names'] ?? [];
$mode = $tdata['tpl_data']['mode'] ?? 'picker';
?>
<?php if ($mode === 'mgmt'): ?>
<h2>Interface Sets</h2>
<?php endif; ?>
<form id="iface-set-form" class="std-form" autocomplete="off">
    <input type="hidden" name="id" id="iface_id" value="">
    <div class="std-flex-row">
        <label>Type*
            <span class="js-info-icon" data-info-modal="help-iface-type"></span>
            <select name="type" required>
                <option value="single">Single</option>
                <option value="set">Set</option>
            </select>
        </label>
        <label>Name*
            <span class="js-info-icon" data-info-modal="help-iface-name"></span>
            <input type="text" name="name" required maxlength="32" placeholder="Unique name">
        </label>
        <label>Description
            <span class="js-info-icon" data-info-modal="help-iface-description"></span>
            <input type="text" name="description" maxlength="64" placeholder="Optional">
        </label>
        <label>Tags
            <span class="js-info-icon" data-info-modal="help-iface-tags"></span>
            <input type="text" name="tags" placeholder="Tags separated by spaces or commas">
        </label>
    </div>

    <div class="std-flex-row value-row value-row-single">
        <label>Interface*
            <span class="js-info-icon" data-info-modal="help-iface-value-single"></span>
            <select name="value_single">
                <option value="">-- Select --</option>
                <?php foreach ($ifaces_names as $iface): ?>
                    <option value="<?= $iface ?>"><?= $iface ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    </div>

    <div class="std-flex-row value-row value-row-set sets-hidden">
        <label>Interfaces*
            <span class="js-info-icon" data-info-modal="help-iface-value-set"></span>
            <select id="iface-multiselect" name="value_set[]" multiple class="sets-multiselect-size">
                <?php foreach ($ifaces_names as $iface): ?>
                    <option value="<?= $iface ?>"><?= $iface ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    </div>

    <div id="help-iface-type" style="display:none">
        <p><strong>Type</strong>: Single interface or a set of interfaces.</p>
    </div>
    <div id="help-iface-name" style="display:none">
        <p><strong>Name</strong>: Unique identifier for this interface set.</p>
    </div>
    <div id="help-iface-description" style="display:none">
        <p><strong>Description</strong>: Optional human-readable description.</p>
    </div>
    <div id="help-iface-tags" style="display:none">
        <p><strong>Tags</strong>: Space or comma-separated tags for filtering.</p>
    </div>
    <div id="help-iface-value-single" style="display:none">
        <p><strong>Interface</strong>: Select a single interface value.</p>
    </div>
    <div id="help-iface-value-set" style="display:none">
        <p><strong>Interfaces</strong>: Choose multiple interfaces for this set.</p>
    </div>

    <div class="std-flex-row">
        <button type="submit" class="std-btn">Save</button>
        <button type="button" class="std-btn cancel-edit-btn sets-hidden">Cancel</button>
    </div>
</form>

<hr>
<?php if ($mode === 'mgmt'): ?>
<h3>Existing Interface Sets</h3>
<?php endif; ?>
<?php if ($mode === 'mgmt' || $mode === 'picker'): ?>
<div class="std-flex-row filters-row">
    <label>Filter
        <input type="text" id="iface-filter" class="set-filter-input" placeholder="Filter by name, value or tags">
    </label>
    <label>Filter Type
        <select id="iface-filter-type" name="filter_type" class="std-select">
            <option value="">All</option>
            <option value="single">Single</option>
            <option value="set">Set</option>
        </select>
    </label>
</div>
<?php endif; ?>
<table class="std-table" id="iface-set-table">
    <thead>
        <tr>
            <?php if ($mode === 'picker'): ?><th>Select</th><?php endif; ?>
            <th>Name</th>
            <th>Type</th>
            <th>Interfaces</th>
            <th>Description</th>
            <th>Tags</th>
            <th>Refs</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($interfaces_sets as $is): ?>
            <tr>
                <?php if ($mode === 'picker'): ?>
                <td>
                    <input type="checkbox" class="js-set-pick-row"
                        value="<?= $is['id'] ?? '' ?>"
                        data-name="<?= $is['name'] ?? '' ?>">
                </td>
                <?php endif; ?>
                <td class="col-name"><?= $is['name'] ?? '' ?></td>
                <td class="col-type"><?= $is['type'] ?? '' ?></td>
                <td class="col-value"><?= $is['value_display'] ?? '' ?></td>
                <td class="col-description"><?= $is['description'] ?? '' ?></td>
                <td class="tags-cell"><?= $is['tags_html'] ?? '' ?></td>
                <td class="col-refs"><?= $is['refs_count'] ?? 0 ?></td>
                <td>
                    <button class="std-btn std-btn-edit"
                        data-id="<?= $is['id'] ?? '' ?>"
                        aria-label="Edit" title="Edit"></button>
                    <?php if (($is['refs_count'] ?? 0) == 0): ?>
                        <button class="std-btn std-btn-delete"
                            data-id="<?= $is['id'] ?? '' ?>"
                            aria-label="Delete" title="Delete"></button>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php if ($mode === 'picker'): ?>
<div class="js-set-picker-actions sets-hidden">
    <button type="button" class="std-btn js-set-picker-confirm">Use selected</button>
</div>
<?php endif; ?>
