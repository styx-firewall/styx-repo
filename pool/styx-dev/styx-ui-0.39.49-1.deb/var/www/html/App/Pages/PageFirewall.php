<?php
/**
 *
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
*/
namespace App\Pages;

use App\Core\AppContext;
use App\Core\Config;
use App\Services\Filter;
use App\Controllers\Request\FirewallRequestController;
use App\Controllers\Request\NatRequestController;
use App\Pages\Fmt\FwRulesLocalFormatter;
use App\Pages\Fmt\FwLogsLocalFormatter;
use App\Pages\Fmt\FwLogsFirewallFormatter;
use App\Pages\Fmt\FwLogsCtFormatter;
use App\Pages\Fmt\FwRulesForwardFormatter;
use App\Pages\Fmt\NatFormatter;
use App\Services\AuthService;
use App\Helpers\RoleHelper;


class PageFirewall
{
    /**
     *
     * @param AppContext $ctx
     * @return array<string, mixed>
     */
    public static function get(AppContext $ctx): array
    {
        $page = [];
        $cfg = $ctx->get(Config::class);

        $sections_array = [
            'fw-rules-forward',
            'fw-rules-local',
            'fw-rules-mgmt-local',
            'fw-rules-mgmt-forward',
            'fw-logs-firewall',
            'fw-logs-ct',
            'fw-mgmt-sets',
            'fw-nat',
        ];
        $section = Filter::getString('section');
        $modify = (bool) Filter::getInt('modify');
        $create = (bool) Filter::getInt('create');
        $bypass_filter_raw = Filter::getInt('bypass_filter');
        $bypass_filter = $bypass_filter_raw !== null ? (bool) $bypass_filter_raw : true;

        if (empty($section) || !in_array($section, $sections_array)) {
            $section = 'fw-rules-forward';
        }

        $fmt_data = [];

        // Add necessary scripts based on the section
        if ($section === 'fw-nat') {
            $page['web_main']['scriptlink'][] = '/scripts/core/api-client.js';
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/firewall/fw-nat.js'];
        } elseif ($section === 'fw-rules-mgmt-forward' || $section === 'fw-rules-mgmt-local') {
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/sets-mgmt-core.js'];
            $page['web_main']['footer_script'][] = ['src' => '/scripts/objects/labels-mgmt.js'];
            $page['web_main']['footer_script'][] = ['src' =>  '/scripts/firewall/firewall-mgmt-rules.js'];
        } elseif ($section === 'fw-logs-firewall') {
            $page['web_main']['scriptlink'][] = '/scripts/core/state-storage.js';
            $page['web_main']['footer_script'][] = ['src' => '/scripts/firewall/fw-logs-firewall.js'];
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/logs/logTable.js'];
        } elseif ($section === 'fw-logs-ct') {
            $page['web_main']['scriptlink'][] = '/scripts/core/state-storage.js';
            $page['web_main']['footer_script'][] = ['src' => '/scripts/firewall/fw-logs-ct.js'];
            $page['web_main']['scriptlink'][] = ['src' =>  '/scripts/logs/logTable.js'];
        } elseif ($section === 'fw-rules-local' || $section === 'fw-rules-forward') {
            $page['web_main']['scriptlink'][] = '/scripts/core/state-storage.js';
            $page['web_main']['scriptlink'][] = '/scripts/core/dynamic-table.js';
            $page['web_main']['scriptlink'][] = '/scripts/core/dynamic-draggable-table.js';
            $page['web_main']['footer_script'][] = ['src' => '/scripts/firewall/fw-rules.js'];
        }

        // Request and Format data for presentation in the template
        if ($section === 'fw-logs-firewall') {
            // Prepare presentation keys for unified firewall logs (tabs)
            $fmt_data = FwLogsFirewallFormatter::format($fmt_data);
        } elseif ($section === 'fw-logs-ct') {
            // Prepare presentation keys for conntrack flow logs
            $fmt_data = FwLogsCtFormatter::format($fmt_data);
        } elseif ($section === 'fw-rules-forward') {
            $fwController = new FirewallRequestController($ctx);
            $filters = $bypass_filter ? ['conntrack_bypass' => 0, 'antilockout' => 0, 'drop_invalid' => 0] : [];
            $response = $fwController->getFirewallRules(
                ['table' => ['filter'], 'chain' => ['forward']], $filters
            );
            $fmt_data['rules'] = ($response['status'] ?? '') === 'success' ? $response['result'] : [];
            // Format rules for presentation (moved from template)
            if (is_array($fmt_data)) {
                $fmt_data = FwRulesForwardFormatter::format($fmt_data);
            }
        } elseif ($section === 'fw-rules-local') {
            $fwController = new FirewallRequestController($ctx);
            $filters = $bypass_filter ? ['conntrack_bypass' => 0, 'antilockout' => 0, 'drop_invalid' => 0, 'loopback_accept' => 0] : [];

            $response = $fwController->getFirewallRules(
                ['table' => ['filter'], 'chain' => ['local']], $filters
            );
            $fmt_data['rules'] = ($response['status'] ?? '') === 'success' ? $response['result'] : [];
            // Prepare presentation-ready table data for the template
            if (is_array($fmt_data)) {
                $fmt_data = FwRulesLocalFormatter::format($fmt_data);
            }
        } elseif (
            $create &&
            ($section === 'fw-rules-mgmt-forward' || $section === 'fw-rules-mgmt-local')
        ) {
            $fwController = new FirewallRequestController($ctx);
            $response = $fwController->getCreateRuleFormData();

            $fmt_data['addresses'] = [];
            $fmt_data['ports'] = [];
            $fmt_data['ifaces_sets'] = [];

            if (isset($response['status']) && $response['status'] === 'success') {
                $result = $response['result'];
                $fmt_data['addresses'] = $result['addresses'] ?? [];
                $fmt_data['ports'] = $result['ports'] ?? [];
                $fmt_data['ifaces_sets'] = $result['ifaces_sets'] ?? [];
            }
        } elseif (
            $modify &&
            ($section === 'fw-rules-mgmt-forward' || $section === 'fw-rules-mgmt-local')
        ) {
            $rule_id = Filter::getString('id');
            $fwController = new FirewallRequestController($ctx);
            $response = $fwController->getEditRuleFormData($rule_id);

            $fmt_data['rule'] = [];
            $fmt_data['addresses'] = [];
            $fmt_data['ports'] = [];
            $fmt_data['ifaces_sets'] = [];

            if (isset($response['status']) && $response['status'] === 'error') {
                $fmt_data['error'] = $response['response_msg'] ?? 'Unknown error';
            } elseif (isset($response['status']) && $response['status'] === 'success') {
                $result = $response['result'];
                $fmt_data['rule'] = $result['rule'] ?? [];
                $fmt_data['addresses'] = $result['addresses'] ?? [];
                $fmt_data['ports'] = $result['ports'] ?? [];
                $fmt_data['ifaces_sets'] = $result['ifaces_sets'] ?? [];
            }
        } elseif ($section === 'fw-nat') {
            $natController = new NatRequestController($ctx);
            $natResp = $natController->getNatPageData();
            if (($natResp['status'] ?? '') === 'success') {
                $fmt_data['rules']       = $natResp['result']['nftables'];
                $fmt_data['addresses']   = $natResp['result']['addresses'];
                $fmt_data['ports']       = $natResp['result']['ports'];
                $fmt_data['ifaces_sets'] = $natResp['result']['ifaces_sets'];
            } else {
                $fmt_data['rules']       = [];
                $fmt_data['addresses']   = [];
                $fmt_data['ports']       = [];
                $fmt_data['ifaces_sets'] = [];
            }
            $fmt_data = NatFormatter::format($fmt_data);
        } else {
            $fmt_data['rules'] = [];
        }

        $fmt_data['create'] = $create ? true : false;
        $fmt_data['modify'] = $modify ? true : false;
        $fmt_data['bypass_filter'] = $bypass_filter;
        $fmt_data['section'] = $section;

        $auth = $ctx->get(AuthService::class);
        $fmt_data['can_create'] = RoleHelper::hasCapability(
            $auth->getCapabilities(), 'firewall:write'
        );

        $page['page'] = $section;
        $page['page_data'] = $fmt_data;
        $page['load_tpl'][] = PageHead::get($ctx);
        $page['load_tpl'][] = [
            'file' => 'sidebar',
            'tpl_data' => ['features' => $cfg->get('features', [])],
            'place' => 'sidebar'
        ];

        return $page;
    }
}
