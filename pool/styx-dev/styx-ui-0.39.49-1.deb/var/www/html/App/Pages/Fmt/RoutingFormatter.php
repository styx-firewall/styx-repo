<?php
/**
 * @author STYX FLF
 * @copyright Copyright All Right Reserved @ 2024 - 2026 StyxFLF
 */
namespace App\Pages\Fmt;

use App\Helpers\RoleHelper;

class RoutingFormatter
{
    /**
     * Prepare routing page data for template consumption.
     *
     * @param string $section
     * @param array<string,mixed> $fmt_data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    public static function format(string $section, array $fmt_data, array $userCaps = []): array
    {
        if ($section === 'routing-bgp') {
            return self::formatBgp($fmt_data, $userCaps);
        }
        if ($section === 'routing-ospf') {
            return self::formatOspf($fmt_data, $userCaps);
        }
        if ($section === 'routing-overview') {
            return self::formatOverview($fmt_data);
        }
        if ($section === 'routing-igmp-proxy') {
            return self::formatIgmpProxy($fmt_data);
        }
        if ($section === 'routing-bfd') {
            return self::formatBfd($fmt_data);
        }
        if ($section === 'routing-frr') {
            return self::formatFrr($fmt_data);
        }
        if ($section === 'routing-policies') {
            return self::formatPolicies($fmt_data, $userCaps);
        }
        if ($section === 'routing-frr-static') {
            return self::formatFrrStatic($fmt_data, $userCaps);
        }
        if ($section === 'routing-vrrp') {
            return self::formatVrrp($fmt_data, $userCaps);
        }
        if ($section === 'routing-zebra') {
            return self::formatZebra($fmt_data, $userCaps);
        }
        if ($section === 'routing-evpn') {
            return self::formatEvpn($fmt_data, $userCaps);
        }

        return $fmt_data;
    }

    /**
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    private static function formatBgp(array $data, array $userCaps): array
    {
        $canWrite  = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_save']   = $canWrite;
        $data['can_add']    = $canWrite;
        // Normalize global BGP config defaults so templates don't need inline logic
        $bgp = $data['bgp_config'] ?? [];
        $bgp['keepalive'] = isset($bgp['keepalive']) ? (int)$bgp['keepalive'] : 60;
        $bgp['hold_time'] = isset($bgp['hold_time']) ? (int)$bgp['hold_time'] : 180;
        $bgp['default_local_pref'] = isset($bgp['default_local_pref']) ? (int)$bgp['default_local_pref'] : 100;
        $bgp['enabled'] = !empty($bgp['enabled']);
        $bgp['log_neighbor_changes'] = !empty($bgp['log_neighbor_changes']);
        $bgp['always_compare_med'] = !empty($bgp['always_compare_med']);
        $bgp['graceful_restart'] = !empty($bgp['graceful_restart']);
        // preserve any existing display entries (router_as_display, router_id_display)
        $bgp['redistribute'] = $bgp['redistribute'] ?? [];
        $data['bgp_config'] = $bgp;

        $neighbors = $data['neighbors'] ?? [];
        foreach ($neighbors as &$n) {
            // Display-only classification of the real FRR status values
            // (state FSM + peerState condition). No value is fabricated.
            $n['state_bg_class']      = self::bgpStateBgClass($n['peer_status']['state'] ?? null);
            $n['peer_state_bg_class'] = self::bgpPeerStateBgClass($n['peer_status']['peerState'] ?? null);
            // ensure description exists
            $n['description'] = $n['description'] ?? '';
            $n['can_delete']  = $canDelete;
        }
        unset($n);

        $data['neighbors'] = $neighbors;

        $networks = $data['networks'] ?? [];
        foreach ($networks as &$nw) {
            $nw['can_delete'] = $canDelete;
        }
        unset($nw);
        $data['networks'] = $networks;

        $peerGroups = $data['peer_groups'] ?? [];
        foreach ($peerGroups as &$pg) {
            $pg['can_delete'] = $canDelete;
        }
        unset($pg);
        $data['peer_groups'] = $peerGroups;

        return $data;
    }

    /**
     * Background badge variant for the BGP FSM state.
     *
     * Display-only classification of the real FRR state value. Unknown values
     * map to 'warning' (amber) so a state we don't know is never shown green.
     */
    private static function bgpStateBgClass(?string $state): string
    {
        switch ($state) {
            case 'Established':
                return 'enabled';
            case 'Connect':
            case 'Active':
            case 'OpenSent':
            case 'OpenConfirm':
                return 'warning';
            case 'Idle':
            case 'Stopped':
                return 'danger';
            default:
                return 'warning';
        }
    }

    /**
     * Background badge variant for the FRR peerState condition.
     *
     * Display-only classification of the real peerState value. Unknown values
     * map to 'warning' so a condition we don't know is never shown green.
     */
    private static function bgpPeerStateBgClass(?string $peerState): string
    {
        switch ($peerState) {
            case 'OK':
                return 'enabled';
            case 'Passive':
            case 'NSF Wait':
                return 'warning';
            case 'Policy':
            case 'Shutdown':
            case 'Prefix Overflow':
                return 'danger';
            default:
                return 'warning';
        }
    }

    /**
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    private static function formatOspf(array $data, array $userCaps): array
    {
        $canWrite  = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_save']   = $canWrite;
        $data['can_add']    = $canWrite;
        // Normalize global OSPF config so templates can read prepared values
        $ospf = $data['ospf_config'] ?? [];
        $ospf['reference_bandwidth'] = isset($ospf['reference_bandwidth']) ? (int)$ospf['reference_bandwidth'] : 100;
        $ospf['enabled'] = !empty($ospf['enabled']);
        $ospf['log_adjacency_changes'] = !empty($ospf['log_adjacency_changes']);
        $ospf['passive_interface_default'] = !empty($ospf['passive_interface_default']);
        $data['ospf_config'] = $ospf;

        $areas = $data['areas'] ?? [];
        foreach ($areas as &$area) {
            $area['can_delete'] = $canDelete;
        }
        unset($area);
        $data['areas'] = $areas;

        $interfaces = $data['interfaces'] ?? [];
        foreach ($interfaces as &$iface) {
            $iface['can_delete'] = $canDelete;
            $iface['cost_display']  = isset($iface['cost']) && $iface['cost'] !== null
                ? (int)$iface['cost']
                : '-';
            $iface['passive_label'] = !empty($iface['passive']) ? 'Yes' : 'No';
            $iface['hello_interval'] = isset($iface['hello_interval']) ? (int)$iface['hello_interval'] : 10;
            $iface['dead_interval']  = isset($iface['dead_interval']) ? (int)$iface['dead_interval'] : 40;
            $iface['priority']       = isset($iface['priority']) ? (int)$iface['priority'] : 1;
            $iface['poll_interval']  = isset($iface['poll_interval']) ? (int)$iface['poll_interval'] : 120;
        }
        unset($iface);

        $data['interfaces'] = $interfaces;

        // OSPFv3 normalization
        $ospf6 = $data['ospf6_config'] ?? [];
        $ospf6['reference_bandwidth'] = isset($ospf6['reference_bandwidth']) ? (int)$ospf6['reference_bandwidth'] : 100;
        $ospf6['enabled'] = !empty($ospf6['enabled']);
        $ospf6['log_adjacency_changes'] = !empty($ospf6['log_adjacency_changes']);
        $ospf6['stub_router_administrative'] = !empty($ospf6['stub_router_administrative']);
        $data['ospf6_config'] = $ospf6;

        $areas6 = $data['areas6'] ?? [];
        foreach ($areas6 as &$a) { $a['can_delete'] = $canDelete; }
        unset($a);
        $data['areas6'] = $areas6;

        $ifaces6 = $data['interfaces6'] ?? [];
        foreach ($ifaces6 as &$i) {
            $i['can_delete'] = $canDelete;
            $i['cost_display'] = isset($i['cost']) && $i['cost'] !== null ? (int)$i['cost'] : '-';
            $i['passive_label'] = !empty($i['passive']) ? 'Yes' : 'No';
            $i['hello_interval'] = isset($i['hello_interval']) ? (int)$i['hello_interval'] : 10;
            $i['dead_interval'] = isset($i['dead_interval']) ? (int)$i['dead_interval'] : 40;
            $i['priority'] = isset($i['priority']) ? (int)$i['priority'] : 1;
        }
        unset($i);
        $data['interfaces6'] = $ifaces6;

        // Live neighbors (daemon-provided): derive a display-only background class.
        $neighbors = $data['neighbors'] ?? [];
        foreach ($neighbors as &$n) {
            $n['state_bg_class'] = self::ospfStateBgClass($n['nbrState'] ?? null);
        }
        unset($n);
        $data['neighbors'] = $neighbors;

        $neighbors6 = $data['neighbors6'] ?? [];
        foreach ($neighbors6 as &$n) {
            $n['state_bg_class'] = self::ospfStateBgClass($n['state'] ?? null);
        }
        unset($n);
        $data['neighbors6'] = $neighbors6;

        return $data;
    }

    /**
     * Background badge variant for an OSPF neighbor state.
     *
     * Display-only classification of the real FRR state value (RFC 2328). The
     * state is the token before "/" (e.g. ``nbrState`` may be ``"Full/-"``).
     * Unknown values map to 'warning' so a state we don't know is never green.
     */
    private static function ospfStateBgClass(?string $state): string
    {
        $s = strtolower((string)($state ?? ''));
        $s = explode('/', $s, 2)[0];
        switch ($s) {
            case 'full':
                return 'enabled';
            case '2-way':
            case 'attempt':
            case 'exstart':
            case 'exchange':
            case 'loading':
                return 'warning';
            case 'down':
            case 'init':
                return 'danger';
            default:
                return 'warning';
        }
    }

    /**
     * Splits interfaces into upstream / downstream arrays.
     *
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    private static function formatIgmpProxy(array $data): array
    {
        $interfaces = $data['interfaces'] ?? [];

        // Normalize IGMP proxy global config
        $igmp = $data['igmp_config'] ?? [];
        $igmp['enabled'] = !empty($igmp['enabled']);
        $data['igmp_config'] = $igmp;

        $data['upstream']   = array_values(
            array_filter($interfaces, fn($i) => ($i['role'] ?? '') === 'upstream')
        );
        $data['downstream'] = array_values(
            array_filter($interfaces, fn($i) => ($i['role'] ?? '') === 'downstream')
        );

        return $data;
    }

    /**
     * Normalize BFD session fields for templates.
     *
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    private static function formatBfd(array $data): array
    {
        $canWrite  = true; // BFD profiles inherit routing:write via page guard
        $canDelete = true;
        $data['can_add']  = $canWrite;
        $data['can_save'] = $canWrite;

        $sessions = $data['sessions'] ?? [];

        foreach ($sessions as &$s) {
            $s['tx_interval'] = isset($s['tx_interval']) ? (int)$s['tx_interval'] : 0;
            $s['rx_interval'] = isset($s['rx_interval']) ? (int)$s['rx_interval'] : 0;
            $s['multiplier']   = isset($s['multiplier']) ? (int)$s['multiplier'] : 0;
            $s['status']       = $s['status'] ?? 'down';
            $s['state_class']  = $s['status'] === 'up' ? 'enabled' : 'disabled';
            $s['uptime']       = $s['uptime'] ?? '-';
        }
        unset($s);

        $data['sessions'] = $sessions;

        $profiles = $data['bfd_profiles'] ?? [];
        foreach ($profiles as &$p) {
            $p['can_delete'] = $canDelete;
            $p['detect_multiplier'] = isset($p['detect_multiplier']) ? (int)$p['detect_multiplier'] : 3;
            $p['receive_interval']  = isset($p['receive_interval']) ? (int)$p['receive_interval'] : 300;
            $p['transmit_interval'] = isset($p['transmit_interval']) ? (int)$p['transmit_interval'] : 300;
            $p['echo_mode_label']   = !empty($p['echo_mode']) ? 'Yes' : 'No';
            $p['passive_label']     = !empty($p['passive_mode']) ? 'Yes' : 'No';
        }
        unset($p);
        $data['bfd_profiles'] = $profiles;

        return $data;
    }

    /**
     * Normalize FRR policy objects for template consumption.
     *
     * @param array<string,mixed> $data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    private static function formatPolicies(array $data, array $userCaps): array
    {
        $canWrite  = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_add']    = $canWrite;
        $data['can_delete'] = $canDelete;

        $data['prefix_lists']    = self::normalizePolicyList($data['prefix_lists'] ?? [], $canDelete);
        $data['route_maps']      = self::normalizePolicyList($data['route_maps'] ?? [], $canDelete);
        $data['as_path_lists']   = self::normalizePolicyList($data['as_path_lists'] ?? [], $canDelete);
        $data['community_lists'] = self::normalizePolicyList($data['community_lists'] ?? [], $canDelete);

        return $data;
    }

    /**
     * Guard: ensure the value is an array of arrays before annotating with can_delete.
     *
     * @param mixed $list
     * @param bool $canDelete
     * @return array<int, array<string, mixed>>
     */
    private static function normalizePolicyList($list, bool $canDelete): array
    {
        if (!is_array($list)) {
            return [];
        }

        $out = [];
        foreach ($list as $item) {
            if (!is_array($item)) {
                continue;
            }
            $item['can_delete'] = $canDelete;
            $out[] = $item;
        }

        return $out;
    }

    /**
     * Normalize daemon display names for the overview page.
     *
     * Adds `display_daemon_name` to each daemon entry.
     *
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    private static function formatOverview(array $data): array
    {
        // Normalize frr sub-object
        $data['frr'] = $data['frr'] ?? ['enabled' => false, 'daemons' => []];
        $data['frr']['enabled'] = !empty($data['frr']['enabled']);

        // Normalize igmp_proxy sub-object
        $data['igmp_proxy'] = $data['igmp_proxy'] ?? ['enabled' => false, 'daemon' => null];
        $data['igmp_proxy']['enabled'] = !empty($data['igmp_proxy']['enabled']);

        // Cast top-level counters
        $data['num_tables']       = isset($data['num_tables']) ? (int)$data['num_tables'] : 0;
        $data['num_policy_rules'] = isset($data['num_policy_rules']) ? (int)$data['num_policy_rules'] : 0;

        // Normalize route_summary.ipv4 / ipv6
        $data['route_summary'] = $data['route_summary'] ?? [];
        foreach (['ipv4', 'ipv6'] as $family) {
            $fam = $data['route_summary'][$family] ?? [];
            $fam['total']       = isset($fam['total']) ? (int)$fam['total'] : 0;
            $fam['by_protocol'] = self::intMap($fam['by_protocol'] ?? []);
            $fam['by_scope']    = self::intMap($fam['by_scope'] ?? []);
            $fam['by_table']    = self::intMap($fam['by_table'] ?? []);
            $data['route_summary'][$family] = $fam;
        }

        // Normalize frr_routes (from backend fr_routes)
        $data['frr_routes'] = $data['frr_routes'] ?? [];
        foreach (['ipv4', 'ipv6'] as $family) {
            $fr = $data['frr_routes'][$family] ?? [];
            $data['frr_routes'][$family] = self::intMap($fr, ['bgp','ospf','rip']);
        }

        // Default gateways
        $data['default_gateway_v4'] = $data['default_gateway_v4'] ?? null;
        $data['default_gateway_v6'] = $data['default_gateway_v6'] ?? null;

        // FRR daemon display names
        $labels = [
            'bgpd'      => 'BGP daemon',
            'ospfd'     => 'OSPF daemon',
            'ripd'      => 'RIP daemon',
            'bfdd'      => 'BFD daemon',
        ];
        $daemons = $data['frr']['daemons'] ?? [];
        foreach ($daemons as &$d) {
            $name = $d['name'] ?? '';
            if (isset($d['display'])) {
                $d['display_daemon_name'] = $d['display'];
            } elseif (isset($labels[$name])) {
                $d['display_daemon_name'] = $labels[$name];
            } else {
                $d['display_daemon_name'] = $name !== '' ? ucfirst($name) : '';
            }
        }
        unset($d);
        $data['frr']['daemons'] = $daemons;

        // IGMP daemon display name
        $igmpDaemon = $data['igmp_proxy']['daemon'] ?? null;
        if (is_array($igmpDaemon)) {
            $name = $igmpDaemon['name'] ?? '';
            $igmpDaemon['display_daemon_name'] = $igmpDaemon['display'] ?? 'IGMP Proxy';
            $data['igmp_proxy']['daemon'] = $igmpDaemon;
        }

        return $data;
    }

    /**
     * Cast keys of an associative array to int, optionally ensuring a fixed set of keys exist.
     *
     * @param array<string,mixed> $map
     * @param string[] $defaultKeys
     * @return array<string,int>
     */
    private static function intMap(array $map, array $defaultKeys = []): array
    {
        foreach ($defaultKeys as $k) {
            if (!array_key_exists($k, $map)) {
                $map[$k] = 0;
            }
        }
        $out = [];
        foreach ($map as $k => $v) {
            $out[$k] = (int)$v;
        }
        return $out;
    }

    /**
     * @param array<string,mixed> $data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    private static function formatFrrStatic(array $data, array $userCaps): array
    {
        $canWrite  = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_save']   = $canWrite;
        $data['can_add']    = $canWrite;

        $routes = $data['frr_static_routes'] ?? [];
        foreach ($routes as &$r) {
            $r['can_delete'] = $canDelete;
            $r['type'] = $r['type'] ?? 'unicast';
        }
        unset($r);
        $data['frr_static_routes'] = $routes;

        return $data;
    }

    /**
     * @param array<string,mixed> $data
     * @param string[] $userCaps
     * @return array<string,mixed>
     */
    private static function formatVrrp(array $data, array $userCaps): array
    {
        $canWrite  = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_save']   = $canWrite;
        $data['can_add']    = $canWrite;

        $instances = $data['vrrp_instances'] ?? [];
        foreach ($instances as &$inst) {
            $inst['can_delete'] = $canDelete;
            // Display-only classification of the live v4/v6 FSM status, only
            // for address families that are actually active (have VIPs).
            $st = $inst['status'] ?? null;
            foreach (['v4', 'v6'] as $af) {
                $inst["{$af}_status"] = null;
                $inst["{$af}_bg_class"] = null;
                if ($st && isset($st[$af]['status']) && !empty($st[$af]['addresses'])) {
                    $inst["{$af}_status"] = $st[$af]['status'];
                    $inst["{$af}_bg_class"] = self::vrrpStateBgClass($st[$af]['status']);
                }
            }
        }
        unset($inst);
        $data['vrrp_instances'] = $instances;

        return $data;
    }

    /**
     * Background badge variant for a VRRP FSM state.
     *
     * Display-only classification of the real vrrpd state. Unknown values map
     * to 'warning' so a state we don't know is never shown green.
     */
    private static function vrrpStateBgClass(?string $state): string
    {
        switch (strtolower((string)($state ?? ''))) {
            case 'master':
                return 'enabled';
            case 'backup':
                return 'warning';
            case 'initialize':
                return 'danger';
            default:
                return 'warning';
        }
    }

    /** @param array<string,mixed> $data */
    private static function formatFrr(array $data): array
    {
        $overview = $data['frr_overview'] ?? [];

        $labels = [
            'bgpd'      => 'BGP daemon',
            'ospfd'     => 'OSPF daemon',
            'ripd'      => 'RIP daemon',
            'bfdd'      => 'BFD daemon',
        ];
        $daemons = $overview['daemons'] ?? [];
        foreach ($daemons as &$d) {
            $name = $d['name'] ?? '';
            if (isset($d['display'])) {
                $d['display_name'] = $d['display'];
            } elseif (isset($labels[$name])) {
                $d['display_name'] = $labels[$name];
            } else {
                $d['display_name'] = $name !== '' ? ucfirst($name) : '';
            }
        }
        unset($d);

        $routes = $overview['routes'] ?? [];
        foreach (['ipv4', 'ipv6'] as $family) {
            if (isset($routes[$family])) {
                $routes[$family]['_label'] = strtoupper($family);
            }
        }

        $data['frr_overview'] = [
            'enabled' => !empty($overview['enabled']),
            'daemons' => $daemons,
            'routes'  => $routes,
        ];
        return $data;
    }

    /** @param array<string,mixed> $data @param string[] $userCaps */
    private static function formatZebra(array $data, array $userCaps): array
    {
        $data['can_save'] = RoleHelper::hasCapability($userCaps, 'routing:write');
        $data['protocol_rm_list'] = [
            'any', 'babel', 'bgp', 'eigrp', 'isis', 'nhrp',
            'ospf', 'ospf6', 'rip', 'ripng', 'static', 'table',
        ];
        return $data;
    }

    /** @param array<string,mixed> $data @param string[] $userCaps */
    private static function formatEvpn(array $data, array $userCaps): array
    {
        $canWrite = RoleHelper::hasCapability($userCaps, 'routing:write');
        $canDelete = RoleHelper::hasCapability($userCaps, 'routing:delete');
        $data['can_save'] = $canWrite;
        $data['can_add'] = $canWrite;
        $bindings = $data['vrf_bindings'] ?? [];
        foreach ($bindings as &$b) { $b['can_delete'] = $canDelete; }
        unset($b);
        $data['vrf_bindings'] = $bindings;
        return $data;
    }
}
