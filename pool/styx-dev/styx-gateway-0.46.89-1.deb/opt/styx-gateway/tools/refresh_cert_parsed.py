import sys
import unittest

# Ensure project root is on sys.path when running this test from any cwd
sys.path.insert(0, "/opt/styx-gateway")

from core.app_context import AppContext
from services.logger import Logger
from stores.datastore import Datastore
from services.certificates_service import CertificatesService


class TestRefreshParsedMetadata(unittest.TestCase):
    def test_refresh_parsed_metadata_runs(self):
        ctx = AppContext("/opt/styx-gateway")
        logger = Logger()
        ctx.set_logger(logger)

        ds = Datastore(logger)
        ctx.set_datastore(ds)

        svc = CertificatesService(ctx)
        certs = svc.load_certificates()
        # Should execute without raising; returns a bool
        changed = svc._cache.ensure_all(certs, save_fn=lambda c: svc._save_certificates(c))
        self.assertIsInstance(changed, bool)

        # Force cryptographic matching for each entry by passing a
        # pre-loaded certs_list (replaces the old force_crypto_match=True).
        for entry in certs:
            # Invalidate parsed flag to force re-parse
            entry.pop("_parsed", None)
            entry.pop("_parsed_metadata", None)
            result = svc._cache.ensure_parsed(entry, certs_list=certs)
            self.assertIsInstance(result, bool)

        # Verify that parsed metadata is populated on all entries
        for entry in certs:
            self.assertTrue(entry.get("_parsed"), f"Entry {entry.get('id')} was not parsed")
            self.assertEqual(
                entry.get("_parsed_version"),
                svc._cache.PARSED_VERSION,
                f"Entry {entry.get('id')} has wrong parsed version",
            )
            self.assertEqual(
                entry.get("_parsed_hash"),
                entry.get("hash_ds"),
                f"Entry {entry.get('id')} parsed hash mismatch",
            )
            meta = entry.get("_parsed_metadata", {})
            self.assertIn("format", meta)
            self.assertIn("matches_usages", meta)
            self.assertIn("status", meta)


if __name__ == "__main__":
    unittest.main()
