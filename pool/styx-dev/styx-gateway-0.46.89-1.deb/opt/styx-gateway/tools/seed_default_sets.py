#!/usr/bin/env python3
"""Seed default sets from files/default_sets.json without requiring a cold boot.

Seeds address, port, domain and label sets from the default-sets catalog
into the gateway datastore. Intended for development setups and for
refreshing the defaults on an existing installation (e.g. after the catalog
changes) without wiping the datastore for a cold boot.

Usage:
  python3 tools/seed_default_sets.py [--catalog PATH] [--commit] [--update] [--skip-interfaces]

Options:
  --catalog PATH      Catalog JSON to seed. Defaults to GW_ROOT_DIR/files/
                      default_sets.json, which works in both source and
                      PyInstaller installs.
  --commit            Write the set keys to /etc/styx/startup-config.json
                      (running-config is updated as well). The gateway copies
                      startup-config over running-config at boot, so run this
                      with the gateway stopped; the new values become active
                      at the next start. Without it the script is a dry-run
                      and only writes ./data/running.debug.json.
  --update            Update sets whose name already exists in the datastore
                      (default: skip them and leave them untouched). Existing
                      entries are updated in place: id is kept and refs are
                      preserved. Per-entry failures are logged as warnings
                      and never abort the run.
  --skip-interfaces   Do not seed interface sets collected from the system.

Examples:
  python3 tools/seed_default_sets.py                     # dry-run, skip existing sets
  python3 tools/seed_default_sets.py --update            # dry-run, overwrite existing sets
  python3 tools/seed_default_sets.py --update --commit   # apply, active at next boot

Notes:
  - Commit mode asks for confirmation before writing; the gateway must be
    stopped while running it and the new sets become active at the next start.
  - The gateway does not reload configuration files while running: a live
    gateway keeps its own in-memory copy and will overwrite the files on its
    next save. Run the script with the gateway stopped.
  - Only the set-related datastore keys are written; the rest of the
    configuration files is left untouched.
  - Sets present in the datastore but no longer in the catalog are not
    removed; delete them via the sets-mgmt API.
"""

import argparse
import json
import os
import sys

# Ensure project root is on sys.path when run as a script
ROOT = os.path.dirname(os.path.dirname(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from config.styx_config import GW_ROOT_DIR
from constants.datastore_keys import (
    DS_KEY_SET_ADDRESS,
    DS_KEY_SET_DOMAIN,
    DS_KEY_SET_INTERFACE,
    DS_KEY_SET_LABEL,
    DS_KEY_SET_PORT,
)
from core.app_context import AppContext
from services.logger import Logger
from constants.log_level import LogLevel
from stores.datastore import Datastore

from services.sets.address_sets import add_address_set
from services.sets.ports_sets import add_port_set
from services.sets.domain_sets import add_domain_set
from services.sets.interfaces_sets import add_interface_set
from services.sets.label_sets import add_label_set

# Import collector at module level so missing core pieces fail early when
# running the standalone script (makes failures clearly attributable to core).
from utils.interfaces_collector import InterfacesCollector

# Absolute path -- works in both source and PyInstaller modes via GW_ROOT_DIR.
DEFAULT_CATALOG = os.path.join(GW_ROOT_DIR, "files", "default_sets.json")

# Set-related datastore keys written to running-config by the set services.
_SET_DS_KEYS = [DS_KEY_SET_ADDRESS, DS_KEY_SET_PORT, DS_KEY_SET_DOMAIN, DS_KEY_SET_LABEL, DS_KEY_SET_INTERFACE]


def make_ctx(commit: bool) -> AppContext:
    workdir = os.getcwd()
    ctx = AppContext(workdir)
    logger = Logger(min_log_level=int(LogLevel.INFO), force_file_log=False)
    ctx.set_logger(logger)
    # When commit=True, use the project's default Datastore paths (system
    # `startup-config.json` / `running-config.json`) so the script writes to
    # the real configuration files. In dry-run mode use local debug files
    # under ./data/.
    if commit:
        ds = Datastore(logger)
    else:
        # In dry-run mode create a Datastore that writes to local debug files
        # (store names must match the ones replace_data/get_data actually use).
        data_dir = os.path.join(workdir, "data")
        os.makedirs(data_dir, exist_ok=True)
        files = {
            "running-config": os.path.join(data_dir, "running.debug.json"),
        }
        ds = Datastore(logger, files=files)
    ctx.set_datastore(ds)
    return ctx


def load_catalog(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def _seed_entries(ctx, ds_key, add_fn, entries, stats_key, summary, update):
    """Seed one catalog section (address/port/domain/label).

    Existing names are skipped by default; with update=True they are updated
    in place. Per-entry failures are logged and counted without aborting the
    run.
    """
    logger = ctx.get_logger()
    existing = ctx.get_datastore().get_data(ds_key) or []
    for entry in entries:
        name = entry.get("name")
        data = {k: v for k, v in entry.items() if k != "description"}
        existing_entry = next((e for e in existing if e.get("name") == name), None)
        if existing_entry is not None and not update:
            logger.warning(f"[SEED] {stats_key.capitalize()} set '{name}' already exists in datastore -- skipping.")
            summary[stats_key]["skipped"] += 1
            continue
        if existing_entry is not None:
            # add_*_set matches existing entries by id; reuse the current one
            # so the entry is updated in place instead of duplicated.
            if existing_entry.get("id"):
                data["id"] = existing_entry["id"]
        try:
            sid, err = add_fn(ctx, data)
        except Exception as exc:
            logger.warning(f"[SEED] Exception seeding {stats_key} set '{name}': {exc}")
            summary[stats_key]["fail"] += 1
            continue
        if err:
            logger.warning(f"[SEED] Failed to seed {stats_key} set '{name}': {err}")
            summary[stats_key]["fail"] += 1
        else:
            logger.info(
                f"[SEED] {'Updated' if existing_entry is not None else 'Created'} " f"{stats_key} set '{name}' ({sid})"
            )
            summary[stats_key]["ok"] += 1


def seed_sets(ctx: AppContext, catalog: dict, skip_interfaces: bool = False, update: bool = False) -> dict:
    logger = ctx.get_logger()
    # Track skipped separately from failures so dry-run output is clearer.
    summary = {
        "address": {"ok": 0, "fail": 0, "skipped": 0},
        "port": {"ok": 0, "fail": 0, "skipped": 0},
        "domain": {"ok": 0, "fail": 0, "skipped": 0},
        "label": {"ok": 0, "fail": 0, "skipped": 0},
        "interfaces": {"ok": 0, "fail": 0, "skipped": 0},
    }

    _seed_entries(ctx, DS_KEY_SET_ADDRESS, add_address_set, catalog.get("address", []), "address", summary, update)
    _seed_entries(ctx, DS_KEY_SET_PORT, add_port_set, catalog.get("port", []), "port", summary, update)
    _seed_entries(ctx, DS_KEY_SET_DOMAIN, add_domain_set, catalog.get("domain", []), "domain", summary, update)
    _seed_entries(ctx, DS_KEY_SET_LABEL, add_label_set, catalog.get("label", []), "label", summary, update)

    if not skip_interfaces:
        # Seed interfaces by reading existing system interfaces via the interfaces collector
        try:
            # Use the module-level InterfacesCollector import so module-level
            # import errors are surfaced immediately when running the script.
            phys = InterfacesCollector.get_phy_interfaces()
            virt = InterfacesCollector.get_virtual_interfaces()
            phys_names = [i.get("interface") for i in phys if i.get("interface")]
            virt_names = [i.get("interface") for i in virt if i.get("interface")]
            existing_if_sets = ctx.get_datastore().get_data(DS_KEY_SET_INTERFACE) or []
            if phys_names:
                entry = {"name": "all_physical", "type": "set", "value_set": phys_names}
                if any(e.get("name") == "all_physical" for e in existing_if_sets):
                    logger.warning("[SEED] Interface set name 'all_physical' already exists -- skipping.")
                    summary["interfaces"]["skipped"] += 1
                else:
                    try:
                        sid, err = add_interface_set(ctx, entry)
                    except Exception as exc:
                        logger.warning(f"[SEED] Exception creating interface set all_physical: {exc}")
                        summary["interfaces"]["fail"] += 1
                    else:
                        if err:
                            logger.warning(f"[SEED] Failed to create interface set all_physical: {err}")
                            summary["interfaces"]["fail"] += 1
                        else:
                            logger.info(f"[SEED] Created interface set all_physical ({sid})")
                            summary["interfaces"]["ok"] += 1
            if virt_names:
                entry = {"name": "all_virtual", "type": "set", "value_set": virt_names}
                if any(e.get("name") == "all_virtual" for e in existing_if_sets):
                    logger.warning("[SEED] Interface set name 'all_virtual' already exists -- skipping.")
                    summary["interfaces"]["skipped"] += 1
                else:
                    try:
                        sid, err = add_interface_set(ctx, entry)
                    except Exception as exc:
                        logger.warning(f"[SEED] Exception creating interface set all_virtual: {exc}")
                        summary["interfaces"]["fail"] += 1
                    else:
                        if err:
                            logger.warning(f"[SEED] Failed to create interface set all_virtual: {err}")
                            summary["interfaces"]["fail"] += 1
                        else:
                            logger.info(f"[SEED] Created interface set all_virtual ({sid})")
                            summary["interfaces"]["ok"] += 1
            for name in phys_names + virt_names:
                safe_name = f"if_{name}" if name else None
                if not safe_name:
                    continue
                # Skip if a set with this name already exists in datastore
                if any(e.get("name") == safe_name for e in existing_if_sets):
                    logger.debug(f"[SEED] Interface set {safe_name} already exists -- skipping.")
                    summary["interfaces"]["skipped"] += 1
                    continue
                entry = {"name": safe_name, "type": "single", "value_single": name}
                try:
                    sid, err = add_interface_set(ctx, entry)
                except Exception as exc:
                    logger.debug(f"[SEED] Exception creating single interface set {safe_name}: {exc}")
                    summary["interfaces"]["fail"] += 1
                    continue
                if err:
                    logger.debug(f"[SEED] Failed to create single interface set {safe_name}: {err}")
                    summary["interfaces"]["fail"] += 1
                else:
                    logger.info(f"[SEED] Created single interface set {safe_name} ({sid})")
                    summary["interfaces"]["ok"] += 1
        except Exception as exc:
            logger.warning(f"[SEED] Skipping interface seeding: {exc}")

    return summary


def persist_to_startup(ctx: AppContext) -> None:
    """Copy the seeded set keys from running-config to startup-config.

    The gateway copies startup-config over running-config at boot, so a seed
    left only in running-config would be lost on the next start. Only the
    set-related keys are replaced; the rest of startup-config is untouched.
    """
    datastore = ctx.get_datastore()
    for key in _SET_DS_KEYS:
        data = datastore.get_data(key, store="running-config")
        if data is not None:
            datastore.replace_data(key, data, store="startup-config")


def confirm_commit() -> bool:
    """Ask for confirmation before writing the real datastore files.

    Returns True only on an explicit yes; any other input (or no TTY / EOF)
    aborts.
    """
    print()
    print("WARNING: this will write /etc/styx/startup-config.json and")
    print("running-config.json. The gateway must be stopped while running")
    print("this script; the new sets become active when it starts again.")
    try:
        answer = input("Continue? [y/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("Aborted.")
        return False
    return answer in ("y", "yes")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--catalog", default=DEFAULT_CATALOG, help="Path to default_sets.json")
    p.add_argument("--commit", action="store_true", help="Write to /etc/styx/startup-config.json (active at next boot)")
    p.add_argument("--update", action="store_true", help="Update sets whose name already exists (default: skip them)")
    p.add_argument("--skip-interfaces", action="store_true", help="Do not seed interface sets")
    args = p.parse_args()

    if not os.path.exists(args.catalog):
        print(f"Catalog not found: {args.catalog}")
        sys.exit(2)

    if args.commit and not confirm_commit():
        print("Aborted, nothing was written.")
        return

    ctx = make_ctx(commit=args.commit)
    catalog = load_catalog(args.catalog)

    print("Seeding sets from:", args.catalog)
    if args.commit:
        print("Mode: commit to /etc/styx/startup-config.json (applied at next boot, run with the gateway stopped)")
    else:
        print("Mode: dry-run (writes to ./data/running.debug.json)")
    print("Existing sets:", "update" if args.update else "skip")

    summary = seed_sets(ctx, catalog, skip_interfaces=args.skip_interfaces, update=args.update)

    if args.commit:
        persist_to_startup(ctx)
        print("Set keys copied from running-config to startup-config.")

    print("Summary:")
    for k, v in summary.items():
        parts = [f"ok={v['ok']}"]
        if v.get("skipped", 0):
            parts.append(f"skipped={v['skipped']}")
        parts.append(f"fail={v['fail']}")
        print(f" - {k}: " + " ".join(parts))


if __name__ == "__main__":
    main()
