#!/usr/bin/env python3
"""Remove orphaned datastore refs from a gateway config JSON file (standalone).

Entities in config_interfaces / config_set_* / etc. carry a ``refs`` list of
UUIDs that must resolve to an existing entity.  If an entity is deleted without
its refs being cleaned up, the stale refs stay behind and the startup integrity
check ([INTGRITY_CK], configure/integrity_checks.py) warns about them on every
boot.  This tool prunes exactly those orphaned refs, it never deletes
entities, only removes refs that point to a UUID not present in any known
entity source.

IMPORTANT: this script is fully standalone (stdlib only) so it can be copied
to any gateway, including PyInstaller builds that have no source tree to import
from.  Because of that, the entity-source tables below are a copy of the
ENTITY_SOURCES / REFS_OWNERS constants in configure/integrity_checks.py and the
pool-building logic mirrors its nested-key handling.  Keep them in sync when
changing either side; tests/test_config_iface_refs.py asserts they match.

Intended for running with the gateway STOPPED, against a config file on disk.
The gateway copies startup-config over running-config at boot and keeps its own
in-memory copy while running, so it must not be running while this writes.

Usage:
  python3 cleanup_orphan_refs.py                              # dry-run
  python3 cleanup_orphan_refs.py --path PATH                  # dry-run, other file
  python3 cleanup_orphan_refs.py --commit                     # write startup-config
  python3 cleanup_orphan_refs.py --commit --path PATH         # write other file

Options:
  --path PATH     Config JSON to scan/clean. Defaults to
                  /etc/styx/startup-config.json.
  --commit        Write the cleaned config back. Without it the run is a
                  dry-run: only prints the refs that would be removed.
  --keep-backups  Do not prune old .bak files after a successful commit.
                  (A fresh timestamped .bak of the file is always written
                  before the change.)
"""

import argparse
import json
import os
import shutil
import sys
import time

#
# Datastore key tables. MUST stay in sync with configure/integrity_checks.py.
#

# Keys whose entities are considered valid UUID sources (have an 'id' field).
ENTITY_SOURCES = [
    "routing_config->bgp",
    "nftables",
    "config_interfaces",
    "config_set_address",
    "config_set_ports",
    "config_set_interfaces",
    "config_set_domains",
    "config_set_labels",
    "tc_config",
    "certificates",
    "strongswan_connections",
    "strongswan_global_config",
    "strongswan_pools",
    "dhcp_server",
    "lighttpd_ssl",
    "ssh_config",
    # Routing singletons (config dicts with 'id' field)
    "routing_config->zebra",
    "routing_config->ospf",
    "routing_config->ospf6",
    "routing_config->rip",
    # Routing list entities
    "routing_config->frr_static",
    "routing_config->frr_route_maps",
    "routing_config->ipv4",
    "routing_config->ipv6",
    "routing_config->bgp_networks",
    "routing_rules",
    # FRR policy objects and referenced entities
    "routing_config->bfd_peers",
    "routing_config->bfd_profiles",
    "routing_config->bgp_neighbors",
    "routing_config->bgp_peer_groups",
    "routing_config->bgp_as_path_lists",
    "routing_config->bgp_community_lists",
    "routing_config->frr_prefix_lists",
    "routing_config->ospf_areas",
    "routing_config->ospf_interfaces",
    "routing_config->ospf6_areas",
    "routing_config->ospf6_interfaces",
    "routing_config->rip_networks",
    "routing_config->igmp_interfaces",
    "routing_config->evpn",
    "routing_config->vrrp",
    # Non-FRR referenced entities
    "packet_marking",
    "sla_monitors",
]

# Keys whose entities may have a 'refs' list that must point into ENTITY_SOURCES.
REFS_OWNERS = [
    "config_set_address",
    "config_set_ports",
    "config_set_interfaces",
    "config_set_domains",
    "config_set_labels",
    "config_interfaces",
    "certificates",
    # Policy objects that carry refs registered by FRR services
    "routing_config->bfd_profiles",
    "routing_config->frr_prefix_lists",
    "routing_config->bgp_as_path_lists",
    "routing_config->bgp_community_lists",
    "routing_config->frr_route_maps",
]

# Keys whose entities have a nested-dict shape (handled specially when
# collecting ids: the sub-entities carry the real UUIDs).
NESTED_DICT_KEYS = {"dhcp_server", "routing_config->evpn", "routing_config->vrrp", "tc_config"}

# Absolute path, works in source and PyInstaller modes.
DEFAULT_CONFIG = "/etc/styx/startup-config.json"


def _build_known_ids(data: dict) -> set:
    """Build the global UUID pool from every ENTITY_SOURCES key present in *data*."""
    known_ids = set()
    for key in ENTITY_SOURCES:
        entities = data.get(key) or []
        # Normalize: single dict entries (lighttpd SSL, SSH config) vs list entries
        if isinstance(entities, dict):
            if key == "dhcp_server":
                for section in entities.values():
                    if isinstance(section, dict):
                        uid = section.get("id")
                        if uid:
                            known_ids.add(uid)
                        # interfaces sub-dict is itself a map of name → entity
                        for sub_entry in section.values():
                            if isinstance(sub_entry, dict):
                                uid = sub_entry.get("id")
                                if uid:
                                    known_ids.add(uid)
            elif key == "routing_config->evpn":
                for binding in entities.get("vrf_bindings") or []:
                    if isinstance(binding, dict):
                        uid = binding.get("id")
                        if uid:
                            known_ids.add(uid)
            elif key == "routing_config->vrrp":
                for inst in entities.get("instances") or []:
                    if isinstance(inst, dict):
                        uid = inst.get("id")
                        if uid:
                            known_ids.add(uid)
            elif key == "tc_config":
                for iface_uuid, iface_data in entities.get("interfaces", {}).items():
                    known_ids.add(iface_uuid)
                    if isinstance(iface_data, dict):
                        for sub_key in ("qdiscs", "classes", "filters"):
                            for entry in iface_data.get(sub_key, []) or []:
                                if isinstance(entry, dict):
                                    uid = entry.get("id")
                                    if uid:
                                        known_ids.add(uid)
            else:
                uid = entities.get("id")
                if uid:
                    known_ids.add(uid)
        else:
            for entity in entities:
                if not isinstance(entity, dict):
                    continue
                uid = entity.get("id")
                if uid:
                    known_ids.add(uid)
    return known_ids


def _find_orphaned_refs(data: dict, known_ids: set) -> list:
    """Return (key, entity_id, ref) triples for every ref that resolves nowhere."""
    orphans = []
    for key in REFS_OWNERS:
        entities = data.get(key) or []
        for entity in entities:
            entity_id = entity.get("id", "<no-id>")
            for ref in entity.get("refs") or []:
                if ref not in known_ids:
                    orphans.append((key, entity_id, ref))
    return orphans


def _remove_orphans(data: dict) -> list:
    """Return the orphaned (key, entity_id, ref) triples, removing them in place."""
    known = _build_known_ids(data)
    orphans = _find_orphaned_refs(data, known)
    for key, entity_id, ref in orphans:
        entities = data.get(key)
        if not isinstance(entities, list):
            continue
        for entity in entities:
            if not isinstance(entity, dict) or entity.get("id") != entity_id:
                continue
            refs = entity.get("refs")
            if isinstance(refs, list) and ref in refs:
                refs.remove(ref)
            break
    return orphans


def _write_json(path: str, data: dict) -> None:
    """Write the config back in the same format the Datastore uses."""
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=4, ensure_ascii=False)
        fh.write("\n")


def _prune_old_backups(path: str) -> None:
    base = os.path.basename(path)
    d = os.path.dirname(path)
    try:
        for name in os.listdir(d):
            if name.startswith(base + ".orphan-refs-") and name.endswith(".bak"):
                os.remove(os.path.join(d, name))
    except OSError:
        pass


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--path", default=DEFAULT_CONFIG, help=f"Config file to scan. Default: {DEFAULT_CONFIG}")
    parser.add_argument("--commit", action="store_true", help="Write the cleaned config back (dry-run by default).")
    parser.add_argument("--keep-backups", action="store_true", help="Keep old .bak files after a commit.")
    args = parser.parse_args()

    path = os.path.expanduser(args.path)
    if not os.path.exists(path):
        print(f"ERROR: file not found: {path}")
        return 2

    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except json.JSONDecodeError as exc:
        print(f"ERROR: '{path}' is not valid JSON: {exc}")
        return 2
    if not isinstance(data, dict):
        print(f"ERROR: '{path}' is not a JSON object (expected a datastore file).")
        return 2

    orphans = _remove_orphans(data)

    if not orphans:
        print(f"No orphaned refs found in {path}.")
        return 0

    print(f"Found {len(orphans)} orphaned ref(s) in {path}:")
    for key, entity_id, ref in orphans:
        print(f"  {key}  entity={entity_id}  ref={ref}")

    if not args.commit:
        print("\nDry-run: nothing written. Re-run with --commit to remove them.")
        return 0

    # Backup the original before touching it.
    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = f"{path}.orphan-refs-{stamp}.bak"
    try:
        shutil.copy2(path, backup)
    except OSError as exc:
        print(f"ERROR: could not create backup {backup}: {exc}")
        return 1

    _write_json(path, data)
    if not args.keep_backups:
        _prune_old_backups(path)

    print(f"\nRemoved {len(orphans)} orphaned ref(s) and wrote {path}.")
    print(f"Backup saved at {backup}.")
    print("Restart the gateway so the cleaned startup-config becomes the running-config.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
