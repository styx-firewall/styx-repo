/**
 * Traffic Stats page JS.
 *
 * Handles chart rendering, live polling, and refresh/reset controls.
 * Tab switching is handled by the global .std-tabs handler in
 * scripts/core/common.js.
 *
 * Depends on: api-client.js (global `apiClient`), Chart.js (global
 * `Chart`), common.js (`formatBytes`, `showApiResult`, `appLog`).
 */

(function () {
    'use strict';

    let refreshTimer = null;
    const REFRESH_INTERVAL_MS = 5000;

    /** canvas id -> live Chart instance */
    const charts = new Map();

    /* generic helpers */

    function toInt(value) {
        return parseInt(value, 10) || 0;
    }

    /* colour palette */

    const palette = [
        '#4e79a7', '#f28e2b', '#e15759', '#76b7b2', '#59a14f',
        '#edc948', '#b07aa1', '#ff9da7', '#9c755f', '#bab0ac',
        '#86bcf9', '#d4a6c8', '#a1c9f4', '#f4a582', '#92c5de'
    ];

    const colour = (i) => palette[i % palette.length];

    // Fixed colours for the direction chart (not palette index order).
    const DIR_COLOURS = ['#4e79a7', '#f28e2b', '#76b7b2'];

    /* entry normalisation */

    /**
     * Flatten raw API entries into one shape for tables and charts:
     * numbers parsed, missing fields become '-' or ''.
     * Names follow the same source as the primary ip: in/out
     * entries carry ip+hostname/custom_name, forwarded entries carry
     * src_ip/dst_ip each with its own name pair. Never mix them.
     */
    function normalizeSetEntries(rawEntries) {
        if (!Array.isArray(rawEntries)) return [];
        return rawEntries
            .filter((e) => e && typeof e === 'object')
            .map((e) => {
                // '' for plain ip entries, 'src_'/'dst_' for forwarded entries
                const prefix = e.ip ? '' : e.src_ip ? 'src_' : e.dst_ip ? 'dst_' : '';
                return {
                    iface: e.iface || '-',
                    ip: e[prefix + 'ip'] || '-',
                    hostname: e[prefix + 'hostname'] || '',
                    custom_name: e[prefix + 'custom_name'] || '',
                    src_ip: e.src_ip || '',
                    src_hostname: e.src_hostname || '',
                    src_custom_name: e.src_custom_name || '',
                    dst_ip: e.dst_ip || '',
                    dst_hostname: e.dst_hostname || '',
                    dst_custom_name: e.dst_custom_name || '',
                    proto: e.proto || '-',
                    packets: toInt(e.packets),
                    bytes: toInt(e.bytes),
                    expires: e.expires || '-',
                };
            });
    }

    /**
     * Display name for an ip following the priority:
     * custom -> hostname -> ip.
     */
    function displayName(customName, hostname, ip) {
        return customName || hostname || ip || '-';
    }

    /* chart rendering */

    function destroyChart(canvasId) {
        const chart = charts.get(canvasId);
        if (chart) {
            chart.destroy();
            charts.delete(canvasId);
        }
    }

    /** Tooltip value formatting shared by all doughnut charts. */
    function formatValue(value, valueKey) {
        return valueKey === 'bytes' ? formatBytes(value) : value.toLocaleString();
    }

    /**
     * Create (or replace) a doughnut chart: one coloured slice per
     * label, right-hand legend, tooltip formatted per valueKey.
     * Colours default to the palette; pass a fixed list for
     * label-specific colouring (direction chart).
     */
    function buildDoughnut(canvasId, labels, values, valueKey, colours) {
        destroyChart(canvasId);
        const canvas = document.getElementById(canvasId);
        if (!canvas || !labels.length) return;
        const colors = colours || labels.map((_, i) => colour(i));
        charts.set(canvasId, new Chart(canvas.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: values,
                    backgroundColor: colors,
                    borderColor: '#1e1e2e',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 0 },
                plugins: {
                    legend: { position: 'right', labels: { color: '#cdd6f4' } },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => ctx.label + ': ' + formatValue(ctx.parsed || 0, valueKey)
                        }
                    }
                }
            }
        }));
    }

    /** Doughnut chart of per-interface totals for one metric. */
    function renderIfaceChart(canvasId, summary, valueKey) {
        if (!summary) return;
        const labels = Object.keys(summary);
        buildDoughnut(canvasId, labels, labels.map((iface) => toInt(summary[iface][valueKey])), valueKey);
    }

    /** Doughnut chart of protocol totals across all directions. */
    function renderProtocolChart(canvasId, setsIn, setsOut, setsFwd, valueKey) {
        const protoTotals = {};
        for (const set of [setsIn, setsOut, setsFwd]) {
            for (const e of set) {
                const proto = (e.proto || 'unknown').toUpperCase();
                protoTotals[proto] = (protoTotals[proto] || 0) + toInt(e[valueKey]);
            }
        }
        const protos = Object.keys(protoTotals).sort((a, b) => protoTotals[b] - protoTotals[a]);
        buildDoughnut(canvasId, protos, protos.map((p) => protoTotals[p]), valueKey);
    }

    /** Doughnut chart of in/out/fwd totals for one metric. */
    function renderDirChart(canvasId, setsIn, setsOut, setsFwd, valueKey) {
        const total = (set) => set.reduce((sum, e) => sum + toInt(e[valueKey]), 0);
        const inTotal = total(setsIn);
        const outTotal = total(setsOut);
        const fwdTotal = total(setsFwd);
        if (!inTotal && !outTotal && !fwdTotal) return;
        buildDoughnut(
            canvasId,
            ['Inbound', 'Outbound', 'Forwarded'],
            [inTotal, outTotal, fwdTotal],
            valueKey,
            DIR_COLOURS
        );
    }

    /**
     * Horizontal bar chart of the top 10 IPs by total bytes.
     * Labels show the best available name (custom -> hostname -> ip);
     * the tooltip title shows the raw ip.
     */
    function renderTopIpsChart(canvasId, setsIn, setsOut, setsFwd) {
        destroyChart(canvasId);
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;

        // Aggregate bytes per ip, keeping the best display name
        // (rank: custom_name > hostname > ip).
        const ipBytes = {};
        const bestName = {};
        const rankOf = {};
        const nameRank = (e) => e.custom_name ? 3 : e.hostname ? 2 : 1;
        const addEntries = (entries) => {
            for (const e of entries) {
                const ip = e.ip || 'unknown';
                ipBytes[ip] = (ipBytes[ip] || 0) + toInt(e.bytes);
                const rank = nameRank(e);
                if (rank > (rankOf[ip] || 0)) {
                    rankOf[ip] = rank;
                    bestName[ip] = displayName(e.custom_name, e.hostname, ip);
                }
            }
        };
        addEntries(setsIn);
        addEntries(setsOut);
        addEntries(setsFwd);

        const ips = Object.keys(ipBytes).sort((a, b) => ipBytes[b] - ipBytes[a]);
        if (ips.length === 0) return;
        const top = ips.slice(0, 10);
        const labels = top.map((ip) => bestName[ip] || ip);
        const colours = labels.map((_, i) => colour(i));

        charts.set(canvasId, new Chart(canvas.getContext('2d'), {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    data: top.map((ip) => ipBytes[ip]),
                    backgroundColor: colours,
                    borderColor: colours,
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 0 },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            title: (items) => {
                                const idx = items && items[0] ? items[0].dataIndex : -1;
                                return idx >= 0 && idx < top.length ? top[idx] : '';
                            },
                            label: (ctx) => formatBytes(ctx.parsed.x || 0)
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: '#cdd6f4',
                            callback: (val) => formatBytes(val)
                        },
                        grid: { color: 'rgba(255,255,255,0.05)' }
                    },
                    y: {
                        ticks: { color: '#cdd6f4' },
                        grid: { display: false }
                    }
                }
            }
        }));
    }

    /* DOM renderers */

    function renderSummaryBar(summaryAll) {
        const bar = document.querySelector('.ts-summary-bar');
        if (!bar) return;
        const items = bar.querySelectorAll('.ts-summary-item');
        if (items.length >= 3) {
            items[0].innerHTML = `<strong>Total:</strong> ${formatBytes(summaryAll.bytes || 0)}`;
            items[1].innerHTML = `<strong>Packets:</strong> ${(summaryAll.packets || 0).toLocaleString()}`;
            items[2].innerHTML = `<strong>Flows:</strong> ${(summaryAll.flows || 0).toLocaleString()}`;
        }
    }

    /**
     * Build a <tr> with one <td> per cell. A cell is a plain value or a
     * { text, title, bold } spec. Values are written via textContent, so
     * gateway data never reaches innerHTML and needs no escaping.
     */
    function makeRow(cells) {
        const tr = document.createElement('tr');
        for (const cell of cells) {
            const spec = (cell !== null && typeof cell === 'object') ? cell : { text: cell };
            const td = document.createElement('td');
            if (spec.bold) {
                const strong = document.createElement('strong');
                strong.textContent = spec.text;
                td.appendChild(strong);
            } else {
                td.textContent = spec.text;
            }
            if ('title' in spec) td.title = spec.title;
            tr.appendChild(td);
        }
        return tr;
    }

    function renderSummaryTable(summary) {
        const tbody = document.querySelector('.ts-summary-table tbody');
        if (!tbody) return;
        tbody.replaceChildren();
        const entries = summary ? Object.entries(summary) : [];
        if (!entries.length) {
            tbody.innerHTML = '<tr><td colspan="4" class="ts-empty">No data</td></tr>';
            return;
        }
        for (const [iface, agg] of entries) {
            tbody.appendChild(makeRow([
                { text: iface, bold: true },
                (agg.packets || 0).toLocaleString(),
                formatBytes(agg.bytes || 0),
                (agg.flows || 0).toLocaleString(),
            ]));
        }
    }

    function renderDetailTable(tableId, entries) {
        const tbody = document.querySelector(`#${tableId} tbody`);
        if (!tbody) return;
        tbody.replaceChildren();
        if (!entries || !entries.length) {
            tbody.innerHTML = '<tr><td colspan="7" class="ts-empty">No traffic data</td></tr>';
            return;
        }
        for (const e of entries) {
            tbody.appendChild(makeRow([
                e.iface,
                e.ip,
                { text: displayName(e.custom_name, e.hostname, ''), title: e.ip },
                e.proto,
                e.packets.toLocaleString(),
                formatBytes(e.bytes),
                e.expires,
            ]));
        }
    }

    function renderDetailTableFwd(tableId, entries) {
        const tbody = document.querySelector(`#${tableId} tbody`);
        if (!tbody) return;
        tbody.replaceChildren();
        if (!entries || !entries.length) {
            tbody.innerHTML = '<tr><td colspan="9" class="ts-empty">No traffic data</td></tr>';
            return;
        }
        for (const e of entries) {
            tbody.appendChild(makeRow([
                e.iface,
                e.src_ip || '-',
                { text: displayName(e.src_custom_name, e.src_hostname, ''), title: e.src_ip },
                e.dst_ip || '-',
                { text: displayName(e.dst_custom_name, e.dst_hostname, ''), title: e.dst_ip },
                e.proto,
                e.packets.toLocaleString(),
                formatBytes(e.bytes),
                e.expires,
            ]));
        }
    }

    function renderOverview(summary, setsIn, setsOut, setsFwd) {
        renderTopIpsChart('ts-chart-top-ips', setsIn, setsOut, setsFwd);
        renderIfaceChart('ts-chart-iface-packets', summary, 'packets');
        renderIfaceChart('ts-chart-iface-bytes', summary, 'bytes');
        renderProtocolChart('ts-chart-protocol', setsIn, setsOut, setsFwd, 'bytes');
        renderDirChart('ts-chart-dir-packets', setsIn, setsOut, setsFwd, 'packets');
        renderDirChart('ts-chart-dir-bytes', setsIn, setsOut, setsFwd, 'bytes');
    }

    /* fetch & refresh */

    async function fetchAndRender() {
        try {
            const response = await window.apiClient.request('traffic-stats-get', {});
            if (!response || response.status !== 'success' || !response.result) {
                if (window.appLog) window.appLog.warn('traffic-stats: fetch failed', response);
                return;
            }

            const result = response.result;
            const sets = result.sets || {};
            const summary = result.summary || {};
            const summaryAll = result.summary_all || {};

            const setsIn = normalizeSetEntries(
                (sets.ipv4_traffic_in || []).concat(sets.ipv6_traffic_in || [])
            );
            const setsOut = normalizeSetEntries(
                (sets.ipv4_traffic_out || []).concat(sets.ipv6_traffic_out || [])
            );
            const setsFwd = normalizeSetEntries(
                (sets.ipv4_traffic_fwd || []).concat(sets.ipv6_traffic_fwd || [])
            );

            renderSummaryBar(summaryAll);
            renderSummaryTable(summary);
            renderDetailTable('ts-table-in', setsIn);
            renderDetailTable('ts-table-out', setsOut);
            renderDetailTableFwd('ts-table-fwd', setsFwd);
            renderOverview(summary, setsIn, setsOut, setsFwd);
        } catch (err) {
            if (window.appLog) window.appLog.warn('traffic-stats: fetch error', err);
        }
    }

    /* auto-refresh controls */

    function startAutoRefresh() {
        stopAutoRefresh();
        refreshTimer = setInterval(fetchAndRender, REFRESH_INTERVAL_MS);
    }

    function stopAutoRefresh() {
        if (refreshTimer !== null) {
            clearInterval(refreshTimer);
            refreshTimer = null;
        }
    }

    /* init */

    async function handleReset() {
        try {
            const result = await window.apiClient.submit('traffic-stats-reset', {});
            if (window.showApiResult) {
                window.showApiResult(result, {
                    title: 'Reset Traffic Stats',
                    closeText: 'Close',
                    reloadOnOk: false
                });
            }
        } catch (err) {
            if (window.showApiResult) {
                window.showApiResult(
                    { status: 'error', response_msg: err.message },
                    { title: 'Error', closeText: 'Close' }
                );
            }
        } finally {
            // Refresh the data regardless
            fetchAndRender();
        }
    }

    function init() {
        const refreshBtn = document.getElementById('ts-refresh-btn');
        const resetBtn = document.getElementById('ts-reset-btn');
        const autoCheckbox = document.getElementById('ts-auto-refresh');

        if (refreshBtn) refreshBtn.addEventListener('click', fetchAndRender);
        if (resetBtn) resetBtn.addEventListener('click', handleReset);
        if (autoCheckbox) {
            autoCheckbox.addEventListener('change', () => autoCheckbox.checked ? startAutoRefresh() : stopAutoRefresh());
            if (autoCheckbox.checked) startAutoRefresh();
        }

        fetchAndRender();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
