/**
 * telemetry.js
 *
 * Client side of the Telemetry section (Styx page): queries the TelemetryBus
 * through `telemetry_query` and paints the raw points, each row expandable to
 * its full JSON, on demand per row, or all at once with the expand-all
 * checkbox.
 *
 * The filter shell and the Stats tab are rendered server side by
 * TelemetryFormatter; this file only owns the points table, the view options
 * and the polling.
 *
 * Shape copied from the eBPF telemetry pane (scripts/ebpf/ebpf.js).
 */
(function () {
    'use strict';

    var ACTION_QUERY = 'telemetry_query';

    // Badge variants from default-badge.css. Severity and kind enums come from
    // the backend's TelemetryPoint; this mirrors level_badge() in
    // styx-events.tpl.php, which does the same job for log levels.
    var SEVERITY_BADGE = {
        debug: 'std-badge--muted',
        info:  'std-badge--log-info',
        warn:  'std-badge--warning',
        crit:  'std-badge--danger'
    };
    var KIND_BADGE = {
        snapshot: 'std-badge--info',
        delta:    'std-badge--info',
        event:    'std-badge--warning'
    };

    var els = {};
    var pollTimer = null;
    var inflight = null;
    /** Points of the last render, indexed by row position. */
    var points = [];
    /** Row index -> the expanded JSON row, so toggling is not a rebuild. */
    var jsonRows = {};
    /** Kept so a repaint does not lose the reason the table is empty. */
    var lastEmptyMessage = '';
    /**
     * Every instance option as rendered by the server, each with its species,
     * so the list can be narrowed locally when a scope is picked.
     */
    var instanceChoices = [];

    // helpers

    function $(id) { return document.getElementById(id); }

    /**
     * `ts_ns` is nanoseconds; dateUtils.formatTimestamp() would read that as
     * microseconds (it only auto-detects seconds/ms/us), so it is converted to
     * milliseconds here. Full precision stays in the expanded JSON.
     */
    function formatTs(tsNs) {
        var ns = Number(tsNs);
        if (!isFinite(ns) || ns <= 0) return '';
        if (typeof window.dateUtils === 'undefined') {
            return String(tsNs);
        }
        return window.dateUtils.formatTimestamp(Math.floor(ns / 1e6));
    }

    function badgeClass(map, value) {
        return map[String(value || '').toLowerCase()] || 'std-badge--muted';
    }

    /**
     * Scope/source matching, following the backend's rule: "*" means no filter,
     * otherwise exact or prefix at a "/" boundary,so "ebpf" matches
     * "ebpf/net_block" but never "ebpf2/...".
     *
     * The storage applies the wildcard check and then its own path_matches();
     * both are folded into this one helper so that narrowing the instance list
     * here agrees with what a query using that scope would actually return.
     */
    function pathMatches(filter, value) {
        if (filter === '*') return true;
        return filter === value || value.indexOf(filter + '/') === 0;
    }

    function setStatus(text, kind) {
        if (!els.status) return;
        els.status.textContent = text || '';
        els.status.className = 'telemetry-status' + (kind ? ' telemetry-status-' + kind : '');
    }

    /** datetime-local value -> epoch seconds, or null when empty/invalid. */
    function inputToEpoch(input) {
        if (!input || !input.value) return null;
        var ms = new Date(input.value).getTime();
        return isFinite(ms) ? ms / 1000 : null;
    }

    // state

    /**
     * Filter memory, via the shared helper (scripts/core/state-storage.js)
     * rather than localStorage directly,it namespaces the keys per user.
     */
    var STATE_SCOPE = 'telemetry';

    function stateGet(key, def) {
        return typeof window.loadState === 'function' ? window.loadState(STATE_SCOPE, key, def) : def;
    }

    function stateSet(key, value) {
        if (typeof window.saveState === 'function') {
            window.saveState(STATE_SCOPE, key, value);
        }
    }

    /**
     * Restore a <select> only if the stored value is still one of its options.
     *
     * A stored scope can stop existing between visits,an eBPF module gets
     * unloaded and its UUID is gone from the inventory. Assigning it anyway
     * leaves the control blank, so an option that no longer exists falls back
     * to whatever the server rendered as selected.
     */
    function restoreSelect(select, saved) {
        if (!select || saved === null || saved === undefined) return;
        var value = String(saved);
        var options = select.options || [];
        for (var i = 0; i < options.length; i++) {
            if (options[i].value === value) {
                select.value = value;
                return;
            }
        }
    }

    function restoreState() {
        restoreSelect(els.scope, stateGet('scope', null));
        restoreSelect(els.instance, stateGet('instance', null));
        restoreSelect(els.source, stateGet('source', null));
        restoreSelect(els.schema, stateGet('schema_type', null));
        restoreSelect(els.n, stateGet('n', null));
        restoreSelect(els.interval, stateGet('pollInterval', null));

        if (els.expandAll) els.expandAll.checked = stateGet('expandAll', false) === true;
        if (els.autopoll) els.autopoll.checked = stateGet('autopoll', false) === true;
    }

    /**
     * Narrow the instance list to the selected species.
     *
     * Every instance arrives already labelled with the species it belongs to, so
     * this is a local pass over the rendered options,picking a scope costs no
     * round trip. The current instance is kept when it is still on the list and
     * falls back to "All instances" when it belonged to another species.
     */
    function applyScopeFilter() {
        if (!els.instance || !instanceChoices.length) return;
        var scope = els.scope ? els.scope.value : '*';
        var keep = els.instance.value;

        els.instance.innerHTML = '';
        instanceChoices.forEach(function (choice) {
            // The "All instances" entry carries scope "*", which no species
            // filter can match, so it is excluded from the test by value.
            if (choice.value !== '*' && !pathMatches(scope, choice.scope)) return;
            var option = document.createElement('option');
            option.value = choice.value;
            option.textContent = choice.label;
            option.dataset.scope = choice.scope;
            els.instance.appendChild(option);
        });

        els.instance.value = '*';
        restoreSelect(els.instance, keep);
    }

    /**
     * Persist the picked filters and view options.
     *
     * The date range is deliberately absent: a window the operator looked at
     * yesterday is not a sensible default for today, and silently re-asking it
     * would look like an empty bus.
     */
    function saveState() {
        if (els.scope) stateSet('scope', els.scope.value);
        if (els.instance) stateSet('instance', els.instance.value);
        if (els.source) stateSet('source', els.source.value);
        if (els.schema) stateSet('schema_type', els.schema.value);
        if (els.n) stateSet('n', els.n.value);
        if (els.interval) stateSet('pollInterval', els.interval.value);
        if (els.expandAll) stateSet('expandAll', els.expandAll.checked);
        if (els.autopoll) stateSet('autopoll', els.autopoll.checked);
    }

    // render

    function renderPoints(result, emptyMessage) {
        points = (result && result.points) || [];
        lastEmptyMessage = emptyMessage || '';
        paint();
    }

    /**
     * Paint the stored points.
     *
     * Split from renderPoints so the expand-all toggle can repaint what is
     * already on screen without going back to the gateway for it.
     */
    function paint() {
        var tbody = els.body;
        var expand = isExpandAll();
        tbody.innerHTML = '';
        jsonRows = {};

        if (!points.length) {
            var empty = document.createElement('tr');
            var cell = document.createElement('td');
            cell.colSpan = 8;
            cell.className = 'text-center';
            cell.textContent = lastEmptyMessage || 'No points in storage for this filter.';
            empty.appendChild(cell);
            tbody.appendChild(empty);
            return;
        }

        var frag = document.createDocumentFragment();
        points.forEach(function (point, idx) {
            var row = buildRow(point, idx);
            frag.appendChild(row);
            // Expanding everything is one fragment insertion, not N of them.
            if (expand) {
                frag.appendChild(buildJsonRow(point, idx));
                row.querySelector('.telemetry-caret').classList.add('telemetry-caret-open');
            }
        });
        tbody.appendChild(frag);
    }

    /**
     * The full-JSON row for a point. It registers itself in `jsonRows` under
     * `idx` either way, so rows opened by expand-all stay individually
     * collapsible.
     */
    function buildJsonRow(point, idx) {
        var tr = document.createElement('tr');
        var td = document.createElement('td');
        td.colSpan = 7;
        td.className = 'telemetry-json-cell';

        var pre = document.createElement('pre');
        pre.className = 'telemetry-json';
        // textContent, not innerHTML: this is an arbitrary payload from the bus.
        pre.textContent = JSON.stringify(point, null, 2);
        td.appendChild(pre);
        tr.appendChild(td);

        jsonRows[idx] = tr;
        return tr;
    }

    function buildRow(point, idx) {
        var tr = document.createElement('tr');
        tr.className = 'telemetry-point-row';
        tr.dataset.idx = String(idx);

        var caretCell = document.createElement('td');
        var caret = document.createElement('span');
        caret.className = 'telemetry-caret';
        caret.textContent = '▶';
        caretCell.appendChild(caret);
        tr.appendChild(caretCell);

        tr.appendChild(textCell(formatTs(point.ts_ns)));
        tr.appendChild(textCell(point.scope));

        // Composed by the backend, and the same string the instance dropdown
        // shows,so nothing here has to interpret instance_labels, and a
        // future change to how an instance reads is a backend change only.
        tr.appendChild(textCell(point.instance_display));

        tr.appendChild(textCell(point.source));

        var schemaCell = document.createElement('td');
        schemaCell.className = 'telemetry-schema';
        schemaCell.textContent = point.schema_type || '';
        tr.appendChild(schemaCell);

        var kindCell = document.createElement('td');
        var kind = document.createElement('span');
        kind.className = 'std-badge ' + badgeClass(KIND_BADGE, point.kind);
        kind.textContent = point.kind || '';
        kindCell.appendChild(kind);
        tr.appendChild(kindCell);

        var sevCell = document.createElement('td');
        var sev = document.createElement('span');
        sev.className = 'std-badge ' + badgeClass(SEVERITY_BADGE, point.severity);
        sev.textContent = point.severity || '';
        sevCell.appendChild(sev);
        tr.appendChild(sevCell);

        return tr;
    }

    function textCell(value) {
        var td = document.createElement('td');
        td.textContent = value === null || value === undefined ? '' : String(value);
        return td;
    }

    function toggleJson(idx) {
        var row = els.body.querySelector('tr[data-idx="' + idx + '"]');
        if (!row) return;

        if (jsonRows[idx]) {
            jsonRows[idx].remove();
            delete jsonRows[idx];
            row.querySelector('.telemetry-caret').classList.remove('telemetry-caret-open');
            return;
        }

        var point = points[idx];
        if (!point) return;

        row.parentNode.insertBefore(buildJsonRow(point, idx), row.nextSibling);
        row.querySelector('.telemetry-caret').classList.add('telemetry-caret-open');
    }

    function isExpandAll() {
        return !!(els.expandAll && els.expandAll.checked);
    }

    /**
     * Repaint from the points already held, so ticking the box is instant and
     * costs nothing at the gateway. A row collapsed by hand while expand-all is
     * on stays collapsed until the next paint (a new query or a re-tick).
     */
    function applyExpandAll() {
        if (els.body) paint();
    }

    // query

    function currentPayload() {
        var from = inputToEpoch(els.from);
        var to = inputToEpoch(els.to);

        // The backend only does a range query when both bounds are present and
        // silently falls back to "last N" otherwise, so a half-set range is
        // caught here (the controller refuses it too, this just saves a round trip).
        if ((from === null) !== (to === null)) {
            return { error: 'From and To must be set together (or both empty for the last N points).' };
        }

        var payload = {
            scope: els.scope ? els.scope.value : '*',
            instance: els.instance ? els.instance.value : '*',
            source: els.source ? els.source.value : '*',
            schema_type: els.schema ? els.schema.value : '*',
            n: els.n ? parseInt(els.n.value, 10) : 50
        };
        if (from !== null) {
            payload.from_ts = from;
            payload.to_ts = to;
        }
        return { payload: payload };
    }

    function fetchPoints() {
        var built = currentPayload();
        if (built.error) {
            setStatus(built.error, 'error');
            return;
        }

        if (inflight) inflight.abort();
        inflight = new AbortController();
        setStatus('Querying…');

        apiClient.request(ACTION_QUERY, built.payload, { signal: inflight.signal })
            .then(function (res) {
                if (!res || res.status === 'error') {
                    setStatus((res && res.response_msg) || 'Query failed', 'error');
                    renderPoints(null, 'Query failed.');
                    return;
                }
                var result = res.result || {};
                renderPoints(result);
                var q = result.query || {};
                var count = (result.points || []).length;
                var kind = q.kind === 'range' ? 'time range' : 'last per bucket';
                setStatus(count + ' point' + (count === 1 ? '' : 's') + ' (' + kind + ')');
            })
            .catch(function (err) {
                if (err && err.name === 'AbortError') return;
                setStatus((err && err.message) || 'Query failed', 'error');
            });
    }

    /**
     * Drop the date range and re-ask.
     *
     * Re-asking is the point: leaving the previous range's rows on screen while
     * the inputs read empty would be a table that no longer matches its own
     * filters. The range is not persisted (see saveState), so there is no stored
     * copy to clear, and clearing programmatically fires no `change` event,
     * nothing is written either way.
     */
    function clearDates() {
        if (els.from) els.from.value = '';
        if (els.to) els.to.value = '';
        fetchPoints();
    }

    // polling

    function stopPolling() {
        if (pollTimer) {
            clearInterval(pollTimer);
            pollTimer = null;
        }
    }

    function startPolling() {
        stopPolling();
        var ms = els.interval ? parseInt(els.interval.value, 10) : 5000;
        if (!isFinite(ms) || ms < 1000) ms = 5000;
        pollTimer = setInterval(function () {
            // A hidden tab has nobody reading it; skipping keeps a backgrounded
            // page from polling the bus forever.
            if (document.hidden) return;
            fetchPoints();
        }, ms);
    }

    function syncPolling() {
        if (els.autopoll && els.autopoll.checked && isLiveTabActive()) {
            startPolling();
        } else {
            stopPolling();
        }
    }

    /** Polling only makes sense while the Live panel is the visible one. */
    function isLiveTabActive() {
        var panel = $('tab-telemetry-live');
        return !!panel && panel.classList.contains('active');
    }

    // settings tab

    function settingsForm() {
        return $('telemetry-settings-form');
    }

    function fieldValue(name) {
        var form = settingsForm();
        var el = form ? form.querySelector('[name="' + name + '"]') : null;
        return el ? String(el.value).trim() : '';
    }

    function asInt(value) {
        return (value === '' || isNaN(Number(value))) ? NaN : parseInt(value, 10);
    }

    function asNumber(value) {
        return (value === '' || isNaN(Number(value))) ? NaN : Number(value);
    }

    function intInRange(value, low, high) {
        return isFinite(value) && value === Math.floor(value) && value >= low && value <= high;
    }

    function numberInRange(value, low, high) {
        return isFinite(value) && value >= low && value <= high;
    }

    /** The backend's rule: empty, or an http(s) URL without query or fragment. */
    function endpointValid(value) {
        if (value === '') return true;
        try {
            var url = new URL(value);
            return (url.protocol === 'http:' || url.protocol === 'https:') && !url.search && !url.hash;
        } catch (err) {
            return false;
        }
    }

    /**
     * The headers exactly as shown. A row with no name is not a header; a masked
     * value ("***") is resent verbatim, which the backend reads as "keep the
     * stored one". Omitting a name is how a header is deleted.
     */
    function headersFromRows() {
        var body = $('telemetry-headers-body');
        var headers = {};
        if (!body) return headers;
        body.querySelectorAll('tr.telemetry-header-row').forEach(function (row) {
            var keyEl = row.querySelector('[data-header-key]');
            var valueEl = row.querySelector('[data-header-value]');
            var name = keyEl ? keyEl.value.trim() : '';
            if (name === '') return;
            headers[name] = valueEl ? valueEl.value : '';
        });
        return headers;
    }

    function settingsPayload() {
        var payload = {
            maxlen: asInt(fieldValue('maxlen')),
            ttl: asNumber(fieldValue('ttl')),
            series_budget_default: asInt(fieldValue('series_budget_default'))
        };

        // The export fields only exist when the backend reports the export
        // configuration; sending export keys to a backend that does not would
        // be an unknown-key refusal, so they are omitted wholesale.
        var form = settingsForm();
        if (!form || !form.querySelector('[name="export_endpoint"]')) {
            return payload;
        }

        var enabled = $('telemetry-export-enabled');
        payload.export_enabled = !!(enabled && enabled.checked);
        payload.export_endpoint = fieldValue('export_endpoint');
        payload.export_interval_s = asInt(fieldValue('export_interval_s'));
        payload.export_timeout_s = asInt(fieldValue('export_timeout_s'));
        payload.export_service_name = fieldValue('export_service_name');
        payload.export_instance_id = fieldValue('export_instance_id');
        payload.export_headers = headersFromRows();
        return payload;
    }

    /**
     * The backend's rules, restated for a fast answer. It stays the authority;
     * this only avoids the round trip for an error it would return anyway.
     */
    function validateSettings(p) {
        if (!intInRange(p.maxlen, 1, 1000000)) {
            return 'Points per bucket must be between 1 and 1000000.';
        }
        if (!numberInRange(p.ttl, 0, 86400)) {
            return 'Lifetime must be between 0 and 86400 seconds.';
        }
        if (!intInRange(p.series_budget_default, 1, 1000000)) {
            return 'Series per producer must be between 1 and 1000000.';
        }
        if (!Object.prototype.hasOwnProperty.call(p, 'export_enabled')) {
            return ''; // export not reported by this backend; nothing more to check
        }
        if (p.export_enabled && p.export_endpoint === '') {
            return 'An endpoint is required to enable export.';
        }
        if (!endpointValid(p.export_endpoint)) {
            return 'The endpoint must be an http(s):// URL without query or fragment.';
        }
        if (!intInRange(p.export_interval_s, 1, 3600)) {
            return 'Interval must be between 1 and 3600 seconds.';
        }
        if (!intInRange(p.export_timeout_s, 1, 60)) {
            return 'Timeout must be between 1 and 60 seconds.';
        }
        if (p.export_service_name === '' || p.export_service_name.length > 64) {
            return 'Service name must be 1 to 64 characters.';
        }
        if (p.export_instance_id !== '' && !/^[A-Za-z0-9._:-]+$/.test(p.export_instance_id)) {
            return 'Instance id may only contain letters, digits and . _ : -';
        }
        return '';
    }

    function buildHeaderRow(name, value) {
        var row = document.createElement('tr');
        row.className = 'telemetry-header-row';

        var keyCell = document.createElement('td');
        var key = document.createElement('input');
        key.type = 'text';
        key.className = 'std-input';
        key.setAttribute('data-header-key', '');
        key.value = name;
        keyCell.appendChild(key);

        var valueCell = document.createElement('td');
        var val = document.createElement('input');
        val.type = 'text';
        val.className = 'std-input';
        val.setAttribute('data-header-value', '');
        val.value = value;
        valueCell.appendChild(val);

        var actionCell = document.createElement('td');
        var remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'std-btn telemetry-header-remove';
        remove.textContent = 'Remove';
        actionCell.appendChild(remove);

        row.appendChild(keyCell);
        row.appendChild(valueCell);
        row.appendChild(actionCell);
        return row;
    }

    function initSettings() {
        var form = settingsForm();
        if (!form) return;

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var payload = settingsPayload();
            var error = validateSettings(payload);
            if (error) {
                showError(error);
                return;
            }
            apiClient.submit('telemetry_set_settings', payload)
                .then(function (res) {
                    // The save applies hot; reloading shows the merged settings
                    // with the header values re-masked by the backend.
                    showApiResult(res, { closeText: 'Close', reloadOnOk: true });
                })
                .catch(function (err) {
                    showApiResult(
                        { status: 'error', response_msg: err.message },
                        { title: 'Error', closeText: 'Close' }
                    );
                });
        });

        var add = $('telemetry-header-add');
        if (add) {
            add.addEventListener('click', function () {
                var body = $('telemetry-headers-body');
                if (!body) return;
                if (body.querySelectorAll('tr.telemetry-header-row').length >= 32) {
                    showError('At most 32 headers.');
                    return;
                }
                body.appendChild(buildHeaderRow('', ''));
            });
        }

        // Delegated: the Remove buttons come and go with the rows.
        document.addEventListener('click', function (e) {
            var btn = e.target.closest('.telemetry-header-remove');
            if (!btn) return;
            var row = btn.closest('tr.telemetry-header-row');
            if (row) row.remove();
        });
    }

    // init

    function init() {
        els.body = $('telemetry-points-body');
        if (!els.body) return; // not on this page

        els.status = $('telemetry-status');
        els.scope = document.querySelector('#telemetry-filter-form select[name="scope"]');
        els.instance = document.querySelector('#telemetry-filter-form select[name="instance"]');
        els.source = document.querySelector('#telemetry-filter-form select[name="source"]');
        els.schema = document.querySelector('#telemetry-filter-form select[name="schema_type"]');
        els.n = document.querySelector('#telemetry-filter-form select[name="n"]');
        els.from = document.querySelector('#telemetry-filter-form input[name="from_ts"]');
        els.to = document.querySelector('#telemetry-filter-form input[name="to_ts"]');
        els.autopoll = $('telemetry-autopoll');
        els.interval = $('telemetry-poll-interval');
        els.expandAll = $('telemetry-expand-all');
        els.clearDates = $('telemetry-clear-dates');

        var form = $('telemetry-filter-form');
        if (form) {
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                fetchPoints();
            });
            // `change` bubbles, so one listener covers every select and checkbox.
            form.addEventListener('change', saveState);
        }

        if (els.autopoll) els.autopoll.addEventListener('change', syncPolling);
        if (els.interval) els.interval.addEventListener('change', syncPolling);
        if (els.expandAll) els.expandAll.addEventListener('change', applyExpandAll);
        if (els.clearDates) els.clearDates.addEventListener('click', clearDates);

        if (els.body) {
            els.body.addEventListener('click', function (e) {
                var row = e.target.closest('tr.telemetry-point-row');
                if (!row) return;
                toggleJson(parseInt(row.dataset.idx, 10));
            });
        }

        // The std-tabs handler (common.js) only swaps classes, so the polling
        // state is re-synced here after it has run.
        document.addEventListener('click', function (e) {
            if (e.target.closest('#telemetry-tabs .std-tab-btn')) {
                setTimeout(syncPolling, 0);
            }
        });

        // Snapshot every instance option the server rendered, with its species,
        // before anything narrows the list.
        if (els.instance) {
            for (var i = 0; i < els.instance.options.length; i++) {
                var opt = els.instance.options[i];
                instanceChoices.push({
                    value: opt.value,
                    label: opt.textContent,
                    scope: opt.dataset.scope || '*',
                });
            }
        }
        if (els.scope) els.scope.addEventListener('change', applyScopeFilter);

        // Restore before the first query, so the page opens on the filters the
        // user last picked rather than on defaults that then get saved over them.
        restoreState();
        applyScopeFilter();
        syncPolling();
        fetchPoints();
        initSettings();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
