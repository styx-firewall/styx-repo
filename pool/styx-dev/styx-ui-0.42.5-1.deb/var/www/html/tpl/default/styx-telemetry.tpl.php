<?php
/**
 * TemplateService->getTpl()
 *
 * Telemetry,raw inspector for the Styx TelemetryBus, whatever subsystem
 * produced the points.
 *
 * Everything below is pre-computed by TelemetryFormatter: values ending in
 * `_html` are ready to echo, values ending in `_attr` are ready to drop into an
 * attribute, and numbers arrive already cast to strings. This file holds no
 * escaping and no casting.
 *
 * Structure of $tdata['page_data']:
 *   scope_options|source_options|schema_options: array<array{value_attr,label_html,selected}>
 *   instance_options: array<array{value_attr,label_html,selected,scope_attr}>
 *                     label is the backend's instance_display; scope lets the
 *                     client narrow the list when a species is selected.
 *   n_options:     array<array{value_attr,label_html,selected}>
 *   sources_rows:  array<array{scope_html,source_html,schemas_html}>
 *   has_inventory: bool
 *   stats:         array{available:bool,gauges:array,drop_rows:array,has_drops:bool,
 *                        total_dropped_html:string,dropped_class_attr:string,
 *                        eviction_rows:array,has_evictions:bool,
 *                        total_evictions_html:string,evictions_class_attr:string,
 *                        delivered_html:string,has_bus:bool,exporter:array}
 *   settings:      array{has_settings:bool,can_write:bool,retention:array,
 *                        export_enabled:bool,export_reported:bool,export_available:bool,
 *                        export_available_error_html:string,export_endpoint_attr:string,
 *                        export_interval_s_attr:string,export_timeout_s_attr:string,
 *                        export_service_name_attr:string,export_instance_id_attr:string,
 *                        header_rows:array,headers_max:int}  Retention + OTLP export.
 *   error_html:    string  (only on failure)
 *   denied:        bool    (only when telemetry:read is missing)
 *
 * The points table is filled client-side by telemetry.js, which polls
 * telemetry_query,hence the empty tbody.
 *
 * Included JS: scripts/telemetry/telemetry.js
 * Included CSS: default-telemetry.css
 *
 * @var array<mixed> $tdata
 */
$pd = $tdata['page_data'];
$stats = $pd['stats'] ?? ['available' => false];
?>
<div><?= $tdata['page_head'] ?></div>
<div class="page-layout">
    <div><?= $tdata['sidebar'] ?></div>
    <main class="page-content">
        <h1>Telemetry</h1>

        <?php if (!empty($pd['denied'])): ?>
            <div class="content-box">
                <div class="std-error-box">
                    <strong>Error:</strong>
                    <div><?= $pd['error_html'] ?? '' ?></div>
                </div>
            </div>
        <?php else: ?>

        <?php if (!empty($pd['error_html'])): ?>
            <div class="std-error-box">
                <strong>Error:</strong>
                <div><?= $pd['error_html'] ?></div>
            </div>
        <?php endif; ?>
        <?php if (!empty($pd['warnings_html'])): ?>
            <div class="std-error-box">
                <strong>Warning:</strong>
                <div><?= $pd['warnings_html'] ?></div>
            </div>
        <?php endif; ?>

        <div class="telemetry-tabs">
            <div class="std-tabs" id="telemetry-tabs">
                <button class="std-tab-btn active" data-tab="telemetry-live">Live</button>
                <button class="std-tab-btn" data-tab="telemetry-stats">Stats</button>
                <button class="std-tab-btn" data-tab="telemetry-settings">Settings</button>
            </div>

            <div id="telemetry-tab-panels">
                <div class="std-tab-panel active" id="tab-telemetry-live">
                    <div class="content-box">
                        <form class="std-form" id="telemetry-filter-form">
                            <div class="form-row">
                                <div class="form-col">
                                    <label>Scope
                                        <select name="scope" class="std-select">
                                            <?php foreach (($pd['scope_options'] ?? []) as $opt): ?>
                                                <option
                                                    value="<?= $opt['value_attr'] ?>"
                                                    <?php if (!empty($opt['selected'])): ?>selected<?php endif; ?>
                                                ><?= $opt['label_html'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label>Source
                                        <select name="source" class="std-select">
                                            <?php foreach (($pd['source_options'] ?? []) as $opt): ?>
                                                <option
                                                    value="<?= $opt['value_attr'] ?>"
                                                    <?php if (!empty($opt['selected'])): ?>selected<?php endif; ?>
                                                ><?= $opt['label_html'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label>Instance
                                        <select name="instance" class="std-select">
                                            <?php foreach (($pd['instance_options'] ?? []) as $opt): ?>
                                                <option
                                                    value="<?= $opt['value_attr'] ?>"
                                                    data-scope="<?= $opt['scope_attr'] ?>"
                                                    <?php if (!empty($opt['selected'])): ?>selected<?php endif; ?>
                                                ><?= $opt['label_html'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label>Schema type
                                        <select name="schema_type" class="std-select">
                                            <?php foreach (($pd['schema_options'] ?? []) as $opt): ?>
                                                <option
                                                    value="<?= $opt['value_attr'] ?>"
                                                    <?php if (!empty($opt['selected'])): ?>selected<?php endif; ?>
                                                ><?= $opt['label_html'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label>Points per bucket
                                        <select name="n" class="std-select">
                                            <?php foreach (($pd['n_options'] ?? []) as $opt): ?>
                                                <option
                                                    value="<?= $opt['value_attr'] ?>"
                                                    <?php if (!empty($opt['selected'])): ?>selected<?php endif; ?>
                                                ><?= $opt['label_html'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-col">
                                    <label>From
                                        <input type="datetime-local" name="from_ts" class="std-input" step="1">
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label>To
                                        <input type="datetime-local" name="to_ts" class="std-input" step="1">
                                    </label>
                                </div>
                                <div class="form-col align-self-end">
                                    <button
                                        type="button"
                                        class="std-btn"
                                        id="telemetry-clear-dates"
                                    >Clear dates</button>
                                </div>
                                <div class="form-col align-self-end">
                                    <button type="submit" class="std-btn" id="telemetry-query-btn">Query</button>
                                </div>
                            </div>
                            <div class="form-row telemetry-options-row">
                                <div class="form-col">
                                    <label class="telemetry-option-label">
                                        <input type="checkbox" id="telemetry-autopoll">
                                        Auto-refresh every
                                        <select
                                            id="telemetry-poll-interval"
                                            class="std-select telemetry-poll-interval"
                                        >
                                            <option value="2000">2s</option>
                                            <option value="5000" selected>5s</option>
                                            <option value="10000">10s</option>
                                            <option value="30000">30s</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-col">
                                    <label class="telemetry-option-label">
                                        <input type="checkbox" id="telemetry-expand-all">
                                        Expand every payload
                                    </label>
                                </div>
                            </div>
                        </form>

                        <div class="telemetry-status" id="telemetry-status"></div>

                        <table class="std-table telemetry-points-table">
                            <thead>
                                <tr>
                                    <th class="telemetry-caret-col"></th>
                                    <th>Time</th>
                                    <th>Scope</th>
                                    <th>Instance</th>
                                    <th>Source</th>
                                    <th>Schema</th>
                                    <th>Kind</th>
                                    <th>Severity</th>
                                </tr>
                            </thead>
                            <tbody id="telemetry-points-body">
                                <tr>
                                    <td colspan="8" class="text-center">Loading&hellip;</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="std-tab-panel" id="tab-telemetry-stats">
                    <div class="content-box">
                        <?php if (empty($stats['available'])): ?>
                            <p class="text-center">No storage stats available.</p>
                        <?php else: ?>

                        <div class="telemetry-gauges">
                            <?php foreach (($stats['gauges'] ?? []) as $gauge): ?>
                                <div class="telemetry-gauge">
                                    <div class="telemetry-gauge-head">
                                        <span class="telemetry-gauge-label"><?= $gauge['label_html'] ?></span>
                                        <span class="telemetry-gauge-value">
                                            <?= $gauge['value_html'] ?>
                                            <span class="telemetry-gauge-cap"><?= $gauge['cap_html'] ?></span>
                                        </span>
                                    </div>
                                    <?php if (!empty($gauge['has_bar'])): ?>
                                        <div class="std-progress std-progress--grow">
                                            <div
                                                class="std-progress-fill <?= $gauge['tone'] ?>"
                                                style="width:<?= $gauge['pct_attr'] ?>%"
                                            ></div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="telemetry-stat-meta">
                            <?php if (!empty($stats['has_bus'])): ?>
                                <span>Delivered by the bus: <strong><?= $stats['delivered_html'] ?></strong></span>
                            <?php endif; ?>
                            <span>
                                Dropped:
                                <strong
                                    class="<?= $stats['dropped_class_attr'] ?>"
                                ><?= $stats['total_dropped_html'] ?></strong>
                            </span>
                            <span>
                                Evicted since start:
                                <strong
                                    class="<?= $stats['evictions_class_attr'] ?>"
                                ><?= $stats['total_evictions_html'] ?></strong>
                            </span>
                        </div>

                        <h2 class="telemetry-h2">Evictions</h2>
                        <?php if (empty($stats['has_evictions'])): ?>
                            <p class="text-center">No producer is over budget.</p>
                        <?php else: ?>
                            <table class="std-table">
                                <thead>
                                    <tr><th>Scope</th><th>Instance</th><th>Evicted</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach (($stats['eviction_rows'] ?? []) as $row): ?>
                                        <tr>
                                            <td><?= $row['scope_html'] ?></td>
                                            <td><?= $row['instance_html'] ?></td>
                                            <td class="<?= $row['class_attr'] ?>"><?= $row['count_html'] ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>

                        <h2 class="telemetry-h2">Drops</h2>
                        <?php if (empty($stats['has_drops'])): ?>
                            <p class="text-center">No drop counters reported.</p>
                        <?php else: ?>
                            <table class="std-table">
                                <thead>
                                    <tr><th>Reason</th><th>Dropped</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach (($stats['drop_rows'] ?? []) as $row): ?>
                                        <tr>
                                            <td><?= $row['key_html'] ?></td>
                                            <td class="<?= $row['class_attr'] ?>"><?= $row['count_html'] ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>

                        <h2 class="telemetry-h2">Sources in storage</h2>
                        <?php if (empty($pd['has_inventory'])): ?>
                            <p class="text-center">Nothing in storage yet.</p>
                        <?php else: ?>
                            <table class="std-table">
                                <thead>
                                    <tr><th>Scope</th><th>Source</th><th>Schema types</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach (($pd['sources_rows'] ?? []) as $row): ?>
                                        <tr>
                                            <td><?= $row['scope_html'] ?></td>
                                            <td><?= $row['source_html'] ?></td>
                                            <td><?= $row['schemas_html'] ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>

                        <?php endif; ?>
                    </div>
                </div>

                <?php
                // Retention defaults and the OTLP export configuration. The read
                // is telemetry:read (same as this page); only the save is gated,
                // so without telemetry:write every field is rendered disabled.
                $set = $pd['settings'] ?? ['has_settings' => false];
                ?>
                <div class="std-tab-panel" id="tab-telemetry-settings">
                    <div class="content-box">
                        <?php if (empty($set['has_settings'])): ?>
                            <p class="text-center">No settings available.</p>
                        <?php else: ?>
                            <form class="std-form" id="telemetry-settings-form" method="post" action="submit.php">
                                <h2 class="telemetry-h2">Retention</h2>
                                <p class="telemetry-note">
                                    Changes apply to the buckets created from now on; the ones already holding
                                    points keep the configuration they were created with.
                                </p>
                                <div class="form-row">
                                    <?php foreach (($set['retention'] ?? []) as $field): ?>
                                        <div class="form-col">
                                            <label><?= $field['label_html'] ?>
                                                <input
                                                    type="number"
                                                    class="std-input"
                                                    name="<?= $field['name_attr'] ?>"
                                                    value="<?= $field['value_attr'] ?>"
                                                    min="<?= $field['min_attr'] ?>"
                                                    max="<?= $field['max_attr'] ?>"
                                                    <?php if (empty($set['can_write'])): ?>disabled<?php endif; ?>
                                                >
                                            </label>
                                            <small class="telemetry-note"><?= $field['hint_html'] ?></small>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <?php if (empty($set['export_reported'])): ?>
                                    <h2 class="telemetry-h2">OTLP export</h2>
                                    <p class="telemetry-note">
                                        This backend does not report OTLP export settings, so only retention is
                                        configurable here.
                                    </p>
                                <?php else: ?>
                                <h2 class="telemetry-h2">OTLP export</h2>
                                <?php if (empty($set['export_available'])): ?>
                                    <div class="std-error-box">
                                        <strong>Export unavailable:</strong>
                                        <div><?= $set['export_available_error_html'] !== ''
                                            ? $set['export_available_error_html']
                                            : 'The OpenTelemetry SDK is not present in this build.' ?></div>
                                    </div>
                                <?php endif; ?>

                                <div class="form-row">
                                    <div class="form-col">
                                        <label class="telemetry-option-label">
                                            <input
                                                type="checkbox"
                                                name="export_enabled"
                                                id="telemetry-export-enabled"
                                                <?php if (!empty($set['export_enabled'])): ?>checked<?php endif; ?>
                                                <?php if (empty($set['can_write']) || empty($set['export_available'])): ?>disabled<?php endif; ?>
                                            >
                                            Enable export to a collector
                                        </label>
                                    </div>
                                    <div class="form-col">
                                        <label>Collector endpoint
                                            <input
                                                type="text"
                                                class="std-input"
                                                name="export_endpoint"
                                                id="telemetry-export-endpoint"
                                                value="<?= $set['export_endpoint_attr'] ?>"
                                                maxlength="2048"
                                                placeholder="http://collector:4318"
                                                <?php if (empty($set['can_write'])): ?>disabled<?php endif; ?>
                                            >
                                        </label>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-col">
                                        <label>Interval (seconds)
                                            <input
                                                type="number"
                                                class="std-input"
                                                name="export_interval_s"
                                                value="<?= $set['export_interval_s_attr'] ?>"
                                                min="1"
                                                max="3600"
                                                <?php if (empty($set['can_write'])): ?>disabled<?php endif; ?>
                                            >
                                        </label>
                                    </div>
                                    <div class="form-col">
                                        <label>Timeout (seconds)
                                            <input
                                                type="number"
                                                class="std-input"
                                                name="export_timeout_s"
                                                value="<?= $set['export_timeout_s_attr'] ?>"
                                                min="1"
                                                max="60"
                                                <?php if (empty($set['can_write'])): ?>disabled<?php endif; ?>
                                            >
                                        </label>
                                    </div>
                                    <div class="form-col">
                                        <label>Service name
                                            <input
                                                type="text"
                                                class="std-input"
                                                name="export_service_name"
                                                value="<?= $set['export_service_name_attr'] ?>"
                                                maxlength="64"
                                                <?php if (empty($set['can_write'])): ?>disabled<?php endif; ?>
                                            >
                                        </label>
                                    </div>
                                    <div class="form-col">
                                        <label>Instance id
                                            <input
                                                type="text"
                                                class="std-input"
                                                name="export_instance_id"
                                                value="<?= $set['export_instance_id_attr'] ?>"
                                                maxlength="255"
                                                placeholder="Automatic"
                                                <?php if (empty($set['can_write'])): ?>disabled<?php endif; ?>
                                            >
                                        </label>
                                        <small class="telemetry-note">
                                            Empty means automatic (the DMI UUID, else a persisted random one).
                                        </small>
                                    </div>
                                </div>

                                <h2 class="telemetry-h2">Export headers</h2>
                                <p class="telemetry-note">
                                    Values come back masked as <code>***</code>. Leave one untouched to keep the
                                    stored value, type a new one to replace it, or remove the row to delete the header.
                                </p>
                                <table class="std-table telemetry-headers-table">
                                    <thead>
                                        <tr>
                                            <th>Header</th>
                                            <th>Value</th>
                                            <th class="telemetry-header-actions-col"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="telemetry-headers-body">
                                        <?php foreach (($set['header_rows'] ?? []) as $row): ?>
                                            <tr class="telemetry-header-row">
                                                <td>
                                                    <input
                                                        type="text"
                                                        class="std-input"
                                                        data-header-key
                                                        value="<?= $row['key_attr'] ?>"
                                                        <?php if (empty($set['can_write'])): ?>disabled<?php endif; ?>
                                                    >
                                                </td>
                                                <td>
                                                    <input
                                                        type="text"
                                                        class="std-input"
                                                        data-header-value
                                                        value="<?= $row['value_attr'] ?>"
                                                        <?php if (empty($set['can_write'])): ?>disabled<?php endif; ?>
                                                    >
                                                </td>
                                                <td>
                                                    <?php if (!empty($set['can_write'])): ?>
                                                        <button type="button" class="std-btn telemetry-header-remove">Remove</button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <?php if (!empty($set['can_write'])): ?>
                                    <button type="button" class="std-btn" id="telemetry-header-add">Add header</button>
                                <?php endif; ?>
                                <?php endif; ?>

                                <div class="text-center telemetry-settings-actions">
                                    <?php if (!empty($set['can_write'])): ?>
                                        <button type="submit" class="std-btn" id="telemetry-settings-save">Save</button>
                                    <?php else: ?>
                                        <p class="telemetry-note">
                                            You need the <code>telemetry:write</code> capability to change these settings.
                                        </p>
                                    <?php endif; ?>
                                </div>
                            </form>

                            <?php $exp = $pd['stats']['exporter'] ?? null; ?>
                            <?php if (is_array($exp) && !empty($exp['present'])): ?>
                                <h2 class="telemetry-h2">Exporter status</h2>
                                <div class="telemetry-stat-meta">
                                    <span>State:
                                        <strong class="<?= $exp['tone'] === 'crit' ? 'telemetry-drop-crit' : '' ?>"><?= $exp['state_html'] ?></strong>
                                    </span>
                                    <?php if (!empty($exp['has_endpoint'])): ?>
                                        <span>Endpoint: <?= $exp['endpoint_html'] ?></span>
                                    <?php endif; ?>
                                    <?php if (!empty($exp['has_instance_id'])): ?>
                                        <span>Instance: <strong><?= $exp['instance_id_html'] ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($exp['last_error_html'] !== ''): ?>
                                    <div class="std-error-box">
                                        <strong>Last error:</strong>
                                        <div><?= $exp['last_error_html'] ?></div>
                                    </div>
                                <?php endif; ?>
                                <?php if ($exp['available_error_html'] !== ''): ?>
                                    <div class="std-error-box">
                                        <strong>Unavailable:</strong>
                                        <div><?= $exp['available_error_html'] ?></div>
                                    </div>
                                <?php endif; ?>
                                <table class="std-table">
                                    <thead><tr><th>Counter</th><th>Value</th></tr></thead>
                                    <tbody>
                                        <?php foreach (($exp['counter_rows'] ?? []) as $row): ?>
                                            <tr>
                                                <td><?= $row['label_html'] ?></td>
                                                <td class="<?= $row['class_attr'] ?>"><?= $row['value_html'] ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php endif; ?>
    </main>
</div>
