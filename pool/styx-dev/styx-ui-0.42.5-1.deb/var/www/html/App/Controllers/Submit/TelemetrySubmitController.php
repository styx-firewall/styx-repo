<?php
/**
 * Controller for the telemetry configuration write path.
 *
 * Wraps the backend's `telemetry.set_settings` (handlers/handler_telemetry.py):
 * a partial payload, merged by the backend over the stored settings. At least
 * one key must be sent.
 *
 * Registered command (SubmitRegistry):
 *   telemetry_set_settings -> setSettings()
 *
 * The read side (telemetry.get_settings) lives in TelemetryRequestController.
 *
 * Writes are strict here on purpose: an unknown key is refused instead of
 * dropped, and a value that is not the type the setting is declared with is
 * refused instead of coerced,a silently dropped key reads as a successful
 * save. Ranges (1..1000000, 0..86400, ...) are the backend's call and its
 * per-key message is surfaced unchanged; this only fixes the types, because the
 * gateway type-checks and a form always yields strings.
 *
 * `export_headers` replaces the stored object wholesale, with one exception the
 * backend keeps: a value equal to the mask `***` preserves what was stored under
 * that key. So the client resends the masked rows untouched; omitting a key
 * deletes that header. The real token never leaves the backend.
 *
 * The change is applied hot: the backend rebuilds the exporter when it saves.
 */
namespace App\Controllers\Submit;

use App\Controllers\BaseController;

class TelemetrySubmitController extends BaseController
{
    /** Keys accepted by the partial settings payload. */
    private const DATA_KEYS = [
        'maxlen',
        'ttl',
        'series_budget_default',
        'export_enabled',
        'export_endpoint',
        'export_headers',
        'export_interval_s',
        'export_timeout_s',
        'export_service_name',
        'export_instance_id',
    ];

    /** Keys the backend declares as integers. */
    private const INT_KEYS = ['maxlen', 'series_budget_default', 'export_interval_s', 'export_timeout_s'];

    /** Keys the backend declares as strings (endpoint and the OTel resource ids). */
    private const STRING_KEYS = ['export_endpoint', 'export_service_name', 'export_instance_id'];

    /**
     * Save a (partial) set of telemetry settings. Omitted keys keep their
     * current value.
     *
     * @param array<string,mixed> $data request body (command/metadata are ignored)
     * @return array<string,mixed>
     */
    public function setSettings(array $data = []): array
    {
        $unknown = $this->unknownFields($data, self::DATA_KEYS);
        if (!empty($unknown)) {
            return $this->baseError('unknown setting(s): ' . implode(', ', $unknown));
        }

        $payload = [];

        foreach (self::INT_KEYS as $key) {
            if (!array_key_exists($key, $data)) {
                continue;
            }
            // JSON hands a number over as int or float; an integer key only
            // accepts one that is whole, because truncating 1.5 would store a
            // different value than the one asked for.
            if (!is_numeric($data[$key]) || (float)$data[$key] != (int)$data[$key]) {
                return $this->baseError("{$key} must be an integer");
            }
            $payload[$key] = (int)$data[$key];
        }

        // ttl is a number (seconds may be fractional), so it is not in INT_KEYS.
        if (array_key_exists('ttl', $data)) {
            if (!is_numeric($data['ttl'])) {
                return $this->baseError('ttl must be a number');
            }
            $payload['ttl'] = (float)$data['ttl'];
        }

        if (array_key_exists('export_enabled', $data)) {
            // Not coerced from a string: `"false"` is truthy, and guessing which
            // one the client meant is how export ends up doing the opposite.
            if (!is_bool($data['export_enabled'])) {
                return $this->baseError('export_enabled must be true or false');
            }
            $payload['export_enabled'] = $data['export_enabled'];
        }

        foreach (self::STRING_KEYS as $key) {
            if (!array_key_exists($key, $data)) {
                continue;
            }
            if (!is_string($data[$key])) {
                return $this->baseError("{$key} must be a string");
            }
            $payload[$key] = $data[$key];
        }

        if (array_key_exists('export_headers', $data)) {
            if (!is_array($data['export_headers'])) {
                return $this->baseError('export_headers must be an object of string values');
            }
            $headers = [];
            foreach ($data['export_headers'] as $name => $value) {
                // JSON object keys are always strings, but PHP coerces a
                // numeric-looking one ("123") to an int on decode; cast it back
                // rather than refuse a header name HTTP allows.
                if ((!is_string($name) && !is_int($name)) || !is_string($value)) {
                    return $this->baseError('export_headers must map string keys to string values');
                }
                $headers[(string)$name] = $value;
            }
            // Cast so an empty map serializes as `{}` and not `[]`.
            $payload['export_headers'] = (object)$headers;
        }

        if (empty($payload)) {
            return $this->baseError('no telemetry settings provided');
        }

        $commands = [
            [
                'method' => 'telemetry.set_settings',
                'id'     => 'set_settings',
                'data'   => (object)$payload,
            ],
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        $cmd = $resp['commands']['set_settings'] ?? null;
        if (!$cmd) {
            return $this->baseError($resp['response_msg'] ?? 'No response for telemetry.set_settings');
        }

        return $cmd;
    }
}
