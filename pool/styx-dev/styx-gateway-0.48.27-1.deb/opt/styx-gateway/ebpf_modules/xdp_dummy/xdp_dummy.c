// SPDX-License-Identifier: GPL-2.0
// xdp_dummy.c - CO-RE XDP module that only counts
//
// Passes every frame and counts what it saw. Nothing about the traffic changes:
// what it is for is the plumbing (load, attach, stack, telemetry, unload) and for
// reading what the modules in front of it are letting through.

#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <xdp/xdp_helpers.h>

// What it saw. Single-entry PERCPU_ARRAY: one slice per CPU, so the datapath
// needs no atomic and userspace sums the slices.
struct stats_t {
    __u64 packets;
    __u64 bytes;
};

struct {
    __uint(type,        BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key,         __u32);
    __type(value,       struct stats_t);
} stats SEC(".maps");

// XDP dispatcher metadata: passive, chain on PASS only and let the next program
// decide (it never returns anything else). Its default priority is 90, which puts
// it after the filters of the usual chain, so what it counts is what they let
// through; a monitor that has to see everything goes before them instead.
// Runtime priority is set from [[pre_attach_param]] (default 90).
struct {
    __uint(priority, 90);
    __uint(XDP_PASS, 1);
} XDP_RUN_CONFIG(xdp_dummy);

// Program

SEC("xdp")
int xdp_dummy(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;
    void *data     = (void *)(long)ctx->data;

    __u32 zero = 0;
    struct stats_t *s = bpf_map_lookup_elem(&stats, &zero);
    if (s) {
        __sync_fetch_and_add(&s->packets, 1);
        __sync_fetch_and_add(&s->bytes, (__u64)(data_end - data));
    }

    return XDP_PASS;
}

char _license[] SEC("license") = "GPL";
