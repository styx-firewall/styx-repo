# xdp_dummy/xdp_dummy_companion.py
#
# Companion for xdp_dummy. Registers the deserializer for its stats telemetry map
# and nothing else: the module has no control maps, so there is nothing to
# serialize and no map entry to format.

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import aggregate_percpu


@register_deserializer("xdp_dummy", "stats")
class StatsDeserializer(FeedbackDeserializer):
    """Aggregates the per-CPU stats array: frames seen and their bytes."""

    def from_map(self, raw, spec, key=None) -> dict:
        totals = aggregate_percpu(raw, ["packets", "bytes"], ["<Q", "Q"])
        return {"packets": totals["packets"], "bytes": totals["bytes"]}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")
