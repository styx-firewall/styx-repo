// SPDX-License-Identifier: GPL-2.0
// ddos_protect.c - per-IP, per-protocol rate limiting via XDP
//
// Drops packets when a source IP exceeds its per-protocol rate, counted both in
// packets and in bytes, each held in a token bucket. Designed to stack with
// net_block (static blocking) on the same interface via libxdp dispatcher.

#ifndef BCC_COMPILE
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_endian.h>
#include <xdp/xdp_helpers.h>

#ifndef ETH_P_IP
#define ETH_P_IP 0x0800
#endif
#endif

// The limiter counts BOTH packets and bytes and drops when either limit is
// crossed, because they protect different resources: packets protect the cost
// of processing each frame, bytes protect the link. A flood of many small
// packets stays under any sane byte limit, and a flood of few large packets
// stays under any sane packet limit, so either counter alone leaves a hole.
//
// The byte defaults are the packet default times a nominal 1500-byte frame, so
// that by default neither binds before the other at MTU size: the byte limit
// only bites first when the average frame is larger than MTU, and the packet
// limit only when it is smaller. Both are meant to be sized per deployment.
//
// The defaults are deliberately generous: a DDoS is orders of magnitude above
// them, and the cost of being tight is cutting traffic that has every right to
// pass. Sized as "what ONE source may do", per 5 s window, which at MTU is
// around 100 Mbit/s and 12k pps for TCP: a SSH session, a screen refresh of a
// remote desktop or a file transfer fit; a flood does not. These are the values
// the operator is expected to tune, not a policy.
#define DEFAULT_TCP_THRESHOLD   60000            // 12000 pps
#define DEFAULT_UDP_THRESHOLD   60000            // 12000 pps
#define DEFAULT_ICMP_THRESHOLD  1000             // 200 pps
#define DEFAULT_TCP_BYTES_THRESHOLD   60000000   // 12 MB/s, the same 100 Mbit/s at MTU
#define DEFAULT_UDP_BYTES_THRESHOLD   45000000   // 9 MB/s: UDP payloads are the small ones
#define DEFAULT_ICMP_BYTES_THRESHOLD  5000000    // 1 MB/s, orders above a ping
// Window and cooldown are configured in MILLISECONDS, not nanoseconds: the
// config map value is a __u32 and 5 s in ns does not fit, so the intended
// 5000000000 was silently truncated to 705032704 (705 ms) and the limiter
// allowed 7x more packets per second than its own documentation promised.
#define DEFAULT_WINDOW_MS       5000     // 5 seconds
#define DEFAULT_COOLDOWN_MS     10000    // 10 seconds between events per IP+proto
// How much of the limit a source may spend in one go. This is the whole point of
// the bucket: with a capacity equal to a full window the bucket hands out the
// same as the old fixed window (measured), so the burst has to be a small
// fraction of the window for the limiter to mean anything. 500 ms is a tenth of
// the window: the burst a normal source does (a screen refresh, a few pings, a
// chunk of a transfer) passes, and the sustained rate is still what the bucket
// refills. The 100 ms this used to be handed out a fiftieth of the limit, which
// for ICMP was two packets: any three pings dropped one.
#define DEFAULT_BURST_MS        500
#define MIN_PKTS_BURST          1        // below one there is nothing to spend
#define MIN_BYTES_BURST         65536    // one maximum-size GSO frame, or no frame fits
#define NS_PER_MS               1000000ULL

// Structs

struct rate_key {
    __u32 src_ip;
    __u8  proto;   // 6=TCP, 17=UDP, 1=ICMP
} __attribute__((packed));

// Token bucket. What used to be here was a fixed window that reset on expiry,
// which leaked twice the configured limit: a source could spend a full quota
// just before the boundary and another just after, and that is 2x for any
// window size (measured, see docs/xdp_virtio_rendimiento.md). It also let the
// whole quota be spent in one go, 20.000 frames in 0,13 s, which is more than
// 130.000 packets per second from a single source.
//
// With a bucket the rate is what refills it and the capacity is the burst
// tolerance, which stops being an accident of where the boundary falls.
//
// Tokens are SIGNED because two CPUs can be processing packets from the same
// source at the same time: a concurrent overspend leaves the bucket negative,
// which reads as "no credit", instead of wrapping an unsigned value into an
// enormous balance. The refill is an atomic add for the same reason; the clamp
// and the timestamp are plain stores, and losing one of those only makes the
// bucket marginally fuller or emptier, never unbounded.
//
// Not packed: the layout is naturally aligned, and the compiler refuses to emit
// atomics on a packed member.
struct rate_bucket {
    __s64 tokens;
    __u64 last_ns;
};

struct rate_entry {
    __u64 last_event_ns;   // cooldown - suppress duplicate events
    __u64 packets_seen;    // cumulative, only for the event payload
    struct rate_bucket pkts;
    struct rate_bucket bytes;
};

struct drop_event_t {
    __u64 ts_ns;
    __u32 src_ip;
    __u32 packet_count;
    __u8  proto;
} __attribute__((packed));

struct stats_t {
    __u64 drops;
    __u64 last_drop_ns;
    __u64 ring_drops;   // events lost to a full ring (reserve returned NULL)
} __attribute__((packed));

// Maps

// Runtime config (adjustable without reload via control-push)
// Key 0: tcp_threshold, 1: udp_threshold, 2: icmp_threshold, 3: window_ms,
// Key 4: cooldown_ms, 5: tcp_bytes_threshold, 6: udp_bytes_threshold,
// 7: icmp_bytes_threshold, 8: burst_ms.
// A value of 0 means unset and the constant default applies (see read_config).
//
// A threshold is the sustained rate: that many per window_ms. The bucket can
// hold only burst_ms worth of that rate at a time, and burst_ms is what bounds
// the burst. With burst_ms equal to the window the bucket would hand out the
// same as the old fixed window, which is why the default is a fraction of it.
struct {
    __uint(type,        BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 16);
    __type(key,         __u32);
    __type(value,       __u32);
} cfg_map SEC(".maps");

// Internal rate-limit tracker (per IP + protocol)
struct {
    __uint(type,        BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, 65536);
    __type(key,         struct rate_key);
    __type(value,       struct rate_entry);
} rate_map SEC(".maps");

// Telemetry
struct {
    __uint(type,        BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key,         __u32);
    __type(value,       struct stats_t);
} stats SEC(".maps");

// Events
struct {
    __uint(type,        BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);
} drop_events SEC(".maps");

// Helpers

// A value of 0 means unset and the default applies. The lookup never fails on
// an ARRAY map - it returns a pointer to a zeroed slot - so without the "> 0"
// check the defaults above were dead code, and a module attached before the
// config was pushed ran with every threshold at 0, which drops everything.
static __always_inline __u32 read_config(__u32 key, __u32 default_val) {
    __u32 *val = bpf_map_lookup_elem(&cfg_map, &key);
    return (val && *val > 0) ? *val : default_val;
}

static __always_inline __u32 get_threshold(__u8 proto) {
    switch (proto) {
    case 6:   // TCP
        return read_config(0, DEFAULT_TCP_THRESHOLD);
    case 17:  // UDP
        return read_config(1, DEFAULT_UDP_THRESHOLD);
    case 1:   // ICMP
        return read_config(2, DEFAULT_ICMP_THRESHOLD);
    default:
        return read_config(0, DEFAULT_TCP_THRESHOLD);  // fallback to TCP
    }
}

static __always_inline __u32 get_bytes_threshold(__u8 proto) {
    switch (proto) {
    case 6:   // TCP
        return read_config(5, DEFAULT_TCP_BYTES_THRESHOLD);
    case 17:  // UDP
        return read_config(6, DEFAULT_UDP_BYTES_THRESHOLD);
    case 1:   // ICMP
        return read_config(7, DEFAULT_ICMP_BYTES_THRESHOLD);
    default:
        return read_config(5, DEFAULT_TCP_BYTES_THRESHOLD);  // fallback to TCP
    }
}

// How much the bucket can hold: the part of the limit that `burst_ms` represents,
// and never less than `floor`. The floor matters: a capacity of zero drops
// everything, because no packet could ever be paid for, and in the byte bucket a
// capacity below one frame would blackhole every frame larger than it.
static __always_inline __u32 bucket_capacity(__u32 limit, __u32 window_ms, __u32 burst_ms,
                                             __u32 floor) {
    if (burst_ms > window_ms)
        burst_ms = window_ms;  // a burst longer than the window is the whole limit
    __u64 cap = (__u64)limit * burst_ms / window_ms;
    return (__u32)(cap < floor ? floor : cap);
}

// Puts into the bucket what has accrued since the last packet and returns the
// credit available. The rate is `limit` per `window_ms`, so the config keys keep
// meaning "N per window" and what changes is the shape; the capacity is what
// bounds the burst, and it is well below the rate times the window on purpose.
static __always_inline __s64 bucket_refill(struct rate_bucket *b, __u32 limit, __u32 capacity,
                                           __u32 window_ms, __u64 now) {
    __u64 elapsed_ms = (now - b->last_ns) / NS_PER_MS;

    if (elapsed_ms >= window_ms) {
        // Quiet for a full window or more: full bucket, and the backlog is
        // dropped rather than accumulated into a larger burst.
        b->tokens = (__s64)capacity;
        b->last_ns = now;
    } else if (elapsed_ms > 0) {
        __u64 add = (__u64)limit * elapsed_ms / window_ms;
        // A slow rate needs several ms per token. If nothing has accrued there
        // is nothing to add and the elapsed time is kept, so the fraction is not
        // thrown away on every packet.
        if (add > 0) {
            __sync_fetch_and_add(&b->tokens, (__s64)add);
            if (b->tokens > (__s64)capacity)
                b->tokens = (__s64)capacity;
            b->last_ns += elapsed_ms * NS_PER_MS;
        }
    }
    return b->tokens;
}

static __always_inline void record_drop(__u64 now) {
    __u32 idx = 0;
    struct stats_t *s = bpf_map_lookup_elem(&stats, &idx);
    if (!s) return;
    // stats is a PERCPU_ARRAY, so each CPU owns its slice: a plain increment is
    // correct and cheaper than an atomic. The atomic was also what the compiler
    // complained about (address of a packed member, unaligned pointer).
    s->drops++;
    s->last_drop_ns = now;
}

// Counts an event that is lost because the ring is full (per-CPU: no atomic).
// libbpf does not report ringbuf losses to userspace, so this counter is
// the only record that they occurred; it is exposed through the "stats" telemetry map.
static __always_inline void count_ring_drop(void) {
    __u32 idx = 0;
    struct stats_t *s = bpf_map_lookup_elem(&stats, &idx);
    if (s)
        s->ring_drops++;
}

// Program

// XDP dispatcher metadata: active filter, chain on PASS only so a drop is final.
// Declaring XDP_DROP as well (which is what this did until 0.4.0, to let a
// monitor behind it see the discarded traffic) hands the packet to the next
// program instead and the limiter stops limiting: measured, a 1000 packet flood
// that it counted as 996 drops arrived at the stack whole. A module placed
// before this one sees all the traffic, one placed after it sees only what
// passes; the order comes from the priority, which is set at load time.
// Runtime priority is set from [[pre_attach_param]] (default 30).
struct {
    __uint(priority, 30);
    __uint(XDP_PASS, 1);
} XDP_RUN_CONFIG(ddos_protect);

SEC("xdp")
int ddos_protect(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;
    void *data     = (void *)(long)ctx->data;

    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end)
        return XDP_PASS;

    if (eth->h_proto != __builtin_bswap16(ETH_P_IP))
        return XDP_PASS;

    struct iphdr *iph = (void *)(eth + 1);
    if ((void *)(iph + 1) > data_end)
        return XDP_PASS;

    __u32 src_ip = iph->saddr;
    __u8  proto  = iph->protocol;
    __u64 now    = bpf_ktime_get_ns();
    // Frame length as the driver delivered it. It feeds the byte counter, so it
    // is 32 bits and not 16: a GSO super-frame can be larger than 65535 bytes.
    __u32 pkt_len = (__u32)(data_end - data);

    __u32 threshold       = get_threshold(proto);
    __u32 bytes_threshold = get_bytes_threshold(proto);
    __u32 window_ms       = read_config(3, DEFAULT_WINDOW_MS);
    __u32 burst_ms        = read_config(8, DEFAULT_BURST_MS);
    __u32 pkts_cap  = bucket_capacity(threshold, window_ms, burst_ms, MIN_PKTS_BURST);
    __u32 bytes_cap = bucket_capacity(bytes_threshold, window_ms, burst_ms, MIN_BYTES_BURST);

    struct rate_key key = {.src_ip = src_ip, .proto = proto};
    struct rate_entry *entry = bpf_map_lookup_elem(&rate_map, &key);

    if (entry) {
        __sync_fetch_and_add(&entry->packets_seen, 1);

        // Both buckets are checked before either is charged, so a source that is
        // over one limit does not also drain the other one. They guard different
        // resources (see the note on the defaults above).
        __s64 pkts_left  = bucket_refill(&entry->pkts, threshold, pkts_cap, window_ms, now);
        __s64 bytes_left = bucket_refill(&entry->bytes, bytes_threshold, bytes_cap, window_ms, now);

        if (pkts_left < 1 || bytes_left < (__s64)pkt_len) {
            record_drop(now);

            // Cooldown: at most one event per IP+proto per cooldown_ns
            __u64 cooldown_ns = (__u64)read_config(4, DEFAULT_COOLDOWN_MS) * NS_PER_MS;
            if (now - entry->last_event_ns >= cooldown_ns) {
                entry->last_event_ns = now;
                struct drop_event_t *ev = bpf_ringbuf_reserve(&drop_events, sizeof(struct drop_event_t), 0);
                if (ev) {
                    ev->ts_ns  = now;
                    ev->src_ip = src_ip;
                    // Cumulative since the entry was created, not per window: the
                    // bucket has no window to report a count for.
                    ev->packet_count = entry->packets_seen > 0xFFFFFFFFu
                                           ? 0xFFFFFFFFu
                                           : (__u32)entry->packets_seen;
                    ev->proto = proto;
                    bpf_ringbuf_submit(ev, 0);
                } else {
                    count_ring_drop();
                }
            }
            return XDP_DROP;
        }

        // Only what passes is charged.
        __sync_fetch_and_add(&entry->pkts.tokens, -1);
        __sync_fetch_and_add(&entry->bytes.tokens, -(__s64)pkt_len);
    } else {
        // A source seen for the first time starts with a full bucket, which is
        // the same allowance the old first window gave it, capped at the burst.
        struct rate_entry new_entry = {
            .pkts  = {.tokens = (__s64)pkts_cap, .last_ns = now},
            .bytes = {.tokens = (__s64)bytes_cap, .last_ns = now},
        };
        bpf_map_update_elem(&rate_map, &key, &new_entry, BPF_ANY);
    }

    return XDP_PASS;
}

char _license[] SEC("license") = "GPL";
