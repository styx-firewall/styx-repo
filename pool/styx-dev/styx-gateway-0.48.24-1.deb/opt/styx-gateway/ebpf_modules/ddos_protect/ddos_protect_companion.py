# modules/ddos_protect/ddos_protect_companion.py

import ctypes

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import serialize_uint32, format_uint32, ktime_to_epoch, u32_to_ip

# Companion API

_PROTO_LABELS = {1: "ICMP", 6: "TCP", 17: "UDP"}

_SERIALIZERS = {"cfg_map": serialize_uint32}
_FORMATTERS = {"cfg_map": format_uint32}


def serialize_entry(items, map_name, op):
    try:
        handler = _SERIALIZERS[map_name]
    except KeyError:
        raise ValueError(f"Map '{map_name}' does not support push")
    return [handler(item) for item in items]


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# C struct mirrors


class StatsT(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("drops", ctypes.c_uint64),
        ("last_drop_ns", ctypes.c_uint64),
        ("ring_drops", ctypes.c_uint64),
    ]


class DropEventT(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("ts_ns", ctypes.c_uint64),
        ("src_ip", ctypes.c_uint32),
        ("packet_count", ctypes.c_uint32),
        ("proto", ctypes.c_uint8),
    ]


# Telemetry / Event deserializers


@register_deserializer("ddos_protect", "stats")
class StatsDeserializer(FeedbackDeserializer):
    # Same as net_block: `drops` and `ring_drops` are counters and add up across
    # CPUs, `last_drop` is a timestamp and the newest one wins.
    absolute_fields = ("last_drop",)

    def from_map(self, raw, spec, key=None) -> dict:
        s = StatsT.from_buffer_copy(bytes(raw))
        return {"drops": s.drops, "last_drop": ktime_to_epoch(s.last_drop_ns), "ring_drops": s.ring_drops}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("stats is a telemetry map, not an event buffer")


@register_deserializer("ddos_protect", "drop_events")
class DropEventDeserializer(FeedbackDeserializer):
    def from_map(self, raw, spec, key=None) -> dict:
        raise NotImplementedError("drop_events is an event buffer, not a telemetry map")

    def from_event(self, data: bytes, size: int, spec) -> dict:
        e = DropEventT.from_buffer_copy(data[:size])
        return {
            "ts_ns": e.ts_ns,
            # u32_to_ip, not IPv4Address(e.src_ip): the field holds the address
            # as it sits in the packet (network order), so the int a c_uint32
            # gives back is that sequence backwards.
            "src_ip": u32_to_ip(e.src_ip),
            "packet_count": e.packet_count,
            "proto": _PROTO_LABELS.get(e.proto, str(e.proto)),
        }
