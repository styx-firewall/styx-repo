// SPDX-License-Identifier: GPL-2.0
// ping_monitor.c - XDP ICMP echo request/reply monitor with flood detection.

#ifndef BCC_COMPILE
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_endian.h>
#include <xdp/xdp_helpers.h>
#else
#include <uapi/linux/if_ether.h>
#include <uapi/linux/ip.h>
#include <uapi/linux/icmp.h>
#include <uapi/linux/in.h>
#endif

#define DEFAULT_THRESHOLD 100
#define DEFAULT_WINDOW_MS 1000 // 1 second
#define NS_PER_MS         1000000ULL

struct icmp_stats_t {
    __u64 requests;        // cumulative, for display
    __u64 replies;         // cumulative, for display
    __u64 bytes;           // cumulative, for display
    __u64 last_alert_ns;   // when this IP last raised an alert
    __u64 window_start_ns; // start of the current counting window
    __u64 window_requests; // requests seen in the current window (flood check)
};

struct totals_t {
    __u64 floods;      // offset 0 - verifier-tested
    __u64 requests;
    __u64 replies;
    __u64 ring_drops;  // alerts lost to a full ring (reserve returned NULL)
};

// Must match ping_monitor_companion.py FloodAlertDeserializer struct layout
struct alert_t {
    __u32 src_ip;
    __u64 requests;
} __attribute__((packed));

// Per-IP ICMP statistics.
//
// A shared map, not PERCPU: the flood threshold is a per-IP count, and a
// per-CPU counter cannot be summed from the datapath, so the check used to
// compare one CPU's slice against the limit while the UI showed the sum of all
// of them - with N CPUs the effective threshold was N times the configured one.
// LRU so a spoofed source cannot exhaust the key space.
struct {
    __uint(type, BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, 65536);
    __type(key, __u32);
    __type(value, struct icmp_stats_t);
} icmp_stats SEC(".maps");

// Global counters exposed as telemetry (plain ARRAY, one atomic per ICMP packet).
struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 1);
    __type(key, __u32);
    __type(value, struct totals_t);
} totals SEC(".maps");

// Configuration: key 0 = threshold (requests per window), key 1 = window in ms.
// A value of 0 means unset and the constant default is used. The config is
// pushed from module.toml, so the datapath never writes to this map: it used to
// write the default back on every ICMP packet while the key was unset.
struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 2);
    __type(key, __u32);
    __type(value, __u32);
} cfg SEC(".maps");

// Ring buffer for flood alerts.
struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);
} flood_alert SEC(".maps");

static __always_inline __u32 read_config(__u32 key, __u32 default_val) {
    __u32 *val = bpf_map_lookup_elem(&cfg, &key);
    return (val && *val > 0) ? *val : default_val;
}

static __always_inline int is_icmp_echo(__u8 type) {
    return type == 8 || type == 0;
}

// XDP dispatcher metadata: passive monitor - run last, always chain on XDP_PASS.
// The value here is only the fallback for a hand attach: the gateway overrides
// it with the [[pre_attach_param]] from module.toml, which is the single source
// of truth (see docs/EBPF_DESIGN.md - lower priority values run first).
struct {
    __uint(priority, 50);
    __uint(XDP_PASS, 1);
} XDP_RUN_CONFIG(ping_monitor);

SEC("xdp")
int ping_monitor(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;
    void *data     = (void *)(long)ctx->data;

    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end) return XDP_PASS;
    if (eth->h_proto != bpf_htons(0x0800)) return XDP_PASS;

    struct iphdr *ip = (void *)(eth + 1);
    if ((void *)(ip + 1) > data_end) return XDP_PASS;
    if (ip->protocol != IPPROTO_ICMP) return XDP_PASS;

    struct icmphdr *icmp = (void *)((void *)ip + (ip->ihl * 4));
    if ((void *)(icmp + 1) > data_end) return XDP_PASS;
    if (!is_icmp_echo(icmp->type)) return XDP_PASS;

    __u32 src_ip = ip->saddr;
    // __u32 and not __u16: a frame can be larger than 65535 bytes (a GSO
    // super-frame arrives that way), and this feeds the byte counter, so a
    // truncation corrupts the accounting instead of just wrapping a display.
    __u32 pkt_len = (__u32)(data_end - data);
    __u8 is_request = (icmp->type == 8);

    // Per-IP stats - LRU_HASH needs an explicit init on first sight of each IP
    struct icmp_stats_t zero_val = {};
    struct icmp_stats_t *entry = bpf_map_lookup_elem(&icmp_stats, &src_ip);
    if (!entry) {
        bpf_map_update_elem(&icmp_stats, &src_ip, &zero_val, BPF_NOEXIST);
        entry = bpf_map_lookup_elem(&icmp_stats, &src_ip);
    }
    if (entry) {
        if (is_request) __sync_fetch_and_add(&entry->requests, 1);
        else            __sync_fetch_and_add(&entry->replies, 1);
        __sync_fetch_and_add(&entry->bytes, pkt_len);
    }

    // Global totals + flood detection
    __u32 zero = 0;
    struct totals_t *tot = bpf_map_lookup_elem(&totals, &zero);
    if (tot) {
        if (is_request) __sync_fetch_and_add(&tot->requests, 1);
        else            __sync_fetch_and_add(&tot->replies, 1);

        if (entry && is_request) {
            __u32 limit = read_config(0, DEFAULT_THRESHOLD);
            __u64 window_ns = (__u64)read_config(1, DEFAULT_WINDOW_MS) * NS_PER_MS;
            __u64 now_ns = bpf_ktime_get_ns();

            // Fixed window: the count resets on expiry, so the condition is
            // "more than the limit in THIS window" and an IP that stops
            // flooding stops alerting. A counter that never reset made an IP
            // that ever crossed the limit alert once per second for the rest of
            // the entry's life.
            if (now_ns - entry->window_start_ns >= window_ns) {
                entry->window_start_ns = now_ns;
                entry->window_requests = 0;
            }
            __sync_fetch_and_add(&entry->window_requests, 1);

            // last_alert_ns is both the display field and the gate: at most one
            // alert burst per window per IP, which is what stops the ring from
            // filling as soon as the limit is crossed and stays crossed.
            if (entry->window_requests > limit &&
                now_ns - entry->last_alert_ns >= window_ns) {
                entry->last_alert_ns = now_ns;
                __sync_fetch_and_add(&tot->floods, 1);
                struct alert_t *a;
                a = bpf_ringbuf_reserve(&flood_alert, sizeof(*a), 0);
                if (a) {
                    a->src_ip = src_ip;
                    a->requests = entry->window_requests;
                    bpf_ringbuf_submit(a, 0);
                } else {
                    // Ring full: the alert is lost. libbpf does not report it, so
                    // it is counted here (shared map -> atomic increment) and
                    // surfaces through the "totals" telemetry map.
                    __sync_fetch_and_add(&tot->ring_drops, 1);
                }
            }
        }
    }

    return XDP_PASS;
}

char _license[] SEC("license") = "GPL";
