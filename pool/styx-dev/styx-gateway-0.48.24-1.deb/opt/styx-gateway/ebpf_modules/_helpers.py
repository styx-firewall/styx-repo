"""Helper library for eBPF module companions.

Module authors import the functions they need instead of reimplementing
common BPF map type conversions in every companion.

Usage::

    from _helpers import serialize_ipv4, serialize_cidr, serialize_uint32
    from _helpers import format_ipv4, format_cidr, format_uint32
    from _helpers import ktime_to_epoch

    _SERIALIZERS = {"blocklist": serialize_ipv4, "cidr_rules": serialize_cidr}
    _FORMATTERS = {"blocklist": format_ipv4, "cidr_rules": format_cidr}

    def serialize_entry(items, map_name, op):
        return [_SERIALIZERS[map_name](item) for item in items]

    def format_map_entry(key, value, map_name):
        return _FORMATTERS[map_name](key, value)
"""

import ctypes
import ipaddress
import struct as _struct
import time as _time
from typing import Any

# bpf_ktime_get_ns() returns nanoseconds since boot (CLOCK_MONOTONIC).
# Convert to Unix epoch so frontends can display relative times correctly.
_BOOT_EPOCH_S = _time.time() - _time.CLOCK_MONOTONIC


def ktime_to_epoch(ktime_ns: int) -> float | None:
    """Convert ``bpf_ktime_get_ns()`` to Unix epoch seconds, or ``None`` if zero."""
    if ktime_ns == 0:
        return None
    return _BOOT_EPOCH_S + (ktime_ns / 1_000_000_000.0)


#
# High-level serializers  (Python value → (key_ctypes, value_ctypes) tuple)
#


def serialize_ipv4(item: Any) -> tuple[ctypes.Structure, ctypes.Structure]:
    """``"1.2.3.4"`` or ``{"ip": "1.2.3.4"}`` → ``(c_uint32, c_uint8)``.

    The address goes in as network byte order, which is what the datapath looks
    up: these maps are keyed with the packet's source address as it sits in
    memory (``iph->saddr``, no byte swap). On a little-endian host that u32 is
    not the numeric form of the address -- 10.50.0.2 is stored as 0x0200320a --
    and storing the numeric form instead means the lookup never matches, so the
    module silently stops filtering.
    """
    if isinstance(item, dict):
        item = item.get("ip", item)
    return (ctypes.c_uint32(ip_to_u32(str(ipaddress.IPv4Address(item)))), ctypes.c_uint8(1))


def serialize_uint32(item: Any) -> tuple[ctypes.Structure, ctypes.Structure]:
    """``100``, ``{"value": 100}`` or ``{"key": 0, "value": 100}`` → ``(c_uint32, c_uint32)``."""
    if isinstance(item, dict) and "value" in item:
        return (ctypes.c_uint32(item.get("key", 0)), ctypes.c_uint32(item["value"]))
    val = int(item)
    return (ctypes.c_uint32(val), ctypes.c_uint32(val))


# CIDR helpers


class _LpmKey(ctypes.Structure):
    """ctypes mirror of ``struct lpm_key { u32 prefixlen; u32 addr; }``."""

    _fields_ = [("prefixlen", ctypes.c_uint32), ("addr", ctypes.c_uint32)]


def serialize_cidr(item: Any) -> tuple[ctypes.Structure, ctypes.Structure]:
    """``"10.0.0.0/8"`` or ``{"cidr": "10.0.0.0/8"}`` → ``(_LpmKey, c_uint8)``.

    Same byte order as ``serialize_ipv4``: an LPM trie compares the address
    bytes from their most significant bit, and the datapath fills the key with
    the packet's address as it sits in memory, so the prefix has to go in as
    network byte order too.
    """
    if isinstance(item, dict):
        item = item.get("cidr", item)
    net = ipaddress.IPv4Network(item, strict=False)
    return (_LpmKey(prefixlen=net.prefixlen, addr=ip_to_u32(str(net.network_address))), ctypes.c_uint8(1))


#
# High-level formatters  (raw bytes → (key_repr, value_repr) JSON-safe)
#


def format_ipv4(key: bytes, value: Any) -> tuple[str, Any]:
    """u32 bytes + u8 bytes → ``("1.2.3.4", 1)``. Inverse of ``serialize_ipv4``."""
    return (u32_to_ip(_key_bytes(key)), int(value) if value is not None else None)


def format_uint32(key: bytes, value: Any) -> tuple[int, Any]:
    """u32 bytes + u32 bytes → ``(0, 100)``."""
    k = _struct.unpack("<I", key)[0] if isinstance(key, bytes) else int(key)
    v = _struct.unpack("<I", value)[0] if isinstance(value, bytes) else int(value) if value is not None else None
    return (k, v)


def format_cidr(key: bytes, value: Any) -> tuple[str, Any]:
    """``struct lpm_key`` bytes + u8 → ``("10.0.0.0/8", 1)``. Inverse of ``serialize_cidr``."""
    if isinstance(key, bytes):
        prefixlen = _struct.unpack("<I", key[:4])[0]
        addr = ipaddress.IPv4Address(key[4:8])
    else:
        prefixlen, addr = key.prefixlen, ipaddress.IPv4Address(_key_bytes(key.addr))
    return (str(ipaddress.IPv4Network((addr, prefixlen), strict=False)), int(value) if value is not None else None)


def _key_bytes(key: Any) -> bytes:
    """A key holding an IPv4 address, as its four network-order bytes.

    Keys read from the kernel arrive as bytes already; an int (what ``bpftool
    -j`` prints, for instance) is the little-endian reading of those same bytes
    on a little-endian host.
    """
    if isinstance(key, (bytes, bytearray)):
        return bytes(key[:4])
    return int(key).to_bytes(4, "little")


#
# Low-level helpers  (for custom types that need manual assembly)
#


def u32_to_ip(raw: Any) -> str:
    """An IPv4 address written by the kernel → dotted-quad string.

    Accepts either the raw 4 bytes (a map key, an event field) or the int those
    bytes read as on a little-endian host (what a ``c_uint32`` field of a struct
    read out of a buffer gives you). The datapath stores the address the way it
    arrives in the packet, so the four bytes are in network order and the int is
    that sequence backwards: 192.168.1.3 arrives as 0x0301a8c0.

    Both forms are accepted on purpose: printing the int directly
    (``str(IPv4Address(value))``) is the mistake this hides, and it shows the
    address reversed -- how an operator ends up blocklisting the wrong host.
    """
    if isinstance(raw, (bytes, bytearray)):
        return str(ipaddress.IPv4Address(bytes(raw[:4])))
    return str(ipaddress.IPv4Address(int(raw).to_bytes(4, "little")))


def ip_to_u32(ip_str: str) -> int:
    """Dotted-quad string → the u32 the datapath sees for that address.

    The four bytes go in network order, so on a little-endian host the value
    reads swapped from the numeric form of the address (10.50.0.2 →
    0x0200320a). This is what a map keyed on ``iph->saddr`` needs, and it is not
    the same as ``int(IPv4Address(ip_str))``. ``ip_to_u32_be`` gives those same
    four bytes packed for a map that takes a byte array.
    """
    return _struct.unpack("<I", ipaddress.IPv4Address(ip_str).packed)[0]


def ip_to_u32_be(ip_str: str) -> bytes:
    """Dotted-quad string → 4-byte big-endian (network byte order)."""
    return _struct.pack(">I", int(ipaddress.IPv4Address(ip_str)))


def unpack_struct(raw: bytes, field_names: list[str], field_formats: list[str]) -> dict[str, Any]:
    """Unpack raw bytes into a dict using struct format strings.

    Only the first format needs a byte-order prefix (``<`` or ``>``); subsequent
    prefixes are stripped automatically.
    """
    fmt = field_formats[0]
    for f in field_formats[1:]:
        fmt += f.lstrip("<>@=!")
    values = _struct.unpack(fmt, raw)
    return dict(zip(field_names, values))


def pack_struct(fields: dict[str, Any], field_names: list[str], field_formats: list[str]) -> bytes:
    """Pack a dict of values into raw bytes using struct format strings."""
    fmt = field_formats[0]
    for f in field_formats[1:]:
        fmt += f.lstrip("<>@=!")
    return _struct.pack(fmt, *(fields[n] for n in field_names))


def bytes_to_int(raw: bytes, byte_order: str = "little") -> int:
    """1/2/4/8-byte buffer → integer."""
    return int.from_bytes(raw, byte_order)


def int_to_bytes(val: int, size: int, byte_order: str = "little") -> bytes:
    """Integer → byte buffer."""
    return val.to_bytes(size, byte_order)


def aggregate_percpu(per_cpu_values, field_names: list[str], field_formats: list[str]) -> dict[str, int]:
    """Sum struct fields across per-CPU slices.

    BPF PERCPU maps return one raw byte slice per CPU. This helper unpacks
    each slice and sums every field, returning a single dict of totals.
    """
    slices = per_cpu_values if isinstance(per_cpu_values, list) else [per_cpu_values]
    totals: dict[str, int] = {name: 0 for name in field_names}
    for s in slices:
        cpu = unpack_struct(s, field_names, field_formats)
        for name in field_names:
            totals[name] += cpu[name]
    return totals


def raw_to_hex(raw: Any) -> Any:
    """Convert raw bytes to hex string or list of ints (JSON-safe fallback)."""
    if raw is None:
        return None
    if isinstance(raw, (int, float, str, bool)):
        return raw
    if isinstance(raw, bytes):
        return raw.hex() if len(raw) <= 32 else list(raw)
    return str(raw)
