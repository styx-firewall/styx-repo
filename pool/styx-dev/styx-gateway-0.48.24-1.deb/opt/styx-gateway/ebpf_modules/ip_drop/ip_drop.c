// SPDX-License-Identifier: GPL-2.0
// ip_drop.c - CO-RE XDP IP-based packet dropper
//
// Drops all packets from IPv4 addresses in the blocklist.
// Designed to stack with other XDP modules on the same interface
// via libxdp dispatcher.

#ifndef BCC_COMPILE
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_endian.h>
#include <xdp/xdp_helpers.h>

#ifndef ETH_P_IP
#define ETH_P_IP 0x0800
#endif
#endif

// Maps

// Blocklist: source IP → 1 (drop) or 0 (pass)
struct {
    __uint(type,        BPF_MAP_TYPE_HASH);
    __uint(max_entries, 1024);
    __type(key,         __u32);   // IPv4 address (network byte order)
    __type(value,       __u8);    // 1 = drop, 0 = pass
} blocklist SEC(".maps");

// Stats: single-entry PERCPU_ARRAY, only dropped counter
struct stats_t {
    __u64 dropped;
};

struct {
    __uint(type,        BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key,         __u32);
    __type(value,       struct stats_t);
} stats SEC(".maps");

// XDP dispatcher metadata

// Active filter, chain on PASS only so a drop is final. Declaring XDP_DROP as
// well (which is what this did until 0.2.0, "so downstream programs still see
// the decision") hands the packet to the next program instead and the block
// stops blocking: with any other module in the chain, every address in the
// blocklist is let through. A module placed before this one sees all the
// traffic, one placed after it sees only what passes; the order comes from the
// priority, which is set at load time.
struct {
    __uint(priority, 90);
    __uint(XDP_PASS, 1);
} XDP_RUN_CONFIG(ip_drop);

// Program

SEC("xdp")
int ip_drop(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;
    void *data     = (void *)(long)ctx->data;

    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end)
        return XDP_PASS;

    // Only process IPv4
    if (eth->h_proto != __builtin_bswap16(ETH_P_IP))
        return XDP_PASS;

    struct iphdr *iph = (void *)(eth + 1);
    if ((void *)(iph + 1) > data_end)
        return XDP_PASS;

    __u32 src_ip = iph->saddr;
    __u8 *action = bpf_map_lookup_elem(&blocklist, &src_ip);

    __u32 zero = 0;
    struct stats_t *s = bpf_map_lookup_elem(&stats, &zero);

    if (action && *action) {
        if (s)
            __sync_fetch_and_add(&s->dropped, 1);
        return XDP_DROP;
    }

    return XDP_PASS;
}

char _license[] SEC("license") = "GPL";
