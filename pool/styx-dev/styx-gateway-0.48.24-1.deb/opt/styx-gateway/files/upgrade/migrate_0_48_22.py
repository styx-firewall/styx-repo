"""
Migration script: -> 0.48.22

Flattens the features_state datastore entry. Feature options used to be stored
under the section they were listed in:

    {"core_features": {"options": {"tc": true}, "option_errors": {"tc": "..."}}}

Sections are presentation only (an option can be moved to another section
without changing any gate), so the state is now keyed by option:

    {"selected": {"tc": true}, "errors": {"tc": "..."}}

Option keys do not change, so an option the user had enabled stays enabled no
matter which section it is listed under now. The old section entries are
dropped: they carry no information the flat state does not have. Option keys
that are no longer in the config are dropped too, so state that has been
accumulating since a key was renamed does not stay forever.
"""

from constants.datastore_keys import DS_KEY_FEATURES_STATE
from core.app_context import AppContext
from services.features.features_config import FEATURES

TAG = "[MIGRATE 0.48.22]"
STORE = "startup-config"

_KNOWN_OPTIONS = {opt.get("key") for feat in FEATURES for opt in feat.get("options", [])}


def run(ctx: AppContext) -> bool:
    """Flatten features_state from section-keyed to option-keyed state."""
    logger = ctx.get_logger()
    ds = ctx.get_datastore()
    state = ds.get_data(DS_KEY_FEATURES_STATE, store=STORE) or {}

    if not isinstance(state, dict) or not state:
        logger.notice(f"{TAG} No features_state entry to migrate.")
        return True

    logger.notice(f"{TAG} Migration started.")

    # Keep whatever is already flat: the migration may run over a partially
    # migrated state (for instance if a box ran the bootstrap before this).
    selected = state.get("selected")
    errors = state.get("errors")
    flat = {
        "selected": dict(selected) if isinstance(selected, dict) else {},
        "errors": dict(errors) if isinstance(errors, dict) else {},
    }

    moved = 0
    for section, entry in state.items():
        if section in ("selected", "errors") or not isinstance(entry, dict):
            continue
        options = entry.get("options")
        if isinstance(options, dict):
            flat["selected"].update(options)
            moved += len(options)
        option_errors = entry.get("option_errors")
        if isinstance(option_errors, dict):
            flat["errors"].update(option_errors)

    # Drop state for options that no longer exist in the config
    stale = [key for key in list(flat["selected"]) + list(flat["errors"]) if key not in _KNOWN_OPTIONS]
    for key in stale:
        flat["selected"].pop(key, None)
        flat["errors"].pop(key, None)

    if not ds.replace_data(DS_KEY_FEATURES_STATE, flat, store=STORE):
        logger.error(f"{TAG} Migration failed could not write features_state.")
        return False

    logger.notice(
        f"{TAG} Migration completed {moved} option state(s) moved, "
        f"{len(stale)} stale key(s) dropped, {len(flat['errors'])} recorded error(s) kept."
    )
    return True
