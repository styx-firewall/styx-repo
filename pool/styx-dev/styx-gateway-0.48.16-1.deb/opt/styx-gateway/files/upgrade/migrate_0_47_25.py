"""
Migration script: -> 0.47.25

Installs conntrack (userspace CLI for the conntrack tables: `conntrack -L`,
`conntrack -E`, ...). The kernel side (nf_conntrack) and the daemon
(conntrackd) are already handled elsewhere; this only pulls in the tool.

Uses the SystemPackages service for installation, which handles apt-get
locking, non-interactive mode, and proper error reporting.
"""

from core.app_context import AppContext
from services.system_packages import SystemPackages

TAG = "[MIGRATE 0.47.25]"
PACKAGE = "conntrack"


def run(ctx: AppContext) -> bool:
    """Ensure conntrack is installed via the SystemPackages service."""
    logger = ctx.get_logger()
    logger.notice(f"{TAG} Migration started -- ensuring {PACKAGE} is installed.")

    # refresh_cache=False: el MemoryDataStore aún no existe durante el upgrade
    result = SystemPackages.install_package(ctx, PACKAGE, refresh_cache=False)

    if result.get("status") == "success":
        logger.notice(f"{TAG} Migration completed -- {PACKAGE} installed successfully.")
        return True

    logger.error(f"{TAG} Migration failed -- could not install {PACKAGE}: " f"{result.get('message', 'unknown error')}")
    return False
