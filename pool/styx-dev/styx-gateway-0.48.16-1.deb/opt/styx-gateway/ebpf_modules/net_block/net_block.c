// SPDX-License-Identifier: GPL-2.0
// net_block.c - eBPF module compatible with ebpf-app
//
// Compilar:
//   clang -O2 -g -target bpf \
//         -D__TARGET_ARCH_x86 \
//         -I/usr/include/bpf \
//         -c net_block.c -o net_block.o

// 1. CO-RE headers
// vmlinux.h holds every kernel type on this host.
// Generate it with: bpftool btf dump file /sys/kernel/btf/vmlinux format c > vmlinux.h
// The developer generates it on their build machine; CO-RE takes care of
// relocating the offsets when loaded into the target kernel.
// BCC auto-provides its own BPF helpers - the signatures differ from
// libbpf's bpf_helper_defs.h (BCC 0.31 uses int, modern libbpf uses long).
// The BccBackend passes -DBCC_COMPILE so we skip the conflicting headers.
#ifndef BCC_COMPILE
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_core_read.h>   // BPF_CORE_READ, bpf_core_field_exists, etc.
#include <bpf/bpf_endian.h>      // bpf_ntohs, bpf_htonl

// vmlinux.h carries BTF types only, not macros - define TC constants manually.
#ifndef TC_ACT_OK
#define TC_ACT_OK 0
#endif
#ifndef TC_ACT_SHOT
#define TC_ACT_SHOT 2
#endif
#ifndef ETH_P_IP
#define ETH_P_IP 0x0800
#endif
#endif  // BCC_COMPILE


// 2. Data structs
// RULE: struct names must match value_type / struct_name
//         declared in module.toml so the app can auto-generate
//         the deserializers via FieldSpec.

// Value of the stats map (toml: value_type = "struct stats_t")
struct stats_t {
    __u64 hits;         // toml field: name="hits"      bpf_type="u64"
    __u64 drops;        // toml field: name="drops"     bpf_type="u64"
    __u64 bytes_seen;   // toml field: name="bytes_seen" bpf_type="u64"
    __u64 last_seen_ns; // toml field: name="last_seen_ns" bpf_type="u64"
    __u64 ring_drops;   // events lost to a full ring (reserve returned NULL)
} __attribute__((packed));  // packed avoids hidden padding that would confuse ctypes

// Event emitted to the ring buffer (toml: struct_name = "event_t")
struct event_t {
    __u64 ts_ns;    // toml field: name="ts_ns"  bpf_type="u64"  unit="ns"
    __u32 src_ip;   // toml field: name="src_ip" bpf_type="u32"  unit="ipv4"
    __u32 dst_ip;   // toml field: name="dst_ip" bpf_type="u32"  unit="ipv4"
    __u16 dport;    // toml field: name="dport"  bpf_type="u16"  unit="port"
    __u8  proto;    // toml field: name="proto"  bpf_type="u8"   unit="count"
    __u8  action;   // toml field: name="action" bpf_type="u8"   unit="count"
} __attribute__((packed));


// 3. Map definitions
// CRITICAL RULE: the C variable name = name in module.toml.
// libbpf identifies maps by name in the ELF.
// If the name differs, the app will not find the map when doing bpf_obj["blocklist"].

// control_map: name="blocklist" data_type="ipv4" key_schema="u32" value_schema="u8"
struct {
    __uint(type,        BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, 65536);   // = max_entries in toml
    __type(key,         __u32);   // = key_schema "u32"
    __type(value,       __u8);    // = value_schema "u8"
} blocklist SEC(".maps");         // <- "blocklist" name must match toml

// control_map: name="cidr_rules" data_type="cidr_v4"
// LPM_TRIE requires key with prefixlen + data
struct lpm_key {
    __u32 prefixlen;
    __u32 addr;
};
struct {
    __uint(type,        BPF_MAP_TYPE_LPM_TRIE);
    __uint(max_entries, 4096);
    __uint(map_flags,   BPF_F_NO_PREALLOC);
    __type(key,         struct lpm_key);
    __type(value,       __u8);
} cidr_rules SEC(".maps");

// control_map: name="config" data_type="uint32"
// known indices: CONFIG_ENABLED=0, CONFIG_LOG_LEVEL=1
// (renamed to cfg_map to avoid collision with struct config_s from vmlinux.h)
struct {
    __uint(type,        BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 16);
    __type(key,         __u32);
    __type(value,       __u32);
} cfg_map SEC(".maps");

// telemetry_map: name="stats" value_type="struct stats_t"
// PERCPU: each CPU keeps its own counter -> no contention, the app sums them
struct {
    __uint(type,        BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);      // a single entry, index 0
    __type(key,         __u32);
    __type(value,       struct stats_t);
} stats SEC(".maps");

// event: name="blocked_events" buffer_type="ring_buffer"
struct {
    __uint(type,        BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);  // 256 KB ring buffer
} blocked_events SEC(".maps");


// 4. Internal helpers

// Checks whether an IP is in blocklist (exact hash)
static __always_inline int is_blocked_exact(__u32 ip) {
    return bpf_map_lookup_elem(&blocklist, &ip) != NULL;
}

// Checks whether an IP falls into any CIDR of cidr_rules (LPM)
static __always_inline int is_blocked_cidr(__u32 ip) {
    struct lpm_key key = { .prefixlen = 32, .addr = ip };
    return bpf_map_lookup_elem(&cidr_rules, &key) != NULL;
}

// Updates the stats counters (per-CPU, no lock)
static __always_inline void update_stats(__u64 bytes, int dropped) {
    __u32 idx = 0;
    struct stats_t *s = bpf_map_lookup_elem(&stats, &idx);
    if (!s) return;

    __sync_fetch_and_add(&s->hits, 1);
    __sync_fetch_and_add(&s->bytes_seen, bytes);
    if (dropped)
        __sync_fetch_and_add(&s->drops, 1);
    s->last_seen_ns = bpf_ktime_get_ns();
}

// Counts an event lost because the ring is full (per-CPU: no atomic).
// libbpf does not report ringbuf losses to userspace, so this counter is
// the only record that they occurred; it is exposed through the "stats" telemetry map.
static __always_inline void count_ring_drop(void) {
    __u32 idx = 0;
    struct stats_t *s = bpf_map_lookup_elem(&stats, &idx);
    if (s)
        s->ring_drops++;
}

// Emits an event to the ring buffer
static __always_inline void emit_event(__u32 src, __u32 dst,
                                        __u16 dport, __u8 proto, __u8 action) {
    struct event_t *e = bpf_ringbuf_reserve(&blocked_events,
                                             sizeof(struct event_t), 0);
    if (!e) {   // ring buffer full - drop_policy="drop" in toml
        count_ring_drop();
        return;
    }

    e->ts_ns  = bpf_ktime_get_ns();
    e->src_ip = src;
    e->dst_ip = dst;
    e->dport  = dport;
    e->proto  = proto;
    e->action = action;

    bpf_ringbuf_submit(e, 0);
}


// 5. Main program
// SEC("tc") -> hook_type = "tc_egress" in toml
// The function name does not matter for the contract; what matters is SEC().

SEC("tc")
int net_block_egress(struct __sk_buff *skb) {
    // Read IP header via CO-RE
    // BPF_CORE_READ resolves offsets at load time, not at compile time
    void *data     = (void *)(long)skb->data;
    void *data_end = (void *)(long)skb->data_end;

    // Validate there is room for an Ethernet + IP header
    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end)
        return TC_ACT_OK;

    if (eth->h_proto != bpf_htons(ETH_P_IP))
        return TC_ACT_OK;

    struct iphdr *ip = (void *)(eth + 1);
    if ((void *)(ip + 1) > data_end)
        return TC_ACT_OK;

    __u32 src_ip = ip->saddr;
    __u32 dst_ip = ip->daddr;
    __u8  proto  = ip->protocol;
    __u64 pkt_bytes = skb->len;

    // Read destination port if TCP/UDP
    __u16 dport = 0;
    if (proto == IPPROTO_TCP || proto == IPPROTO_UDP) {
        // port offset: after the IP header (ihl * 4 bytes)
        __u32 ip_hlen = ip->ihl * 4;
        void *transport = (void *)ip + ip_hlen;
        if (transport + 4 > data_end)
            goto allow;
        // destination port is in bytes 2-3 of the TCP/UDP header
        __u16 *dport_ptr = transport + 2;
        if ((void *)(dport_ptr + 1) > data_end)
            goto allow;
        dport = bpf_ntohs(*dport_ptr);
    }

    // Blocking logic
    // 1. check the exact blocklist (O(1))
    if (is_blocked_exact(src_ip)) {
        update_stats(pkt_bytes, 1);
        emit_event(src_ip, dst_ip, dport, proto, 1 /*DROP*/);
        return TC_ACT_SHOT;
    }

    // 2. check CIDR rules (LPM, more costly - after the hash)
    if (is_blocked_cidr(src_ip)) {
        update_stats(pkt_bytes, 1);
        emit_event(src_ip, dst_ip, dport, proto, 1 /*DROP*/);
        return TC_ACT_SHOT;
    }

allow:
    update_stats(pkt_bytes, 0);
    return TC_ACT_OK;
}


// 6. Lifecycle hooks
// toml: on_load = "init_defaults"
// The app calls this function via bpf_prog_test_run after loading the object.
// Useful to pre-populate config, clear stats, etc.

SEC("syscall")
int init_defaults(void *ctx) {
    // Set CONFIG_ENABLED = 1 by default
    __u32 key = 0, val = 1;
    bpf_map_update_elem(&cfg_map, &key, &val, BPF_ANY);
    return 0;
}

char _license[] SEC("license") = "GPL";
