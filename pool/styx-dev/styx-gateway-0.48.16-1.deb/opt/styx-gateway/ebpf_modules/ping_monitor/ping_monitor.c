// SPDX-License-Identifier: GPL-2.0
// ping_monitor.c - XDP ICMP echo request/reply monitor with flood detection.

#ifndef BCC_COMPILE
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_endian.h>
#include <xdp/xdp_helpers.h>
#else
#include <uapi/linux/if_ether.h>
#include <uapi/linux/ip.h>
#include <uapi/linux/icmp.h>
#include <uapi/linux/in.h>
#endif

struct icmp_stats_t {
    __u64 requests;
    __u64 replies;
    __u64 bytes;
    __u64 last_alert_ns;  // cooldown: suppress duplicate alerts within 1 s
};

struct totals_t {
    __u64 floods;      // offset 0 - verifier-tested
    __u64 requests;
    __u64 replies;
    __u64 ring_drops;  // alerts lost to a full ring (reserve returned NULL)
};

// Must match ping_monitor_companion.py FloodAlertDeserializer struct layout
struct alert_t {
    __u32 src_ip;
    __u64 requests;
} __attribute__((packed));

// Per-IP ICMP statistics (PERCPU for XDP concurrency).
struct {
    __uint(type, BPF_MAP_TYPE_PERCPU_HASH);
    __uint(max_entries, 65536);
    __type(key, __u32);
    __type(value, struct icmp_stats_t);
} icmp_stats SEC(".maps");

// Global counters exposed as telemetry (plain ARRAY - no PERCPU overhead).
struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 1);
    __type(key, __u32);
    __type(value, struct totals_t);
} totals SEC(".maps");

// Configuration: key 0 = threshold (0 or unset -> default 100).
struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 1);
    __type(key, __u32);
    __type(value, __u32);
} cfg SEC(".maps");

// Ring buffer for flood alerts.
struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);
} flood_alert SEC(".maps");

static __always_inline int is_icmp_echo(__u8 type) {
    return type == 8 || type == 0;
}

// XDP dispatcher metadata: passive monitor - run last, always chain on XDP_PASS.
// Runtime priority is set from module.toml (default 100); this is the fallback.
struct {
    __uint(priority, 100);
    __uint(XDP_PASS, 1);
} XDP_RUN_CONFIG(ping_monitor);

SEC("xdp")
int ping_monitor(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;
    void *data     = (void *)(long)ctx->data;

    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end) return XDP_PASS;
    if (eth->h_proto != bpf_htons(0x0800)) return XDP_PASS;

    struct iphdr *ip = (void *)(eth + 1);
    if ((void *)(ip + 1) > data_end) return XDP_PASS;
    if (ip->protocol != IPPROTO_ICMP) return XDP_PASS;

    struct icmphdr *icmp = (void *)((void *)ip + (ip->ihl * 4));
    if ((void *)(icmp + 1) > data_end) return XDP_PASS;
    if (!is_icmp_echo(icmp->type)) return XDP_PASS;

    __u32 src_ip = ip->saddr;
    __u16 pkt_len = data_end - data;
    __u8 is_request = (icmp->type == 8);

    // Per-IP stats - PERCPU_HASH needs explicit init on first sight of each IP
    struct icmp_stats_t zero_val = {};
    struct icmp_stats_t *entry = bpf_map_lookup_elem(&icmp_stats, &src_ip);
    if (!entry) {
        bpf_map_update_elem(&icmp_stats, &src_ip, &zero_val, BPF_NOEXIST);
        entry = bpf_map_lookup_elem(&icmp_stats, &src_ip);
    }
    if (entry) {
        if (is_request) __sync_fetch_and_add(&entry->requests, 1);
        else            __sync_fetch_and_add(&entry->replies, 1);
        __sync_fetch_and_add(&entry->bytes, pkt_len);
    }

    // Global totals + flood detection
    __u32 zero = 0;
    struct totals_t *tot = bpf_map_lookup_elem(&totals, &zero);
    if (tot) {
        if (is_request) __sync_fetch_and_add(&tot->requests, 1);
        else            __sync_fetch_and_add(&tot->replies, 1);

        // Flood alert: threshold of 0 means use default (100).
        // On first use, write the default back to the map so the admin
        // can read the effective value via map-get.
        // 1 s cooldown per IP (PERCPU) to avoid event storms.
        __u32 *threshold = bpf_map_lookup_elem(&cfg, &zero);
        __u32 limit;
        if (threshold && *threshold > 0) {
            limit = *threshold;
        } else {
            static const __u32 default_val = 100;
            bpf_map_update_elem(&cfg, &zero, &default_val, BPF_ANY);
            limit = default_val;
        }
        if (entry && is_request) {
            __u64 count = __sync_fetch_and_add(&entry->requests, 0);
            __u64 now_ns = bpf_ktime_get_ns();
            __u64 last = entry->last_alert_ns;
            if (count > limit && now_ns - last >= 1000000000ULL) {
                entry->last_alert_ns = now_ns;
                __sync_fetch_and_add(&tot->floods, 1);
                struct alert_t *a;
                a = bpf_ringbuf_reserve(&flood_alert, sizeof(*a), 0);
                if (a) {
                    a->src_ip = src_ip;
                    a->requests = count;
                    bpf_ringbuf_submit(a, 0);
                } else {
                    // Ring full: the alert is lost. libbpf does not report it, so
                    // it is counted here (shared map -> atomic increment) and
                    // surfaces through the "totals" telemetry map.
                    __sync_fetch_and_add(&tot->ring_drops, 1);
                }
            }
        }
    }

    return XDP_PASS;
}

char _license[] SEC("license") = "GPL";
