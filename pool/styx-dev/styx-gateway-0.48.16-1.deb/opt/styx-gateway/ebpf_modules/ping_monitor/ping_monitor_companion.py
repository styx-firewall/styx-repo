# ping_monitor/ping_monitor_companion.py

import ctypes

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import serialize_uint32, format_uint32, u32_to_ip, aggregate_percpu, ktime_to_epoch

# Companion API

_SERIALIZERS = {"cfg": serialize_uint32}


def serialize_entry(items, map_name, op):
    try:
        handler = _SERIALIZERS[map_name]
    except KeyError:
        raise ValueError(f"Map '{map_name}' does not support push")
    return [handler(item) for item in items]


# Custom formatter for icmp_stats


def _format_icmp_stats(key, value):
    # Kernel-written IPs from network packets are in big-endian byte order.
    key_repr = {"ip": u32_to_ip(key)}
    val_repr = None
    if value:
        val_repr = aggregate_percpu(
            value,
            ["requests", "replies", "bytes", "last_alert_ns"],
            ["<Q", "Q", "Q", "Q"],
        )
        val_repr["last_alert"] = ktime_to_epoch(val_repr.pop("last_alert_ns", 0))
    return key_repr, val_repr


_FORMATTERS = {"cfg": format_uint32, "icmp_stats": _format_icmp_stats}


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# Telemetry / Event deserializers


@register_deserializer("ping_monitor", "totals")
class TotalsDeserializer(FeedbackDeserializer):
    class _Struct(ctypes.Structure):
        _pack_ = 1
        _fields_ = [
            ("floods", ctypes.c_uint64),
            ("requests", ctypes.c_uint64),
            ("replies", ctypes.c_uint64),
            ("ring_drops", ctypes.c_uint64),
        ]

    def from_map(self, raw, spec, key=None) -> dict:
        val = self._Struct.from_buffer_copy(bytes(raw))
        return {
            "floods": val.floods,
            "requests": val.requests,
            "replies": val.replies,
            "ring_drops": val.ring_drops,
        }

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("totals is a telemetry map, not an event buffer")


@register_deserializer("ping_monitor", "flood_alert")
class FloodAlertDeserializer(FeedbackDeserializer):
    class _Struct(ctypes.Structure):
        _pack_ = 1
        _fields_ = [
            ("src_ip", ctypes.c_uint32),
            ("requests", ctypes.c_uint64),
        ]

    def from_map(self, raw, spec, key=None) -> dict:
        raise NotImplementedError("flood_alert is an event buffer, not a telemetry map")

    def from_event(self, data: bytes, size: int, spec) -> dict:
        import ipaddress
        import struct

        src_ip_raw = struct.unpack("!I", data[0:4])[0]
        requests = struct.unpack("<Q", data[4:12])[0]
        src_ip_str = str(ipaddress.IPv4Address(src_ip_raw))
        return {
            "src_ip": src_ip_str,
            "requests": requests,
            "summary": f"ICMP flood from {src_ip_str}: {requests} requests",
        }
