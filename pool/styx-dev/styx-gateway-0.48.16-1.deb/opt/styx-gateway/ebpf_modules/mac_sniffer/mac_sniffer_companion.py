# modules/mac_sniffer/mac_sniffer_companion.py
#
# Companion for mac_sniffer.
# - format_map_entry for hosts control map (MAC → IP)
# - deserializer for host_count telemetry (new MACs per poll interval)

import ipaddress

from services.ebpf.feedback.feedback_deserializer_base import FeedbackDeserializer
from services.ebpf.feedback.feedback_deserializer_registry import register_deserializer

from _helpers import aggregate_percpu

# Control map formatters


def _format_hosts_entry(key, value):
    """Parse raw key (u64 MAC, little-endian) and raw value (u32 IP, big-endian)."""
    key_bytes = bytes(key)
    mac_int = int.from_bytes(key_bytes[:8], "little")
    mac_str = ":".join(f"{(mac_int >> (8 * i)) & 0xFF:02x}" for i in range(6))

    val_bytes = bytes(value)
    ip_int = int.from_bytes(val_bytes[:4], "big")
    ip_str = str(ipaddress.IPv4Address(ip_int))

    return mac_str, ip_str


_FORMATTERS = {"hosts": _format_hosts_entry}


def format_map_entry(key, value, map_name):
    handler = _FORMATTERS.get(map_name)
    if handler is None:
        return None, None
    return handler(key, value)


# Telemetry deserializers


@register_deserializer("mac_sniffer", "host_count")
class HostCountDeserializer(FeedbackDeserializer):
    """Aggregate per-CPU new-MAC counter."""

    def from_map(self, raw, spec, key=None) -> dict:
        totals = aggregate_percpu(raw, ["new_macs"], ["<Q"])
        return {"new_macs": totals["new_macs"]}

    def from_event(self, data: bytes, size: int, spec) -> dict:
        raise NotImplementedError("host_count is a telemetry map, not an event buffer")
