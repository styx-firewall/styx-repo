// SPDX-License-Identifier: GPL-2.0
// xdp_cpu_redirect.c - CO-RE XDP CPU load balancer using CPUMAP
//
// Adapted from Suricata OISF XDP CPU load balancer
// (Copyright (C) 2019 Open Information Security Foundation).
//
// Hashes (src_ip, dst_ip) pairs for session-affine CPU steering.
// Supports IPv4, IPv6, VLAN (802.1Q / 802.1AD), and optional
// GRE decapsulation controlled via runtime config map.
//
// The SuperFastHash implementation below is LGPL-2.1 licensed
// (Paul Hsieh, http://www.azillionmonkeys.com/qed/hash.html)
// and is compatible with the GPL-2.0 main program.
//
// See module.toml for usage, control maps, and telemetry.

#ifndef BCC_COMPILE
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_endian.h>
#include <xdp/xdp_helpers.h>

// EtherType constants - not in vmlinux.h (they're #define, not BTF types)
#ifndef ETH_P_IP
#define ETH_P_IP    0x0800
#endif
#ifndef ETH_P_IPV6
#define ETH_P_IPV6  0x86DD
#endif
#ifndef ETH_P_ARP
#define ETH_P_ARP   0x0806
#endif
#ifndef ETH_P_8021Q
#define ETH_P_8021Q 0x8100
#endif
#ifndef ETH_P_8021AD
#define ETH_P_8021AD 0x88A8
#endif
#endif  // BCC_COMPILE

// GRE flag bits - not in vmlinux.h (they're #define in <uapi/linux/gre.h>)
#define GRE_CSUM    0x0080
#define GRE_KEY     0x2000
#define GRE_SEQ     0x1000
#define GRE_VERSION 0x0001
#define GRE_ROUTING 0x0002

#ifndef ETH_P_ERSPAN
#define ETH_P_ERSPAN 0x22EB
#endif

#ifndef IPPROTO_GRE
#define IPPROTO_GRE 47
#endif

// EtherType for GRE - IP protocol 47 inside IPv4
#define ETH_P_GRE_IPV4 ETH_P_IP

// Maximum CPUs supported
#define CPUMAP_MAX_CPUS 256

// Hash initial value
#define HASH_INITVAL 15485863

/*
 * SuperFastHash (LGPL-2.1, Paul Hsieh)
 * Based on: http://www.azillionmonkeys.com/qed/hash.html
 * */

#define get16bits(d) \
    ((((uint32_t)(((const uint8_t *)(d))[1])) << 8) + \
      (uint32_t)(((const uint8_t *)(d))[0]))

static __always_inline uint32_t
SuperFastHash(const char *data, int len, uint32_t initval)
{
    uint32_t hash = initval;
    uint32_t tmp;
    int rem;

    if (len <= 0 || data == NULL)
        return 0;

    rem = len & 3;
    len >>= 2;

    /* Main loop */
#pragma clang loop unroll(full)
    for (; len > 0; len--) {
        hash += get16bits(data);
        tmp = (get16bits(data + 2) << 11) ^ hash;
        hash = (hash << 16) ^ tmp;
        data += 2 * sizeof(uint16_t);
        hash += hash >> 11;
    }

    /* Handle end cases */
    switch (rem) {
    case 3:
        hash += get16bits(data);
        hash ^= hash << 16;
        hash ^= ((signed char)data[sizeof(uint16_t)]) << 18;
        hash += hash >> 11;
        break;
    case 2:
        hash += get16bits(data);
        hash ^= hash << 11;
        hash += hash >> 17;
        break;
    case 1:
        hash += (signed char)*data;
        hash ^= hash << 10;
        hash += hash >> 1;
    }

    /* Force "avalanching" of final 127 bits */
    hash ^= hash << 3;
    hash += hash >> 5;
    hash ^= hash << 4;
    hash += hash >> 17;
    hash ^= hash << 25;
    hash += hash >> 6;

    return hash;
}

/*
 * End of SuperFastHash block (LGPL-2.1)
 **/

// Telemetry struct

struct stats_t {
    __u64 packets_processed;
    __u64 packets_redirected;
    __u64 packets_passed;
    __u64 errors;
};

// Maps

// Runtime config - adjustable via control-push without reload
//   Key 0: gre_decap_enabled  (0=off, 1=on, default: 1)
//   Key 1: ipv6_enabled       (0=off, 1=on, default: 1)
struct {
    __uint(type,        BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 4);
    __type(key,         __u32);
    __type(value,       __u32);
} cfg_map SEC(".maps");

// Hash index → real CPU number (populated by companion populate_init_maps)
struct {
    __uint(type,        BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, CPUMAP_MAX_CPUS);
    __type(key,         __u32);
    __type(value,       __u32);
} cpus_available SEC(".maps");

// Single entry: number of available CPUs (populated by companion)
struct {
    __uint(type,        BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 1);
    __type(key,         __u32);
    __type(value,       __u32);
} cpus_count SEC(".maps");

// CPUMAP - populated by companion on init via bpf_map_update_elem()
// (bpf_cpumap_val comes from vmlinux.h)
struct {
    __uint(type,        BPF_MAP_TYPE_CPUMAP);
    __uint(max_entries, CPUMAP_MAX_CPUS);
    __type(key,         __u32);
    __type(value,       struct bpf_cpumap_val);
} cpu_map SEC(".maps");

// Per-CPU telemetry counters
struct {
    __uint(type,        BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key,         __u32);
    __type(value,       struct stats_t);
} stats SEC(".maps");

// XDP dispatcher metadata

// Priority 40 - runs after early filters (ddos_protect: 30, ip_drop: 90).
// Only XDP_PASS needs chain-call (redirect is terminal).
// Runtime priority is overridden by [[pre_attach_param]].
struct {
    __uint(priority, 40);
    __uint(XDP_PASS, 1);
} XDP_RUN_CONFIG(xdp_cpu_redirect);

// Helpers

static __always_inline __u32 read_cfg(__u32 key, __u32 default_val)
{
    __u32 *val = bpf_map_lookup_elem(&cfg_map, &key);
    return val ? *val : default_val;
}

static __always_inline void inc_stat(__u32 field)
{
    __u32 zero = 0;
    struct stats_t *s = bpf_map_lookup_elem(&stats, &zero);
    if (!s)
        return;
    switch (field) {
    case 0: __sync_fetch_and_add(&s->packets_processed, 1); break;
    case 1: __sync_fetch_and_add(&s->packets_redirected, 1); break;
    case 2: __sync_fetch_and_add(&s->packets_passed, 1); break;
    case 3: __sync_fetch_and_add(&s->errors, 1); break;
    }
}

// IP hashing

static __always_inline int hash_ipv4(void *data, void *data_end)
{
    struct iphdr *iph = data;
    if ((void *)(iph + 1) > data_end)
        return XDP_PASS;

    __u32 key0 = 0;
    __u32 *cpu_max = bpf_map_lookup_elem(&cpus_count, &key0);
    __u32 *cpu_selected;
    __u32 cpu_hash;
    __u32 cpu_dest;

    // Session affinity: saddr + daddr hash to the same CPU
    cpu_hash = iph->saddr + iph->daddr;
    cpu_hash = SuperFastHash((char *)&cpu_hash, 4, HASH_INITVAL);

    if (cpu_max && *cpu_max) {
        cpu_dest = cpu_hash % *cpu_max;
        cpu_selected = bpf_map_lookup_elem(&cpus_available, &cpu_dest);
        if (!cpu_selected)
            return XDP_ABORTED;
        return bpf_redirect_map(&cpu_map, *cpu_selected, 0);
    }
    return XDP_PASS;
}

static __always_inline int hash_ipv6(void *data, void *data_end)
{
    struct ipv6hdr *ip6h = data;
    if ((void *)(ip6h + 1) > data_end)
        return XDP_PASS;

    __u32 key0 = 0;
    __u32 *cpu_max = bpf_map_lookup_elem(&cpus_count, &key0);
    __u32 *cpu_selected;
    __u32 cpu_hash;
    __u32 cpu_dest;

    // Session affinity across all 32 bytes of an IPv6 pair
    // Kernel's struct in6_addr uses union in6_u { u6_addr32[4] }
    cpu_hash  = ip6h->saddr.in6_u.u6_addr32[0] + ip6h->daddr.in6_u.u6_addr32[0];
    cpu_hash += ip6h->saddr.in6_u.u6_addr32[1] + ip6h->daddr.in6_u.u6_addr32[1];
    cpu_hash += ip6h->saddr.in6_u.u6_addr32[2] + ip6h->daddr.in6_u.u6_addr32[2];
    cpu_hash += ip6h->saddr.in6_u.u6_addr32[3] + ip6h->daddr.in6_u.u6_addr32[3];
    cpu_hash = SuperFastHash((char *)&cpu_hash, 4, HASH_INITVAL);

    if (cpu_max && *cpu_max) {
        cpu_dest = cpu_hash % *cpu_max;
        cpu_selected = bpf_map_lookup_elem(&cpus_available, &cpu_dest);
        if (!cpu_selected)
            return XDP_ABORTED;
        return bpf_redirect_map(&cpu_map, *cpu_selected, 0);
    }
    return XDP_PASS;
}

// GRE decapsulation

static __always_inline int
filter_gre(struct xdp_md *ctx, void *data, __u64 nh_off, void *data_end)
{
    struct iphdr *iph = data + nh_off;
    __u16 proto;

    nh_off += sizeof(struct iphdr);
    struct gre_base_hdr *grhdr = (struct gre_base_hdr *)(iph + 1);

    if ((void *)(grhdr + 1) > data_end)
        return XDP_PASS;

    // Skip GRE packets with version or routing flags set
    if (grhdr->flags & (GRE_VERSION | GRE_ROUTING))
        return XDP_PASS;

    // GRE base header is 4 bytes
    nh_off += 4;
    proto = grhdr->protocol;

    // Optional GRE fields (each 4 bytes)
    if (grhdr->flags & GRE_CSUM)
        nh_off += 4;
    if (grhdr->flags & GRE_KEY)
        nh_off += 4;
    if (grhdr->flags & GRE_SEQ)
        nh_off += 4;

    // ERSPAN (Encapsulated Remote SPAN) header
    if (proto == bpf_htons(ETH_P_ERSPAN))
        nh_off += 8;

    if (data + nh_off > data_end)
        return XDP_PASS;

    // Strip outer headers so the inner packet starts at Ethernet
    if (bpf_xdp_adjust_head(ctx, 0 + (int)nh_off))
        return XDP_PASS;

    // Reload pointers after adjust_head
    data     = (void *)(long)ctx->data;
    data_end = (void *)(long)ctx->data_end;

    // Now parse the inner Ethernet header
    struct ethhdr *eth = data;
    proto = eth->h_proto;
    nh_off = sizeof(*eth);

    if (data + nh_off > data_end)
        return XDP_PASS;

    // VLAN on inner packet
    if (proto == bpf_htons(ETH_P_8021Q) || proto == bpf_htons(ETH_P_8021AD)) {
        struct vlan_hdr *vhdr = (struct vlan_hdr *)(data + nh_off);
        if ((void *)(vhdr + 1) > data_end)
            return XDP_PASS;
        proto = vhdr->h_vlan_encapsulated_proto;
        nh_off += sizeof(struct vlan_hdr);
    }

    if (data + nh_off > data_end)
        return XDP_PASS;

    if (proto == bpf_htons(ETH_P_IP))
        return hash_ipv4(data + nh_off, data_end);
    else if (proto == bpf_htons(ETH_P_IPV6))
        return hash_ipv6(data + nh_off, data_end);

    return XDP_PASS;
}

// IP filters

static __always_inline int
filter_ipv4(struct xdp_md *ctx, void *data, __u64 nh_off, void *data_end)
{
    struct iphdr *iph = data + nh_off;
    if ((void *)(iph + 1) > data_end)
        return XDP_PASS;

    // GRE decapsulation (only if enabled via cfg_map[0])
    if (iph->protocol == IPPROTO_GRE && read_cfg(0, 1))
        return filter_gre(ctx, data, nh_off, data_end);

    return hash_ipv4(data + nh_off, data_end);
}

static __always_inline int
filter_ipv6(struct xdp_md *ctx, void *data, __u64 nh_off, void *data_end)
{
    struct ipv6hdr *ip6h = data + nh_off;
    if ((void *)(ip6h + 1) > data_end)
        return XDP_PASS;

    return hash_ipv6((void *)ip6h, data_end);
}

// Main XDP program

SEC("xdp")
int xdp_cpu_redirect(struct xdp_md *ctx)
{
    void *data_end = (void *)(long)ctx->data_end;
    void *data     = (void *)(long)ctx->data;
    struct ethhdr *eth = data;
    __u16 h_proto;
    __u64 nh_off;

    nh_off = sizeof(*eth);
    if (data + nh_off > data_end)
        return XDP_PASS;

    h_proto = eth->h_proto;

    // Walk up to 2 levels of VLAN tags (802.1Q and 802.1AD / QinQ)
    if (h_proto == bpf_htons(ETH_P_8021Q) || h_proto == bpf_htons(ETH_P_8021AD)) {
        struct vlan_hdr *vhdr = data + nh_off;
        nh_off += sizeof(struct vlan_hdr);
        if (data + nh_off > data_end)
            return XDP_PASS;
        h_proto = vhdr->h_vlan_encapsulated_proto;
    }
    if (h_proto == bpf_htons(ETH_P_8021Q) || h_proto == bpf_htons(ETH_P_8021AD)) {
        struct vlan_hdr *vhdr = data + nh_off;
        nh_off += sizeof(struct vlan_hdr);
        if (data + nh_off > data_end)
            return XDP_PASS;
        h_proto = vhdr->h_vlan_encapsulated_proto;
    }

    inc_stat(0);  // packets_processed

    if (h_proto == bpf_htons(ETH_P_IP)) {
        return filter_ipv4(ctx, data, nh_off, data_end);
    } else if (h_proto == bpf_htons(ETH_P_IPV6)) {
        // IPv6 only if enabled (cfg_map[1])
        if (read_cfg(1, 1))
            return filter_ipv6(ctx, data, nh_off, data_end);
    }

    inc_stat(2);  // packets_passed (fallthrough)
    return XDP_PASS;
}

char _license[] SEC("license") = "GPL";
