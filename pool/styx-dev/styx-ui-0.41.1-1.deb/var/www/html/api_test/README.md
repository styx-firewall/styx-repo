# Styx API tooling

Python tooling para interactuar con la API HTTP de una máquina Styx
(`/request.php` + `/submit.php`) contra una máquina objetivo real. Sustituye al
antiguo runner declarativo basado en payloads JSON.

Tres usos en un mismo conjunto de scripts:

1. **Probing** — explorar la API y encadenar verificaciones ad-hoc.
2. **Verificación / regresión** — flujos completos (crear → verificar → borrar) y
   chequeos read-only de consistencia/estado real.
3. **Provisioning / despliegue** — configurar una máquina con una configuración concreta.

Cada corrida apunta a **una máquina por nombre** (`--target <nombre>`): el
`config.json` define un mapa `targets` y el script resuelve el que se le pida.
No hay target por defecto: si no se especifica `--target` (o el nombre no
existe) el script falla y lista los targets disponibles.

## Requisitos

- `python3` (solo stdlib, sin dependencias externas: no `requests`, no `jmespath`, no `curl`).
- Correr los scripts directo (`python api_test/<categoria>/<script>.py`) o como módulo desde la raíz (`python -m api_test.<categoria>.<script>`).
- `api_test/config.json` (gitignored):

```json
{
  "targets": {
    "maquina1": {
      "base_url": "https://IP_MAQUINA1",
      "bearer_token": "tk_live_...",
      "timeout": 10,
      "verify_tls": false
    },
    "maquina2": {
      "base_url": "https://IP_MAQUINA2:3041",
      "bearer_token": "tk_live_..."
    }
  }
}
```

Copia `config.example.json` → `config.json` y rellena los targets. El token se
valida en el backend; mantén `config.json` fuera del control de versiones (ya
está en `.gitignore`). Un target copiado sin rellenar (token placeholder) solo
falla **cuando se selecciona**, no al cargar el config.

## Estructura

`api_test` funciona como **paquete** y también con invocación **directa**; las
categorías separan los tipos de flujo y `apicore` es la carpeta del módulo
compartido que importan los scripts.

```
api_test/                         # paquete (__init__.py)
├── README.md                     # Esta guía
├── config.example.json           # Plantilla de configuración (targets)
├── config.json                   # Targets reales (gitignored)
├── probe.py                      # Probing genérico (cualquier action/command)
├── apicore/                      # Módulo compartido (librería, no se ejecuta directo)
│   ├── __init__.py
│   ├── api_client.py             # Cliente común + carga/resolución de targets
│   └── verify_common.py          # Helpers compartidos (argparse, build_client, cleanup, finish)
├── consistency/                  # Chequeos read-only de consistencia / estado real (no mutan)
│   ├── verify_readonly.py        # Smoke checks read-only de /request.php
│   ├── verify_firewall_consistency.py  # Reporte de consistencia del firewall
│   ├── verify_ct_logs.py         # Fetch + resumen de logs conntrack
│   └── verify_labels.py          # Tipos de label permitidos + rechazo de tipos desconocidos
├── integration/                  # Lifecycles crear → verificar → borrar (mutan el estado real y lo dejan limpio)
│   ├── verify_sets.py            # Sets (ports/addresses/domains/interface-sets) con la matriz de tipos
│   ├── verify_tc.py              # Traffic Control (qdisc/class/rule en if0 e if1)
│   ├── verify_packet_marking.py
│   ├── verify_virtual_interfaces.py
│   └── verify_fw_rules_regression.py
├── health/                       # Housekeeping del gateway (report por defecto; mutan con flags explícitos)
│   ├── verify_orphan_refs.py     # cleanup_orphan_refs (--apply / --commit)
│   └── verify_cert_metadata.py   # refresh_cert_metadata (--apply / --force)
└── deploy/                       # Provisioning / despliegue idempotente
    ├── provision_example.py      # Plantilla (copiar por perfil y rellenar deploy())
    ├── provision_default_sets.py # Siembra los sets por defecto (equivalente HTTP de tools/seed_default_sets.py)
    └── upgrade_and_reboot.py     # Actualiza paquetes, reinicia y espera hasta 60 s a que vuelva (destructivo)
```

## Uso rápido

```bash
# Smoke checks read-only (no modifica nada) contra una máquina concreta
python api_test/consistency/verify_readonly.py --target maquina1

# Flujos lifecycle completos (crean y borran; dejan el estado limpio)
python api_test/integration/verify_sets.py --target maquina1
python api_test/integration/verify_tc.py --target maquina1
python api_test/integration/verify_packet_marking.py --target maquina1
python api_test/integration/verify_virtual_interfaces.py --target maquina1

# Probing interactivo
python api_test/probe.py --action get_interfaces_sets --target maquina1
python api_test/probe.py --command set_port --dry-run --name p1 --type single --value_single 8080 --target maquina1

# Provisioning (preview sin aplicar, luego aplicar)
python api_test/deploy/provision_example.py --target maquina1 --dry-run
python api_test/deploy/provision_example.py --target maquina1

# Seed de sets por defecto (catálogo files/default_sets.json)
python api_test/deploy/provision_default_sets.py --target maquina1 --dry-run   # preview (no aplica nada)
python api_test/deploy/provision_default_sets.py --target maquina1             # aplicar (running-config)
python api_test/deploy/provision_default_sets.py --target maquina1 --save      # aplicar + persistir a startup-config

# Upgrade + reinicio (DESTRUCTIVO: corta el servicio; el script espera a que vuelva)
python api_test/deploy/upgrade_and_reboot.py --target maquina1
python api_test/deploy/upgrade_and_reboot.py --target all                      # todas las del config, en serie

# Cleanup de refs huérfanos (report-only; --apply purga running-config sin persistir; --commit purga + save_config)
python api_test/health/verify_orphan_refs.py --target maquina1
python api_test/health/verify_orphan_refs.py --target maquina1 --apply
python api_test/health/verify_orphan_refs.py --target maquina1 --commit

# Refresh de metadata parseada de certificados (preview; --apply para aplicar)
python api_test/health/verify_cert_metadata.py --target maquina1
python api_test/health/verify_cert_metadata.py --target maquina1 --apply --force
```

Equivalente como módulo (desde la raíz del repo): `python -m api_test.<categoria>.<script> ...`.

Si no pasas `--target`, o pasas uno que no existe en el config, el script imprime
`  FAIL` con el listado de targets disponibles y termina con código 1. `--config`
permite apuntar a otro archivo de configuración (p. ej. el de otra persona).

## Migración desde el config plano

El formato anterior era un único par `base_url`/`bearer_token` a nivel raíz (y,
para varias máquinas, se "aparcaban" claves viejas con prefijo `_`). Ese formato
ya no se soporta. Para migrar, mueve cada máquina a su entrada `targets`:

```json
{
  "targets": {
    "maquina_actual": { "base_url": "https://192.168.2.153", "bearer_token": "tk_live_..." },
    "maquina_aparcada": { "base_url": "https://192.168.3.202:3041", "bearer_token": "tk_live_..." }
  }
}
```

## Dry-run

La API soporta una bandera `"dry-run": true` en los comandos de `/submit.php`
(ver `handlers/handler_client.py` del gateway): el backend **valida** el comando
(schema/lógica) pero **no aplica** el cambio real; responde `status: success` con
una traza `debug` y `response_msg` prefijada con `"dry-run: "`. No todos los
comandos la soportan.

En el cliente: `client.submit(command, data, dry_run=True)` o `client.preview(command, data)`.
Cada script decide por llamada si quiere preview o cambio real — no hay un "modo"
global.

## El módulo compartido (`api_test/apicore`)

```python
from api_test.apicore.api_client import load_config, resolve_target, ApiClient, require_ok, dump
from api_test.apicore.verify_common import build_parser, build_client

cfg = load_config()                            # api_test/config.json
profile = resolve_target(cfg, "maquina1")      # {base_url, bearer_token, timeout, verify_tls}
api = ApiClient(profile["base_url"], profile["bearer_token"],
                verify_tls=profile["verify_tls"], timeout=profile["timeout"])

resp = api.request("get_interfaces_sets")      # POST /request.php
require_ok(resp, "result.interfaces")          # lanza AssertionError si falla

created = api.submit("set_port", {"name": "p1", "type": "single", "value_single": 443})
preview = api.preview("set_port", {...})       # dry-run
dump(resp)                                     # pretty-print
```

`resolve_target(cfg, name)` exige un nombre explícito (no hay default) y valida
solo ese target. Errores de red/timeout/HTTP no-200 lanzan `ApiError`; una
respuesta con `status != 'success'` (o sin las claves pedidas) hace fallar
`require_ok`.

## Escribir scripts de provisioning

Copia `deploy/provision_example.py` por perfil (p. ej.
`deploy/provision_office.py`) y rellena `deploy()`. Patrón recomendado:

1. Consulta `get_*` para ver qué existe.
2. Crea solo lo que falta (idempotente).
3. Pasa `--dry-run` para validar el despliegue completo antes de aplicarlo.

## Notas

- Los scripts `verify_*` se ejecutan contra el target indicado con `--target`;
  deben terminar con `0` y sin dejar recursos residuales (los borrados están
  dentro del propio script).
- Se corren directos o como módulo (`python -m` desde la raíz). El header con
  `if __package__ is None` agrega la raíz del repo a `sys.path` solo cuando se
  ejecuta el archivo directo; los imports son de paquete (`api_test.apicore.*`),
  así que el editor los resuelve igual.
- Opcionalmente se puede borrar `api_test/.venv` (ya no se usa ninguna dependencia).
- Para one-liners rápidos de solo lectura, bash + `curl | jq` sigue siendo una alternativa válida; esta herramienta no lo reemplaza.
