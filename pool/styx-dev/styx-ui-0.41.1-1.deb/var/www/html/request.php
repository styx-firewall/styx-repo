<?php
/**
 * Request entry point
 * Handles AJAX requests and routes to appropriate controllers
 */

require __DIR__ . '/bootstrap/bootstrap_api.php';

use App\Controllers\Request\StyxRequestController;
use App\Registry\RequestRegistry;

$action = $inputData['action'] ?? $inputData['command'] ?? '';

// Public actions that do not require authentication
$publicActions = [
];

// Early authentication (fail-fast)
if (!in_array($action, $publicActions, true)) {
    requireApiAuth($ctx);
}

try {

// === SPECIAL CASES ===
// styx-backup-download: modifies HTTP headers for file download
if ($action === 'styx-backup-download') {
    $controller = new StyxRequestController($ctx);
    $backup = $controller->getStyxBackup($inputData);
    if (isset($backup['status']) && $backup['status'] === 'error') {
        if (!headers_sent()) {
            if (function_exists('header_remove')) header_remove();
            header('Content-Type: application/json');
        }
        echo json_encode($backup);
        exit();
    }

    if (!headers_sent()) {
        header('Content-Type: application/json');
    }
    echo json_encode([
        'status' => 'success',
        'filename' => $backup['result']['filename'] ?? null,
        'result' => $backup['result']
    ]);
    exit();
}

// === REGISTRY ROUTING (same pattern as submit.php) ===
if (!RequestRegistry::has($action)) {
    echo json_encode(['status' => 'error', 'response_msg' => 'Invalid request action']);
    exit();
}

    $response = RequestRegistry::execute($ctx, $action, $inputData);
    echo json_encode($response);

} catch (\Exception $e) {
    echo json_encode(['status' => 'error', 'response_msg' => $e->getMessage()]);
}

exit();
