<?php

namespace App\Controllers\Request;

use App\Core\AppContext;
use App\Controllers\BaseController;

class StyxRequestController extends BaseController
{
    /**
     * Get Styx backup data
     */
    public function getStyxBackup($data)
    {
        // Forward any provided `data` from the request to the backend command.
        // Expecting shape: $data['data'] = ['type' => 'startup']
        $cmdData = (object)($data['data'] ?? []);
        $commands = [
            [
                'method' => 'styx-mgmt.get_backup',
                'id' => 'backup',
                'data' => $cmdData
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $backup = $resp['commands']['backup'] ?? null;
        if (empty($backup['result']['backup_content'])) {
            return $this->baseError('Backup data not received from backend.');
        }
        $response_data = $backup['result'];
        // The backend names the file with its type and a UTC timestamp; prefix
        // that so a saved copy is identifiable as a Styx backup.
        $response_data['filename'] = 'styx-' . $response_data['filename'];
        return [
            'status' => 'success',
            'result' => $response_data,
        ];
    }

    /**
     * Get enabled Styx features (summary)
     */
    public function getStyxEnabledFeatures()
    {
        $commands = [
            [
                'method' => 'styx-features.get_enabled_features',
                'id' => 'enabled_features',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['enabled_features'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'enabled_features command failed');
        }
        return [
            'status'   => $resp['status'],
            'result'   => ['features' => $cmd['result'] ?? []],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get full Styx features info (detailed)
     */
    public function getStyxFeaturesFull()
    {
        $commands = [
            [
                'method' => 'styx-features.get_features_full',
                'id' => 'enabled_features_full',
                'data' => (object)[],
            ]
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['enabled_features_full'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'enabled_features_full command failed');
        }
        return [
            'status'   => $resp['status'],
            'result'   => ['features' => $cmd['result']['features'] ?? []],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get events from event-manager-service
     * $filters - associative array of filters (e.g. ['since' => '2023-01-01T00:00:00Z', 'level' => 'error'])
     * Returns array of events or error array ['status' => 'error', 'response_msg' => '...']
     */
    /**
     * @param array<string,mixed> $data wire key: `filters` (optional)
     */
    public function getEvents(array $data)
    {
        $filters = $data['filters'] ?? [];
        if (!is_array($filters)) {
            return $this->baseError('filters must be an array');
        }

        $commands[] = [
            'method' => 'event-manager-service.get_events',
            'id' => 'events',
            'data' => (object)$filters,
        ];
        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $eventsCmd = $resp['commands']['events'] ?? null;
        if (!$eventsCmd || ($eventsCmd['status'] ?? null) !== 'success') {
            return $this->baseError($eventsCmd['response_msg'] ?? 'events command failed');
        }
        $events = $eventsCmd['result']['events'] ?? [];
        usort($events, function($a, $b) {
            $ta = 0;
            if (isset($a['timestamp'])) {
                if (is_numeric($a['timestamp'])) {
                    $ta = (float)$a['timestamp'];
                } else {
                    $ta = strtotime($a['timestamp']);
                }
            }
            $tb = 0;
            if (isset($b['timestamp'])) {
                if (is_numeric($b['timestamp'])) {
                    $tb = (float)$b['timestamp'];
                } else {
                    $tb = strtotime($b['timestamp']);
                }
            }
            return $tb <=> $ta;
        });
        return [
            'status'   => $resp['status'],
            'result'   => ['events' => $events],
            'warnings' => $resp['warnings'],
        ];
    }


    /**
     * Get Styx service settings from backend (commands: styx-settings and get_certs_by_usage)
     * Returns ['status' => 'success', 'data' => [...]] or an error array
     * The returned data will include a 'certificates' key with TLS server certs (possibly empty).
     */
    public function getStyxSettings()
    {
        $commands = [
            [
                'method' => 'styx-mgmt.get_styx_settings',
                'id' => 'settings',
                'data' => (object)[],
            ],
            [
                'method' => 'styx-mgmt.get_lighttpd_config',
                'id' => 'lighttpd',
                'data' => (object)[],
            ],
            [
                'method' => 'certs-mgmt.get_certs_by_usage',
                'id' => 'certs',
                'data' => [ 'usage' => 'tls-server' ],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmds = $resp['commands'];
        $settingsCmd = $cmds['settings'] ?? null;
        $uiSettings  = $cmds['lighttpd'] ?? null;
        $certsCmd    = $cmds['certs'] ?? null;

        if (!$settingsCmd || ($settingsCmd['status'] ?? null) !== 'success') {
            return $this->baseError($settingsCmd['response_msg'] ?? 'styx-settings command failed');
        }
        if (!$uiSettings || ($uiSettings['status'] ?? null) !== 'success') {
            return $this->baseError($uiSettings['response_msg'] ?? 'get_lighttpd_config command failed');
        }

        // Prepare certs data. If certs command is missing or errored, log and continue with empty certs.
        $certsData = [];
        if ($certsCmd === null) {
            $this->logService->warning('get_certs_by_usage command not found in response for getStyxSettings');
        } else {
            if (($certsCmd['status'] ?? null) === 'error') {
                $this->logService->warning('get_certs_by_usage returned error: ' . ($certsCmd['response_msg'] ?? 'Unknown'));
            } else {
                $certsData = $certsCmd['result']['certs'] ?? [];
            }
        }

        // Pre-process certificates for the view: filter by type, build display and selection flag
        $selectedPem = $uiSettings['result']['pemfile'] ?? '';
        $processedCerts = [];
        foreach ($certsData as $c) {
            $type = strtoupper($c['type'] ?? '');
            if ($type !== 'CERT') {
                continue;
            }
            $id = $c['id'] ?? '';
            $name = $c['name'] ?? ($c['file_name'] ?? '');
            $display = $name . ' (' . $type . ')';
            if (!empty($c['file_missing'])) {
                $display .= ' - missing';
            }
            $processedCerts[] = [
                'id' => $id,
                'name' => $name,
                'display' => $display,
                'cert_path' => $c['cert_path'] ?? '',
                'key_path' => $c['key_path'] ?? '',
                'file_missing' => !empty($c['file_missing']),
                'selected' => (!empty($selectedPem) && (($c['cert_path'] ?? '') === $selectedPem)),
            ];
        }

        $return_data['styx_settings'] = $settingsCmd['result'] ?? [];
        $uiPort = $uiSettings['result']['https_port'] ?? $uiSettings['result']['port'] ?? null;
        $return_data['certs'] = $processedCerts;
        $return_data['ui_settings'] = $uiSettings['result'] ?? [];
        $return_data['ui_settings']['pemfile'] = $selectedPem;
        // Expose https_port in ui_settings as provided by backend
        $return_data['ui_settings']['https_port'] = $uiPort;
        return [
            'status'   => $resp['status'],
            'result'   => $return_data,
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get watchdog watchers status from styx-mgmt.
     * Returns ['status' => 'success', 'result' => ['watchers' => [...]]]
     */
    public function getWatchers()
    {
        $commands = [
            [
                'method' => 'styx-mgmt.get_watchers',
                'id' => 'watchers',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['watchers'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'get_watchers command failed');
        }

        return [
            'status'   => $resp['status'],
            'result'   => ['watchers' => $cmd['result']['watchers'] ?? []],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Get config diff between startup-config and running-config.
     * Returns ['status' => 'success', 'result' => ['identical' => bool, 'config_dirty' => bool, 'diff' => string, 'summary' => [...]]]
     */
    public function getConfigDiff()
    {
        $commands = [
            [
                'method' => 'styx-mgmt.get_config_diff',
                'id' => 'config_diff',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['config_diff'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'get_config_diff command failed');
        }

        return [
            'status'   => $resp['status'],
            'result'   => $cmd['result'] ?? [],
            'warnings' => $resp['warnings'],
        ];
    }

    /**
     * Lightweight "do I have to offer a Save button?" check: the same answer as
     * the `config_dirty` field of get_config_diff, without computing the diff.
     * The backend reconciles the datastore dirty flag against disk first, so a
     * change applied and reverted without saving reports false.
     */
    public function hasUnsavedChanges()
    {
        $commands = [
            [
                'method' => 'styx-mgmt.has_unsaved_changes',
                'id' => 'has_unsaved_changes',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['has_unsaved_changes'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'has_unsaved_changes command failed');
        }

        return [
            'status'       => $resp['status'],
            'response_msg' => $cmd['response_msg'] ?? 'Unsaved changes check done',
            'result'       => $cmd['result'] ?? [],
            'warnings'     => $resp['warnings'],
        ];
    }

    /**
     * Which restarts the system is asking for, as two independent markers:
     * `gateway_restart_required` (newer styx-gateway code than the running
     * process, a service restart suffices) and `system_restart_required`
     * (Debian wants a reboot, typically a new kernel). Both can be pending at
     * once, and `system_restart_packages` names the packages that ask for it.
     * `response_msg` already summarizes the case.
     */
    public function getRestartRequired()
    {
        $commands = [
            [
                'method' => 'styx-mgmt.get_restart_required',
                'id' => 'get_restart_required',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['get_restart_required'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'get_restart_required command failed');
        }

        return [
            'status'       => $resp['status'],
            'response_msg' => $cmd['response_msg'] ?? 'Restart check done',
            'result'       => $cmd['result'] ?? [],
            'warnings'     => $resp['warnings'],
        ];
    }

    /**
     * Get available Styx backup types from the backend
     * Returns ['status' => 'success', 'result' => ['backup_types' => [...]]]
     */
    public function getStyxBackupTypes()
    {
        $commands = [
            [
                'method' => 'styx-mgmt.get_backup_types',
                'id' => 'backup_types',
                'data' => (object)[],
            ]
        ];

        $resp = $this->processGwResp($this->sendCommands($commands));
        if ($resp['status'] === 'error') {
            return $resp;
        }
        $cmd = $resp['commands']['backup_types'] ?? null;
        if (!$cmd || ($cmd['status'] ?? null) !== 'success') {
            return $this->baseError($cmd['response_msg'] ?? 'get_backup_types command failed');
        }

        return [
            'status' => $resp['status'],
            'result' => ['backup_types' => $cmd['result']['backup_types'] ?? []],
            'warnings' => $resp['warnings'],
        ];
    }

}
